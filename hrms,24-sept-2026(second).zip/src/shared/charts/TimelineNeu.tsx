import { forwardRef, useImperativeHandle, useRef, useState, useEffect } from 'react';
import type { ThreeChartHandle } from '../three/ThreeSankey3D';
import type { ExportTheme } from '../three/exportUtils';

/* ============================================================
   Neumorphic Timeline Infographic — a faithful rebuild of the supplied
   reference (timeline_infographic.html): a vibrant blue→green serpentine
   glossy tube snaking across three rows over a recessed base trench, white
   indicator beads on the rail, two large concentric neumorphic start/end
   dial badges (search-$ and hand-coin), and numbered milestone pills that
   alternate above / below the track with dashed connectors and a small
   ringed node dot. Two recessed paragraph slots sit at the corners.

   Rendered on the reference's own 1200×675 (16:9) SVG viewBox scaled to the
   tile, drawn DIRECTLY inside the tile (no separate white card) with a
   neumorphic build-in loading animation.
   ============================================================ */

export interface TimelineItem { n: number; label: string; detail?: string }

interface Props {
  items: TimelineItem[];
  theme: ExportTheme;
  dark?: boolean;
  startText?: string;
  endText?: string;
}

const VW = 1200, VH = 675;

/* Reference serpentine geometry (verbatim from timeline_infographic.html). */
const TRACK_D = 'M 315 220 L 770 220 A 75 75 0 0 1 770 370 L 430 370 A 75 75 0 0 0 430 520 L 885 520';
/* Fixed milestone slots along the snake (id → x,y, pill above/below). */
const SLOTS: { x: number; y: number; above: boolean }[] = [
  { x: 430, y: 220, above: true },   // 01
  { x: 600, y: 220, above: false },  // 02
  { x: 770, y: 220, above: true },   // 03
  { x: 770, y: 370, above: true },   // 04
  { x: 600, y: 370, above: false },  // 05
  { x: 430, y: 370, above: true },   // 06
  { x: 430, y: 520, above: true },   // 07
  { x: 600, y: 520, above: false },  // 08
  { x: 770, y: 520, above: true },   // 09
];
const NODE_STROKE = ['#2563eb', '#0284c7', '#06b6d4', '#10b981', '#06b6d4', '#0284c7', '#06b6d4', '#10b981', '#059669'];
const BEADS = [
  [360, 220], [515, 220], [685, 220], [845, 295],
  [685, 370], [515, 370], [360, 370], [355, 445],
  [360, 520], [515, 520], [685, 520], [840, 520],
];

const TimelineNeu = forwardRef<ThreeChartHandle, Props>(function TimelineNeu(
  { items, theme, dark, startText, endText }, ref,
) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => { const t = setTimeout(() => setReady(true), 520); return () => clearTimeout(t); }, [items]);

  // Palette — light uses the reference clay tones; dark adapts them.
  const bg = dark ? '#232a33' : '#e6edf5';
  const ink = dark ? '#e8eef6' : '#334155';
  const muted = dark ? '#93a2b5' : '#64748b';
  const beadFill = dark ? '#2b333d' : '#ffffff';
  const beadStroke = dark ? '#5a6a7c' : '#94a3b8';
  const trench = dark ? '#2a323c' : '#cbd5e1';
  const dash = dark ? '#5a6a7c' : '#94a3b8';

  const list = (items && items.length ? items : Array.from({ length: 9 }, (_, i) => ({ n: i + 1, label: 'Enter Detailed Content' })))
    .slice(0, 9)
    .map((it, i) => ({ ...it, ...SLOTS[i] }));

  const desc = 'You can complete your presentation with infographic slides on various topics and designs.';
  const leftDesc = startText || desc;
  const rightDesc = endText || desc;

  const scene = (
    <>
      <defs>
        {/* vibrant gradient tube track */}
        <linearGradient id="tlSerp" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1d4ed8" />
          <stop offset="25%" stopColor="#0284c7" />
          <stop offset="50%" stopColor="#06b6d4" />
          <stop offset="75%" stopColor="#10b981" />
          <stop offset="100%" stopColor="#059669" />
        </linearGradient>
        {/* dual extruded drop shadow for pills */}
        <filter id="tlPill" x="-40%" y="-40%" width="180%" height="180%">
          <feDropShadow dx="5" dy="6" stdDeviation="5" floodColor={dark ? '#12171f' : '#a8b8cc'} floodOpacity={dark ? 0.7 : 0.8} />
          <feDropShadow dx="-5" dy="-5" stdDeviation="5" floodColor={dark ? '#3d4854' : '#ffffff'} floodOpacity={dark ? 0.35 : 1} />
        </filter>
        {/* large badge extruded ring shadow */}
        <filter id="tlBadge" x="-40%" y="-40%" width="180%" height="180%">
          <feDropShadow dx="10" dy="12" stdDeviation="12" floodColor={dark ? '#10151c' : '#9eb0c6'} floodOpacity={dark ? 0.75 : 0.75} />
          <feDropShadow dx="-10" dy="-10" stdDeviation="12" floodColor={dark ? '#414d5b' : '#ffffff'} floodOpacity={dark ? 0.4 : 0.95} />
        </filter>
        {/* recessed concentric groove */}
        <filter id="tlGroove" x="-30%" y="-30%" width="160%" height="160%">
          <feDropShadow dx="4" dy="4" stdDeviation="4" floodColor={dark ? '#12171f' : '#a0b1c7'} floodOpacity="0.6" />
          <feDropShadow dx="-4" dy="-4" stdDeviation="4" floodColor={dark ? '#414d5b' : '#ffffff'} floodOpacity="0.9" />
        </filter>
        {/* serpentine trench drop */}
        <filter id="tlPath" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="8" stdDeviation="8" floodColor="#64748b" floodOpacity="0.25" />
        </filter>
        <linearGradient id="tlSurf" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={dark ? '#3b4552' : '#ffffff'} />
          <stop offset="100%" stopColor={dark ? '#2a323c' : '#e2e8f0'} />
        </linearGradient>
        <linearGradient id="tlBezel" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={dark ? '#39424e' : '#f1f5f9'} />
          <stop offset="100%" stopColor={dark ? '#232a33' : '#cbd5e1'} />
        </linearGradient>
      </defs>

      {/* carved header */}
      <text x={600} y={70} textAnchor="middle" fontSize={36} fontWeight={800} fill={ink}
        fontFamily={theme.fontDisplay} letterSpacing={-0.5}>Timeline</text>

      {/* left / right recessed paragraph slots */}
      <g transform="translate(60, 196)">
        <rect width={182} height={128} rx={16} fill={bg} filter="url(#tlGroove)" />
        <rect x={2} y={2} width={178} height={124} rx={14} fill="none"
          stroke={dark ? 'rgba(0,0,0,0.25)' : 'rgba(181,195,213,0.9)'} strokeWidth={1} />
        <foreignObject x={12} y={12} width={158} height={104}>
          <div style={{ fontFamily: theme.fontBody, fontSize: 12, lineHeight: 1.5, color: muted, fontWeight: 500 }}>{leftDesc}</div>
        </foreignObject>
      </g>
      <g transform="translate(958, 458)">
        <rect width={182} height={128} rx={16} fill={bg} filter="url(#tlGroove)" />
        <rect x={2} y={2} width={178} height={124} rx={14} fill="none"
          stroke={dark ? 'rgba(0,0,0,0.25)' : 'rgba(181,195,213,0.9)'} strokeWidth={1} />
        <foreignObject x={12} y={12} width={158} height={104}>
          <div style={{ fontFamily: theme.fontBody, fontSize: 12, lineHeight: 1.5, color: muted, fontWeight: 500 }}>{rightDesc}</div>
        </foreignObject>
      </g>

      {/* recessed base trench under the track */}
      <path d={TRACK_D} stroke={trench} strokeWidth={22} strokeLinecap="round" strokeLinejoin="round" fill="none" opacity={0.6} />
      {/* vibrant glossy serpentine tube (draws in during load) */}
      <path d={TRACK_D} stroke="url(#tlSerp)" strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" fill="none"
        filter="url(#tlPath)"
        style={{
          strokeDasharray: 2000, strokeDashoffset: ready ? 0 : 2000,
          transition: 'stroke-dashoffset 1.1s cubic-bezier(0.22,1,0.36,1)',
        }} />
      {/* glossy highlight along the tube */}
      <path d={TRACK_D} stroke="rgba(255,255,255,0.35)" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" fill="none"
        transform="translate(0 -3)"
        style={{ strokeDasharray: 2000, strokeDashoffset: ready ? 0 : 2000, transition: 'stroke-dashoffset 1.1s cubic-bezier(0.22,1,0.36,1)' }} />

      {/* indicator beads */}
      {BEADS.map(([bx, by], i) => (
        <circle key={`b${i}`} cx={bx} cy={by} r={5} fill={beadFill} stroke={beadStroke} strokeWidth={1.5}
          style={{ opacity: ready ? 1 : 0, transition: `opacity 0.4s ease ${0.6 + i * 0.02}s` }} />
      ))}

      {/* start badge — concentric neu dial + search $ */}
      <g transform="translate(260, 220)" style={{ opacity: ready ? 1 : 0, transform: ready ? 'translate(260px,220px) scale(1)' : 'translate(260px,220px) scale(0.6)', transition: 'opacity 0.5s ease, transform 0.6s cubic-bezier(0.34,1.56,0.64,1)' }}>
        <circle r={54} fill="url(#tlBezel)" filter="url(#tlBadge)" />
        <circle r={45} fill={bg} filter="url(#tlGroove)" />
        <circle r={36} fill="url(#tlSurf)" filter="url(#tlPill)" />
        <g transform="scale(0.95)">
          <path d="M-8,-8 A12,12 0 1,1 8,8 A12,12 0 1,1 -8,-8 Z" fill="none" stroke="#2563eb" strokeWidth={3} />
          <line x1={8} y1={8} x2={16} y2={16} stroke="#2563eb" strokeWidth={3.5} strokeLinecap="round" />
          <text x={0} y={4.5} textAnchor="middle" fontSize={13} fontWeight={800} fill="#2563eb" fontFamily={theme.fontDisplay}>$</text>
        </g>
      </g>

      {/* end badge — concentric neu dial + hand-coin */}
      <g transform="translate(940, 520)" style={{ opacity: ready ? 1 : 0, transform: ready ? 'translate(940px,520px) scale(1)' : 'translate(940px,520px) scale(0.6)', transition: 'opacity 0.5s ease, transform 0.6s cubic-bezier(0.34,1.56,0.64,1) 0.15s' }}>
        <circle r={54} fill="url(#tlBezel)" filter="url(#tlBadge)" />
        <circle r={45} fill={bg} filter="url(#tlGroove)" />
        <circle r={36} fill="url(#tlSurf)" filter="url(#tlPill)" />
        <g transform="translate(0,-2) scale(0.9)">
          <circle cx={4} cy={-12} r={5} fill="none" stroke="#2563eb" strokeWidth={2.5} />
          <circle cx={4} cy={-12} r={2} fill="#2563eb" />
          <path d="M-16,8 C-16,2 -10,-1 -3,-1 L6,-1 C10,-1 14,2 17,5 L20,8 C21,9 20,11 18,11 L-2,11 C-6,11 -10,13 -13,16 L-16,16 Z" fill="#2563eb" />
        </g>
      </g>

      {/* milestone nodes */}
      {list.map((n, i) => {
        const stem = n.above ? -50 : 50;
        const pillY = n.above ? -84 : 50;
        const numY = n.above ? -62 : 72;
        const labelY = n.above ? 38 : -28;
        return (
          <g key={n.n} transform={`translate(${n.x}, ${n.y})`}
            style={{ opacity: ready ? 1 : 0, transition: `opacity 0.45s ease ${0.5 + i * 0.06}s` }}>
            <line x1={0} y1={0} x2={0} y2={stem} stroke={dash} strokeWidth={2} strokeDasharray="3,3" />
            <circle cx={0} cy={0} r={6} fill={beadFill} stroke={NODE_STROKE[i] || '#2563eb'} strokeWidth={3} />
            <rect x={-32} y={pillY} width={64} height={34} rx={17} fill={bg} filter="url(#tlPill)" />
            <text x={0} y={numY} textAnchor="middle" fontSize={14} fontWeight={800} fill={ink} fontFamily={theme.fontDisplay}>{String(n.n).padStart(2, '0')}</text>
            <text x={0} y={labelY} textAnchor="middle" fontSize={12} fontWeight={600} fill={muted} fontFamily={theme.fontBody}>{n.label}</text>
          </g>
        );
      })}
    </>
  );

  const buildSVG = (title: string) => {
    const inner = svgRef.current?.innerHTML || '';
    const head = title ? 40 : 0;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${VW}" height="${VH + head}" viewBox="0 0 ${VW} ${VH + head}"><rect width="${VW}" height="${VH + head}" fill="${bg}"/>${title ? `<text x="24" y="28" font-family="${theme.fontDisplay}, sans-serif" font-weight="800" font-size="17" fill="${ink}">${title.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</text>` : ''}<g transform="translate(0 ${head})">${inner}</g></svg>`;
  };

  useImperativeHandle(ref, () => ({
    exportSVG: async (title: string) => `<?xml version="1.0" encoding="utf-8"?>\n${buildSVG(title)}`,
    exportPNG: async (title: string) => {
      const head = title ? 40 : 0;
      const raw = buildSVG(title);
      const blob = new Blob([raw], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      try {
        const img = await new Promise<HTMLImageElement>((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = url; });
        const scale = 2;
        const cv = document.createElement('canvas');
        cv.width = VW * scale; cv.height = (VH + head) * scale;
        const ctx = cv.getContext('2d')!;
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, cv.width, cv.height);
        ctx.drawImage(img, 0, 0, cv.width, cv.height);
        return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
      } finally { URL.revokeObjectURL(url); }
    },
    setZoom: () => { /* timeline has no zoom */ },
  }), [dark, theme]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="absolute inset-0 h-full w-full overflow-hidden" style={{ background: 'transparent' }}>
      {/* neumorphic build-in loading animation */}
      {!ready && (
        <div className="absolute inset-0 z-20 flex items-center justify-center gap-2.5 font-body text-[12.5px] font-semibold" style={{ color: muted }}>
          <span className="h-5 w-5 animate-spin rounded-full border-2 border-current border-t-transparent opacity-70" />
          Building timeline…
        </div>
      )}
      <svg ref={svgRef} width="100%" height="100%" viewBox={`0 0 ${VW} ${VH}`} preserveAspectRatio="xMidYMid meet" style={{ display: 'block' }}>
        {scene}
      </svg>
    </div>
  );
});

export default TimelineNeu;
