import { useEffect } from "react";
// @ts-ignore – plain JS scene module (three.js r12x UMD + original renderer)
import { startScene } from "./scene.js";

export default function App() {
  useEffect(() => {
    startScene();
  }, []);

  return (
    <>
      <canvas id="view"></canvas>
      <div id="ui" role="group" aria-label="Scene controls">
        <div className="row">
          <span>Render quality</span>
          <b id="qv">65</b>
        </div>
        <input id="q" type="range" min="1" max="100" defaultValue="65" aria-label="Render quality" />

        <div className="row">
          <span>Pace</span>
          <b>
            <span id="gait">Walk</span> · <span id="spdv">1.0×</span>
          </b>
        </div>
        <input id="spd" type="range" min="0" max="100" defaultValue="25" aria-label="Walking speed" />
        <div className="ticks">
          <span>stroll</span>
          <span>walk</span>
          <span>jog</span>
          <span>run</span>
          <span>sprint</span>
        </div>

        <div id="info"></div>
        <div id="hint">Press H to hide this panel</div>
      </div>
    </>
  );
}
