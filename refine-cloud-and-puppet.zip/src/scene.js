import './vendor/three.js';
import { HAND_B64 } from './vendor/handData.js';
const THREE=globalThis.THREE;
let started=false;
export function startScene(){if(started)return;started=true;
(()=>{
"use strict";
/* ---------- constants & helpers ---------- */
const DW=1920,DH=1080,U=100,WW=19.2,WH=10.8;
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v)),lerp=(a,b,t)=>a+(b-a)*t;
const sm=t=>{t=clamp(t,0,1);return t*t*(3-2*t)};
const rng=s=>()=>((s=(s*1664525+1013904223)>>>0)/4294967296);
const CIRC={x:14.75,R:16.9};CIRC.y=2.62-CIRC.R;                 // globe centre (world, y up)
const GX=13.35;                                                   // puppet x
const GY=CIRC.y+Math.sqrt(CIRC.R*CIRC.R-(GX-CIRC.x)**2);          // ground height under puppet
const WALK={T:1.12,S:1.18,beta:.62,v:1.05,run:0,lift:.085};
const TIME={t:0,ph:0,rot:0};
const SC=1.3;                                                     // realistic 7.5-head figure scaled to the original puppet's screen height
const blinkAmt=t=>{const c=(t+1.7)%4.3,d=(t+.4)%11;return Math.max(c<.16?Math.sin(c/.16*Math.PI):0,d<.16?Math.sin(d/.16*Math.PI):0)};                 // world units / s (employee gait from the zip)
const PITCH=0.2,DIR=-1;                                           // DIR=-1: puppet is mirrored and walks left

const canvas=document.getElementById('view');
const renderer=new THREE.WebGLRenderer({canvas,antialias:false,powerPreference:'high-performance'});
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
const isGL2=renderer.capabilities.isWebGL2;

/* ---------- cameras (right-anchored so the composition always holds) ---------- */
let camL=0,camR=WW;
const bgCam=new THREE.OrthographicCamera(0,WW,WH,0,-10,10);
const fgCam=new THREE.OrthographicCamera(0,WW,WH-GY,-GY,.1,100);
const D=30;fgCam.position.set(0,GY+D*Math.sin(PITCH),D*Math.cos(PITCH));fgCam.lookAt(0,GY,0);

/* ======================= BACKGROUND SCENE ======================= */
const bgScene=new THREE.Scene();
const mk=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};
function addPlane(scene,w,h,mat,x,y,order){const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),mat);m.position.set(x,y,0);m.renderOrder=order;scene.add(m);return m}
const flat=p=>Object.assign(p,{depthTest:false,depthWrite:false});

/* clouds: engraved cauliflower cumulus traced from the reference.
   Each cloud = hand-placed primary domes (design px) on a flat base -> scalloped with two generations of outline bumps
   + interior sub-domes -> rendered as a union of spheres (heightfield) lit from the upper-left.
   Output: R = light (1 lit / 0 shade), A = coverage. The post pass turns light into solid peach and shade into diamond cross-hatching. */
const CLOUD_DEFS=[
  /* A · small cloud left of the hill: tall dome left of centre, shoulder left, lower lobes stepping down to the right */
  {base:888,seed:3,lobes:[[905,866,20],[930,846,30],[962,820,40],[996,792,46],[1030,774,33],[1027,758,17],[1050,786,36],[1080,812,38],[1110,838,32],[1135,862,22],[985,840,44],[1060,846,40],[970,786,24],[1012,760,22]]},
  /* B · cloud tucked under the forearm */
  {base:392,seed:7,lobes:[[1578,372,20],[1600,346,30],[1628,318,32],[1612,296,18],[1660,302,30],[1690,316,30],[1716,340,28],[1742,364,22],[1650,352,38],[1700,360,30]]},
  /* C · mid cloud: low left shoulder, high bumpy crown left of centre, terraces down to the right */
  {base:558,seed:11,lobes:[[1528,538,18],[1550,516,26],[1578,490,32],[1602,462,26],[1594,444,14],[1628,456,26],[1656,476,28],[1684,496,26],[1708,516,22],[1726,538,16],[1600,520,36],[1660,528,34]]},
  /* D · big stacked cumulus on the right edge: tower behind the arm, cascading lobes down-left, massive lower body */
  {base:862,seed:19,lobes:[[1840,412,34],[1810,436,30],[1872,446,44],[1906,486,52],[1786,478,36],[1846,500,52],[1760,520,34],[1918,566,66],[1730,566,38],[1790,566,50],[1690,606,34],[1662,634,28],[1740,620,52],[1860,620,74],[1640,666,26],[1612,694,24],[1676,676,40],[1760,690,62],[1906,690,70],[1624,734,34],[1680,744,48],[1780,770,70],[1880,780,72],[1640,800,40],[1720,816,52],[1940,820,60]]},
  /* E · top-right cloud peeking above the forearm */
  {base:118,seed:23,lobes:[[1712,96,18],[1738,76,26],[1770,54,30],[1806,36,32],[1846,24,36],[1890,30,40],[1930,52,40],[1790,86,30],[1860,80,40]]}
];
function cloudCanvas(def){
  const r=rng(def.seed*7919+13),P=24;
  const L=def.lobes.map(l=>({x:l[0],y:l[1]+l[2]*.1,r:l[2]*.86,z:0,g:0}));   // scallops grow the outline ~14%: shrink domes so the silhouette lands on the traced edge
  let x0=1e9,x1=-1e9,y0=1e9;L.forEach(l=>{x0=Math.min(x0,l.x-l.r);x1=Math.max(x1,l.x+l.r);y0=Math.min(y0,l.y-l.r)});
  const inside=(px,py,skip,m)=>L.some(o=>o!==skip&&o.g===0&&Math.hypot(px-o.x,py-o.y)<o.r-m);
  const spheres=L.slice();
  /* generation 1 + 2 scallops along the exposed upper outline */
  const scallop=(src,kMin,kMax,gen,rMin)=>{const out=[];
    src.forEach(p=>{let a=Math.PI*.9;while(a<Math.PI*2.1){const br=Math.max(rMin,p.r*(kMin+r()*(kMax-kMin)));
      const bx=p.x+Math.cos(a)*p.r*.9,by=p.y+Math.sin(a)*p.r*.9;
      if(by<def.base-br*.6&&!inside(bx,by,p,br*.35))
        out.push({x:bx,y:by,r:br,z:0,g:gen,parent:p});
      a+=(br*1.55)/p.r*(.85+r()*.35)}});return out};
  const g1=scallop(L,.2,.3,1,6);spheres.push(...g1);
  const g2=scallop(g1.filter(()=>r()<.85),.34,.46,2,3.2).filter(b=>!g1.some(q=>q!==b.parent&&Math.hypot(b.x-q.x,b.y-q.y)<q.r*.8));spheres.push(...g2);
  x0-=P;x1+=P;y0-=P;const W=Math.ceil(x1-x0),H=Math.ceil(def.base+P-y0),c=mk(W,H),ctx=c.getContext('2d');
  const Hb=new Float32Array(W*H).fill(-1e9),Nx=new Float32Array(W*H),Ny=new Float32Array(W*H),Nz=new Float32Array(W*H),Al=new Float32Array(W*H);
  const stamp=s=>{const cx=s.x-x0,cy=s.y-y0,R=s.r;
    for(let y=Math.max(0,Math.floor(cy-R-1));y<=Math.min(H-1,Math.ceil(cy+R+1));y++)for(let x=Math.max(0,Math.floor(cx-R-1));x<=Math.min(W-1,Math.ceil(cx+R+1));x++){
      const dx=x+.5-cx,dy=y+.5-cy,d2=dx*dx+dy*dy,d=Math.sqrt(d2),i=y*W+x;const a=clamp(R-d+.5,0,1);if(a<=0)continue;if(a>Al[i])Al[i]=a;
      const hz=Math.sqrt(Math.max(0,R*R-d2)),h=s.z+hz;if(h>Hb[i]){Hb[i]=h;Nx[i]=dx/R;Ny[i]=dy/R;Nz[i]=hz/R}}};
  spheres.forEach(stamp);
  /* interior sub-domes: small cauliflower heads pushing slightly out of the surface */
  const heightAt=(px,py)=>{const x=Math.round(px-x0),y=Math.round(py-y0);return x>=0&&y>=0&&x<W&&y<H?Hb[y*W+x]:-1e9};
  const inner=[];L.forEach(l=>{const n=Math.round(l.r/7);for(let k=0;k<n;k++){const a=Math.PI*(1.05+r()*.9),rr=l.r*(.25+r()*.55),bx=l.x+Math.cos(a)*rr,by=l.y+Math.sin(a)*rr*.9,br=l.r*(.2+r()*.16);
    const hp=heightAt(bx,by);if(hp>0&&by<def.base-br*1.4)inner.push({x:bx,y:by,r:br,z:hp-br*.8,g:3})}});
  inner.forEach(stamp);
  const img=ctx.createImageData(W,H),D=img.data,lx=-.48,ly=-.72,lz=.5,ll=Math.hypot(lx,ly,lz),cloudH=def.base-y0-P;
  for(let y=0;y<H;y++){const dy=y+y0,baseShade=1-.6*sm((dy-(def.base-cloudH*.42))/(cloudH*.42)),cut=1-sm((dy-(def.base-16))/18);
    for(let x=0;x<W;x++){const i=y*W+x;if(Al[i]<=0)continue;
      let l=(Nx[i]*lx+Ny[i]*ly+Nz[i]*lz)/ll;l=clamp(l*.95+.1,0,1)*baseShade;
      const rim=1-sm((Nz[i]-.05)/.4);l*=1-.45*rim;                      // terminator band at every bump edge
      const o=i*4;D[o]=D[o+1]=D[o+2]=Math.round(clamp(l,0,1)*255);D[o+3]=Math.round(Al[i]*clamp(cut+(r()-.5)*.25*(1-cut)*cut*4,0,1)*255)}}
  ctx.putImageData(img,0,0);
  return {c,cx:x0+W/2,cy:y0+H/2};
}
const clouds=CLOUD_DEFS.map((def,i)=>{
  const {c,cx,cy}=cloudCanvas(def),t=new THREE.CanvasTexture(c);t.minFilter=THREE.LinearFilter;t.magFilter=THREE.LinearFilter;t.generateMipmaps=false;
  const m=addPlane(bgScene,c.width/U,c.height/U,flat(new THREE.MeshBasicMaterial({map:t,transparent:true,premultipliedAlpha:false})),cx/U,WH-cy/U,1);
  m.userData={y0:m.position.y,ph:i*1.9};return m});

/* globe: polar-mapped ground strip */
function stripTexture(){
  const W=4096,H=512,c=mk(W,H),x=c.getContext('2d'),r=rng(7);
  const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#5c5230');g.addColorStop(.3,'#3a331c');g.addColorStop(.6,'#211d10');g.addColorStop(1,'#0e0d07');
  x.fillStyle=g;x.fillRect(0,0,W,H);
  const wrap=f=>{f(0);f(W);f(-W)};
  for(let i=0;i<120;i++){const px=r()*W,py=8+r()*H*.5,s=5+r()*11;       // stones
    wrap(o=>{x.fillStyle='rgba(30,27,12,.45)';x.beginPath();x.ellipse(px+o+s*.2,py+s*.3,s*1.1,s*.55,0,0,7);x.fill();
      x.fillStyle='#5f5836';x.beginPath();x.ellipse(px+o,py,s,s*.55,0,0,7);x.fill();
      x.fillStyle='#7a7244';x.beginPath();x.ellipse(px+o-s*.2,py-s*.15,s*.55,s*.28,0,0,7);x.fill()})}
  for(let i=0;i<46;i++){const px=r()*W,py=14+r()*H*.45,s=12+r()*16;       // shrubs
    wrap(o=>{for(let k=0;k<5;k++){const ox=(k-2)*s*.5,oy=-Math.abs(k-2)*s*.15;
      x.fillStyle=k%2?'#4a4a21':'#3c3d19';x.beginPath();x.arc(px+o+ox,py+oy,s*.62,0,7);x.fill();
      x.fillStyle='rgba(138,140,70,.55)';x.beginPath();x.arc(px+o+ox-s*.18,py+oy-s*.2,s*.26,0,7);x.fill()}})}
  const t=new THREE.CanvasTexture(c);t.wrapS=THREE.RepeatWrapping;t.wrapT=THREE.ClampToEdgeWrapping;t.minFilter=THREE.LinearFilter;t.generateMipmaps=false;return t;
}
const globeMat=flat(new THREE.ShaderMaterial({transparent:true,
  uniforms:{uC:{value:new THREE.Vector3(CIRC.x,CIRC.y,CIRC.R)},uRot:{value:0},uPx:{value:.01},uStrip:{value:stripTexture()}},
  vertexShader:'varying vec2 vW;void main(){vW=(modelMatrix*vec4(position,1.)).xy;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:`uniform vec3 uC;uniform float uRot,uPx;uniform sampler2D uStrip;varying vec2 vW;
  void main(){vec2 p=vW-uC.xy;float r=length(p),e=uC.z-r;if(e<-uPx*2.)discard;
   float a=atan(p.y,p.x);vec3 c=texture2D(uStrip,vec2((a-uRot)/6.2831853*3.,1.-clamp(e/4.2,0.,1.))).rgb;
   vec2 n=p/max(r,1e-4);float l=dot(n,normalize(vec2(-.5,.85)));c*=.72+.46*l;
   c+=vec3(.2,.17,.08)*(1.-smoothstep(0.,.2,e))*.85;
   gl_FragColor=vec4(c,smoothstep(-uPx,uPx,e));}`}));
addPlane(bgScene,40,16,globeMat,WW/2,WH/2-2,2);

/* blob shadows (they live in the background pass so they pick up the print texture) */
const shTex=(()=>{const c=mk(128,128),x=c.getContext('2d'),g=x.createRadialGradient(64,64,0,64,64,64);
  g.addColorStop(0,'rgba(14,12,4,.9)');g.addColorStop(.55,'rgba(14,12,4,.55)');g.addColorStop(1,'rgba(14,12,4,0)');x.fillStyle=g;x.fillRect(0,0,128,128);return new THREE.CanvasTexture(c)})();
const shadows=[0,1,2].map(()=>addPlane(bgScene,1,1,flat(new THREE.MeshBasicMaterial({map:shTex,transparent:true,opacity:.62})),0,0,3));

/* ======================= FOREGROUND SCENE : PUPPET ======================= */
const fgScene=new THREE.Scene();fgScene.add(fgCam);
/* ---- employee (ported from the zip's Puppet): rounded-box human, formal suit, tie, ID badge and leather office bag ---- */
const TAU=Math.PI*2,minJerk=u=>{u=clamp(u,0,1);return u*u*u*(10-15*u+6*u*u)};
const LEG={t:.58,s:.56,ankle:.1};

/* rounded box (non-indexed, smooth normals on the bevels) */
function rbox(w,h,d,seg,rad){
  seg=seg*2+1;rad=Math.min(w/2,h/2,d/2,rad);
  const g=new THREE.BoxGeometry(1,1,1,seg,seg,seg).toNonIndexed(),P=g.attributes.position,N=g.attributes.normal,hs=.5/seg,v=new THREE.Vector3();
  const bx=w/2-rad,by=h/2-rad,bz=d/2-rad;
  for(let i=0;i<P.count;i++){
    const px=P.getX(i),py=P.getY(i),pz=P.getZ(i);
    v.set(px-Math.sign(px)*hs,py-Math.sign(py)*hs,pz-Math.sign(pz)*hs).normalize();
    P.setXYZ(i,bx*Math.sign(px)+v.x*rad,by*Math.sign(py)+v.y*rad,bz*Math.sign(pz)+v.z*rad);
    N.setXYZ(i,v.x,v.y,v.z)}
  return g}
/* box-projected UVs so texel density is identical on every face */
function boxUV(g,sc){
  const p=g.attributes.position,n=g.attributes.normal,uv=g.attributes.uv;
  for(let i=0;i<p.count;i++){const ax=Math.abs(n.getX(i)),ay=Math.abs(n.getY(i)),az=Math.abs(n.getZ(i));let u,v;
    if(ax>=ay&&ax>=az){u=p.getZ(i);v=p.getY(i)}else if(ay>=az){u=p.getX(i);v=p.getZ(i)}else{u=p.getX(i);v=p.getY(i)}
    uv.setXY(i,u*sc+.37,v*sc+.61)}
  uv.needsUpdate=true}

/* embossed letterform map (colour + bump) and woven cloth map */
function glyphMaps(size,seed){
  const c=mk(size,size),x=c.getContext('2d'),r=rng(seed);
  x.fillStyle='#000';x.fillRect(0,0,size,size);
  const chars='ABRHWGOQNZKEDUMSabdeghkmnqrsuw&§@%?';
  x.strokeStyle='#fff';x.lineCap='round';x.lineJoin='round';
  const N=Math.round(size*size/1500);
  for(let i=0;i<N;i++){
    const kk=size/1024,px=r()*size,py=r()*size,s=(24+r()*34)*kk,a=r()*Math.PI*2,ch=chars[Math.floor(r()*chars.length)],lw=(1.6+r()*2.4)*Math.max(.7,kk),kind=r();
    const draw=(ox,oy)=>{x.save();x.translate(px+ox,py+oy);x.rotate(a);x.lineWidth=lw;x.globalAlpha=.55+r()*.45;
      if(kind<.62){x.font=(r()<.5?'italic ':'')+'700 '+s+'px "Times New Roman",Georgia,serif';x.textAlign='center';x.textBaseline='middle';x.strokeText(ch,0,0)}
      else if(kind<.84){x.beginPath();let qx=-s*.5,qy=0;x.moveTo(qx,qy);
        for(let k=0;k<4;k++){const nx=qx+s*.3,ny=(k%2?1:-1)*s*(.2+r()*.2);x.quadraticCurveTo(qx+s*.15,ny*1.4,nx,ny*.2);qx=nx;qy=ny}x.stroke()}
      else{x.beginPath();for(let k=0;k<26;k++){const th=k*.42,rr=s*.04*k*.55,X=Math.cos(th)*rr,Y=Math.sin(th)*rr;k?x.lineTo(X,Y):x.moveTo(X,Y)}x.stroke()}
      x.restore()};
    for(const ox of[-size,0,size])for(const oy of[-size,0,size])if(px+ox>-80&&px+ox<size+80&&py+oy>-80&&py+oy<size+80)draw(ox,oy)}
  const b=mk(size,size),bx=b.getContext('2d');
  try{bx.filter='blur(1.1px)'}catch(e){}bx.drawImage(c,0,0);try{bx.filter='none'}catch(e){}
  const H=bx.getImageData(0,0,size,size).data,col=new Uint8Array(size*size*4),bump=new Uint8Array(size*size*4);
  const h=(X,Y)=>H[(((Y+size)%size)*size+((X+size)%size))*4]/255;
  for(let y=0;y<size;y++)for(let X=0;X<size;X++){
    const e=(h(X-1,y-1)-h(X+1,y+1))*1.6,R=Math.max(0,-e),G=Math.max(0,e),B=h(X,y),i=(y*size+X)*4,v=Math.min(1,Math.max(0,.84-R*.62+G*.3-B*.06));
    col[i]=col[i+1]=col[i+2]=v*255;col[i+3]=255;bump[i]=bump[i+1]=bump[i+2]=B*255;bump[i+3]=255}
  const mkT=d=>{const t=new THREE.DataTexture(d,size,size,THREE.RGBAFormat);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.minFilter=THREE.LinearMipmapLinearFilter;t.magFilter=THREE.LinearFilter;t.generateMipmaps=true;t.anisotropy=4;t.needsUpdate=true;return t};
  return {col:mkT(col),bump:mkT(bump)}}
function clothMap(size,seed){
  const r=rng(seed),d=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const tw=((x+y)%4<2?1:0)*.08+((x-y+400)%6<1?-.06:0),v=.86+tw+(r()-.5)*.1,i=(y*size+x)*4;
    d[i]=d[i+1]=d[i+2]=Math.max(0,Math.min(255,v*255));d[i+3]=255}
  const t=new THREE.DataTexture(d,size,size,THREE.RGBAFormat);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.minFilter=THREE.LinearMipmapLinearFilter;t.magFilter=THREE.LinearFilter;t.generateMipmaps=true;t.needsUpdate=true;return t}

const GM=glyphMaps(512,3),CL=clothMap(256,9);
const PM=(c,o={})=>{const m=new THREE.MeshStandardMaterial({color:c,roughness:o.r===undefined?.8:o.r,metalness:o.m||0,transparent:true});
  if(o.map)m.map=o.map;if(o.bump){m.bumpMap=o.bump;m.bumpScale=o.bs||1}return m};
const MT={
  suit:PM(0x1a2340,{map:CL,r:.82}),suitD:PM(0x0e152b,{map:CL,r:.82}),
  skin:PM(0xe65f22,{r:.7}),skinD:PM(0xbd461a,{r:.7}),blush:PM(0xee7a42,{r:.7}),
  hair:PM(0x2a160c,{map:CL,r:.55}),shirt:PM(0xfff4de,{map:CL,r:.85}),tie:PM(0xdc2a26,{map:CL,r:.5}),tieS:PM(0x14213d,{r:.5}),
  pants:PM(0x1a2340,{map:CL,r:.88}),pantsD:PM(0x0e152b,{map:CL,r:.88}),
  shoe:PM(0x5e2a10,{r:.38,map:GM.col}),sole:PM(0x24170f,{r:.7}),dark:PM(0x17110e,{r:.5}),eyeW:PM(0xfbf3e3,{r:.4}),
  leather:PM(0x6b3414,{map:GM.col,bump:GM.bump,bs:.12,r:.45}),gold:PM(0xf0dca0,{r:.3,m:.1}),
  badge:PM(0xf8f2e2,{r:.6}),badgeB:PM(0x2f6fb5,{r:.6}),lanyard:PM(0x2f6fb5,{r:.6})};

const root=new THREE.Group();root.position.set(GX,GY,0);root.rotation.y=Math.PI*1.25;root.scale.setScalar(SC);fgScene.add(root);   // built facing +x, turned to walk left and 45° toward the viewer
function box(w,h,d,mat,x=0,y=0,z=0,par=root,rad=.03){
  const r=Math.min(rad,w/2.2,h/2.2,d/2.2),g=rbox(w,h,d,2,r);boxUV(g,1/2.3);
  const m=new THREE.Mesh(g,mat);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;par.add(m);return m}
const grp=(par,x=0,y=0,z=0)=>{const g=new THREE.Group();g.position.set(x,y,z);par.add(g);return g};
const anc={};const mkAnchor=(n,par,x,y,z)=>{const o=new THREE.Object3D();o.position.set(x,y,z);par.add(o);anc[n]=o};

/* ======== realistic human (7.5 heads tall, ~2.4 units), lathe-turned anatomy under a tailored suit ========
   Same rig interface as before: legs{hip,th,kn,an,toe} · upper · head · arms{sh,ab,el,hand} · caseG · anchors */
const TAPER=(len,keys,n=18)=>{ // keys: [u(0 top..1 bottom), radius]; returns lathe points bottom->top with rounded caps
  const r=u=>{let i=0;while(i<keys.length-2&&u>keys[i+1][0])i++;const a=keys[i],b=keys[i+1],k=sm((u-a[0])/(b[0]-a[0]));return lerp(a[1],b[1],k)};
  const pts=[],r1=r(1),r0=r(0);
  pts.push([1e-4,-len-r1*.55]);for(let k=1;k<=4;k++){const a=k/4*Math.PI/2;pts.push([r1*Math.sin(a),-len-r1*.55*Math.cos(a)])}
  for(let k=n-1;k>=1;k--){const u=k/n;pts.push([r(u),-u*len])}
  for(let k=4;k>=1;k--){const a=k/4*Math.PI/2;pts.push([r0*Math.sin(a),r0*.55*Math.cos(a)])}pts.push([1e-4,r0*.55]);
  return pts};
function lathe(pts,mat,par,x=0,y=0,z=0,sx=1,sz=1,seg=30){
  const g=new THREE.LatheGeometry(pts.map(p=>new THREE.Vector2(p[0],p[1])),seg);g.computeVertexNormals();
  const m=new THREE.Mesh(g,mat);m.position.set(x,y,z);m.scale.set(sx,1,sz);m.castShadow=m.receiveShadow=true;par.add(m);return m}
const SPH=new THREE.SphereGeometry(1,32,24);
function ell(rx,ry,rz,mat,par,x=0,y=0,z=0){const m=new THREE.Mesh(SPH,mat);m.scale.set(rx,ry,rz);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;par.add(m);return m}
function flatShape(pts,mat,par,x,y,z,ry=Math.PI/2){const s=new THREE.Shape();pts.forEach((p,i)=>i?s.lineTo(p[0],p[1]):s.moveTo(p[0],p[1]));
  const g=new THREE.ExtrudeGeometry(s,{depth:.006,bevelEnabled:true,bevelThickness:.003,bevelSize:.003,bevelSegments:2});const m=new THREE.Mesh(g,mat);
  m.position.set(x,y,z);m.rotation.y=ry;m.castShadow=true;par.add(m);return m}

/* legs: trousers over thigh/calf volumes, oxford shoes */
const legsG=grp(root),pelvis=grp(legsG);
lathe([[1e-4,-.2],[.12,-.19],[.175,-.13],[.198,-.03],[.196,.06],[.186,.13],[1e-4,.135]],MT.pants,pelvis,0,.06,0,.7,1);   // seat / hips
const belt=new THREE.Mesh(new THREE.TorusGeometry(.187,.022,8,40),MT.dark);belt.rotation.x=Math.PI/2;belt.scale.set(.71,1,1);belt.position.y=.19;pelvis.add(belt);
box(.012,.04,.05,MT.gold,.135,.19,0,pelvis,.006);                                                             // buckle
const legs=[-1,1].map(s=>{
  const hip=grp(legsG,0,0,s*.102),th=grp(hip);
  lathe(TAPER(LEG.t,[[0,.112],[.18,.116],[.55,.1],[1,.08]]),MT.pants,th,0,0,0,1.06,1);                         // thigh (quads give front depth)
  const kn=grp(th,0,-LEG.t);
  ell(.082,.085,.08,MT.pants,kn);                                                                               // knee
  lathe(TAPER(LEG.s-.07,[[0,.08],[.3,.085],[.75,.074],[1,.078]]),MT.pants,kn,0,0,0,1,1);                       // shin + calf, trouser break
  ell(.083,.03,.08,MT.pantsD,kn,.004,-LEG.s+.075,0);                                                            // hem fold
  const an=grp(kn,0,-LEG.s);
  lathe(TAPER(.06,[[0,.042],[1,.045]]),MT.dark,an,0,.06,0);                                                      // sock
  ell(.075,.058,.056,MT.shoe,an,-.005,-.045,0);                                                                 // heel counter
  ell(.115,.052,.058,MT.shoe,an,.085,-.055,0);                                                                  // vamp / instep
  box(.24,.022,.11,MT.sole,.06,-.1,0,an,.01);                                                                   // sole
  box(.07,.04,.1,MT.sole,-.02,-.083,0,an,.01);                                                                  // heel block
  const toe=grp(an,.185,-.1,0);
  ell(.08,.045,.056,MT.shoe,toe,.035,.04,0);                                                                    // toe cap
  box(.12,.02,.108,MT.sole,.04,.006,0,toe,.008);
  for(let k=0;k<3;k++)box(.006,.005,.05,MT.dark,.04+k*.022,.0,0,an,.002).position.y=-.006-k*.004;             // laces
  mkAnchor(s<0?'kneeN':'kneeF',kn,.09,.02,0);
  return {hip,th,kn,an,toe,s}});

/* torso: tailored jacket (lathe, elliptical section), shirt, tie, lapels */
const upper=grp(root);
lathe([[1e-4,-.36],[.19,-.35],[.205,-.24],[.19,-.08],[.182,.02],[.198,.18],[.222,.34],[.234,.46],[.226,.54],[.19,.6],[.11,.645],[.075,.66],[1e-4,.665]],MT.suit,upper,0,0,0,.62,1,40);
[-1,1].forEach(s=>{ell(.075,.06,.09,MT.suit,upper,0,.555,s*.19);                                             // shoulder line
  flatShape([[.048,.02],[.072,.02],[.075,-.05],[.1,-.07],[.085,-.13],[.004,-.3],[0,-.26]],MT.suitD,upper,.136,.6,0).scale.x=-s;   // notched lapels
  box(.03,.016,.05,MT.suitD,.11,.12,s*.11,upper,.006)});                                                      // pocket flaps
flatShape([[-.055,0],[.055,0],[0,-.27]],MT.shirt,upper,.132,.62,0);                                          // shirt V
flatShape([[-.016,0],[.016,0],[.026,-.2],[0,-.24],[-.026,-.2]],MT.tie,upper,.142,.565,0);                   // tie blade
for(let k=0;k<3;k++)flatShape([[-.022,-.02],[.022,.0],[.022,.008],[-.022,-.012]],MT.tieS,upper,.148,.47-k*.06,0);
ell(.02,.022,.022,MT.tie,upper,.143,.585,0);                                                                 // knot
[-1,1].forEach(s=>ell(.025,.035,.03,MT.shirt,upper,.13,.62,s*.035).rotation.x=s*.5);                        // collar points
[.3,.18].forEach(y=>ell(.008,.01,.01,MT.dark,upper,.123,y,-.02));                                            // buttons
const badge=grp(upper,.128,.33,-.1);badge.rotation.y=-.35;                                                    // ID badge on the near side
box(.012,.11,.075,MT.badge,0,0,0,badge,.008);box(.014,.026,.075,MT.badgeB,0,.04,0,badge,.004);box(.014,.03,.035,MT.dark,0,-.02,-.012,badge,.003);
box(.008,.22,.012,MT.lanyard,.0,.15,.035,badge,.003).rotation.x=.25;
box(.01,.03,.05,MT.shirt,.126,.42,.12,upper,.004);                                                           // pocket square
lathe(TAPER(.2,[[0,.053],[1,.06]]),MT.skin,upper,.005,.82,0,1.05,1);                                         // neck
const collar=new THREE.Mesh(new THREE.TorusGeometry(.064,.014,8,32),MT.shirt);collar.rotation.x=Math.PI/2;collar.position.set(.006,.665,0);collar.scale.set(1.05,1,1);upper.add(collar);
mkAnchor('shN',upper,0,.6,-.24);mkAnchor('shF',upper,0,.6,.24);

/* head: sculpted from a sphere (cranium, brow, eye sockets, cheekbones, jaw, chin), features added on top */
function headGeo(){const g=new THREE.SphereGeometry(1,72,56),p=g.attributes.position;
  for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i);
    let X=x*.104,Y=y*.142,Z=z*.084;
    const low=sm((-y-.05)/.85),front=sm(x*2);
    Z*=1-.42*low*(1-.25*front);                                    // jaw narrows to the chin
    if(x<0)X*=1-.5*sm(-y/.9);                                       // back of skull tucks into the neck
    X+=.012*sm((-y-.55)/.3)*front;                                   // chin forward
    X-=.012*sm((y-.55)/.4)*front;                                    // forehead slopes back
    const eye=Math.exp(-((y-.12)**2)/.012-((Math.abs(z)-.42)**2)/.03)*front;X-=.011*eye;   // orbital sockets
    const brow=Math.exp(-((y-.27)**2)/.006-((Math.abs(z)-.38)**2)/.06)*front;X+=.004*brow;
    const cheek=Math.exp(-((y+.12)**2)/.02-((Math.abs(z)-.62)**2)/.02)*front;X+=.006*cheek;Z*=1+.05*cheek;
    const temple=Math.exp(-((y-.2)**2)/.04-((x-.1)**2)/.05);Z*=1-.05*temple;
    p.setXYZ(i,X,Y,Z)}
  g.computeVertexNormals();return g}
const head=grp(upper,.012,.84,0);
const skull=new THREE.Mesh(headGeo(),MT.skin);skull.position.set(.0,.15,0);skull.castShadow=skull.receiveShadow=true;head.add(skull);
const face=grp(head,0,.15,0);
/* nose: bridge, tip, alae */
const nb=new THREE.Mesh(new THREE.ConeGeometry(.016,.058,16),MT.skin);nb.position.set(.1,.0,0);nb.rotation.z=-.42;nb.scale.set(1,1,.8);face.add(nb);
ell(.014,.013,.013,MT.skin,face,.112,-.026,0);[-1,1].forEach(s=>ell(.009,.009,.008,MT.skinD,face,.104,-.03,s*.014));
/* eyes with irises and blinking lids; brows */
const lids=[];
[-1,1].forEach(s=>{ell(.013,.012,.014,MT.eyeW,face,.084,.017,s*.036);
  ell(.004,.0075,.0075,MT.dark,face,.096,.016,s*.036);
  const lid=new THREE.Mesh(new THREE.SphereGeometry(.0148,20,10,0,Math.PI*2,0,Math.PI/2),MT.skin);lid.position.set(.084,.017,s*.036);lid.rotation.z=-.5;lid.castShadow=true;face.add(lid);lids.push(lid);
  ell(.007,.0045,.022,MT.hair,face,.1,.038,s*.037).rotation.x=s*.12;                                       // brow
  ell(.012,.03,.02,MT.skinD,face,-.006,.0,s*.086).rotation.z=.15;                                         // ear
  ell(.006,.018,.012,MT.skin,face,-.004,.0,s*.093)});
/* mouth: upper & lower lip, philtrum shadow */
ell(.007,.0055,.02,MT.blush,face,.1,-.056,0);ell(.0075,.0065,.019,MT.blush,face,.097,-.068,0);box(.004,.002,.034,MT.skinD,.103,-.062,0,face,.001);
ell(.012,.012,.018,MT.skin,face,.098,-.098,0);                                                                 // chin pad
/* hair: cap over crown and back, side part, sideburns */
const hairG=new THREE.SphereGeometry(1,48,32,0,Math.PI*2,0,Math.PI*.56);
const hair=new THREE.Mesh(hairG,MT.hair);hair.scale.set(.112,.152,.091);hair.position.set(-.006,.162,0);hair.rotation.z=.38;hair.castShadow=true;head.add(hair);
ell(.06,.028,.07,MT.hair,head,.04,.285,-.01).rotation.z=-.2;                                                  // front swoop
[-1,1].forEach(s=>ell(.012,.03,.006,MT.hair,head,.035,.17,s*.083));
mkAnchor('headN',head,0,.31,-.06);mkAnchor('headF',head,0,.31,.06);

/* arms: sleeves over deltoid / biceps / forearm volumes, shirt cuffs, articulated hands */
const ARM={u:.44,f:.34};
function handMesh(par,s,curl){
  ell(.044,.052,.016,MT.skin,par,0,-.05,0);                                                                   // palm
  ell(.04,.016,.017,MT.skinD,par,0,-.092,0);                                                                  // knuckle ridge
  const fingers=[[.03,.044,.039],[.011,.05,.043],[-.009,.047,.04],[-.027,.038,.032]].map((f,i)=>{
    const g1=grp(par,f[0],-.095,0);g1.rotation.x=s*curl*(1+.08*i);
    lathe(TAPER(f[1],[[0,.0105],[1,.0092]],6),MT.skin,g1,0,0,0,1,.9,12);
    const g2=grp(g1,0,-f[1]);g2.rotation.x=s*curl*1.2;lathe(TAPER(f[2],[[0,.009],[1,.0078]],6),MT.skin,g2,0,0,0,1,.9,12);
    return [g1,g2]});
  const th=grp(par,.04,-.035,s*-.008);th.rotation.set(s*.5,0,.55);
  lathe(TAPER(.04,[[0,.013],[1,.011]],6),MT.skin,th);const th2=grp(th,0,-.04);th2.rotation.x=s*curl*.6;lathe(TAPER(.032,[[0,.0105],[1,.009]],6),MT.skin,th2);
  return fingers}
const arms=[-1,1].map(s=>{
  const sh=grp(upper,0,.535,s*.235),ab=grp(sh);
  ell(.072,.075,.075,MT.suit,ab,0,-.01,0);
  lathe(TAPER(ARM.u,[[0,.068],[.25,.066],[.75,.056],[1,.052]]),MT.suit,ab,0,0,0,1.05,1);
  const el=grp(ab,0,-ARM.u);
  ell(.052,.054,.05,MT.suit,el);
  lathe(TAPER(ARM.f-.02,[[0,.053],[.3,.054],[1,.044]]),MT.suit,el);
  lathe(TAPER(.03,[[0,.043],[1,.043]],4),MT.shirt,el,0,-ARM.f+.035,0);                                        // shirt cuff
  lathe(TAPER(.04,[[0,.03],[1,.032]],4),MT.skin,el,0,-ARM.f+.02,0);                                           // wrist
  const hand=grp(el,0,-ARM.f);
  const fingers=handMesh(hand,s,s<0?1.25:.32);
  mkAnchor(s<0?'wN':'wF',hand,0,.02,0);
  return {sh,ab,el,hand,s,fingers}});
const caseG=grp(arms[0].hand,0,-.13,0);
box(.5,.36,.13,MT.leather,0,-.24,0,caseG,.035);
box(.51,.035,.135,MT.dark,0,-.11,0,caseG,.01);
const handle=new THREE.Mesh(new THREE.TorusGeometry(.06,.011,8,20,Math.PI),MT.dark);handle.position.set(0,-.085,0);caseG.add(handle);
box(.05,.04,.14,MT.gold,-.15,-.15,0,caseG,.01);box(.05,.04,.14,MT.gold,.15,-.15,0,caseG,.01);
const key=new THREE.DirectionalLight(0xfff0dc,.95);key.position.set(GX-6,GY+8,11);key.target=root;key.castShadow=true;
Object.assign(key.shadow.camera,{left:-3,right:3,top:5,bottom:-1,near:1,far:30});key.shadow.bias=-.0006;key.shadow.radius=3;
fgScene.add(key,new THREE.AmbientLight(0x9fb4d8,.72),new THREE.HemisphereLight(0x6f9bd1,0x6a4a22,.28));

/* string overlays (front, and behind the puppet) are camera-attached planes carrying 2D canvases */
const ovF=mk(16,16),ovB=mk(16,16),ovFt=new THREE.CanvasTexture(ovF),ovBt=new THREE.CanvasTexture(ovB);
[ovFt,ovBt].forEach(t=>{t.minFilter=THREE.LinearFilter;t.generateMipmaps=false});
const mkOv=(t,z)=>{const m=new THREE.Mesh(new THREE.PlaneGeometry(1,1),new THREE.MeshBasicMaterial({map:t,transparent:true,depthTest:false,depthWrite:false}));m.position.z=z;m.renderOrder=z<-30?-1:10;fgCam.add(m);return m};
const planeF=mkOv(ovFt,-10),planeB=mkOv(ovBt,-60);

/* ======================= HAND + ARM : skinned mesh from right.glb + lofted forearm =======================
   The hand is the supplied right.glb (subdivided once, 25-bone skeleton, linear-blend skinning on the CPU).
   Nails and knuckle creases are baked per-vertex fields (rest pose) so they follow the deformation.
   The forearm is a loft welded to the glb's open wrist rim and morphed into the traced reference arm profile.
   Everything is in design pixels (x right, y down, z toward camera); output feeds the engraving post-pass as L / nail / facing. */
const SM=t=>{t=clamp(t,0,1);return t*t*(3-2*t)};
const V3=(x,y,z)=>new THREE.Vector3(x,y,z);
const WRIST={x:1523.5108492,y:153.0507012};
const BT=[[1235,100,200],[1275,80,225],[1300,68,236],[1350,55,240],[1400,48,246],[1450,60,243],[1500,90,236],[1550,92,256],[1600,90,284],[1700,85,316],[1800,78,342],[1920,75,372],[2150,72,420]];
function tab(x,c){const n=BT.length;let i=0;while(i<n-2&&x>BT[i+1][0])i++;
  const p=k=>BT[clamp(k,0,n-1)],a=p(i-1)[c],b=p(i)[c],d=p(i+1)[c],e=p(i+2)[c],t=clamp((x-BT[i][0])/(BT[i+1][0]-BT[i][0]),0,1);
  return .5*((2*b)+(-a+d)*t+(2*a-5*b+4*d-e)*t*t+(-a+3*b-3*d+e)*t*t*t)}
const HD=(()=>{const u8=Uint8Array.from(atob(HAND_B64),c=>c.charCodeAt(0)),b=u8.buffer,dv=new DataView(b);
  const nV=dv.getUint32(0,true),nT=dv.getUint32(4,true),nJ=dv.getUint32(8,true);let o=12;
  const take=(T,n,sz)=>{const r=new T(b.slice(o,o+n*sz));o+=n*sz;return r};
  const pos=take(Float32Array,nV*3,4),jid=take(Uint8Array,nV*4,1),wt=take(Uint8Array,nV*4,1),j0=take(Int8Array,nV,1),j1=take(Int8Array,nV,1),j2=take(Int8Array,nV,1),ne=take(Uint8Array,nV,1),fm=take(Uint8Array,nV,1),dr=take(Int8Array,nV,1),idx=take(Uint16Array,nT*3,2),JP=take(Float32Array,nJ*3,4);
  const nR=dv.getUint16(o,true);o+=2;const rim=take(Uint16Array,nR,2);return {nV,nT,nJ,pos,jid,wt,j0,j1,j2,ne,fm,dr,idx,JP,rim}})();
/* shader: lighting, nails (superellipse field), knuckle creases (distance-to-joint fields), fine skin texture */
const handVS='attribute vec4 fa;attribute vec3 rp;attribute vec2 nd;varying vec3 vN,vR;varying vec4 vF;varying vec2 vD;void main(){vN=normal;vR=rp;vF=fa;vD=nd;gl_Position=projectionMatrix*viewMatrix*modelMatrix*vec4(position,1.);}';
const handFS=`precision highp float;uniform float uPm;varying vec3 vN,vR;varying vec4 vF;varying vec2 vD;
  float ln(float d,float w){return 1.-smoothstep(w*.5,w*.5+1.,d);}
  void main(){vec3 n=normalize(vN);
    float L=clamp(.5+(dot(n,normalize(vec3(-.42,-.85,.5)))-.5)*.95,0.,1.);
    float nz=clamp(n.z,0.,1.);if(vD.x<2.9)L*=mix(.32,1.,smoothstep(.03,.5,nz));
    float dm=smoothstep(.3,.9,vD.y),innerSide=smoothstep(.3,.9,-vD.y),cr=0.,palmCr=0.,kb=0.;
    for(int j=0;j<3;j++){float signedD=(j==0?vF.x:j==1?vF.y:vF.z)*uPm;
      float arc=sin(vR.z*125.+float(j)*.8)*.8,arc2=sin(vR.z*210.+float(j)*2.1)*.45;
      /* knuckle wrinkle cluster: deep central fold, echo folds either side, fine broken lines further out */
      float primary=ln(abs(signedD+arc),.55*uPm);
      float secondary=ln(abs(signedD+arc-2.1*uPm),.22*uPm)*.32;
      float above=ln(abs(signedD+arc*1.25+arc2+1.5*uPm),.34*uPm)*.55;
      float below=ln(abs(signedD+arc*.8-arc2-1.2*uPm),.3*uPm)*.5;
      float fine=ln(abs(signedD+arc*1.5+arc2*2.+2.9*uPm),.16*uPm)*.28*step(.35,fract(vR.z*95.+float(j)*.37));
      cr=max(cr,max(max(primary,secondary),max(max(above,below),fine)));
      kb=max(kb,exp(-signedD*signedD/(10.*uPm*uPm)));
       float innerFold=ln(abs(signedD+arc),.82*uPm);
       float innerEcho=ln(abs(signedD+arc+1.7*uPm),.32*uPm)*.38;
       palmCr=max(palmCr,max(innerFold,innerEcho));}
    cr*=dm*vF.w*smoothstep(.15,.55,nz);
     cr=max(cr,palmCr*innerSide*vF.w*smoothstep(.15,.55,nz)*.82);
    float e=vD.x*.8;float nail=(1.-smoothstep(.98,1.04,e))*mix(.5,1.,1.-smoothstep(.6,.67,e));
    if(nail>.9)L=mix(L,.9,.35);
    float k=sin(vR.y*1150.+sin(vR.z*760.)*2.)*sin(vR.z*930.+sin(vR.x*820.)*2.);
    float k2=sin(dot(vR,vec3(1700.,-1300.,1500.)))*sin(dot(vR,vec3(-1400.,1800.,1100.)));
    L*=1.-.07*k*smoothstep(.2,.9,L)-.05*k2;
    /* raised knuckle pads catch the light on the back of the fingers; rhombic skin micro-relief everywhere */
    L+=.07*kb*dm*vF.w*smoothstep(.25,.75,L);
    float sk=abs(sin(dot(vR,vec3(2600.,1900.,-2200.))))*abs(sin(dot(vR,vec3(-2100.,2500.,2400.))));L*=1.-.035*(1.-sk);
    L*=1.-.42*cr;
    gl_FragColor=vec4(L,nail,nz,1.);}`;
const hMat=new THREE.ShaderMaterial({vertexShader:handVS,fragmentShader:handFS,side:THREE.DoubleSide,depthTest:true,depthWrite:true,blending:THREE.NoBlending,uniforms:{uPm:{value:2.4}}});
const handScene=new THREE.Scene(),handGroup=new THREE.Group();handGroup.scale.set(.01,-.01,.01);handGroup.position.set(0,WH,0);handScene.add(handGroup);
/* hand geometry */
const nV=HD.nV,KR=HD.rim.length,MR=28,nA=MR*KR;
const sculptWeights=new Float32Array(nV*2),palmJoints=new Set([0,1,5,6,10,11,15,16,20,21]);
for(let i=0;i<nV;i++)for(let k=0;k<4;k++){
  const joint=HD.jid[i*4+k],weight=HD.wt[i*4+k]/255;
  if(palmJoints.has(joint))sculptWeights[i*2]+=weight;
  if(joint>=20)sculptWeights[i*2+1]+=weight;
}
const NT=nV+nA,hPos=new Float32Array(NT*3),hNor=new Float32Array(NT*3),hFa=new Float32Array(NT*4),hRp=new Float32Array(NT*3),hNd=new Float32Array(NT*2);
for(let i=0;i<nV;i++){hFa[i*4]=HD.j0[i]*.5;hFa[i*4+1]=HD.j1[i]*.5;hFa[i*4+2]=HD.j2[i]*.5;hFa[i*4+3]=HD.fm[i]/255;hRp.set(HD.pos.subarray(i*3,i*3+3),i*3);hNd[i*2]=HD.ne[i]/80;hNd[i*2+1]=HD.dr[i]/127}
for(let i=nV;i<NT;i++){hNd[i*2]=3;hNd[i*2+1]=0;hRp[i*3]=i*.0007;hRp[i*3+1]=i*.0011;hRp[i*3+2]=i*.0005}
const hIdx=[...HD.idx];
for(let i=0;i<MR-1;i++)for(let k=0;k<KR;k++){const a=nV+i*KR+k,b=nV+i*KR+(k+1)%KR,c=a+KR,d=b+KR;hIdx.push(a,c,b,b,c,d)}
const hg=new THREE.BufferGeometry();
hg.setAttribute('position',new THREE.BufferAttribute(hPos,3));hg.setAttribute('normal',new THREE.BufferAttribute(hNor,3));hg.setAttribute('fa',new THREE.BufferAttribute(hFa,4));hg.setAttribute('rp',new THREE.BufferAttribute(hRp,3));hg.setAttribute('nd',new THREE.BufferAttribute(hNd,2));hg.setIndex(hIdx);
const hMesh=new THREE.Mesh(hg,hMat);hMesh.frustumCulled=false;handGroup.add(hMesh);
/* welded vertex groups (glb has UV seams) so normals are continuous */
const wg=new Int32Array(nV);{const m=new Map();for(let i=0;i<nV;i++){const k=Math.round(HD.pos[i*3]*1e5)+','+Math.round(HD.pos[i*3+1]*1e5)+','+Math.round(HD.pos[i*3+2]*1e5);if(!m.has(k))m.set(k,m.size);wg[i]=m.get(k)}wg.n=m.size}
const NW=Math.max(...wg)+1,wAcc=new Float32Array(NW*3);
/* ---- rig ---- joints: 0 wrist · 1-4 thumb(meta,prox,dist,tip) · 5-9 index · 10-14 middle · 15-19 ring · 20-24 pinky (meta,prox,mid,dist,tip) */
const JPv=i=>V3(HD.JP[i*3],HD.JP[i*3+1],HD.JP[i*3+2]);
const RC=(()=>{const c=V3(0,0,0);for(let i=0;i<KR;i++){const v=HD.rim[i];c.x+=HD.pos[v*3];c.y+=HD.pos[v*3+1];c.z+=HD.pos[v*3+2]}return c.multiplyScalar(1/KR)})();
const AX=V3(1,0,0),AZ=V3(0,0,1);
const M4=THREE.Matrix4,Mj=[...Array(25)].map(()=>new M4()),_m=new M4(),_r=new M4(),_t1=new M4(),_t2=new M4();
const pivRot=(p,ax,ang,out)=>{_r.makeRotationAxis(ax,ang);_t1.makeTranslation(p.x,p.y,p.z);_t2.makeTranslation(-p.x,-p.y,-p.z);return out.copy(_t1).multiply(_r).multiply(_t2)};
/* hand pose in the reference: back of hand toward the camera, knuckles to the left, fingers hanging in a fan, thumb below */
/* pose fitted (least squares) so that the skeleton's knuckles/tips land on the traced reference fingers */
const S=2785.8712067,POSE={z0:34,stretch:0.9400000};
const RX=(a)=>new M4().makeRotationAxis(AX,a),RY=(a)=>new M4().makeRotationAxis(V3(0,1,0),a),RZ=(a)=>new M4().makeRotationAxis(AZ,a);
const Rg=RZ(1.2836784).multiply(RY(0.1490894)).multiply(RX(-2.3325917));
const FINGERS=[
  {j:[20,21,22,23,24],f:[0.3944747,0.7357004,0.2173767],sp:0.0214514,meta:0.0817703},
  {j:[15,16,17,18,19],f:[0.7364004,0.2805515,0.0753453],sp:-1.3000000,meta:-0.2619082},
  {j:[10,11,12,13,14],f:[0.8507767,0.4192672,-0.0939056],sp:0.4099365,meta:-0.2335184},
  {j:[5,6,7,8,9],f:[0.6667800,0.7257684,1.2000000],sp:0.3158175,meta:0.1118421}];
const poseV=V3(0,0,0),_p=V3(0,0,0),_n=V3(0,0,0);
const hjP=[...Array(25)].map(()=>V3(0,0,0));
const tips=[...Array(5)].map(()=>[0,0]),jd=[...Array(25)].map(()=>[0,0]);
// Attach to the skinned surface, not to bones buried inside the fingertips.
const surfaceTips=[[23,24],[8,9],[18,19],[13,14],[3,4]].map(([distal,tip])=>{
  const direction=JPv(tip).sub(JPv(distal)),vertices=[];
  for(let i=0;i<nV;i++){
    let membership=0;for(let k=0;k<4;k++)if(HD.jid[i*4+k]===distal||HD.jid[i*4+k]===tip)membership+=HD.wt[i*4+k]/255;
    if(membership>.5)vertices.push({i,d:HD.pos[i*3]*direction.x+HD.pos[i*3+1]*direction.y+HD.pos[i*3+2]*direction.z});
  }
  return vertices.sort((a,b)=>b.d-a.d).slice(0,8).map(v=>v.i);
});
const nailPins=new Set(surfaceTips.flat());
// Landmark residuals adjust finger shafts while keeping the traced nail tips pinned.
const jointOffsets={
  1:[16.9,4.1],2:[-.9,3.3],3:[-2.2,9.4],4:[-7.8,11.3],
  6:[-10.6,-5],7:[-3.2,5],8:[3.5,-.9],9:[-2.2,1.7],
  11:[10.7,1.4],12:[-.2,-3],13:[-11.8,7.6],14:[-12.6,18.6],
  16:[1.4,3.5],17:[7,-4.5],18:[-5.2,7.4],19:[-10.5,13.8],
  21:[-20.7,-6.8],22:[1,-1],23:[-5.4,5],24:[-12.9,12.2]
};
const fingerGuide=new Float32Array(nV*2);
for(let i=0;i<nV;i++)for(let k=0;k<4;k++){
  const delta=jointOffsets[HD.jid[i*4+k]],weight=HD.wt[i*4+k]/255;
  if(delta){fingerGuide[i*2]+=delta[0]*weight;fingerGuide[i*2+1]+=delta[1]*weight;}
}
const rimC=V3(0,0,0);
function poseHand(t,ph,hipBob){
  const sx=Math.sin(ph*Math.PI*2)*3.5*DIR,sy=-hipBob*100*.22,tilt=Math.sin(ph*Math.PI*2)*.009,ct=Math.cos(tilt),st=Math.sin(tilt);
  /* --- FK in rest space --- */
  Mj.forEach(m=>m.identity());
  FINGERS.forEach((F,i)=>{const [m,p,q,d,tp]=F.j;
    const breath=Math.sin(t*.85+i*.7)-Math.sin(i*.7);
    const pull=Math.sin(ph*Math.PI*2+i*.55)-Math.sin(i*.55);
    const fl=[0,1,2].map(k=>F.f[k]+breath*.009+pull*(k===0?.016:.009));
    const spread=F.sp+breath*.005,axs=AZ.clone().applyAxisAngle(AX,spread);
    pivRot(JPv(m),AZ,F.meta,Mj[m]);
    pivRot(JPv(p),AX,spread,_m);const sp=_m.clone();
    pivRot(JPv(p),axs,-fl[0],_m);Mj[p].copy(Mj[m]).multiply(_m).multiply(sp);
    pivRot(JPv(q),AZ,-fl[1],_m);Mj[q].copy(Mj[p]).multiply(_m);
    pivRot(JPv(d),AZ,-fl[2],_m);Mj[d].copy(Mj[q]).multiply(_m);Mj[tp].copy(Mj[d])});
  { /* Thumb opposition, then MCP and IP flexion. */
    pivRot(JPv(1),V3(0,1,0),1.6648398,_m);const a=_m.clone();pivRot(JPv(1),AX,1.3876056,_m);a.premultiply(_m);pivRot(JPv(1),AZ,-0.1478794,_m);Mj[1].copy(_m).multiply(a);
    pivRot(JPv(2),AZ,-0.5736131+Math.sin(t*.9)*.012,_m);Mj[2].copy(Mj[1]).multiply(_m);
    pivRot(JPv(3),AZ,0.4806959+Math.sin(t*1.2)*.009,_m);Mj[3].copy(Mj[2]).multiply(_m);Mj[4].copy(Mj[3])}
  /* --- skin: rest -> posed rest -> design --- */
  const e=Rg.elements,xf=(v,o,i)=>{ // v posed rest (y-up frame) -> design px
    const x=v.x-RC.x,y=v.y-RC.y,z=v.z-RC.z;
    let X=S*(e[0]*x+e[4]*y+e[8]*z),Y=S*(e[1]*x+e[5]*y+e[9]*z),Z=S*(e[2]*x+e[6]*y+e[10]*z);
    let dx=X,dy=-Y*POSE.stretch;const rx=dx*ct-dy*st,ry=dx*st+dy*ct;
    o[i]=WRIST.x+rx+sx;o[i+1]=WRIST.y+ry+sy;o[i+2]=POSE.z0+Z}
  const P=HD.pos;
  for(let i=0;i<nV;i++){let X=0,Y=0,Z=0;const x=P[i*3],y=P[i*3+1],z=P[i*3+2];
    for(let k=0;k<4;k++){const w=HD.wt[i*4+k]/255;if(!w)continue;const m=Mj[HD.jid[i*4+k]].elements;
      X+=w*(m[0]*x+m[4]*y+m[8]*z+m[12]);Y+=w*(m[1]*x+m[5]*y+m[9]*z+m[13]);Z+=w*(m[2]*x+m[6]*y+m[10]*z+m[14])}
    poseV.set(X,Y,Z);xf(poseV,hPos,i*3);
    const nailFade=nailPins.has(i)?0:clamp((HD.ne[i]-80)/100,0,1);
    hPos[i*3]+=fingerGuide[i*2]*.68*nailFade;hPos[i*3+1]+=fingerGuide[i*2+1]*.68*nailFade;
    // Restore the palm's lower fullness and outer knuckle arch without shifting distal fingertips.
    const px=hPos[i*3]-sx,py=hPos[i*3+1]-sy;
    const palm=Math.exp(-Math.pow((px-1380)/100,2)-Math.pow((py-180)/65,2))*sculptWeights[i*2]*clamp((1535-px)/55,0,1);
    const outer=Math.exp(-Math.pow((px-1260)/95,2)-Math.pow((py-100)/45,2))*sculptWeights[i*2+1];
    hPos[i*3]-=.2773475*outer;hPos[i*3+1]+=41.243598*palm-21.394374*outer;
  }
  /* joints (for strings) */
  const jx=(j)=>{_p.copy(JPv(j)).applyMatrix4(Mj[j]);const o=[0,0,0];xf(_p,o,0);return o};
  surfaceTips.forEach((indices,i)=>{
    const point=[0,0];indices.forEach(v=>{point[0]+=hPos[v*3];point[1]+=hPos[v*3+1];});
    tips[i]=point.map(value=>value/indices.length);
  });

  [23,8,18,13,3].forEach((j,i)=>{const o=jx(j);jd[i]=[o[0],o[1]]});
  /* --- forearm: loft welded to the wrist rim, morphing into the traced reference profile --- */
  const rim=HD.rim,c0=[0,0,0];for(let k=0;k<KR;k++){const v=rim[k]*3;c0[0]+=hPos[v];c0[1]+=hPos[v+1];c0[2]+=hPos[v+2]}c0[0]/=KR;c0[1]/=KR;c0[2]/=KR;
  let ry0=1,rz0=1;for(let k=0;k<KR;k++){const v=rim[k]*3;ry0=Math.max(ry0,Math.abs(hPos[v+1]-c0[1]));rz0=Math.max(rz0,Math.abs(hPos[v+2]-c0[2]))}
  const xEnd=2260;
  for(let i=0;i<MR;i++){const u=i/(MR-1),m=SM(u*1.7),xi=c0[0]+(xEnd-c0[0])*Math.pow(u,1.2),top=tab(xi,1),bot=tab(xi,2),hy=(bot-top)/2,hz=hy*lerp(.62,.9,SM((xi-1490)/280));
    const cy=lerp(c0[1],(top+bot)/2,m),cz=lerp(c0[2],18,m),sy2=lerp(1,hy/ry0,m),sz2=lerp(1,hz/rz0,m),cx=xi;
    for(let k=0;k<KR;k++){const v=rim[k]*3,o=(nV+i*KR+k)*3,dx=hPos[v]-c0[0],dy=hPos[v+1]-c0[1],dz=hPos[v+2]-c0[2];
      hPos[o]=cx+dx*(1-m);hPos[o+1]=cy+dy*sy2;hPos[o+2]=cz+dz*sz2}}
  /* --- normals (y-down design space: use face normals, flipped outward by the sign test) --- */
  hNor.fill(0);wAcc.fill(0);const FA0=nV*3;
  const I=hIdx,nI=I.length;
  for(let f=0;f<nI;f+=3){const a=I[f]*3,b=I[f+1]*3,c=I[f+2]*3;
    const ux=hPos[b]-hPos[a],uy=hPos[b+1]-hPos[a+1],uz=hPos[b+2]-hPos[a+2],vx=hPos[c]-hPos[a],vy=hPos[c+1]-hPos[a+1],vz=hPos[c+2]-hPos[a+2];
    const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
    for(const q of [I[f],I[f+1],I[f+2]]){if(q<nV){const w=wg[q]*3;wAcc[w]+=nx;wAcc[w+1]+=ny;wAcc[w+2]+=nz}else{hNor[q*3]+=nx;hNor[q*3+1]+=ny;hNor[q*3+2]+=nz}}}
  for(let i=0;i<nV;i++){const w=wg[i]*3;hNor[i*3]=wAcc[w];hNor[i*3+1]=wAcc[w+1];hNor[i*3+2]=wAcc[w+2]}
  /* outward sign: hand (design y-down flips winding) -> test against vector from the hand centre line */
  let sg=0;for(let i=0;i<nV;i+=7){const o=i*3;sg+=hNor[o]*(hPos[o]-WRIST.x+250)+hNor[o+1]*(hPos[o+1]-WRIST.y)+hNor[o+2]*(hPos[o+2]-POSE.z0)}
  const sgn=sg>=0?1:-1;
  for(let i=0;i<NT;i++){const o=i*3;let x=hNor[o]*sgn,y=hNor[o+1]*sgn,z=hNor[o+2]*sgn;const l=Math.hypot(x,y,z)||1;hNor[o]=x/l;hNor[o+1]=y/l;hNor[o+2]=z/l}
  /* forearm: shade by position across the arm (lit top -> shaded underside) like the reference engraving */
  for(let i=0;i<MR;i++){const u=i/(MR-1),xi=c0[0]+(xEnd-c0[0])*Math.pow(u,1.2),top=tab(xi,1),bot=tab(xi,2),cy=(top+bot)/2,hy=(bot-top)/2;
    for(let k=0;k<KR;k++){const o=(nV+i*KR+k)*3,r=clamp((hPos[o+1]-cy)/hy,-1.2,1.2),ny=clamp((r+.85*SM((hPos[o]-1560)/650))*.8-.55+.08*Math.sin(hPos[o]*.012),-.97,.9),m=SM(u*3),nz=Math.sqrt(1-ny*ny);
      hNor[o]=lerp(hNor[o],0,m);hNor[o+1]=lerp(hNor[o+1],ny,m);hNor[o+2]=lerp(hNor[o+2],nz,m);const l=Math.hypot(hNor[o],hNor[o+1],hNor[o+2]);hNor[o]/=l;hNor[o+1]/=l;hNor[o+2]/=l}}
  /* weld the forearm start to the hand rim normals */
  for(let k=0;k<KR;k++){const a=rim[k]*3,b=(nV+k)*3;for(let q=0;q<3;q++)hNor[b+q]=hNor[a+q]}
  hg.attributes.position.needsUpdate=hg.attributes.normal.needsUpdate=true;
  rimC.set(c0[0],c0[1],c0[2]);
  if(typeof postMat!=='undefined')postMat.uniforms.uWrist.value.set(c0[0]+6,c0[1]);
}

/* ======================= POST: the engraved-print look ======================= */
const glyphTex=(()=>{const c=mk(512,512),x=c.getContext('2d'),r=rng(31);x.fillStyle='#000';x.fillRect(0,0,512,512);
  x.strokeStyle='#fff';x.lineWidth=5.2;x.font='700 60px "Times New Roman",Georgia,serif';x.textAlign='center';x.textBaseline='middle';x.lineJoin='round';
  const L='ABRHWGOQNZKEDUMS';
  for(let i=0;i<70;i++){const px=r()*512,py=r()*512,a=r()*6.283,ch=L[Math.floor(r()*L.length)];
    for(const ox of[-512,0,512])for(const oy of[-512,0,512]){x.save();x.translate(px+ox,py+oy);x.rotate(a);x.scale(.8+r()*.0,1);x.strokeText(ch,0,0);x.restore()}}
  const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.minFilter=THREE.LinearMipmapLinearFilter;t.anisotropy=4;return t})();
const postScene=new THREE.Scene(),postCam=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
const postMat=new THREE.ShaderMaterial({uniforms:{uBG:{value:null},uFG:{value:null},uHand:{value:null},uGlyph:{value:glyphTex},uView:{value:new THREE.Vector2(0,DW)},
  uCircle:{value:new THREE.Vector3(CIRC.x*U,DH-CIRC.y*U,CIRC.R*U)},uQ:{value:.65},uFp:{value:1},uT:{value:0},uWrist:{value:new THREE.Vector2(WRIST.x,WRIST.y)}},
vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}',
fragmentShader:`precision highp float;
uniform sampler2D uBG,uFG,uHand,uGlyph;uniform vec2 uView,uWrist;uniform vec3 uCircle;uniform float uQ,uFp,uT;varying vec2 vUv;
float h11(float n){return fract(sin(n*127.1)*43758.5453);}
float h21(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
vec2 h22(vec2 p){return fract(sin(vec2(dot(p,vec2(127.1,311.7)),dot(p,vec2(269.5,183.3))))*43758.5453);}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*vn(p);p*=2.03;a*=.5;}return s;}
mat2 rot(float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c);}
float lum(vec3 c){return dot(c,vec3(.299,.587,.114));}
/* engraving: strokes run in irregular patches whose direction (two diagonals, optionally also axis-aligned) follows a slowly evolving
   noise field; lines wobble and break into dashes, so it reads as hand-cut maze work that keeps crawling */
float engr(vec2 d,float pitch,float psz,float seed,float ax,float duty,float brk){
  float N=2.+2.*ax,n=fbm(d/psz+seed*1.7+vec2(uT*.025,-uT*.018));
  float o=floor(clamp((n-.5)*2.6+.5,0.,.999)*N);
  float across=o<.5?(d.x+d.y)*.70710678:o<1.5?(d.x-d.y)*.70710678:o<2.5?d.x:d.y;
  float along=o<.5?(d.x-d.y)*.70710678:o<1.5?(d.x+d.y)*.70710678:o<2.5?d.y:d.x;
  float u=across/pitch+(fbm(d/9.+seed)-.5)*.5+seed;
  float tr=abs(fract(u)-.5)*2.;
  float on=smoothstep(brk-.05,brk+.05,vn(vec2(along/10.+uT*.12*(h11(floor(u)+seed)-.5),floor(u)*1.37+seed*3.)));
  float aa=.12*uFp+.015;
  return smoothstep(1.-duty-aa,1.-duty+aa,tr)*on;}
float halftone(vec2 d,float per,float inten){
  vec2 f=fract(rot(.785398)*d/per)-.5;float r=sqrt(clamp(inten,0.,1.))*.74,aa=uFp/per*.8+.02;
  return mix(clamp(inten,0.,1.),1.-smoothstep(r-aa,r+aa,length(f)),1.-smoothstep(.5,1.1,uFp/per));}
/* mottled blue sky with dotted diagonal chains that slowly re-route */
vec3 skyTex(vec2 d){
  float bt=uT*.05;vec3 c=vec3(.032,.25,.362);
  c*=1.+(fbm(d/7.+vec2(bt,0.))-.5)*.5+(fbm(d/26.-vec2(0.,bt))-.5)*.36+(fbm(d/110.+4.)-.5)*.2;
  float fade=1.-smoothstep(.6,1.9,uFp/2.5);
  float fam=step(.5,h21(floor(d/90.)+3.));vec2 r=rot(fam>.5?.785398:-.785398)*d;
  float row=floor(r.y/11.),rf=fract(r.y/11.),seg=floor(r.x/(14.+h11(row)*30.));
  float hs=h21(vec2(row,seg)+fam*9.);
  float live=step(.5,h21(vec2(row,seg)+fam*9.+floor(uT*.45+h21(vec2(seg,row))*5.)*.31));
  vec2 q=vec2(fract(r.x/5.5)-.5,rf-.5)*vec2(5.5,11.);
  float dots=1.-smoothstep(.7,.7+uFp*.8,length(q));
  float dash=(1.-smoothstep(.45,.45+uFp*.8,abs(q.y)))*step(.5,fract(r.x/13.+hs));
  float chain=mix(dots,dash*.7,step(.82,fract(hs*13.)))*live;
  vec2 g=d/8.,gf=(fract(g)-.5)*8.;
  float d2=(1.-smoothstep(.7,.7+uFp*.8,length(gf)))*step(.9,h21(floor(g)+1.7+floor(uT*.7+h21(floor(g))*6.)));
  return mix(c,vec3(.55,.76,.88),max(chain*.66,d2*.8)*fade*(.55+.45*uQ));}
/* hill: gold engraving over deep ink, ink pools where the light falls off */
vec3 hillTex(vec3 bc,vec2 d){
  float L=lum(bc),dens=clamp((L-.04)/.3,.02,1.);
  float st=engr(d,3.5,24.,11.,0.,mix(.25,.7,dens),.12);
  float st2=engr(d+7.,4.1,19.,23.,0.,.3*dens,.3);
  float ink=smoothstep(.0,.3,fbm(d/18.+vec2(0.,uT*.03))-(.8-dens*.6))*.6;
  vec3 gold=vec3(.85,.72,.38)*(.3+L*1.0),dark=vec3(.03,.085,.11)*(1.+(fbm(d/50.)-.5)*.6);
  float m=clamp(max(st,st2*.8)*(1.-ink*.6)+.05*dens,0.,1.);
  return mix(dark,gold,m);}
vec3 orangeTex(vec3 c,vec2 d){
  if(uQ<.4)return c*(.9+.14*engr(d,3.4,18.,21.,0.,.4,.1));
  vec2 w=vec2(fbm(d/41.),fbm(d/41.+7.3))-.5;vec2 p=d/15.+w*2.2;vec2 i=floor(p),f=fract(p);
  float m=9.,m2=9.,id=0.;
  for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec2 g=vec2(float(x),float(y));vec2 r=g+h22(i+g)-f;float dd=dot(r,r);
    if(dd<m){m2=m;m=dd;id=h21(i+g+3.+floor(uT*.5+h21(i+g)*3.)*.17);}else if(dd<m2){m2=dd;}}
  float seam=1.-smoothstep(0.,.15,sqrt(m2)-sqrt(m));
  vec3 o=c*(.8+.3*id);o=mix(o,c*1.3+vec3(.07,.05,0.),seam*.5);
  return o*(.92+.14*engr(d,3.4,18.,21.,0.,.4,.1));}
float orangeness(vec4 t){vec3 c=t.rgb/max(t.a,.001);return t.a*smoothstep(1.3,1.8,c.r/(c.g+.02))*smoothstep(1.6,2.6,c.r/(c.b+.02));}
/* peach surfaces (clouds, arm): solid where lit, then diagonal pale-blue hatching as the light falls off */
vec4 peachHatch(vec2 d,float s,float seed){
  float f=.42+.5*s;
  float st=max(engr(d,3.9,15.,seed,0.,f,.1),engr(d+3.,3.9,21.,seed+5.,0.,.3,.2)*(1.-s)*.9);
  vec3 pe=vec3(.9,.71,.55)*(.95+.1*h21(floor(d/2.))),pb=vec3(.84,.87,.84);
  vec2 sp=d/5.;float spk=(1.-smoothstep(.1,.2+uFp*.1,length(fract(sp)-.5)))*step(.965,h21(floor(sp)+seed));
  pe=mix(pe,vec3(.45,.27,.2),spk*.7);
  float solid=smoothstep(.8,.97,s);
  return vec4(mix(pb,pe,smoothstep(.2,.75,s)),mix(st,1.,solid));}
/* clouds (reference): lit bump crowns are solid peach with a faint engraved weave; toward the shade the peach breaks into a
   diamond cross-hatch (two diagonals) whose lines thin out, leaving blue lozenges; deepest shade keeps sparse broken lines */
vec4 cloudHatch(vec2 d,float s,vec3 sky){
  vec2 w=d+(vec2(fbm(d/13.),fbm(d/13.+5.2))-.5)*3.4;
  float p=4.3;
  float u1=(w.x+w.y)*.70710678/p,u2=(w.x-w.y)*.70710678/p;
  float t1=abs(fract(u1)-.5)*2.,t2=abs(fract(u2)-.5)*2.;
  float k1=mix(.16,1.05,smoothstep(.04,.8,s)),k2=mix(.0,1.05,smoothstep(.12,.86,s));
  float aa=.16*uFp+.04;
  float br1=smoothstep(.12,.22,vn(vec2(u2*1.7,floor(u1)*3.1)+uT*.05)),br2=smoothstep(.2,.3,vn(vec2(u1*1.7,floor(u2)*2.3)+7.));
  float l1=(1.-smoothstep(k1-aa,k1+aa,t1))*mix(br1,1.,smoothstep(.3,.6,s));
  float l2=(1.-smoothstep(k2-aa,k2+aa,t2))*mix(br2,1.,smoothstep(.35,.65,s));
  float m=max(l1,l2);
  float solid=smoothstep(.78,.93,s);m=mix(m,1.,solid);
  vec3 pe=vec3(.93,.76,.6)*(.95+.08*h21(floor(d/2.)));
  vec3 lt=vec3(.97,.85,.7);
  vec3 c=mix(vec3(.84,.71,.6),mix(pe,lt,smoothstep(.85,1.,s)),smoothstep(.25,.8,s));
  /* fine engraved weave + rust specks on the lit peach */
  float wv=engr(d,3.,11.,7.,1.,.18,.25)*solid;c=mix(c,vec3(.78,.6,.48),wv*.35);
  vec2 sp=d/4.6;float spk=(1.-smoothstep(.1,.2+uFp*.1,length(fract(sp)-.5)))*step(.955,h21(floor(sp)+3.));
  c=mix(c,vec3(.5,.3,.22),spk*.6*smoothstep(.4,.9,s));
  /* the blue lozenges between lines are a touch darker than open sky */
  vec3 gap=sky*mix(.82,1.,s);
  return vec4(mix(gap,c,m),1.);}
/* the hand: orange engraved skin, peach rim, nails, then the forearm fading to hatching */
vec4 handLayer(vec2 d,vec3 h,float edge,float top){
  float L=h.x,nz=h.z,nailIn=step(.75,h.y),nailRing=step(.25,h.y)-nailIn;
  float armW=smoothstep(.38,.62,smoothstep(-26.,26.,d.x-(uWrist.x-(d.y-uWrist.y)*.22)-(fbm(d/28.)-.5)*12.)+(h21(floor(d/2.5))-.5)*.3);
  vec3 dk=vec3(.5,.1,.03),md=vec3(.85,.25,.05),lt=vec3(.96,.4,.1),pe=vec3(.95,.74,.56);
  float t=clamp(L*.92,0.,1.);
  vec3 o=t<.45?mix(dk,md,t/.45):mix(md,lt,(t-.45)/.55);
  float jx=floor(uT*8.);vec2 jit=(vec2(h11(jx),h11(jx+3.))-.5)*7.+uT*vec2(2.,-1.3);
  float g1=texture2D(uGlyph,(d+jit)/118.).r,g2=texture2D(uGlyph,(d.yx*vec2(1.,-1.)+jit*1.7+40.)/84.).r;
  /* engraved strokes: dark maze in the shade, pale grid on the lit side, glyph swirls throughout */
  float dm=engr(d,4.2,15.,5.,1.,.5,.12)*smoothstep(.85,.15,t);
  o=mix(o,dk*.9,dm*.5);
  o*=1.-g1*.3*smoothstep(.6,.1,t);
  o=mix(o,lt+.12,max(g1,g2)*.62*smoothstep(.15,.5,t)*(1.-smoothstep(.95,1.,t)));
  float gm=engr(d,4.2,13.,9.,1.,.34,.15)*smoothstep(.35,.65,t)*(1.-smoothstep(.8,.98,t));
  o=mix(o,lt+.08,gm*.55);
  vec2 dc=d/6.5;float cd=(1.-smoothstep(.12,.2+uFp*.1,length(fract(dc)-.5)))*step(.88,h21(floor(dc)+floor(uT*.5+h21(floor(dc))*4.)))*smoothstep(.25,.55,t);
  o=mix(o,vec3(.99,.78,.58),cd*.85);
  /* peach rim that dissolves into the orange with a dithered edge */
  float rim=smoothstep(.1,.55,edge)*smoothstep(.2,.65,L);
  float dith=(h21(floor(d/2.))-.5)*.42+(g1-.3)*.25;
  o=mix(o,pe*(.94+.1*h21(floor(d/2.))),smoothstep(.34,.62,rim+dith));
  /* nails */
  o=mix(o,mix(md,vec3(.99,.86,.7),.8)*(.92+.16*g2)*(.65+.45*t),nailIn*.8);o=mix(o,dk*1.3,nailRing*.28);
  /* forearm */
  float s=clamp((L-.66)/.3,0.,1.);float sl=clamp(s*1.15+.1,0.,1.);
  float stk=max(engr(d,3.9,15.,17.,0.,.4+.5*sl,.1),engr(d+3.,3.9,21.,22.,0.,.34,.2)*(1.-sl)*.9);
  vec3 pe2=vec3(.9,.74,.58)*(.94+.12*h21(floor(d/2.)));
  vec3 shd=mix(vec3(.1,.24,.4),vec3(.32,.47,.6),fbm(d/36.+3.));
  vec4 a=vec4(mix(mix(shd,pe2*(.85+.15*sl),stk),pe2,smoothstep(.55,.85,sl)),1.);
  float dash=top*step(.1,edge)*step(edge,.42)*step(.45,fract(d.x/6.5))*step(.35,h21(floor(vec2(d.x/6.5,uT*.7))))*armW;
  vec3 ac=mix(a.rgb,vec3(.1,.2,.26),dash*.7);
  return vec4(mix(mix(o,md,armW*.6),ac,armW),mix(1.,max(a.a,dash),armW));}
void main(){
  vec2 d=vec2(uView.x+vUv.x*uView.y,(1.-vUv.y)*1080.);
  vec4 bg=texture2D(uBG,vUv),fg=texture2D(uFG,vUv),hd=texture2D(uHand,vUv);
  float dist=length(d-uCircle.xy)-uCircle.z,hillM=1.-smoothstep(-uFp*1.3,uFp*1.3,dist);
  vec3 sky=hillM>.999?vec3(0.):skyTex(d);
  /* clouds */
  float cov=bg.a*(1.-hillM);vec3 tone=bg.rgb/max(bg.a,.01);
  float s=clamp(tone.r+(fbm(d/9.+uT*.02)-.5)*.16,0.,1.);
  vec4 ch=cloudHatch(d,s,sky);
  float body=smoothstep(.2,.6,cov);
  vec3 col=mix(sky,ch.rgb,ch.a*body*step(.01,cov));
  if(hillM>.001)col=mix(col,hillTex(tone,d),hillM);
  /* hand and forearm */
  float ha=smoothstep(.3,.7,hd.a);
  {vec2 px=vec2(1./uView.y,1./1080.);
    vec2 o=px*2.4;
    float hl=max(max(texture2D(uHand,vUv+vec2(o.x,0.)).a,texture2D(uHand,vUv-vec2(o.x,0.)).a),max(texture2D(uHand,vUv+vec2(0.,o.y)).a,texture2D(uHand,vUv-vec2(0.,o.y)).a));
    col=mix(col,vec3(.8,.9,.94),smoothstep(.4,.9,hl)*(1.-ha)*.55);
    if(ha>.002){
      float miss=0.;
      for(int i=0;i<8;i++){float an=float(i)*.785398;vec2 v=vec2(cos(an),sin(an));
        miss+=1.-texture2D(uHand,vUv+v*px*8.).a;miss+=1.-texture2D(uHand,vUv+v*px*17.).a;}
      float top=1.-texture2D(uHand,vUv+vec2(0.,px.y*8.)).a;
      vec4 hc=handLayer(d,hd.rgb/max(hd.a,.01),clamp(miss/12.,0.,1.),top);col=mix(col,hc.rgb,hc.a*ha);}}
  /* puppet */
  float a=fg.a;vec3 fc=fg.rgb/max(a,.001);float gr=fc.g/(fc.r+.001);
  float orw=smoothstep(1.3,1.8,fc.r/(fc.g+.02))*smoothstep(1.6,2.6,fc.r/(fc.b+.02));
  float peW=smoothstep(.55,.66,gr)*(1.-smoothstep(.86,.92,gr))*(1.-orw);
  vec3 ft=fc;if(orw>.01)ft=mix(fc,orangeTex(fc,d),orw);
  float pm=halftone(d,3.3,clamp(lum(fc)/.72,0.,1.)*1.05);
  ft=mix(ft,vec3(.9,.72,.56)*(.93+.12*h21(floor(d/2.))),peW);a*=mix(1.,pm,peW);
  {vec2 o=vec2(2.4/uView.y,2.4/1080.);
    float hl=max(max(texture2D(uFG,vUv+vec2(o.x,0.)).a,texture2D(uFG,vUv-vec2(o.x,0.)).a),max(texture2D(uFG,vUv+vec2(0.,o.y)).a,texture2D(uFG,vUv-vec2(0.,o.y)).a));
    hl=max(hl,max(max(texture2D(uFG,vUv+o).a,texture2D(uFG,vUv-o).a),max(texture2D(uFG,vUv+vec2(o.x,-o.y)).a,texture2D(uFG,vUv+vec2(-o.x,o.y)).a)));
    col=mix(col,vec3(.9,.76,.6),smoothstep(.2,.8,hl)*(1.-smoothstep(.0,.6,fg.a))*.8);}
  col=ft*a+col*(1.-a);
  col=mix(vec3(lum(col)),col,1.08);
  gl_FragColor=vec4(clamp(col,0.,1.),1.);}
`});
postScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2),postMat));

/* ======================= STRINGS (2D glyph chains) ======================= */
const FONT='700 16px "Times New Roman",Georgia,serif',ABC='ABRHWGOQNZKEDUBMRHW';
const strRng=rng(5),strLetters=[...Array(8)].map(()=>[...Array(48)].map(()=>ABC[Math.floor(strRng()*ABC.length)]));
const UP=['wN','shN','headN','headF','shF','wF'],LOW=['kneeN','kneeF'];
const v3=new THREE.Vector3();
function toDesign(o){o.getWorldPosition(v3);v3.project(fgCam);return [(camL+(v3.x+1)/2*(camR-camL))*U,(1-(v3.y+1)/2)*DH]}
function drawGlyphString(x,S,E,seed,t,slack,detail){
  const dx=E[0]-S[0],dy=E[1]-S[1],len=Math.max(1,Math.hypot(dx,dy)),nx=-dy/len,ny=dx/len;
  const N=detail?clamp(Math.round(len/17),16,34):clamp(Math.round(len/27),10,22);
  const cx=S[0]+dx*.48,cy=S[1]+dy*.52,pt=u=>{const o=slack*Math.sin(Math.PI*u)*(Math.sin(t*.9+seed*.7)*.7+Math.sin(t*1.35+seed)*.3),a=(1-u)*(1-u),b=2*u*(1-u),c=u*u;return [a*S[0]+b*cx+c*E[0]+nx*o,a*S[1]+b*cy+c*E[1]+ny*o]};
  x.save();x.beginPath();for(let j=0;j<=24;j++){const p=pt(j/24);j?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]);}
  x.strokeStyle='rgba(243,230,198,.28)';x.lineWidth=detail ? .8 : .55;x.stroke();x.restore();
  x.textAlign='center';x.textBaseline='middle';x.font=FONT;x.lineJoin='round';
  for(let i=0;i<N;i++){const u=(i+.5)/N,p=pt(u),q=pt(Math.min(1,u+.02)),r=pt(Math.max(0,u-.02));
    const ux=r[0]-q[0],uy=r[1]-q[1];x.save();x.translate(p[0],p[1]);x.rotate(Math.atan2(ux,-uy));x.scale(.72,1);
    if(detail){x.strokeStyle='rgba(6,24,44,.5)';x.lineWidth=2;x.strokeText(strLetters[seed][i%48],0,0);x.fillStyle='#f3e6c6';x.fillText(strLetters[seed][i%48],0,0)}
    else{x.fillStyle='#f3e6c6';x.fillRect(-2,-4,4,8)}x.restore()}}
/* One stable, ordered tether per digit keeps the letter chains from crossing. */
const stringBindings=[
  {finger:0,target:'wF',back:true,offset:0},{finger:2,target:'shF',back:true,offset:0},
  {finger:3,target:'headN',back:false,offset:0},{finger:1,target:'shN',back:false,offset:0},
  {finger:4,target:'wN',back:false,offset:0}
];
function drawStrings(t,k,detail){
  [ovF,ovB].forEach(c=>{const x=c.getContext('2d');x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,c.width,c.height);x.setTransform(k,0,0,k,-camL*U*k,0)});
  const front=ovF.getContext('2d'),back=ovB.getContext('2d');
  stringBindings.forEach((binding,i)=>{
    const tip=tips[binding.finger],source=[tip[0]+binding.offset,tip[1]+2];
    drawGlyphString(binding.back?back:front,source,toDesign(anc[binding.target]),i,t,2.5,detail);
  });
  ovFt.needsUpdate=ovBt.needsUpdate=true;
}

/* ======================= WALK / POSE (employee gait from the zip) ======================= */
/* foot state relative to the hip column for leg phase p (0 = heel strike). x forward, y above ground */
function foot(p){
  const {S,beta}=WALK,X0=-.1+S*beta*.48,a=LEG.ankle,hx=q=>X0-S*q,bk=beta/.62,q1=.12*bk*(1-WALK.run*.7),q2=.38*bk;
  const stance=q=>{
    if(q<q1){const k=q/q1,pitch=.26*(1-(1-(1-k)*(1-k))),hX=hx(q);return {x:hX+.11*Math.cos(pitch)-a*Math.sin(pitch),y:a*Math.cos(pitch)+.11*Math.sin(pitch),pitch,toe:0}}
    if(q<q2)return {x:hx(q)+.11,y:a,pitch:0,toe:0};
    const k=(q-q2)/(beta-q2),pitch=-.62*k*k*(1.4-.4*k),bx=hx(q)+.3;
    return {x:bx-.19*Math.cos(pitch)-a*Math.sin(pitch),y:-.19*Math.sin(pitch)+a*Math.cos(pitch),pitch,toe:-pitch}};
  if(p<beta)return stance(p);
  const u=(p-beta)/(1-beta),s0=stance(beta-1e-4),s1=stance(0),e=minJerk(u),lift=WALK.lift*Math.pow(Math.sin(Math.PI*Math.pow(u,lerp(.78,.62,WALK.run))),1.1),pk=[-.62,-.3,.02,.26];
  const pitch=u<.3?lerp(pk[0],pk[1],sm(u/.3)):u<.7?lerp(pk[1],pk[2],sm((u-.3)/.4)):lerp(pk[2],pk[3],sm((u-.7)/.3));
  return {x:lerp(s0.x,s1.x,e),y:lerp(s0.y,s1.y,u)+lift,pitch,toe:.62*(1-sm(u/.45))}}
function solveLeg(Lg,fx,fy,pitch,toe){
  const l1=LEG.t,l2=LEG.s;let d=Math.hypot(fx,fy);d=clamp(d,Math.abs(l1-l2)+.01,l1+l2-.002);
  const base=Math.atan2(fx,-fy),a1=Math.acos(clamp((l1*l1+d*d-l2*l2)/(2*l1*d),-1,1)),a2=Math.acos(clamp((l2*l2+d*d-l1*l1)/(2*l2*d),-1,1)),t1=base+a1,t2=-(a1+a2);
  Lg.th.rotation.z=t1;Lg.kn.rotation.z=t2;Lg.an.rotation.z=pitch-(t1+t2);Lg.toe.rotation.z=toe}
function pose(phIn){
  const R=WALK.run,ph=((phIn%1)+1)%1,w=TAU*ph,Lc=(LEG.t+LEG.s)*lerp(.972,.9,R),f=[foot(ph),foot((ph+.5)%1)];
  const hs=f.map(q=>q.y+Math.sqrt(Math.max(.01,Lc*Lc-q.x*q.x))),k=.018,H=-k*Math.log(Math.exp(-hs[0]/k)+Math.exp(-hs[1]/k));
  legsG.position.y=H;legs.forEach((Lg,i)=>solveLeg(Lg,f[i].x,f[i].y-H,f[i].pitch,f[i].toe));
  pelvis.rotation.y=-lerp(.09,.15,R)*Math.cos(w);pelvis.rotation.x=.035*Math.sin(w);
  const sway=-.028*Math.sin(w);legsG.position.z=sway;
  upper.position.set(0,H+.2,sway*1.1);
  upper.rotation.set(.025*Math.sin(w),.04+lerp(.085,.16,R)*Math.cos(w),-.05-.2*R-.012*Math.cos(2*w)-.02*R*Math.cos(2*w));
  head.rotation.set(-.02*Math.sin(w),.2-lerp(.07,.12,R)*Math.cos(w),.04+.17*R+.02*Math.sin(2*w-.6));
  {const bl=blinkAmt(TIME.t);lids.forEach(l=>l.rotation.z=lerp(-.5,1.25,bl));}
  arms.forEach((A,i)=>{const sgn=i===0?-1:1,amp=i===0?lerp(.26,.5,R):lerp(.42,.85,R),sw=sgn*amp*Math.cos(w-.3);
    A.sh.rotation.z=sw-.08*R;A.ab.rotation.x=(i===0?.1:-.1)*(1+R)+.02*Math.sin(w);
    A.el.rotation.z=lerp(i===0?.1:.22,i===0?.75:1.45,R)+lerp(.32,.45,R)*Math.max(0,sw)+.04*Math.sin(2*w);A.hand.rotation.z=.06*Math.sin(w-.8)-.15*R});
  const A0=arms[0],tot=A0.sh.rotation.z+A0.el.rotation.z+A0.hand.rotation.z+upper.rotation.z;
  caseG.rotation.z=-tot+.07*Math.sin(w-1.5);caseG.rotation.x=.06*Math.sin(w*2-.5);
  return {ph,H}}
let hMean=0;
/* pace: one parameter (body speed v) drives cadence, stride, duty factor and posture, walk -> run */
const PACE=[[0,.35],[25,1.05],[50,2.0],[75,3.2],[100,4.6]];
const paceV=x=>{let i=0;while(i<PACE.length-2&&x>PACE[i+1][0])i++;const a=PACE[i],b=PACE[i+1];return lerp(a[1],b[1],(x-a[0])/(b[0]-a[0]))};
function setSpeed(v){
  const R=sm((v-1.75)/.9);WALK.v=v;WALK.run=R;
  const Tw=1.12*Math.pow(1.05/v,.55),Tr=.74*Math.pow(2.6/v,.28);WALK.T=lerp(Tw,Tr,R);
  WALK.S=v*WALK.T;WALK.beta=lerp(.62,.37,R)-.06*sm((v-3.4)/1.2);WALK.lift=lerp(.085,.36,R);
  hMean=0;for(let i=0;i<48;i++)hMean+=pose(i/48).H;hMean/=48}
setSpeed(1.05);   // mean hip height, so the hand follows only the bob

/* ======================= QUALITY / LAYOUT ======================= */
const Q={v:65},qEl=document.getElementById('q'),qv=document.getElementById('qv'),info=document.getElementById('info');
let bgRT,fgRT,hdRT,rtW=0,rtH=0,rtMs=-1,shMap=0;
const HS=1;                                                     // hand pass resolution relative to the frame
const tier=()=>({ms:isGL2?(Q.v<20?0:Q.v<55?2:4):0,sh:Q.v<30?512:Q.v<60?1024:Q.v<85?2048:4096});
function layout(){
  const cw=innerWidth,ch=innerHeight,dpr=Math.min(devicePixelRatio||1,2);
  const scale=(.3+Q.v/100*1.2)*dpr;let w=Math.round(cw*scale),h=Math.round(ch*scale);
  const cap=Math.sqrt(8.4e6/(w*h));if(cap<1){w=Math.round(w*cap);h=Math.round(h*cap)}
  const wv=WH*cw/ch;camR=WW;camL=WW-wv;
  bgCam.left=fgCam.left=camL;bgCam.right=fgCam.right=camR;bgCam.updateProjectionMatrix();fgCam.updateProjectionMatrix();
  planeF.scale.set(wv,WH,1);planeB.scale.set(wv,WH,1);
  planeF.position.x=planeB.position.x=(camL+camR)/2;planeF.position.y=planeB.position.y=(WH-GY-GY)/2;
  renderer.setSize(w,h,false);
  const tr=tier();
  if(w!==rtW||h!==rtH||tr.ms!==rtMs){bgRT&&bgRT.dispose();fgRT&&fgRT.dispose();hdRT&&hdRT.dispose();
    const o={minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,format:THREE.RGBAFormat,generateMipmaps:false};
    bgRT=new THREE.WebGLRenderTarget(w,h,o);hdRT=tr.ms?new THREE.WebGLMultisampleRenderTarget(w,h,o):new THREE.WebGLRenderTarget(w,h,o);if(tr.ms)hdRT.samples=tr.ms;
    fgRT=tr.ms?new THREE.WebGLMultisampleRenderTarget(w,h,o):new THREE.WebGLRenderTarget(w,h,o);if(tr.ms)fgRT.samples=tr.ms;
    rtW=w;rtH=h;rtMs=tr.ms}
  if(tr.sh!==shMap){key.shadow.mapSize.set(tr.sh,tr.sh);key.shadow.map&&key.shadow.map.dispose();key.shadow.map=null;shMap=tr.sh}
  if(ovF.width!==w||ovF.height!==h)[ovF,ovB].forEach(c=>{c.width=w;c.height=h});
  const fp=wv*U/w;
  postMat.uniforms.uView.value.set(camL*U,wv*U);postMat.uniforms.uQ.value=Q.v/100;postMat.uniforms.uFp.value=fp;
  globeMat.uniforms.uPx.value=wv/w;
  Q.k=h/DH;Q.w=w;Q.h=h;Q.ms=tr.ms;Q.sh=tr.sh;
}
let rafPending=false;
qEl.addEventListener('input',()=>{Q.v=+qEl.value;qv.textContent=Q.v;if(!rafPending){rafPending=true;requestAnimationFrame(()=>{rafPending=false;layout()})}});
addEventListener('resize',layout);
const spdEl=document.getElementById('spd'),spdv=document.getElementById('spdv'),gaitEl=document.getElementById('gait');
const gaitName=v=>v<.7?'Stroll':v<1.45?'Walk':v<1.8?'Brisk walk':v<2.6?'Jog':v<3.9?'Run':'Sprint';
function applySpeed(x){const v=paceV(x);setSpeed(v);spdv.textContent=(v/1.05).toFixed(1)+'×';gaitEl.textContent=gaitName(v)}
spdEl.addEventListener('input',()=>applySpeed(+spdEl.value));
addEventListener('keydown',e=>{if(e.key==='h'||e.key==='H')document.getElementById('ui').classList.toggle('off')});
const params=new URLSearchParams(location.search);
if(params.has('q')){Q.v=+params.get('q');qEl.value=Q.v;qv.textContent=Q.v}
if(params.has('spd'))spdEl.value=params.get('spd');applySpeed(+spdEl.value);
layout();

/* ======================= LOOP ======================= */
const fixedT=params.has('t')?+params.get('t'):null;let T0=performance.now(),fpsN=0,fpsT=T0;
const clear=(rt)=>{renderer.setRenderTarget(rt);renderer.setClearColor(0x000000,0);renderer.clear()};
function frame(now){
  const t=fixedT!==null?fixedT:(now-T0)/1000,dt=clamp(t-TIME.t,0,.1);TIME.t=t;
  if(fixedT!==null){TIME.ph=t/WALK.T;TIME.rot=-t*WALK.v*SC*Math.SQRT1_2/CIRC.R}else{TIME.ph+=dt/WALK.T;TIME.rot-=dt*WALK.v*SC*Math.SQRT1_2/CIRC.R}
  globeMat.uniforms.uRot.value=TIME.rot;
  const {ph,H}=pose(TIME.ph);
                    // surface now slides to the right, opposite the leftward walk
  fgScene.updateMatrixWorld(true);
  clouds.forEach(c=>c.position.y=c.userData.y0+Math.sin(t*.35+c.userData.ph)*.035);
  /* foot + body shadows on the ground */
  const proj=(o,gy)=>{o.getWorldPosition(v3);v3.y=gy;v3.project(fgCam);return [camL+(v3.x+1)/2*(camR-camL),(v3.y+1)/2*WH]};
  legs.forEach((L,i)=>{const p=proj(L.an,GY);const lift=Math.max(0,L.an.getWorldPosition(v3).y-GY-LEG.ankle);shadows[i].position.set(p[0]+.14,p[1]-.02,0);
    shadows[i].scale.set(.62*(1-lift*.8),.14*(1-lift*.8),1);shadows[i].material.opacity=.62*(1-lift*1.8)});
  shadows[2].position.set(GX+.62,GY-.1,0);shadows[2].scale.set(1.9,.34,1);shadows[2].material.opacity=.38;
  poseHand(t,ph,H-hMean);
  drawStrings(t,Q.k,Q.v>=22);
  clear(bgRT);renderer.render(bgScene,bgCam);
  clear(fgRT);renderer.render(fgScene,fgCam);
  clear(hdRT);renderer.render(handScene,bgCam);
  postMat.uniforms.uBG.value=bgRT.texture;postMat.uniforms.uFG.value=fgRT.texture;postMat.uniforms.uHand.value=hdRT.texture;postMat.uniforms.uT.value=t;
  renderer.setRenderTarget(null);renderer.render(postScene,postCam);
  fpsN++;if(now-fpsT>500){const fps=fpsN*1000/(now-fpsT);fpsN=0;fpsT=now;
    info.textContent=`${Q.w}×${Q.h} · ${Q.ms?Q.ms+'× MSAA':'no MSAA'} · shadows ${Q.sh} · ${fps.toFixed(0)} fps`}

  if(fixedT===null)requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
})();
}
