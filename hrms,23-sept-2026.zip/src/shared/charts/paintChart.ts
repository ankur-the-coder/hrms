import { radialOffset, distinctLineColor } from '../chartGeometry';
import {
  type ChartDatum, type ChartKind, type StackedSeries, type CalendarDay, type SankeyLink,
  type GanttTask, type ScatterPoint, type StreamEvent, type Theme, type DrawCtx, type Ctx,
  TOROID_GLOSS, PALETTE, activePalette, themeColors, font, shade, rgba, withAlpha, luma,
  easeOut, easeInOut, lerp, clamp01, parseColor, fmtNum, fitText, approxW,
  xyLayout, seriesDepth, circGeom, leaderLabel, funnelLabel, funnelGeom, drawLeaders, drawAxes,
  drawXLabels, planX, planXFit, radialGeom, radialClassicGeom,
  sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad,
  pipeShade, streamGeom, STREAM_SALARY_10Y, type StreamGeom, type Hover, NO_HOVER,
  ZX, ZY, DZ, DZY, K, SIN45, TILT,
  type Orbit3D, ORBIT_REST, makeProj, setShadow, noShadow, fitCtx, measureW, type SkFlow,
} from './core';

export function paintChart(ctx: Ctx, kind: ChartKind, d: DrawCtx) {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  if (d.bg) { ctx.fillStyle = d.bg; ctx.fillRect(0, 0, W, H); } else ctx.clearRect(0, 0, W, H);
  // OPTIMIZATION + STALE-TILE FIX: `radialbar` renders through its own
  // dedicated Three.js overlay (ThreeReferenceRadialBar) — this 2D canvas
  // is hidden (opacity 0) whenever it's active. With no explicit guard
  // here, kind==='radialbar' used to fall through EVERY unmatched `if`
  // block all the way to the generic pie/donut painter at the bottom of
  // this function, which then wastefully redrew a whole pie chart from
  // the radial-bar dataset on every hidden frame for nothing. Bailing out
  // immediately (after the clear above, so the hidden canvas is at least
  // blank rather than a stale pie) removes that wasted CPU/GPU work.
  if (kind === 'radialbar') return;
  if (!data.length && !(multi && cats.length) && kind !== 'calendarpie' && kind !== 'sankey' && kind !== 'gantt' && kind !== 'scatter' && kind !== 'stream') return;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;

  /* ============ BAR ============ */
  if (kind === 'bar') {
    const labels = multi ? cats : data.map((x) => x.label);
    const max = multi
      ? Math.max(...cats.map((_, c) => series.reduce((s, sr) => s + (sr.values[c] || 0), 0)), 1)
      : Math.max(...data.map((x) => x.value), 1);
    const L = xyLayout('bar', W, H, m, labels, 1, max, !!d.yLabel, full);
    const { pad, ch, step, ox, oy } = L;
    drawAxes(ctx, W, H, pad, max, t, ox, oy);
    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2 + ox / 2, pad.t + ch, t, W);

    labels.forEach((_, ci) => {
      const bw = Math.min(44, step * 0.52);
      const x = pad.l + step * ci + (step - bw) / 2;
      const segs = multi
        ? series.map((sr, si) => ({ v: sr.values[ci] || 0, col: sColors[si], on: !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === si) }))
        : [{ v: data[ci].value, col: colors[ci], on: hov.idx === ci }];
      // HTML combo-bar hover: hovered group stays full, every other
      // group eases to 0.38 opacity (Leave Analytics chart.html).
      const groupOn = multi
        ? !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1))
        : hov.idx === ci;
      const anyHov = multi ? hov.seg !== null : hov.idx !== null;
      ctx.save();
      ctx.globalAlpha = anyHov ? (groupOn ? 1 : 1 - 0.62 * hov.amt) : 1;
      let acc = 0;
      segs.forEach((sg, si) => {
        if (sg.v <= 0) return;
        const h = (sg.v / max) * ch * p;
        const yTop = pad.t + ch - ((acc / max) * ch * p) - h;
        const col = sg.on ? shade(sg.col, 1 + 0.16 * hov.amt) : sg.col;
        if (m > 0.02) {
          ctx.fillStyle = shade(sg.col, 0.7 * (sg.on ? 1 + 0.1 * hov.amt : 1));
          ctx.beginPath(); ctx.moveTo(x + bw, yTop); ctx.lineTo(x + bw + ox, yTop - oy);
          ctx.lineTo(x + bw + ox, yTop - oy + h); ctx.lineTo(x + bw, yTop + h); ctx.closePath(); ctx.fill();
          const isTop = si === segs.length - 1 || segs.slice(si + 1).every((z) => z.v <= 0);
          if (isTop) {
            ctx.fillStyle = shade(sg.col, 1.22);
            ctx.beginPath(); ctx.moveTo(x, yTop); ctx.lineTo(x + ox, yTop - oy);
            ctx.lineTo(x + bw + ox, yTop - oy); ctx.lineTo(x + bw, yTop); ctx.closePath(); ctx.fill();
          }
          ctx.fillStyle = col;
          ctx.fillRect(x, yTop, bw, h);
        } else {
          ctx.fillStyle = col;
          ctx.beginPath(); ctx.roundRect(x, yTop, bw, Math.max(1, h - (multi ? 1 : 0)), multi ? 2 : [6, 6, 0, 0]); ctx.fill();
        }
        acc += sg.v;
      });
      ctx.restore();
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ LINE & AREA (2D + true 3D) ============ */
  if (kind === 'line' || kind === 'area') {
    const list: { name: string; color: string; values: number[] }[] = multi
      ? series.map((s, i) => ({ name: s.name, color: sColors[i], values: s.values }))
      : [{ name: '', color: colors[0], values: data.map((x) => x.value) }];
    const nD = list.length;
    // smaller series sit in FRONT, larger ones recede — nothing gets hidden
    const depth = multi ? seriesDepth(series) : [0];
    const zx = ZX * m, zy = ZY * m, dz = DZ * m, dzy = DZY * m;
    const labels = multi ? cats : data.map((x) => x.label);
    const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
    const L = xyLayout(kind, W, H, m, labels, nD, max, !!d.yLabel, full);
    const { pad, ch, step, ox, oy } = L;
    drawAxes(ctx, W, H, pad, max, t, ox, oy);
    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);

    const isArea = kind === 'area';
    const order = list.map((_, i) => i).sort((a, b) => depth[b] - depth[a]); // back → front
    for (const si of order) {
      const sr = list[si];
      const offX = zx * depth[si], offY = zy * depth[si];
      const baseY = pad.t + ch - offY;
      const pts = sr.values.map((v, i) => ({
        x: pad.l + step * i + step / 2 + offX,
        y: pad.t + ch - (v / max) * ch * p - offY,
      }));
      if (!pts.length) continue;

      // Smooth freehand curve through the points (Catmull-Rom → Bézier), the
      // SAME path builder used in 2D and 3D so the morph never kinks.
      const curve = (offX = 0, offY = 0) => {
        ctx.moveTo(pts[0].x + offX, pts[0].y + offY);
        if (pts.length === 2) { ctx.lineTo(pts[1].x + offX, pts[1].y + offY); return; }
        for (let i = 0; i < pts.length - 1; i++) {
          const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
          ctx.bezierCurveTo(
            p1.x + offX + (p2.x - p0.x) / 6, p1.y + offY + (p2.y - p0.y) / 6,
            p2.x + offX - (p3.x - p1.x) / 6, p2.y + offY - (p3.y - p1.y) / 6, p2.x + offX, p2.y + offY);
        }
      };
      // Reversed curve back along the same points — closes area bands and
      // ribbon walls without seams.
      const curveBack = (offX = 0, offY = 0) => {
        if (pts.length === 2) { ctx.lineTo(pts[0].x + offX, pts[0].y + offY); return; }
        for (let i = pts.length - 1; i > 0; i--) {
          const p0 = pts[Math.min(pts.length - 1, i + 1)], p1 = pts[i], p2 = pts[i - 1], p3 = pts[Math.max(0, i - 2)];
          ctx.bezierCurveTo(
            p1.x + offX + (p2.x - p0.x) / 6, p1.y + offY + (p2.y - p0.y) / 6,
            p2.x + offX - (p3.x - p1.x) / 6, p2.y + offY - (p3.y - p1.y) / 6, p2.x + offX, p2.y + offY);
        }
      };
      if (m > 0.02) {
        // TRUE 3D for BOTH line and area: the series floats as a smooth
        // ribbon above a soft floor shadow; the area adds a translucent
        // curtain down to the floor so depth reads at a glance.
        const lift = 10 * m + depth[si] * 3 * m;
        // floor shadow — same freehand silhouette, blurred onto the floor
        ctx.save();
        setShadow(ctx, 0, 6 * m + 3, 10, rgba(t.ink, 0.20 * m));
        ctx.fillStyle = rgba(t.ink, 0.10 * m);
        ctx.beginPath();
        curve(dz, lift - dzy + 6 * m);
        if (isArea) { ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy + 6 * m); ctx.lineTo(pts[0].x + dz, baseY - dzy + 6 * m); }
        ctx.closePath(); ctx.fill();
        ctx.restore();
        // back wall: the freehand curve swept through the depth vector —
        // front curve out, back curve reversed: a seamless smooth band
        ctx.fillStyle = shade(sr.color, isArea ? 0.62 : 0.78);
        ctx.beginPath();
        curve(0, 0);
        ctx.lineTo(pts[pts.length - 1].x + dz, pts[pts.length - 1].y - dzy);
        curveBack(dz, -dzy);
        ctx.closePath(); ctx.fill();
        if (isArea) {
          // back curtain (floor to curve, at depth) then front curtain
          ctx.fillStyle = shade(sr.color, 0.55);
          ctx.beginPath();
          curve(dz, -dzy);
          ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy);
          ctx.lineTo(pts[0].x + dz, baseY - dzy);
          ctx.closePath(); ctx.fill();
          const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ch);
          grad.addColorStop(0, withAlpha(sr.color, multi ? '66' : '7a'));
          grad.addColorStop(1, withAlpha(sr.color, '14'));
          ctx.fillStyle = grad;
          ctx.beginPath();
          curve(0, 0);
          ctx.lineTo(pts[pts.length - 1].x, baseY); ctx.lineTo(pts[0].x, baseY);
          ctx.closePath(); ctx.fill();
        } else {
          // line 3D: translucent floor curtain in the brand color
          ctx.fillStyle = withAlpha(sr.color, '26');
          ctx.beginPath();
          curve(dz, -dzy);
          ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy);
          ctx.lineTo(pts[0].x + dz, baseY - dzy);
          ctx.closePath(); ctx.fill();
        }
        // glowing freehand crest on top
        ctx.save();
        setShadow(ctx, 0, 0, 6 * m, rgba(sr.color, 0.55 * m));
        ctx.strokeStyle = shade(sr.color, 1.18); ctx.lineWidth = isArea ? 2.2 : 2.8; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        ctx.beginPath(); curve(0, 0); ctx.stroke();
        ctx.restore();
        // end cap seals the ribbon at the last point
        ctx.fillStyle = shade(sr.color, 0.6);
        ctx.beginPath();
        ctx.moveTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
        ctx.lineTo(pts[pts.length - 1].x + dz, pts[pts.length - 1].y - dzy);
        ctx.lineTo(pts[pts.length - 1].x + dz, (isArea ? baseY : pts[pts.length - 1].y + 2) - dzy);
        ctx.lineTo(pts[pts.length - 1].x, isArea ? baseY : pts[pts.length - 1].y + 2);
        ctx.closePath(); ctx.fill();
        // markers float on the crest
        const dense = step < 14;
        pts.forEach((pt, i) => {
          const on = multi ? (hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === si) : hov.idx === i;
          if (dense && !on) return;
          ctx.save();
          setShadow(ctx, 0, 2, 4, rgba(t.ink, 0.3 * m));
          ctx.fillStyle = on ? shade(sr.color, 1 + 0.2 * hov.amt) : shade(sr.color, 1.1);
          ctx.beginPath(); ctx.arc(pt.x, pt.y, (step < 26 ? 3 : 4) + (on ? 2.5 * hov.amt : 0), 0, Math.PI * 2); ctx.fill();
          ctx.restore();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
        });
      } else {
        if (isArea) {
          ctx.beginPath(); curve();
          ctx.lineTo(pts[pts.length - 1].x, baseY); ctx.lineTo(pts[0].x, baseY); ctx.closePath();
          const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ch);
          grad.addColorStop(0, withAlpha(sr.color, multi ? '3d' : '59'));
          grad.addColorStop(1, withAlpha(sr.color, '08'));
          ctx.fillStyle = grad; ctx.fill();
          ctx.strokeStyle = sr.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
          ctx.beginPath(); curve(); ctx.stroke();
        } else {
          ctx.strokeStyle = sr.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
          ctx.beginPath(); curve(); ctx.stroke();
        }
        // markers thin out automatically when points get dense
        const dense = step < 14;
        pts.forEach((pt, i) => {
          const on = multi ? (hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === si) : hov.idx === i;
          if (dense && !on) return;
          ctx.fillStyle = on ? shade(sr.color, 1 + 0.2 * hov.amt) : sr.color;
          ctx.beginPath(); ctx.arc(pt.x, pt.y, (step < 26 ? 3 : 4) + (on ? 2.5 * hov.amt : 0), 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
        });
      }
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ RADAR (2D + TRUE 3D: distance-from-centre at every morph step) ============
     A radar chart ALWAYS encodes value as distance from the centre — in 2D
     and in 3D. The 3D here is the SAME flat polygon, continuously tilted
     (squash), extruded (slab walls under the filled polygon) and shaded,
     so the 2D→3D morph never changes what the values mean. */
  if (kind === 'radar') {
    /* ============ RADAR — sticks + thread, no fill volume ============
       The chart shows ONLY vertical sticks (one per axis, height =
       value) and the thread polygon connecting the stick tips. There is
       deliberately NO filled area and NO extruded slab — in 2D or 3D.
       2D→3D is a pure camera tilt: the SAME vertex math (angle i, radius
       v/max·R) is projected through an oblique view whose pitch grows
       with m, plus stick verticals so height reads in 3D. Vertices
       never move off their data radius at any morph step. */
    const labels = multi ? cats : data.map((x) => x.label);
    const longest = Math.max(0, ...labels.map((l) => approxW(l)));
    const margin = full ? Math.min(W * 0.4, longest + 24) : 44;
    const cx = W / 2, cy = H / 2 + 6;
    const squash = 1 - 0.52 * m;
    const Rflat = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30) / Math.max(0.45, squash)));
    const depth = Math.min(46, Math.max(12, Rflat * 0.24)) * m;
    const R = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30 - depth) / Math.max(0.45, squash)));
    const n = Math.max(1, labels.length);
    const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
    const ang = (i: number) => -Math.PI / 2 + (i * Math.PI * 2) / n;
    // ONE projection for every element at every morph step: disc point +
    // vertical stick height h (in px). 2D: h collapses (sticks are dots);
    // 3D: h lifts tips toward the viewer-tilted plane. The disc itself is
    // identical in 2D and 3D, so 2D→3D never re-plots the data.
    const P = (a: number, r: number, h = 0) => ({
      x: cx + Math.cos(a) * r,
      y: cy + Math.sin(a) * r * squash - h,
    });

    // ---- floor shadow of the web (3D only) ----
    if (m > 0.02) {
      ctx.save();
      setShadow(ctx, 0, 9 * m + 2, 18, rgba(t.ink, 0.20 * m));
      ctx.fillStyle = rgba(t.ink, 0.08 * m);
      ctx.beginPath();
      for (let i = 0; i <= n; i++) {
        const q = P(ang(i % n), R);
        i === 0 ? ctx.moveTo(q.x, q.y + depth * 0.4) : ctx.lineTo(q.x, q.y + depth * 0.4);
      }
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    // ---- web rings (tilted ellipses in 3D) ----
    for (let ring = 1; ring <= 3; ring++) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i <= n; i++) {
        const q = P(ang(i % n), (R * ring) / 3);
        i === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y);
      }
      ctx.stroke();
    }
    ctx.font = font(t, 600, 10.5);
    labels.forEach((l, i) => {
      const aa = ang(i);
      const q = P(aa, R);
      ctx.strokeStyle = t.grid;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(q.x, q.y); ctx.stroke();
      ctx.fillStyle = t.axis;
      ctx.textAlign = Math.abs(Math.cos(aa)) < 0.3 ? 'center' : Math.cos(aa) > 0 ? 'left' : 'right';
      const lx = cx + Math.cos(aa) * (R + 12);
      const avail = Math.abs(Math.cos(aa)) < 0.3 ? W - 8 : Math.cos(aa) > 0 ? W - lx - 4 : lx - 4;
      ctx.fillText(full ? l : fitCtx(ctx, l, Math.max(30, avail)), lx, cy + Math.sin(aa) * (R + 12) * squash + 3);
    });
    const polys = multi
      ? series.map((s, i) => ({ color: sColors[i], values: s.values }))
      : [{ color: colors[0], values: data.map((x) => x.value) }];
    // Stick height: value-proportional lift in 3D only (0 in 2D), so the
    // tips rise off the disc while the disc footprint stays data-true.
    const stickH = (pi: number, i: number) => {
      const v = (polys[pi].values[i % n] || 0) / max;
      return v * depth * p;
    };
    const vert = (pi: number, i: number) => {
      const v = (polys[pi].values[i % n] || 0) / max;
      return P(ang(i % n), v * R * p, stickH(pi, i));
    };
    const foot = (pi: number, i: number) => {
      const v = (polys[pi].values[i % n] || 0) / max;
      return P(ang(i % n), v * R * p, 0);
    };
    const traceThread = (pi: number) => {
      for (let i = 0; i <= n; i++) {
        const q = vert(pi, i);
        i === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y);
      }
      ctx.closePath();
    };
    // ---- sticks: shaded verticals from disc foot to tip (3D), dots (2D) ----
    polys.forEach((poly, pi) => {
      const onS = multi && hov.seg?.s === pi;
      const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= sDim;
      for (let i = 0; i < n; i++) {
        const f = foot(pi, i), v = vert(pi, i);
        if (m > 0.02 && v.y < f.y - 0.5) {
          // stick: dark foot → bright tip, width tapers with light
          const sg = ctx.createLinearGradient(0, f.y, 0, v.y);
          sg.addColorStop(0, shade(poly.color, 0.55));
          sg.addColorStop(1, onS ? shade(poly.color, 1.2 + 0.1 * hov.amt) : shade(poly.color, 1.05));
          ctx.strokeStyle = sg;
          ctx.lineWidth = 3;
          ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(v.x, v.y); ctx.stroke();
          ctx.lineCap = 'butt';
          // foot dot on the disc
          ctx.fillStyle = shade(poly.color, 0.8);
          ctx.beginPath(); ctx.arc(f.x, f.y, 2.2, 0, Math.PI * 2); ctx.fill();
        }
      }
      ctx.restore();
      void pi;
    });
    // ---- thread: the connecting polygon through the stick tips ----
    polys.forEach((poly, pi) => {
      const onS = multi && hov.seg?.s === pi;
      const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= sDim;
      ctx.beginPath();
      traceThread(pi);
      ctx.strokeStyle = onS ? shade(poly.color, 1.15) : poly.color;
      ctx.lineWidth = (onS ? 2.6 : 2) + m * 0.6;
      ctx.lineJoin = 'round';
      if (m > 0.02) {
        ctx.save();
        ctx.shadowColor = rgba(poly.color, 0.45 * m);
        ctx.shadowBlur = 6;
        ctx.stroke();
        ctx.restore();
      } else {
        ctx.stroke();
      }
      ctx.restore();
    });
    // ---- tip knots: glossy spheres on every stick tip ----
    polys.forEach((poly, pi) => {
      const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= sDim;
      for (let i = 0; i < n; i++) {
        const q = vert(pi, i);
        const on = !multi && hov.idx === i;
        const rr = 3.4 + m * 1.2 + (on ? 2 * hov.amt : 0);
        const kg = ctx.createRadialGradient(q.x - rr * 0.3, q.y - rr * 0.35, rr * 0.1, q.x, q.y, rr);
        kg.addColorStop(0, '#ffffff');
        kg.addColorStop(0.4, shade(poly.color, 1.2));
        kg.addColorStop(1, shade(poly.color, 0.7));
        ctx.fillStyle = kg;
        ctx.beginPath(); ctx.arc(q.x, q.y, rr, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
      }
      ctx.restore();
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ POLAR (2D ⇄ 3D) ============ */
  if (kind === 'polar') {
    const g = circGeom(W, H, m, data, full);
    const cx = g.cx, cy = g.cy, R = g.R;
    const squash = 1 - 0.44 * m;
    const depth = 16 * m;
    const max = Math.max(...data.map((x) => x.value), 1);

    if (m > 0.05) {
      ctx.save();
      setShadow(ctx, 0, 8, 20, rgba(t.ink, 0.22 * m));
      ctx.fillStyle = t.surface || '#e4e7e0';
      ctx.beginPath();
      ctx.ellipse(cx, cy + depth, R, R * squash, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    for (let ring = 1; ring <= 3; ring++) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(cx, cy, R * (ring / 3), R * (ring / 3) * squash, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    const n = Math.max(1, data.length);
    const pieces = data.map((x, i) => {
      const a0 = -Math.PI / 2 + (i * Math.PI * 2) / n;
      const a1 = a0 + (Math.PI * 2) / n;
      const offset = radialOffset((a0 + a1) / 2, hov.idx === i ? 14 * hov.amt : 0, squash);
      return { i, a0, a1, r: Math.max(2, (x.value / max) * R * p), dx: offset.x, dy: offset.y };
    });
    // Closed opaque prisms. All faces move together in the chart plane, never upward in Z.
    const faces: { y: number; draw: () => void }[] = [];
    pieces.forEach(({ i, a0, a1, r, dx, dy }) => {
      if (m <= 0.005) return;
      const x = (a: number) => cx + dx + Math.cos(a) * r;
      const y = (a: number) => cy + dy + Math.sin(a) * r * squash;
      [a0, a1].forEach(edge => faces.push({
        y: cy + dy + Math.sin(edge) * r * squash / 2,
        draw: () => {
          ctx.fillStyle = shade(colors[i], 0.72);
          ctx.beginPath(); ctx.moveTo(cx + dx, cy + dy); ctx.lineTo(x(edge), y(edge));
          ctx.lineTo(x(edge), y(edge) + depth); ctx.lineTo(cx + dx, cy + dy + depth);
          ctx.closePath(); ctx.fill();
        },
      }));
      const count = Math.max(3, Math.ceil((a1 - a0) * r / 6));
      for (let step = 0; step < count; step++) {
        const b0 = a0 + (a1 - a0) * step / count;
        const b1 = a0 + (a1 - a0) * (step + 1) / count;
        const mid = (b0 + b1) / 2;
        if (Math.sin(mid) <= 0) continue;
        faces.push({ y: y(mid), draw: () => {
          ctx.fillStyle = shade(colors[i], 0.64 + 0.16 * Math.cos(mid));
          ctx.beginPath(); ctx.moveTo(x(b0), y(b0)); ctx.lineTo(x(b1), y(b1));
          ctx.lineTo(x(b1), y(b1) + depth); ctx.lineTo(x(b0), y(b0) + depth);
          ctx.closePath(); ctx.fill();
        } });
      }
    });
    faces.sort((a, b) => a.y - b.y).forEach(face => face.draw());
    pieces.forEach(({ i, a0, a1, r, dx, dy }) => {
      ctx.fillStyle = hov.idx === i ? shade(colors[i], 1 + 0.1 * hov.amt) : colors[i];
      ctx.beginPath(); ctx.moveTo(cx + dx, cy + dy);
      ctx.ellipse(cx + dx, cy + dy, r, r * squash, 0, a0, a1);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 0.7; ctx.stroke();
    });
    if (p > 0.95) drawLeaders(ctx, cx, cy, R, squash, data, colors, total, t, W, H, true, full);
    return;
  }

  /* ============ CALENDAR PIE — one mini pie per day (echarts calendar-pie) ============ */
  if (kind === 'calendarpie') {
    const days = d.days || [];
    const names = series.map((x) => x.name);
    if (!days.length || !names.length) return;
    const dates = days.map((x) => new Date(x.date + 'T00:00:00'));
    const first = new Date(Math.min(...dates.map((x) => x.getTime())));
    const monthStart = new Date(first.getFullYear(), first.getMonth(), 1);
    const monthEnd = new Date(first.getFullYear(), first.getMonth() + 1, 0);
    const byDay = new Map(days.map((x) => [x.date, x.values]));
    const padL = 12, padR = 12, padT = 34, padB = 10;
    const cols = 7;
    const leadBlank = (monthStart.getDay() + 6) % 7; // Monday-first grid, like the reference
    const rows = Math.ceil((leadBlank + monthEnd.getDate()) / cols);
    const cell = Math.min((W - padL - padR) / cols, (H - padT - padB) / rows);
    const gx = padL + ((W - padL - padR) - cell * cols) / 2, gy = padT + ((H - padT - padB) - cell * rows) / 2;
    const r = cell * 0.36;
    ctx.font = font(t, 700, Math.min(11, Math.max(8.5, cell * 0.16)));
    ctx.fillStyle = t.ink; ctx.textAlign = 'left';
    ctx.fillText(monthStart.toLocaleDateString('en', { month: 'long', year: 'numeric' }), padL, 18);
    ctx.font = font(t, 700, Math.min(10, Math.max(8, cell * 0.14))); ctx.fillStyle = t.axis; ctx.textAlign = 'center';
    ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].forEach((wd, i) => ctx.fillText(wd, gx + cell * i + cell / 2, gy - 6));
    // grid cells
    for (let dnum = 1; dnum <= monthEnd.getDate(); dnum++) {
      const idx = leadBlank + dnum - 1, c = idx % cols, rw = Math.floor(idx / cols);
      const x0 = gx + c * cell, y0 = gy + rw * cell;
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.rect(x0 + 0.5, y0 + 0.5, cell - 1, cell - 1); ctx.stroke();
      const iso = `${monthStart.getFullYear()}-${String(monthStart.getMonth() + 1).padStart(2, '0')}-${String(dnum).padStart(2, '0')}`;
      const vals = byDay.get(iso);
      ctx.font = font(t, 700, Math.min(10, Math.max(7.5, cell * 0.14))); ctx.fillStyle = vals ? t.ink : t.axis; ctx.textAlign = 'left';
      ctx.fillText(String(dnum), x0 + 4, y0 + Math.min(12, cell * 0.18));
      if (!vals) continue;
      const tot = vals.reduce((a2, b) => a2 + b, 0) || 1;
      const cx0 = x0 + cell / 2, cy0 = y0 + cell / 2 + cell * 0.05;
      const on = hov.seg && hov.seg.c === dnum;
      let a = -Math.PI / 2;
      vals.forEach((v, si) => {
        if (v <= 0) return;
        const a1 = a + (v / tot) * Math.PI * 2 * p;
        const hi = on && hov.seg!.s === si;
        const rr = r * (hi ? 1 + 0.1 * hov.amt : 1);
        ctx.fillStyle = hi ? shade(sColors[si], 1.12) : sColors[si];
        ctx.beginPath(); ctx.moveTo(cx0, cy0); ctx.arc(cx0, cy0, rr, a, a1); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = d.bg || t.surface || '#fff'; ctx.lineWidth = 1.2; ctx.stroke();
        // value labels inside slices when there is room
        if (cell >= 64 && v / tot >= 0.12 && p > 0.95) {
          const mid = (a + a1) / 2;
          ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
          ctx.font = font(t, 700, Math.max(7.5, Math.min(10, r * 0.28)));
          ctx.fillText(fmtNum(v), cx0 + Math.cos(mid) * rr * 0.62, cy0 + Math.sin(mid) * rr * 0.62 + 3);
        }
        a = a1;
      });
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ SANKEY — agon 2D + TRUE rotatable 3D ============ */
  /* ============ SANKEY (Classic · canvas, no Three.js) — ported from
     the agon-agent-cleaned reference build: isometric-offset 2D/3D, node
     hover only (matches the reference exactly) ============ */
  if (kind === 'sankey') {
    const links = (d.links || []).filter((l) => l.value > 0 && l.source !== l.target);
    if (!links.length) return;
    const lay = sankeyLayout(links, W, H, full ? 200 : Math.min(150, W * 0.22));
    if (!lay) return;
    const { nodes, flows, nodeW, cols } = lay;
    const maxCol = Math.max(1, cols - 1);
    const ox = 7 * m, oy = 5 * m; // 3D isometric extrusion offset

    // Hover animation model (mirrors the 3D scene's isolate behaviour):
    //  - hovering a NODE spotlights it + every ribbon touching it;
    //  - hovering a FLOW spotlights that ribbon + its source/target nodes;
    //  - everything else dims. `hov.amt` (eased 0→1 in the Chart shell)
    //    drives the emphasis so the highlight blooms instead of popping.
    const hovFlowIdx = hov.seg && hov.seg.s === -2 ? hov.seg.c : -1;
    const hovNodeIdx = hov.idx;
    const hovActive = hovNodeIdx !== null || hovFlowIdx >= 0;
    const flowEmph = (fi: number, f: SkFlow) => {
      if (!hovActive) return 0;
      if (hovFlowIdx >= 0) return fi === hovFlowIdx ? hov.amt : 0;
      return (hovNodeIdx === f.si || hovNodeIdx === f.ti) ? hov.amt : 0;
    };
    const nodeEmph = (ni: number) => {
      if (!hovActive) return 0;
      if (hovFlowIdx >= 0) {
        const f = flows[hovFlowIdx];
        return f && (ni === f.si || ni === f.ti) ? hov.amt : 0;
      }
      return ni === hovNodeIdx ? hov.amt : 0;
    };
    const glow = (col: string, e: number) => e > 0.01 && hovActive ? shade(col, 1 + 0.28 * e) : col;

    // Sequential left-to-right sweep:
    // 1. Draw nodes per column
    // 2. Flow ribbons sweep outward from left to right along their path vectors
    flows.forEach((f, fi) => {
      const src = nodes[f.si], tgt = nodes[f.ti];
      const emph = flowEmph(fi, f); // 0 … 1 eased emphasis
      const isDimmed = hovActive && emph < 0.01;
      const x0 = src.x + nodeW, x1 = tgt.x;
      const c1 = x0 + (x1 - x0) * 0.5, c2 = x1 - (x1 - x0) * 0.5;
      const yA0 = f.sy0, yA1 = f.sy1, yB0 = f.ty0, yB1 = f.ty1;

      // Sequential progress: left ribbons begin early, right ribbons follow
      const pStart = 0.12 + (src.col / maxCol) * 0.45;
      const pEnd = Math.min(1, pStart + 0.38);
      const fp = clamp01((p - pStart) / (pEnd - pStart));
      if (fp <= 0.001) return;

      // hover bloom: the emphasised ribbon brightens, thickens and lifts
      const lift = emph * 3;
      const alpha = hovActive
        ? (emph > 0.01 ? 0.45 + 0.45 * emph : 0.45 * (1 - 0.78 * hov.amt))
        : 0.45;
      const grad = ctx.createLinearGradient(x0, 0, x1, 0);
      grad.addColorStop(0, rgba(glow(src.color, emph), alpha));
      grad.addColorStop(1, rgba(glow(tgt.color, emph), alpha));

      ctx.save();
      // Sweep outward along path vectors
      if (fp < 0.999) {
        const sweepX = x0 + (x1 - x0) * fp;
        ctx.beginPath();
        ctx.rect(0, 0, sweepX, H);
        ctx.clip();
      }

      // 3D Depth Shadow ribbon underneath in 3D mode
      if (m > 0.05) {
        ctx.fillStyle = rgba(t.ink, (0.08 + 0.14 * emph) * m * (isDimmed ? (1 - 0.7 * hov.amt) : 1));
        ctx.beginPath();
        ctx.moveTo(x0, yA0 + oy - lift * 0.4);
        ctx.bezierCurveTo(c1, yA0 + oy - lift * 0.4, c2, yB0 + oy - lift * 0.4, x1, yB0 + oy - lift * 0.4);
        ctx.lineTo(x1, yB1 + oy - lift * 0.4);
        ctx.bezierCurveTo(c2, yB1 + oy - lift * 0.4, c1, yA1 + oy - lift * 0.4, x0, yA1 + oy - lift * 0.4);
        ctx.closePath();
        ctx.fill();
      }

      // Main flow ribbon
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(x0, yA0 - lift);
      ctx.bezierCurveTo(c1, yA0 - lift, c2, yB0 - lift, x1, yB0 - lift);
      ctx.lineTo(x1, yB1 + lift * 0.6);
      ctx.bezierCurveTo(c2, yB1 + lift * 0.6, c1, yA1 + lift * 0.6, x0, yA1 + lift * 0.6);
      ctx.closePath();
      ctx.fill();

      // Top edge highlight in 3D mode or on hover
      if (emph > 0.01 || m > 0.1) {
        ctx.strokeStyle = emph > 0.01 ? rgba('#ffffff', 0.35 + 0.65 * emph) : 'rgba(255,255,255,0.35)';
        ctx.lineWidth = emph > 0.01 ? 0.8 + 1.2 * emph : 0.8;
        ctx.beginPath();
        ctx.moveTo(x0, yA0 - lift);
        ctx.bezierCurveTo(c1, yA0 - lift, c2, yB0 - lift, x1, yB0 - lift);
        ctx.stroke();
      }

      ctx.restore();
    });

    // Draw nodes sequentially from left to right with 3D cuboid depth
    nodes.forEach((n, i) => {
      const colP = n.col / maxCol;
      const np = clamp01((p - colP * 0.22) / 0.32);
      if (np <= 0.001) return;
      const emph = nodeEmph(i); // 0 … 1 eased emphasis
      const isDimmed = hovActive && emph < 0.01;
      const col = glow(n.color, emph);
      const nh = Math.max(2, n.h * np);
      const ny = n.y + (n.h - nh) / 2;
      // hovered node widens slightly; dimmed nodes fade
      const xW = nodeW + emph * 4;
      const xOff = emph * 2;
      if (isDimmed) ctx.globalAlpha = 1 - 0.62 * hov.amt;

      const nx = n.x - xOff;

      // 3D Cuboid extrusion in 3D mode
      if (m > 0.05) {
        // Top cap
        ctx.fillStyle = shade(col, 1.28);
        ctx.beginPath();
        ctx.moveTo(nx, ny);
        ctx.lineTo(nx + ox, ny - oy);
        ctx.lineTo(nx + xW + ox, ny - oy);
        ctx.lineTo(nx + xW, ny);
        ctx.closePath();
        ctx.fill();

        // Right side shadow face
        ctx.fillStyle = shade(col, 0.72);
        ctx.beginPath();
        ctx.moveTo(nx + xW, ny);
        ctx.lineTo(nx + xW + ox, ny - oy);
        ctx.lineTo(nx + xW + ox, ny + nh - oy);
        ctx.lineTo(nx + xW, ny + nh);
        ctx.closePath();
        ctx.fill();
      }

      // Front node face
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.roundRect(nx, ny, xW, nh, m > 0.05 ? 0 : 3);
      ctx.fill();

      // Hover glow border — eased width/alpha via emph
      if (emph > 0.01) {
        ctx.strokeStyle = rgba('#ffffff', 0.45 + 0.55 * emph);
        ctx.lineWidth = 1 + 1.4 * emph;
        ctx.stroke();
      }
      if (isDimmed) ctx.globalAlpha = 1;

      // Labels appear as node materializes
      if (np > 0.65) {
        const lx = n.x + nodeW + 8 + (m > 0.05 ? ox : 0);
        ctx.textAlign = 'left';
        const avail = n.col < lay.cols - 1 ? (lay.colX[n.col + 1] ?? W) - lx - 10 : W - lx - 6;
        const one = `${n.name} · ${fmtNum(n.value)}`;
        ctx.font = font(t, 600 + Math.round(emph * 100), 11);
        const labelCol = emph > 0.01 ? t.ink : shade(t.ink, 0.9);
        if (full || measureW(ctx, one) <= avail) {
          ctx.fillStyle = labelCol;
          ctx.fillText(one, lx, n.y + n.h / 2 + 3.5);
        } else {
          ctx.fillStyle = labelCol;
          ctx.fillText(fitCtx(ctx, n.name, Math.max(30, avail)), lx, n.y + n.h / 2 - 2);
          ctx.font = font(t, 600, 9.5);
          ctx.fillStyle = t.axis;
          ctx.fillText(fmtNum(n.value), lx, n.y + n.h / 2 + 9);
        }
      }
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ RADIAL BARS CIRCULAR (MUI RadialBarChart · canvas) ============
     Faithful to https://mui.com/x/react-charts/radial-bars/ + reference shot:
     - rotationAxis: band scale — one angular lane per category, starting at
       12 o'clock, clockwise, categoryGapRatio 0.3 between lanes.
     - radiusAxis: linear scale — bars grow ALONG THE RADIUS from a shared
       inner baseline (layout='vertical'), with tick rings + value labels.
     - ChartsRadialGrid: faint concentric rings + radial spokes, drawn UNDER
       the bars; outer rotation-axis ring carries the category labels
       (rotated tangent, exactly like MUI) — NO leader arrows.
     - Multi-series: bars subdivide each lane (barGapRatio 0.1); single
       series: one flat bar per lane (each lane keeps its family colour).
     - Hover: the bar brightens + lifts with a drop shadow (MUI highlight);
       the axis tooltip text mirrors on the card as usual.
     2D⇄3D morph: the SAME polar layout on a tilted disc — vertical glass
     walls + lit top caps rise with m, grid/labels stay glued to the disc. */
  if (kind === 'radialbars') {
    /* ============ RADIAL BARS CIRCULAR — PREMIUM 2D ============
       The 2D version of the 3D radial bar chart (replaces the Three.js
       port): the SAME reference language rendered on canvas — arc-wedge
       bars on a (optionally tilted) disc, dashed scale rings with value
       labels, a red dashed AVERAGE ring + tag, prior-period red arc
       markers on every wedge, up/down delta arrows around the perimeter,
       tangent category labels and a glossy centre hub. Colours use the
       premium glossy family (TOROID_GLOSS) with crown→core→deep shading —
       the same material language as the rest of the chart family. The
       geometry contract shared with the hit test (labBand / plotMax / rIn
       / lane / catGap / radOf / squash) is unchanged, and the 2D⇄3D morph
       still extrudes the wedges into lit caps on deep walls. */
    const n = Math.max(1, multi ? cats.length || data.length : data.length);
    const squash = 1 - 0.5 * m; // 1 → 0.5: tilted-disc language, eased with m
    const FS = full ? 12 : W >= 760 ? 11 : 10;
    // Rotation-axis labels ring the OUTSIDE: reserve a label band by
    // measuring the longest category on the live/scratch context.
    ctx.font = font(t, 600, FS);
    const nameList: string[] = multi ? cats : data.map((x) => x.label);
    const longest = Math.max(0, ...nameList.map((l) => measureW(ctx, l)));
    const labBand = Math.min(W * 0.24, Math.max(34, longest * 0.62 + 26));
    const plotMax = Math.max(60, Math.min((W - labBand * 2) / 2 - 6, (H - 56) / 2 / Math.max(0.5, squash) - 6));
    const cx = W / 2, cy = H / 2 + 2;
    const rIn = Math.max(22, plotMax * 0.34); // radiusAxis baseline (shared inner ring)
    const A0 = -Math.PI / 2; // 12 o'clock
    const lane = (Math.PI * 2) / n;
    const catGap = lane * 0.30; // categoryGapRatio 0.3
    const nS = multi ? Math.max(1, series.length) : 1;
    const barGap = nS > 1 ? (lane - catGap) * 0.10 : 0; // barGapRatio 0.1
    const barW = nS > 1 ? (lane - catGap - barGap * (nS - 1)) / nS : lane - catGap;
    const sMax = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
    const radOf = (v: number) => rIn + ((Math.max(0, v) / sMax) * (plotMax - rIn)) * p;
    const ell = (r: number, a: number, y0 = cy): [number, number] =>
      [cx + Math.cos(a) * r, y0 + Math.sin(a) * r * squash];
    const wallHOf = (rO: number) => (m > 0.05 ? Math.min(44, Math.max(12, (rO - rIn) * 0.5)) * m : 0);
    const hasPrior = !multi && data.some((x) => x.prior != null && Number.isFinite(x.prior));
    const avgVal = multi ? 0 : data.reduce((s, x) => s + x.value, 0) / Math.max(1, data.length);

    // ---- dashed scale rings + faint spokes + value labels (reference grid) ----
    {
      const NT = 5;
      ctx.save();
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      for (let gi = 1; gi <= NT; gi++) {
        const gr = rIn + ((plotMax - rIn) * gi) / NT;
        ctx.beginPath();
        ctx.ellipse(cx, cy, gr, Math.max(1, gr * squash), 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.setLineDash([]);
      const nSp = Math.min(n, 48);
      ctx.globalAlpha *= 0.4;
      for (let si2 = 0; si2 < nSp; si2++) {
        const aa = A0 + (si2 * Math.PI * 2) / nSp;
        const [x0, y0] = ell(rIn, aa), [x1, y1] = ell(plotMax, aa);
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      }
      ctx.restore();
      // radiusAxis tick labels (value scale, parked near 12 o'clock)
      ctx.font = font(t, 700, full ? 10 : 9);
      ctx.fillStyle = t.axis;
      ctx.textAlign = 'left';
      for (let gi = 1; gi <= NT; gi++) {
        const gr = rIn + ((plotMax - rIn) * gi) / NT;
        const [tx, ty] = ell(gr, A0 - 0.045);
        ctx.fillText(fmtNum(Math.round((sMax * gi) / NT)), tx + 4, ty + 3);
      }
      ctx.textAlign = 'left';
    }

    // ---- soft floor wash under the disc (3D only) ----
    if (m > 0.05) {
      ctx.save();
      ctx.fillStyle = rgba(t.ink, 0.08 * m);
      ctx.beginPath();
      ctx.ellipse(cx, cy + 4 + 9 * m, plotMax, plotMax * squash, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // ---- jobs: one bar per (lane × series), painted back-to-front ----
    interface RBCJob { i: number; si: number; aS: number; aE: number; rO: number; col: string; on: boolean; mid: number }
    const jobs: RBCJob[] = [];
    const orderRB = Array.from({ length: n }, (_, i) => i).sort((a, b) => {
      const ma = A0 + a * lane + lane / 2, mb = A0 + b * lane + lane / 2;
      return Math.sin(ma) - Math.sin(mb); // far (top) first
    });
    orderRB.forEach((i) => {
      const laneStart = A0 + i * lane + catGap / 2;
      if (!multi) {
        const rO = radOf(data[i] ? data[i].value : 0);
        jobs.push({ i, si: 0, aS: laneStart, aE: laneStart + barW, rO, col: colors[i], on: hov.idx === i, mid: laneStart + barW / 2 });
      } else {
        series.forEach((sr, si2) => {
          const v = sr.values[i] || 0;
          const aS = laneStart + si2 * (barW + barGap);
          jobs.push({
            i, si: si2, aS, aE: aS + barW, rO: v > 0 || p >= 0.99 ? radOf(v) : rIn + 0.5,
            col: sColors[si2], on: !!(hov.seg && hov.seg.c === i && hov.seg.s === si2), mid: aS + barW / 2,
          });
        });
      }
    });

    jobs.forEach((j) => {
      const col = j.on ? shade(j.col, 1 + 0.18 * hov.amt) : j.col;
      // hover swell: the wedge grows a few px OUTWARD in place (never lifts)
      const rO = j.rO + (j.on ? 3 * hov.amt : 0);
      if (rO - rIn < 0.75) return;
      const datum = !multi ? data[j.i] : undefined;
      const priorR = datum && datum.prior != null && Number.isFinite(datum.prior)
        ? Math.min(plotMax, radOf(datum.prior as number)) : NaN;
      if (m <= 0.05) {
        // 2D premium wedge: crown→core→deep gloss across the disc, white
        // rim sheen, hairline partings, soft drop shadow on hover.
        ctx.save();
        if (j.on && hov.amt > 0.01) setShadow(ctx, 0, 3 * hov.amt, 12 * hov.amt, rgba(t.ink, 0.34 * hov.amt));
        const gW = ctx.createLinearGradient(0, cy - rO * squash, 0, cy + rO * squash);
        gW.addColorStop(0, shade(col, 1.34));
        gW.addColorStop(0.34, shade(col, 1.08));
        gW.addColorStop(0.66, col);
        gW.addColorStop(1, shade(col, 0.70));
        ctx.fillStyle = gW;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rO, rO * squash, 0, j.aS, j.aE);
        ctx.ellipse(cx, cy, rIn, rIn * squash, 0, j.aE, j.aS, true);
        ctx.closePath(); ctx.fill();
        noShadow(ctx);
        // crisp white crown along the outer rim (gloss sheen)
        ctx.strokeStyle = rgba('#ffffff', 0.65);
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rO - 0.8, (rO - 0.8) * squash, 0, j.aS + 0.012, Math.max(j.aS + 0.02, j.aE - 0.012));
        ctx.stroke();
        // hairline partings between neighbouring wedges
        ctx.strokeStyle = rgba('#ffffff', 0.5);
        ctx.lineWidth = 1;
        ([j.aS, j.aE] as const).forEach((aa) => {
          const [ix, iy] = ell(rIn, aa), [ox, oy] = ell(rO, aa);
          ctx.beginPath(); ctx.moveTo(ix, iy); ctx.lineTo(ox, oy); ctx.stroke();
        });
        // prior-period marker: red arc across the wedge at the prior radius
        if (Number.isFinite(priorR) && p > 0.6) {
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 2.4;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.ellipse(cx, cy, priorR, priorR * squash, 0, j.aS + 0.03, Math.max(j.aS + 0.04, j.aE - 0.03));
          ctx.stroke();
          ctx.lineCap = 'butt';
        }
        ctx.restore();
      } else {
        // 3D: the same wedge extruded — deep vertical walls + glossy lit cap.
        const wallH = wallHOf(rO);
        const yTop = cy - wallH;
        ctx.save();
        if (j.on && hov.amt > 0.01) setShadow(ctx, 0, 4 * hov.amt, 12 * hov.amt, rgba(t.ink, 0.28 * hov.amt));
        // outer + inner walls
        ctx.fillStyle = shade(col, 0.52);
        ctx.beginPath();
        ctx.ellipse(cx, cy, rO, rO * squash, 0, j.aS, j.aE);
        ctx.ellipse(cx, yTop, rO, rO * squash, 0, j.aE, j.aS, true);
        ctx.closePath(); ctx.fill();
        noShadow(ctx);
        ctx.fillStyle = shade(col, 0.42);
        ctx.beginPath();
        ctx.ellipse(cx, cy, rIn, rIn * squash, 0, j.aE, j.aS, true);
        ctx.ellipse(cx, yTop, rIn, rIn * squash, 0, j.aS, j.aE);
        ctx.closePath(); ctx.fill();
        // radial side edges (start/end caps of the wall)
        ([j.aS, j.aE] as const).forEach((aa) => {
          const [ox, oy] = ell(rO, aa), [ix, iy] = ell(rIn, aa);
          ctx.fillStyle = shade(col, 0.46);
          ctx.beginPath();
          ctx.moveTo(ix, iy); ctx.lineTo(ox, oy);
          ctx.lineTo(ox, oy - wallH); ctx.lineTo(ix, iy - wallH);
          ctx.closePath(); ctx.fill();
        });
        // top cap: bright crown → saturated core (premium gloss ramp)
        const capG = ctx.createLinearGradient(0, yTop - rO * squash, 0, yTop + rO * squash);
        capG.addColorStop(0, shade(col, 1.38));
        capG.addColorStop(0.4, shade(col, 1.10));
        capG.addColorStop(0.75, shade(col, 0.96));
        capG.addColorStop(1, shade(col, 0.80));
        ctx.fillStyle = capG;
        ctx.beginPath();
        ctx.ellipse(cx, yTop, rO, rO * squash, 0, j.aS, j.aE);
        ctx.ellipse(cx, yTop, rIn, rIn * squash, 0, j.aE, j.aS, true);
        ctx.closePath(); ctx.fill();
        // crest specular along the outer rim
        ctx.strokeStyle = rgba('#ffffff', 0.6 * m);
        ctx.lineWidth = Math.max(1, (rO - rIn) * 0.08);
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.ellipse(cx, yTop, rO - (rO - rIn) * 0.12, (rO - (rO - rIn) * 0.12) * squash, 0, j.aS + 0.03, Math.max(j.aS + 0.04, j.aE - 0.03));
        ctx.stroke();
        ctx.lineCap = 'butt';
        // prior-period marker rides the lit cap
        if (Number.isFinite(priorR) && p > 0.6) {
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 2.4;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.ellipse(cx, yTop, priorR, priorR * squash, 0, j.aS + 0.03, Math.max(j.aS + 0.04, j.aE - 0.03));
          ctx.stroke();
          ctx.lineCap = 'butt';
        }
        ctx.restore();
      }
    });

    // ---- perimeter delta arrows (reference increase/decrease cones) ----
    if (hasPrior && p > 0.85) {
      data.forEach((x, i) => {
        if (x.prior == null || !Number.isFinite(x.prior)) return;
        const up = x.value >= (x.prior as number);
        const mid = A0 + i * lane + lane / 2;
        const [axx, ayy] = ell(plotMax + 7, mid);
        const s = 4.6;
        ctx.save();
        ctx.fillStyle = up ? '#16a34a' : '#ef4444';
        ctx.strokeStyle = 'rgba(255,255,255,0.9)';
        ctx.lineWidth = 1;
        ctx.lineJoin = 'round';
        ctx.beginPath();
        if (up) { ctx.moveTo(axx, ayy - s); ctx.lineTo(axx + s * 0.86, ayy + s * 0.6); ctx.lineTo(axx - s * 0.86, ayy + s * 0.6); }
        else { ctx.moveTo(axx, ayy + s); ctx.lineTo(axx + s * 0.86, ayy - s * 0.6); ctx.lineTo(axx - s * 0.86, ayy - s * 0.6); }
        ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.restore();
      });
    }

    // ---- average ring (red dashed) + tag (reference average language) ----
    if (!multi && data.length && p > 0.7) {
      const avgR = radOf(avgVal);
      ctx.save();
      ctx.strokeStyle = 'rgba(239,68,68,0.85)';
      ctx.lineWidth = 1.6;
      ctx.setLineDash([5, 4]);
      ctx.beginPath();
      ctx.ellipse(cx, cy, avgR, Math.max(1, avgR * squash), 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      // tag pill parked ON the ring at the reference's angle
      const aTag = -Math.PI * 0.72;
      const [tgx, tgy] = ell(avgR, aTag, cy - (m > 0.05 ? wallHOf(avgR) : 0));
      const tagTxt = `Average ${fmtNum(Math.round(avgVal * 10) / 10)}`;
      ctx.font = font(t, 700, 9.5);
      const tw = measureW(ctx, tagTxt);
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.strokeStyle = '#fecaca';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(tgx - tw / 2 - 5, tgy - 8, tw + 10, 15, 4); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#ef4444';
      ctx.textAlign = 'center';
      ctx.fillText(tagTxt, tgx, tgy + 3.5);
      ctx.textAlign = 'left';
      ctx.restore();
    }

    // ---- centre hub (glossy origin marker + average readout) ----
    {
      const hr = Math.max(11, Math.min(24, rIn * 0.5));
      const hg = ctx.createLinearGradient(0, cy - hr, 0, cy + hr);
      hg.addColorStop(0, '#ffffff');
      hg.addColorStop(0.55, t.surface || '#e8e8e8');
      hg.addColorStop(1, shade(t.surface || '#e8e8e8', 0.85));
      ctx.fillStyle = hg;
      ctx.beginPath(); ctx.ellipse(cx, cy, hr, Math.max(1, hr * squash), 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = rgba(t.ink, 0.14);
      ctx.lineWidth = 1;
      ctx.stroke();
      if (!multi && p > 0.9) {
        ctx.fillStyle = t.ink;
        ctx.font = font(t, 700, Math.max(8, Math.min(11, hr * 0.62)));
        ctx.textAlign = 'center';
        ctx.fillText(fmtNum(Math.round(avgVal)), cx, cy + 3.5);
        ctx.textAlign = 'left';
      }
    }

    // ---- rotationAxis: outer ring + tangent CATEGORY labels outside ----
    // Labels sit OUTSIDE the data radius (and beyond the delta-arrow band
    // when priors are present); long sets stride exactly like a band axis —
    // never overlapping, never leaders.
    {
      ctx.save();
      ctx.strokeStyle = rgba(t.ink, 0.30);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(cx, cy, plotMax + 3, (plotMax + 3) * squash, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      const names: string[] = multi ? cats : data.map((x) => x.label);
      const stride = Math.max(1, Math.ceil(n / Math.max(4, Math.floor(plotMax / 26))));
      ctx.font = font(t, 600, FS);
      ctx.fillStyle = t.axis;
      ctx.textAlign = 'center';
      const lOut = hasPrior ? 9 : 0; // delta arrows own the first band outside the rim
      for (let i = 0; i < n; i++) {
        if (i % stride !== 0) continue;
        const mid = A0 + i * lane + lane / 2;
        const lr = plotMax + 8 + lOut + FS * 0.9;
        const lx = cx + Math.cos(mid) * lr;
        const ly = cy + Math.sin(mid) * lr * squash;
        // tangent rotation: readable on both halves (flip past the bottom)
        let rot = mid + Math.PI / 2;
        const deg = ((rot * 180) / Math.PI % 360 + 360) % 360;
        const flip = deg > 90 && deg < 270;
        if (flip) rot += Math.PI;
        ctx.save();
        ctx.translate(lx, ly);
        ctx.rotate(rot);
        const label = names[i] ?? '';
        const maxL = Math.min(labBand + 30, Math.max(40, (Math.PI * 2 * lr) / n - 8));
        ctx.fillText(fitCtx(ctx, label, maxL), 0, FS * 0.32);
        ctx.restore();
      }
      ctx.textAlign = 'left';
    }
    return;
  }

  /* ============ RADIAL BAR (Classic · canvas) — rebuilt Option B ============
     Beautiful in 2D AND 3D: concentric round-cap tubes on soft full-circle
     tracks, glassy cylindrical wrap in 3D, sweep-end dots, and proper
     outside labels with pie/donut-style curved leaders + arrowheads.
     NOTE: `radialbar` (Three.js) no longer falls through to this painter —
     it is always covered by its WebGL overlay. This block serves
     `radialbarclassic` only (see the guard). */
  /* ============ RADIAL BAR (Classic · canvas) — Highcharts 2D + TRUE 3D ============
     2D (Highcharts language): concentric round-cap progress rings on soft
     full-circle tracks, % rim ticks, center total, outside curved leaders.
     3D (ported from RadialBarText3D.html): the SAME rings on a tilted disc
     (squash eases 1 → 0.5 with m) rendered as sphere-shaded pipes — radial
     light→base→dark shading, contact shadows, z-sorted back-to-front
     painter order, sphere end caps, tangent-rotated in-tube labels.
     Geometry contract (shared with radialClassicGeom + hit test):
     - pitch is SOLVED so tubes can never overlap (see radialClassicGeom);
     - bars START at 12 o'clock and sweep CLOCKWISE up to 0.985 of a turn;
     - the disc DIAMETER is fixed across the morph (R never changes with m);
     - ellipse squash applies to Y only: (cos a · r, sin a · r · squash). */
  if (kind === 'radialbarclassic') {
    const rg = radialClassicGeom(W, H, data, full);
    const squash = 1 - 0.5 * m; // 1 → 0.5: the reference tilt, eased smoothly
    const R = rg.R; // FIXED diameter — identical in 2D and 3D
    const cx = rg.cx, cy = rg.cy;
    const tubeHalf = rg.thick / 2;
    const pipeLift = m; // 0 = flat ring, 1 = full pipe shading
    const ringR = (i: number) => rg.ringR(i) + (hov.idx === i ? hov.amt * 2.5 : 0);
    const max = Math.max(...data.map((x) => x.value), 1);
    const sweepOf = (x: ChartDatum) => Math.min(Math.PI * 2 * 0.985, (x.value / max) * Math.PI * 2 * 0.985 * p);
    const A0 = -Math.PI / 2; // 12 o'clock
    const ell = (r: number, a: number, y = cy): [number, number] =>
      [cx + Math.cos(a) * r, y + Math.sin(a) * r * squash];

    // ---- polar grid: concentric rings + spokes with % rim ticks ----
    {
      const G = Math.max(3, Math.min(6, data.length + 1));
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = 1;
      for (let gi = 1; gi <= G; gi++) {
        const gr = Math.max(4, (R * gi) / G);
        ctx.beginPath();
        ctx.ellipse(cx, cy, gr, gr * squash, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.font = font(t, 600, full ? 10 : 9);
      ctx.fillStyle = t.axis;
      ctx.textAlign = 'center';
      for (let pct = 10; pct <= 100; pct += 10) {
        const aa = A0 + (pct / 100) * Math.PI * 2 * 0.985;
        const [sx0, sy0] = ell(Math.max(4, R / G), aa);
        const [sx1, sy1] = ell(R, aa);
        ctx.strokeStyle = rgba(t.grid, 0.7);
        ctx.beginPath(); ctx.moveTo(sx0, sy0); ctx.lineTo(sx1, sy1); ctx.stroke();
        const [lx, ly] = ell(R + tubeHalf + 9, aa);
        ctx.fillText(`${pct}%`, Math.max(14, Math.min(W - 14, lx)), Math.max(10, Math.min(H - 4, ly + 3)));
      }
      ctx.textAlign = 'left';
    }

    // ---- glossy centre hub + total ----
    {
      const hr = Math.max(7, Math.min(22, tubeHalf * 1.2));
      ctx.fillStyle = rgba(t.ink, 0.10);
      ctx.beginPath(); ctx.ellipse(cx, cy + 3, hr + 3, (hr + 3) * squash, 0, 0, Math.PI * 2); ctx.fill();
      const hg = ctx.createLinearGradient(0, cy - hr, 0, cy + hr);
      hg.addColorStop(0, '#ffffff');
      hg.addColorStop(0.55, rgba(t.surface || '#e8e8e8', 1));
      hg.addColorStop(1, shade(t.surface || '#e8e8e8', 0.82));
      ctx.fillStyle = hg;
      ctx.beginPath(); ctx.ellipse(cx, cy, hr, hr * squash, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = rgba(t.ink, 0.14);
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.font = font(t, 700, full ? 12 : 10.5);
      ctx.fillStyle = t.ink;
      ctx.textAlign = 'center';
      ctx.fillText(fmtNum(total), cx, cy + (full ? 4 : 3.5));
      ctx.textAlign = 'left';
    }

    // ---- background tracks (full-circle grooves) ----
    noShadow(ctx);
    data.forEach((_, i) => {
      const rr = ringR(i);
      ctx.save();
      ctx.strokeStyle = rgba(t.surface || '#e4e7e0', full ? 0.9 : 1);
      ctx.lineWidth = rg.thick;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.ellipse(cx, cy, rr, rr * squash, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    });

    // ---- contact shadows (grow with the tilt, like the reference) ----
    data.forEach((x, i) => {
      const sweep = sweepOf(x);
      if (sweep <= 0.01) return;
      const rr = ringR(i);
      ctx.save();
      ctx.strokeStyle = rgba(t.ink, 0.08 + 0.06 * m);
      ctx.lineWidth = rg.thick;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.ellipse(cx, cy + 2 + 10 * m, rr, rr * squash, 0, A0, A0 + sweep);
      ctx.stroke();
      ctx.restore();
    });

    // ---- pipes: z-sorted back-to-front (reference spheresToDraw order) ----
    // Sampled beads per ring, sorted by screen Y (far beads under near
    // beads), each bead a sphere-shaded circle: white-hot crown → light →
    // base → dark limb. Bead count eases with m (flat ring needs none, the
    // tilt reveals the pipe), and alpha cross-fades flat↔pipe so the morph
    // is perfectly smooth at every step.
    interface Bead { x: number; y: number; r: number; col: string; light: string; dark: string; on: boolean }
    const beads: Bead[] = [];
    const labeled: { i: number; x: ChartDatum; baseR: number; col: string; on: boolean; sweep: number; end: number }[] = [];
    data.forEach((x, i) => {
      const on = hov.idx === i;
      const col = colors[i];
      const sweep = sweepOf(x);
      const end = A0 + sweep;
      const baseR = ringR(i);
      labeled.push({ i, x, baseR, col, on, sweep, end });
      if (sweep <= 0.01) return;
      // 2D flat ring (fades out as the pipe fades in)
      if (pipeLift < 0.98) {
        ctx.save();
        ctx.globalAlpha *= 1 - pipeLift;
        ctx.lineCap = 'round';
        const grad = ctx.createLinearGradient(0, cy - baseR * squash, 0, cy + baseR * squash);
        grad.addColorStop(0, shade(col, 1.14));
        grad.addColorStop(0.5, on ? shade(col, 1 + 0.14 * hov.amt) : col);
        grad.addColorStop(1, shade(col, 0.88));
        ctx.strokeStyle = grad;
        ctx.lineWidth = rg.thick;
        ctx.beginPath();
        ctx.ellipse(cx, cy, baseR, baseR * squash, 0, A0, end);
        ctx.stroke();
        ctx.strokeStyle = rgba('#ffffff', 0.35 * (1 - pipeLift));
        ctx.lineWidth = Math.max(1, rg.thick * 0.22);
        ctx.beginPath();
        ctx.ellipse(cx, cy - rg.thick * 0.12, baseR, baseR * squash, 0, A0 + 0.04, Math.max(A0 + 0.05, end - 0.04));
        ctx.stroke();
        ctx.restore();
      }
      // 3D pipe beads (fade in with the tilt)
      if (pipeLift > 0.02) {
        const arcLen = Math.max(8, sweep * baseR);
        const nBeads = Math.max(24, Math.min(420, Math.round(arcLen / Math.max(1.5, rg.thick * 0.22))));
        for (let bi = 0; bi <= nBeads; bi++) {
          const a = A0 + (sweep * bi) / nBeads;
          const [bx, by] = ell(baseR, a);
          beads.push({ x: bx, y: by, r: tubeHalf, col, light: shade(col, 1.45), dark: shade(col, 0.45), on });
        }
      }
    });
    if (beads.length) {
      beads.sort((a, b) => a.y - b.y); // far (top) first — reference z-sort
      ctx.save();
      ctx.globalAlpha *= pipeLift;
      beads.forEach((bd) => {
        const g = ctx.createRadialGradient(bd.x, bd.y - bd.r * 0.6, bd.r * 0.05, bd.x, bd.y, bd.r);
        g.addColorStop(0, '#ffffff');
        g.addColorStop(0.3, bd.light);
        g.addColorStop(0.7, bd.on ? shade(bd.col, 1 + 0.15 * hov.amt) : bd.col);
        g.addColorStop(1, bd.dark);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(bd.x, bd.y, bd.r, 0, Math.PI * 2); ctx.fill();
      });
      ctx.restore();
    }

    // ---- sweep-end caps + in-tube rotated labels (reference textAngle style) ----
    labeled.forEach(({ i, x, baseR, col, on, sweep, end }) => {
      if (sweep <= 0.01) return;
      // Perspective-true pipe end: the tube terminates in a sphere-shaded
      // cap bead — a sphere silhouettes as a PERFECT circle at any tilt, so
      // the end always follows the perspective rules for the angle it sits
      // at. (The old flat colour disc + white speck sat on the spherical
      // end like a sticker — the stray "ball" past halfway and the "circle
      // with a white dot" at the pipe end.) In flat 2D the ring stroke's
      // round lineCap already IS the perfect end, so nothing is overlaid.
      if (pipeLift > 0.02) {
        const [dx, dy0] = ell(baseR, end);
        ctx.save();
        ctx.globalAlpha *= Math.min(1, pipeLift * 1.2);
        const cg = ctx.createRadialGradient(dx, dy0 - tubeHalf * 0.6, tubeHalf * 0.05, dx, dy0, tubeHalf);
        cg.addColorStop(0, '#ffffff');
        cg.addColorStop(0.3, shade(col, 1.45));
        cg.addColorStop(0.7, on ? shade(col, 1 + 0.15 * hov.amt) : col);
        cg.addColorStop(1, shade(col, 0.45));
        ctx.fillStyle = cg;
        ctx.beginPath(); ctx.arc(dx, dy0, tubeHalf, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
      // rotated in-tube label at the arc midpoint (Highcharts-style inside,
      // reference-style tangent rotation), only when the arc is long enough
      const arcLen = sweep * baseR;
      if (arcLen > 70 && p > 0.9 && pipeLift > 0.02) {
        const la = A0 + sweep * 0.5;
        const [lx, ly] = ell(baseR, la);
        const tangent = Math.atan2(Math.cos(la) * squash, -Math.sin(la));
        let rot = tangent + Math.PI / 2;
        if (rot > Math.PI / 2 || rot < -Math.PI / 2) rot += Math.PI;
        ctx.save();
        ctx.translate(lx, ly);
        ctx.rotate(rot - Math.PI / 2 + Math.PI / 2);
        ctx.rotate(0);
        ctx.font = font(t, 700, Math.min(12, Math.max(9, rg.thick * 0.62)));
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 4; ctx.shadowOffsetX = 1; ctx.shadowOffsetY = 1;
        ctx.fillText(fitCtx(ctx, `${x.label} ${Math.round((x.value / max) * 100)}%`, Math.min(arcLen * 0.8, 170)), 0, -tubeHalf - 8);
        ctx.restore();
        void i;
        ctx.restore();
        ctx.textBaseline = 'alphabetic';
      }
    });

    // ---- outside curved leaders (2D-forward; fade as pipes take over) ----
    if (pipeLift < 0.85) {
      ctx.save();
      ctx.globalAlpha *= 1 - pipeLift;
      const FS = full ? 12 : W >= 760 ? 11.5 : 10;
      ctx.font = font(t, 600, FS);
      const PITCH = FS + 8;
      interface RBCand { e: (typeof labeled)[number]; text: string; ax: number; ay: number; right: boolean; y: number }
      const wantLabel = (e: { on: boolean }) => (rg.roomy ? (e.on || full || rg.thick >= 5) : e.on);
      const cands: RBCand[] = labeled.filter(wantLabel).map((e) => {
        const anchorA = e.sweep > 0.03 ? e.end : A0;
        const [aX, aY] = ell(e.baseR, anchorA);
        return { e, text: `${e.x.label} · ${fmtNum(e.x.value)}`, ax: aX, ay: aY, right: aX >= cx, y: aY };
      });
      const place = (list: RBCand[]) => {
        list.sort((p2, q) => p2.y - q.y);
        let prev = -Infinity;
        list.forEach((c) => { c.y = Math.max(c.y, prev + PITCH); prev = c.y; });
        list.forEach((c) => { c.y = Math.max(12, Math.min(H - 8, c.y)); });
      };
      place(cands.filter((c) => c.right));
      place(cands.filter((c) => !c.right));
      cands.forEach((c) => {
        const tx = c.right ? Math.min(W - 8, c.ax + 30) : Math.max(8, c.ax - 30);
        const ex = c.right ? tx - 8 : tx + 8;
        const mx2 = (ex + c.ax) / 2;
        ctx.strokeStyle = c.e.col;
        ctx.lineWidth = c.e.on ? 2 : 1.4;
        ctx.beginPath();
        ctx.moveTo(tx, c.y);
        ctx.lineTo(ex, c.y);
        ctx.bezierCurveTo(mx2, c.y, c.ax, c.ay, c.ax, c.ay);
        ctx.stroke();
        const dx = c.ax - mx2, dy = c.ay - c.y;
        const dl = Math.hypot(dx, dy) || 1;
        const ux = dx / dl, uy = dy / dl;
        const px2 = -uy, py2 = ux;
        const bx = c.ax - ux * 6, by = c.ay - uy * 6;
        ctx.fillStyle = c.e.col;
        ctx.beginPath();
        ctx.moveTo(c.ax + ux * 0.5, c.ay + uy * 0.5);
        ctx.lineTo(bx - ux * 1.2 + px2 * 4, by - uy * 1.2 + py2 * 4);
        ctx.lineTo(bx - ux * 1.2 - px2 * 4, by - uy * 1.2 - py2 * 4);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.lineJoin = 'round';
        ctx.stroke();
        ctx.lineJoin = 'miter';
        const avail = c.right ? W - tx - 8 : tx - 8;
        ctx.fillStyle = t.ink;
        ctx.textAlign = c.right ? 'left' : 'right';
        ctx.fillText(full ? c.text : fitCtx(ctx, c.text, Math.max(30, avail)), tx + (c.right ? 4 : -4), c.y + FS * 0.35);
      });
      ctx.restore();
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ DUAL AXES — columns (left) + lines (right) (2D ⇄ 3D) ============ */
  if (kind === 'dual') {
    const labels = multi ? cats : data.map((x) => x.label);
    const colVals = multi ? cats.map((_, c) => series[0]?.values[c] || 0) : data.map((x) => x.value);
    const barColors = multi ? [sColors[0]] : colors;
    const lines: { name: string; color: string; values: number[] }[] = multi
      ? series.slice(1).map((s, i) => ({ name: s.name, color: distinctLineColor(barColors, sColors[i + 1], activePalette()), values: s.values }))
      : [{
        name: 'Cumulative %',
        // Premium slate ink for the Pareto cumulative line — never a bar color.
        color: distinctLineColor(barColors, '#0f172a', activePalette()),
        values: (() => {
          let acc = 0;
          return data.map((x) => { acc += x.value; return Math.round((acc / total) * 100); });
        })(),
      }];

    const ox = 20 * m, oy = 15 * m; // 3D isometric offset
    const maxL = Math.max(...colVals, 1);
    const maxR = Math.max(...lines.flatMap((l) => l.values), 1);
    const L = xyLayout('bar', W, H, 0, labels, 1, maxL, !!d.yLabel, full);
    const pad = { ...L.pad, r: 12 + approxW(fmtNum(maxR), 10.5) + 14 + ox, t: L.pad.t + oy };
    const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
    const step = cw / Math.max(1, labels.length);

    // 3D Isometric floor grid
    if (m > 0.05) {
      ctx.strokeStyle = rgba(t.grid, 0.4);
      ctx.lineWidth = 1;
      for (let g = 0; g <= 4; g++) {
        const y = pad.t + ch - (ch * g) / 4;
        ctx.beginPath();
        ctx.moveTo(pad.l, y);
        ctx.lineTo(pad.l + ox, y - oy);
        ctx.lineTo(W - pad.r + ox, y - oy);
        ctx.stroke();
      }
    }

    drawAxes(ctx, W, H, pad, maxL, t, m > 0.05 ? ox : 0, m > 0.05 ? oy : 0);

    // Right Y-axis
    ctx.font = font(t, 600, 10.5); ctx.fillStyle = t.axis; ctx.textAlign = 'left';
    for (let g = 0; g <= 4; g++) {
      const y = pad.t + ch - (ch * g) / 4;
      ctx.fillText(fmtNum((maxR * g) / 4) + (multi ? '' : '%'), W - pad.r + (m > 0.05 ? ox : 0) + 7, (m > 0.05 ? y - oy : y) + 3.5);
    }
    ctx.strokeStyle = t.axis; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t - 4 - (m > 0.05 ? oy : 0)); ctx.lineTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t + ch - (m > 0.05 ? oy : 0)); ctx.stroke(); ctx.lineWidth = 1;

    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, planX(labels, step, full), (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);

    // 3D Columns
    labels.forEach((_, ci) => {
      const bw = Math.min(36, step * 0.5);
      const x = pad.l + step * ci + (step - bw) / 2;
      const h = (colVals[ci] / maxL) * ch * p;
      const yTop = pad.t + ch - h;
      const yBase = pad.t + ch;
      const on = multi ? !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === 0) : hov.idx === ci;
      const col = multi ? sColors[0] : colors[ci];
      const cFill = on ? shade(col, 1 + 0.16 * hov.amt) : col;

      if (m > 0.05 && h > 1) {
        // 3D Top face
        ctx.fillStyle = shade(cFill, 1.25);
        ctx.beginPath();
        ctx.moveTo(x, yTop);
        ctx.lineTo(x + ox, yTop - oy);
        ctx.lineTo(x + bw + ox, yTop - oy);
        ctx.lineTo(x + bw, yTop);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 1; ctx.stroke();

        // 3D Right face
        ctx.fillStyle = shade(cFill, 0.68);
        ctx.beginPath();
        ctx.moveTo(x + bw, yTop);
        ctx.lineTo(x + bw + ox, yTop - oy);
        ctx.lineTo(x + bw + ox, yBase - oy);
        ctx.lineTo(x + bw, yBase);
        ctx.closePath();
        ctx.fill();
      }

      // Front face
      ctx.fillStyle = cFill;
      ctx.beginPath(); ctx.roundRect(x, yTop, bw, Math.max(1, h), m > 0.05 ? 0 : [5, 5, 0, 0]); ctx.fill();
    });

    // Lines on the right axis
    lines.forEach((ln, li) => {
      const pts = ln.values.map((v, i) => ({
        x: pad.l + step * i + step / 2 + (m > 0.05 ? ox * 0.5 : 0),
        y: pad.t + ch - (v / maxR) * ch * p - (m > 0.05 ? oy * 0.5 : 0),
      }));
      if (!pts.length) return;

      // Freehand (Catmull-Rom → bezier) path shared by line AND shadow —
      // the shadow is the same curve translated down, so they always match.
      const traceFreehand = (dy: number) => {
        ctx.beginPath();
        pts.forEach((pt, i) => {
          if (i === 0) { ctx.moveTo(pt.x, pt.y + dy); return; }
          const p0 = pts[Math.max(0, i - 2)], p1 = pts[i - 1], p2 = pt, p3 = pts[Math.min(pts.length - 1, i + 1)];
          ctx.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + dy + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y + dy - (p3.y - p1.y) / 6, p2.x, p2.y + dy);
        });
      };
      // 3D Shadow ribbon (same freehand curve, offset down-right)
      if (m > 0.05) {
        ctx.strokeStyle = rgba(t.ink, 0.15);
        ctx.lineWidth = 3;
        traceFreehand(oy * 0.5);
        ctx.stroke();
      }

      ctx.strokeStyle = ln.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
      traceFreehand(0);
      ctx.stroke();

      const dense = step < 14;
      pts.forEach((pt, i) => {
        const on = multi ? !!(hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === li + 1) : hov.idx === i;
        if (dense && !on) return;
        const rad = (step < 26 ? 3.5 : 4.5) + (on ? 2 * hov.amt : 0);
        if (m > 0.05) {
          const g = ctx.createRadialGradient(pt.x - 1.5, pt.y - 1.5, 1, pt.x, pt.y, rad);
          g.addColorStop(0, shade(ln.color, 1.35));
          g.addColorStop(1, shade(ln.color, 0.75));
          ctx.fillStyle = g;
        } else {
          ctx.fillStyle = on ? shade(ln.color, 1.2) : ln.color;
        }
        ctx.beginPath(); ctx.arc(pt.x, pt.y, rad, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
      });
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ GANTT CHART (2D + glass-block 3D) — rebuilt Option B ============
     Modern Gantt language inspired by the best web Gantts (rounded bars,
     progress sheen, milestones, baseline ghosts, dependency elbows,
     critical-path glow, today line, overdue hatch, weekend shading, swim
     lanes with avatar chips). 3D = the SAME layout with extruded glass
     blocks, continuous 2D⇄3D morph. */
  if (kind === 'gantt') {
    type GT = GanttTask & { _s: number; _e: number; _bS?: number; _bE?: number };
    const toMs = (v: string | number): number => (typeof v === 'number' ? v : new Date(v).getTime());
    const isDate = !!(d.tasks && d.tasks.length && typeof d.tasks[0].start === 'string');
    const rawTasks: GT[] = d.tasks && d.tasks.length ? d.tasks.map((tk) => ({
      ...tk,
      _s: toMs(tk.start), _e: Math.max(toMs(tk.start) + 1, toMs(tk.end)),
      _bS: tk.baselineStart !== undefined ? toMs(tk.baselineStart) : undefined,
      _bE: tk.baselineEnd !== undefined ? toMs(tk.baselineEnd) : undefined,
    })) : (
      data.map((x, i) => ({
        id: i, name: x.label, start: i * 3, end: i * 3 + Math.max(3, Math.round(x.value / 8)),
        progress: 35 + ((i * 17) % 60), color: colors[i], category: 'Milestone',
        _s: i * 3, _e: i * 3 + Math.max(3, Math.round(x.value / 8)),
      }))
    );
    const byId = new Map<string | number, number>();
    rawTasks.forEach((tk, i) => byId.set(tk.id, i));
    const padL = Math.max(150, Math.min(250, W * 0.27));
    const padR = 30 + 14 * m, padT = 52 + 10 * m, padB = 30;
    const chartW = W - padL - padR;
    const chartH = H - padT - padB;
    const rowH = Math.min(46, Math.max(28, chartH / Math.max(1, rawTasks.length)));
    const plotBot = padT + rowH * rawTasks.length;

    const starts = rawTasks.map((tk) => tk._s);
    const ends = rawTasks.map((tk) => tk._e);
    const minTime = Math.min(...starts);
    const maxTime = Math.max(...ends, minTime + 1);
    const timeSpan = maxTime - minTime || 1;
    // ONE oblique 3D projection for the whole Gantt scene: every 2D point
    // (x, y) at extrusion height z maps to (x + z·cosA, y − z·sinA) with a
    // fixed cabinet angle A=38°. Tracks sit at z=0, bar tops at z=barH·0.9,
    // elbows at z=barH·0.45 — so bars, caps, shadows and dependency links
    // share one consistent depth instead of ad-hoc per-element offsets.
    const G_ANG = (38 * Math.PI) / 180;
    const gOx = Math.cos(G_ANG) * 13 * m, gOy = Math.sin(G_ANG) * 13 * m;
    const X = (ms: number) => padL + ((ms - minTime) / timeSpan) * chartW;
    const ZP = (x: number, y: number, z: number): [number, number] =>
      [x + (z / 13) * gOx, y - (z / 13) * gOy];

    // ---- swim-lane grouping (by category) ----
    const lanes: { name: string; rows: number[] }[] = [];
    const laneOf = new Array(rawTasks.length).fill(0);
    rawTasks.forEach((tk, i) => {
      const nm = tk.category || 'Plan';
      let li = lanes.findIndex((l) => l.name === nm);
      if (li < 0) { lanes.push({ name: nm, rows: [] }); li = lanes.length - 1; }
      lanes[li].rows.push(i);
      laneOf[i] = li;
    });
    const laneColors = lanes.map((_, li) => colors[li % colors.length]);

    // ---- plot bay ----
    ctx.fillStyle = rgba(t.ink, m > 0.02 ? 0.05 : 0.035);
    ctx.beginPath(); ctx.roundRect(padL - 8, padT - 34, chartW + 16, plotBot - padT + 40, 10); ctx.fill();

    // ---- weekend shading (date mode) ----
    if (isDate) {
      const t0 = new Date(minTime); t0.setHours(0, 0, 0, 0);
      for (let dd = new Date(t0); dd.getTime() <= maxTime; dd = new Date(dd.getTime() + 864e5)) {
        const dow = dd.getDay();
        if (dow === 0 || dow === 6) {
          const x0 = X(dd.getTime()), x1 = X(dd.getTime() + 864e5);
          ctx.fillStyle = rgba(t.ink, 0.045);
          ctx.fillRect(x0, padT - 4, Math.max(1, x1 - x0), plotBot - padT + 8);
        }
      }
    }

    // ---- time axis: day gridlines + adaptive header (month/day or Day N) ----
    const cols = 5;
    ctx.font = font(t, 600, 10);
    ctx.textAlign = 'center';
    for (let c = 0; c <= cols; c++) {
      const gx = padL + (chartW * c) / cols;
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(gx, padT - 4);
      ctx.lineTo(gx, plotBot);
      if (m > 0.02) { ctx.moveTo(gx, plotBot); ctx.lineTo(gx + gOx, plotBot - gOy); }
      ctx.stroke();
      ctx.setLineDash([]);
      const tVal = minTime + (timeSpan * c) / cols;
      const tLabel = isDate
        ? new Date(tVal).toLocaleDateString('en', { month: 'short', day: 'numeric' })
        : `Day ${Math.round(tVal)}`;
      ctx.fillStyle = t.axis;
      ctx.fillText(tLabel, gx + (m > 0.02 ? gOx / 2 : 0), padT - 22);
    }
    if (isDate) {
      // month band above the day labels
      ctx.font = font(t, 700, 9);
      ctx.fillStyle = rgba(t.axis, 0.85);
      let lastM = '';
      for (let c = 0; c <= cols; c++) {
        const tVal = minTime + (timeSpan * c) / cols;
        const mm = new Date(tVal).toLocaleDateString('en', { month: 'long', year: 'numeric' });
        if (mm !== lastM) {
          const gx = padL + (chartW * c) / cols;
          ctx.fillText(mm.toUpperCase(), Math.min(gx + 34, padL + chartW - 40), padT - 34 - 10);
          lastM = mm;
        }
      }
    }
    // ---- today marker ----
    const nowMs = Date.now();
    if (isDate && nowMs >= minTime && nowMs <= maxTime) {
      const tx = X(nowMs);
      ctx.save();
      ctx.strokeStyle = '#e11d63'; ctx.lineWidth = 1.6; ctx.setLineDash([5, 3]);
      ctx.beginPath(); ctx.moveTo(tx, padT - 8); ctx.lineTo(tx, plotBot + 2); ctx.stroke();
      ctx.setLineDash([]);
      ctx.font = font(t, 700, 9); ctx.textAlign = 'center';
      const tw = measureW(ctx, 'TODAY') + 12;
      ctx.fillStyle = '#e11d63';
      ctx.beginPath(); ctx.roundRect(tx - tw / 2, padT - 26, tw, 14, 7); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.fillText('TODAY', tx, padT - 15.5);
      ctx.restore();
    }
    ctx.textAlign = 'left';
    if (m > 0.02) {
      ctx.fillStyle = rgba(t.ink, 0.045 * m);
      ctx.beginPath();
      ctx.moveTo(padL, plotBot);
      ctx.lineTo(padL + gOx, plotBot - gOy);
      ctx.lineTo(padL + chartW + gOx, plotBot - gOy);
      ctx.lineTo(padL + chartW, plotBot);
      ctx.closePath(); ctx.fill();
    }

    // ---- critical path: longest dependency chain (finish-to-start) ----
    const crit = new Set<number>();
    {
      const memo = new Map<number, number>();
      const depth = (i: number, seen: Set<number>): number => {
        if (memo.has(i)) return memo.get(i)!;
        if (seen.has(i)) return 0;
        seen.add(i);
        const tk = rawTasks[i];
        let best = 1;
        (tk.dependsOn || []).forEach((dep) => {
          const j = byId.get(dep);
          if (j !== undefined) best = Math.max(best, 1 + depth(j, seen));
        });
        seen.delete(i);
        memo.set(i, best);
        return best;
      };
      let longest = 0;
      rawTasks.forEach((tk, i) => { if ((tk.dependsOn || []).length) longest = Math.max(longest, depth(i, new Set())); });
      if (longest >= 2) {
        // mark tasks lying on SOME longest chain (greedy from the deepest)
        let end = -1, bd = -1;
        rawTasks.forEach((_, i) => { const dd = depth(i, new Set()); if (dd > bd) { bd = dd; end = i; } });
        let cur = end;
        const guard = new Set<number>();
        while (cur >= 0 && !guard.has(cur)) {
          guard.add(cur);
          crit.add(cur);
          const tk = rawTasks[cur];
          let nxt = -1, nd = -1;
          (tk.dependsOn || []).forEach((dep) => {
            const j = byId.get(dep);
            if (j !== undefined) { const dd = depth(j, new Set()); if (dd > nd) { nd = dd; nxt = j; } }
          });
          cur = nxt;
        }
      }
    }
    rawTasks.forEach((task, i) => {
      const sx = X(task._s);
      const ex = X(task._e);
      const barW = Math.max(8, ex - sx);
      const ry = padT + i * rowH;
      const barH = Math.max(15, rowH - 13);
      const by = ry + (rowH - barH) / 2;
      const on = hov.idx === i;
      const col = task.color || colors[i % colors.length] || '#0d7a54';
      const prg = Math.min(100, Math.max(0, task.progress ?? 100)) / 100;
      // WEDGE FIX: a progress width shorter than the bar's own height made
      // the 3D lozenge's hull centreline endpoints (fAx/fBx below) cross
      // over each other — the round-cap stroke degenerates into a pointed
      // sliver poking out past the bar for any low-progress task. Flooring
      // at barH (not a flat 4px) keeps the pill at least as wide as it is
      // tall, so the hull can never invert into a wedge, while barely
      // changing anything for any normal (wider) progress value.
      const pw = Math.max(Math.min(barW, barH), barW * prg * p);
      const pCol = on ? shade(col, 1 + 0.15 * hov.amt) : col;
      const isCrit = crit.has(i);
      const overdue = isDate && prg < 1 && task._e < nowMs;
      const laneCol = laneColors[laneOf[i] % laneColors.length];

      // swim-lane band: soft tint per category + hairline separators
      ctx.fillStyle = rgba(laneCol, i % 2 === 1 ? 0.07 : 0.045);
      ctx.fillRect(padL - 8, ry, chartW + 16, rowH);
      ctx.strokeStyle = rgba(t.ink, 0.06);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(padL - 8, ry + rowH); ctx.lineTo(padL + chartW + 8, ry + rowH); ctx.stroke();
      // lane label on its first row
      if (lanes[laneOf[i]].rows[0] === i && lanes.length > 1) {
        ctx.font = font(t, 700, 8.5);
        ctx.fillStyle = rgba(laneCol, 0.95);
        ctx.textAlign = 'left';
        ctx.fillText(lanes[laneOf[i]].name.toUpperCase(), padL + chartW - Math.min(150, measureW(ctx, lanes[laneOf[i]].name.toUpperCase()) + 4), ry + 11);
      }
      // duration pill at the bar's right end (date-aware: "12d" / "3w")
      {
        const durMs = task._e - task._s;
        const durDays = isDate ? Math.max(1, Math.round(durMs / 864e5)) : Math.max(1, Math.round(durMs));
        const durTxt = isDate ? (durDays >= 14 ? `${Math.round(durDays / 7)}w` : `${durDays}d`) : `${durDays}d`;
        const slackTxt = task.slackDays !== undefined && task.slackDays !== null
          ? ` · slack ${task.slackDays}d`
          : '';
        ctx.font = font(t, 600, 8.5);
        const pill = `${durTxt}${slackTxt}`;
        const pwPill = measureW(ctx, pill) + 12;
        const pillX = Math.min(sx + barW + 6, padL + chartW - pwPill);
        if (sx + barW + 6 < padL + chartW - 10 && barH >= 14) {
          ctx.fillStyle = rgba(t.ink, 0.07);
          ctx.beginPath(); ctx.roundRect(pillX, by + barH / 2 - 8, pwPill, 15, 7); ctx.fill();
          ctx.fillStyle = t.axis;
          ctx.textAlign = 'left';
          ctx.fillText(pill, pillX + 6, by + barH / 2 + 3);
        }
      }
      // dependency count badge at the bar's left edge ("⑂2")
      if ((task.dependsOn || []).length) {
        ctx.font = font(t, 700, 8.5);
        const depTxt = `\u2442${(task.dependsOn || []).length}`;
        const dw = measureW(ctx, depTxt) + 10;
        if (sx - dw - 16 > padL) {
          ctx.fillStyle = rgba(t.ink, 0.08);
          ctx.beginPath(); ctx.roundRect(sx - dw - 4, by + barH / 2 - 8, dw, 15, 7); ctx.fill();
          ctx.fillStyle = t.axis;
          ctx.textAlign = 'left';
          ctx.fillText(depTxt, sx - dw + 1, by + barH / 2 + 3);
        }
      }
      if (on) {
        ctx.fillStyle = rgba(t.ink, 0.05);
        ctx.beginPath(); ctx.roundRect(8, ry + 1, W - 16, rowH - 2, 6); ctx.fill();
      }

      // critical-path glow behind the bar
      if (isCrit) {
        ctx.save();
        setShadow(ctx, 0, 0, 10, rgba('#e11d63', 0.5));
        ctx.fillStyle = rgba('#e11d63', 0.10);
        ctx.beginPath(); ctx.roundRect(sx - 3, by - 3, barW + 6, barH + 6, (barH + 6) / 2); ctx.fill();
        ctx.restore();
      }

      // name + date range + avatar chip in the label gutter
      ctx.font = font(t, 600, 11);
      ctx.fillStyle = on ? t.ink : shade(t.ink, 0.85);
      ctx.textAlign = 'left';
      ctx.fillText(fitCtx(ctx, task.name, padL - 66), 16, by + barH * 0.42);
      ctx.font = font(t, 500, 9);
      ctx.fillStyle = t.axis;
      const rangeTxt = isDate
        ? `${new Date(task._s).toLocaleDateString('en', { month: 'short', day: 'numeric' })} → ${new Date(task._e).toLocaleDateString('en', { month: 'short', day: 'numeric' })}`
        : `Day ${Math.round(task._s)} → ${Math.round(task._e)}`;
      ctx.fillText(fitCtx(ctx, rangeTxt, padL - 66), 16, by + barH * 0.42 + 12);
      if (task.assignee) {
        const init = task.assignee.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();
        const ax = padL - 30, ay = by + barH / 2;
        ctx.fillStyle = shade(col, 0.85);
        ctx.beginPath(); ctx.arc(ax, ay, 9, 0, Math.PI * 2); ctx.fill();
        ctx.font = font(t, 700, 8);
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
        ctx.fillText(init, ax, ay + 2.8);
        ctx.textAlign = 'left';
      }

      // baseline ghost (thin grey bar under the plan)
      if (task._bS !== undefined && task._bE !== undefined) {
        const bsx = X(task._bS), bex = X(task._bE);
        ctx.fillStyle = rgba(t.ink, 0.22);
        ctx.beginPath(); ctx.roundRect(bsx, by + barH + 1.5, Math.max(4, bex - bsx), 3, 1.5); ctx.fill();
      }

      // milestone diamond (zero-duration or flagged) — in 3D a true
      // diamond PRISM: back face + two visible side faces via ZP, glass front.
      if (task.milestone || task._e - task._s <= 1) {
        const dx = sx + (task.milestone ? barW / 2 : 0), dyy = by + barH / 2, rr = barH * 0.52;
        const zDia = Math.min(13, Math.max(7, barH * 0.6));
        const dT = ZP(dx, dyy - rr, zDia), dR = ZP(dx + rr, dyy, zDia),
          dB = ZP(dx, dyy + rr, zDia), dL = ZP(dx - rr, dyy, zDia);
        ctx.save();
        if (m > 0.02) { setShadow(ctx, 2 * m, 3 * m, 6, rgba(t.ink, 0.25 * m)); }
        if (m > 0.02) {
          // side faces (right flank darker than top flank)
          ctx.fillStyle = shade(pCol, 0.55);
          ctx.beginPath();
          ctx.moveTo(dx + rr, dyy); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dB[0], dB[1]); ctx.lineTo(dx, dyy + rr);
          ctx.closePath(); ctx.fill();
          ctx.fillStyle = shade(pCol, 0.8);
          ctx.beginPath();
          ctx.moveTo(dx, dyy - rr); ctx.lineTo(dT[0], dT[1]); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dx + rr, dyy);
          ctx.closePath(); ctx.fill();
        }
        const mg = ctx.createLinearGradient(0, dyy - rr, 0, dyy + rr);
        mg.addColorStop(0, shade(pCol, 1.3)); mg.addColorStop(1, shade(pCol, 0.75));
        ctx.fillStyle = mg;
        ctx.beginPath();
        if (m > 0.02) {
          ctx.moveTo(dT[0], dT[1]); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dB[0], dB[1]); ctx.lineTo(dL[0], dL[1]);
        } else {
          ctx.moveTo(dx, dyy - rr); ctx.lineTo(dx + rr, dyy); ctx.lineTo(dx, dyy + rr); ctx.lineTo(dx - rr, dyy);
        }
        ctx.closePath(); ctx.fill();
        ctx.restore();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
      } else if (m > 0.02) {
        // contact shadow for the whole group
        ctx.save();
        setShadow(ctx, 0, 3 * m + 1, 7, rgba(t.ink, 0.22 * m));
        ctx.fillStyle = rgba(t.ink, 0.10 * m);
        ctx.beginPath(); ctx.roundRect(sx + gOx * 0.4, by + gOy * 0.4 + 2 * m, barW, barH, barH / 2); ctx.fill();
        ctx.restore();
        // recessed track groove (dark inset rail)
        ctx.fillStyle = rgba(t.ink, 0.10 + 0.04 * m);
        ctx.beginPath(); ctx.roundRect(sx, by, barW, barH, barH / 2); ctx.fill();
        ctx.strokeStyle = rgba('#ffffff', 0.35);
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(sx + 0.5, by + barH - 1.5, barW - 1, 1.2, 1); ctx.stroke();
        // Progress lozenge: a ROUNDED extrusion built as the exact silhouette
        // HULL of the front and back pills — one thick round-join stroke of
        // the two centrelines' hull (a stadium is the Minkowski sum of its
        // centreline and a disc, so stroking the hull quad with barH
        // reproduces the union exactly). The old stack of offset roundRect
        // slices let the dark far pill's round caps peek out around BOTH
        // ends of the front pill — the little wedge slivers that stuck out
        // of the bars in 3D.
        const zBar = Math.min(13, Math.max(7, barH * 0.72));
        const [oxB, oyB] = ZP(0, 0, zBar);
        const rC = barH / 2;
        const fAx = sx + rC, fAy = by + rC;              // front centreline left
        const fBx = sx + pw - rC, fBy = by + rC;         // front centreline right
        const bAx = fAx + oxB, bAy = fAy + oyB;          // back centreline left
        const bBx = fBx + oxB, bBy = fBy + oyB;          // back centreline right
        ctx.save();
        ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        // 1) full extrusion body — dark side wall (exact hull silhouette)
        ctx.strokeStyle = shade(pCol, 0.52);
        ctx.lineWidth = barH;
        ctx.beginPath();
        ctx.moveTo(fAx, fAy); ctx.lineTo(fBx, fBy); ctx.lineTo(bBx, bBy); ctx.lineTo(bAx, bAy);
        ctx.closePath(); ctx.stroke();
        // 2) the roof (top face): a FILLED quad from the front centreline to
        // the back centreline, PLUS its own round end caps at the back
        // vertices. Drawing this as a bare stroke used to leave the dark
        // side-wall's round caps at bAx/bBx showing raw past the quad's
        // straight edges — a mismatched-colour sliver poking out beyond the
        // rounded end of the bar (the wedge from the screenshot). Filling
        // the whole quad AND re-painting full circles over both back
        // vertices with the same mid-tone recolours those caps so nothing
        // but the intended lit roof is ever visible past the front face.
        ctx.strokeStyle = shade(pCol, 0.85);
        ctx.fillStyle = shade(pCol, 0.85);
        ctx.beginPath();
        ctx.moveTo(fAx, fAy); ctx.lineTo(fBx, fBy); ctx.lineTo(bBx, bBy); ctx.lineTo(bAx, bAy);
        ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.arc(bAx, bAy, rC, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(bBx, bBy, rC, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.moveTo(bAx, bAy); ctx.lineTo(bBx, bBy); ctx.stroke();
        ctx.restore();
        // top sheen slice: one bright rounded cap just under the glass front
        {
          const [ox3, oy3] = ZP(0, 0, zBar * 0.12);
          ctx.fillStyle = shade(pCol, 1.18);
          ctx.beginPath(); ctx.roundRect(sx + ox3, by + oy3, pw, Math.max(2, barH * 0.42), barH * 0.21); ctx.fill();
        }
        const gg = ctx.createLinearGradient(0, by, 0, by + barH);
        gg.addColorStop(0, shade(pCol, 1.22));
        gg.addColorStop(0.45, pCol);
        gg.addColorStop(1, shade(pCol, 0.74));
        ctx.fillStyle = gg;
        ctx.beginPath(); ctx.roundRect(sx, by, pw, barH, barH / 2); ctx.fill();
        // specular gloss band across the upper third
        ctx.fillStyle = 'rgba(255,255,255,0.30)';
        ctx.beginPath(); ctx.roundRect(sx + 3, by + 2.5, Math.max(1, pw - 6), Math.max(1, barH * 0.3), barH * 0.15); ctx.fill();
        ctx.strokeStyle = rgba('#ffffff', 0.55);
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(sx + 0.5, by + 0.5, pw - 1, barH - 1, barH / 2 - 0.5); ctx.stroke();
        // progress pip at the leading edge of the lozenge
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(sx + pw - 1, by + barH / 2, Math.max(1.6, barH * 0.14), 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = pCol;
        ctx.beginPath(); ctx.arc(sx + pw - 1, by + barH / 2, Math.max(1, barH * 0.09), 0, Math.PI * 2); ctx.fill();
        // overdue: diagonal hatch over the unworked remainder
        if (overdue) {
          ctx.save();
          ctx.beginPath(); ctx.roundRect(sx + pw, by, Math.max(0, barW - pw), barH, 4); ctx.clip();
          ctx.strokeStyle = rgba('#e11d63', 0.5);
          ctx.lineWidth = 1.4;
          for (let hx = sx + pw - barH; hx < sx + barW + barH; hx += 6) {
            ctx.beginPath(); ctx.moveTo(hx, by + barH); ctx.lineTo(hx + barH, by); ctx.stroke();
          }
          ctx.restore();
        }
        // status dot: green = done, amber = in flight, grey = not started,
        // red ring when overdue
        const stCol = overdue ? '#e11d63' : prg >= 1 ? '#16a34a' : prg > 0 ? '#d97706' : '#9ca3af';
        ctx.fillStyle = stCol;
        ctx.beginPath(); ctx.arc(sx - 9, by + barH / 2, 3.2, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
        // dependency links from EXPLICIT dependsOn (finish-to-start elbows)
        // — lifted onto the bar-face plane (z = zBar·0.5) so arrowheads plug
        // into the 3D faces instead of floating behind them.
        (task.dependsOn || []).forEach((dep) => {
          const j = byId.get(dep);
          if (j === undefined || j === i) return;
          const fromX = X(rawTasks[j]._e);
          const py = padT + j * rowH + rowH / 2;
          const cy2 = by + barH / 2;
          const hot = crit.has(i) && crit.has(j);
          const midX = Math.max(fromX + 6, sx - 14);
          const zEl = Math.min(13, Math.max(7, barH * 0.72)) * 0.5;
          const e0 = ZP(fromX, py, zEl), e1 = ZP(midX, py, zEl),
            e2 = ZP(midX, cy2, zEl), e3 = ZP(sx - 2, cy2, zEl);
          ctx.save();
          ctx.strokeStyle = hot ? '#e11d63' : rgba(t.ink, 0.35);
          ctx.lineWidth = hot ? 1.8 : 1.2;
          if (!hot) ctx.setLineDash([3, 2.5]);
          ctx.beginPath();
          ctx.moveTo(e0[0], e0[1]);
          ctx.lineTo(e1[0], e1[1]);
          ctx.lineTo(e2[0], e2[1]);
          ctx.lineTo(e3[0], e3[1]);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.fillStyle = hot ? '#e11d63' : rgba(t.ink, 0.5);
          ctx.beginPath();
          ctx.moveTo(e3[0], e3[1]);
          ctx.lineTo(e3[0] - 5, e3[1] - 3);
          ctx.lineTo(e3[0] - 5, e3[1] + 3);
          ctx.closePath(); ctx.fill();
          ctx.restore();
        });
      } else {
        // Fix #7: fully rounded pill edges in 2D to match the flattened
        // projection of the 3D design (which uses barH/2 everywhere).
        const pillR = barH / 2;
        ctx.fillStyle = rgba(col, 0.2);
        ctx.beginPath(); ctx.roundRect(sx, by, barW, barH, pillR); ctx.fill();
        // (The green/amber "effort vs elapsed" mini-track that used to sit
        // under each 2D pill was removed per product request — the status
        // dot before the bar already carries schedule health.)
        ctx.fillStyle = on ? shade(col, 1.15) : col;
        ctx.beginPath(); ctx.roundRect(sx, by, pw, barH, Math.min(pillR, pw / 2)); ctx.fill();
        ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
        ctx.beginPath(); ctx.roundRect(sx, by, Math.max(1, pw), barH / 2, [Math.min(pillR, pw / 2), Math.min(pillR, pw / 2), 0, 0]); ctx.fill();
        // owner avatar overlapping the bar's leading edge (2D + 3D alike)
        if (task.assignee && barW > 30) {
          const init2 = task.assignee.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();
          const ox = sx + 9, oy = by + barH / 2;
          ctx.fillStyle = '#ffffff';
          ctx.beginPath(); ctx.arc(ox, oy, 7.5, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = shade(col, 0.7);
          ctx.beginPath(); ctx.arc(ox, oy, 6.2, 0, Math.PI * 2); ctx.fill();
          ctx.font = font(t, 700, 7);
          ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
          ctx.fillText(init2, ox, oy + 2.4);
          ctx.textAlign = 'left';
        }
        // start/end date caps under long bars
        if (isDate && barW > 120) {
          ctx.font = font(t, 600, 8);
          ctx.fillStyle = t.axis;
          ctx.textAlign = 'left';
          const sCap = new Date(task._s).toLocaleDateString('en', { month: 'short', day: 'numeric' });
          const eCap = new Date(task._e).toLocaleDateString('en', { month: 'short', day: 'numeric' });
          ctx.fillText(sCap, sx + 2, by + barH + 10);
          ctx.textAlign = 'right';
          ctx.fillText(eCap, sx + barW - 2, by + barH + 10);
          ctx.textAlign = 'left';
        }
        if (overdue) {
          ctx.save();
          ctx.beginPath(); ctx.roundRect(sx + pw, by, Math.max(0, barW - pw), barH, 4); ctx.clip();
          ctx.strokeStyle = rgba('#e11d63', 0.5);
          ctx.lineWidth = 1.4;
          for (let hx = sx + pw - barH; hx < sx + barW + barH; hx += 6) {
            ctx.beginPath(); ctx.moveTo(hx, by + barH); ctx.lineTo(hx + barH, by); ctx.stroke();
          }
          ctx.restore();
        }
        // status dot + dependency links in 2D as well (same language)
        const stCol2 = overdue ? '#e11d63' : prg >= 1 ? '#16a34a' : prg > 0 ? '#d97706' : '#9ca3af';
        ctx.fillStyle = stCol2;
        ctx.beginPath(); ctx.arc(sx - 9, by + barH / 2, 3.2, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
        (task.dependsOn || []).forEach((dep) => {
          const j = byId.get(dep);
          if (j === undefined || j === i) return;
          const fromX = X(rawTasks[j]._e);
          const py = padT + j * rowH + rowH / 2;
          const cy2 = by + barH / 2;
          const hot = crit.has(i) && crit.has(j);
          const midX = Math.max(fromX + 6, sx - 14);
          ctx.save();
          ctx.strokeStyle = hot ? '#e11d63' : rgba(t.ink, 0.35);
          ctx.lineWidth = hot ? 1.8 : 1.2;
          if (!hot) ctx.setLineDash([3, 2.5]);
          ctx.beginPath();
          ctx.moveTo(fromX, py);
          ctx.lineTo(midX, py);
          ctx.lineTo(midX, cy2);
          ctx.lineTo(sx - 2, cy2);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.fillStyle = hot ? '#e11d63' : rgba(t.ink, 0.5);
          ctx.beginPath();
          ctx.moveTo(sx - 2, cy2);
          ctx.lineTo(sx - 7, cy2 - 3);
          ctx.lineTo(sx - 7, cy2 + 3);
          ctx.closePath(); ctx.fill();
          ctx.restore();
        });
      }

      if (barW > 35 && !(task.milestone || task._e - task._s <= 1)) {
        ctx.fillStyle = '#ffffff'; ctx.font = font(t, 700, 9.5); ctx.textAlign = 'center';
        ctx.fillText(`${Math.round(prg * 100)}%`, sx + pw / 2, by + barH * 0.7);
      }
      if (isCrit) {
        ctx.font = font(t, 700, 8);
        ctx.fillStyle = '#e11d63'; ctx.textAlign = 'left';
        ctx.fillText('CRITICAL', sx + barW + 6, by + barH * 0.68);
      }
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ SCATTER PLOT (2D + 3D room: floor, stems, shaded spheres) ============ */
  if (kind === 'scatter') {
    const rawScatter: ScatterPoint[] = d.scatter && d.scatter.length ? d.scatter : (
      data.map((x, i) => ({
        x: 20 + i * 8 + ((i * 13) % 19),
        y: x.value,
        label: x.label,
        size: 7 + ((i * 3) % 5),
        color: colors[i % colors.length],
      }))
    );

    const padL = 52, padR = 24, padT = 34, padB = 40;
    const plotW = W - padL - padR, plotH = H - padT - padB;
    const xs = rawScatter.map((pt) => pt.x);
    const ys = rawScatter.map((pt) => pt.y);
    const minX = Math.min(...xs, 0), maxX = Math.max(...xs, minX + 1);
    const minY = Math.min(...ys, 0), maxY = Math.max(...ys, minY + 1);

    const sOx = 16 * m, sOy = 12 * m;
    drawAxes(ctx, W, H, { l: padL, r: padR, t: padT, b: padB }, maxY, t, sOx, sOy);

    const xSteps = 5;
    ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center';
    for (let s = 0; s <= xSteps; s++) {
      const val = minX + ((maxX - minX) * s) / xSteps;
      const gx = padL + (plotW * s) / xSteps;
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      if (m > 0.02) { ctx.moveTo(gx, padT + plotH); ctx.lineTo(gx + sOx, padT + plotH - sOy); ctx.lineTo(gx + sOx, padT - sOy); }
      else { ctx.moveTo(gx, padT); ctx.lineTo(gx, padT + plotH); }
      ctx.stroke();
      ctx.fillStyle = t.axis; ctx.fillText(fmtNum(val), gx + (m > 0.02 ? sOx / 2 : 0), padT + plotH + 18);
    }
    ctx.textAlign = 'left';
    // 3D floor wash so the room reads
    if (m > 0.02) {
      ctx.fillStyle = rgba(t.ink, 0.05 * m);
      ctx.beginPath();
      ctx.moveTo(padL, padT + plotH); ctx.lineTo(padL + sOx, padT + plotH - sOy);
      ctx.lineTo(padL + plotW + sOx, padT + plotH - sOy); ctx.lineTo(padL + plotW, padT + plotH);
      ctx.closePath(); ctx.fill();
    }

    // Linear regression trendline
    if (rawScatter.length >= 2) {
      const n = rawScatter.length;
      const sumX = xs.reduce((a, b) => a + b, 0), sumY = ys.reduce((a, b) => a + b, 0);
      const sumXY = rawScatter.reduce((a, pt) => a + pt.x * pt.y, 0);
      const sumX2 = xs.reduce((a, b) => a + b * b, 0);
      const slope = (n * sumXY - sumX * sumY) / Math.max(1e-6, n * sumX2 - sumX * sumX);
      const intercept = (sumY - slope * sumX) / n;
      const px0 = padL, py0 = padT + plotH - ((intercept + slope * minX - minY) / (maxY - minY)) * plotH;
      const px1 = padL + plotW, py1 = padT + plotH - ((intercept + slope * maxX - minY) / (maxY - minY)) * plotH;
      ctx.strokeStyle = rgba(t.axis, 0.4); ctx.lineWidth = 1.5; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(px0, py0); ctx.lineTo(px1, py1); ctx.stroke();
      ctx.setLineDash([]);
    }

    // Painter's order in 3D: far (small y-value → back) first so near spheres overlap correctly
    const sOrder = rawScatter.map((_, i) => i).sort((a, b) => (m > 0.02 ? rawScatter[a].y - rawScatter[b].y : a - b));
    sOrder.forEach((i) => {
      const pt = rawScatter[i];
      const lift = m > 0.02 ? (pt.size || 7) * 0.9 * m : 0;
      const px = padL + ((pt.x - minX) / (maxX - minX)) * plotW + (m > 0.02 ? sOx * 0.5 : 0);
      const py = padT + plotH - ((pt.y - minY) / (maxY - minY)) * plotH - (m > 0.02 ? sOy * 0.5 : 0) - lift;
      const baseR = pt.size || 7;
      const rad = Math.max(1.5, baseR * Math.max(0.05, p));
      const on = hov.idx === i;
      const col = pt.color || colors[i % colors.length] || '#0d7a54';

      if (m > 0.02) {
        // drop stem from sphere to floor + contact ellipse: classic 3D scatter depth cue
        const fx = px, fy = padT + plotH - sOy * 0.35;
        ctx.strokeStyle = rgba(col, 0.45);
        ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(px, py + rad * 0.8); ctx.lineTo(fx, fy); ctx.stroke();
        ctx.fillStyle = rgba(t.ink, 0.16 * m);
        ctx.beginPath(); ctx.ellipse(fx, fy, rad * 0.85, rad * 0.32, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = rgba(col, 0.30);
        ctx.beginPath(); ctx.ellipse(fx, fy, rad * 0.55, rad * 0.2, 0, 0, Math.PI * 2); ctx.fill();
      }

      if (on) {
        ctx.strokeStyle = rgba(col, 0.5); ctx.lineWidth = 1; ctx.setLineDash([2, 2]);
        ctx.beginPath(); ctx.moveTo(padL, py); ctx.lineTo(padL + plotW, py); ctx.moveTo(px, padT); ctx.lineTo(px, padT + plotH); ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = rgba(col, 0.2); ctx.beginPath(); ctx.arc(px, py, rad + 6 + 3 * m, 0, Math.PI * 2); ctx.fill();
      }

      // shaded sphere: stronger light model in 3D + crisp specular dot
      const rr = on ? rad + 2 * hov.amt : rad;
      const r0 = Math.max(0.1, rr * 0.12);
      const g = ctx.createRadialGradient(px - rr * 0.35, py - rr * 0.4, r0, px, py, rr);
      g.addColorStop(0, shade(col, m > 0.02 ? 1.55 : 1.35));
      g.addColorStop(0.55, shade(col, on ? 1 + 0.12 * hov.amt : 1));
      g.addColorStop(1, shade(col, m > 0.02 ? 0.55 : 0.85));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, rr, 0, Math.PI * 2); ctx.fill();
      if (m > 0.02) {
        ctx.fillStyle = rgba('#ffffff', 0.85);
        ctx.beginPath(); ctx.arc(px - rr * 0.34, py - rr * 0.4, Math.max(0.8, rr * 0.16), 0, Math.PI * 2); ctx.fill();
      }
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1; ctx.stroke();
      // Labels: hovered point always; otherwise a decluttered subset —
      // greedy min-distance pass in 3D so dense clouds stay readable.
      (pt as ScatterPoint & { _lx?: number; _ly?: number })._lx = px;
      (pt as ScatterPoint & { _lx?: number; _ly?: number })._ly = py - rr - 6;
    });
    // second pass: collision-free labels (3D dense-data fix)
    const labelPts = sOrder
      .map((i) => ({ i, pt: rawScatter[i] }))
      .filter(({ pt, i }) => hov.idx === i || (m > 0.02 && pt.label && pt.label.trim().length > 0));
    const placed: { x: number; y: number; w: number }[] = [];
    ctx.font = font(t, 700, 9.5); ctx.textAlign = 'center';
    // hovered first so it always wins collisions
    labelPts.sort((a, b) => (hov.idx === b.i ? 1 : 0) - (hov.idx === a.i ? 1 : 0));
    labelPts.forEach(({ i, pt }) => {
      const on = hov.idx === i;
      const px = (pt as ScatterPoint & { _lx?: number })._lx ?? 0;
      const py = (pt as ScatterPoint & { _ly?: number })._ly ?? 0;
      const shown = fitCtx(ctx, pt.label || `(${fmtNum(pt.x)}, ${fmtNum(pt.y)})`, 90);
      const w = measureW(ctx, shown) + 8;
      if (!on) {
        for (const q of placed) {
          if (Math.abs(q.x - px) < (q.w + w) / 2 && Math.abs(q.y - py) < 13) return;
        }
        if (m <= 0.02) return; // 2D keeps hover-only labels (unchanged behaviour)
      }
      placed.push({ x: px, y: py, w });
      ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.82);
      const tw = measureW(ctx, shown);
      ctx.beginPath(); ctx.roundRect(px - tw / 2 - 4, py - 10, tw + 8, 14, 7); ctx.fill();
      ctx.fillStyle = on ? t.ink : t.axis;
      ctx.fillText(shown, px, py + 1);
    });
    return;
  }

    /* ============ STREAMGRAPH (Highcharts-style · TRUE 2D + TRUE 3D, canvas) ============
     Ground-up rebuild, no Three.js. 2D = the Highcharts streamgraph look:
     symmetric organic river, onset-ordered layers, flat solid fills, crisp
     hairline partings, hover crosshair + markers, in-stream labels, event
     flags. 3D = the SAME river as stacked glossy slabs (per-layer walls,
     rims, end caps, floor shadows) with a continuous 2D⇄3D morph. */
  if (kind === 'stream') {
    const gm = streamGeom(multi, cats, series, sColors, data, colors, activePalette(), W, H, full);
    if (!gm) return;
    const { list, labels, xs, bound, order, padT, plotH } = gm;
    const n = labels.length;
    const traceBound = (b: number[], dx = 0, dy = 0, upto = n) => {
      const lim = Math.max(2, Math.min(n, upto));
      ctx.moveTo(xs[0] + dx, b[0] + dy);
      if (lim === 2) { ctx.lineTo(xs[1] + dx, b[1] + dy); return; }
      for (let j = 0; j < lim - 1; j++) {
        const p0y = b[Math.max(0, j - 1)], p1y = b[j], p2y = b[j + 1], p3y = b[Math.min(n - 1, j + 2)];
        const p0x = xs[Math.max(0, j - 1)], p2x = xs[j + 1];
        const p1x = xs[j], p3x = xs[Math.min(n - 1, j + 2)];
        ctx.bezierCurveTo(
          p1x + dx + (p2x - p0x) / 6, p1y + dy + (p2y - p0y) / 6,
          xs[j + 1] + dx - (p3x - p1x) / 6, p2y + dy - (p3y - p1y) / 6,
          xs[j + 1] + dx, p2y + dy);
      }
    };
    const traceBoundBack = (b: number[], dx = 0, dy = 0, upto = n) => {
      const lim = Math.max(2, Math.min(n, upto));
      for (let j = lim - 1; j > 0; j--) {
        const p0y = b[Math.min(n - 1, j + 1)], p1y = b[j], p2y = b[j - 1], p3y = b[Math.max(0, j - 2)];
        const p0x = xs[Math.min(n - 1, j + 1)], p2x = xs[j - 1];
        const p1x = xs[j], p3x = xs[Math.max(0, j - 2)];
        ctx.bezierCurveTo(
          p1x + dx + (p2x - p0x) / 6, p1y + dy + (p2y - p0y) / 6,
          xs[j - 1] + dx - (p3x - p1x) / 6, p2y + dy - (p3y - p1y) / 6,
          xs[j - 1] + dx, p2y + dy);
      }
    };
    // column gridlines + rotated year axis (Highcharts has a bare plot area;
    // ours keeps the family's faint grid + the shared x-label planner).
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    xs.forEach((x) => {
      ctx.beginPath(); ctx.moveTo(x, padT - 4); ctx.lineTo(x, padT + plotH + 4); ctx.stroke();
    });
    drawXLabels(ctx, labels, gm.plan, (j) => xs[j], padT + plotH, t, W);
    const activeS = hov.seg ? hov.seg.s : (hov.idx !== null ? hov.idx : null);
    const activeC = hov.seg ? hov.seg.c : null;
    const sFocused = activeS !== null;
    const dzS = 9 * m, dyS = 7 * m;
    const upto = Math.max(2, Math.ceil(n * easeOut(p)));
    const B = bound;
    const flat = m < 0.02;
    // ---- 3D floor shadow of the whole silhouette ----
    if (!flat) {
      ctx.save();
      setShadow(ctx, 0, 7 * m + 2, 14, rgba(t.ink, 0.18 * m));
      ctx.fillStyle = rgba(t.ink, 0.10 * m);
      ctx.beginPath();
      traceBound(B[0], dzS * 0.7, -dyS * 0.7 + 10 * m, upto);
      traceBoundBack(B[B.length - 1], dzS * 0.7, -dyS * 0.7 + 10 * m, upto);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    // ---- 3D slab walls, back layer first ----
    if (!flat) {
      for (let k = order.length - 1; k >= 0; k--) {
        const si = order[k];
        const b1 = B[k + 1], b0w = B[k];
        const on = activeS === si;
        const aMul = sFocused && !on ? 1 - 0.55 * hov.amt : 1;
        ctx.save();
        ctx.globalAlpha *= aMul;
        // recessed groove along the band's lower edge (paper-cut separation)
        ctx.strokeStyle = rgba(t.ink, 0.32 * m);
        ctx.lineWidth = 5; ctx.lineCap = 'round';
        ctx.beginPath();
        traceBound(b0w, dzS * 0.55, -dyS * 0.55 + 3.5, upto);
        ctx.stroke();
        ctx.lineCap = 'butt';
        // riser wall along the band's top edge (paper side, darker)
        ctx.fillStyle = shade(list[si].color, 0.50);
        ctx.beginPath();
        traceBound(b1, dzS, -dyS, upto);
        traceBoundBack(b1, 0, 0, upto);
        ctx.closePath(); ctx.fill();
        // front wall swept toward the viewer (the visible stacked strip)
        ctx.fillStyle = shade(list[si].color, 0.44);
        ctx.beginPath();
        traceBound(b0w, 0, 0, upto);
        traceBoundBack(b0w, dzS, -dyS + 4, upto);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = rgba(shade(list[si].color, 0.32), 0.9);
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        traceBound(b0w, dzS, -dyS + 4, upto);
        ctx.stroke();
        // bright rim where the riser meets the top skin
        ctx.strokeStyle = rgba('#ffffff', 0.55 * m);
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        traceBound(b1, dzS, -dyS, upto);
        ctx.stroke();
        // second inner rim: the card's cut edge catching the light
        ctx.strokeStyle = rgba('#ffffff', 0.28 * m);
        ctx.lineWidth = 1;
        ctx.beginPath();
        traceBound(b1, dzS * 0.45, -dyS * 0.45 + 1.5, upto);
        ctx.stroke();
        // end cap at the final column + toe shadow
        const ex = xs[Math.min(n - 1, upto - 1)];
        const yT = b1[Math.min(n - 1, upto - 1)], yB = b0w[Math.min(n - 1, upto - 1)];
        ctx.fillStyle = shade(list[si].color, 0.5);
        ctx.beginPath();
        ctx.moveTo(ex, yT); ctx.lineTo(ex + dzS, yT - dyS);
        ctx.lineTo(ex + dzS, yB - dyS); ctx.lineTo(ex, yB);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = rgba(t.ink, 0.12 * m);
        ctx.beginPath();
        ctx.moveTo(ex, yB); ctx.lineTo(ex + dzS, yB - dyS);
        ctx.lineTo(ex + dzS + 3, yB - dyS + 3); ctx.lineTo(ex + 3, yB + 3);
        ctx.closePath(); ctx.fill();
        ctx.restore();
      }
    }
    // ---- faces: bottom layer first so upper layers overlap naturally ----
    const labelJobs: { si: number; dim: number; cx: number; x: number; w: number }[] = [];
    order.forEach((si) => {
      const k = order.indexOf(si);
      const b0 = B[k], b1 = B[k + 1];
      const on = activeS === si;
      const dim = sFocused && !on ? 1 - 0.62 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= dim;
      if (flat) {
        // Highcharts streamgraph: flat solid colour, gentle brighten on hover
        ctx.fillStyle = shade(list[si].color, on ? 1 + 0.14 * hov.amt : 1);
        ctx.globalAlpha *= 0.92;
      } else {
        // paper-cut 3D (reference look): each band is a thin card with a
        // bright LIT top skin, a saturated core and a deep paper edge; the
        // ramp is LOCAL to this band so every layer reads separately.
        const jm = Math.floor(n / 2);
        const gTop = b1[jm], gBot = Math.max(gTop + 2, b0[jm]);
        const grad = ctx.createLinearGradient(0, gTop, 0, gBot);
        const lift = on ? 0.10 * hov.amt : 0;
        grad.addColorStop(0, shade(list[si].color, 1.34 + lift));
        grad.addColorStop(0.28, shade(list[si].color, 1.10 + lift));
        grad.addColorStop(0.62, shade(list[si].color, 0.92));
        grad.addColorStop(1, shade(list[si].color, 0.62));
        ctx.fillStyle = grad;
      }
      ctx.beginPath();
      traceBound(b1, 0, 0, upto);
      traceBoundBack(b0, 0, 0, upto);
      ctx.closePath(); ctx.fill();
      ctx.restore();
      // crisp parting line between bands (+ white halo on the hovered layer)
      ctx.save();
      ctx.globalAlpha *= dim;
      ctx.strokeStyle = flat ? rgba('#ffffff', 0.85) : rgba('#ffffff', 0.7);
      ctx.lineWidth = flat ? 1.5 : 1;
      ctx.beginPath();
      traceBound(b1, 0, 0, upto);
      ctx.stroke();
      if (on) {
        ctx.strokeStyle = rgba('#ffffff', 0.95);
        ctx.lineWidth = flat ? 2.5 : 2;
        ctx.beginPath();
        traceBound(b1, 0, 0, upto);
        ctx.stroke();
      }
      ctx.restore();
      // in-stream label candidate at the layer's widest column
      let wj = 0, ww = -1;
      for (let j = 0; j < n; j++) { const w = b0[j] - b1[j]; if (w > ww) { ww = w; wj = j; } }
      labelJobs.push({ si, dim, cx: (b0[wj] + b1[wj]) / 2, x: xs[wj], w: ww });
    });
    // ---- Highcharts crosshair: vertical line + per-layer markers + total ----
    if (activeC !== null && activeC >= 0 && activeC < n && p > 0.9) {
      const j = activeC;
      const fx = xs[j];
      const yTop = Math.min(...B.map((b) => b[j]));
      const yBot = Math.max(...B.map((b) => b[j]));
      ctx.save();
      ctx.strokeStyle = rgba(t.ink, 0.45);
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(fx, yTop - 8); ctx.lineTo(fx, padT + plotH + 2); ctx.stroke();
      ctx.setLineDash([]);
      // markers on every visible layer boundary at this column
      order.forEach((si) => {
        const k = order.indexOf(si);
        if (k < 0) return;
        const yT = B[k + 1][j], yB = B[k][j];
        if (yB - yT < 3) return;
        const mid = (yT + yB) / 2;
        ctx.fillStyle = list[si].color;
        ctx.beginPath(); ctx.arc(fx, mid, si === activeS ? 4.2 : 3, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
      });
      // total chip above the river
      const tot = gm.totals[j] || 0;
      const tTxt = `${labels[j]} · ${fmtNum(tot)}`;
      ctx.font = font(t, 700, 10.5);
      const tw = measureW(ctx, tTxt);
      const chx = Math.max(tw / 2 + 8, Math.min(W - tw / 2 - 8, fx));
      const chy = Math.max(16, yTop - 14);
      ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
      ctx.strokeStyle = rgba(t.ink, 0.22); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(chx - tw / 2 - 7, chy - 11, tw + 14, 18, 9); ctx.fill(); ctx.stroke();
      ctx.fillStyle = t.ink; ctx.textAlign = 'center';
      ctx.fillText(tTxt, chx, chy + 2);
      ctx.restore();
    }
    // ---- in-stream labels: widest bands win, never overlap ----
    // Reference look: white pills with ink text floating ON the band.
    labelJobs.sort((a, b) => b.w - a.w);
    const taken: { x0: number; x1: number; y0: number; y1: number }[] = [];
    labelJobs.forEach(({ si, dim, cx, x, w }) => {
      if (w < 22 || p <= 0.9) return;
      const flat = m < 0.02;
      const fs = w > 44 ? (full ? 12 : 11.5) : 10;
      ctx.font = font(t, 700, fs);
      const nm = fitCtx(ctx, list[si].name, Math.max(44, plotH / 6));
      const tw = measureW(ctx, nm);
      const pwP = tw + 16, phP = fs + 8;
      const box = { x0: x - pwP / 2, x1: x + pwP / 2, y0: cx - phP / 2, y1: cx + phP / 2 };
      if (box.x0 < 6 || box.x1 > W - 6) return;
      for (const q of taken) {
        if (box.x0 < q.x1 && box.x1 > q.x0 && box.y0 < q.y1 && box.y1 > q.y0) return;
      }
      taken.push(box);
      ctx.save();
      ctx.globalAlpha *= dim;
      ctx.font = font(t, 700, fs);
      ctx.textAlign = 'center';
      if (flat) {
        // 2D: white pill + ink text (reference look)
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.20)'; ctx.shadowBlur = 4; ctx.shadowOffsetY = 1;
        ctx.fillStyle = 'rgba(255,255,255,0.95)';
        ctx.beginPath(); ctx.roundRect(box.x0, box.y0, pwP, phP, phP / 2); ctx.fill();
        ctx.restore();
        ctx.fillStyle = shade(list[si].color, 0.55);
        ctx.fillText(nm, x, cx + fs * 0.35);
      } else {
        // 3D: ink-on-frost pill so it reads over the glossy skin
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.30)'; ctx.shadowBlur = 5; ctx.shadowOffsetY = 2;
        ctx.fillStyle = 'rgba(255,255,255,0.92)';
        ctx.beginPath(); ctx.roundRect(box.x0, box.y0, pwP, phP, phP / 2); ctx.fill();
        ctx.restore();
        ctx.fillStyle = shade(list[si].color, 0.45);
        ctx.fillText(nm, x, cx + fs * 0.35);
      }
      ctx.restore();
    });
    // ---- event flags: default to the salary-story events when the dataset
    // carries none (built-in demo), staggered bubble lanes above the river ----
    const evts = ((d.streamEvents && d.streamEvents.length ? d.streamEvents : STREAM_SALARY_10Y.events).filter((e) => e.at >= 0 && e.at < n));
    const riverTopAt = (j: number) => Math.min(...B.map((b) => b[Math.max(0, Math.min(n - 1, j))]));
    const riverBotAt = (j: number) => Math.max(...B.map((b) => b[Math.max(0, Math.min(n - 1, j))]));
    const placedEv: { x0: number; x1: number; lane: number }[] = [];
    evts.forEach((e) => {
      const jj0 = Math.round(e.at);
      const fx = xs[jj0];
      ctx.save();
      // anchor dot sits ON the river's top surface (never floating above it)
      const surfY = riverTopAt(jj0);
      const botY = riverBotAt(jj0);
      const anchorY = Math.max(padT + 2, Math.min(padT + plotH - 2, surfY));
      void botY;
      ctx.strokeStyle = rgba(t.ink, 0.4); ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(fx, anchorY); ctx.lineTo(fx, padT - 6); ctx.stroke();
      ctx.setLineDash([]);
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.25)'; ctx.shadowBlur = 3;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(fx, anchorY, 4, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      ctx.fillStyle = t.ink;
      ctx.beginPath(); ctx.arc(fx, anchorY, 2.4, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(fx, anchorY, 1, 0, Math.PI * 2); ctx.fill();
      ctx.font = font(t, 600, 10);
      const words = e.label.split(' ');
      const lines: string[] = [];
      let cur = '';
      words.forEach((w) => {
        const trial = cur ? cur + ' ' + w : w;
        if (measureW(ctx, trial) > 132 && cur) { lines.push(cur); cur = w; } else cur = trial;
      });
      if (cur) lines.push(cur);
      const bh = lines.length * 13 + 12;
      const bw = Math.min(150, Math.max(...lines.map((l) => measureW(ctx, l))) + 18);
      let bx = fx - bw / 2;
      bx = Math.max(4, Math.min(W - bw - 4, bx));
      let lane = 0;
      for (;;) {
        const y0 = padT - 10 - bh - lane * (bh + 8);
        const clash = placedEv.some((q) => bx < q.x1 && bx + bw > q.x0 && Math.abs(y0 - (padT - 10 - bh - q.lane * (bh + 8))) < bh + 6);
        if (!clash || lane > 2) break;
        lane++;
      }
      placedEv.push({ x0: bx, x1: bx + bw, lane });
      const byTop = Math.max(4, padT - 10 - bh - lane * (bh + 8));
      ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
      ctx.strokeStyle = rgba(t.ink, 0.25); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(bx, byTop, bw, bh, 7); ctx.fill(); ctx.stroke();
      const tailX = Math.max(bx + 10, Math.min(bx + bw - 10, fx));
      ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
      ctx.beginPath();
      ctx.moveTo(tailX - 5, byTop + bh - 0.5);
      ctx.lineTo(tailX + 5, byTop + bh - 0.5);
      ctx.lineTo(tailX, byTop + bh + 6);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = t.ink; ctx.textAlign = 'left';
      lines.forEach((l, li) => ctx.fillText(l, bx + 9, byTop + 14 + li * 13));
      ctx.restore();
      if (activeS !== null && p > 0.9) {
        const si = activeS;
        const k = order.indexOf(si);
        if (k >= 0) {
          const jj = Math.round(e.at);
          const yT = B[k + 1][jj], yB = B[k][jj];
          if (yB - yT > 8) {
            const vy = (yT + yB) / 2;
            const label = fmtNum(list[si].values[jj] || 0);
            ctx.save();
            ctx.font = font(t, 700, 10);
            const tw = measureW(ctx, label);
            const cxp = Math.max(tw / 2 + 8, Math.min(W - tw / 2 - 8, fx));
            ctx.fillStyle = rgba(list[si].color, 0.95);
            ctx.beginPath(); ctx.roundRect(cxp - tw / 2 - 6, vy - 10, tw + 12, 17, 8); ctx.fill();
            ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
            ctx.fillText(label, cxp, vy + 2.5);
            ctx.restore();
          }
        }
      }
    });
    ctx.textAlign = 'left';
    return;
  }

/* ============ FUNNEL / PYRAMID (2D + 3D) ============ */
  if (kind === 'funnel' || kind === 'pyramid') {
    const g = funnelGeom(W, H, m, data, full, kind === 'pyramid');
    const { ch, plotW, sq, topY, cx, laneX } = g;
    const heights = data.map((x) => (x.value / total) * ch * p);
    const sumH = heights.reduce((a, b) => a + b, 0);
    const widthAt = (rel: number) => kind === 'funnel'
      ? plotW * (0.96 - 0.66 * (rel / ch))
      : plotW * (0.96 * (rel / ch)); // pyramid: true point at the top
    ctx.font = font(t, 600, 10.5);
    // label rows: pushed apart so thin segments never overlap, then pulled
    // back inside the plot from the bottom
    const rows: number[] = [];
    { let yy = topY + (ch - sumH); heights.forEach((h) => { rows.push(yy + h / 2); yy += h; }); }
    const PITCH = 14;
    for (let i = 1; i < rows.length; i++) rows[i] = Math.max(rows[i], rows[i - 1] + PITCH);
    const floor = Math.min(H - 8, topY + ch + 18);
    for (let i = rows.length - 1; i >= 0; i--) rows[i] = Math.min(rows[i], i === rows.length - 1 ? floor : rows[i + 1] - PITCH);
    let y = topY + (ch - sumH);
    data.forEach((x, i) => {
      const h = heights[i];
      const rel0 = y - topY;
      const w0 = widthAt(rel0), w1 = widthAt(rel0 + h);
      const on = hov.idx === i;
      const col = on ? shade(colors[i], 1 + 0.12 * hov.amt) : colors[i];
      if (kind === 'funnel' && m > 0.02) {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.ellipse(cx, y + h, Math.max(0.1, w1 / 2), Math.max(0.1, (w1 / 2) * sq), 0, Math.PI, 0, true);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.ellipse(cx, y, Math.max(0.1, w0 / 2), Math.max(0.1, (w0 / 2) * sq), 0, 0, Math.PI, false);
        ctx.closePath(); ctx.fill();
        if (i === 0) {
          ctx.fillStyle = shade(colors[i], 1.22);
          ctx.beginPath(); ctx.ellipse(cx, y, Math.max(0.1, w0 / 2), Math.max(0.1, (w0 / 2) * sq), 0, 0, Math.PI * 2); ctx.fill();
        }
      } else if (kind === 'pyramid' && m > 0.005) {
        // side face grows with the morph — no jump at the 2D/3D boundary
        const dxr = (w: number) => w * 0.2 * m, dyr = (w: number) => w * 0.075 * m;
        ctx.fillStyle = shade(colors[i], 0.72);
        ctx.beginPath();
        ctx.moveTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w0 / 2 + dxr(w0), y - dyr(w0));
        ctx.lineTo(cx + w1 / 2 + dxr(w1), y + h - dyr(w1));
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        if (m < 0.98) { ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke(); }
      } else {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        if (m < 0.98) { ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke(); }
      }
      // leader — attached at the segment's true mid-width edge, head fully outside
      const midY = y + h / 2;
      const rowY = rows[i];
      const wMid = widthAt(rel0 + h / 2);
      // anchor on the shape's true silhouette: the front edge in 2D, the side face's
      // outer edge in 3D (blended through the morph). The head is entirely outside it.
      const edgeX = cx + wMid / 2 + (kind === 'pyramid' ? wMid * 0.2 * m : 0);
      const edgeY = midY - (kind === 'pyramid' ? wMid * 0.075 * m : 0);
      // every leader turns in one shared vertical lane just right of the widest
      // part of the shape (incl. the 3D side face), then runs to its label row
      const textX = laneX + 16;
      // arrowhead scales with the segment but never below a legible 2.2px half-height
      const ah = Math.min(3.8, Math.max(2.2, h / 2 - 0.5)), al = Math.max(4.5, ah * 2);
      ctx.strokeStyle = colors[i];
      ctx.lineWidth = 1.3;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(edgeX + al, edgeY);
      if (Math.abs(rowY - edgeY) > 0.5) { ctx.lineTo(Math.max(edgeX + al + 4, laneX - 6), edgeY); ctx.lineTo(laneX, rowY); }
      ctx.lineTo(textX - 6, rowY);
      ctx.stroke();
      ctx.lineJoin = 'miter';
      ctx.fillStyle = colors[i];
      ctx.beginPath();
      ctx.moveTo(edgeX + 0.5, edgeY);
      ctx.lineTo(edgeX + al + 0.5, edgeY - ah);
      ctx.lineTo(edgeX + al + 0.5, edgeY + ah);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 0.8; ctx.stroke();
      ctx.fillStyle = t.ink;
      ctx.textAlign = 'left';
      const text = funnelLabel(x, total);
      ctx.fillText(full ? text : fitCtx(ctx, text, W - textX - 4), textX, rowY + 3.5);
      y += h;
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ TOROID DONUT (ported from chart.html drawTorus/renderDonut) ============
     TRUE toroidal torus on canvas: quads sorted back-to-front by depth, tube
     cross-section lit by a fixed light dir (ambient + diffuse + pow6 spec),
     hovered segment inflates IN PLACE (tube radius r×1.32, ring radius R
     stays put — never a pulled-out / R+9 slice), divider lines, glowing
     centre orb, radial leader labels + centre total — same structure,
     in-place hover expansion and tilt (0.52) as the reference.
     Colors: glossy Sankey-3D family (TOROID_GLOSS), tilt eases 0→0.52 with m
     so 2D⇄3D is a smooth morph, never a jump. */
  if (kind === 'toroid') {
    /* ---- intelligent ambient: why light mode looked "dull" ----
       The torus is lit by ambient + diffuse + spec. The old model used a
       fixed low ambient (0.28) tuned for dark tiles, where deep shading
       reads as richness. On a bright tile the same deep falloff turns every
       tube's underside near-black — high-contrast mud, read as "dull".
       Fix: sense the tile mood (theme dark/light + card luminance) and
       re-balance the whole rig — bright tiles get a lifted, hue-holding
       ambient + gentler diffuse falloff + reined-in spec, dark tiles keep
       the dramatic rig. Same model, same code path, always well-dressed. */
    const PI2 = Math.PI * 2;
    const moodLight = !t.dark;
    const amb = moodLight ? 0.62 : 0.28;      // base fill
    const dif = moodLight ? 0.42 : 0.72;      // diffuse strength (soft falloff on light)
    const spec = moodLight ? 0.34 : 0.60;     // spec stays a kiss, not a blowout
    const liftFloor = moodLight ? 0.30 : 0.0; // undersides keep hue, never near-black
    const tilt = 0.52 * m;
    // fixed diameter across the morph: sized once, only tilts afterwards
    const g0 = circGeom(W, H, 0, data, full);
    const cx = g0.cx, cy = g0.cy;
    const R = Math.max(40, g0.R * 0.78);
    const r = Math.max(14, R * 0.34);
    // perf: adaptive resolution — quad counts follow ON-SCREEN tube pixels,
    // not the container width. Small tiles stop paying for invisible slices;
    // fullscreen still renders buttery. (See cache bubble below for the
    // static-frame reuse that makes hover-only repaints cheap.)
    const tubePx = r * 2;
    const fine = tubePx * (full ? 2.2 : 1.35);
    const isSvg = typeof (ctx as unknown as { els?: unknown }).els !== 'undefined';
    // EXPORT SMOOTHNESS: exports render once, so they get the smoothest
    // possible surface — a far denser facet mesh than any live frame needs
    // (PNG/PDF compose at 3x; SVG emits fine vector facets).
    const exportHiRes = !isSvg && !!d.bg;
    // True-SVG path: rather than a bespoke geometry, SVG export reuses the
    // EXACT same `paintTube` quad-strip painter as the live canvas (see
    // below) — every quad connects TWO adjacent ring-angle cross-sections
    // (a "top" ring and a "bottom" ring of tube-profile points), so the
    // surface is always continuous. GEOMETRY-CORRECTNESS FIX: an earlier
    // version drew ONE STANDALONE cross-section "bead" per ring sample
    // instead of a connecting quad. At ring angles where the torus's
    // tilt-squash projection happens to compress that lone bead's own two
    // basis directions onto nearly the same screen axis (a real projection
    // degeneracy of this tilt model, not a texture problem), an isolated
    // bead collapses to a thin sliver — the "small grey dash lines" seen
    // in the export. A connecting QUAD never has this failure mode: even
    // if one of its two edges is momentarily thin, the strip still has
    // real area contributed by the neighbouring, non-degenerate edge, so
    // the surface stays solid everywhere. FILE-SIZE FIX: resolution is
    // capped low enough for SVG (unlike the live canvas, which can afford
    // very fine steps) that the exported quad count stays in the low
    // hundreds — each quad is one small flat-filled path with no
    // separate stroke — keeping the file in the tens of KB while still
    // reading as a smooth, continuously round tube.
    // SVG-ONLY SMOOTHNESS BUMP: the PNG/PDF exports (and the live canvas)
    // were already smooth — only the SVG's quad-strip mesh still read a
    // touch faceted. The tube's ROUND cross-section (tubeSteps, below) is
    // what most affects perceived smoothness, so it gets the bigger bump;
    // ringSteps is nudged up too. Quad count stays ring×tube ≈ ≤960, which
    // keeps the file comfortably under 100 KB.
    // toroid_donut_cascade.html: RING_STEPS=360, TUBE_STEPS=64 ("always maximum smoothness")
    const ringSteps = isSvg ? 240 : 360;
    // Export bodies render at the LIVE transform scale (composeExport = 3x),
    // so exports always resolve MORE tube bands than the screen — smoother
    // surface at export size, same silhouette (bands are pure shading).
    const liveScaleNow = (() => {
      try { return Math.max(1, (ctx as CanvasRenderingContext2D).getTransform?.().a || 1); }
      catch { return 1; }
    })();
    const exportBoost = !isSvg && d.bg && liveScaleNow > 1.5 ? 2.2 : 1;
    const tubeSteps = isSvg ? 48 : 64;
    const rot = -Math.PI / 2 + (d.toroidRot || 0); // idle spin from cascade.html dRot
    // perf: module-level texture cache — the torus body is invariant in
    // (W,H,p,m,theme,data) space, so hover-only frames repaint from cache
    // and pay JUST the hovered slice. Key rounds floats to kill jitter.
    const torKey = [
      kind, Math.round(W), Math.round(H), Math.round(p * 1000), Math.round(m * 500),
      Math.round((d.toroidRot || 0) * 200),
      t.dark ? 'd' : 'l', full ? 'f' : 'c', isSvg ? 's' : 'r', data.map((x) => x.value).join(','), colors.join(','),
    ].join('|');
    type TorCache = {
      body: HTMLCanvasElement | null; bodyScale: number; staticQuads: { a0: number; a1: number; depth: number }[];
      ringSteps: number; tubeSteps: number; cx: number; cy: number; R: number; r: number;
      tilt: number; rot: number; moodLight: boolean; amb: number; dif: number; spec: number; liftFloor: number;
      /** perf: tube cross-section sin/cos table, built ONCE per cache key —
       * `paintTube` used to rebuild this from scratch on every single call,
       * including every animation frame of a hover pop (the main
       * contributor to the hover feeling sluggish, alongside the frame's
       * genuine facet-fill cost). Reusing it cuts real per-frame CPU work. */
      phiCos: number[]; phiSin: number[];
    };
    const tc = (paintChart as unknown as { _tor?: { key: string; c: TorCache } })._tor;
    let cache: TorCache;
    if (tc && tc.key === torKey) {
      cache = tc.c;
    } else {
      // Static quad projection (centreline + depth + per-facet lighting is
      // all camera-invariant here — only the hover slice repaints live).
      interface TSegT { aStart: number; aEnd: number; color: string; i: number }
      const segsT: TSegT[] = [];
      {
        let acc = 0;
        data.forEach((x, i) => {
          const frac = (x.value / total) * PI2;
          segsT.push({ aStart: acc, aEnd: acc + frac, color: colors[i], i });
          acc += frac;
        });
      }
      interface TQ { a0: number; a1: number; depth: number; seg: TSegT }
      const quadsT: TQ[] = [];
      const cosT = Math.cos(tilt);
      for (let si = 0; si < ringSteps; si++) {
        const a0 = (PI2 * si) / ringSteps;
        const a1 = (PI2 * (si + 1)) / ringSteps;
        const aMid = (a0 + a1) / 2;
        let seg = segsT[segsT.length - 1];
        for (let q = 0; q < segsT.length; q++) {
          if (aMid >= segsT[q].aStart && aMid < segsT[q].aEnd) { seg = segsT[q]; break; }
        }
        const ca = aMid + rot;
        quadsT.push({ a0, a1, depth: R * Math.sin(ca) * cosT, seg });
      }
      quadsT.sort((a, b) => a.depth - b.depth);
      const phiCosInit: number[] = [], phiSinInit: number[] = [];
      for (let k = 0; k < tubeSteps; k++) { const phi = (PI2 * k) / tubeSteps; phiCosInit.push(Math.cos(phi)); phiSinInit.push(Math.sin(phi)); }
      cache = {
        body: null,
        bodyScale: 1,
        staticQuads: quadsT.map((q) => ({ a0: q.a0, a1: q.a1, depth: q.depth })),
        ringSteps, tubeSteps, cx, cy, R, r, tilt, rot, moodLight, amb, dif, spec, liftFloor,
        phiCos: phiCosInit, phiSin: phiSinInit,
      };
      // cache full slices too (typed via closure, stored on the cache obj)
      (cache as TorCache & { segs?: { aStart: number; aEnd: number; color: string; i: number }[] }).segs = segsT.map((s) => ({ ...s }));
      (paintChart as unknown as { _tor?: { key: string; c: TorCache } })._tor = { key: torKey, c: cache };
    }
    const cachedSegs = (cache as TorCache & { segs?: { aStart: number; aEnd: number; color: string; i: number }[] }).segs || [];
    const segOf = (q: { a0: number; a1: number }) => {
      const aMid = (q.a0 + q.a1) / 2;
      let seg = cachedSegs[cachedSegs.length - 1];
      for (let qi = 0; qi < cachedSegs.length; qi++) {
        if (aMid >= cachedSegs[qi].aStart && aMid < cachedSegs[qi].aEnd) { seg = cachedSegs[qi]; break; }
      }
      return seg;
    };
    const LD = { x: 0.4, y: -0.6 };
    const cosTilt = Math.cos(tilt), sinTilt = Math.sin(tilt);
    const rgbCache = new Map<string, [number, number, number]>();
    const rgbOf = (c: string): [number, number, number] => {
      let hit = rgbCache.get(c);
      if (!hit) { const pc = parseColor(c) || [128, 128, 128, 1]; hit = [pc[0], pc[1], pc[2]]; rgbCache.set(c, hit); }
      return hit;
    };
    // perf: pre-computed shade ramps — hovering never re-parses/shades per
    // facet; the eased amt lerps between the two endpoints instead.
    const hovA = hov.amt;
    const cascadeT = p;
    const easeOutBackC = (tt: number) => { const c1 = 1.70158; return 1 + (c1 + 1) * Math.pow(tt - 1, 3) + c1 * Math.pow(tt - 1, 2); };
    const segFactor = (i: number) => {
      if (cascadeT >= 0.999) return 1;
      const raw = Math.max(0, Math.min(1, (cascadeT * 28 - i) / 3));
      return Math.max(0, easeOutBackC(raw));
    };
    const paintTube = (
      c2d: Ctx, rEff: number, rEff2: number, isHover: boolean, amt: number,
      hovSeg: number | null, alphaMul: number,
      layer: 'all' | 'overlay' = 'all', overlayMinD = -Infinity,
    ) => {
      const { phiCos, phiSin } = cache;
      for (const q of cache.staticQuads) {
        const { a0, a1 } = q;
        const seg = segOf(q);
        const factor = segFactor(seg.i);
        if (factor < 0.02) continue;
        const hov2 = isHover && seg.i === hovSeg;
        // Hover overlay: skip resting quads that sit BEHIND the hovered
        // slice (already in the cached body blit). Keep the hovered
        // slice (inflated) and any resting quads in front of it so the
        // torus wall still occludes correctly — same in-place expansion,
        // far fewer fills per frame.
        if (layer === 'overlay' && !hov2 && q.depth < overlayMinD) continue;
        const rE = (hov2 ? rEff : cache.r) * factor;
        const rE2 = hov2 ? rEff2 : cache.R;
        // seam fix (Fix #4): each quad overlaps the next by half a slice so
        // adjacent facets share an edge — no hairline of tile background can
        // ever show through at segment joints (the "small white lines").
        const a1o = a1;
        const top: { x: number; y: number }[] = [], bot: { x: number; y: number }[] = [];
        ([a0, a1o] as const).forEach((ta) => {
          const cosA = Math.cos(ta + cache.rot), sinA = Math.sin(ta + cache.rot);
          const arr = ta === a0 ? top : bot;
          for (let k = 0; k < cache.tubeSteps; k++) {
            const rad = rE2 + rE * phiCos[k];
            arr.push({ x: cache.cx + rad * cosA, y: cache.cy + rad * sinA * cosTilt + rE * phiSin[k] * sinTilt });
          }
        });
        const ca = (a0 + a1) / 2 + cache.rot;
        const [r1, g1, b1] = rgbOf(seg.color);
        const ambient = (hov2 ? cache.amb + 0.12 : cache.amb) * alphaMul;
        for (let k = 0; k < cache.tubeSteps; k++) {
          const k2 = (k + 1) % cache.tubeSteps;
          const phiMid = (PI2 * (k + 0.5)) / cache.tubeSteps;
          const ld = Math.max(0, Math.cos(phiMid) * Math.cos(ca) * LD.x + (Math.cos(phiMid) * Math.sin(ca) * cosTilt + Math.sin(phiMid) * sinTilt) * LD.y);
          let ll = ambient + cache.dif * ld;
          if (cache.liftFloor) ll = Math.max(ll, cache.liftFloor + cache.dif * ld * 0.4);
          let ls = Math.pow(ld, 6) * cache.spec;
          if (hov2) { ll *= 1 + 0.2 * amt; ls *= 1 + 0.35 * amt; }
          c2d.fillStyle = `rgb(${Math.min(255, Math.round(r1 * ll + ls * 255))},${Math.min(255, Math.round(g1 * ll + ls * 255))},${Math.min(255, Math.round(b1 * ll + ls * 255))})`;
          c2d.beginPath();
          c2d.moveTo(top[k].x, top[k].y);
          c2d.lineTo(top[k2].x, top[k2].y);
          c2d.lineTo(bot[k2].x, bot[k2].y);
          c2d.lineTo(bot[k].x, bot[k].y);
          c2d.closePath();
          c2d.fill();
        }
      }
    };
    // Hover expansion happens IN PLACE on the torus axis: the tube swells
    // symmetrically around its own centreline (radius r only) — the ring
    // radius R NEVER moves, is never passed as rEff2, and there is NO
    // radial pull / vertical lift, so the piece grows exactly where it sits
    // instead of floating off-axis like a pulled-out slice.
    const hovR = r * (1 + 0.32 * hovA);
    const hovRingR = R; // ring radius is invariant on hover (in-place, not extracted)
    const canCache = !isSvg && typeof document !== 'undefined' && typeof (ctx as CanvasRenderingContext2D).drawImage === 'function';
    const hoverOn = hov.idx !== null && hovA > 0.01;
    // Static body: render ONCE per (geometry+theme+data+scale) into an
    // offscreen bitmap; every non-hover frame (and same-size exports)
    // reuses it. Scale is part of validity: a live-DPR body must never
    // serve a 3x export (or vice versa). Pulled out into its own function
    // (perf fix below) so the fast hover-redraw path can also guarantee a
    // fresh bitmap exists to blit from, without duplicating this logic.
    const ensureBody = () => {
      const liveScale = (() => {
        try {
          const t2 = (ctx as CanvasRenderingContext2D).getTransform();
          return Math.max(1, t2.a || 1);
        } catch { return (typeof window !== 'undefined' && window.devicePixelRatio) || 1; }
      })();
      if (!cache.body || cache.bodyScale !== liveScale) {
        const off = document.createElement('canvas');
        // Crisp-PNG fix: key the bitmap scale to the LIVE transform (DPR ×
        // export scale), not window DPR. composeExport renders at scale=3,
        // so export bodies need 3x pixels or the torus downsamples blurry.
        off.width = Math.max(1, Math.round(W * liveScale));
        off.height = Math.max(1, Math.round(H * liveScale));
        const octx = off.getContext('2d')!;
        octx.setTransform(liveScale, 0, 0, liveScale, 0, 0);
        paintTube(octx as unknown as Ctx, r, R, false, 0, null, 1);
        cache.body = off;
        cache.bodyScale = liveScale;
      }
      return cache.body;
    };
    if (isSvg) {
      // SVG must use the SAME connecting-quad tube as the live canvas.
      // An earlier "stroked ellipse + radialGradient" shortcut flattened
      // the torus into a 2D ring (wrong silhouette, no tube lighting, and
      // SvgCtx's elliptical-arc sweep did not match the painter's tilt),
      // so exports disagreed with the on-screen chart. paintTube emits
      // true vector facets through SvgCtx's path/fill — geometry, depth
      // sort and per-facet lighting identical to the live tile.
      paintTube(ctx, r, R, false, 0, null, 1);
    } else if (!canCache || p < 0.999 || Math.abs(d.toroidRot || 0) > 0.0005) {
      // Cascade + idle spin: live paint every frame (HTML drawTorus path).
      paintTube(ctx, hovR, hovRingR, true, hovA, hoverOn && hov.idx !== null ? hov.idx : null, 1);
    } else if (hoverOn && hov.idx !== null) {
      // IN-PLACE hover, depth-correct AND cheap: blit the cached resting
      // body, then overpaint only (a) the hovered slice inflated around
      // its own centreline and (b) resting quads in front of it so the
      // torus wall still occludes the swell. Same motion as a full live
      // repaint — no radial pull — without filling every facet 60×/s.
      const body = ensureBody();
      (ctx as CanvasRenderingContext2D).drawImage(body, 0, 0, W, H);
      let overlayMin = Infinity;
      for (const q of cache.staticQuads) {
        if (segOf(q).i === hov.idx) overlayMin = Math.min(overlayMin, q.depth);
      }
      paintTube(ctx, hovR, hovRingR, true, hovA, hov.idx, 1, 'overlay', overlayMin);
    } else {
      (ctx as CanvasRenderingContext2D).drawImage(ensureBody(), 0, 0, W, H);
    }
    // No divider ticks — stroking joints on the torus read as grey
    // dashes across the tube (see greydashonthetoroidDonut.png). Segment
    // boundaries already come from the per-quad colour change.
    // glowing centre orb + total
    if (p > 0.5) {
      const orbR = r * 0.72;
      const og = ctx.createRadialGradient(cx, cy, 0, cx, cy, orbR);
      if (t.dark) {
        og.addColorStop(0, 'rgba(120,160,255,1)');
        og.addColorStop(0.4, 'rgba(80,100,220,0.9)');
        og.addColorStop(0.85, 'rgba(40,60,180,0.5)');
        og.addColorStop(1, 'rgba(20,30,120,0)');
      } else {
        og.addColorStop(0, 'rgba(255,255,255,1)');
        og.addColorStop(0.45, 'rgba(210,228,255,0.95)');
        og.addColorStop(0.85, 'rgba(170,200,250,0.55)');
        og.addColorStop(1, 'rgba(150,180,240,0)');
      }
      ctx.beginPath(); ctx.arc(cx, cy, orbR, 0, PI2); ctx.fillStyle = og; ctx.fill();
    }
    if (p > 0.95) drawLeaders(ctx, cx, cy, R + r * 0.9, cosTilt, data, colors, total, t, W, H, false, full, d.toroidRot || 0);
    if (p > 0.85) {
      ctx.fillStyle = t.ink;
      ctx.font = font(t, 700, 16, true);
      ctx.textAlign = 'center';
      ctx.fillText(String(total), cx, cy + 5);
      ctx.textAlign = 'left';
    }
    return;
  }

  /* ============ PIE / DONUT (2D ⇄ 3D morph) ============ */
  const g = circGeom(W, H, m, data, full);
  const { cx, cy, R: R0, depth, squash } = g;
  const rIn = kind === 'donut' ? R0 * g.rInRatio : 0;

  interface Seg { a0: number; a1: number; i: number }
  let a = -Math.PI / 2;
  const segs: Seg[] = data.map((x, i) => {
    const a1 = a + (x.value / total) * Math.PI * 2 * p;
    const s = { a0: a, a1, i };
    a = a1;
    return s;
  });
  // hover: the slice pops radially outward along its true angle vector from the center
  const hovAmt = (s: Seg) => (hov.idx === s.i ? hov.amt : 0);
  const pullOf = (s: Seg) => 14 * hovAmt(s);                 // radial pop along the bisector angle
  const px = (ang: number, r: number) => cx + Math.cos(ang) * r;
  const py = (ang: number, r: number) => cy + Math.sin(ang) * r * squash;
  const OVER = 0.012;
  // per-slice translation (dx, dy) in screen space: pure radial along angle vector
  const offsetOf = (s: Seg): [number, number] => {
    const a = hovAmt(s);
    if (!a) return [0, 0];
    const mid = (s.a0 + s.a1) / 2, pull = pullOf(s);
    const offset = radialOffset(mid, pull, squash);
    return [offset.x, offset.y];
  };

  // soft ground shadow (live only) — replaces the CSS drop-shadow filter that
  // made large-canvas morphs stutter; fades out as the chart extrudes
  if (!d.bg && m < 0.999 && p > 0.05) {
    ctx.save();
    setShadow(ctx, 0, 7, 16, rgba(t.ink, 0.2 * (1 - m)));
    ctx.fillStyle = t.surface || '#e4e7e0';
    ctx.beginPath(); ctx.ellipse(cx, cy + depth, R0 + 1, (R0 + 1) * squash, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  /** Draw one slice's 3D body (outer rim, inner rim, cut faces) depth-sorted. */
  // exports (vector recorder) get ONE arc-bounded band per slice with a gradient
  // instead of dozens of shaded strips — same look, a fraction of the file size
  const vector = !!d.bg;
  const drawBody = (s: Seg, dx: number, dy: number) => {
    const faces: { y: number; draw: () => void }[] = [];
    const Rx = R0;
    const col = hov.idx === s.i ? shade(colors[s.i], 1 + 0.08 * hov.amt) : colors[s.i];
    if (vector) {
      const vis0 = Math.max(s.a0, 0), vis1 = Math.min(s.a1, Math.PI); // front half only
      if (vis1 > vis0 + 1e-4) {
        faces.push({
          y: py((vis0 + vis1) / 2, Rx),
          draw: () => {
            const g = ctx.createLinearGradient(px(vis0, Rx) + dx, 0, px(vis1, Rx) + dx, 0);
            g.addColorStop(0, shade(col, 0.62 + 0.2 * Math.cos(vis0)));
            g.addColorStop(1, shade(col, 0.62 + 0.2 * Math.cos(vis1)));
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, vis0, vis1, false);
            ctx.ellipse(cx + dx, cy + dy + depth, Rx, Rx * squash, 0, vis1, vis0, true);
            ctx.closePath(); ctx.fill();
          },
        });
      }
      if (rIn > 0) {
        const b0 = Math.max(s.a0, Math.PI), b1 = Math.min(s.a1, Math.PI * 2); // inner wall visible at the back
        const c0 = Math.max(s.a0, -Math.PI), c1 = Math.min(s.a1, 0);
        [[b0, b1], [c0, c1]].forEach(([q0, q1]) => {
          if (q1 <= q0 + 1e-4) return;
          faces.push({
            y: py((q0 + q1) / 2, rIn) - 900,
            draw: () => {
              ctx.fillStyle = shade(colors[s.i], 0.52);
              ctx.beginPath();
              ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, q0, q1, false);
              ctx.ellipse(cx + dx, cy + dy + depth, rIn, rIn * squash, 0, q1, q0, true);
              ctx.closePath(); ctx.fill();
            },
          });
        });
      }
      ([s.a0, s.a1] as const).forEach((edge) => {
        faces.push({
          y: py(edge, (Rx + rIn) / 2) - 0.25,
          draw: () => {
            ctx.fillStyle = shade(colors[s.i], 0.72);
            ctx.beginPath();
            if (rIn > 0) {
              ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy); ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy); ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
            } else {
              ctx.moveTo(cx + dx, cy + dy); ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy); ctx.lineTo(cx + dx, cy + depth + dy);
            }
            ctx.closePath(); ctx.fill();
          },
        });
      });
      return faces;
    }
    const steps = Math.max(3, Math.min(72, Math.ceil(((s.a1 - s.a0) * Rx) / 7)));
    for (let k = 0; k < steps; k++) {
      const b0 = s.a0 + ((s.a1 - s.a0) * k) / steps - OVER;
      const b1 = s.a0 + ((s.a1 - s.a0) * (k + 1)) / steps + OVER;
      const midS = (b0 + b1) / 2;
      if (Math.sin(midS) <= 0) continue;
      faces.push({
        y: py(midS, Rx),
        draw: () => {
          ctx.fillStyle = shade(col, 0.62 + 0.2 * Math.cos(midS));
          ctx.beginPath();
          ctx.moveTo(px(b0, Rx) + dx, py(b0, Rx) + dy);
          ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + dy);
          ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + depth + dy);
          ctx.lineTo(px(b0, Rx) + dx, py(b0, Rx) + depth + dy);
          ctx.closePath(); ctx.fill();
        },
      });
    }
    if (rIn > 0) {
      const inner = Math.max(3, Math.min(48, Math.ceil(((s.a1 - s.a0) * rIn) / 7)));
      for (let k = 0; k < inner; k++) {
        const b0 = s.a0 + ((s.a1 - s.a0) * k) / inner - OVER;
        const b1 = s.a0 + ((s.a1 - s.a0) * (k + 1)) / inner + OVER;
        const midS = (b0 + b1) / 2;
        const back = Math.sin(midS) < 0;
        faces.push({
          y: back ? py(midS, rIn) - 900 : py(midS, rIn) - 0.5,
          draw: () => {
            ctx.fillStyle = shade(colors[s.i], back ? 0.52 : 0.44);
            ctx.beginPath();
            ctx.moveTo(px(b0, rIn) + dx, py(b0, rIn) + dy);
            ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + dy);
            ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + depth + dy);
            ctx.lineTo(px(b0, rIn) + dx, py(b0, rIn) + depth + dy);
            ctx.closePath(); ctx.fill();
          },
        });
      }
    }
    ([s.a0, s.a1] as const).forEach((edge) => {
      faces.push({
        y: py(edge, (Rx + rIn) / 2) - 0.25,
        draw: () => {
          ctx.fillStyle = shade(colors[s.i], 0.88);
          ctx.beginPath();
          if (rIn > 0) {
            ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
            ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
          } else {
            ctx.moveTo(cx + dx, cy + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
            ctx.lineTo(cx + dx, cy + depth + dy);
          }
          ctx.closePath(); ctx.fill();
        },
      });
    });
    return faces;
  };
  /** Draw one slice's top face — polar 3D style: radial pop + brightness boost
   *  on the hovered slice, soft glossy bevel that matches the polar chart. */
  const drawTop = (s: Seg, dx: number, dy: number) => {
    const Rx = R0;
    const on = hov.idx === s.i;
    const pull = on ? 14 * hov.amt : 0;
    const o = OVER * clamp01(m * 8);
    // Soft drop shadow under the hovered slice — matches polar's hover lift feel
    if (on && pull > 0.5) {
      ctx.save();
      ctx.fillStyle = rgba(t.ink, 0.18 * hov.amt);
      ctx.beginPath();
      ctx.ellipse(cx + dx, cy + dy + 4, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
      if (rIn > 0) ctx.ellipse(cx + dx, cy + dy + 4, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
      else ctx.lineTo(cx + dx, cy + dy + 4);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    // Solid fill always — hover only lifts brightness uniformly. The old
    // radial-gradient wash faded the slice edge toward white, which read as a
    // hollow / washed-out ring on hover (notably on light slices like pink).
    ctx.fillStyle = on && hov.amt > 0.01 ? shade(colors[s.i], 1 + 0.14 * hov.amt) : colors[s.i];
    ctx.beginPath();
    ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
    if (rIn > 0) ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
    else ctx.lineTo(cx + dx, cy + dy);
    ctx.closePath(); ctx.fill();

    // NOTE: no specular wash is painted on the top face. The old white
    // overlay did two bad things in 3D: its auto-closed arc chord read as a
    // small white scratch on every slice, and the white fill made light
    // slices (e.g. pink) look non-solid. Slices stay 100 % solid color now.

    if (m < 0.02) {
      // Separator hint (2D only): stroke the rim arcs ONLY — never the full
      // slice path, whose radial cut edges used to flash as a fan of white
      // lines during the 2D⇄3D morph. 3D slices get no stroke at all, so the
      // top face stays perfectly clean and solid.
      ctx.strokeStyle = `rgba(255,255,255,${(0.55 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
      ctx.stroke();
      if (rIn > 0) {
        ctx.beginPath();
        ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, s.a0 - o, s.a1 + o, false);
        ctx.stroke();
      }
    }
  };

  // Hover is a planar translation, not elevation. Keep every body opaque and
  // depth-sort all slices together rather than painting the active slice on top.
  if (m > 0.005) {
    const faces = segs.flatMap((s) => {
      const [dx, dy] = offsetOf(s);
      return drawBody(s, dx, dy).map(face => ({ ...face, y: face.y + dy }));
    });
    faces.sort((a, b) => a.y - b.y).forEach(face => face.draw());
  }
  segs.forEach((s) => {
    const [dx, dy] = offsetOf(s);
    drawTop(s, dx, dy);
  });

  if (p > 0.95) drawLeaders(ctx, cx, cy, R0, squash, data, colors, total, t, W, H, false, full);
  if (kind === 'donut' && m < 0.5) {
    ctx.save();
    ctx.globalAlpha = clamp01(1 - m * 2);
    ctx.fillStyle = t.ink;
    ctx.font = font(t, 700, 16, true);
    ctx.textAlign = 'center';
    ctx.fillText(String(total), cx, cy + 5);
    ctx.restore();
    ctx.textAlign = 'left';
  }
}

