import { HONEST_PALETTE } from '../../theme/themes';
import { fontFaceCss } from '../../theme/fonts';
import { buildRiverStream } from './streamRiver';

export interface ChartDatum { label: string; value: number; color?: string; /** Prior-period comparison value (Radial Bars Circular markers / deltas). */ prior?: number }
export interface StackedSeries { name: string; color?: string; values: number[] }
export type ChartKind = 'bar' | 'line' | 'area' | 'pie' | 'donut' | 'radar' | 'polar' | 'radialbar' | 'radialbarclassic' | 'radialbars' | 'dual' | 'funnel' | 'pyramid' | 'calendarpie' | 'sankey' | 'sankey3d' | 'toroid' | 'gantt' | 'scatter' | 'stream';
/** Calendar-pie: one mini pie per day (ISO date → per-series values). */
export interface CalendarDay { date: string; values: number[] }
/** Sankey flow: source → target with a weight. */
export interface SankeyLink { source: string; target: string; value: number }
/** Gantt task: milestone / phase duration and progress. */
export interface GanttTask { id: string | number; name: string; start: string | number; end: string | number; progress?: number; color?: string; category?: string; assignee?: string; dependsOn?: (string | number)[]; milestone?: boolean; baselineStart?: string | number; baselineEnd?: string | number; slackDays?: number }
/** Scatter point: 2D numeric correlation coordinate. */
export interface ScatterPoint { x: number; y: number; label?: string; size?: number; color?: string; category?: string }
/** Streamgraph event flag (Highcharts-style plot-line label marking a special event on the timeline). */
export interface StreamEvent { at: number; label: string; detail?: string }

/** Brand palette — no purple, violet or indigo anywhere. */
export const PALETTE = ['#0d7a54', '#c9932b', '#0ea5e9', '#e11d63', '#f97316', '#14b8a6', '#1e5aa8', '#84cc16', '#f43f5e', '#a16207', '#06b6d4', '#64748b'];
/** Glossy Sankey-3D family for the Toroid Donut (REFERENCE_PALETTE minus violet, per palette rule). */
export const TOROID_GLOSS = ['#7dd4f8', '#f07ed0', '#4dba80', '#fcc84a', '#f7984a', '#5cd9d5', '#6b9ff5', '#a8db5a', '#f87171', '#fb923c', '#34d399', '#f472b6', '#38bdf8', '#b8e065'];
/** Palette for the active theme — the Honest Paper theme brings Pie.’s slice colours with it. */
export function activePalette(): string[] {
  try { return document.documentElement.getAttribute('data-theme') === 'honest' ? HONEST_PALETTE : PALETTE; } catch { return PALETTE; }
}

export const TILT = 0.32; // slight left-leaning perspective — aesthetic, not a full tilt
export const K = Math.sin(TILT);
export const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
export const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const SIN45 = Math.SQRT1_2;

/* ---------- colour utils ---------- */
export function parseColor(c: string): [number, number, number, number] | null {
  const s = (c || '').trim();
  let m = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(s);
  if (m) return [parseInt(m[1] + m[1], 16), parseInt(m[2] + m[2], 16), parseInt(m[3] + m[3], 16), 1];
  m = /^#([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(s);
  if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, m[2] ? parseInt(m[2], 16) / 255 : 1]; }
  m = /^rgba?\(([^)]+)\)$/i.exec(s);
  if (m) {
    const parts = m[1].split(/[\s,/]+/).filter(Boolean).map(parseFloat);
    if (parts.length >= 3) return [parts[0], parts[1], parts[2], parts.length > 3 ? parts[3] : 1];
  }
  return null;
}
export const shadeCache = new Map<string, string>();
export const shade = (col: string, f: number) => {
  const key = col + '|' + f.toFixed(3);
  const hit = shadeCache.get(key);
  if (hit) return hit;
  const p = parseColor(col) || [136, 136, 136, 1];
  const c = (v: number) => Math.min(255, Math.max(0, Math.round(v * f)));
  const out = `rgb(${c(p[0])},${c(p[1])},${c(p[2])})`;
  if (shadeCache.size > 4000) shadeCache.clear();
  shadeCache.set(key, out);
  return out;
};
export const rgba = (col: string, a: number) => {
  const p = parseColor(col);
  return p ? `rgba(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])},${a})` : col;
};
export const withAlpha = (hex: string, a: string) => (/^#[0-9a-f]{6}$/i.test(hex) ? hex + a : rgba(hex, parseInt(a, 16) / 255));
export const luma = (col: string) => { const p = parseColor(col); return p ? (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) / 255 : 0.5; };

/* ---------- theme (colours + fonts read from the live token set) ---------- */
export interface Theme { ink: string; axis: string; grid: string; surface?: string; fontBody?: string; fontDisplay?: string; dark?: boolean }
export const DEF_BODY = '"Outfit", ui-sans-serif, system-ui, sans-serif';
export const DEF_DISPLAY = '"Fraunces", Georgia, serif';
export function cssVar(name: string, fallback: string): string {
  try { return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback; } catch { return fallback; }
}
export function themeColors(forExport = false): Theme {
  const fontBody = cssVar('--t-font-body', DEF_BODY);
  const fontDisplay = cssVar('--t-font-display', DEF_DISPLAY);
  if (forExport) return { ink: '#1c2620', axis: '#39443d', grid: 'rgba(60,70,64,0.18)', surface: '#eef0ec', fontBody, fontDisplay, dark: false };
  const ink = cssVar('--t-ink', '#101914');
  const surface = cssVar('--t-surface', '#e4e7e0');
  return { ink, axis: ink, grid: 'rgba(128,128,128,0.18)', surface, fontBody, fontDisplay, dark: luma(ink) > 0.5 };
}
export const font = (t: Theme | undefined, weight: number, size: number, display = false) =>
  `${weight} ${size}px ${display ? t?.fontDisplay || DEF_DISPLAY : t?.fontBody || DEF_BODY}`;
/** Families to @import inside exported SVGs so text renders with the app's fonts. */
export function fontFamilies(t: Theme): string[] {
  const out = new Set<string>();
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem('aviary-prefs-v2') : null;
    if (raw) {
      const p = JSON.parse(raw);
      if (p.fontBody) out.add(p.fontBody.trim());
      if (p.fontDisplay) out.add(p.fontDisplay.trim());
    }
  } catch { /* ignore */ }
  [t.fontBody || DEF_BODY, t.fontDisplay || DEF_DISPLAY].forEach((stack) => {
    stack.split(',').forEach((part) => {
      const first = part.trim().replace(/^["']|["']$/g, '');
      if (first && !/^(serif|sans-serif|system-ui|ui-sans-serif|ui-serif|monospace|Georgia|Arial|Helvetica)$/i.test(first)) out.add(first);
    });
  });
  return [...out];
}
export const fontsReady = async () => { try { await (document as unknown as { fonts?: { ready: Promise<unknown> } }).fonts?.ready; } catch { /* noop */ } };

/* ---------- text helpers ---------- */
export const approxW = (s: string, fs = 10.5) => s.length * fs * 0.58;
/** Smart label fitting — ellipsis, prefers word boundaries. Deterministic (no ctx). */
export function fitText(s: string, maxW: number, fs = 10.5): string {
  const cw = fs * 0.58;
  const maxC = Math.max(2, Math.floor(maxW / cw));
  if (s.length <= maxC) return s;
  let cut = s.slice(0, maxC - 1);
  const sp = cut.lastIndexOf(' ');
  if (sp > maxC * 0.5) cut = cut.slice(0, sp);
  return cut.trimEnd() + '…';
}
export const fmtNum = (n: number) =>
  Math.abs(n) >= 1e6 ? `${(n / 1e6).toFixed(1).replace(/\.0$/, '')}M`
    : Math.abs(n) >= 1e3 ? `${(n / 1e3).toFixed(1).replace(/\.0$/, '')}k`
    : String(Math.round(n));
export type Ctx = CanvasRenderingContext2D;
export const measureW = (ctx: Ctx, s: string) => {
  try { const w = ctx.measureText(s).width; return w > 0 && isFinite(w) ? w : approxW(s); } catch { return approxW(s); }
};
/** Measured ellipsis using the context's current font. */
export function fitCtx(ctx: Ctx, s: string, maxW: number): string {
  if (maxW === Infinity || measureW(ctx, s) <= maxW) return s;
  let lo = 0, hi = s.length;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (measureW(ctx, s.slice(0, mid) + '…') <= maxW) lo = mid; else hi = mid - 1; }
  let cut = s.slice(0, Math.max(1, lo));
  const sp = cut.lastIndexOf(' ');
  if (sp > cut.length * 0.5) cut = cut.slice(0, sp);
  return cut.trimEnd() + '…';
}

/* ================= CDN loaders ================= */
export const scriptCache = new Map<string, Promise<void>>();
export function loadScript(src: string): Promise<void> {
  if (!scriptCache.has(src)) {
    scriptCache.set(src, new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = () => resolve();
      s.onerror = () => { scriptCache.delete(src); reject(new Error('Failed to load ' + src)); };
      document.head.appendChild(s);
    }));
  }
  return scriptCache.get(src)!;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
export async function loadPdfMake(): Promise<any> {
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.12/pdfmake.min.js');
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.12/vfs_fonts.js');
  return (window as any).pdfMake;
}
export async function loadExcelJS(): Promise<any> {
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js');
  return (window as any).ExcelJS;
}
/* eslint-enable @typescript-eslint/no-explicit-any */

export function downloadBlob(name: string, blob: Blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

export function jpegToPdf(jpegBytes: Uint8Array, wPx: number, hPx: number): Blob {
  const wPt = (wPx * 0.75) / 3, hPt = (hPx * 0.75) / 3;
  const enc = new TextEncoder();
  const chunks: (Uint8Array | string)[] = [];
  const offsets: number[] = [];
  let len = 0;
  const push = (s: Uint8Array | string) => { chunks.push(s); len += typeof s === 'string' ? enc.encode(s).length : s.length; };
  const obj = (body: string) => { offsets.push(len); push(body); };
  push('%PDF-1.4\n');
  obj('1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n');
  obj('2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n');
  obj(`3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${wPt.toFixed(1)} ${hPt.toFixed(1)}]/Resources<</XObject<</Im0 4 0 R>>>>/Contents 5 0 R>>endobj\n`);
  offsets.push(len);
  push(`4 0 obj<</Type/XObject/Subtype/Image/Width ${wPx}/Height ${hPx}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ${jpegBytes.length}>>stream\n`);
  push(jpegBytes);
  push('\nendstream endobj\n');
  const content = `q ${wPt.toFixed(1)} 0 0 ${hPt.toFixed(1)} 0 0 cm /Im0 Do Q`;
  obj(`5 0 obj<</Length ${content.length}>>stream\n${content}\nendstream endobj\n`);
  const xrefAt = len;
  push(`xref\n0 6\n0000000000 65535 f \n${offsets.map((o) => String(o).padStart(10, '0') + ' 00000 n \n').join('')}`);
  push(`trailer<</Size 6/Root 1 0 R>>\nstartxref\n${xrefAt}\n%%EOF`);
  return new Blob(chunks.map((c) => (typeof c === 'string' ? enc.encode(c) : c)) as BlobPart[], { type: 'application/pdf' });
}

export function printCanvas(title: string, cv: HTMLCanvasElement) {
  const url = cv.toDataURL('image/png');
  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'position:fixed;right:200vw;bottom:200vh;width:980px;height:720px;border:0;';
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow!.document;
  doc.open();
  doc.write(`<html><head><title>${title}</title><style>@page{margin:12mm;}body{margin:0;display:grid;place-items:center;background:#fff;}img{max-width:100%;}</style></head><body><img src="${url}"/></body></html>`);
  doc.close();
  const cleanup = () => { try { iframe.remove(); } catch { /* noop */ } };
  iframe.contentWindow!.onafterprint = cleanup;
  const img = doc.querySelector('img')!;
  const go = () => setTimeout(() => {
    try { iframe.contentWindow!.focus(); iframe.contentWindow!.print(); } catch { cleanup(); }
    setTimeout(cleanup, 60000);
  }, 150);
  if ((img as HTMLImageElement).complete) go(); else img.addEventListener('load', go);
}

/** Rasterize an SVG string to a canvas (white background). */
export function svgToCanvas(svg: string, w: number, h: number, scale = 3): Promise<HTMLCanvasElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
    img.onload = () => {
      const cv = document.createElement('canvas');
      cv.width = w * scale; cv.height = h * scale;
      const ctx = cv.getContext('2d')!;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.drawImage(img, 0, 0, cv.width, cv.height);
      URL.revokeObjectURL(url);
      resolve(cv);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('SVG rasterize failed')); };
    img.src = url;
  });
}

/* ============================================================
   Canvas → SVG recorder. Implements the 2D-context subset used
   by the painters (paths, text, gradients, soft shadows, alpha,
   transforms) emitting true vector SVG — so EVERY chart, including
   the neumorphic family, exports as vector with fonts intact.
   ============================================================ */
// FILE-SIZE FIX: every SVG export's path coordinates flow through this
// rounder. 2-decimal precision (hundredths of a px) is invisible at any
// normal viewing size but meaningfully lengthens every single coordinate
// string — a real cost for facet-heavy charts (the toroid in particular,
// with hundreds to low-thousands of small quads). 1-decimal precision
// (tenths of a px) is still far finer than anything visible on screen or
// in print, and shortens the average coordinate string noticeably.
export const r2 = (n: number) => Math.round(n * 10) / 10;
export function splitColor(c: string): { color: string; opacity: number } {
  const p = parseColor(c);
  if (!p) return { color: c || '#000', opacity: 1 };
  return { color: `rgb(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])})`, opacity: p[3] };
}
export class SvgCtx {
  els: string[] = [];
  defs: string[] = [];
  /** embedded @font-face rules (base64 woff2) — fonts travel with the file, no CDN */
  fontCss = '';
  fillStyle: string | { __grad: string } = '#000';
  strokeStyle: string | { __grad: string } = '#000';
  lineWidth = 1;
  lineJoin = 'miter';
  lineCap = 'butt';
  font = '10px sans-serif';
  textAlign: 'left' | 'center' | 'right' | 'start' | 'end' = 'left';
  globalAlpha = 1;
  shadowBlur = 0; shadowOffsetX = 0; shadowOffsetY = 0; shadowColor = 'rgba(0,0,0,0)';
  private d = '';
  private tx = 0; private ty = 0; private rot = 0;
  private stack: { tx: number; ty: number; rot: number; alpha: number; sb: number; sx: number; sy: number; sc: string }[] = [];
  private gradN = 0;
  private filters = new Map<string, string>();
  private meas: CanvasRenderingContext2D;
  constructor(public W: number, public H: number) {
    this.meas = document.createElement('canvas').getContext('2d')!;
  }
  /* transforms / state */
  setTransform() { /* dpr no-op */ }
  clearRect() { /* no-op */ }
  save() { this.stack.push({ tx: this.tx, ty: this.ty, rot: this.rot, alpha: this.globalAlpha, sb: this.shadowBlur, sx: this.shadowOffsetX, sy: this.shadowOffsetY, sc: this.shadowColor }); }
  restore() {
    const s = this.stack.pop();
    if (s) { this.tx = s.tx; this.ty = s.ty; this.rot = s.rot; this.globalAlpha = s.alpha; this.shadowBlur = s.sb; this.shadowOffsetX = s.sx; this.shadowOffsetY = s.sy; this.shadowColor = s.sc; }
  }
  translate(x: number, y: number) { this.tx += x; this.ty += y; }
  rotate(a: number) { this.rot += a; }
  scale() { /* entrance scale is 1 at export */ }
  clip() { /* reveal clips are full-frame at export */ }
  setLineDash() { /* dashes only decorate live hover guides */ }
  rect(x: number, y: number, w: number, h: number) { this.d += `M ${this.px(x, y)} h ${r2(w)} v ${r2(h)} h ${r2(-w)} Z `; }
  /* path building */
  private px(x: number, y: number) { return `${r2(x + this.tx)} ${r2(y + this.ty)}`; }
  beginPath() { this.d = ''; }
  moveTo(x: number, y: number) { this.d += `M ${this.px(x, y)} `; }
  lineTo(x: number, y: number) { this.d += `L ${this.px(x, y)} `; }
  closePath() { this.d += 'Z '; }
  bezierCurveTo(c1x: number, c1y: number, c2x: number, c2y: number, x: number, y: number) {
    this.d += `C ${this.px(c1x, c1y)} ${this.px(c2x, c2y)} ${this.px(x, y)} `;
  }
  quadraticCurveTo(cx: number, cy: number, x: number, y: number) {
    this.d += `Q ${this.px(cx, cy)} ${this.px(x, y)} `;
  }
  arc(x: number, y: number, r: number, a0: number, a1: number, ccw = false) {
    this.ellipse(x, y, r, r, 0, a0, a1, ccw);
  }
  ellipse(x: number, y: number, rx: number, ry: number, _rot: number, a0: number, a1: number, ccw = false) {
    rx = Math.max(0.01, rx); ry = Math.max(0.01, ry);
    let d = a1 - a0;
    if (ccw && d > 0) d -= Math.PI * 2;
    if (!ccw && d < 0) d += Math.PI * 2;
    const full = Math.abs(d) >= Math.PI * 2 - 1e-4;
    const seg = full ? (d > 0 ? Math.PI : -Math.PI) : d;
    const steps = full ? 2 : 1;
    const sx = x + Math.cos(a0) * rx, sy = y + Math.sin(a0) * ry;
    if (this.d === '' || this.d.endsWith('Z ')) this.d += `M ${this.px(sx, sy)} `;
    else this.d += `L ${this.px(sx, sy)} `;
    let cur = a0;
    for (let i = 0; i < steps; i++) {
      const next = full ? cur + seg : a0 + d;
      const ex = x + Math.cos(next) * rx, ey = y + Math.sin(next) * ry;
      const large = Math.abs(next - cur) > Math.PI ? 1 : 0;
      const sweep = next > cur ? 1 : 0;
      this.d += `A ${r2(rx)} ${r2(ry)} 0 ${large} ${sweep} ${this.px(ex, ey)} `;
      cur = next;
    }
  }
  roundRect(x: number, y: number, w: number, h: number, r: number | number[]) {
    const lim = Math.min(w, h) / 2;
    const rr = (Array.isArray(r) ? r : [r, r, r, r]).map((v) => Math.min(lim, Math.max(0, v)));
    const [tl, tr, br, bl] = [rr[0] ?? 0, rr[1] ?? rr[0] ?? 0, rr[2] ?? rr[0] ?? 0, rr[3] ?? rr[1] ?? rr[0] ?? 0];
    this.d += `M ${this.px(x + tl, y)} H ${r2(x + w - tr + this.tx)} `;
    if (tr) this.d += `A ${r2(tr)} ${r2(tr)} 0 0 1 ${this.px(x + w, y + tr)} `;
    this.d += `V ${r2(y + h - br + this.ty)} `;
    if (br) this.d += `A ${r2(br)} ${r2(br)} 0 0 1 ${this.px(x + w - br, y + h)} `;
    this.d += `H ${r2(x + bl + this.tx)} `;
    if (bl) this.d += `A ${r2(bl)} ${r2(bl)} 0 0 1 ${this.px(x, y + h - bl)} `;
    this.d += `V ${r2(y + tl + this.ty)} `;
    if (tl) this.d += `A ${r2(tl)} ${r2(tl)} 0 0 1 ${this.px(x + tl, y)} `;
    this.d += 'Z ';
  }
  /* paint */
  private resolve(style: string | { __grad: string }): string {
    return typeof style === 'string' ? style : `url(#${style.__grad})`;
  }
  private fx(): string {
    let attr = this.globalAlpha < 1 ? ` opacity="${r2(this.globalAlpha)}"` : '';
    if (this.shadowBlur > 0 || this.shadowOffsetX || this.shadowOffsetY) {
      const { color, opacity } = splitColor(this.shadowColor);
      if (opacity > 0) {
        const key = `${r2(this.shadowOffsetX)}|${r2(this.shadowOffsetY)}|${r2(this.shadowBlur)}|${color}|${r2(opacity)}`;
        let id = this.filters.get(key);
        if (!id) {
          id = `sh${this.filters.size + 1}`;
          this.filters.set(key, id);
          // classic blur → offset → flood → composite → merge chain: renders in every
          // SVG engine (browsers, Inkscape, librsvg, Illustrator), unlike feDropShadow
          this.defs.push(`<filter id="${id}" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur in="SourceAlpha" stdDeviation="${r2(this.shadowBlur / 2)}"/><feOffset dx="${r2(this.shadowOffsetX)}" dy="${r2(this.shadowOffsetY)}" result="ob"/><feFlood flood-color="${color}" flood-opacity="${r2(opacity)}"/><feComposite in2="ob" operator="in" result="sh"/><feMerge><feMergeNode in="sh"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`);
        }
        attr += ` filter="url(#${id})"`;
      }
    }
    return attr;
  }
  fill() { if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`); }
  stroke() {
    if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="none" stroke="${this.resolve(this.strokeStyle)}" stroke-width="${r2(this.lineWidth)}" stroke-linejoin="${this.lineJoin === 'round' ? 'round' : 'miter'}" stroke-linecap="${this.lineCap === 'round' ? 'round' : 'butt'}"${this.fx()}/>`);
  }
  fillRect(x: number, y: number, w: number, h: number) {
    this.els.push(`<rect x="${r2(x + this.tx)}" y="${r2(y + this.ty)}" width="${r2(w)}" height="${r2(h)}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`);
  }
  fillText(text: string, x: number, y: number) {
    const fm = /(\d+(?:\.\d+)?)px\s+(.+)$/.exec(this.font);
    const size = fm ? +fm[1] : 10;
    const fam = fm ? fm[2] : 'sans-serif';
    const wm = /^(\d{3}|bold)\s/.exec(this.font);
    const weight = wm ? (wm[1] === 'bold' ? '700' : wm[1]) : '400';
    const anchor = this.textAlign === 'center' ? 'middle' : this.textAlign === 'right' || this.textAlign === 'end' ? 'end' : 'start';
    const esc = text.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const gx = r2(x + this.tx), gy = r2(y + this.ty);
    const tf = this.rot !== 0 ? ` transform="rotate(${r2((this.rot * 180) / Math.PI)} ${gx} ${gy})"` : '';
    this.els.push(`<text x="${gx}" y="${gy}" font-family="${fam.replace(/"/g, "'")}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}" fill="${this.resolve(this.fillStyle)}"${tf}${this.fx()}>${esc}</text>`);
  }
  measureText(t: string) { this.meas.font = this.font; return this.meas.measureText(t); }
  createLinearGradient(x0: number, y0: number, x1: number, y1: number) {
    const id = `g${++this.gradN}`;
    const stops: string[] = [];
    this.defs.push('');
    const idx = this.defs.length - 1;
    const self = this;
    const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
    return {
      __grad: id,
      addColorStop(off: number, col: string) {
        const sc = splitColor(col);
        stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
        self.defs[idx] = `<linearGradient id="${id}" x1="${r2(ax)}" y1="${r2(ay)}" x2="${r2(bx)}" y2="${r2(by)}" gradientUnits="userSpaceOnUse">${stops.join('')}</linearGradient>`;
      },
    };
  }
  /** SVG <radialGradient> support — required for dual-axis 3D line markers
   * and the toroid's centre orb. Canvas semantics: offset 0 lives on the
   * START circle (x0,y0,r0) and offset 1 on the END circle (x1,y1,r1). In
   * SVG that maps to fx/fy/fr = start (focal) circle and cx/cy/r = end
   * circle — the old attribute mapping had the two circles swapped, which
   * inverted every radial gradient in SVG exports. */
  createRadialGradient(x0: number, y0: number, r0: number, x1: number, y1: number, r1: number) {
    const id = `g${++this.gradN}`;
    const stops: string[] = [];
    this.defs.push('');
    const idx = this.defs.length - 1;
    const self = this;
    const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
    return {
      __grad: id,
      addColorStop(off: number, col: string) {
        const sc = splitColor(col);
        stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
        self.defs[idx] = `<radialGradient id="${id}" cx="${r2(bx)}" cy="${r2(by)}" r="${r2(Math.max(0.01, r1))}" fx="${r2(ax)}" fy="${r2(ay)}" fr="${r2(Math.max(0, r0))}" gradientUnits="userSpaceOnUse">${stops.join('')}</radialGradient>`;
      },
    };
  }
  toString(): string {
    const fams = fontFamilies(themeColors(true));
    const googleImport = fams.length
      ? `@import url('https://fonts.googleapis.com/css2?family=${fams.map((f) => encodeURIComponent(f).replace(/%20/g, '+')).join('&family=')}:wght@400;600;700&display=swap');\n`
      : '';
    const style = `<style><![CDATA[\n${googleImport}${this.fontCss}]]></style>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${this.W}" height="${this.H}" viewBox="0 0 ${this.W} ${this.H}"><defs>${style}${this.defs.join('')}</defs><rect width="${this.W}" height="${this.H}" fill="#ffffff"/>${this.els.join('')}</svg>`;
  }
}

export interface XPlan { rot: number; stride: number; padB: number; maxW: number; fs: number; /** how far a rotated first label reaches left of its anchor */ overhang: number }
export function planX(labels: string[], step: number, full: boolean, fs = 10.5): XPlan {
  const longest = labels.reduce((m, l) => Math.max(m, approxW(l, fs)), 0);
  const base = 34;
  if (!labels.length || longest <= step - 6) return { rot: 0, stride: 1, padB: base, maxW: Math.max(20, step - 4), fs, overhang: 0 };
  if (full) {
    const rot = longest * SIN45 + fs <= 130 ? -Math.PI / 4 : -Math.PI / 2;
    const foot = (fs * 1.4) / Math.abs(Math.sin(rot));
    const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
    const padB = Math.min(170, (rot === -Math.PI / 2 ? longest : longest * SIN45) + 22);
    return { rot, stride, padB, maxW: Infinity, fs, overhang: longest * Math.abs(Math.cos(rot)) + 4 };
  }
  if (step >= 56) return { rot: 0, stride: 1, padB: base, maxW: step - 4, fs, overhang: 0 };
  const rot = -Math.PI / 4;
  const foot = (fs * 1.4) / SIN45;
  const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
  const maxW = 78;
  const padB = Math.min(70, Math.min(longest, maxW) * SIN45 + 22);
  return { rot, stride, padB, maxW, fs, overhang: Math.min(longest, maxW) * SIN45 + 4 };
}
/** Plan labels for a plot of width `W - l - r`, growing the left pad when a rotated first label would spill off-canvas. */
export function planXFit(labels: string[], W: number, l: number, r: number, full: boolean, fs: number, slots: number, endpoints = false) {
  const stepOf = (left: number) => { const cw = Math.max(10, W - left - r); return endpoints ? (slots > 1 ? cw / (slots - 1) : cw) : cw / Math.max(1, slots); };
  let plan = planX(labels, stepOf(l), full, fs);
  if (plan.overhang > l) { l = plan.overhang; plan = planX(labels, stepOf(l), full, fs); }
  return { plan, l, step: stepOf(l) };
}
export function drawXLabels(ctx: Ctx, labels: string[], plan: XPlan, xOf: (i: number) => number, yAxis: number, t: Theme, W: number, weight = 600, color?: string) {
  ctx.font = font(t, weight, plan.fs);
  ctx.fillStyle = color || t.axis;
  const n = labels.length;
  for (let i = 0; i < n; i++) {
    const x = xOf(i);
    const isLast = i === n - 1;
    const shown = i % plan.stride === 0 || (isLast && plan.stride > 1 && (n - 1) % plan.stride >= Math.ceil(plan.stride * 0.6));
    if (!shown) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x, yAxis); ctx.lineTo(x, yAxis + 3); ctx.stroke();
      continue;
    }
    const text = plan.maxW === Infinity ? labels[i] : fitCtx(ctx, labels[i], plan.maxW);
    if (plan.rot === 0) {
      const w = measureW(ctx, text);
      const cx = Math.max(w / 2 + 2, Math.min(W - w / 2 - 2, x));
      ctx.textAlign = 'center';
      ctx.fillText(text, cx, yAxis + 16);
    } else {
      ctx.save(); ctx.translate(x, yAxis + 8); ctx.rotate(plan.rot); ctx.textAlign = 'right';
      ctx.fillText(text, 0, plan.fs * 0.35); ctx.restore();
    }
  }
  ctx.textAlign = 'left';
}

/* ================= geometry helpers ================= */
export const ZX = 15, ZY = 10, DZ = 7, DZY = 4.5; // 3D line/area: per-series depth step + (thin) slab thickness
export interface XY { pad: { l: number; r: number; t: number; b: number }; cw: number; ch: number; step: number; plan: XPlan; ox: number; oy: number }
export function xyLayout(kind: 'bar' | 'line' | 'area', W: number, H: number, m: number, labels: string[], nD: number, max: number, hasY: boolean, full: boolean): XY {
  const isBar = kind === 'bar';
  const ox = isBar ? 13 * m : ZX * m * Math.max(0, nD - 1) + DZ * m;
  const oy = isBar ? 9 * m : ZY * m * Math.max(0, nD - 1) + DZY * m;
  const l0 = 12 + approxW(fmtNum(max), 10.5) + 12 + (hasY ? 14 : 0);
  const r = 16 + (isBar ? 20 * m : ox);
  const tp = 18 + (isBar ? 12 * m : oy);
  const { plan, l, step } = planXFit(labels, W, l0, r, full, 10.5, labels.length);
  return { pad: { l, r, t: tp, b: plan.padB }, cw: W - l - r, ch: H - tp - plan.padB, step, plan, ox, oy };
}

/** Depth rank per series: 0 = front (smallest total) … n-1 = back (largest). */
export function seriesDepth(series: StackedSeries[]): number[] {
  const order = series.map((s, i) => ({ i, sum: s.values.reduce((a, b) => a + b, 0) })).sort((a, b) => a.sum - b.sum);
  const depth = new Array(series.length).fill(0);
  order.forEach((o, rank) => { depth[o.i] = rank; });
  return depth;
}

export const leaderLabel = (d: ChartDatum, total: number) => `${d.label} · ${Math.round((d.value / total) * 100)}%`;
export function circGeom(W: number, H: number, m: number, data: ChartDatum[], full = false) {
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const longest = Math.max(0, ...data.map((x) => approxW(leaderLabel(x, total))));
  const labelSpace = full ? longest + 40 : Math.min(Math.max(60, longest) + 34, W * 0.32);
  const squash = lerp(1, K, m);
  // The diameter is FIXED across the 2D⇄3D morph: the disc is sized once for
  // the flat view (the binding constraint) and only tilts/extrudes afterwards.
  let R = Math.min(W / 2 - labelSpace, (H - 44) / 2);
  R = Math.max(full ? 60 : 40, R);
  // Keep the extruded disc's depth strictly proportional to its radius so the
  // 3D pie/donut/polar always read with a proper thickness in fullscreen,
  // regardless of how much vertical space the container offers.
  // Slimmer than the legacy 0.42 ratio: the old slab looked chunky in
  // fullscreen, so the extrusion now tops out at ~30 % of the radius with a
  // capped pixel ceiling.
  const depth = Math.min(58, Math.max(12, R * 0.3)) * m;
  const cy = (H - depth) / 2 + 4;
  return { cx: W / 2, cy, R, rInRatio: 0.55, depth, squash, total };
}

/* ================= true-3D projection core (rotatable 3D scenes) =================
   A tiny software 3D pipeline shared by the rotatable 3D charts (currently
   Sankey 3D). World space is pixels in X/Y with a Z depth in pixels; the
   camera orbits around the scene centre by yaw (horizontal) and pitch
   (vertical tilt). Projection is a gentle perspective divide, so near edges
   grow and far edges shrink exactly like a modelled object in a viewport.
   Dragging the canvas orbits the camera; the angles ease back toward rest on
   release so the scene always settles into a readable default view. */
export interface Orbit3D { yaw: number; pitch: number }
export const ORBIT_REST: Orbit3D = { yaw: -0.30, pitch: 0.30 };
export interface Proj3D {
  px: (x: number, y: number, z: number) => number;
  py: (x: number, y: number, z: number) => number;
  sc: (x: number, y: number, z: number) => number;
  yaw: number; pitch: number; cx: number; cy: number;
}
export function makeProj(W: number, H: number, o: Orbit3D, dist?: number): Proj3D {
  // Focal length scales with canvas size so perspective strength is identical
  // in cards, fullscreen and exports.
  const D = dist ?? Math.max(W, H) * 2.2;
  const cx = W / 2, cy = H / 2;
  const cyaw = Math.cos(o.yaw), syaw = Math.sin(o.yaw);
  const cpit = Math.cos(o.pitch), spit = Math.sin(o.pitch);
  const rot = (x: number, y: number, z: number): [number, number, number] => {
    const dx = x - cx, dy = y - cy;
    // yaw around the vertical axis, then pitch around the horizontal axis
    const x1 = dx * cyaw - z * syaw;
    const z1 = dx * syaw + z * cyaw;
    const y2 = dy * cpit - z1 * spit;
    const z2 = dy * spit + z1 * cpit;
    return [x1, y2, z2];
  };
  const sc = (x: number, y: number, z: number) => D / (D + rot(x, y, z)[2]);
  return {
    px: (x, y, z) => cx + rot(x, y, z)[0] * sc(x, y, z),
    py: (x, y, z) => cy + rot(x, y, z)[1] * sc(x, y, z),
    sc, yaw: o.yaw, pitch: o.pitch, cx, cy,
  };
}

/* ---- sankey layout: longest-path column assignment, proportional node heights, flows stacked in node order ---- */
export interface SkNode { name: string; col: number; value: number; x: number; y: number; h: number; color: string }
export interface SkFlow { si: number; ti: number; value: number; sy0: number; sy1: number; ty0: number; ty1: number }
export function sankeyLayout(links: SankeyLink[], W: number, H: number, labelSpace: number) {
  const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
  const idx = new Map(names.map((n, i) => [n, i]));
  const outs = names.map(() => [] as number[]), ins = names.map(() => [] as number[]);
  links.forEach((l, li) => { outs[idx.get(l.source)!].push(li); ins[idx.get(l.target)!].push(li); });
  // column = longest path from a source (cycle-guarded)
  const col = new Array(names.length).fill(0);
  const visit = (i: number, depth: number, seen: Set<number>) => {
    if (seen.has(i) || depth > 32) return;
    col[i] = Math.max(col[i], depth);
    seen.add(i);
    outs[i].forEach((li) => visit(idx.get(links[li].target)!, depth + 1, seen));
    seen.delete(i);
  };
  names.forEach((_, i) => { if (!ins[i].length) visit(i, 0, new Set()); });
  const cols = Math.max(...col) + 1;
  if (cols < 2) return null;
  const value = names.map((_, i) => Math.max(outs[i].reduce((s2, li) => s2 + links[li].value, 0), ins[i].reduce((s2, li) => s2 + links[li].value, 0)));
  const padT = 14, padB = 14, padL = 8, padR = labelSpace;
  const nodeW = 12, gap = 10;
  const plotW = W - padL - padR - nodeW, plotH = H - padT - padB;
  const colX = Array.from({ length: cols }, (_, c) => padL + (plotW * c) / (cols - 1));
  const perCol = Array.from({ length: cols }, () => [] as number[]);
  names.forEach((_, i) => perCol[col[i]].push(i));
  // scale so the tallest column fits
  const colTotal = perCol.map((ids) => ids.reduce((s2, i) => s2 + value[i], 0) + gap * Math.max(0, ids.length - 1));
  const scale = (plotH) / Math.max(...colTotal, 1);
  const pal = activePalette();
  const nodes: SkNode[] = names.map((n, i) => ({ name: n, col: col[i], value: value[i], x: colX[col[i]], y: 0, h: value[i] * scale, color: pal[i % pal.length] }));
  perCol.forEach((ids) => {
    ids.sort((a, b) => value[b] - value[a]);
    const total = ids.reduce((s2, i) => s2 + nodes[i].h, 0) + gap * Math.max(0, ids.length - 1);
    let y = padT + (plotH - total) / 2;
    ids.forEach((i) => { nodes[i].y = y; y += nodes[i].h + gap; });
  });
  // flows: stack outgoing on the source (ordered by target y) and incoming on the target (ordered by source y)
  const flows: SkFlow[] = links.map((l) => ({ si: idx.get(l.source)!, ti: idx.get(l.target)!, value: l.value, sy0: 0, sy1: 0, ty0: 0, ty1: 0 }));
  nodes.forEach((n, i) => {
    let y = n.y;
    outs[i].map((li) => flows[li]).sort((a, b) => nodes[a.ti].y - nodes[b.ti].y).forEach((f) => { f.sy0 = y; y += f.value * scale; f.sy1 = y; });
    y = n.y;
    ins[i].map((li) => flows[li]).sort((a, b) => nodes[a.si].y - nodes[b.si].y).forEach((f) => { f.ty0 = y; y += f.value * scale; f.ty1 = y; });
  });
  return { nodes, flows, nodeW, cols, colX };
}

/** 3D layout: same flow math as 2D, but shifted right to reserve the
   left outside-label gutter and vertically centred in the taller 3D plot. */
export function sankeyLayout3D(links: SankeyLink[], W: number, H: number, labelSpace: number, padL3D: number) {
  const lay = sankeyLayout(links, W - padL3D, H, labelSpace);
  if (!lay) return null;
  const dx = padL3D;
  lay.nodes.forEach((n) => { n.x += dx; });
  lay.colX = lay.colX.map((x) => x + dx);
  return lay;
}

export function sankeyRibbon(ctx: Ctx, f: SkFlow, nodes: SkNode[], nodeW: number, emphasis = 0) {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x, mid = (x0 + x1) / 2;
  const spread = 5 * emphasis;
  ctx.beginPath(); ctx.moveTo(x0, f.sy0);
  ctx.bezierCurveTo(mid, f.sy0 - spread, mid, f.ty0 - spread, x1, f.ty0);
  ctx.lineTo(x1, f.ty1);
  ctx.bezierCurveTo(mid, f.ty1 + spread, mid, f.sy1 + spread, x0, f.sy1);
  ctx.closePath();
}

/* ---- sankey ribbon sampler: bezier ribbons as polylines so perspective
   projection can be applied per-vertex (true 3D), shared by painter + hit ---- */
export interface SlabPt { x: number; y: number }
// Shared glass-slab camera: the painter and the hit tester MUST use the same
// projection or hover will drift from the rotated artwork.
export function sankeyCam(W: number, H: number, o: Orbit3D) {
  // Oblique-cabinet projection tuned to the reference render: depth recedes
  // up-and-right at a fixed shallow angle, and yaw only *scales* that
  // direction (never a rotation matrix), so x-order can never flip and no
  // mirror/break can occur at any orbit, size or morph step.
  const yaw = Math.max(-1.1, Math.min(1.1, o.yaw));
  const tilt = Math.max(0, Math.min(1, (o.pitch + 0.15) / 1.25));
  const dir = yaw >= 0 ? 1 : -1;
  const k = 0.34 + 0.30 * Math.min(1, Math.abs(yaw) / 0.6); // 0.34..0.64
  const dx = dir * k, dy = -(0.30 + 0.34 * tilt);
  const px = (x: number, y: number, z: number): number => x + z * dx;
  const py = (x: number, y: number, z: number): number => {
    const s = 1 / (1 + Math.max(0, z) * 0.0009);
    return H / 2 + (y - H / 2) * (0.985 - tilt * 0.06) * s + z * -dy * -1 * s;
  };
  return { px, py };
}
export const SK_SEG = 22;
export function sankeySlab(f: SkFlow, nodes: SkNode[], nodeW: number, spread: number): { top: SlabPt[]; bot: SlabPt[] } {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x;
  const c1 = x0 + (x1 - x0) * 0.5, c2 = x1 - (x1 - x0) * 0.5;
  const tA0 = f.sy0 - spread, tA1 = f.sy1 + spread, tB0 = f.ty0 - spread, tB1 = f.ty1 + spread;
  const top: SlabPt[] = [], bot: SlabPt[] = [];
  for (let s = 0; s <= SK_SEG; s++) {
    const tt = s / SK_SEG, u = 1 - tt;
    const bx = u * u * u * x0 + 3 * u * u * tt * c1 + 3 * u * tt * tt * c2 + tt * tt * tt * x1;
    const by0 = u * u * u * tA0 + 3 * u * u * tt * tA0 + 3 * u * tt * tt * tB0 + tt * tt * tt * tB0;
    const by1 = u * u * u * tA1 + 3 * u * u * tt * tA1 + 3 * u * tt * tt * tB1 + tt * tt * tt * tB1;
    top.push({ x: bx, y: by0 }); bot.push({ x: bx, y: by1 });
  }
  return { top, bot };
}

/* ---- radial bar geometry ---- */
/* ---- radial pipe renderer: solves the flat-tube problem ----
   A flat 3D ring reads as a ribbon because its top face is a single fill.
   A pipe reads as a pipe because light wraps around its circular cross
   section. pipeShade() reproduces that wrap analytically: given the
   fractional position v across the tube (0 = inner wall, 1 = outer wall),
   it returns the light factor of a cylinder lit from the top-left —
   bright crest, saturated flank, dark contact edge — so N stacked strokes
   fuse into one round tube. Ends are NOT round dots: they are flat radial
   cuts (butt caps) whose top edge follows the same perspective squash as
   the ring, exactly like a sawn pipe end. */
export const pipeShade = (v: number) => 0.62 + 0.78 * Math.sin(Math.PI * Math.min(1, Math.max(0, v)));

/* ---- sankey-3D glass-tube renderer (matches the reference render) ----
   Reference anatomy, observed pixel-by-pixel:
   - Nodes are OPAQUE vertical glass bars with a rounded top / elliptical cap,
     a bright vertical sheen band on the face, and the "Name · value" label
     printed ON the bar face (dark ink on light bars, white on dark bars).
   - Ribbons are TRANSLUCENT glass tubes: bright highlight along the TOP edge,
     saturated color through the middle, deep saturated color along the
     BOTTOM edge, with a soft blurred shadow cast beneath each tube onto the
     glossy off-white floor. Tube color = horizontal source→target blend.
   - Thin downstream ribbons (Offered→Hired/Declined) curve gracefully and
     the tiny end nodes sit as small glass blocks the tubes plug into.
   The helpers below reproduce exactly that construction. */
export const SK3_TUBE_SEG = 40;
/** Sample a ribbon's S-curve edges into a polyline tube.
   Reference curvature: the bend concentrates ~55% across (smoothstep ease),
   NOT a symmetric cubic — that is what makes tubes swoop and settle like
   the reference instead of bowing evenly. Bevel bulbs at the mouths are
   intentional (the reference tubes bulge slightly as they leave the bars). */
export function sk3Smooth(u: number): number {
  const t = Math.max(0, Math.min(1, u));
  return t * t * t * (t * (t * 6 - 15) + 10);
}
export function sk3Tube(f: SkFlow, nodes: SkNode[], nodeW: number): { top: SlabPt[]; bot: SlabPt[] } {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x;
  const top: SlabPt[] = [], bot: SlabPt[] = [];
  for (let s = 0; s <= SK3_TUBE_SEG; s++) {
    const u = s / SK3_TUBE_SEG;
    const e = sk3Smooth(u);
    const bx = x0 + (x1 - x0) * u;
    const by0 = f.sy0 + (f.ty0 - f.sy0) * e;
    const by1 = f.sy1 + (f.ty1 - f.sy1) * e;
    // bevel bulb: tube mouths bulge ~12% near the bars, like the reference
    const bulb = 1 + 0.12 * (Math.exp(-Math.pow(u / 0.10, 2)) + Math.exp(-Math.pow((1 - u) / 0.10, 2)));
    const mid = (by0 + by1) / 2, half = ((by1 - by0) / 2) * bulb;
    top.push({ x: bx, y: mid - half }); bot.push({ x: bx, y: mid + half });
  }
  return { top, bot };
}
/** Fill the tube silhouette between two sampled edges. */
export function sk3FillTube(ctx: Ctx, T: SlabPt[], B: SlabPt[]) {
  ctx.beginPath();
  T.forEach((q, k) => { k === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y); });
  for (let k = B.length - 1; k >= 0; k--) ctx.lineTo(B[k].x, B[k].y);
  ctx.closePath(); ctx.fill();
}
/** Stroke one sampled edge. */
export function sk3StrokeEdge(ctx: Ctx, E: SlabPt[]) {
  ctx.beginPath();
  E.forEach((q, k) => { k === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y); });
  ctx.stroke();
}
/** Vertical glass gradient for a tube: bright crown → mid color → deep base. */
export function sk3TubeGrad(ctx: Ctx, yTop: number, yBot: number, c0: string, c1: string, a: number) {
  const g = ctx.createLinearGradient(0, yTop, 0, Math.max(yTop + 1, yBot));
  g.addColorStop(0, rgba(shade(c0, 1.45), a));
  g.addColorStop(0.28, rgba(shade(c0, 1.12), a));
  g.addColorStop(0.55, rgba(c1, a));
  g.addColorStop(1, rgba(shade(c1, 0.62), Math.min(1, a + 0.1)));
  return g;
}
export function radialGeom(W: number, H: number, data: ChartDatum[], full: boolean, m = 0) {
  const n = Math.max(1, data.length);
  // Adaptive label column: only reserve side space when there is genuinely
  // room (large canvas or fullscreen). On small tiles / narrow exports every
  // pixel goes to the rings and labels render inside the tubes instead.
  const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
  const roomy = full || W >= 560;
  const labelSpace = roomy ? longest + 26 : 0;
  const squash = 1 - 0.44 * m;
  // Vertical budget accounts for the 3D squash: an untilted disc needs its
  // full radius, a squashed one needs far less height.
  const vBudget = full ? (H - 32) / 2 : (H - 24) / 2;
  const R = Math.max(26, Math.min((W - labelSpace) / 2 - 10, vBudget / Math.max(0.5, squash) - 4));
  const cx = labelSpace + (W - labelSpace) / 2, cy = H / 2;
  // Tube thickness adapts to ring count so N rings always fit: thin tubes for
  // many rings (min 3px), chunky tubes for few (max 22px). The inner hole
  // keeps a floor of 14px so the last (innermost) bar never splits/collapses.
  const avail = Math.max(30, R - 16);
  const thick = Math.max(3, Math.min(22, avail / Math.max(1, n * 1.22)));
  const gap = Math.max(1.5, Math.min(4, thick * 0.28));
  const radiusOf = (i: number) => R - thick / 2 - i * (thick + gap);
  // Clamp helper: keeps the innermost tube's inner edge >= minHole so the
  // last bar can never invert / split into a broken ring.
  const minHole = 13;
  const ringR = (i: number) => Math.max(thick / 2 + minHole, radiusOf(i));
  return { cx, cy, R, thick, gap, radiusOf, ringR, labelSpace, n, roomy };
}

/* ---- radial classic geometry: fixed-diameter rings that can never overlap ----
   Pitch is SOLVED from the ring count (n·thick + (n−1)·gap ≤ R − minHole),
   so adjacent tubes always clear each other. Shared verbatim by the painter
   and the hit tester. */
export interface RadialClassicGeom { cx: number; cy: number; R: number; thick: number; gap: number; ringR: (i: number) => number; n: number; roomy: boolean }
export function radialClassicGeom(W: number, H: number, data: ChartDatum[], full: boolean): RadialClassicGeom {
  const n = Math.max(1, data.length);
  const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
  const roomy = full || W >= 560;
  const gutter = roomy ? Math.min(longest + 30, W * 0.34) : 0;
  const R = Math.max(40, Math.min((W - gutter) / 2 - 14, H / 2 - 14));
  const cx = gutter + (W - gutter) / 2, cy = H / 2;
  const minHole = 16;
  const avail = Math.max(24, R - minHole);
  const GAP_RATIO = 0.38;
  let thick = Math.min(26, avail / (n + (n - 1) * GAP_RATIO));
  thick = Math.max(4, thick);
  let gap = Math.max(2, thick * GAP_RATIO);
  const total = n * thick + (n - 1) * gap;
  if (total > avail) { const k = avail / total; thick *= k; gap *= k; }
  const ringR = (i: number) => R - thick / 2 - i * (thick + gap);
  return { cx, cy, R, thick, gap, ringR, n, roomy };
}

export const funnelLabel = (x: ChartDatum, total: number) => `${x.label} · ${x.value} (${Math.round((x.value / total) * 100)}%)`;
export function funnelGeom(W: number, H: number, m: number, data: ChartDatum[], full: boolean, pyramid = false) {
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const longest = Math.max(0, ...data.map((x) => approxW(funnelLabel(x, total))));
  const labelSpace = full ? longest + 40 : Math.min(160, W * 0.3);
  const padT = 16, padB = 16;
  // the visual envelope is identical in 2D and 3D — the 3D body shrinks to
  // make room for its elliptical caps instead of growing past it
  const env = Math.min(H - padT - padB, W * 0.62);
  const sq = 0.16 * m;
  const ch = env / (1 + 1.2 * sq);
  // the 3D pyramid's side face extends 20 % of the base width to the right;
  // reserve that room so the leader lane always clears it
  const side = pyramid ? 0.2 * 0.96 * m : 0;
  const plotW = Math.min((W - labelSpace - 60) / (1 + side / 2), ch * 1.15);
  const capTop = (plotW / 2) * sq;
  const topY = padT + (H - padT - padB - env) / 2 + capTop;
  const cx = (W - labelSpace) / 2 + 10 - (plotW * side) / 4;
  // x where every leader turns towards its label: just right of the widest point
  const laneX = cx + (plotW / 2) * 0.96 + plotW * side + 14;
  return { total, labelSpace, ch, plotW, sq, topY, cx, capTop, laneX };
}

/* ================= leader labels — curved arrows attached ON the rim ================= */
export function drawLeaders(ctx: Ctx, cx: number, cy: number, R: number, squash: number, data: ChartDatum[], colors: string[], total: number, t: Theme, W: number, H: number, equalAngles = false, full = false, rot = 0) {
  ctx.font = font(t, 600, full ? 13 : 12);
  const n = data.length;
  let a = -Math.PI / 2 + rot;
  interface E { i: number; mid: number; right: boolean; y: number }
  const entries: E[] = data.map((d, i) => {
    let mid: number;
    if (equalAngles) mid = -Math.PI / 2 + rot + ((i + 0.5) * Math.PI * 2) / n;
    else { const a2 = a + (d.value / total) * Math.PI * 2; mid = (a + a2) / 2; a = a2; }
    return { i, mid, right: Math.cos(mid) >= 0, y: cy + Math.sin(mid) * (R + 20) * squash };
  });
  const place = (list: E[]) => {
    list.sort((p, q) => p.y - q.y);
    let prev = -Infinity;
    list.forEach((e) => { e.y = Math.max(e.y, prev + 18); prev = e.y; });
    list.forEach((e) => { e.y = Math.max(12, Math.min(H - 8, e.y)); });
  };
  place(entries.filter((e) => e.right));
  place(entries.filter((e) => !e.right));

  entries.forEach((e) => {
    const d = data[e.i];
    const ax = cx + Math.cos(e.mid) * R;
    const ay = cy + Math.sin(e.mid) * R * squash;
    const qx = cx + Math.cos(e.mid) * (R + 18);
    const qy = cy + Math.sin(e.mid) * (R + 18) * squash;
    const ex = cx + (e.right ? R + 26 : -(R + 26));
    const tx = cx + (e.right ? R + 34 : -(R + 34));
    const c1x = (ex + qx) / 2, c1y = e.y;
    const c2x = qx, c2y = qy;
    // end tangent (anchor − c2) → arrow direction
    const dx = ax - c2x, dy = ay - c2y;
    const dl = Math.hypot(dx, dy) || 1;
    const ux = dx / dl, uy = dy / dl;
    const px2 = -uy, py2 = ux;
    // the curve stops where the arrowhead begins so nothing overdraws the head
    const bx = ax - ux * 8, by = ay - uy * 8;
    ctx.strokeStyle = colors[e.i];
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(tx, e.y);
    ctx.lineTo(ex, e.y);
    ctx.bezierCurveTo(c1x, c1y, c2x, c2y, bx, by);
    ctx.stroke();
    // arrowhead: tip sits ON the rim, outlined so it reads cleanly against any background
    ctx.fillStyle = colors[e.i];
    ctx.beginPath();
    ctx.moveTo(ax + ux * 0.5, ay + uy * 0.5);
    ctx.lineTo(bx - ux * 1.2 + px2 * 4.2, by - uy * 1.2 + py2 * 4.2);
    ctx.lineTo(bx - ux * 1.2 - px2 * 4.2, by - uy * 1.2 - py2 * 4.2);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.lineJoin = 'round';
    ctx.stroke();
    ctx.lineJoin = 'miter';
    // label — larger font (12px / 13px), clear legible text
    const avail = e.right ? W - tx - 8 : tx - 8;
    ctx.fillStyle = t.ink;
    ctx.textAlign = e.right ? 'left' : 'right';
    const text = leaderLabel(d, total);
    ctx.fillText(full ? text : fitCtx(ctx, text, avail), tx + (e.right ? 4 : -4), e.y + 4);
  });
  ctx.textAlign = 'left';
}

/* ================= axes ================= */
export function drawAxes(ctx: Ctx, W: number, H: number, pad: { l: number; r: number; t: number; b: number }, max: number, t: Theme, ox = 0, oy = 0) {
  const ch = H - pad.t - pad.b;
  ctx.font = font(t, 600, 10.5);
  for (let g = 0; g <= 4; g++) {
    const y = pad.t + ch - (ch * g) / 4;
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    ctx.beginPath();
    if (ox) { ctx.moveTo(pad.l, y); ctx.lineTo(pad.l + ox, y - oy); ctx.lineTo(W - pad.r + ox, y - oy); }
    else { ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); }
    ctx.stroke();
    ctx.fillStyle = t.axis; ctx.textAlign = 'right';
    ctx.fillText(fmtNum((max * g) / 4), pad.l - 7, y + 3.5);
  }
  ctx.strokeStyle = t.axis; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(pad.l, pad.t - 4); ctx.lineTo(pad.l, pad.t + ch); ctx.lineTo(W - pad.r, pad.t + ch); ctx.stroke();
  ctx.lineWidth = 1;
  ctx.textAlign = 'left';
}

/* ================= streamgraph model + geometry (Highcharts-style) =================
   Layers stack with an inside-out order (largest centred) over a smoothed
   silhouette baseline, drawn with freehand-smooth Catmull-Rom boundaries.
   Shared verbatim by the painter and the hit tester so hover always matches. */
export interface StreamLayer { name: string; color: string; values: number[] }
export interface StreamGeom {
  list: StreamLayer[]; labels: string[]; xs: number[];
  /** bound[k][j]: px y of the k-th stack boundary (0 = bottom) at column j */
  bound: number[][]; order: number[]; posOf: number[];
  padT: number; padB: number; plotW: number; plotH: number; midY: number;
  plan: XPlan;
  /** per-column totals (raw, unsmoothed) — for markers + hit % */
  totals: number[];
}
/** Canonical 10-year salary-story demo (Highcharts-style streamgraph):
 * TEN yearly salary layers (₹L p.a. salary mass per cohort) telling the
 * company's decade: joiners, exits, rejoiners, a layoff year (2021), a bonus
 * year (2023) and contract hiring (2025). Cohorts:
 *  Founders         — here all 10 years, steady compounding rises;
 *  Eng Early        — 2016 crew, fast early raises, some leave in 2021;
 *  Eng Growth       — joins 2018 hiring wave, fastest raises of anyone;
 *  Sales Core       — joins 2017, dips in the layoff, rebounds on bonus;
 *  Support          — joins 2017, flat middle years, exits partly in 2024;
 *  Marketing        — joins 2019, cut HARD in the 2021 layoff, regrows;
 *  People Ops       — joins 2018, slow-and-steady, never leaves;
 *  Finance          — joins 2018, steady, small bonus-year bump;
 *  Boomerangs       — leave in 2020–21, REJOIN in 2022 (zero middle years);
 *  Contract Flex    — contract hiring: bursts in 2020 and 2025, zero between.
 * Used as the honest built-in demo whenever no series data is supplied. */
export const STREAM_SALARY_10Y = {
  labels: ['2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
  layers: [
    { name: 'Founders', color: '#0d7a54', values: [46, 52, 60, 68, 76, 72, 80, 96, 102, 110] },
    { name: 'Eng Early', color: '#1e5aa8', values: [74, 104, 138, 172, 198, 158, 178, 226, 240, 258] },
    { name: 'Eng Growth', color: '#0ea5e9', values: [0, 0, 52, 92, 128, 112, 152, 214, 246, 288] },
    { name: 'Sales Core', color: '#c9932b', values: [0, 58, 82, 108, 122, 92, 116, 156, 168, 186] },
    { name: 'Support', color: '#14b8a6', values: [0, 34, 48, 62, 74, 58, 68, 82, 70, 76] },
    { name: 'Marketing', color: '#e11d63', values: [0, 0, 0, 56, 62, 28, 48, 84, 92, 104] },
    { name: 'People Ops', color: '#84cc16', values: [0, 0, 30, 38, 46, 42, 50, 62, 68, 74] },
    { name: 'Finance', color: '#64748b', values: [0, 0, 26, 32, 38, 34, 40, 50, 56, 60] },
    { name: 'Boomerangs', color: '#f97316', values: [26, 34, 30, 26, 12, 0, 22, 42, 48, 54] },
    { name: 'Contract Flex', color: '#a16207', values: [0, 0, 0, 0, 44, 18, 0, 0, 26, 58] },
  ],
  events: [
    { at: 1, label: 'Sales + Support join', detail: 'GTM founded' },
    { at: 2, label: 'Hiring wave', detail: '60+ joiners' },
    { at: 5, label: 'Layoff period', detail: '-18% salary base' },
    { at: 6, label: 'Boomerangs return', detail: 'Rejoiners + growth' },
    { at: 7, label: 'Bonus year', detail: '+24% payouts' },
    { at: 9, label: 'Contract hiring', detail: 'Flex workforce' },
  ] as StreamEvent[],
};
export function streamGeom(
  multi: boolean, cats: string[], series: StackedSeries[], sColors: string[],
  data: ChartDatum[], colors: string[], pal: string[],
  W: number, H: number, full: boolean,
): StreamGeom | null {
  let list: StreamLayer[] = [];
  let labels: string[] = [];
  if (multi && series.length && cats.length >= 2) {
    labels = cats;
    list = series.map((s, i) => ({
      name: s.name, color: s.color || sColors[i] || pal[i % pal.length],
      values: cats.map((_, j) => s.values[j] || 0),
    }));
  } else if (data.length >= 2) {
    labels = data.map((x) => x.label);
    list = [{
      name: data[0]?.label ? 'Value' : 'Value',
      color: colors[0] || pal[0],
      values: data.map((x) => x.value),
    }];
  } else {
    labels = STREAM_SALARY_10Y.labels.slice();
    list = STREAM_SALARY_10Y.layers.map((l, i) => ({
      name: l.name, color: l.color || colors[i] || pal[i % pal.length], values: l.values.slice(),
    }));
  }
  const n = labels.length;
  const padT = 46, padL = 14, padR = 14;
  const plotW = W - padL - padR;
  const stepS = n > 1 ? plotW / (n - 1) : plotW;
  const plan = planX(labels, stepS, full);
  const river = buildRiverStream(list, labels, W, H, { padT, padL, padR, padB: plan.padB });
  return {
    list: river.layers, labels: river.labels, xs: river.xs, bound: river.bound,
    order: river.order, posOf: river.posOf, padT: river.padT, padB: river.padB,
    plotW: river.plotW, plotH: river.plotH, midY: river.midY, plan, totals: river.totals,
  };
}

/* ================= hover model ================= */
export interface Hover { idx: number | null; seg: { c: number; s: number } | null; amt: number }
export const NO_HOVER: Hover = { idx: null, seg: null, amt: 0 };

export interface DrawCtx {
  W: number; H: number; t: Theme; p: number; m: number; hov: Hover;
  data: ChartDatum[]; colors: string[];
  multi: boolean; cats: string[]; series: StackedSeries[]; sColors: string[];
  yLabel?: string;
  /** fullscreen / export — labels are never truncated */
  full?: boolean;
  /** opaque background (exports) — otherwise the frame is cleared to transparent */
  bg?: string;
  /** calendar-pie input (series names come from `series`) */
  days?: CalendarDay[];
  /** sankey input */
  links?: SankeyLink[];
  /** gantt input */
  tasks?: GanttTask[];
  /** scatter input */
  scatter?: ScatterPoint[];
  /** camera orbit for rotatable true-3D scenes (Sankey 3D) */
  orbit?: Orbit3D;
  /** streamgraph event flags (Highcharts-style special-event labels) */
  streamEvents?: StreamEvent[];
  /** idle spin of the toroid donut (radians, added to the 12-o'clock rest pose) */
  toroidRot?: number;
}


export function setShadow(ctx: Ctx, x: number, y: number, blur: number, color: string) {
  ctx.shadowOffsetX = x; ctx.shadowOffsetY = y; ctx.shadowBlur = blur; ctx.shadowColor = color;
}
export function noShadow(ctx: Ctx) { ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; ctx.shadowColor = 'rgba(0,0,0,0)'; }
