# Keysteady — your feel-good typing studio

A full-stack Next.js App Router rebuild of the Keysteady project supplied at https://github.com/ankur-the-coder/hrms/blob/main/typing.zip. The original React/Vite and Supabase screens were reviewed and migrated to a self-contained Next.js, PostgreSQL, and Drizzle application. No Supabase, Google OAuth, or external asset service is required.

## Included

- Interactive, physically lit Three.js keyboard on the landing page. Physical keystrokes depress keys and identify the responsible finger.
- Skinned anatomical 3D hands with a 25-joint forward-kinematics rig, a warm skin material, smooth finger articulation, active-finger highlights, and a draggable camera in guided lessons. The locally bundled generic-hand mesh is from WebXR Input Profiles (@webxr-input-profiles/assets 1.0.20); its asset license is included at `public/models/HAND-LICENSE.md`. Procedural hands are used while the rig loads.
- Native-input typing engine with memoized words, animated transform-based caret, smooth scrolling, monotonic timers, live WPM/accuracy, correction handling, composition support, mobile input, sound, and keyboard shortcuts.
- Time / words / quotes / custom text / adaptive practice; 12 English and 6 Hindi lessons; 3 velocity drills.
- Results, charts, saved attempts, accuracy and speed history, practice streaks, word mastery, CSV export, and persistent settings.
- Responsive light/dim interface, local fonts, keyboard-accessible controls, reduced-motion support, and a WebGL fallback.

## Run

1. Install packages: `npm install`.
2. Set `DATABASE_URL` in `.env` to your PostgreSQL connection string.
3. Apply the schema: `npx drizzle-kit push`. The supplied Drizzle config uses the sandbox's local database; change the config for another environment.
4. Run `npm run dev` for development, or `npm run build` then `npm run start` for a production deployment.
5. The lesson/test/drill catalog seeds idempotently on the first `/api/content` request or saved attempt.

On the managed preview, use the platform build/start tool to bootstrap PostgreSQL before pushing the schema.

## Database tables

- `profiles`: anonymous and named demo identities.
- `typing_lessons`: English and Hindi curricula with accuracy/speed targets.
- `typing_tests`: source word pools, quotes, and code content.
- `typing_attempts`: per-profile session metrics, errors, timings, and chart samples.
- `word_metrics`: unique profile/word mastery, mistakes, hesitations, and clean streaks.
- `adaptive_settings`: themes, sounds, caret, duration, live stats, and coach target.
- `velocity_drills`: seeded sprint, rhythm, and endurance training content.

All database reads and writes use Drizzle. Results and word metrics are saved in one transaction. API routes validate session inputs. No fake history or statistics are seeded.

## Deliberately open demo access

Every screen is directly accessible. Anonymous progress is attached to an HTTP-only SameSite cookie. The sign-in screen accepts any nonempty name/ID and any password (including no password). Passwords are never transmitted, read, stored, or logged. Entering a previously used demo ID opens that profile; guest results are preserved when naming a new profile and transferred to an existing demo profile when signing in.

**This is not secure authentication.** Anyone entering the same ID can see its typing progress. Use made-up credentials and no sensitive information. Replace this mechanism with real authentication before using the application with private data. Set `COOKIE_SECURE=true` for HTTPS-only cookie delivery in a production deployment.

## Useful routes

`/`, `/practice`, `/practice?mode=adaptive`, `/learn`, `/learn/1`, `/learn/101`, `/velocity`, `/velocity/sprint`, `/progress`, `/settings`, `/login`.

`/api/health` checks the database connection. Session, catalog, attempts, words, and preferences are exposed through same-origin API routes under `/api`.

Hindi lessons accept a device's Hindi keyboard or IME. The hand guidance shows standard InScript positions where available; other input layouts can still be used through the native input.
