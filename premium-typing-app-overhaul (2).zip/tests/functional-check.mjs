import { chromium, expect } from '@playwright/test';
import { mkdir } from 'node:fs/promises';
await mkdir('artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage', '--enable-unsafe-swiftshader'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
const origin = 'http://localhost:3000';
const go = path => page.goto(origin + path, { waitUntil: 'networkidle' });
try {
  await go('/practice');
  await expect(page.getByRole('textbox', { name: /Typing area/ })).toBeVisible();
  console.log('PASS: direct guest access');
  await go('/login');
  const demoId = 'qa-flow-' + Date.now();
  await page.getByLabel('Your name or ID').fill(demoId);
  await page.locator('#demo-password').fill('x');
  await page.getByRole('button', { name: 'Let me in' }).click();
  await expect(page).toHaveURL(origin + '/');
  await expect(page.locator('.profile-name')).toHaveText(demoId);
  console.log('PASS: arbitrary ID and one-character password sign in');

  await go('/practice');
  await page.getByRole('button', { name: 'custom', exact: true }).click();
  await page.getByRole('textbox', { name: 'Custom practice text' }).fill('steady hands make good habits');
  await page.getByRole('button', { name: 'Make it my practice' }).click();
  const input = page.getByRole('textbox', { name: /Typing area/ });
  await input.pressSequentially('steady hanxs make good habits', { delay: 70 });
  await expect(page.getByRole('heading', { name: /That was a good flow/ })).toBeVisible();
  await expect(page.getByText('Progress saved', { exact: true })).toBeVisible({ timeout: 15000 });
  await page.screenshot({ path: 'artifacts/result-desktop.png', fullPage: true });
  const resultResponse = await page.request.get(origin + '/api/attempts');
  const resultBody = await resultResponse.json();
  expect(resultBody.attempts.length).toBeGreaterThan(0);
  expect(resultBody.attempts[0].correctChars).toBe(28);
  expect(resultBody.attempts[0].totalChars).toBe(29);
  expect(resultBody.attempts[0].accuracy).toBeLessThan(100);
  console.log('PASS: character scoring, accuracy, result chart, and database persistence');

  await go('/practice?mode=adaptive');
  await expect(page.locator('.typing-input')).toBeVisible();
  await expect(page.locator('#typing-passage')).toContainText('hands');
  console.log('PASS: word mistakes become adaptive practice');

  await go('/learn/1');
  await expect(page.locator('.guidance-panel canvas')).toBeVisible({ timeout: 15000 });
  await page.locator('.typing-input').pressSequentially('fff jjj', { delay: 80 });
  await expect(page.locator('.typing-char.correct')).toHaveCount(7);
  await page.waitForTimeout(300);
  const caretStyle = await page.locator('.typing-caret').getAttribute('style');
  expect(caretStyle).toContain('translate3d');
  await page.locator('.typing-input').press('Tab');
  await expect(page.getByRole('button', { name: 'Start fresh', exact: true })).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page.locator('.typing-input')).toHaveValue('');
  console.log('PASS: live 3D guidance, smooth caret, correction-free input, keyboard restart');

  await go('/learn/hindi');
  await expect(page.getByRole('button', { name: 'हिन्दी', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await go('/learn/hindi/1');
  await expect(page).toHaveURL(origin + '/learn/101');
  await page.locator('.typing-input').fill('अ आ इ');
  await expect(page.locator('.typing-char.correct')).toHaveCount(5);
  console.log('PASS: legacy Hindi routes and Unicode input');

  await go('/practice/2');
  await expect(page.locator('#typing-passage')).toContainText('Almost everything will work again');
  await go('/practice/weak');
  await expect(page).toHaveURL(origin + '/practice?mode=adaptive');
  console.log('PASS: legacy test and weak-word routes');

  await go('/velocity/sprint');
  const sprintText = await page.locator('#typing-passage').textContent();
  await page.locator('.typing-input').pressSequentially(sprintText.slice(0, 40), { delay: 65 });
  await expect(page.getByRole('heading', { name: 'That was a good flow.' })).toBeVisible({ timeout: 20000 });
  await expect(page.getByText('Progress saved', { exact: true })).toBeVisible({ timeout: 10000 });
  console.log('PASS: accurate 15-second countdown and velocity result persistence');

  await go('/settings');
  await page.getByRole('switch', { name: 'Smooth caret', exact: true }).click();
  await expect(page.getByRole('switch', { name: 'Smooth caret', exact: true })).toHaveAttribute('aria-checked', 'false');
  await page.getByRole('button', { name: 'Dim', exact: true }).click();
  await page.reload({ waitUntil: 'networkidle' });
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  await expect(page.getByRole('switch', { name: 'Smooth caret', exact: true })).toHaveAttribute('aria-checked', 'false');
  await page.getByRole('button', { name: 'Light', exact: true }).click();
  await page.getByRole('switch', { name: 'Smooth caret', exact: true }).click();
  console.log('PASS: persistent theme and typing preferences');

  await go('/progress');
  await expect(page.locator('tbody tr')).toHaveCount(2);
  await expect(page.getByRole('cell', { name: 'Your own words', exact: true })).toBeVisible();
  const downloadEvent = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export progress' }).click();
  const download = await downloadEvent;
  expect(download.suggestedFilename()).toContain('keysteady-progress');
  await page.screenshot({ path: 'artifacts/progress-desktop.png', fullPage: true });
  console.log('PASS: progress history, real metrics, and CSV export');

  const invalid = await page.request.post(origin + '/api/attempts', { data: { durationSeconds: -1, correctChars: 5, totalChars: 2, accuracy: 300 } });
  expect(invalid.status()).toBe(400);
  console.log('PASS: server-side result validation');

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  mobile.on('pageerror', error => errors.push(error.message));
  await mobile.goto(origin, { waitUntil: 'networkidle' });
  await mobile.getByRole('button', { name: 'Open menu' }).click();
  await mobile.getByRole('navigation', { name: 'Mobile navigation' }).getByRole('link', { name: 'Learn', exact: true }).click();
  await expect(mobile).toHaveURL(origin + '/learn');
  expect(await mobile.evaluate(() => document.documentElement.scrollWidth > innerWidth)).toBe(false);
  await mobile.goto(origin + '/practice', { waitUntil: 'networkidle' });
  expect(await mobile.evaluate(() => document.documentElement.scrollWidth > innerWidth)).toBe(false);
  await mobile.locator('.typing-input').pressSequentially('a little flow', { delay: 50 });
  await expect(mobile.locator('.typing-input')).toHaveValue('a little flow');
  console.log('PASS: responsive navigation, layout, and mobile typing');
  await mobile.close();
  expect(errors).toEqual([]);
  console.log('PASS: no uncaught browser exceptions');
  console.log('All functional checks passed. Demo test profile:', demoId);
} catch (error) {
  console.error(error);
  await page.screenshot({ path: 'artifacts/functional-failure.png', fullPage: true });
  process.exitCode = 1;
} finally {
  await browser.close();
}
