"use client";
import { useId } from "react";
import type { SpeedPoint } from "@/lib/types";

export function SpeedChart({ points, duration, sessionAxis = false }: { points: SpeedPoint[]; duration?: number; sessionAxis?: boolean }) {
  const id = useId().replace(/:/g, "");
  const width = 640, height = 164, left = 31, top = 12, bottom = 25, right = 12;
  const maxX = Math.max(1, duration || points.at(-1)?.second || 1);
  const maxY = Math.max(40, Math.ceil(Math.max(...points.map(p => p.wpm), 0) / 20) * 20 + 20);
  const x = (n: number) => left + (n / maxX) * (width - left - right);
  const y = (n: number) => height - bottom - (n / maxY) * (height - top - bottom);
  const safePoints = points.length ? points : [{ second: 0, wpm: 0 }, { second: maxX, wpm: 0 }];
  const path = safePoints.map((p, i) => `${i === 0 ? "M" : "L"} ${x(p.second).toFixed(2)} ${y(p.wpm).toFixed(2)}`).join(" ");
  const area = `${path} L ${x(safePoints.at(-1)!.second)} ${height - bottom} L ${x(safePoints[0].second)} ${height - bottom} Z`;
  return <svg className="speed-chart" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" role="img" aria-label={`Typing speed chart. ${safePoints.map(p => `${sessionAxis ? "Session" : "Second"} ${p.second}: ${p.wpm} words per minute`).join(". ")}`}>
    <defs><linearGradient id={`chart-${id}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#b698d0" stopOpacity="0.2" /><stop offset="100%" stopColor="#b698d0" stopOpacity="0" /></linearGradient></defs>
    {[0, 1, 2, 3, 4].map(n => <g key={n}><line className="chart-grid" x1={left} x2={width - right} y1={y(maxY * n / 4)} y2={y(maxY * n / 4)} /><text className="chart-label" textAnchor="end" x={left - 10} y={y(maxY * n / 4) + 3}>{Math.round(maxY * n / 4)}</text></g>)}
    {[0, 1, 2, 3, 4, 5].map(n => <text key={n} className="chart-label" textAnchor="middle" x={x(maxX * n / 5)} y={height - 5}>{Math.round(maxX * n / 5)}{sessionAxis ? "" : "s"}</text>)}
    <path d={area} fill={`url(#chart-${id})`} /><path className="chart-line" d={path} />
    {safePoints.length < 20 && safePoints.map((p, i) => <circle key={i} cx={x(p.second)} cy={y(p.wpm)} r={2.5} fill="#a280be"><title>{p.wpm} wpm</title></circle>)}
  </svg>;
}
