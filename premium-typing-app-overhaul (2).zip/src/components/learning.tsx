"use client";

import Link from "next/link";
import dynamic from "next/dynamic";
import { useCallback, useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, ArrowUpRight, BookOpen, CheckCircle2, ChevronRight, Gauge, Hand, Lightbulb, MousePointer2, Sparkles, Target } from "lucide-react";
import { Shell } from "./shell";
import { useApp } from "./app-provider";
import { useCatalog } from "@/lib/use-catalog";
import { fingerMap, hindiPhysicalKeys } from "@/lib/catalog";
import { TypingEngine } from "./typing-engine";
import { Toggle } from "./ui";
import type { Attempt } from "@/lib/types";

const KeyboardScene = dynamic(() => import("./keyboard-scene"), { ssr: false, loading: () => <div className="scene-loading"><span /><span /><span /></div> });
export function LearningLibrary({ initialLanguage = "en" }: { initialLanguage?: string }) {
  const { lessons } = useCatalog();
  const { profile, ready, refreshKey } = useApp();
  const [language, setLanguage] = useState(initialLanguage);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  useEffect(() => { if (!ready) return; let active = true; fetch("/api/attempts").then(r => r.ok ? r.json() : { attempts: [] }).then(data => { if (active) setAttempts(data.attempts); }).catch(() => {}); return () => { active = false; }; }, [ready, profile?.id, refreshKey]);
  const selected = lessons.filter(lesson => lesson.language === language);
  const completed = new Set(lessons.filter(lesson => attempts.some(attempt => attempt.lessonId === lesson.id && attempt.wpm >= lesson.targetWpm && attempt.accuracy >= lesson.targetAccuracy)).map(lesson => lesson.id));
  return <Shell><div className="page-container"><div className="page-heading"><div><span className="eyebrow">FIND YOUR FOUNDATION</span><h1>Good habits. <em>Great beginnings.</em></h1><p>Give every finger a home. Build a skill that stays with you, one gentle lesson at a time.</p></div><div className="segmented-control" aria-label="Lesson language"><button onClick={() => setLanguage("en")} className={language === "en" ? "active" : ""} aria-pressed={language === "en"}>English</button><button onClick={() => setLanguage("hi")} className={language === "hi" ? "active" : ""} aria-pressed={language === "hi"}>हिन्दी</button></div></div>
    <div className="learning-intro"><span><Hand size={23} strokeWidth={1.5} /></span><div><h3>{language === "en" ? "A home for every finger. A guide for every step." : "नई भाषा, वही आत्मविश्वास।"}</h3><p>{language === "en" ? "Follow your interactive 3D hands. Take your time. Accuracy first, speed follows." : "Practice using your Hindi keyboard or IME. Begin with vowels and grow into full sentences."}</p></div><span className="text-link">{selected.filter(lesson => completed.has(lesson.id)).length} / {selected.length} lessons completed <CheckCircle2 size={15} /></span></div>
    <div className="lesson-grid">{selected.map((lesson, index) => <Link href={`/learn/${lesson.id}`} key={lesson.id} className="lesson-card"><div className="lesson-card-header"><span className="lesson-number">LESSON {String(index + 1).padStart(2, "0")}</span>{completed.has(lesson.id) ? <span className="lesson-status"><CheckCircle2 size={12} /> All yours</span> : index === 0 ? <span className="lesson-status" style={{ color: "var(--violet)" }}><Sparkles size={12} /> Start here</span> : <ArrowUpRight size={14} color="var(--soft)" />}</div><div className="lesson-keys">{lesson.keys.split(" ").slice(0, 6).map((key, i) => <kbd key={i}>{key}</kbd>)}{lesson.keys.split(" ").length > 6 && <kbd>+{lesson.keys.split(" ").length - 6}</kbd>}</div><h3>{lesson.title}</h3><p>{lesson.description}</p><div className="lesson-card-footer"><span><Gauge size={12} />{lesson.targetWpm} wpm</span><span><Target size={12} />{lesson.targetAccuracy}% accuracy</span><ChevronRight size={14} /></div></Link>)}</div>
    <div className="research-note"><Lightbulb size={14} /> Just five minutes a day can build a habit. Pick up where you left off — there’s no rush.</div>
  </div></Shell>;
}

export function LearningSession({ lessonId }: { lessonId: number }) {
  const { lessons } = useCatalog();
  const lesson = lessons.find(item => item.id === lessonId);
  const [seed, setSeed] = useState(0);
  const [key, setKey] = useState(lesson?.practiceText[0] || "f");
  const [showHands, setShowHands] = useState(true);
  const handleNext = useCallback((value: string) => setKey(value), []);
  if (!lesson) return <Shell><div className="not-found"><h1>This lesson took a little detour.</h1><p>Your next beginning is waiting in the lesson library.</p><Link className="button button-dark" href="/learn">Back to lessons <ArrowRight size={17} /></Link></div></Shell>;
  const siblings = lessons.filter(item => item.language === lesson.language);
  const index = siblings.findIndex(item => item.id === lesson.id);
  const next = siblings[index + 1];
  const physicalKey = lesson.language === "hi" ? hindiPhysicalKeys[key] || "" : key;
  const finger = key === " " ? "Either thumb" : fingerMap[physicalKey.toLowerCase()] || (lesson.language === "hi" ? "Hindi input method" : "Follow your home row");
  return <Shell compact><div className="page-container"><div className="breadcrumb"><Link href="/learn"><ArrowLeft size={12} style={{ display: "inline", verticalAlign: "middle", marginRight: 5 }} />Your foundation</Link><ChevronRight size={12} /><span>Lesson {String(index + 1).padStart(2, "0")} of {siblings.length}</span></div><div className="lesson-session-header"><div><span className="eyebrow">ONE GOOD HABIT AT A TIME</span><h1>{lesson.title}<span className="heading-dot">.</span></h1><p>{lesson.description}</p></div><div className="lesson-session-meta"><span><Gauge size={14} />{lesson.targetWpm} wpm</span><span><Target size={14} />{lesson.targetAccuracy}% accuracy</span><span><Hand size={14} /><Toggle checked={showHands} label="Show 3D hand guidance" onChange={setShowHands} /></span></div></div>
    <TypingEngine key={`${lesson.id}-${seed}`} text={lesson.practiceText} duration={null} module="learn" title={lesson.title} lessonId={lesson.id} language={lesson.language} targetWpm={lesson.targetWpm} targetAccuracy={lesson.targetAccuracy} onNextKey={handleNext} onRestart={() => { setSeed(n => n + 1); setKey(lesson.practiceText[0]); }} nextLessonHref={next ? `/learn/${next.id}` : "/learn"} />
    {showHands && <div className="guidance-panel"><div className="guidance-panel-heading"><h3><Hand size={14} />Your hands, in harmony.</h3><p>{lesson.language === "hi" ? "Standard InScript positions. Use your Hindi IME." : "Follow the highlighted finger. Drag to look around."}</p></div><div className="next-finger-chip"><span className="mini-key">{key === " " ? "␣" : key.toUpperCase() || "✓"}</span><div><small>{key ? "UP NEXT" : "NICELY DONE"}</small><strong>{key ? finger : "Find that flow again."}</strong></div></div><KeyboardScene variant="guide" activeKey={physicalKey} /><div className="finger-legend"><span><i />Pinky · A / ;</span><span><i />Ring · S / L</span><span><i />Middle · D / K</span><span><i />Index · F / J</span><span><i />Thumbs · Space</span></div></div>}
    <p className="guidance-tip"><Lightbulb size={14} />{lesson.language === "hi" ? "Switch your device to Hindi input before typing. Composition and mobile keyboards are supported." : "Feel the little ridges on F and J? That’s home. Keep your wrists light and your shoulders relaxed."}</p>
  </div></Shell>;
}
