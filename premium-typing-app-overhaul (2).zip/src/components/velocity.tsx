"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, ArrowUpRight, AudioLines, ChevronRight, Clock3, Flag, Gauge, HeartPulse, Lightbulb, Sparkles, Target, Zap } from "lucide-react";
import { Shell } from "./shell";
import { useCatalog } from "@/lib/use-catalog";
import { buildPassage } from "@/lib/typing-utils";
import { TypingEngine } from "./typing-engine";

const drillIcons = { sprint: Zap, rhythm: AudioLines, endurance: HeartPulse };
export function VelocityLibrary() {
  const { drills } = useCatalog();
  return <Shell><div className="page-container"><div className="page-heading"><div><span className="eyebrow">THE VELOCITY LAB</span><h1>Your next gear is <em>in here.</em></h1><p>A little adrenaline. A little intention. Short, focused drills to turn comfortable into confident.</p></div><Link href="/progress" className="text-link">See your personal bests <ArrowUpRight size={15} /></Link></div><div className="velocity-intro"><Gauge size={41} strokeWidth={1.3} /><div><h3>Fast is good. Effortless is better.</h3><p>Build speed without losing your flow. Each drill trains a different part of the rhythm — your burst, your consistency, or your staying power.</p></div><div className="velocity-mini-track"><span /><span /><span /><Zap size={34} strokeWidth={1.3} /></div></div>
    <div className="drill-grid">{drills.map((drill, index) => { const Icon = drillIcons[drill.id as keyof typeof drillIcons] || Zap; return <article className="drill-card" key={drill.id}><div className="drill-card-header"><span>EXPERIMENT 0{index + 1}</span><span><Clock3 size={11} />{drill.duration} seconds</span></div><div className="drill-illustration"><Icon /></div><h3>{drill.title}</h3><p>{drill.description}</p><div className="drill-card-details"><span><Target size={13} />{drill.targetWpm} wpm target</span><span><Sparkles size={13} />{drill.id === "sprint" ? "Quick burst" : drill.id === "rhythm" ? "Steady cadence" : "Lasting focus"}</span></div><Link className="button button-outline" href={`/velocity/${drill.id}`}>Let’s find that gear <ArrowUpRight size={16} /></Link></article>; })}</div><p className="research-note"><Lightbulb size={14} /> The sweet spot is just outside your comfort zone. If your accuracy slips, ease back a little.</p>
  </div></Shell>;
}
export function VelocitySession({ drillId }: { drillId: string }) {
  const { drills } = useCatalog();
  const drill = drills.find(item => item.id === drillId);
  const [seed, setSeed] = useState(1);
  const runner = useRef<HTMLSpanElement>(null);
  const liveLabel = useRef<HTMLElement>(null);
  const handleLive = useCallback((wpm: number, progress: number) => { if (runner.current) runner.current.style.left = `${Math.min(1, progress) * 100}%`; if (liveLabel.current) liveLabel.current.textContent = `${wpm} wpm`; }, []);
  const text = useMemo(() => drill ? buildPassage(drill.content.split(" "), drill.duration * 6 + 20, seed) : "", [drill, seed]);
  useEffect(() => { handleLive(0, 0); }, [seed, handleLive]);
  if (!drill) return <Shell><div className="not-found"><h1>A little detour.</h1><p>This drill isn’t in the lab. Let’s find you another one.</p><Link className="button button-dark" href="/velocity">Back to the lab <ArrowRight size={17} /></Link></div></Shell>;
  return <Shell compact><div className="page-container practice-page"><div className="breadcrumb"><Link href="/velocity"><ArrowLeft size={12} style={{ display: "inline", marginRight: 5, verticalAlign: "middle" }} />The velocity lab</Link><ChevronRight size={12} /><span>{drill.title}</span></div><div className="page-heading"><div><span className="eyebrow">A LITTLE CHALLENGE. A NEW KIND OF FLOW.</span><h1>{drill.title}<span className="heading-dot">.</span></h1><p>{drill.description}</p></div><span className="session-configuration"><Clock3 size={13} />{drill.duration}s<span> · </span><Target size={13} />{drill.targetWpm} wpm</span></div><TypingEngine key={`${drill.id}-${seed}`} text={text} duration={drill.duration} module="velocity" title={drill.title} onRestart={() => setSeed(n => n + 1)} onLiveStats={handleLive} />
    <div className="velocity-race"><div className="race-label"><span>Your flow, from start to finish</span><span><strong ref={liveLabel}>0 wpm</strong> · {drill.targetWpm} wpm target</span></div><div className="race-track"><span ref={runner} className="race-runner"><Zap size={13} /></span><Flag size={18} className="race-goal" /></div></div><p className="research-note"><Lightbulb size={14} />{drill.id === "sprint" ? "Light fingers, quick moves. Let muscle memory take the lead." : drill.id === "rhythm" ? "Think of the keys like a quiet drumbeat. Keep the spaces as steady as the letters." : "Breathe, relax, and keep moving. The goal is a pace you can make your own."}</p>
  </div></Shell>;
}
