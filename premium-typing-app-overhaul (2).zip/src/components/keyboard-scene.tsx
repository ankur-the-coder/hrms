"use client";

import { Component, Suspense, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ContactShadows, Environment, Lightformer, OrbitControls, RoundedBox } from "@react-three/drei";
import * as THREE from "three";
import { fingerMap } from "@/lib/catalog";
import { RiggedHand } from "./rigged-hand";

interface KeyDefinition { label: string; key: string; width: number; x: number; z: number; accent?: boolean; modifier?: boolean }
const rawRows: [string, number][] [] = [
  [["esc", 1], ..."1234567890-=".split("").map(k => [k, 1] as [string, number]), ["backspace", 2]],
  [["tab", 1.5], ..."qwertyuiop[]".split("").map(k => [k, 1] as [string, number]), ["\\", 1.5]],
  [["caps", 1.8], ..."asdfghjkl;'".split("").map(k => [k, 1] as [string, number]), ["enter", 2.2]],
  [["shift", 2.3], ..."zxcvbnm,./".split("").map(k => [k, 1] as [string, number]), ["shift", 2.7]],
  [["ctrl", 1.2], ["⌘", 1.2], ["alt", 1.2], ["space", 6.2], ["alt", 1.2], ["fn", 1.2], ["←", 0.93], ["↓", 0.93], ["→", 0.94]],
];
const keyDefinitions: KeyDefinition[] = rawRows.flatMap((row, r) => {
  let offset = -5.4;
  return row.map(([label, width]) => {
    const x = offset + width * 0.36;
    offset += width * 0.72;
    return { label, key: label === "space" ? " " : label, width: width * 0.72 - 0.065, x, z: (r - 2) * 0.72, accent: ["esc", "enter"].includes(label), modifier: label.length > 1 || label === "⌘" };
  });
});
const positions = Object.fromEntries(keyDefinitions.map(key => [key.key, { x: key.x, z: key.z }]));
const keyTextures = new Map<string, THREE.CanvasTexture>();
function legendTexture(label: string, light: boolean) {
  const cacheKey = `${label}-${light}`;
  const cached = keyTextures.get(cacheKey);
  if (cached) return cached;
  const canvas = document.createElement("canvas"); canvas.width = 256; canvas.height = 128;
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, 256, 128);
  ctx.fillStyle = light ? "#ffffff" : "#686173";
  ctx.font = `${label.length > 1 ? 23 : 32}px Arial, sans-serif`;
  ctx.textAlign = "left"; ctx.textBaseline = "middle";
  if (label !== "space") ctx.fillText(label === "backspace" ? "⌫" : label === "enter" ? "enter ↵" : label.toUpperCase().length === 1 ? label.toUpperCase() : label, 32, 37);
  if (label === "f" || label === "j") { ctx.fillStyle = "#c1b9c6"; ctx.fillRect(110, 104, 36, 4); }
  if (label === "space") { ctx.fillStyle = "#988ba9"; ctx.font = "14px Arial"; ctx.textAlign = "center"; ctx.fillText("f i n d   y o u r   f l o w", 128, 65); }
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace; texture.anisotropy = 4;
  keyTextures.set(cacheKey, texture); return texture;
}

type Press = { key: string; at: number };
function Keycap({ definition, press, activeKey, reduced }: { definition: KeyDefinition; press: React.RefObject<Press>; activeKey: string; reduced: boolean }) {
  const ref = useRef<THREE.Group>(null);
  const material = useRef<THREE.MeshStandardMaterial>(null);
  const texture = useMemo(() => legendTexture(definition.label, Boolean(definition.accent)), [definition.label, definition.accent]);
  const active = definition.key === activeKey.toLowerCase();
  const color = definition.accent ? (definition.key === "esc" ? "#9a78c8" : "#b79acf") : definition.key === " " ? "#e0d5eb" : definition.modifier ? "#e2dce6" : "#faf7f0";
  useFrame(({ clock }, delta) => {
    if (!ref.current) return;
    const pressed = press.current.key === definition.key && performance.now() - press.current.at < 200;
    const autoPulse = active && !reduced ? Math.max(0, Math.sin(clock.elapsedTime * 3.5)) * 0.035 : 0;
    const target = 0.32 - (pressed ? 0.115 : autoPulse);
    ref.current.position.y = THREE.MathUtils.damp(ref.current.position.y, target, 22, delta);
    if (material.current) material.current.emissiveIntensity = THREE.MathUtils.damp(material.current.emissiveIntensity, pressed ? 0.5 : active ? 0.24 : 0, 12, delta);
  });
  return <group ref={ref} position={[definition.x, 0.32, definition.z]}>
    <RoundedBox args={[definition.width, 0.38, 0.64]} radius={0.065} smoothness={3} castShadow receiveShadow>
      <meshStandardMaterial ref={material} color={active ? "#bd9fde" : color} roughness={0.38} metalness={0.045} emissive="#9e74d6" emissiveIntensity={0} />
    </RoundedBox>
    <mesh position={[0, 0.194, 0]} rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[definition.width * 0.96, 0.61]} />
      <meshBasicMaterial map={texture} transparent depthWrite={false} polygonOffset polygonOffsetFactor={-1} />
    </mesh>
  </group>;
}

function MechanicalKeyboard({ press, activeKey, reduced }: { press: React.RefObject<Press>; activeKey: string; reduced: boolean }) {
  return <group>
    <RoundedBox args={[11.22, 0.48, 4.13]} position={[0, -0.065, 0]} radius={0.2} smoothness={5} castShadow receiveShadow><meshStandardMaterial color="#b4a9c3" roughness={0.36} metalness={0.32} /></RoundedBox>
    <RoundedBox args={[11.12, 0.27, 4.02]} position={[0, 0.08, -0.015]} radius={0.16} smoothness={5} castShadow receiveShadow><meshStandardMaterial color="#e6dfe9" roughness={0.33} metalness={0.15} /></RoundedBox>
    <RoundedBox args={[10.84, 0.12, 3.67]} position={[0, 0.185, 0]} radius={0.085} smoothness={3} receiveShadow><meshStandardMaterial color="#bcb4c2" roughness={0.5} /></RoundedBox>
    {keyDefinitions.map((key, i) => <Keycap key={i} definition={key} press={press} activeKey={activeKey} reduced={reduced} />)}
    <mesh position={[5.25, 0.226, -1.87]} rotation={[-Math.PI / 2, 0, 0]}><circleGeometry args={[0.033, 12]} /><meshBasicMaterial color="#9fcaa1" /></mesh>
  </group>;
}

const fingerHomes: Record<string, string> = { "Left pinky": "a", "Left ring": "s", "Left middle": "d", "Left index": "f", "Right index": "j", "Right middle": "k", "Right ring": "l", "Right pinky": ";" };
function Finger({ name, x, length, activeKey, press, material, reduced }: { name: string; x: number; length: number; activeKey: string; press: React.RefObject<Press>; material: THREE.MeshPhysicalMaterial; reduced: boolean }) {
  const root = useRef<THREE.Group>(null);
  const joint = useRef<THREE.Group>(null);
  const tip = useRef<THREE.Group>(null);
  const active = fingerMap[activeKey.toLowerCase()] === name;
  const base = positions[fingerHomes[name]];
  const destination = positions[activeKey.toLowerCase()];
  const a = length * 0.44, b = length * 0.32, c = length * 0.24;
  const radius = name.includes("pinky") ? 0.135 : name.includes("ring") ? 0.155 : 0.168;
  useFrame(({ clock }, delta) => {
    if (!root.current || !joint.current || !tip.current) return;
    const pressing = active && performance.now() - press.current.at < 190;
    const flex = active ? (pressing ? 0.21 : reduced ? 0.045 : (Math.sin(clock.elapsedTime * 3.5) + 1) * 0.027) : 0;
    root.current.rotation.x = THREE.MathUtils.damp(root.current.rotation.x, -0.18 - flex, 12, delta);
    joint.current.rotation.x = THREE.MathUtils.damp(joint.current.rotation.x, -0.22 - flex * 0.65, 14, delta);
    tip.current.rotation.x = THREE.MathUtils.damp(tip.current.rotation.x, -0.18 - flex * 0.4, 14, delta);
    root.current.position.x = THREE.MathUtils.damp(root.current.position.x, x + (active && destination && base ? (destination.x - base.x) * 0.55 : 0), 10, delta);
    root.current.position.z = THREE.MathUtils.damp(root.current.position.z, 0.14 + (active && destination && base ? (destination.z - base.z) * 0.65 : 0), 10, delta);
  });
  const segment = (size: number, r: number) => <>
    <mesh material={material} position={[0, 0, -size / 2]} rotation={[Math.PI / 2, 0, 0]} castShadow><capsuleGeometry args={[r, Math.max(0.06, size - r * 2), 8, 16]} /></mesh>
    <mesh material={material} scale={[1.02, 0.88, 1]} castShadow><sphereGeometry args={[r * 1.02, 16, 12]} /></mesh>
  </>;
  return <group ref={root} position={[x, 0.055, 0.14]} rotation={[-0.18, 0, 0]}>
    {segment(a, radius)}
    <group ref={joint} position={[0, 0, -a]} rotation={[-0.22, 0, 0]}>
      {segment(b, radius * 0.91)}
      <group ref={tip} position={[0, 0, -b]} rotation={[-0.18, 0, 0]}>
        {segment(c, radius * 0.79)}
        <RoundedBox args={[radius * 1.22, 0.028, c * 0.61]} radius={0.035} smoothness={3} position={[0, radius * 0.73, -c * 0.54]} rotation={[0.05, 0, 0]}><meshPhysicalMaterial color={active ? "#b294d3" : "#e8c4b2"} roughness={0.29} clearcoat={0.35} /></RoundedBox>
        {active && <mesh position={[0, radius + 0.013, -c * 0.5]} rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[0.23, 0.25, 32]} /><meshBasicMaterial color="#a076ce" transparent opacity={0.6} side={THREE.DoubleSide} /></mesh>}
      </group>
    </group>
  </group>;
}

function AnatomicalHand(props: { side: "left" | "right"; activeKey: string; press: React.RefObject<Press>; reduced: boolean }) {
  return <Suspense fallback={<ProceduralHand {...props} />}><RiggedHand {...props} /></Suspense>;
}

function ProceduralHand({ side, activeKey, press, reduced }: { side: "left" | "right"; activeKey: string; press: React.RefObject<Press>; reduced: boolean }) {
  const isLeft = side === "left";
  const material = useMemo(() => {
    const canvas = document.createElement("canvas"); canvas.width = canvas.height = 128;
    const ctx = canvas.getContext("2d")!; const image = ctx.createImageData(128, 128);
    let seed = 137;
    for (let i = 0; i < image.data.length; i += 4) { seed = (seed * 16807) % 2147483647; const value = 115 + (seed % 36); image.data[i] = image.data[i + 1] = image.data[i + 2] = value; image.data[i + 3] = 255; }
    ctx.putImageData(image, 0, 0); const bump = new THREE.CanvasTexture(canvas); bump.wrapS = bump.wrapT = THREE.RepeatWrapping; bump.repeat.set(5, 5);
    return new THREE.MeshPhysicalMaterial({ color: "#d7ae94", roughness: 0.55, metalness: 0, clearcoat: 0.06, sheen: 0.25, sheenColor: new THREE.Color("#eeb5a4"), bumpMap: bump, bumpScale: 0.014 });
  }, []);
  useEffect(() => () => { material.bumpMap?.dispose(); material.dispose(); }, [material]);
  const names = isLeft ? ["Left pinky", "Left ring", "Left middle", "Left index"] : ["Right index", "Right middle", "Right ring", "Right pinky"];
  const lengths = isLeft ? [1.37, 1.68, 1.81, 1.66] : [1.66, 1.81, 1.68, 1.37];
  const center = isLeft ? -2.664 : 1.656;
  return <group position={[center, 1.12, 1.43]}>
    <mesh material={material} position={[0, -0.035, 0.84]} scale={[1.19, 0.26, 0.92]} castShadow><sphereGeometry args={[1, 40, 32]} /></mesh>
    <mesh material={material} position={[isLeft ? 0.46 : -0.46, -0.08, 1.03]} scale={[0.62, 0.26, 0.73]} castShadow><sphereGeometry args={[1, 28, 20]} /></mesh>
    <mesh material={material} position={[0, -0.065, 1.91]} rotation={[Math.PI / 2, 0, 0]} scale={[0.88, 1, 0.47]} castShadow><capsuleGeometry args={[0.75, 1.2, 10, 24]} /></mesh>
    {names.map((name, i) => <Finger key={name} name={name} x={positions[fingerHomes[name]].x - center} length={lengths[i]} activeKey={activeKey} press={press} material={material} reduced={reduced} />)}
    <group position={[isLeft ? 0.92 : -0.92, -0.03, 0.93]} rotation={[-0.4, isLeft ? -0.72 : 0.72, 0]}>
      <mesh material={material} position={[0, 0, -0.31]} rotation={[Math.PI / 2, 0, 0]} castShadow><capsuleGeometry args={[0.22, 0.38, 10, 20]} /></mesh>
      <group position={[0, 0, -0.63]} rotation={[-0.25, 0, 0]}>
        <mesh material={material} position={[0, 0, -0.23]} rotation={[Math.PI / 2, 0, 0]} castShadow><capsuleGeometry args={[0.175, 0.25, 10, 20]} /></mesh>
        <RoundedBox args={[0.24, 0.035, 0.29]} radius={0.055} position={[0, 0.152, -0.26]}><meshPhysicalMaterial color={activeKey === " " ? "#b294d3" : "#e8c4b2"} roughness={0.3} /></RoundedBox>
      </group>
    </group>
  </group>;
}

function Scene({ variant, activeKey, press, reduced }: { variant: "hero" | "guide"; activeKey: string; press: React.RefObject<Press>; reduced: boolean }) {
  const keyboard = useRef<THREE.Group>(null);
  const { camera, size } = useThree();
  useEffect(() => {
    if (camera instanceof THREE.OrthographicCamera) { camera.zoom = Math.min(size.width / (variant === "guide" ? 12.8 : 13.8), size.height / (variant === "guide" ? 7.8 : 8.5)); camera.updateProjectionMatrix(); }
  }, [camera, size, variant]);
  useFrame(({ clock, pointer }, delta) => {
    if (!keyboard.current || variant === "guide" || reduced) return;
    keyboard.current.rotation.y = THREE.MathUtils.damp(keyboard.current.rotation.y, -0.19 + pointer.x * 0.065, 3, delta);
    keyboard.current.rotation.z = THREE.MathUtils.damp(keyboard.current.rotation.z, -0.08 + pointer.y * 0.025, 3, delta);
    keyboard.current.position.y = Math.sin(clock.elapsedTime * 0.85) * 0.085 + 0.2;
  });
  return <>
    <ambientLight intensity={1.1} />
    <directionalLight position={[-5, 9, 6]} intensity={3.3} castShadow shadow-mapSize={[1024, 1024]} shadow-camera-left={-9} shadow-camera-right={9} shadow-camera-top={8} shadow-camera-bottom={-8} shadow-bias={-0.0005} shadow-normalBias={0.03} />
    <directionalLight position={[6, 5, -5]} intensity={2} color="#ded1fb" />
    <Environment resolution={128} frames={1}>
      <Lightformer form="rect" intensity={2.8} position={[0, 6, 1]} rotation={[-Math.PI / 2, 0, 0]} scale={[10, 10, 1]} />
      <Lightformer form="rect" intensity={1.8} position={[-6, 3, 2]} rotation={[0, Math.PI / 2, 0]} scale={[8, 5, 1]} />
    </Environment>
    <group ref={keyboard} rotation={variant === "hero" ? [0, -0.19, -0.08] : [0, 0, 0]} position={[0, variant === "hero" ? 0.2 : -0.3, 0]}>
      <MechanicalKeyboard press={press} activeKey={activeKey} reduced={reduced} />
      {variant === "guide" && <><AnatomicalHand side="left" activeKey={activeKey} press={press} reduced={reduced} /><AnatomicalHand side="right" activeKey={activeKey} press={press} reduced={reduced} /></>}
    </group>
    <ContactShadows position={[0, -1, 0]} opacity={0.24} scale={20} blur={2.7} far={5} resolution={256} frames={1} color="#5c4577" />
    {variant === "guide" && <OrbitControls enableZoom={false} enablePan={false} minPolarAngle={0.2} maxPolarAngle={1.18} target={[0, 0, 0.55]} enableDamping dampingFactor={0.08} />}
  </>;
}

function KeyboardFallback({ activeKey }: { activeKey: string }) {
  return <div className="keyboard-fallback" aria-hidden="true"><div className="flat-keyboard">{rawRows.map((row, r) => <div className="flat-key-row" key={r}>{row.map(([label, width], i) => <span key={i} className={`${["esc", "enter"].includes(label) ? "accent" : ""} ${(label === activeKey || (label === "space" && activeKey === " ")) ? "lit" : ""}`} style={{ flex: width }}>{label === "space" ? "find your flow" : label}</span>)}</div>)}</div></div>;
}
class SceneBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}

export default function KeyboardScene({ variant = "hero", activeKey = "" }: { variant?: "hero" | "guide"; activeKey?: string }) {
  const container = useRef<HTMLDivElement>(null);
  const press = useRef<Press>({ key: "", at: 0 });
  const [supported, setSupported] = useState<boolean | null>(null);
  const [visible, setVisible] = useState(true);
  const [reduced, setReduced] = useState(false);
  const [current, setCurrent] = useState("");
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    const test = document.createElement("canvas");
    const gl = test.getContext("webgl2");
    setSupported(Boolean(gl));
    gl?.getExtension("WEBGL_lose_context")?.loseContext();
    const media = matchMedia("(prefers-reduced-motion: reduce)"); setReduced(media.matches);
    const change = () => setReduced(media.matches); media.addEventListener("change", change);
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), { rootMargin: "150px" });
    if (container.current) observer.observe(container.current);
    const onKey = (event: KeyboardEvent) => {
      if (variant !== "hero" || event.ctrlKey || event.metaKey || event.altKey || (event.target instanceof HTMLElement && ["INPUT", "TEXTAREA"].includes(event.target.tagName))) return;
      if (event.key.length === 1) { press.current = { key: event.key.toLowerCase(), at: performance.now() }; setCurrent(event.key.toLowerCase()); }
    };
    const onPress = (event: Event) => { const detail = (event as CustomEvent<string>).detail; press.current = { key: detail.toLowerCase(), at: performance.now() }; };
    window.addEventListener("keydown", onKey); window.addEventListener("keysteady:key", onPress);
    return () => { observer.disconnect(); media.removeEventListener("change", change); window.removeEventListener("keydown", onKey); window.removeEventListener("keysteady:key", onPress); };
  }, [variant]);
  const fallback = <KeyboardFallback activeKey={activeKey || current} />;
  return <div ref={container} className={`keyboard-scene keyboard-scene-${variant}`} role="img" aria-label={variant === "hero" ? "Interactive 3D mechanical keyboard. Press a letter to see its key respond." : `Anatomical 3D hand guidance. Next key: ${activeKey === " " ? "space" : activeKey}. Use ${fingerMap[activeKey.toLowerCase()] || "your indicated finger"}.`}>
    {(!loaded || !supported) && fallback}
    {supported && <SceneBoundary fallback={fallback}><div className={`canvas-layer ${loaded ? "is-loaded" : ""}`}><Canvas shadows dpr={[1, 1.6]} orthographic camera={{ position: variant === "hero" ? [3.3, 8, 9.5] : [0, 9.8, 7.3], zoom: 45, near: 0.1, far: 100 }} gl={{ alpha: true, antialias: true, powerPreference: "high-performance" }} frameloop={visible ? "always" : "never"} onCreated={() => setLoaded(true)}>
      <Suspense fallback={null}><Scene variant={variant} activeKey={activeKey || current} press={press} reduced={reduced} /></Suspense>
    </Canvas></div></SceneBoundary>}
    {variant === "hero" && <div className={`keyboard-interaction ${current ? "has-key" : ""}`}><span className="live-dot" />{current ? <><kbd>{current === " " ? "space" : current.toUpperCase()}</kbd><span>{fingerMap[current] || "Nice keystroke"} <span className="interaction-separator">·</span> that’s the one.</span></> : <span>Go on, press a key. <span className="interaction-muted">It’s a little satisfying.</span></span>}</div>}
  </div>;
}
