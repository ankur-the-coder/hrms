"use client";

import { useEffect, useMemo, useRef, type RefObject } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import { clone } from "three/addons/utils/SkeletonUtils.js";
import * as THREE from "three";
import { fingerMap } from "@/lib/catalog";

type HandProps = { side: "left" | "right"; activeKey: string; press: RefObject<{ key: string; at: number }>; reduced: boolean };
const axisX = new THREE.Vector3(1, 0, 0);
const normalization = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().set(0, 0, -1, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1));
const fingerIds = ["index", "middle", "ring", "pinky", "thumb"] as const;
const jointNames = ["metacarpal", "phalanx-proximal", "phalanx-intermediate", "phalanx-distal", "tip"];
const keyRows = ["1234567890-=", "qwertyuiop[]", "asdfghjkl;'", "zxcvbnm,./", " "];
const homeXs: Record<string, number> = { "Left pinky": -3.744, "Left ring": -3.024, "Left middle": -2.304, "Left index": -1.584, "Right index": 0.576, "Right middle": 1.296, "Right ring": 2.016, "Right pinky": 2.736, "Thumb": -0.576 };
function keyTarget(key: string) {
  const k = key.toLowerCase(), row = keyRows.findIndex(keys => keys.includes(k));
  if (!k || row < 0) return { x: 0, z: 0 };
  const offsets = [-4.32, -3.96, -3.744, -3.384, -0.576];
  return { x: offsets[row] + keyRows[row].indexOf(k) * 0.72, z: (row - 2) * 0.72 };
}

// The generic WebXR hand uses 25 independently tracked joints. Reparenting while
// preserving their bind transforms gives us a conventional anatomical FK rig.
export function RiggedHand({ side, activeKey, press, reduced }: HandProps) {
  const source = useGLTF("/models/hand-left.glb");
  const left = side === "left";
  const hand = useRef<THREE.Group>(null);
  const highlight = useRef<THREE.Mesh>(null);
  const activeFinger = fingerMap[activeKey.toLowerCase()];
  const skin = useMemo(() => {
    const canvas = document.createElement("canvas"); canvas.width = canvas.height = 256;
    const ctx = canvas.getContext("2d")!;
    const data = ctx.createImageData(256, 256); let seed = 41;
    for (let i = 0; i < data.data.length; i += 4) { seed = seed * 16807 % 2147483647; const value = 108 + seed % 40; data.data[i] = data.data[i + 1] = data.data[i + 2] = value; data.data[i + 3] = 255; }
    ctx.putImageData(data, 0, 0);
    const pores = new THREE.CanvasTexture(canvas); pores.wrapS = pores.wrapT = THREE.RepeatWrapping; pores.repeat.set(12, 12);
    return new THREE.MeshPhysicalMaterial({ color: "#ae795b", roughness: 0.59, metalness: 0, clearcoat: 0.04, sheen: 0.18, sheenColor: new THREE.Color("#e4a286"), bumpMap: pores, bumpScale: 0.000013 });
  }, []);
  const rig = useMemo(() => {
    const model = clone(source.scene);
    model.updateMatrixWorld(true);
    const wrist = model.getObjectByName("wrist") as THREE.Bone;
    const origin = wrist.position.clone();
    const fingers = fingerIds.map(id => {
      const prefix = id === "thumb" ? "thumb" : `${id}-finger`;
      const chain = jointNames.map(name => model.getObjectByName(`${prefix}-${name}`) as THREE.Bone | undefined).filter((bone): bone is THREE.Bone => Boolean(bone));
      let parent: THREE.Object3D = wrist;
      for (const bone of chain) { parent.attach(bone); parent = bone; }
      const moving = chain.filter(bone => bone.name.includes("phalanx")).map((bone, index) => ({ bone, base: bone.quaternion.clone(), target: new THREE.Quaternion(), bend: new THREE.Quaternion(), angle: 0, rest: id === "thumb" ? [-0.08, -0.11][index] || -0.1 : [-0.25, -0.34, -0.16][index] }));
      const name = id === "thumb" ? "Thumb" : `${left ? "Left" : "Right"} ${id}`;
      return { id, name, moving, tip: chain.at(-1)!, distal: chain.at(-2)! };
    });
    model.traverse(object => {
      const mesh = object as THREE.SkinnedMesh;
      if (mesh.isSkinnedMesh) { mesh.material = skin; mesh.castShadow = true; mesh.receiveShadow = true; mesh.frustumCulled = false; }
    });
    model.position.copy(origin).multiplyScalar(-1);
    return { model, fingers, point: new THREE.Vector3(), otherPoint: new THREE.Vector3() };
  }, [source.scene, skin, left]);
  useEffect(() => () => { skin.bumpMap?.dispose(); skin.dispose(); }, [skin]);
  useFrame(({ clock }, delta) => {
    if (!hand.current) return;
    const owns = Boolean(activeFinger && (activeFinger.startsWith(left ? "Left" : "Right") || activeFinger === "Thumb"));
    const target = keyTarget(activeKey);
    const offsetX = owns && activeFinger !== "Thumb" ? target.x - (homeXs[activeFinger] ?? target.x) : 0;
    const offsetZ = owns && activeFinger !== "Thumb" ? target.z : 0;
    hand.current.position.x = THREE.MathUtils.damp(hand.current.position.x, (left ? -2.2 : 1.2) + offsetX * 0.68, 9, delta);
    hand.current.position.z = THREE.MathUtils.damp(hand.current.position.z, 3.9 + offsetZ * 0.53, 9, delta);
    hand.current.position.y = THREE.MathUtils.damp(hand.current.position.y, 1.62 + offsetZ * 0.15, 9, delta);
    for (const finger of rig.fingers) {
      const indicated = finger.name === activeFinger;
      const pressing = fingerMap[press.current.key] === finger.name && performance.now() - press.current.at < 180;
      const breathe = indicated && !reduced ? (Math.sin(clock.elapsedTime * 3) + 1) * 0.008 : 0;
      finger.moving.forEach((joint, index) => {
        const reach = indicated && finger.id !== "thumb" ? -offsetZ * 0.12 : 0;
        const bend = joint.rest + reach - (pressing ? 0.115 : breathe) * (index === 0 ? 1 : 0.65);
        joint.angle = THREE.MathUtils.damp(joint.angle, bend, 15, delta);
        joint.bend.setFromAxisAngle(axisX, joint.angle);
        joint.target.copy(joint.base).multiply(joint.bend);
        joint.bone.quaternion.copy(joint.target);
      });
    }
    if (highlight.current) {
      const finger = rig.fingers.find(finger => finger.name === activeFinger);
      highlight.current.visible = Boolean(finger && owns);
      if (finger && owns) {
        finger.tip.getWorldPosition(rig.point);
        finger.distal.getWorldPosition(rig.otherPoint);
        rig.point.lerp(rig.otherPoint, 0.42);
        highlight.current.parent?.worldToLocal(rig.point);
        rig.point.y += 0.125;
        highlight.current.position.copy(rig.point);
      }
    }
  });
  return <>
    <group ref={hand} position={[left ? -2.2 : 1.2, 1.62, 3.9]} scale={[left ? 31 : -31, 25, 23]}>
      <group quaternion={normalization}><primitive object={rig.model} dispose={null} /></group>
    </group>
    <mesh ref={highlight} rotation={[-Math.PI / 2, 0, 0]} visible={false} renderOrder={100}><ringGeometry args={[0.16, 0.205, 40]} /><meshBasicMaterial color="#9364bd" transparent opacity={0.95} depthWrite={false} depthTest={false} side={THREE.DoubleSide} /></mesh>
  </>;
}
