"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { AlignLeft, ArrowUpRight, Brain, Clock3, Hand, Hash, Keyboard, Loader2, Quote, Settings2, Sparkles, Volume2, WandSparkles, WholeWord } from "lucide-react";
import { Shell } from "./shell";
import { useApp } from "./app-provider";
import { useCatalog } from "@/lib/use-catalog";
import { buildPassage } from "@/lib/typing-utils";
import { TypingEngine } from "./typing-engine";
import { Modal, Toggle } from "./ui";
import type { WordMetric } from "@/lib/types";

type PracticeMode = "time" | "words" | "quote" | "custom" | "adaptive";
export default function PracticeView({ initialMode, initialTestId }: { initialMode?: string; initialTestId?: number }) {
  const { settings, updateSettings, ready, profile, notify } = useApp();
  const { tests } = useCatalog();
  const [mode, setMode] = useState<PracticeMode>(initialMode === "adaptive" ? "adaptive" : initialMode === "quote" ? "quote" : initialMode === "words" ? "words" : "time");
  const [duration, setDuration] = useState(30);
  const [wordCount, setWordCount] = useState(25);
  const [seed, setSeed] = useState(1);
  const [punctuation, setPunctuation] = useState(false);
  const [numbers, setNumbers] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [customOpen, setCustomOpen] = useState(false);
  const [customText, setCustomText] = useState("");
  const [customDraft, setCustomDraft] = useState("");
  const [metrics, setMetrics] = useState<WordMetric[]>([]);
  const [wordsLoading, setWordsLoading] = useState(initialMode === "adaptive");
  const initialized = useRef(false);
  useEffect(() => { if (ready && !initialized.current) { setDuration(settings.duration); initialized.current = true; } }, [ready, settings.duration]);
  useEffect(() => {
    if (mode !== "adaptive") return;
    if (!ready) { setWordsLoading(true); return; }
    let active = true; setWordsLoading(true);
    fetch("/api/words").then(async r => { if (!r.ok) throw new Error(); return r.json(); }).then(data => { if (active) setMetrics(data.words); }).catch(() => { if (active) notify("Your coach is reconnecting. Enjoy a common-words warm-up for now.", true); }).finally(() => { if (active) setWordsLoading(false); });
    return () => { active = false; };
  }, [mode, ready, profile?.id, notify]);
  useEffect(() => { if (!settingsOpen) return; const listener = (event: globalThis.KeyboardEvent) => { if (event.key === "Escape") setSettingsOpen(false); }; document.addEventListener("keydown", listener); return () => document.removeEventListener("keydown", listener); }, [settingsOpen]);
  const activeWords = useMemo(() => metrics.filter(word => word.status === "active"), [metrics]);
  const quotes = tests.filter(test => test.category === "quote");
  const quote = (initialTestId ? tests.find(test => test.id === initialTestId) : undefined) || quotes[(seed - 1) % Math.max(1, quotes.length)] || tests[0];
  const source = tests.find(test => test.category === "words")?.content || "practice makes progress one word at a time";
  const text = useMemo(() => {
    if (mode === "custom") return customText.replace(/\s+/g, " ").trim();
    if (mode === "quote") return quote?.content || source;
    const pool = mode === "adaptive" && activeWords.length ? activeWords.flatMap(word => Array.from({ length: Math.min(4, word.mistakeCount + word.slowCount + 1) }, () => word.word)) : source.split(" ");
    return buildPassage(pool, mode === "words" ? wordCount : duration * 6 + 20, seed, punctuation, numbers);
  }, [mode, customText, quote?.content, source, activeWords, wordCount, duration, seed, punctuation, numbers]);
  const modeItems = [{ id: "time", label: "time", icon: Clock3 }, { id: "words", label: "words", icon: WholeWord }, { id: "quote", label: "quote", icon: Quote }, { id: "custom", label: "custom", icon: AlignLeft }, { id: "adaptive", label: "adaptive", icon: Sparkles }] as const;
  const changeMode = (next: PracticeMode) => { if (next === "custom") { setCustomDraft(customText); setCustomOpen(true); return; } setMode(next); setSeed(n => n + 1); };
  const title = mode === "quote" ? quote.title : mode === "custom" ? "Your own words" : mode === "adaptive" ? "Your personal word practice" : mode === "words" ? `${wordCount}-word flow` : `${duration}-second flow`;
  return <Shell compact><div className="page-container practice-page"><div className="page-heading"><div><span className="eyebrow">YOUR PERSONAL TYPING STUDIO</span><h1>{mode === "adaptive" ? <>A little more <em>you.</em></> : <>Less noise. More <em>flow.</em></>}</h1><p>{mode === "adaptive" ? "The words that trip you up today will feel effortless tomorrow." : "Settle in. Relax your shoulders. The rest is just one word at a time."}</p></div><div className="practice-settings-wrap"><button className="icon-button" onClick={() => setSettingsOpen(v => !v)} aria-label="Typing preferences" aria-expanded={settingsOpen}><Settings2 size={20} /></button>{settingsOpen && <><button className="popover-scrim" onClick={() => setSettingsOpen(false)} aria-label="Close preferences" /><div className="practice-settings-panel"><h3>Make it feel like you.</h3><div className="preference-mini"><span><Volume2 size={14} /> Gentle key sounds</span><Toggle label="Gentle key sounds" checked={settings.sound} onChange={value => updateSettings({ sound: value })} /></div><div className="preference-mini"><span><WandSparkles size={14} /> Smooth caret</span><Toggle label="Smooth caret" checked={settings.smoothCaret} onChange={value => updateSettings({ smoothCaret: value })} /></div><div className="preference-mini"><span><Hash size={14} /> Live statistics</span><Toggle label="Live statistics" checked={settings.showLiveStats} onChange={value => updateSettings({ showLiveStats: value })} /></div><Link href="/settings" className="text-link" onClick={() => setSettingsOpen(false)}>All preferences <ArrowUpRight size={13} /></Link></div></>}</div></div>
    {mode === "adaptive" && <div className="adaptive-notice"><Brain size={23} /><p>{activeWords.length ? <><strong>{activeWords.length} words, a little extra attention.</strong><br />Your coach brings back missed and hesitant words. Four clean runs help them graduate.</> : <><strong>Your word coach is getting to know you.</strong><br />Start with a warm-up. Missed or hesitant words will automatically shape your next practice.</>}</p><Link className="text-link" href="/progress">Meet your word collection <ArrowUpRight size={13} /></Link></div>}
    <div className="practice-toolbar" aria-label="Test configuration"><div className="test-modes">{modeItems.map(({ id, label, icon: Icon }) => <button key={id} className={mode === id ? "active" : ""} onClick={() => changeMode(id)} aria-pressed={mode === id}><Icon size={13} />{label}</button>)}</div><div className="test-options">{(mode === "time" || mode === "words" || mode === "adaptive") && <><button className={`toggle-option ${punctuation ? "active" : ""}`} onClick={() => setPunctuation(v => !v)} aria-pressed={punctuation} title="Include punctuation">@<span>punctuation</span></button><button className={`toggle-option ${numbers ? "active" : ""}`} onClick={() => setNumbers(v => !v)} aria-pressed={numbers} title="Include numbers">#<span>numbers</span></button><span className="toolbar-divider" /></>}{mode === "time" || mode === "adaptive" ? <div className="duration-group">{[15, 30, 60, 120].map(seconds => <button key={seconds} className={duration === seconds ? "active" : ""} aria-pressed={duration === seconds} onClick={() => { setDuration(seconds); updateSettings({ duration: seconds }); }}>{seconds}</button>)}</div> : mode === "words" ? <div className="duration-group">{[25, 50, 100].map(count => <button key={count} aria-pressed={wordCount === count} className={wordCount === count ? "active" : ""} onClick={() => setWordCount(count)}>{count}</button>)}</div> : <span className="session-configuration"><Keyboard size={12} />{mode === "quote" ? "a little inspiration" : `${text.split(" ").length} of your own words`}</span>}</div></div>
    {mode === "adaptive" && wordsLoading ? <div className="typing-engine"><div className="empty-state"><Loader2 size={24} className="animate-spin" /><p>Getting your words together…</p></div></div> : <TypingEngine key={`${mode}-${seed}-${duration}-${wordCount}-${punctuation}-${numbers}-${text.slice(0, 90)}`} text={text} duration={mode === "time" || mode === "adaptive" ? duration : null} module={mode === "adaptive" ? "adaptive" : "practice"} title={title} onRestart={() => setSeed(n => n + 1)} />}
    {mode === "quote" && <p className="quote-attribution">A little inspiration from {quote.source}.</p>}
    <div className="practice-bottom"><Hand size={17} /><span>Not sure where your fingers belong?</span><Link href="/learn/1">Meet your 3D guide <ArrowUpRight size={12} style={{ display: "inline", verticalAlign: "middle" }} /></Link></div>
  </div>{customOpen && <Modal title="Your words. Your flow." onClose={() => setCustomOpen(false)}><p>A favorite passage, a speech, a bit of code. Make your practice personal.</p><textarea aria-label="Custom practice text" value={customDraft} onChange={event => setCustomDraft(event.target.value.slice(0, 10000))} placeholder="Drop a little inspiration here…" maxLength={10000} /><div className="dialog-bottom"><span>{customDraft.trim().length} / 10,000 characters · minimum 20</span><button className="button button-dark" disabled={customDraft.trim().length < 20} onClick={() => { setCustomText(customDraft); setMode("custom"); setSeed(n => n + 1); setCustomOpen(false); }}>Make it my practice <ArrowUpRight size={15} /></button></div></Modal>}</Shell>;
}
