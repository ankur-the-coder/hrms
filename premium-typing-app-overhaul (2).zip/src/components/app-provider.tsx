"use client";

import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { Check, X, AlertCircle } from "lucide-react";
import { defaultSettings, type Profile, type Settings } from "@/lib/types";

type AppContextValue = { profile: Profile | null; ready: boolean; settings: Settings; updateSettings: (patch: Partial<Settings>) => void; login: (id: string) => Promise<void>; logout: () => Promise<void>; refreshKey: number; refresh: () => void; notify: (message: string, error?: boolean) => void };
const AppContext = createContext<AppContextValue | null>(null);
export function AppProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [ready, setReady] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [toast, setToast] = useState<{ message: string; error: boolean } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const notify = useCallback((message: string, error = false) => {
    if (timer.current) clearTimeout(timer.current);
    setToast({ message, error });
    timer.current = setTimeout(() => setToast(null), 4500);
  }, []);
  const apply = useCallback((next: Settings) => {
    setSettings(next);
    document.documentElement.dataset.theme = next.theme;
    try { localStorage.setItem("keysteady-settings", JSON.stringify(next)); } catch { /* private browsing */ }
  }, []);
  useEffect(() => {
    let active = true;
    try { const stored = localStorage.getItem("keysteady-settings"); if (stored) apply({ ...defaultSettings, ...JSON.parse(stored) }); } catch { /* default preferences */ }
    fetch("/api/session").then(async r => { if (!r.ok) throw new Error("Progress storage is reconnecting. You can still practice."); return r.json(); }).then(data => {
      if (!active) return;
      setProfile(data.profile);
      let local: Partial<Settings> = {};
      try { local = JSON.parse(localStorage.getItem("keysteady-settings") || "{}"); } catch { /* defaults */ }
      apply({ ...defaultSettings, ...data.settings, ...local });
    }).catch(error => { if (active) notify(error.message, true); }).finally(() => { if (active) setReady(true); });
    return () => { active = false; if (timer.current) clearTimeout(timer.current); };
  }, [apply, notify]);
  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings(previous => {
      const next = { ...previous, ...patch };
      document.documentElement.dataset.theme = next.theme;
      try { localStorage.setItem("keysteady-settings", JSON.stringify(next)); } catch { /* private browsing */ }
      return next;
    });
    fetch("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) }).then(r => { if (!r.ok) throw new Error(); }).catch(() => notify("Saved on this device. Cloud preferences will retry next time.", true));
  }, [notify]);
  const login = async (id: string) => {
    const response = await fetch("/api/session", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Please try again.");
    setProfile(data.profile); apply({ ...defaultSettings, ...data.settings }); setRefreshKey(n => n + 1);
    notify(`Welcome to your flow, ${data.profile.displayName}.`);
  };
  const logout = async () => {
    const response = await fetch("/api/session", { method: "DELETE" });
    if (!response.ok) { notify("Could not sign out. Please retry.", true); return; }
    const next = await fetch("/api/session");
    if (next.ok) { const data = await next.json(); setProfile(data.profile); setRefreshKey(n => n + 1); notify("You're now practicing as a guest."); }
  };
  return <AppContext.Provider value={{ profile, ready, settings, updateSettings, login, logout, refreshKey, refresh: () => setRefreshKey(n => n + 1), notify }}>
    {children}
    {toast && <div className={`toast ${toast.error ? "toast-error" : ""}`} role="status">{toast.error ? <AlertCircle size={18} /> : <Check size={18} />}<span>{toast.message}</span><button onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={16} /></button></div>}
  </AppContext.Provider>;
}
export function useApp() { const context = useContext(AppContext); if (!context) throw new Error("useApp must be used in AppProvider"); return context; }
