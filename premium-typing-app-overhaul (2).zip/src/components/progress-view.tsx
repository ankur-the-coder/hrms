"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type CSSProperties } from "react";
import { ArrowUpRight, ChartNoAxesCombined, Check, CircleAlert, Download, Flame, Flower2, Gauge, Keyboard, Loader2, Sparkles, Target, Trophy } from "lucide-react";
import { Shell } from "./shell";
import { useApp } from "./app-provider";
import { SpeedChart } from "./speed-chart";
import type { Attempt, WordMetric } from "@/lib/types";

function practiceStreak(attempts: Attempt[]) {
  const days = [...new Set(attempts.map(attempt => Math.floor(new Date(attempt.createdAt).getTime() / 86400000)))].sort((a, b) => b - a);
  if (!days.length || Math.floor(Date.now() / 86400000) - days[0] > 1) return 0;
  let streak = 1; for (let i = 1; i < days.length && days[i - 1] - days[i] === 1; i++) streak++;
  return streak;
}
const moduleNames: Record<string, string> = { practice: "Practice", learn: "Guided", velocity: "Velocity", adaptive: "Adaptive" };
export default function ProgressView() {
  const { ready, profile, refreshKey, notify } = useApp();
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [words, setWords] = useState<WordMetric[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [period, setPeriod] = useState(7);
  const [filter, setFilter] = useState("all");
  const [limit, setLimit] = useState(20);
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    if (!ready) return;
    let active = true; setLoading(true); setError("");
    Promise.all([fetch("/api/attempts"), fetch("/api/words")]).then(async responses => {
      if (responses.some(response => !response.ok)) throw new Error("We couldn’t load your progress just now. Your saved sessions are still safe.");
      const [a, w] = await Promise.all(responses.map(response => response.json()));
      if (active) { setAttempts(a.attempts); setWords(w.words); }
    }).catch(reason => { if (active) setError(reason.message); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [ready, profile?.id, refreshKey, retry]);
  const best = Math.max(0, ...attempts.map(attempt => attempt.wpm));
  const totalStrokes = attempts.reduce((sum, attempt) => sum + attempt.totalChars, 0);
  const accuracy = totalStrokes ? attempts.reduce((sum, attempt) => sum + attempt.accuracy * attempt.totalChars, 0) / totalStrokes : 0;
  const minutes = Math.round(attempts.reduce((sum, attempt) => sum + attempt.durationSeconds, 0) / 60);
  const mastered = words.filter(word => word.status === "mastered");
  const activeWords = words.filter(word => word.status !== "mastered");
  const mastery = words.length ? Math.round(mastered.length / words.length * 100) : 0;
  const streak = practiceStreak(attempts);
  const filtered = useMemo(() => attempts.filter(attempt => filter === "all" || attempt.module === filter), [attempts, filter]);
  const chartAttempts = useMemo(() => attempts.filter(attempt => period === 0 || Date.now() - new Date(attempt.createdAt).getTime() < period * 86400000).slice(0, 30).reverse(), [attempts, period]);
  const exportHistory = useCallback(() => {
    if (!filtered.length) { notify("Your first session is the start of your story. Let’s make one."); return; }
    const rows = [["Date", "Practice", "Mode", "WPM", "Raw WPM", "Accuracy (%)", "Duration (seconds)", "Corrections"], ...filtered.map(attempt => [new Date(attempt.createdAt).toISOString(), attempt.title, attempt.module, attempt.wpm, attempt.rawWpm, attempt.accuracy, Math.round(attempt.durationSeconds), attempt.corrections])];
    const csv = rows.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(",")).join("\r\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href = url; a.download = `keysteady-progress-${new Date().toISOString().slice(0, 10)}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    notify("A little record of how far you’ve come. Export ready.");
  }, [filtered, notify]);
  return <Shell><div className="page-container"><div className="page-heading"><div><span className="eyebrow">YOUR LITTLE WINS, ALL TOGETHER</span><h1>Look how far <em>you’ve come.</em></h1><p>Progress isn’t always a straight line. Every session is a little more confidence in your hands.</p></div><button className="button button-outline export-button" onClick={exportHistory} disabled={!attempts.length}><Download size={14} />Export progress</button></div>
    {error && <div className="error-message" role="alert"><CircleAlert size={15} /><span>{error}</span><button onClick={() => setRetry(n => n + 1)}>Try again</button></div>}
    {loading ? <div className="progress-loading"><Loader2 className="animate-spin" size={23} style={{ margin: "0 auto 12px" }} />Gathering your little wins…</div> : <><div className="stats-grid"><div className="stat-card"><div className="stat-card-top"><span>Personal best</span><Trophy size={17} /></div><strong>{best || "—"}<small> wpm</small></strong><p>{best ? "A little proof of what you can do." : "Your next chapter starts at one word."}</p></div><div className="stat-card"><div className="stat-card-top"><span>Average accuracy</span><Target size={17} /></div><strong>{attempts.length ? accuracy.toFixed(1) : "—"}<small>%</small></strong><p>Precision is a lovely place to start.</p></div><div className="stat-card"><div className="stat-card-top"><span>Practice sessions</span><Keyboard size={17} /></div><strong>{attempts.length}</strong><p>{minutes} minute{minutes === 1 ? "" : "s"} spent finding your flow.</p></div><div className="stat-card"><div className="stat-card-top"><span>Current streak</span><Flame size={17} /></div><strong>{streak}<small> day{streak === 1 ? "" : "s"}</small></strong><p>{streak ? "Look at you, showing up for yourself." : "Today is a good day to begin."}</p></div></div>
      <div className="progress-layout"><section className="panel"><div className="panel-heading"><h2>Your rhythm over time</h2><div className="segmented-control" aria-label="Chart time range">{[{ value: 7, label: "7 days" }, { value: 30, label: "30 days" }, { value: 0, label: "All time" }].map(item => <button key={item.value} onClick={() => setPeriod(item.value)} className={period === item.value ? "active" : ""} aria-pressed={period === item.value}>{item.label}</button>)}</div></div>{chartAttempts.length ? <><div className="chart-legend"><span><i /> Words per minute</span><span>Last {chartAttempts.length} session{chartAttempts.length === 1 ? "" : "s"}</span></div><SpeedChart sessionAxis points={chartAttempts.map((attempt, index) => ({ second: index + 1, wpm: attempt.wpm }))} /></> : <div className="chart-empty"><ChartNoAxesCombined size={28} strokeWidth={1.3} /><span>{attempts.length ? "A quiet stretch. Ready for a fresh start?" : "Your rhythm is waiting to be discovered."}</span><p>Finish a session and watch your own story take shape, one little win at a time.</p><Link className="text-link" href="/practice">Find your first flow <ArrowUpRight size={13} /></Link></div>}</section>
      <section className="panel mastery-panel"><div className="panel-heading"><h2>Your word collection</h2><Flower2 size={18} color="var(--violet)" /></div><div className="mastery-overview"><div className="mastery-ring" style={{ "--progress": mastery } as CSSProperties}><strong>{mastery}<small>%</small></strong></div><div className="mastery-details"><strong>{mastered.length} word{mastered.length === 1 ? "" : "s"} made easy.</strong><br />{activeWords.length ? `${activeWords.length} more finding their rhythm.` : "Your future easy words live here."}<br /><span>Four clean runs. A new little win.</span></div></div><div className="word-collection">{words.slice(0, 7).map(word => <span className={`word-chip ${word.status === "mastered" ? "mastered" : ""}`} title={`${word.masteryScore}% mastery · ${word.cleanStreak}/4 clean runs`} key={word.id}>{word.word}{word.status === "mastered" && <Check size={10} style={{ marginLeft: 4 }} />}</span>)}</div><Link className="button button-outline" href="/practice?mode=adaptive">A little love for tricky words <ArrowUpRight size={13} /></Link></section></div>
      <section className="panel table-panel"><div className="panel-heading"><h2>Your practice journal <span className="history-count">{filtered.length}</span></h2><div className="history-filter"><label htmlFor="journal-filter" className="sr-only">Filter practice journal</label><select id="journal-filter" value={filter} onChange={event => { setFilter(event.target.value); setLimit(20); }}><option value="all">Every kind of flow</option><option value="practice">Typing practice</option><option value="learn">Guided learning</option><option value="velocity">Velocity drills</option><option value="adaptive">Adaptive practice</option></select></div></div>{filtered.length ? <><div className="table-scroll"><table><thead><tr><th>Practice</th><th>Mode</th><th>Speed</th><th>Accuracy</th><th>Time</th><th>When</th></tr></thead><tbody>{filtered.slice(0, limit).map(attempt => <tr key={attempt.id}><td><strong>{attempt.title}</strong></td><td><span className="mode-tag">{moduleNames[attempt.module] || attempt.module}</span></td><td className="numeric">{attempt.wpm} wpm</td><td>{attempt.accuracy}%</td><td className="time-cell">{Math.round(attempt.durationSeconds)}s</td><td className="time-cell">{new Date(attempt.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })} · {new Date(attempt.createdAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}</td></tr>)}</tbody></table></div>{filtered.length > limit && <div style={{ textAlign: "center", padding: 18 }}><button className="text-link" onClick={() => setLimit(n => n + 20)}>A few more little wins <ArrowUpRight size={13} /></button></div>}</> : <div className="empty-state"><BookIcon /><h3>{attempts.length ? "A fresh page in this chapter." : "Every story starts somewhere."}</h3><p>{attempts.length ? "No sessions in this mode yet. A different kind of practice might be just the thing." : "Your first session will be right here. No perfect scores needed — just a little curiosity."}</p><Link className="button button-dark button-small" href={filter === "learn" ? "/learn" : filter === "velocity" ? "/velocity" : filter === "adaptive" ? "/practice?mode=adaptive" : "/practice"}>Let’s make a little progress <ArrowUpRight size={14} /></Link></div>}</section>
    </>}
  </div></Shell>;
}
function BookIcon() { return <Sparkles size={28} strokeWidth={1.2} />; }
