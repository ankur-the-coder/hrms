"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { ArrowUpRight, ArrowRight, BookOpen, ChartNoAxesCombined, ChevronDown, Gauge, Heart, Keyboard, LayoutGrid, LogOut, Menu, Moon, Settings2, Sun, UserRound, X } from "lucide-react";
import { useApp } from "./app-provider";

export function Brand({ small = false }: { small?: boolean }) {
  return <Link href="/" className={`brand ${small ? "brand-small" : ""}`} aria-label="Keysteady home"><span className="brand-mark"><i /><i /><i /><i /></span><span>keysteady<span className="brand-period">.</span></span></Link>;
}
const nav = [ { href: "/", label: "Overview", icon: LayoutGrid }, { href: "/learn", label: "Learn", icon: BookOpen }, { href: "/practice", label: "Practice", icon: Keyboard }, { href: "/velocity", label: "Velocity", icon: Gauge }, { href: "/progress", label: "Progress", icon: ChartNoAxesCombined } ];
export function Shell({ children, compact = false }: { children: ReactNode; compact?: boolean }) {
  const pathname = usePathname();
  const { settings, updateSettings, profile, logout } = useApp();
  const [mobile, setMobile] = useState(false);
  const [profileMenu, setProfileMenu] = useState(false);
  const active = (href: string) => href === "/" ? pathname === "/" : pathname.startsWith(href);
  return <div className={`site-shell ${compact ? "shell-compact" : ""}`}>
    <a className="skip-link" href="#main-content">Skip to content</a>
    <header className="site-header"><div className="header-inner">
      <Brand />
      <nav className="desktop-nav" aria-label="Main navigation">{nav.map(({ href, label, icon: Icon }) => <Link href={href} key={href} className={active(href) ? "active" : ""} aria-current={active(href) ? "page" : undefined}><Icon size={15} strokeWidth={1.7} /><span>{label}</span></Link>)}</nav>
      <div className="header-actions"><button className="icon-button theme-button" onClick={() => updateSettings({ theme: settings.theme === "light" ? "dark" : "light" })} aria-label={`Switch to ${settings.theme === "light" ? "dark" : "light"} mode`} title="Change the atmosphere">{settings.theme === "light" ? <Sun size={19} /> : <Moon size={19} />}</button><span className="header-divider" />
        {profile?.loginId ? <div className="profile-wrap"><button className="profile-trigger" onClick={() => setProfileMenu(v => !v)} aria-expanded={profileMenu}><span className="avatar">{profile.displayName.slice(0, 1).toUpperCase()}</span><span className="profile-name">{profile.displayName}</span><ChevronDown size={13} /></button>{profileMenu && <><button className="popover-scrim" aria-label="Close profile menu" onClick={() => setProfileMenu(false)} /><div className="profile-menu"><span className="eyebrow">YOUR DEMO PROFILE</span><strong>{profile.displayName}</strong><Link href="/settings" onClick={() => setProfileMenu(false)}><Settings2 size={16} /> Preferences</Link><button onClick={async () => { await logout(); setProfileMenu(false); }}><LogOut size={16} /> Switch to guest</button></div></>}</div> : <Link className="sign-in-button" href="/login">Sign in <ArrowUpRight size={16} /></Link>}
        <button className="icon-button mobile-menu-toggle" aria-label={mobile ? "Close menu" : "Open menu"} aria-expanded={mobile} onClick={() => setMobile(v => !v)}>{mobile ? <X size={21} /> : <Menu size={21} />}</button>
      </div>
    </div>{mobile && <nav className="mobile-nav" aria-label="Mobile navigation">{nav.map(({ href, label, icon: Icon }) => <Link onClick={() => setMobile(false)} key={href} href={href} className={active(href) ? "active" : ""}><Icon size={17} />{label}<ArrowRight size={15} /></Link>)}<Link href="/settings" onClick={() => setMobile(false)}><Settings2 size={17} />Preferences<ArrowRight size={15} /></Link></nav>}</header>
    <main id="main-content">{children}</main>
    <footer className="site-footer"><div className="footer-inner"><div><Brand small /><span className="footer-tagline">A little practice. A little more you.</span></div><span className="footer-made">Made for the love of the flow <Heart size={12} /></span><div className="footer-links"><Link href="/settings">Preferences</Link><Link href="/login"><UserRound size={13} /> Open demo</Link><span>© {new Date().getFullYear()} Keysteady</span></div></div></footer>
  </div>;
}
