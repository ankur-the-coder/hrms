"use client";

import Link from "next/link";
import dynamic from "next/dynamic";
import { useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowRight, ArrowUpRight, AudioLines, BookOpen, Check, ChevronRight, CircleCheck, Clock3, Flower2, Hand, Keyboard, Leaf, MousePointer2, MoveUpRight, Sparkles, TrendingUp, Zap } from "lucide-react";
import { Shell } from "./shell";

const KeyboardScene = dynamic(() => import("./keyboard-scene"), { ssr: false, loading: () => <div className="scene-loading"><span /><span /><span /></div> });
const modes = [
  { title: "Find your foundation", description: "Good habits start here. Give every finger a place to call home.", meta: "12 guided lessons", href: "/learn", color: "lilac", type: "foundation", tag: "THE PERFECT START", icon: BookOpen },
  { title: "Just you. Just type.", description: "Clear your mind and let the words flow. Your pace, your space.", meta: "Time, words & quotes", href: "/practice", color: "peach", type: "practice", tag: "FIND YOUR FOCUS", icon: Clock3 },
  { title: "Pick up the pace", description: "A little challenge goes a long way. Meet your next personal best.", meta: "3 speed-building drills", href: "/velocity", color: "blue", type: "velocity", tag: "A LITTLE ADRENALINE", icon: Zap },
  { title: "Make it personal", description: "Practice that learns with you. Turn your tricky words into easy ones.", meta: "Your adaptive word coach", href: "/practice?mode=adaptive", color: "sage", type: "adaptive", tag: "BUILT AROUND YOU", icon: Sparkles },
];

function ModeIllustration({ type }: { type: string }) {
  if (type === "foundation") return <div className="mode-illustration foundation-illustration"><span>f<i /></span><span>j<i /></span><div className="small-sparkle">✧</div></div>;
  if (type === "practice") return <div className="mode-illustration practice-illustration"><span>Aa</span><i /><span className="type-dots">···</span></div>;
  if (type === "velocity") return <div className="mode-illustration velocity-illustration"><span /><span /><span /><Zap size={37} strokeWidth={1.4} /></div>;
  return <div className="mode-illustration adaptive-illustration"><Flower2 size={58} strokeWidth={1.1} /><span>✧</span></div>;
}

export default function Landing() {
  const guideRef = useRef<HTMLDivElement>(null);
  const [showGuide, setShowGuide] = useState(false);
  useEffect(() => { const observer = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) { setShowGuide(true); observer.disconnect(); } }, { rootMargin: "100px" }); if (guideRef.current) observer.observe(guideRef.current); return () => observer.disconnect(); }, []);
  return <Shell><div className="landing-container">
    <section className="hero" aria-labelledby="hero-heading">
      <div className="hero-copy"><div className="hero-eyebrow"><span className="eyebrow-flower"><Sparkles size={13} /></span> A LITTLE PRACTICE. A WHOLE NEW PACE.</div>
        <h1 id="hero-heading">Find your flow.<br /><em>Own every key.</em></h1>
        <p className="hero-description">Your thoughts move fast. Let your fingers keep up.<br className="desktop-break" /> A feel-good space to build speed, find your rhythm,<br className="desktop-break" /> and make every keystroke a little more you.</p>
        <div className="hero-buttons"><Link href="/practice" className="button button-dark">Let’s get typing <ArrowUpRight size={19} /></Link><Link href="/learn/1" className="button button-outline"><Hand size={17} strokeWidth={1.7} /> Meet your fingers</Link></div>
        <div className="hero-reassurance"><CircleCheck size={14} /><span>No sign-up. No pressure. Just progress.</span></div>
      </div>
      <div className="hero-art"><div className="hero-halo" /><div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" /><span className="art-sparkle sparkle-one">✦</span><span className="art-sparkle sparkle-two">✧</span><span className="art-dot dot-one" /><span className="art-dot dot-two" />
        <div className="flow-badge"><span className="flow-badge-icon"><AudioLines size={15} /></span> less rush, more rhythm.</div>
        <div className="zone-badge"><span /> in the zone.</div>
        <div className="floating-key key-f">f<span>feel</span></div><div className="floating-key key-j">j<span>the flow</span></div>
        <KeyboardScene />
        <div className="hero-art-caption"><MousePointer2 size={12} /> A LITTLE INTERACTIVE, A LOT SATISFYING.</div>
      </div>
    </section>
    <section className="benefit-strip" aria-label="Made for a better practice"><span className="benefit-intro">Less like a test.<br /><strong>More like your thing.</strong></span><div><Leaf size={22} strokeWidth={1.35} /><span>A calmer kind of focus</span></div><div><Hand size={22} strokeWidth={1.35} /><span>Muscle memory, made natural</span></div><div><TrendingUp size={22} strokeWidth={1.35} /><span>Small steps. Real progress.</span></div></section>
    <section className="modes-section" id="find-your-practice" aria-labelledby="modes-heading"><div className="section-heading"><div><span className="eyebrow">YOUR SPACE TO GET BETTER</span><h2 id="modes-heading">A practice for every pace<span className="heading-dot">.</span></h2><p>First keystrokes or new personal bests. There’s a place for you here.</p></div><Link href="/learn" className="text-link">Find your starting point <ArrowRight size={17} /></Link></div>
      <div className="mode-grid">{modes.map(mode => <Link href={mode.href} className={`mode-card mode-${mode.color}`} key={mode.type}><div className="mode-card-top"><ModeIllustration type={mode.type} /><span className="mode-card-arrow"><ArrowUpRight size={18} strokeWidth={1.5} /></span></div><span className="mode-eyebrow">{mode.tag}</span><h3>{mode.title}</h3><p>{mode.description}</p><div className="mode-card-meta"><mode.icon size={13} strokeWidth={1.7} />{mode.meta}<ChevronRight size={13} /></div></Link>)}</div>
    </section>
    <section className="guidance-banner" ref={guideRef}><div className="guidance-banner-copy"><span className="light-eyebrow"><span /> NOT JUST FASTER. SECOND NATURE.</span><h2>Good habits.<br /><em>At your fingertips.</em></h2><p>Meet your hands in a whole new dimension. Real-time 3D guidance shows you where to go, until your fingers just know.</p><Link href="/learn/1" className="button button-cream">Try 3D-guided learning <ArrowUpRight size={18} /></Link><span className="guidance-footnote"><Check size={12} /> Made for beginners. Loved by muscle memory.</span></div><div className="guidance-banner-art"><div className="guide-orbit" />{showGuide && <KeyboardScene variant="guide" activeKey="f" />}<div className="guide-preview-label"><span className="mini-key">F</span><div><strong>Left index finger</strong><span>A home for every finger.</span></div><span className="guide-label-dot" /></div><span className="guide-drag-note"><MousePointer2 size={12} /> Go ahead. Look around.</span></div></section>
    <section className="daily-note"><div className="daily-note-icon"><Flower2 size={34} strokeWidth={1.2} /></div><div><span className="eyebrow">A FRIENDLY LITTLE REMINDER</span><h3>Five minutes today. A little more flow tomorrow.</h3><p>You don’t have to be the fastest. Just a little more you than yesterday.</p></div><Link href="/practice" className="text-link">Make a little time <ArrowRight size={18} /></Link></section>
    <div className="landing-endnote"><span /> KEEP IT LIGHT. KEEP IT STEADY. <span /></div>
  </div></Shell>;
}
