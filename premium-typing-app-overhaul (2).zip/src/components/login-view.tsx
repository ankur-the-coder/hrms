"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { ArrowRight, ArrowUpRight, CircleAlert, Eye, EyeOff, Loader2, ShieldCheck } from "lucide-react";
import { Shell } from "./shell";
import { useApp } from "./app-provider";

export default function LoginView() {
  const { login } = useApp();
  const router = useRouter();
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!id.trim()) { setError("Any name or ID is welcome. What should we call you?"); return; }
    setBusy(true); setError("");
    try { await login(id); setPassword(""); router.push("/"); } catch (reason) { setError(reason instanceof Error ? reason.message : "We couldn’t open your space. Try again?"); } finally { setBusy(false); }
  };
  return <Shell><div className="login-page"><section className="login-story"><span className="eyebrow">A LITTLE SPACE, JUST FOR YOU</span><h1>Your thoughts.<br />Your fingers.<br /><em>Your kind of flow.</em></h1><p>Find your rhythm, keep your little wins, and pick up right where you left off. It’s good to have a place to come back to.</p><div className="login-art" aria-hidden="true"><span>f</span><span>l</span><span>o</span><span>w</span></div></section><section className="login-card"><div className="login-card-heading"><h2>Make yourself at home.</h2><span className="demo-label">OPEN DEMO</span></div><p>No hoops to jump through. Any ID and password work here.</p><form onSubmit={submit}><label className="form-label" htmlFor="demo-id">Your name or ID<input id="demo-id" name="demo-id" type="text" autoComplete="off" value={id} onChange={event => setId(event.target.value)} placeholder="Something like alex, or your favorite nickname" maxLength={100} required /></label><label className="form-label" htmlFor="demo-password">Password <span style={{ color: "var(--soft)", fontSize: 9, fontWeight: 400 }}>· anything goes</span><span className="password-input-wrap"><input id="demo-password" name="demo-password" type={visible ? "text" : "password"} autoComplete="off" value={password} onChange={event => setPassword(event.target.value)} placeholder="Any password, or leave it empty" maxLength={200} /><button type="button" onClick={() => setVisible(value => !value)} aria-label={visible ? "Hide password" : "Show password"}>{visible ? <EyeOff size={16} /> : <Eye size={16} />}</button></span></label>{error && <div className="error-message" role="alert"><CircleAlert size={14} />{error}</div>}<button type="submit" className="button button-dark" disabled={busy}>{busy ? "Getting your space ready…" : "Let me in"}{busy ? <Loader2 size={17} className="animate-spin" /> : <ArrowUpRight size={18} />}</button></form><div className="login-divider">OR KEEP IT SIMPLE</div><Link href="/practice" className="button button-outline guest-button">Just let me type <ArrowRight size={16} /></Link><div className="demo-explainer"><ShieldCheck size={16} /><span>This is an open demo, not secure sign-in. Please use made-up credentials. Passwords never leave your browser. Anyone using the same demo ID can access its progress.</span></div></section></div></Shell>;
}
