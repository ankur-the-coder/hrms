"use client";

import Link from "next/link";
import { memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type ChangeEvent, type KeyboardEvent } from "react";
import { ArrowRight, ArrowUpRight, Check, CheckCircle2, ChevronRight, CircleAlert, Globe2, Loader2, MousePointer2, RotateCcw, Sparkles, Trophy } from "lucide-react";
import { useApp } from "./app-provider";
import { SpeedChart } from "./speed-chart";
import type { SpeedPoint, TypingResult, WordStat } from "@/lib/types";

let soundContext: AudioContext | null = null;
function playKeySound(correct: boolean) {
  try {
    soundContext ??= new AudioContext();
    if (soundContext.state === "suspended") void soundContext.resume();
    const oscillator = soundContext.createOscillator(), gain = soundContext.createGain();
    const now = soundContext.currentTime;
    oscillator.type = "sine"; oscillator.frequency.setValueAtTime(correct ? 430 : 160, now); oscillator.frequency.exponentialRampToValueAtTime(correct ? 160 : 70, now + 0.035);
    gain.gain.setValueAtTime(0.035, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);
    oscillator.connect(gain); gain.connect(soundContext.destination); oscillator.start(now); oscillator.stop(now + 0.04);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  } catch { /* Audio is an optional enhancement. */ }
}
const RenderedWord = memo(function RenderedWord({ word, typed, start, last }: { word: string; typed: string; start: number; last: boolean }) {
  const characters = last ? word : word + " ";
  return <span className="typing-word">{characters.split("").map((character, i) => <span key={i} data-char={start + i} className={`typing-char ${character === " " ? "space" : ""} ${i < typed.length ? typed[i] === character ? "correct" : "incorrect" : ""}`}>{character}</span>)}</span>;
});

type EngineProps = { text: string; duration?: number | null; module?: string; title?: string; lessonId?: number; language?: string; onRestart: () => void; onNextKey?: (key: string) => void; onLiveStats?: (wpm: number, progress: number) => void; nextLessonHref?: string; targetWpm?: number; targetAccuracy?: number };
type RunState = { typed: string; startedAt: number | null; finished: boolean; strokes: number; mistakes: number; corrections: number; correct: number; history: SpeedPoint[]; wordStarts: Map<number, number>; wordErrors: Set<number>; wordStats: Map<number, WordStat> };
const newRun = (): RunState => ({ typed: "", startedAt: null, finished: false, strokes: 0, mistakes: 0, corrections: 0, correct: 0, history: [], wordStarts: new Map(), wordErrors: new Set(), wordStats: new Map() });

export function TypingEngine({ text, duration = 30, module = "practice", title = "Typing practice", lessonId, language = "en", onRestart, onNextKey, onLiveStats, nextLessonHref, targetWpm = 0, targetAccuracy = 0 }: EngineProps) {
  const { settings, notify, refresh } = useApp();
  const [typed, setTyped] = useState("");
  const [status, setStatus] = useState<"idle" | "running" | "done">("idle");
  const [focused, setFocused] = useState(true);
  const [elapsed, setElapsed] = useState(0);
  const [result, setResult] = useState<TypingResult | null>(null);
  const [saveState, setSaveState] = useState<"saving" | "saved" | "error">("saving");
  const [composing, setComposing] = useState(false);
  const [draft, setDraft] = useState("");
  const input = useRef<HTMLTextAreaElement>(null);
  const content = useRef<HTMLDivElement>(null);
  const caret = useRef<HTMLSpanElement>(null);
  const restartButton = useRef<HTMLButtonElement>(null);
  const run = useRef<RunState>(newRun());
  const frame = useRef(0);
  const hasSaved = useRef(false);
  const mounted = useRef(true);
  const latestProps = useRef({ onLiveStats, onNextKey, refresh });
  latestProps.current = { onLiveStats, onNextKey, refresh };
  const words = useMemo(() => {
    let offset = 0;
    return text.split(" ").map((word, index, all) => { const start = offset; offset += word.length + 1; return { word, start, last: index === all.length - 1 }; });
  }, [text]);
  const charToWord = useMemo(() => { const map: number[] = []; words.forEach((word, index) => { for (let i = word.start; i <= word.start + word.word.length; i++) map[i] = index; }); return map; }, [words]);
  const moveCaret = useCallback(() => {
    cancelAnimationFrame(frame.current);
    frame.current = requestAnimationFrame(() => {
      if (!content.current || !caret.current) return;
      const element = content.current.querySelector<HTMLElement>(`[data-char="${Math.min(run.current.typed.length, Math.max(0, text.length - 1))}"]`);
      if (!element) return;
      const charRect = element.getBoundingClientRect(), parentRect = content.current.getBoundingClientRect();
      const x = charRect.left - parentRect.left, y = charRect.top - parentRect.top;
      const lineHeight = parseFloat(getComputedStyle(content.current).lineHeight);
      const caretHeight = caret.current.offsetHeight;
      caret.current.style.transform = `translate3d(${x}px,${y + (charRect.height - caretHeight) / 2}px,0)`;
      content.current.style.transform = `translate3d(0,${-Math.max(0, Math.floor((y + 2) / lineHeight) - 1) * lineHeight}px,0)`;
    });
  }, [text]);
  useLayoutEffect(() => { moveCaret(); }, [typed, focused, moveCaret]);
  useEffect(() => {
    mounted.current = true;
    const timeout = setTimeout(() => { input.current?.focus({ preventScroll: true }); moveCaret(); }, 100);
    const resize = () => moveCaret();
    window.addEventListener("resize", resize);
    document.fonts.ready.then(() => { if (mounted.current) moveCaret(); });
    latestProps.current.onNextKey?.(text[0] || "");
    return () => { mounted.current = false; clearTimeout(timeout); cancelAnimationFrame(frame.current); window.removeEventListener("resize", resize); };
  }, [moveCaret, text]);

  const finish = useCallback((at: number) => {
    const current = run.current;
    if (current.finished || current.startedAt === null || current.strokes === 0) return;
    current.finished = true;
    const seconds = Math.max(0.1, duration ? Math.min(duration, (at - current.startedAt) / 1000) : (at - current.startedAt) / 1000);
    const accuracy = Math.max(0, (current.strokes - current.mistakes) / current.strokes * 100);
    const wpm = Math.round((current.correct / 5) / (seconds / 60));
    for (const [index, started] of current.wordStarts) {
      if (current.wordStats.has(index)) continue;
      const word = words[index];
      if (word && word.start < current.typed.length) current.wordStats.set(index, { word: word.word, ms: Math.max(50, at - started), mistyped: current.wordErrors.has(index) });
    }
    const wordStats = [...current.wordStats.values()];
    const history = [...current.history, { second: Math.round(seconds * 10) / 10, wpm }];
    setResult({ module, title, lessonId: lessonId ?? null, wpm, rawWpm: Math.round((current.strokes / 5) / (seconds / 60)), accuracy: Math.round(accuracy * 10) / 10, corrections: current.corrections, durationSeconds: seconds, totalChars: current.strokes, correctChars: current.correct, errorWords: [...new Set(wordStats.filter(w => w.mistyped).map(w => w.word))], slowWords: [], history, wordStats });
    setStatus("done");
    latestProps.current.onLiveStats?.(wpm, 1);
  }, [duration, lessonId, module, title, words]);

  useEffect(() => {
    if (status !== "running") return;
    const timer = setInterval(() => {
      const current = run.current;
      if (current.startedAt === null || current.finished) return;
      const now = performance.now(), seconds = (now - current.startedAt) / 1000;
      const whole = Math.floor(seconds);
      setElapsed(whole);
      const wpm = Math.round((current.correct / 5) / Math.max(1 / 60, seconds / 60));
      if (whole > 0 && current.history.at(-1)?.second !== whole) current.history.push({ second: whole, wpm });
      latestProps.current.onLiveStats?.(wpm, duration ? Math.min(1, seconds / duration) : current.typed.length / text.length);
      if (duration && seconds >= duration) finish(now);
    }, 100);
    return () => clearInterval(timer);
  }, [duration, finish, status, text.length]);

  const saveResult = useCallback(async (value: TypingResult) => {
    setSaveState("saving");
    try {
      const response = await fetch("/api/attempts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(value) });
      if (!response.ok) throw new Error("Could not save");
      if (mounted.current) { setSaveState("saved"); latestProps.current.refresh(); }
    } catch { if (mounted.current) setSaveState("error"); }
  }, []);
  useEffect(() => { if (result && !hasSaved.current) { hasSaved.current = true; void saveResult(result); } }, [result, saveResult]);

  const commitInput = (value: string) => {
    const current = run.current;
    if (current.finished) return;
    const next = value.replace(/[\r\n]/g, "").slice(0, text.length);
    if (next === current.typed) return;
    const now = performance.now();
    if (current.startedAt === null && next.length > 0) { current.startedAt = now; setStatus("running"); }
    if (duration && current.startedAt !== null && now - current.startedAt >= duration * 1000) { finish(now); return; }
    const previous = current.typed;
    if (next.length < previous.length) {
      current.corrections += previous.length - next.length;
      const wordIndex = charToWord[next.length] ?? 0;
      for (const index of current.wordStats.keys()) if (index >= wordIndex) current.wordStats.delete(index);
      for (const index of current.wordStarts.keys()) if (index > wordIndex) current.wordStarts.delete(index);
      current.wordStarts.set(wordIndex, now);
    } else {
      let firstDifference = 0;
      while (firstDifference < previous.length && previous[firstDifference] === next[firstDifference]) firstDifference++;
      for (let i = firstDifference; i < next.length; i++) {
        const wordIndex = charToWord[i] ?? 0, correct = next[i] === text[i];
        current.strokes++;
        if (!correct) { current.mistakes++; current.wordErrors.add(wordIndex); }
        if (!current.wordStarts.has(wordIndex)) current.wordStarts.set(wordIndex, now);
        if (text[i] === " " || i === text.length - 1) {
          const word = words[wordIndex];
          if (word) current.wordStats.set(wordIndex, { word: word.word, ms: Math.max(50, now - (current.wordStarts.get(wordIndex) ?? now)), mistyped: current.wordErrors.has(wordIndex) });
        }
      }
      const last = next.length - 1;
      if (settings.sound) playKeySound(next[last] === text[last]);
      window.dispatchEvent(new CustomEvent("keysteady:key", { detail: next[last] || " " }));
    }
    current.typed = next;
    current.correct = next.split("").reduce((sum, character, index) => sum + Number(character === text[index]), 0);
    setTyped(next);
    latestProps.current.onNextKey?.(text[next.length] || "");
    if (next.length >= text.length) finish(now);
  };
  const handleChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
    if (composing || (event.nativeEvent as InputEvent).isComposing) { setDraft(event.target.value); return; }
    commitInput(event.target.value);
  };
  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Escape") { event.preventDefault(); input.current?.blur(); }
    if (event.key === "Tab") { event.preventDefault(); restartButton.current?.focus(); }
    if (event.key === "Enter" && !composing) event.preventDefault();
  };
  const liveWpm = elapsed > 0 ? Math.round((run.current.correct / 5) / (elapsed / 60)) : 0;
  const liveAccuracy = run.current.strokes ? Math.round((run.current.strokes - run.current.mistakes) / run.current.strokes * 100) : 100;
  const progress = duration ? Math.min(1, elapsed / duration) : typed.length / Math.max(1, text.length);

  if (result) {
    const passed = !lessonId || (result.accuracy >= targetAccuracy && result.wpm >= targetWpm);
    return <div className="result-panel" aria-live="polite"><div className="result-heading"><span className="result-celebration">{passed ? <Sparkles size={23} /> : <Trophy size={23} />}</span><div><h2>{passed ? "That was a good flow." : "Every practice is progress."}</h2><p>{title} · {Math.round(result.durationSeconds)} seconds of showing up for yourself.</p></div><div className={`save-state ${saveState === "error" ? "error" : ""}`}>{saveState === "saving" ? <><Loader2 size={12} className="animate-spin" /> Saving your progress</> : saveState === "saved" ? <><Check size={12} /> Progress saved</> : <><CircleAlert size={12} /> Not saved <button onClick={() => void saveResult(result)}>Retry</button></>}</div></div>
      <div className="results-stats"><div className="result-stat"><span>Your speed</span><strong>{result.wpm}<small> wpm</small></strong><small>Every good word counts.</small></div><div className="result-stat"><span>Accuracy</span><strong>{result.accuracy}<small>%</small></strong><small>{result.accuracy >= 95 ? "Looking beautifully precise." : "Speed will follow accuracy."}</small></div><div className="result-stat"><span>Raw speed</span><strong>{result.rawWpm}<small> wpm</small></strong><small>Before mistakes & corrections.</small></div><div className="result-stat"><span>Characters</span><strong>{result.correctChars}<small> / {result.totalChars}</small></strong><small>{result.corrections} correction{result.corrections === 1 ? "" : "s"} along the way.</small></div></div>
      <div className="chart-legend"><span><i /> Your rhythm, in words per minute</span><span>WPM</span></div><SpeedChart points={result.history} duration={result.durationSeconds} />
      <div className="result-feedback"><Sparkles size={15} /><span>{lessonId && !passed ? `A lovely start. Aim for ${targetWpm} wpm and ${targetAccuracy}% accuracy before moving on. Slow down a little and let each finger find its home.` : result.accuracy >= 98 ? "Beautifully steady. Your accuracy is doing the heavy lifting — keep that relaxed rhythm, and speed will follow." : result.accuracy >= 90 ? "You're finding your rhythm. Try easing off the speed just a little and give each word a clean finish." : "Take a breath and slow things down. Focus on getting each key right. A relaxed, accurate rhythm is the foundation of real speed."}</span></div>
      {result.errorWords.length > 0 && <div className="result-word-list"><span>A little extra practice for</span>{result.errorWords.slice(0, 8).map(word => <span className="word-chip" key={word}>{word}</span>)}{result.errorWords.length > 8 && <span>+{result.errorWords.length - 8} more</span>}</div>}
      <div className="result-actions"><button className="button button-dark" onClick={onRestart}><RotateCcw size={15} /> Find that flow again</button>{nextLessonHref && passed ? <Link href={nextLessonHref} className="button button-outline">Next lesson <ArrowRight size={15} /></Link> : result.errorWords.length ? <Link href="/practice?mode=adaptive" className="button button-outline">Practice tricky words <ArrowUpRight size={15} /></Link> : <Link href="/progress" className="button button-outline">See your progress <ArrowUpRight size={15} /></Link>}</div>
    </div>;
  }
  return <><div className={`typing-engine ${status === "running" ? "engine-running" : ""}`}>
    <div className="typing-engine-header"><span className="typing-language"><Globe2 size={13} />{language === "hi" ? "हिन्दी · Hindi input" : "english"}{module === "adaptive" ? " · your tricky words" : module === "learn" ? " · guided practice" : " · a little focus"}</span><div className="typing-live-stats">{settings.showLiveStats && <><span><strong>{liveWpm}</strong><small>wpm</small></span><span>{liveAccuracy}<small>%</small></span></>}<span className={`remaining-time ${duration && duration - elapsed <= 5 && status === "running" ? "timer-low" : ""}`}>{duration ? Math.max(0, duration - elapsed) : Math.min(words.length, charToWord[typed.length] ?? words.length)}<small>{duration ? "s" : `/ ${words.length}`}</small></span></div></div>
    <div className="typing-zone" onClick={() => input.current?.focus({ preventScroll: true })}>
      <div className="typing-viewport" aria-hidden="true"><div className="typing-content" ref={content}><span ref={caret} className={`typing-caret ${status === "running" ? "is-running" : ""} ${settings.smoothCaret ? "" : "no-smooth"}`} />{words.map((word, index) => <RenderedWord key={index} word={word.word} start={word.start} last={word.last} typed={typed.slice(word.start, word.start + word.word.length + (word.last ? 0 : 1))} />)}</div></div>
      <textarea ref={input} className="typing-input" value={composing ? draft : typed} onChange={handleChange} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} onKeyDown={handleKeyDown} onCompositionStart={() => { setDraft(typed); setComposing(true); }} onCompositionEnd={event => { setComposing(false); commitInput(event.currentTarget.value); }} onPaste={event => { event.preventDefault(); notify("One keystroke at a time. You've got this."); }} onDrop={event => event.preventDefault()} aria-label="Typing area. Type the displayed passage to begin." aria-describedby="typing-passage" spellCheck={false} autoComplete="off" autoCorrect="off" autoCapitalize="off" inputMode="text" data-gramm="false" data-enable-grammarly="false" />
      <p id="typing-passage" className="sr-only">{text}</p>
      {!focused && <button className="typing-focus-overlay" onClick={() => input.current?.focus({ preventScroll: true })}><MousePointer2 size={15} /> Click here to {status === "running" ? "keep your flow going" : "find your flow"}</button>}
    </div>
    <div className="typing-engine-footer"><span className={`typing-status ${status === "running" ? "is-running" : ""}`}><i />{status === "running" ? "You're in your flow. Keep going." : language === "hi" ? "Use your Hindi keyboard / IME. Start whenever you're ready." : "No rush. The first keystroke starts your session."}</span><button ref={restartButton} className="restart-button" onClick={onRestart} title="Restart this session"><RotateCcw size={14} /><span>Start fresh</span></button></div><div className="typing-progress-track"><div className="typing-progress-fill" style={{ width: `${progress * 100}%` }} /></div>
  </div><div className="keyboard-shortcuts"><span><kbd>tab</kbd> + <kbd>enter</kbd> start fresh</span><span><kbd>esc</kbd> step out of focus</span></div></>;
}
