import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";

export const SESSION_COOKIE = "keysteady_demo_profile";
export async function setProfileCookie(id: string) {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, id, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 365, secure: process.env.NODE_ENV === "production" && process.env.COOKIE_SECURE === "true" });
}
export async function getProfile() {
  const jar = await cookies();
  const id = jar.get(SESSION_COOKIE)?.value;
  if (id && /^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(id)) {
    const [profile] = await db.select().from(profiles).where(eq(profiles.id, id)).limit(1);
    if (profile) return profile;
  }
  const [profile] = await db.insert(profiles).values({ displayName: "Guest" }).returning();
  await setProfileCookie(profile.id);
  return profile;
}
