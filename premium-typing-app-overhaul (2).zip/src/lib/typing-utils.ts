export function buildPassage(pool: string[], count: number, seed: number, punctuation = false, numbers = false) {
  if (!pool.length) return "A little practice every day goes a long way.";
  let value = (seed * 14783 + 15943) >>> 0;
  const random = () => { value = (value * 1664525 + 1013904223) >>> 0; return value / 4294967296; };
  const words: string[] = [];
  for (let i = 0; i < count; i++) {
    let word = pool[Math.floor(random() * pool.length)];
    if (numbers && random() < 0.13) word = String(Math.floor(random() * 2026));
    if (punctuation) {
      if (i === 0 || /[.!?]$/.test(words[i - 1])) word = word.charAt(0).toUpperCase() + word.slice(1);
      if (random() < 0.16) word += random() < 0.55 ? "," : ".";
    }
    words.push(word);
  }
  return words.join(" ");
}
