"use client";
import { useEffect, useState } from "react";
import { lessons, tests, drills } from "./catalog";
import type { Catalog } from "./types";

let cached: Catalog | null = null;
export function useCatalog() {
  const [data, setData] = useState<Catalog>(cached || { lessons, tests, drills });
  useEffect(() => {
    let active = true;
    fetch("/api/content").then(r => { if (!r.ok) throw new Error(); return r.json(); }).then((value: Catalog) => { cached = value; if (active) setData(value); }).catch(() => { /* The bundled lesson library also works when storage is offline. */ });
    return () => { active = false; };
  }, []);
  return data;
}
