import { pgTable, uuid, text, integer, real, boolean, timestamp, jsonb, uniqueIndex } from "drizzle-orm/pg-core";

export const profiles = pgTable("profiles", {
  id: uuid("id").defaultRandom().primaryKey(),
  loginId: text("login_id").unique(),
  displayName: text("display_name").notNull().default("Guest"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const typingLessons = pgTable("typing_lessons", {
  id: integer("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  level: integer("level").notNull(),
  keys: text("keys").notNull(),
  practiceText: text("practice_text").notNull(),
  targetAccuracy: integer("target_accuracy").notNull().default(95),
  targetWpm: integer("target_wpm").notNull().default(30),
  language: text("language").notNull().default("en"),
});

export const typingTests = pgTable("typing_tests", {
  id: integer("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  difficulty: text("difficulty").notNull(),
  content: text("content").notNull(),
  source: text("source"),
});

export const typingAttempts = pgTable("typing_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  profileId: uuid("profile_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  module: text("module").notNull(),
  title: text("title").notNull(),
  lessonId: integer("lesson_id").references(() => typingLessons.id, { onDelete: "set null" }),
  wpm: real("wpm").notNull(),
  rawWpm: real("raw_wpm").notNull(),
  accuracy: real("accuracy").notNull(),
  corrections: integer("corrections").notNull().default(0),
  durationSeconds: real("duration_seconds").notNull(),
  totalChars: integer("total_chars").notNull(),
  correctChars: integer("correct_chars").notNull(),
  errorWords: jsonb("error_words").$type<string[]>().notNull().default([]),
  slowWords: jsonb("slow_words").$type<string[]>().notNull().default([]),
  history: jsonb("history").$type<{ second: number; wpm: number }[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const wordMetrics = pgTable("word_metrics", {
  id: uuid("id").defaultRandom().primaryKey(),
  profileId: uuid("profile_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  word: text("word").notNull(),
  mistakeCount: integer("mistake_count").notNull().default(0),
  slowCount: integer("slow_count").notNull().default(0),
  cleanStreak: integer("clean_streak").notNull().default(0),
  masteryScore: integer("mastery_score").notNull().default(0),
  avgMs: real("avg_ms").notNull().default(0),
  status: text("status").notNull().default("active"),
  lastSeen: timestamp("last_seen", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [uniqueIndex("word_metrics_profile_word_idx").on(table.profileId, table.word)]);

export const adaptiveSettings = pgTable("adaptive_settings", {
  profileId: uuid("profile_id").primaryKey().references(() => profiles.id, { onDelete: "cascade" }),
  sound: boolean("sound").notNull().default(false),
  theme: text("theme").notNull().default("light"),
  duration: integer("duration").notNull().default(30),
  showLiveStats: boolean("show_live_stats").notNull().default(true),
  smoothCaret: boolean("smooth_caret").notNull().default(true),
  targetWpm: integer("target_wpm").notNull().default(60),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const velocityDrills = pgTable("velocity_drills", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  duration: integer("duration").notNull(),
  targetWpm: integer("target_wpm").notNull(),
  content: text("content").notNull(),
});
