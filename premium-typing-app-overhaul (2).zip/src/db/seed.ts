import { db } from "@/db";
import { typingLessons, typingTests, velocityDrills } from "./schema";
import { lessons, tests, drills } from "@/lib/catalog";

let seedPromise: Promise<void> | undefined;
export function ensureCatalog() {
  if (!seedPromise) {
    seedPromise = (async () => {
      await db.insert(typingLessons).values(lessons).onConflictDoNothing();
      await db.insert(typingTests).values(tests).onConflictDoNothing();
      await db.insert(velocityDrills).values(drills).onConflictDoNothing();
    })().catch((error) => { seedPromise = undefined; throw error; });
  }
  return seedPromise;
}
