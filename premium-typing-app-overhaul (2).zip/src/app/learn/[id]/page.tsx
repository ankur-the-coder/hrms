import { notFound } from "next/navigation";
import { LearningSession } from "@/components/learning";
import { lessons } from "@/lib/catalog";
export default async function LessonPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!lessons.some(lesson => lesson.id === Number(id))) notFound();
  return <LearningSession key={id} lessonId={Number(id)} />;
}
