import type { Metadata } from "next";
import { LearningLibrary } from "@/components/learning";
export const metadata: Metadata = { title: "Find your foundation" };
export default function LearnPage() { return <LearningLibrary />; }
