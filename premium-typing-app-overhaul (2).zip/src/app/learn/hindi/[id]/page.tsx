import { redirect, notFound } from "next/navigation";
import { lessons } from "@/lib/catalog";
export default async function HindiLessonPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lessonId = Number(id) < 100 ? Number(id) + 100 : Number(id);
  if (!lessons.some(lesson => lesson.id === lessonId && lesson.language === "hi")) notFound();
  redirect(`/learn/${lessonId}`);
}
