import type { Metadata } from "next";
import { LearningLibrary } from "@/components/learning";
export const metadata: Metadata = { title: "Hindi typing foundations" };
export default function HindiPage() { return <LearningLibrary initialLanguage="hi" />; }
