import Link from "next/link";
import { ArrowLeft, Keyboard } from "lucide-react";
import { Shell } from "@/components/shell";
export default function NotFound() { return <Shell><div className="not-found"><Keyboard size={40} strokeWidth={1.2} color="#9b7ab9" /><span className="eyebrow">A LITTLE OFF THE HOME ROW · 404</span><h1>Let’s find your way back.</h1><p>This page isn’t here, but your next good flow is.</p><Link className="button button-dark" href="/"><ArrowLeft size={16} />Back to your space</Link></div></Shell>; }
