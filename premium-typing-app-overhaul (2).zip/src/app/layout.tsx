import type { Metadata } from "next";
import type { ReactNode } from "react";
import { AppProvider } from "@/components/app-provider";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Keysteady — Find your flow. Own every key.", template: "%s · Keysteady" },
  description: "Your feel-good typing studio. Build muscle memory with interactive 3D hand guidance, distraction-free typing, adaptive practice, and a little progress every day.",
  icons: { icon: "/favicon.svg" },
};
export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en" suppressHydrationWarning><body><AppProvider>{children}</AppProvider></body></html>;
}
