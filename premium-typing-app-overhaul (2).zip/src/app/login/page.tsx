import type { Metadata } from "next";
import LoginView from "@/components/login-view";
export const metadata: Metadata = { title: "Make yourself at home" };
export default function LoginPage() { return <LoginView />; }
