import { notFound } from "next/navigation";
import PracticeView from "@/components/practice-view";
import { tests } from "@/lib/catalog";
export default async function SavedPracticePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const test = tests.find(item => item.id === Number(id));
  if (!test) notFound();
  return <PracticeView key={id} initialTestId={test.id} initialMode={test.category === "words" ? "time" : "quote"} />;
}
