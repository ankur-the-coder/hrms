import type { Metadata } from "next";
import PracticeView from "@/components/practice-view";
export const metadata: Metadata = { title: "Your typing studio" };
export default async function PracticePage({ searchParams }: { searchParams: Promise<{ mode?: string }> }) {
  const { mode } = await searchParams;
  return <PracticeView key={mode || "time"} initialMode={mode} />;
}
