import { redirect } from "next/navigation";
export default function WeakWordsPage() { redirect("/practice?mode=adaptive"); }
