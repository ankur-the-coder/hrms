import type { Metadata } from "next";
import SettingsView from "@/components/settings-view";
export const metadata: Metadata = { title: "Your flow, your way" };
export default function SettingsPage() { return <SettingsView />; }
