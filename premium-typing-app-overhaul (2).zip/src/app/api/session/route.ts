import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adaptiveSettings, profiles, typingAttempts, wordMetrics } from "@/db/schema";
import { getProfile, setProfileCookie, SESSION_COOKIE } from "@/lib/session";
import { defaultSettings } from "@/lib/types";

export async function GET() {
  try {
    const profile = await getProfile();
    const [settings] = await db.select().from(adaptiveSettings).where(eq(adaptiveSettings.profileId, profile.id));
    return NextResponse.json({ profile, settings: { ...defaultSettings, ...settings }, demo: true });
  } catch (error) {
    console.error("Session:", error);
    return NextResponse.json({ error: "Progress storage is temporarily unavailable. Please try again." }, { status: 503 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const loginId = String(body.id ?? "").trim().slice(0, 100);
    if (!loginId) return NextResponse.json({ error: "Enter any name or ID to continue." }, { status: 400 });
    const current = await getProfile();
    const [existing] = await db.select().from(profiles).where(eq(profiles.loginId, loginId.toLowerCase())).limit(1);
    let profile = existing;
    if (!profile && !current.loginId) {
      [profile] = await db.update(profiles).set({ loginId: loginId.toLowerCase(), displayName: loginId.split("@")[0].slice(0, 40) }).where(eq(profiles.id, current.id)).returning();
    } else if (!profile) {
      [profile] = await db.insert(profiles).values({ loginId: loginId.toLowerCase(), displayName: loginId.split("@")[0].slice(0, 40) }).onConflictDoUpdate({ target: profiles.loginId, set: { loginId: loginId.toLowerCase() } }).returning();
    }
    if (existing && !current.loginId && existing.id !== current.id) {
      await db.update(typingAttempts).set({ profileId: existing.id }).where(eq(typingAttempts.profileId, current.id));
      // Preserve guest word metrics without overwriting a returning demo profile's history.
      const guestWords = await db.select().from(wordMetrics).where(eq(wordMetrics.profileId, current.id));
      if (guestWords.length) await db.insert(wordMetrics).values(guestWords.map(({ id: _id, ...word }) => ({ ...word, profileId: existing.id }))).onConflictDoNothing();
    }
    await setProfileCookie(profile.id);
    const [settings] = await db.select().from(adaptiveSettings).where(eq(adaptiveSettings.profileId, profile.id));
    // Deliberately open demo authentication. Passwords are never read, stored, or logged.
    return NextResponse.json({ profile, settings: { ...defaultSettings, ...settings }, demo: true });
  } catch (error) {
    console.error("Demo sign in:", error);
    return NextResponse.json({ error: "Could not open your demo profile. Please try again." }, { status: 503 });
  }
}

export async function DELETE() {
  (await cookies()).delete(SESSION_COOKIE);
  return NextResponse.json({ ok: true });
}
