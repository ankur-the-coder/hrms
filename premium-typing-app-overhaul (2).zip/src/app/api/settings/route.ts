import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adaptiveSettings } from "@/db/schema";
import { getProfile } from "@/lib/session";
import { defaultSettings, type Settings } from "@/lib/types";

export async function GET() {
  try {
    const profile = await getProfile();
    const [settings] = await db.select().from(adaptiveSettings).where(eq(adaptiveSettings.profileId, profile.id));
    return NextResponse.json({ settings: { ...defaultSettings, ...settings } });
  } catch { return NextResponse.json({ error: "Could not load preferences." }, { status: 503 }); }
}

export async function PATCH(request: Request) {
  try {
    const b = await request.json();
    const values: Partial<Settings> = {};
    for (const key of ["sound", "showLiveStats", "smoothCaret"] as const) if (typeof b[key] === "boolean") values[key] = b[key];
    if (b.theme === "light" || b.theme === "dark") values.theme = b.theme;
    if ([15, 30, 60, 120].includes(b.duration)) values.duration = b.duration;
    if (Number.isInteger(b.targetWpm) && b.targetWpm >= 10 && b.targetWpm <= 250) values.targetWpm = b.targetWpm;
    const profile = await getProfile();
    const [settings] = await db.insert(adaptiveSettings).values({ ...defaultSettings, ...values, profileId: profile.id }).onConflictDoUpdate({ target: adaptiveSettings.profileId, set: { ...values, updatedAt: new Date() } }).returning();
    return NextResponse.json({ settings });
  } catch { return NextResponse.json({ error: "Could not save preferences. Please try again." }, { status: 503 }); }
}
