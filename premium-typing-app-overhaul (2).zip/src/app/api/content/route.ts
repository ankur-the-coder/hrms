import { NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { typingLessons, typingTests, velocityDrills } from "@/db/schema";
import { ensureCatalog } from "@/db/seed";

export async function GET() {
  try {
    await ensureCatalog();
    const [lessons, tests, drills] = await Promise.all([
      db.select().from(typingLessons).orderBy(asc(typingLessons.id)),
      db.select().from(typingTests).orderBy(asc(typingTests.id)),
      db.select().from(velocityDrills),
    ]);
    return NextResponse.json({ lessons, tests, drills });
  } catch (error) {
    console.error("Catalog:", error);
    return NextResponse.json({ error: "Could not load the lesson library." }, { status: 503 });
  }
}
