import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { wordMetrics } from "@/db/schema";
import { getProfile } from "@/lib/session";

export async function GET() {
  try {
    const profile = await getProfile();
    const words = await db.select().from(wordMetrics).where(eq(wordMetrics.profileId, profile.id)).orderBy(desc(wordMetrics.lastSeen)).limit(250);
    return NextResponse.json({ words });
  } catch { return NextResponse.json({ error: "Could not load your word collection." }, { status: 503 }); }
}
