import { NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { typingAttempts, wordMetrics, adaptiveSettings, typingLessons } from "@/db/schema";
import { getProfile } from "@/lib/session";
import { ensureCatalog } from "@/db/seed";
import type { WordStat, SpeedPoint } from "@/lib/types";

export async function GET() {
  try {
    const profile = await getProfile();
    const attempts = await db.select().from(typingAttempts).where(eq(typingAttempts.profileId, profile.id)).orderBy(desc(typingAttempts.createdAt)).limit(200);
    return NextResponse.json({ attempts });
  } catch (error) {
    console.error("Attempts:", error);
    return NextResponse.json({ error: "Could not load your practice history." }, { status: 503 });
  }
}

export async function POST(request: Request) {
  try {
    const b = await request.json();
    const duration = Number(b.durationSeconds);
    const total = Number(b.totalChars);
    const correct = Number(b.correctChars);
    const accuracy = Number(b.accuracy);
    if (![duration, total, correct, accuracy].every(Number.isFinite) || duration < 0.1 || duration > 7200 || total < 1 || total > 100000 || correct < 0 || correct > total || accuracy < 0 || accuracy > 100 || !Number.isInteger(total) || !Number.isInteger(correct)) {
      return NextResponse.json({ error: "This result is incomplete. Please finish a new session." }, { status: 400 });
    }
    const profile = await getProfile();
    await ensureCatalog();
    const [settings] = await db.select().from(adaptiveSettings).where(eq(adaptiveSettings.profileId, profile.id));
    const targetWpm = settings?.targetWpm || 60;
    const wordStats: WordStat[] = (Array.isArray(b.wordStats) ? b.wordStats : []).slice(0, 200).filter((s: WordStat) => typeof s.word === "string" && s.word.length > 1 && s.word.length < 60 && Number.isFinite(s.ms)).map((s: WordStat) => ({ word: s.word.toLowerCase().replace(/[.,!?;:"()]/g, ""), ms: Math.max(0, Math.min(120000, s.ms)), mistyped: Boolean(s.mistyped) }));
    const isSlow = (s: WordStat) => s.ms > (60000 / targetWpm) * Math.max(1, s.word.length / 5) * 1.7;
    const errorWords = [...new Set(wordStats.filter(s => s.mistyped).map(s => s.word))];
    const slowWords = [...new Set(wordStats.filter(isSlow).map(s => s.word))];
    const history: SpeedPoint[] = (Array.isArray(b.history) ? b.history : []).slice(0, 600).filter((p: SpeedPoint) => Number.isFinite(p.second) && Number.isFinite(p.wpm)).map((p: SpeedPoint) => ({ second: Math.max(0, p.second), wpm: Math.max(0, Math.min(1000, p.wpm)) }));
    let lessonId: number | null = null;
    if (Number.isInteger(b.lessonId)) {
      const [lesson] = await db.select({ id: typingLessons.id }).from(typingLessons).where(eq(typingLessons.id, b.lessonId)).limit(1);
      lessonId = lesson?.id ?? null;
    }
    const attempt = await db.transaction(async (tx) => {
      const [saved] = await tx.insert(typingAttempts).values({
        profileId: profile.id, module: String(b.module || "practice").slice(0, 30), title: String(b.title || "Typing practice").slice(0, 120), lessonId,
        durationSeconds: Math.round(duration * 10) / 10, totalChars: total, correctChars: correct,
        wpm: Math.round((correct / 5) / (duration / 60)), rawWpm: Math.round((total / 5) / (duration / 60)), accuracy: Math.round(accuracy * 10) / 10,
        corrections: Math.max(0, Math.min(100000, Math.floor(Number(b.corrections) || 0))), errorWords, slowWords, history,
      }).returning();
      for (const stat of wordStats) {
        if (!stat.word) continue;
        const slow = isSlow(stat);
        const [old] = await tx.select().from(wordMetrics).where(and(eq(wordMetrics.profileId, profile.id), eq(wordMetrics.word, stat.word))).limit(1);
        if (!old && !stat.mistyped && !slow) continue;
        const streak = stat.mistyped || slow ? 0 : (old?.cleanStreak ?? 0) + 1;
        const score = Math.max(0, Math.min(100, (old?.masteryScore ?? 0) + (stat.mistyped ? -22 : slow ? -10 : 25)));
        const values = { profileId: profile.id, word: stat.word, mistakeCount: (old?.mistakeCount ?? 0) + Number(stat.mistyped), slowCount: (old?.slowCount ?? 0) + Number(slow), cleanStreak: streak, masteryScore: score, avgMs: old ? old.avgMs * 0.7 + stat.ms * 0.3 : stat.ms, status: streak >= 4 && score >= 80 ? "mastered" : "active", lastSeen: new Date() };
        await tx.insert(wordMetrics).values(values).onConflictDoUpdate({ target: [wordMetrics.profileId, wordMetrics.word], set: values });
      }
      return saved;
    });
    return NextResponse.json({ attempt }, { status: 201 });
  } catch (error) {
    console.error("Save result:", error);
    return NextResponse.json({ error: "Your result could not be saved. You can retry from this screen." }, { status: 503 });
  }
}
