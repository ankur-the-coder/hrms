import type { Metadata } from "next";
import { VelocityLibrary } from "@/components/velocity";
export const metadata: Metadata = { title: "The velocity lab" };
export default function VelocityPage() { return <VelocityLibrary />; }
