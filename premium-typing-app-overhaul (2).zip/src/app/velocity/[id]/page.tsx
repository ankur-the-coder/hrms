import { notFound } from "next/navigation";
import { VelocitySession } from "@/components/velocity";
import { drills } from "@/lib/catalog";
export default async function DrillPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!drills.some(drill => drill.id === id)) notFound();
  return <VelocitySession key={id} drillId={id} />;
}
