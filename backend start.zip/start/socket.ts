import Server from '@ioc:Adonis/Core/Server'
import { Server as SocketServer } from 'socket.io'

// Guard against this module (and its io.on('connection', ...) listeners
// below) being bound twice to the same underlying HTTP server. AdonisJS's
// `--watch` file-reloader can re-execute preload files without tearing down
// what a previous execution already attached — two live Engine.IO routers
// answering the same requests is what was causing the browser's socket to
// get "session ID unknown" errors and spin into a rapid handshake/retry
// loop (the flood of tiny /socket.io/?transport=polling requests).
declare global {
  // eslint-disable-next-line no-var
  var __ubidesk_io: SocketServer | undefined
}

const io = globalThis.__ubidesk_io ?? new SocketServer(Server.instance!, {
  cors: { origin: '*' },              // tighten this in production
  transports: ['websocket', 'polling'],
})
const alreadyBound = !!globalThis.__ubidesk_io
globalThis.__ubidesk_io = io

export { io }

// =============================================================================
// DEBUG LOG SYSTEM — backend half of the "i" button / debug modal.
//
// Keeps a small ring buffer of server-side events (connection errors,
// ticket_message failures, etc) so a browser tab that opens the debug modal
// can see what the SERVER thinks happened — including things like Engine.IO
// `connection_error` (e.g. "session id unknown"), which never reach the
// client as a normal socket event at all. New subscribers get the buffer
// backfilled via `debug_log_history`; after that they get each new entry
// live via `debug_log`. Shape must match frontend's DebugLogEntry
// (src/app/core/models/debug-log.model.ts): { id, ts, level, source,
// message, data }.
// =============================================================================
type DebugLogLevel = 'debug' | 'info' | 'warn' | 'error'
type DebugLogSource = 'client' | 'server' | 'engine'
interface DebugLogEntry {
  id: string
  ts: number
  level: DebugLogLevel
  source: DebugLogSource
  message: string
  data?: any
}

const MAX_SERVER_LOGS = 400
const serverLogBuffer: DebugLogEntry[] = (globalThis as any).__ubidesk_debug_logs ?? []
;(globalThis as any).__ubidesk_debug_logs = serverLogBuffer

let logSeq = 0
function pushServerLog(level: DebugLogLevel, source: DebugLogSource, message: string, data?: any) {
  const entry: DebugLogEntry = { id: `s-${Date.now()}-${logSeq++}`, ts: Date.now(), level, source, message, data }
  serverLogBuffer.push(entry)
  if (serverLogBuffer.length > MAX_SERVER_LOGS) serverLogBuffer.splice(0, serverLogBuffer.length - MAX_SERVER_LOGS)
  // Broadcast live to every socket that has asked to subscribe.
  io.sockets.sockets.forEach((s) => {
    if ((s.data as any)?.debugSubscribed) s.emit('debug_log', entry)
  })
}

// =============================================================================
// SERVER ENVIRONMENT DIAGNOSTICS — backs the "Environment" tab in the debug
// modal. Snapshots everything about the running backend process that's
// useful when something only breaks in production: runtime/platform info,
// memory & event-loop health, DB reachability + latency, active socket
// count, and (sanitized) relevant env vars. Sent on request and refreshed
// automatically every 15s to any subscribed socket so the panel stays live
// without the user needing to reopen it.
// =============================================================================
interface ServerDiagnostics {
  ts: number
  runtime: {
    nodeVersion: string
    platform: string
    arch: string
    pid: number
    uptimeSeconds: number
    env: string | undefined
  }
  host: {
    hostname: string
    totalMemMB: number
    freeMemMB: number
    loadAvg: number[]
    cpuCount: number
  }
  process: {
    rssMB: number
    heapUsedMB: number
    heapTotalMB: number
    externalMB: number
    eventLoopLagMs: number | null
  }
  socket: {
    connectedClients: number
    transport_ws: number
    transport_polling: number
  }
  database: {
    connected: boolean
    latencyMs: number | null
    error: string | null
  }
  config: {
    // Only presence/shape, never values — never leak secrets into a debug
    // panel that could end up in a screenshot or shared log dump.
    hasDbConfig: boolean
    hasWhatsappAccount: boolean
    hasActiveMailAccount: boolean
    corsOrigin: string
  }
}

let lastLoopLagMs: number | null = null
// Cheap event-loop-lag probe: schedule a timer for `1ms` and measure how
// late it actually fires. Large numbers here (tens/hundreds of ms) mean the
// event loop is being blocked by something synchronous/heavy — a common,
// otherwise-invisible cause of "everything feels slow/stuck" reports.
function primeEventLoopLagProbe() {
  const start = Date.now()
  setTimeout(() => {
    lastLoopLagMs = Date.now() - start - 1
    setTimeout(primeEventLoopLagProbe, 2000)
  }, 1)
}

async function collectDiagnostics(): Promise<ServerDiagnostics> {
  const os = await import('os')
  const mem = process.memoryUsage()

  let dbConnected = false
  let dbLatencyMs: number | null = null
  let dbError: string | null = null
  try {
    const { default: Database } = await import('@ioc:Adonis/Lucid/Database')
    const start = Date.now()
    await Database.rawQuery('SELECT 1')
    dbLatencyMs = Date.now() - start
    dbConnected = true
  } catch (err: any) {
    dbError = err?.message || String(err)
  }

  let hasWhatsappAccount = false
  let hasActiveMailAccount = false
  try {
    const { default: Database } = await import('@ioc:Adonis/Lucid/Database')
    const wa = await Database.from('whatsapp_accounts').where('is_active', 1).first()
    hasWhatsappAccount = !!wa
    const mail = await Database.from('mail_accounts').first().catch(() => null)
    hasActiveMailAccount = !!mail
  } catch {
    // Best-effort — diagnostics shouldn't throw just because an optional
    // check failed.
  }

  let wsCount = 0
  let pollingCount = 0
  io.sockets.sockets.forEach((s) => {
    const t = (s.conn as any)?.transport?.name
    if (t === 'websocket') wsCount++
    else if (t === 'polling') pollingCount++
  })

  return {
    ts: Date.now(),
    runtime: {
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
      pid: process.pid,
      uptimeSeconds: Math.round(process.uptime()),
      env: process.env.NODE_ENV,
    },
    host: {
      hostname: os.hostname(),
      totalMemMB: Math.round(os.totalmem() / 1024 / 1024),
      freeMemMB: Math.round(os.freemem() / 1024 / 1024),
      loadAvg: os.loadavg().map((n) => Math.round(n * 100) / 100),
      cpuCount: os.cpus().length,
    },
    process: {
      rssMB: Math.round(mem.rss / 1024 / 1024),
      heapUsedMB: Math.round(mem.heapUsed / 1024 / 1024),
      heapTotalMB: Math.round(mem.heapTotal / 1024 / 1024),
      externalMB: Math.round(mem.external / 1024 / 1024),
      eventLoopLagMs: lastLoopLagMs,
    },
    socket: {
      connectedClients: io.engine.clientsCount,
      transport_ws: wsCount,
      transport_polling: pollingCount,
    },
    database: { connected: dbConnected, latencyMs: dbLatencyMs, error: dbError },
    config: {
      hasDbConfig: !!process.env.DB_HOST || !!process.env.DB_CONNECTION,
      hasWhatsappAccount,
      hasActiveMailAccount,
      corsOrigin: '*', // matches the SocketServer cors config above
    },
  }
}

// Engine.IO-level connection errors (bad handshake, unknown session id from
// a stale/duplicate transport, etc) happen BEFORE a socket.io `connection`
// even exists, so they can only be caught here — this is the layer where
// the production "session ID unknown" symptom actually surfaces.
if (!alreadyBound) {
  ;(io.engine as any).on('connection_error', (err: any) => {
    pushServerLog('error', 'engine', `connection_error: ${err?.message || err}`, {
      code: err?.code,
      context: err?.context,
      req: err?.req?.url,
    })
  })

  primeEventLoopLagProbe()

  // Catch up on any mail that arrived in connected mailboxes while the
  // server was down — was previously dead code (MailAccountService.
  // performCatchUpSync existed but nothing ever called it). Fire-and-forget
  // so it doesn't hold up server boot; failures are logged, not thrown.
  ;(async () => {
    try {
      const { default: MailAccountService } = await import('App/Services/MailAccountService')
      await MailAccountService.performCatchUpSync()

      const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
      console.log('[socket] running boot-time historical mail reconciliation for the last 14 days...')
      await EmailToTicketService.reconcileMailHistory(14)

      // Self-healing pass — corrects wrong timing/attachment-classification
      // on messages that ARE already recorded (as opposed to the
      // reconciliation call above, which only fills in ones that are
      // missing). Runs across every open ticket on every boot; a ticket
      // reopened later gets the same check at that moment instead (see
      // TicketService.reopenByCustomer).
      // console.log('[socket] running boot-time repair pass on open tickets\' email messages...')
      // await EmailToTicketService.repairOpenTicketMessages()
    } catch (err: any) {
      console.error('[socket] boot-time mail catch-up/reconciliation failed:', err?.response?.data ?? err.message)
    }
  })()

  // Push a fresh diagnostics snapshot to every subscribed socket every 15s
  // so the panel stays live without the user re-requesting it. A single
  // shared interval regardless of how many sockets are subscribed — cheap,
  // and avoids N duplicate DB pings per tick.
  setInterval(async () => {
    const hasSubscribers = Array.from(io.sockets.sockets.values()).some((s) => (s.data as any)?.debugSubscribed)
    if (!hasSubscribers) return
    const diagnostics = await collectDiagnostics().catch((err) => {
      pushServerLog('error', 'server', `diagnostics collection failed: ${err.message || err}`)
      return null
    })
    if (!diagnostics) return
    io.sockets.sockets.forEach((s) => {
      if ((s.data as any)?.debugSubscribed) s.emit('server_diagnostics', diagnostics)
    })
  }, 15000)
}

if (!alreadyBound) {
io.on('connection', (socket) => {

  // =========================================================================
  // 0. DEBUG LOG SUBSCRIPTION
  // =========================================================================

  socket.on('subscribe_debug_logs', async () => {
    socket.data = { ...socket.data, debugSubscribed: true }
    socket.emit('debug_log_history', serverLogBuffer)
    // Send an immediate snapshot on subscribe rather than waiting up to 15s
    // for the next scheduled tick.
    const diagnostics = await collectDiagnostics().catch((err) => {
      pushServerLog('error', 'server', `diagnostics collection failed: ${err.message || err}`)
      return null
    })
    if (diagnostics) socket.emit('server_diagnostics', diagnostics)
  })

  // Explicit on-demand refresh — the modal's "Refresh" button uses this so
  // the user isn't stuck waiting for the 15s auto-tick.
  socket.on('request_diagnostics', async () => {
    const diagnostics = await collectDiagnostics().catch((err) => {
      pushServerLog('error', 'server', `diagnostics collection failed: ${err.message || err}`)
      return null
    })
    if (diagnostics) socket.emit('server_diagnostics', diagnostics)
  })

  // =========================================================================
  // 1. AUTH & SESSION LOGIC
  // =========================================================================
  
  socket.on('join_agent', async (data: { agentId: number; agentName: string; role: string; device: string; force?: boolean }) => {
    try {
      if (!data?.agentId) return
      const agentId = Number(data.agentId)

      // Authenticate this socket immediately, synchronously, before any
      // await below. join_agent and a fast follow-up emit on the same
      // socket (e.g. "Pick up" clicked right after page load/reconnect)
      // aren't guaranteed to run in order once this handler yields on an
      // await — assign_ticket's requesterAgentId check could run while
      // this was still mid-flight, rejecting with "Not authenticated on
      // this connection" even though join_agent had already been sent.
      // The DB work below is single-login session bookkeeping, not
      // authorization — if it turns out this agent is already active on
      // another device (and this isn't a forced takeover), we revoke the
      // optimistic auth granted here.
      socket.data = { ...socket.data, agentId, agentName: data.agentName, role: data.role }
      socket.join(`agent_${agentId}`)

      const { default: Database } = await import('@ioc:Adonis/Lucid/Database')

      const agent = await Database.from('support_agents').where('id', agentId).first()
      if (agent?.current_socket_id && agent.current_socket_id !== socket.id) {
        if (!data.force) {
          if (socket.data?.agentId === agentId) {
            socket.data = { ...socket.data, agentId: undefined }
            socket.leave(`agent_${agentId}`)
          }
          socket.emit('login_blocked', { reason: 'Account already active on another device.' })
          return
        }
        io.to(agent.current_socket_id).emit('force_logout', { newDevice: data.device })
      }

      await Database.from('support_agents').where('id', agentId).update({
        current_socket_id: socket.id,
        current_device: data.device,
      })
    } catch (err: any) {
      console.error('[socket] join_agent error:', err)
      pushServerLog('error', 'server', `join_agent error: ${err.message || err}`, { agentId: data?.agentId })
    }
  })

  // =========================================================================
  // 2. TICKET DOMAIN EVENTS
  // =========================================================================

  socket.on('join_ticket', (ticketId: number) => {
    if (ticketId) socket.join(`ticket_${ticketId}`)
  })

  socket.on('leave_ticket', (ticketId: number) => {
    if (ticketId) socket.leave(`ticket_${ticketId}`)
  })

  socket.on('update_ticket_status', async (data: { ticketId: number; status: string; sendClosureMessage?: boolean }) => {
    try {
      if (!data?.ticketId) return
      const { default: TicketService } = await import('App/Services/TicketService')
      const ticket = await TicketService.updateStatus(data.ticketId, data.status, !!data.sendClosureMessage)
      
      io.to(`ticket_${data.ticketId}`).emit('ticket_status_changed', ticket)
      io.emit('tickets_updated')
      io.emit('dashboard_stats_stale')
    } catch (err: any) {
      console.error('[socket] update_ticket_status error:', err)
      pushServerLog('error', 'server', `update_ticket_status error: ${err.message || err}`, { ticketId: data?.ticketId })
    }
  })

  socket.on('ticket_typing', (data: { ticketId: number; sender: string; isTyping: boolean }) => {
    if (data?.ticketId) {
      socket.to(`ticket_${data.ticketId}`).emit('ticket_typing', data)
    }
  })

  // Was: `agentId = socket.data?.agentId || data.agentId` — falling back to
  // data.agentId (the ticket's TARGET agent, e.g. whoever a reassign is
  // FOR) meant that if this socket's own agentId wasn't set yet for any
  // reason, the handler would resolve "requester" as the person being
  // ASSIGNED, not the person clicking the button. For a self pick-up those
  // happen to be the same id, which is exactly why this silently seemed to
  // work sometimes and not others. Must always be the authenticated
  // caller — never fall back to a value that came from the payload.
  socket.on('assign_ticket', async (data: { ticketId: number; agentId: number; agentName: string }, callback?: (response: { ok: boolean; error?: string; ticket?: any }) => void) => {
    try {
      if (!data?.ticketId) {
        callback?.({ ok: false, error: 'Missing ticketId' })
        return
      }
      const { default: Database } = await import('@ioc:Adonis/Lucid/Database')
      const requesterAgentId = socket.data?.agentId
      if (!requesterAgentId) {
        // This socket never completed join_agent (or the tab reconnected
        // and hasn't re-authenticated yet) — reject clearly instead of
        // letting TicketService.assignTicket crash on `requester.role`
        // with an opaque TypeError.
        callback?.({ ok: false, error: 'Not authenticated on this connection — refresh and try again.' })
        return
      }
      const requester = await Database.from('support_agents').where('id', requesterAgentId).first()
      if (!requester) {
        callback?.({ ok: false, error: 'Requesting agent not found.' })
        return
      }

      const { default: TicketService } = await import('App/Services/TicketService')
      const ticket = await TicketService.assignTicket(data.ticketId, data.agentId, data.agentName, requester)
      io.to(`ticket_${data.ticketId}`).emit('ticket_assigned', ticket)
      io.emit('tickets_updated')
      callback?.({ ok: true, ticket })
    } catch (err: any) {
      console.error('[socket] assign_ticket error:', err.message || err)
      pushServerLog('error', 'server', `assign_ticket error: ${err.message || err}`, { ticketId: data?.ticketId })
      socket.emit('assignment_rejected', { reason: err.message || 'Assignment failed' })
      callback?.({ ok: false, error: err.message || 'Assignment failed' })
    }
  })

  // Was: fire-and-forget — emitted 'new_ticket_message' and hoped the
  // frontend's optimistic placeholder eventually got swapped for the real
  // row. No ack meant a slow/failed send and a genuinely dead socket looked
  // identical to the client: both just sat there forever. The frontend
  // (ticket-socket.services.ts) now emits this WITH an ack callback via
  // `socket.timeout(8000).emit(...)`, so this handler must invoke that
  // callback with { ok: true } or { ok: false, error } — that's the 3rd
  // `callback` argument socket.io injects automatically when the client
  // emits with an ack.
  socket.on('ticket_message', async (data: any, callback?: (response: { ok: boolean; error?: string }) => void) => {
    try {
      if (!data?.ticketId) {
        callback?.({ ok: false, error: 'Missing ticketId' })
        return
      }
      const { default: Database } = await import('@ioc:Adonis/Lucid/Database')
      const agentId = socket.data?.agentId || data.agentId || data.agent_id
      const requester = agentId ? await Database.from('support_agents').where('id', agentId).first() : null

      const { default: TicketService } = await import('App/Services/TicketService')
      // NOTE: TicketService.addMessage() now backgrounds the outbound
      // WhatsApp/email send itself and returns as soon as the message is
      // persisted — so this resolves quickly and the ack below reflects
      // "saved", not "delivered to the customer". Delivery/failure status
      // arrives afterwards via a separate 'message_updated' emit.
      const saved = await TicketService.addMessage({ ...data, requester })
      io.to(`ticket_${data.ticketId}`).emit('new_ticket_message', saved)
      io.emit('ticket_bump', { ticketId: data.ticketId })
      io.emit('dashboard_stats_stale')
      callback?.({ ok: true })
    } catch (err: any) {
      console.error('[socket] ticket_message error:', err.message || err)
      pushServerLog('error', 'server', `ticket_message error: ${err.message || err}`, { ticketId: data?.ticketId })
      socket.emit('message_rejected', { reason: err.message || 'Failed to send message' })
      callback?.({ ok: false, error: err.message || 'Failed to send message' })
    }
  })

  // =========================================================================
  // 3. DISCONNECT & CLEANUP
  // =========================================================================

  socket.on('disconnect', async (reason) => {
    try {
      if (socket.data?.agentId) {
        const { default: Database } = await import('@ioc:Adonis/Lucid/Database')
        await Database.from('support_agents')
          .where('id', socket.data.agentId)
          .where('current_socket_id', socket.id)
          .update({ current_socket_id: null, current_device: null })
      }
      pushServerLog('info', 'server', `socket disconnected: ${reason}`, { socketId: socket.id, agentId: socket.data?.agentId })
    } catch (err) {
      console.error('[socket] disconnect error:', err)
    }
  })
})
} // end if (!alreadyBound)