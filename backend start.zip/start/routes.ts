
import Route from '@ioc:Adonis/Core/Route'
// import Route from '@ioc:Adonis/Core/Route'

import "../app/Routes/ChatRoute"
import "../app/Routes/TicketResyncRoute"
import "../app/Routes/ReportRoute"
import Database from '@ioc:Adonis/Lucid/Database';

(global as any).jobListenersByUser = (global as any).jobListenersByUser || {}

Route.get('/sse/job-updates', async ({ request, response }) => {
  const userId = request.input('userId')

  if (!userId) {
    response.status(400).send('Missing user ID')
    return
  }

  response.response.setHeader('Content-Type', 'text/event-stream')
  response.response.setHeader('Cache-Control', 'no-cache')
  response.response.setHeader('Connection', 'keep-alive')
  response.response.setHeader('Access-Control-Allow-Origin', '*')

  if (response.response.flushHeaders) {
    response.response.flushHeaders()
  }

  // Immediately notify client that connection is live
  response.response.write(`data: ${JSON.stringify('connected')}\n\n`)

  const sendEvent = (event: any) => {
    response.response.write(`event: job-update\n`)
    response.response.write(`data: ${JSON.stringify(event)}\n\n`) 
  }

  // Store listener
  if (!(global as any).jobListenersByUser[userId]) {
    (global as any).jobListenersByUser[userId] = []
  }
  (global as any).jobListenersByUser[userId].push(sendEvent)

  // Heartbeat
  const ping = setInterval(() => {
    console.log(`Sending ping to user ${userId}`)
    response.response.write(`event: ping\ndata: {}\n\n`)
  }, 15000)

  request.request.on('close', () => {
    console.log(`SSE closed for user ${userId}`)
    clearInterval(ping)
    const all = (global as any).jobListenersByUser[userId]
    if (all) {
      (global as any).jobListenersByUser[userId] = all.filter((fn: any) => fn !== sendEvent)
    }
    response.response.end()
  })
})

Route.get('/health', async ({ response }) => {
  try {
    await Database.rawQuery('SELECT 1') // ping the database

    return response.status(200).send({
      status: 'ok',
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      db: 'connected',
    })
  } catch (error:any) {
    return response.status(500).send({
      status: 'error',
      message: 'Database connection failed',
      error: error.message,
    })
  }
})


Route.get('/', async ({ request }) => {
  const protocol = request.protocol()
  const host = request.host()
  const url = `${protocol}://${host}`

  console.log('HOST URL:', url)

  return { hello: 'world' }
})

