/*
|--------------------------------------------------------------------------
| Application middleware
|--------------------------------------------------------------------------
|
| This file is used to define middleware for HTTP requests. You can register
| middleware as a `closure` or an IoC container binding. The bindings are
| preferred, since they keep this file clean.
|
*/

import Server from '@ioc:Adonis/Core/Server'

/*
|--------------------------------------------------------------------------
| Global middleware
|--------------------------------------------------------------------------
|
| An array of global middleware, that will be executed in the order they
| are defined for every HTTP requests.
|
*/
Server.middleware.register([
  () => import('@ioc:Adonis/Core/BodyParser'),
  () => import('App/Middleware/SecurityHeaders'),
  // () => import('App/Middleware/Auth'),
  () => import('App/Middleware/Apilogger'),
])

/*
|--------------------------------------------------------------------------
| Named middleware
|--------------------------------------------------------------------------
|
| Named middleware are defined as key-value pair. The value is the namespace
| or middleware function and key is the alias. Later you can use these
| alias on individual routes. For example:
|
| { auth: () => import('App/Middleware/Auth') }
|
| and then use it as follows
|
*/
Server.middleware.registerNamed({

  throttle: () => import('@adonisjs/limiter/build/throttle'),
  auth: () => import('App/Middleware/Auth'),
    agentAuth: () => import('App/Middleware/AgentAuth'),  
  // inject: () => import('App/Middleware/Authentication'),
  ApiLogger:() => import('App/Middleware/Apilogger'),
  RateLimiter:() => import('App/Middleware/RateLimiter'),
  // CustomCors:()=>import('App/Middleware/CustomCors'),
  // EncryptResponse: () => import('App/Middleware/EncryptResponse'),
  // StrictCors: () => import('App/Middleware/StrictCors'),
  
})
  