import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import type { ChartDatum } from '../Charts';
import { buildThreePNG, captureLabelPositions, withExportResolution, type ExportTheme } from './exportUtils';
import type { ThreeChartHandle } from './ThreeSankey3D';

interface Props {
  data: ChartDatum[];
  palette: string[];
  dim: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (idx: number | null, text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

class ArcCurve3 extends THREE.Curve<THREE.Vector3> {
  radius: number; startAngle: number; endAngle: number;
  constructor(radius: number, startAngle: number, endAngle: number) {
    super();
    this.radius = radius; this.startAngle = startAngle; this.endAngle = endAngle;
  }
  getPoint(t: number, target = new THREE.Vector3()) {
    const angle = this.startAngle + t * (this.endAngle - this.startAngle);
    return target.set(Math.cos(angle) * this.radius, 0, -Math.sin(angle) * this.radius);
  }
}

function escXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function adjustColor(hex: string, percent: number): string {
  const num = parseInt(hex.replace('#', ''), 16);
  let r = (num >> 16) + Math.round(255 * (percent / 100));
  let g = ((num >> 8) & 0x00ff) + Math.round(255 * (percent / 100));
  let b = (num & 0x0000ff) + Math.round(255 * (percent / 100));
  r = Math.min(255, Math.max(0, r)); g = Math.min(255, Math.max(0, g)); b = Math.min(255, Math.max(0, b));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

/** Radial bar chart rendered as real 3D tube-arcs.
 * A single Three.js scene serves BOTH the 2D and 3D views — only the
 * camera position/up-vector and each arc's vertical lift morph between
 * them, so 2D⇄3D is a true camera transition rather than a different
 * chart.
 *
 * Design notes (Option B fixes):
 * - NO white/ghost track pipes: each datum paints exactly ONE colored
 *   tube. Empty remainder is implied by the tube's own sweep.
 * - 3D default view is a readable oblique preset where every label pill
 *   floats on its own staggered lane — nothing hides behind anything.
 * - Labels are panel-styled pills (same family as pie/donut leaders)
 *   and follow the card's font.
 * - SVG export is TRUE vector: every tube is re-projected through the
 *   live camera into shaded ribbon paths + gradients (no <image>). */
const ThreeRadialBar = forwardRef<ThreeChartHandle, Props>(function ThreeRadialBar(
  { data, palette, dim, hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);

  const api = useRef<{
    renderer: THREE.WebGLRenderer;
    labelRenderer: CSS2DRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    rings: {
      barGroup: THREE.Group; badge: CSS2DObject; stem: THREE.Line; radius: number;
      mat: THREE.MeshPhysicalMaterial; name: string; value: number;
      startA: number; endA: number; frac: number; color: string;
    }[];
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    setMode: (m: '2D' | '3D') => void;
    getLift: () => number;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 500);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container!.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container!.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 - 0.03;
    controls.enabled = false;

    scene.add(new THREE.AmbientLight(0xffffff, 1.4));
    const key = new THREE.DirectionalLight(0xfffdfa, 2.1);
    key.position.set(8, 20, 10);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0006;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xa0c8ff, 0.8);
    fill.position.set(-10, 8, -10);
    scene.add(fill);

    const graphGroup = new THREE.Group();
    scene.add(graphGroup);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), new THREE.ShadowMaterial({ opacity: 0.1 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.05;
    floor.receiveShadow = true;
    graphGroup.add(floor);

    const INNER_R = 1.55, R_STEP = 0.44, TUBE_R = 0.12;
    const items = (data || []).slice(0, 24);
    const MAX_VAL = Math.max(1, ...items.map((d) => d.value)) * 1.06;

    function makeBar(radius: number, startA: number, endA: number, color: string) {
      const group = new THREE.Group();
      const mat = new THREE.MeshPhysicalMaterial({ color: new THREE.Color(color), roughness: 0.25, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.15 });
      const curve = new ArcCurve3(radius, startA, endA);
      const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 96, TUBE_R, 20, false), mat);
      tube.castShadow = true; tube.receiveShadow = true;
      group.add(tube);
      const capGeo = new THREE.SphereGeometry(TUBE_R, 20, 20);
      const c0 = new THREE.Mesh(capGeo, mat); c0.position.copy(curve.getPoint(0)); c0.castShadow = true; group.add(c0);
      const c1 = new THREE.Mesh(capGeo, mat); c1.position.copy(curve.getPoint(1)); c1.castShadow = true; group.add(c1);
      return { group, mat, tube };
    }

    const rings: NonNullable<typeof api.current>['rings'] = [];
    const hitMeshes: { mesh: THREE.Object3D; ringIdx: number }[] = [];
    const labelRefs: { el: HTMLElement; text: string; color?: string }[] = [];

    items.forEach((d, i) => {
      const color = d.color || palette[i % palette.length];
      const radius = INNER_R + i * R_STEP;
      // NOTE: no track pipe — a single colored tube per datum.
      const frac = Math.min(1, d.value / MAX_VAL);
      const startA = Math.PI / 2;
      const sweep = Math.max(0.02, frac * Math.PI * 2 * 0.97);
      const endA = startA - sweep;
      const { group: barGroup, mat, tube } = makeBar(radius, startA, endA, color);
      graphGroup.add(barGroup);
      hitMeshes.push({ mesh: tube, ringIdx: i });
      (barGroup as unknown as { userData: { targetY: number } }).userData = { targetY: 0.1 + frac * 0.42 };

      const cDiv = document.createElement('div');
      cDiv.className = 'rb3d-badge';
      cDiv.textContent = `${d.label} · ${Math.round(d.value)}`;
      cDiv.style.fontFamily = theme.fontBody;
      cDiv.style.color = dark ? '#f1f5ef' : '#1c2620';
      if (dark) {
        cDiv.style.background = 'rgba(20,26,22,0.88)';
        cDiv.style.border = '1px solid rgba(255,255,255,0.16)';
      }
      cDiv.style.borderLeft = `4px solid ${color}`;
      const cObj = new CSS2DObject(cDiv);
      graphGroup.add(cObj);
      // staggered lanes: outermost ring floats highest — in the default 3D
      // oblique preset every pill sits on its own lane, fully visible.
      (cObj as unknown as { userData: { targetY: number; radius: number } }).userData = {
        targetY: 0.75 + (items.length - 1 - i) * 0 + i * 0.19, radius,
      };
      labelRefs.push({ el: cDiv, text: `${d.label} · ${Math.round(d.value)}`, color });

      const stemMat = new THREE.LineBasicMaterial({ color: dark ? 0x666666 : 0xcccccc, transparent: true, opacity: 0.8 });
      const stemGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, -radius), new THREE.Vector3(0, 0, -radius)]);
      const stemLine = new THREE.Line(stemGeo, stemMat);
      graphGroup.add(stemLine);

      rings.push({ barGroup, badge: cObj, stem: stemLine, radius, mat, name: d.label, value: d.value, startA, endA, frac, color });
    });

    const maxR = INNER_R + Math.max(0, items.length - 1) * R_STEP + 0.6;
    // 2D: straight top-down, plot fills the frame.
    const state2D = { camPos: new THREE.Vector3(0, 21, 0.001), camTarget: new THREE.Vector3(0, 0, 0), up: new THREE.Vector3(0, 0, -1), lift: 0 };
    // 3D default: readable oblique preset. The azimuth swings the stacked
    // label column to the LEFT of the rings (screen space) so no pill is
    // ever hidden behind a tube — see badge anchor below (badges sit at
    // -X, tubes occupy the +X half at their tallest).
    const rr = Math.max(3.2, maxR);
    const state3D = { camPos: new THREE.Vector3(-rr * 1.35, rr * 1.5, rr * 1.9), camTarget: new THREE.Vector3(0, 0.25, 0), up: new THREE.Vector3(0, 1, 0), lift: 1 };

    let mode: '2D' | '3D' = '2D';
    let transitioning = false, tProg = 1;
    const startPos = new THREE.Vector3(), startTarget = new THREE.Vector3(), startUp = new THREE.Vector3();
    camera.position.copy(state2D.camPos);
    camera.up.copy(state2D.up);
    controls.target.copy(state2D.camTarget);

    function setMode(m: '2D' | '3D') {
      if (mode === m) return;
      mode = m;
      controls.enabled = false;
      transitioning = true; tProg = 0;
      startPos.copy(camera.position); startTarget.copy(controls.target); startUp.copy(camera.up);
    }

    function resize() {
      const W = container!.clientWidth || 600, H = container!.clientHeight || 360;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
    }
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    let hoveredRing = -1;
    let origColor: THREE.Color | null = null;

    function applyHover(idx: number) {
      if (hoveredRing === idx) return;
      if (hoveredRing >= 0 && origColor) rings[hoveredRing].mat.color.copy(origColor);
      hoveredRing = idx;
      if (idx >= 0) {
        origColor = rings[idx].mat.color.clone();
        rings[idx].mat.color.offsetHSL(0, 0, 0.12);
      }
    }
    function clearHoverVisual() {
      if (hoveredRing >= 0 && origColor) rings[hoveredRing].mat.color.copy(origColor);
      hoveredRing = -1; origColor = null;
    }

    function onPointerMove(e: PointerEvent) {
      const rect = container!.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(hitMeshes.map((h) => h.mesh), false);
      if (hits.length) {
        const found = hitMeshes.find((h) => h.mesh === hits[0].object);
        if (found) {
          applyHover(found.ringIdx);
          const r = rings[found.ringIdx];
          setTip({ x: e.clientX - rect.left, y: e.clientY - rect.top, text: `${r.name} · ${Math.round(r.value)}` });
          onHover?.(found.ringIdx, `${r.name} · ${Math.round(r.value)}`);
          container!.style.cursor = 'pointer';
        }
      } else {
        clearHoverVisual();
        setTip(null);
        onHover?.(null, null);
        container!.style.cursor = mode === '3D' ? 'grab' : 'default';
      }
    }
    function onPointerLeave() { clearHoverVisual(); setTip(null); onHover?.(null, null); }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    let currentLift = 0;
    const tmpTarget = new THREE.Vector3();
    let raf = 0;
    const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
    const animate = () => {
      raf = requestAnimationFrame(animate);
      const target = mode === '2D' ? state2D : state3D;
      if (transitioning) {
        tProg += 0.022;
        if (tProg >= 1) { tProg = 1; transitioning = false; if (mode === '3D') controls.enabled = true; }
        const ease = easeOutCubic(tProg);
        camera.position.lerpVectors(startPos, target.camPos, ease);
        camera.up.lerpVectors(startUp, target.up, ease).normalize();
        tmpTarget.lerpVectors(startTarget, target.camTarget, ease);
        controls.target.copy(tmpTarget);
      }
      currentLift += (target.lift - currentLift) * 0.08;
      rings.forEach((r) => {
        const ud = (r.barGroup as unknown as { userData: { targetY: number } }).userData;
        const tubeY = ud.targetY * currentLift;
        r.barGroup.position.y = tubeY;
        const bud = (r.badge as unknown as { userData: { targetY: number; radius: number } }).userData;
        const labelY = 0.02 + bud.targetY * currentLift;
        // Badges anchor at -X (left of the rings): in the default 3D
        // preset this column is fully clear of the tube mass, so every
        // label is readable with no hide-behind.
        r.badge.position.set(-bud.radius, labelY, 0);
        const pos = r.stem.geometry.attributes.position.array as Float32Array;
        pos[0] = -bud.radius; pos[1] = labelY; pos[2] = 0;
        pos[3] = -bud.radius; pos[4] = tubeY; pos[5] = 0;
        r.stem.geometry.attributes.position.needsUpdate = true;
        (r.stem.material as THREE.LineBasicMaterial).opacity = currentLift * 0.6;
        // In 2D the tubes sit flat and the pills park on their ring —
        // stems fade away entirely.
        (r.badge.element as HTMLElement).style.opacity = '1';
      });
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    };
    animate();

    const dispose = () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      controls.dispose();
      renderer.dispose();
      container!.removeChild(renderer.domElement);
      container!.removeChild(labelRenderer.domElement);
    };

    api.current = { renderer, labelRenderer, scene, camera, controls, rings, labelRefs, setMode, getLift: () => currentLift, dispose };
    setMode(dim === '3d' ? '3D' : '2D');
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, palette, dark]);

  useEffect(() => { api.current?.setMode(dim === '3d' ? '3D' : '2D'); }, [dim]);

  useEffect(() => {
    const a = api.current;
    if (!a) return;
    a.rings.forEach((r, i) => {
      const active = hoverIndex === i;
      const el = r.badge.element as HTMLElement;
      el.style.boxShadow = active ? '0 4px 14px rgba(0,0,0,0.25)' : '0 2px 6px rgba(0,0,0,0.14)';
      el.style.zIndex = active ? '5' : '1';
    });
  }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(W, H, false);
      const labels = captureLabelPositions(container, a.labelRefs);
      const legend = a.rings.map((r) => ({ label: r.name, color: r.color }));
      const cv = await buildThreePNG({ title, imageDataUrl: dataUrl, chartW: W, chartH: H, labels, legend, theme, footnote: `Radial bar · ${dim === '3d' ? '3D' : '2D'} view` });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      // TRUE vector export: re-project every tube centreline through the
      // live camera, rebuild the ribbon in screen space with a glassy
      // multi-stop gradient + highlight + shadow. No raster <image>.
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      const scratch = document.createElement('canvas').getContext('2d')!;
      const proj = (v: THREE.Vector3): [number, number] => {
        const q = v.clone().project(a.camera);
        return [((q.x * 0.5 + 0.5) * W), ((-(q.y * 0.5) + 0.5) * H)];
      };
      const SEG = 72;
      let defs = `<filter id="rbsoft" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="2.5" stdDeviation="3.5" flood-color="#000000" flood-opacity="0.20"/></filter>\n`;
      let body = '';
      let seq = 0;
      const lift = a.getLift();
      a.rings.forEach((r) => {
        const curve = new ArcCurve3(r.radius, r.startA, r.endA);
        const ud = (r.barGroup as unknown as { userData: { targetY: number } }).userData;
        const tubeY = (ud.targetY || 0) * lift;
        // tube radius in px: project two points TUBE_R apart in screen space
        const c0 = curve.getPoint(0.5).add(new THREE.Vector3(0, tubeY, 0));
        const p0 = proj(c0);
        const pxPerUnit = W / (2 * Math.tan(THREE.MathUtils.degToRad(a.camera.fov / 2)) * a.camera.position.distanceTo(c0) / 1);
        const tubePx = Math.max(3, 0.12 * (pxPerUnit || 40));
        const top: string[] = []; const bot: string[] = [];
        let yMin = Infinity, yMax = -Infinity;
        for (let s = 0; s <= SEG; s++) {
          // screen-space ribbon: offset along the projected normal
          const pA = proj(curve.getPoint(Math.max(0, s / SEG - 0.004)).add(new THREE.Vector3(0, tubeY, 0)));
          const pB = proj(curve.getPoint(Math.min(1, s / SEG + 0.004)).add(new THREE.Vector3(0, tubeY, 0)));
          const pC = proj(curve.getPoint(s / SEG).add(new THREE.Vector3(0, tubeY, 0)));
          const dx = pB[0] - pA[0], dy = pB[1] - pA[1];
          const L = Math.hypot(dx, dy) || 1;
          const nx = -dy / L, ny = dx / L;
          const ax = pC[0] + nx * tubePx, ay = pC[1] + ny * tubePx;
          const bx = pC[0] - nx * tubePx, by = pC[1] - ny * tubePx;
          top.push(`${ax.toFixed(1)},${ay.toFixed(1)}`);
          bot.push(`${bx.toFixed(1)},${by.toFixed(1)}`);
          yMin = Math.min(yMin, ay, by); yMax = Math.max(yMax, ay, by);
        }
        const gid = `rbtube${seq++}`;
        defs += `        <linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="0" y1="${yMin.toFixed(1)}" x2="0" y2="${Math.max(yMin + 1, yMax).toFixed(1)}">\n` +
          `            <stop offset="0" stop-color="${adjustColor(r.color, 40)}"/>\n` +
          `            <stop offset="0.45" stop-color="${r.color}"/>\n` +
          `            <stop offset="1" stop-color="${adjustColor(r.color, -28)}"/>\n` +
          `        </linearGradient>\n`;
        const dPath = `M ${top.join(' L ')} L ${bot.reverse().join(' L ')} Z`;
        // end caps (butt joints rounded like the 3D spheres)
        const capA = top[0].split(',').map(Number);
        void capA;
        body += `        <path d="${dPath}" fill="url(#${gid})" filter="url(#rbsoft)" stroke="${adjustColor(r.color, -30)}" stroke-width="0.7" stroke-opacity="0.6" stroke-linejoin="round"/>\n`;
        body += `        <path d="M ${top.join(' L ')}" fill="none" stroke="#ffffff" stroke-width="${Math.max(1, tubePx * 0.28).toFixed(1)}" stroke-opacity="0.6" stroke-linecap="round"/>\n`;
        // leader stems in 3D (badge → tube)
        if (lift > 0.4) {
          const bud = (r.badge as unknown as { userData: { targetY: number; radius: number } }).userData;
          const bTop = proj(new THREE.Vector3(-bud.radius, 0.02 + bud.targetY * lift, 0));
          const bBot = proj(new THREE.Vector3(-bud.radius, tubeY, 0));
          body += `        <line x1="${bTop[0].toFixed(1)}" y1="${bTop[1].toFixed(1)}" x2="${bBot[0].toFixed(1)}" y2="${bBot[1].toFixed(1)}" stroke="${dark ? '#666666' : '#cccccc'}" stroke-width="1" stroke-opacity="0.6"/>\n`;
        }
      });
      // labels as panel pills at their live screen positions
      const labels = captureLabelPositions(container, a.labelRefs);
      let labelsSvg = '';
      labels.forEach((l) => {
        scratch.font = `700 11px ${theme.fontBody}`;
        const tw = scratch.measureText(l.text).width;
        const chipW = tw + 16, chipH = 19;
        labelsSvg += `        <rect x="${(l.x - chipW / 2).toFixed(1)}" y="${(l.y - chipH / 2).toFixed(1)}" width="${chipW.toFixed(1)}" height="${chipH}" rx="9.5" fill="rgba(255,255,255,0.94)" stroke="rgba(0,0,0,0.10)"/>\n`;
        labelsSvg += `        <text x="${l.x.toFixed(1)}" y="${(l.y + 0.5).toFixed(1)}" class="rb-label">${escXml(l.text)}</text>\n`;
      });
      // legend row
      let legendSvg = ''; let lx = 16; const ly = H - 14;
      a.rings.forEach((r) => {
        legendSvg += `        <rect x="${lx}" y="${ly - 9}" width="14" height="10" rx="4" fill="${r.color}"/>\n`;
        const tx = lx + 22;
        legendSvg += `        <text x="${tx}" y="${ly}" class="rb-legend">${escXml(r.name)}</text>\n`;
        scratch.font = `600 10.5px ${theme.fontBody}`;
        lx = tx + scratch.measureText(r.name).width + 20;
        if (lx > W - 60) { lx = 16; };
      });
      return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs><style>
    text { font-family: ${escXml(theme.fontBody)}; }
    .rb-title { font-family: ${escXml(theme.fontDisplay)}; font-size: 15px; font-weight: 700; fill: #1c2620; }
    .rb-legend { font-size: 10.5px; font-weight: 600; fill: #39443d; dominant-baseline: middle; }
    .rb-label { font-size: 11px; font-weight: 700; fill: ${escXml(theme.ink)}; text-anchor: middle; dominant-baseline: central; }
  </style>
${defs}  </defs>
  <rect width="100%" height="100%" fill="#ffffff"/>
  <text x="12" y="22" class="rb-title">${escXml(title)}</text>
  <g id="radial-tubes">${body}</g>
  <g id="radial-labels">${labelsSvg}</g>
  <g id="radial-legend">${legendSvg}</g>
</svg>`;
    },
  }), [data, palette, theme, dim, dark]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full">
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 max-w-[220px] px-2.5 py-1 font-body text-[11px] font-bold text-ink"
          style={{ left: Math.min(tip.x + 12, (containerRef.current?.clientWidth || 300) - 190), top: Math.max(0, tip.y - 34) }}>
          {tip.text}
        </div>
      )}
    </div>
  );
});

export default ThreeRadialBar;
