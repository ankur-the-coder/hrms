import re

path = 'src/shared/Charts.tsx'
src = open(path).read()

# 1) Fix painter's sankeyLayout call (signature no longer takes morph)
old_call = "    const lay = sankeyLayout(links, W, H, full ? 200 : Math.min(150, W * 0.22), m);"
assert src.count(old_call) == 1, f"call count: {src.count(old_call)}"
src = src.replace(old_call, "    const lay = sankeyLayout(links, W, H, full ? 200 : Math.min(150, W * 0.22));")

# 2) Replace the whole sankey render body (agon geometry + preserved hover animation)
start_marker = "    const { nodes, flows, nodeW, cols } = lay;\n    const maxCol = Math.max(1, cols - 1);"
end_marker = "  /* ============ RADIAL BAR (2D \u21c4 3D) ============ */"
si = src.index(start_marker)
ei = src.index(end_marker)
block = src[si:ei]
assert "ribbonOrder" in block and "skDepth" in block, "unexpected sankey block"

new_body = '''    const { nodes, flows, nodeW, cols } = lay;
    const maxCol = Math.max(1, cols - 1);
    const ox = 7 * m, oy = 5 * m; // 3D isometric extrusion offset (agon geometry)

    // Sequential left-to-right sweep:
    // 1. Flow ribbons sweep outward from left to right along their path vectors
    // 2. Nodes materialize per column with a 3D cuboid extrusion
    // Hover animation (preserved from this project): hovering a node highlights
    // its connected flows; hovering a ribbon highlights that flow + endpoints.
    // hov.amt eases 0->1 so every highlight / dim / widen transition is smooth.
    const activeFlow = hov.seg?.c === -2 ? hov.seg.s : null;
    const focused = hov.idx !== null || activeFlow !== null;
    const isActive = (f: SkFlow, i: number) => activeFlow === i || hov.idx === f.si || hov.idx === f.ti;
    flows.forEach((f, i) => {
      const src = nodes[f.si], tgt = nodes[f.ti];
      const isConnected = isActive(f, i);
      const isDimmed = focused && !isConnected;
      const x0 = src.x + nodeW, x1 = tgt.x;
      const c1 = x0 + (x1 - x0) * 0.5, c2 = x1 - (x1 - x0) * 0.5;
      // Hover emphasis: the active ribbon gently widens (spread eases with hov.amt)
      const spread = 5 * (isConnected ? hov.amt : 0);
      const yA0 = f.sy0 - spread, yA1 = f.sy1 + spread, yB0 = f.ty0 - spread, yB1 = f.ty1 + spread;

      // Sequential progress: left ribbons begin early, right ribbons follow
      const pStart = 0.12 + (src.col / maxCol) * 0.45;
      const pEnd = Math.min(1, pStart + 0.38);
      const fp = clamp01((p - pStart) / (pEnd - pStart));
      if (fp <= 0.001) return;

      // Agon alpha targets (0.75 connected / 0.12 dimmed / 0.45 idle), eased by hov.amt
      const alpha = !focused ? 0.45 : isConnected ? lerp(0.45, 0.75, hov.amt) : lerp(0.45, 0.12, hov.amt);
      const grad = ctx.createLinearGradient(x0, 0, x1, 0);
      grad.addColorStop(0, rgba(src.color, alpha));
      grad.addColorStop(1, rgba(tgt.color, alpha));

      ctx.save();
      // Sweep outward along path vectors
      if (fp < 0.999) {
        const sweepX = x0 + (x1 - x0) * fp;
        ctx.beginPath();
        ctx.rect(0, 0, sweepX, H);
        ctx.clip();
      }

      // 3D Depth Shadow ribbon underneath in 3D mode
      if (m > 0.05) {
        ctx.fillStyle = rgba(t.ink, (isConnected ? 0.22 : 0.08) * m);
        ctx.beginPath();
        ctx.moveTo(x0, yA0 + oy);
        ctx.bezierCurveTo(c1, yA0 + oy, c2, yB0 + oy, x1, yB0 + oy);
        ctx.lineTo(x1, yB1 + oy);
        ctx.bezierCurveTo(c2, yB1 + oy, c1, yA1 + oy, x0, yA1 + oy);
        ctx.closePath();
        ctx.fill();
      }

      // Main flow ribbon
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(x0, yA0);
      ctx.bezierCurveTo(c1, yA0, c2, yB0, x1, yB0);
      ctx.lineTo(x1, yB1);
      ctx.bezierCurveTo(c2, yB1, c1, yA1, x0, yA1);
      ctx.closePath();
      ctx.fill();

      // Top edge highlight in 3D mode or on hover (hover easing preserved)
      if (isConnected || m > 0.1) {
        ctx.strokeStyle = isConnected ? rgba('#ffffff', lerp(0.35, 1, hov.amt)) : 'rgba(255,255,255,0.35)';
        ctx.lineWidth = isConnected ? lerp(0.8, 1.5, hov.amt) : 0.8;
        ctx.beginPath();
        ctx.moveTo(x0, yA0);
        ctx.bezierCurveTo(c1, yA0, c2, yB0, x1, yB0);
        ctx.stroke();
      }

      ctx.restore();
    });

    // Draw nodes sequentially from left to right with 3D cuboid depth
    nodes.forEach((n, i) => {
      const colP = n.col / maxCol;
      const np = clamp01((p - colP * 0.22) / 0.32);
      if (np <= 0.001) return;
      const on = hov.idx === i || (activeFlow !== null && (flows[activeFlow]?.si === i || flows[activeFlow]?.ti === i));
      const expansion = on ? 2 * hov.amt : 0;
      const col = on ? shade(n.color, 1 + 0.18 * hov.amt) : n.color;
      const nh = Math.max(2, n.h * np);
      const ny = n.y + (n.h - nh) / 2;
      const nx = n.x - expansion, nw = nodeW + expansion * 2;

      // 3D Cuboid extrusion in 3D mode
      if (m > 0.05) {
        // Top cap
        ctx.fillStyle = shade(col, 1.28);
        ctx.beginPath();
        ctx.moveTo(nx, ny);
        ctx.lineTo(nx + ox, ny - oy);
        ctx.lineTo(nx + nw + ox, ny - oy);
        ctx.lineTo(nx + nw, ny);
        ctx.closePath();
        ctx.fill();

        // Right side shadow face
        ctx.fillStyle = shade(col, 0.72);
        ctx.beginPath();
        ctx.moveTo(nx + nw, ny);
        ctx.lineTo(nx + nw + ox, ny - oy);
        ctx.lineTo(nx + nw + ox, ny + nh - oy);
        ctx.lineTo(nx + nw, ny + nh);
        ctx.closePath();
        ctx.fill();
      }

      // Front node face
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.roundRect(nx, ny, nw, nh, m > 0.05 ? 0 : 3);
      ctx.fill();

      // Hover glow border (eased with hov.amt)
      if (on && hov.amt > 0.01) {
        ctx.strokeStyle = rgba('#ffffff', hov.amt);
        ctx.lineWidth = 1.6;
        ctx.stroke();
      }

      // Labels appear as node materializes
      if (np > 0.65) {
        const lx = n.x + nodeW + 8 + (m > 0.05 ? ox : 0);
        ctx.textAlign = 'left';
        const avail = n.col < lay.cols - 1 ? (lay.colX[n.col + 1] ?? W) - lx - 10 : W - lx - 6;
        const one = `${n.name} \\u00b7 ${fmtNum(n.value)}`;
        ctx.font = font(t, 600, 11);
        if (full || measureW(ctx, one) <= avail) {
          ctx.fillStyle = on ? t.ink : shade(t.ink, 0.9);
          ctx.fillText(one, lx, n.y + n.h / 2 + 3.5);
        } else {
          ctx.fillStyle = on ? t.ink : shade(t.ink, 0.9);
          ctx.fillText(fitCtx(ctx, n.name, Math.max(30, avail)), lx, n.y + n.h / 2 - 2);
          ctx.font = font(t, 600, 9.5);
          ctx.fillStyle = t.axis;
          ctx.fillText(fmtNum(n.value), lx, n.y + n.h / 2 + 9);
        }
      }
    });
    ctx.textAlign = 'left';
    return;
  }

'''
src = src[:si] + new_body + src[ei:]
open(path, 'w').write(src)
print("sankey block replaced OK")
