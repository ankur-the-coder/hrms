from playwright.sync_api import sync_playwright

with sync_playwright() as pw:
    b = pw.chromium.launch()
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    errors = []
    pg.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: errors.append(str(e)))
    pg.goto('http://127.0.0.1:5199/sankey-verify', wait_until='domcontentloaded', timeout=60000)
    pg.wait_for_function('window.__sankeyReady === true', timeout=20000)
    pg.wait_for_timeout(600)
    el = pg.locator('canvas').first
    el.screenshot(path='./tmpview4/sankey_check.png')
    print('CONSOLE ERRORS:', errors if errors else 'none')
    b.close()
print('capture done')
