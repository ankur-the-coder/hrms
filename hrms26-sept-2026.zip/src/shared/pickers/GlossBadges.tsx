import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

/** Transparent, event-free WebGL layer aligned to the calendar's DOM badges. */
export default function GlossBadges() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const host = canvas?.parentElement;
    if (!canvas || !host) return;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true }); }
    catch { return; }
    host.classList.add('has-webgl-gloss');
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const env = pmrem.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = env.texture;
    const camera = new THREE.OrthographicCamera(0, 1, 0, -1, 1, 1000);
    camera.position.z = 500;
    const key = new THREE.DirectionalLight(0xfff4ea, 2);
    const shine = new THREE.DirectionalLight(0xffffff, 1.1);
    scene.add(key, shine, new THREE.AmbientLight(0xffffff, 0.75));
    const material = new THREE.MeshPhysicalMaterial({ color: 0xff5535, roughness: 0.18, metalness: 0, clearcoat: 1, clearcoatRoughness: 0.04, envMapIntensity: 1.3 });
    const group = new THREE.Group();
    scene.add(group);
    let frame = 0;
    const draw = () => {
      const bounds = host.getBoundingClientRect();
      if (!bounds.width || !bounds.height) return;
      renderer.setSize(bounds.width, bounds.height, false);
      camera.right = bounds.width;
      camera.bottom = -bounds.height;
      camera.updateProjectionMatrix();
      key.position.set(bounds.width / 2 - 150, 150, 300);
      shine.position.set(bounds.width / 2 + 100, 20, 200);
      group.children.forEach(child => { if (child instanceof THREE.Mesh) child.geometry.dispose(); });
      group.clear();
      host.querySelectorAll('.cal-badge').forEach(el => {
        const r = el.getBoundingClientRect();
        const radius = Math.min(r.width, r.height) / 2;
        const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, 32, 24), material);
        mesh.scale.z = 0.6;
        mesh.position.set((r.left + r.right) / 2 - bounds.left, -((r.top + r.bottom) / 2 - bounds.top), 2);
        group.add(mesh);
      });
      renderer.render(scene, camera);
    };
    const schedule = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(draw); };
    const observer = new MutationObserver(schedule);
    observer.observe(host, { subtree: true, childList: true, attributes: true, attributeFilter: ['class'] });
    const resize = new ResizeObserver(schedule);
    resize.observe(host);
    const onPointer = (e: PointerEvent) => {
      const r = host.getBoundingClientRect();
      shine.position.set(e.clientX - r.left, -(e.clientY - r.top), 250);
      renderer.render(scene, camera);
    };
    host.addEventListener('pointermove', onPointer);
    schedule();
    return () => {
      observer.disconnect(); resize.disconnect(); cancelAnimationFrame(frame);
      host.removeEventListener('pointermove', onPointer);
      host.classList.remove('has-webgl-gloss');
      group.children.forEach(child => { if (child instanceof THREE.Mesh) child.geometry.dispose(); });
      material.dispose(); env.texture.dispose(); pmrem.dispose(); renderer.dispose();
    };
  }, []);
  return <canvas ref={canvasRef} className="picker-gloss-canvas" aria-hidden="true" />;
}
