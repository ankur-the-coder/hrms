import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Minus } from 'lucide-react';
import type { ThreeChartHandle } from '../three/ThreeSankey3D';
import type { ExportTheme } from '../three/exportUtils';

/* ============================================================
   Neumorphic Org Chart — a faithful rebuild of the supplied reference
   (orgchart.png): soft raised white cards with a dummy grey profile
   avatar, a domed root card, coloured name-pill cards for direct reports
   (alternating blue / green) and horizontal name+avatar cards for leaves,
   joined by thin grey curved connectors with small junction dots.
   Renders as pure SVG so it exports crisply and stays sharp at any zoom.

   Interaction, modelled on ApexTree (apexcharts.com/apextree):
   - a small −/+ button sits at the bottom edge of every node that has
     subordinates; clicking it collapses the subtree.
   - when collapsed the button becomes a pill showing the total hidden
     subordinate count (ApexTree's collapse-count badge).
   - collapse / expand uses a spring with a per-sibling "wave" stagger:
     children grow out of / retract into their parent, surviving nodes
     spring to their new slots, and the connecting edges draw / undraw
     (pathLength) so a connector never detaches from a node.
   - the app's 2D / 3D toggle drives two views: 2D = zoomed-out overview
     (whole tree fits), 3D = zoomed-in detail (root pinned near the top).
   ============================================================ */

export interface OrgLink { source: string; target: string; value?: number }

interface Props {
  links: OrgLink[];
  palette: string[];
  dim: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (idx: number | null, name: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

/* Card geometry (per the reference proportions). */
const CARD_W = 156;     // root / mid card width
const LEAF_W = 188;     // leaf (horizontal) card width
const COL_W = 210;      // horizontal slot per leaf
const ROW_H = 182;      // vertical distance between tiers
const AV_R = 22;        // avatar radius

/** Per-depth card vertical extent (top/bottom offsets from node centre),
 * used for connector attachment and layout bounds. */
const boxTop = (d: number) => (d === 0 ? -62 : d === 1 ? -58 : -30);
const boxBot = (d: number) => (d === 0 ? 40 : d === 1 ? 44 : 30);
const halfW = (d: number) => (d >= 2 ? LEAF_W / 2 : CARD_W / 2);

/** Alternating name-pill colours for direct reports (reference: blue / green). */
const PILL_BLUE = { a: '#6bb0dd', b: '#4f97cb' };
const PILL_GREEN = { a: '#79cda6', b: '#5cb08a' };
const pillOf = (i: number) => (i % 2 === 0 ? PILL_BLUE : PILL_GREEN);

/** Deterministic real-face photo per person. randomuser.me serves fixed,
 * reliably-hotlinkable portraits at /api/portraits/{men|women}/{0-99}.jpg —
 * keyed by a stable hash of the name so each employee keeps the same face
 * across renders. A grey silhouette is drawn underneath as the fallback. */
function hashSeed(s: string): number {
  let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h;
}
const faceUrl = (seed: string) => {
  const h = hashSeed(seed);
  const gender = h % 2 === 0 ? 'men' : 'women';
  const n = (Math.floor(h / 2)) % 100;
  return `https://randomuser.me/api/portraits/${gender}/${n}.jpg`;
};

/** Profile avatar — a real face photo (URL) clipped to a glossy disc, over a
 * grey silhouette fallback, matching the datepicker's glossy neu language. */
function Avatar({ cx, cy, r, dark, id, seed }: { cx: number; cy: number; r: number; dark?: boolean; id: string; seed?: string }) {
  const disc = dark ? '#3a4351' : '#e7ecf3';
  const fig = dark ? '#8795a6' : '#9aa7b8';
  return (
    <g transform={`translate(${cx} ${cy})`}>
      <circle r={r} fill={disc} filter="url(#btnSh)" />
      <clipPath id={id}><circle r={r} /></clipPath>
      <g clipPath={`url(#${id})`}>
        {/* silhouette fallback (shows until/if the photo fails) */}
        <circle cy={-r * 0.18} r={r * 0.34} fill={fig} />
        <ellipse cy={r * 0.66} rx={r * 0.6} ry={r * 0.5} fill={fig} />
        {seed && (
          <image href={faceUrl(seed)} x={-r} y={-r} width={r * 2} height={r * 2}
            preserveAspectRatio="xMidYMid slice" crossOrigin="anonymous" />
        )}
        {/* glossy top sheen */}
        <ellipse cx={-r * 0.2} cy={-r * 0.5} rx={r * 0.7} ry={r * 0.42} fill="rgba(255,255,255,0.28)" />
      </g>
      <circle r={r} fill="none" stroke={dark ? 'rgba(255,255,255,0.14)' : 'rgba(255,255,255,0.9)'} strokeWidth={1.6} />
    </g>
  );
}

interface ONode {
  name: string; x: number; y: number; depth: number;
  directCount: number; descCount: number; idx: number;
  parentName: string | null; parentX: number; parentY: number;
}

/** Build tree + tidy layout honouring the collapsed set. */
function layout(links: OrgLink[], collapsed: Set<string>) {
  const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
  const parentOf = new Map<string, string>();
  const childrenOf = new Map<string, string[]>();
  for (const l of links) {
    parentOf.set(l.target, l.source);
    if (!childrenOf.has(l.source)) childrenOf.set(l.source, []);
    childrenOf.get(l.source)!.push(l.target);
  }
  const root = names.find((n) => !parentOf.has(n)) || names[0];
  const idxOf = new Map<string, number>();
  names.forEach((n, i) => idxOf.set(n, i));

  // total subordinate count (all descendants) — used for the collapse badge
  const descCache = new Map<string, number>();
  const descCount = (n: string): number => {
    if (descCache.has(n)) return descCache.get(n)!;
    const kids = childrenOf.get(n) || [];
    let c = kids.length;
    for (const k of kids) c += descCount(k);
    descCache.set(n, c);
    return c;
  };

  const nodes: ONode[] = [];
  const byName = new Map<string, ONode>();
  let cursor = 0;
  const place = (name: string, depth: number, parentName: string | null): number => {
    const kids = collapsed.has(name) ? [] : (childrenOf.get(name) || []);
    let x: number;
    if (!kids.length) { x = cursor * COL_W; cursor += 1; }
    else {
      const xs = kids.map((k) => place(k, depth + 1, name));
      x = (Math.min(...xs) + Math.max(...xs)) / 2;
    }
    const node: ONode = {
      name, x, y: depth * ROW_H, depth,
      directCount: (childrenOf.get(name) || []).length,
      descCount: descCount(name),
      idx: idxOf.get(name) ?? 0,
      parentName, parentX: 0, parentY: 0,
    };
    nodes.push(node); byName.set(name, node);
    return x;
  };
  if (root) place(root, 0, null);
  // resolve parent positions (for grow-out-of-parent animation)
  for (const n of nodes) {
    const p = n.parentName ? byName.get(n.parentName) : null;
    n.parentX = p ? p.x : n.x; n.parentY = p ? p.y : n.y;
  }
  const edges = nodes
    .filter((n) => n.parentName && byName.has(n.parentName))
    .map((n) => ({ from: byName.get(n.parentName!)!, to: n, key: `${n.parentName}->${n.name}` }));

  const bounds = {
    minX: Math.min(...nodes.map((n) => n.x - halfW(n.depth))) - 24,
    maxX: Math.max(...nodes.map((n) => n.x + halfW(n.depth))) + 24,
    minY: Math.min(...nodes.map((n) => n.y + boxTop(n.depth))) - 16,
    maxY: Math.max(...nodes.map((n) => n.y + boxBot(n.depth))) + 34,
  };
  return { nodes, edges, bounds, root };
}

const easeInOutCubic = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

const OrgChartNeu = forwardRef<ThreeChartHandle, Props>(function OrgChartNeu(
  { links, dim, hoverIndex, onHover, theme, dark }, ref,
) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const viewGRef = useRef<SVGGElement>(null);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [size, setSize] = useState({ w: 800, h: 520 });
  const [hovered, setHovered] = useState<number | null>(null);
  const [zoomOn, setZoomOn] = useState(false);

  const ink = dark ? '#e8eef6' : '#334155';
  const muted = dark ? '#8ea0b5' : '#94a3b8';
  const line = dark ? '#8793a4' : '#716a62';

  const { nodes, edges, bounds } = useMemo(() => layout(links, collapsed), [links, collapsed]);

  /* ---- imperative view transform (pan / zoom / 2D-3D), no React churn ---- */
  const viewRef = useRef({ tx: 0, ty: 0, s: 1 });
  const rafRef = useRef(0);
  const applyView = useCallback(() => {
    const v = viewRef.current;
    viewGRef.current?.setAttribute('transform', `translate(${v.tx} ${v.ty}) scale(${v.s})`);
  }, []);
  const fitTarget = useCallback((mode: '2d' | '3d') => {
    const W = size.w, H = size.h;
    const worldW = Math.max(1, bounds.maxX - bounds.minX);
    const worldH = Math.max(1, bounds.maxY - bounds.minY);
    // OFF-SCREEN FIX: always fit the ENTIRE current tree inside the tile so a
    // branch opening/closing can never push the head employee's subordinates
    // out of view. Both modes clamp to the fit scale; 3D just uses a tighter
    // pad (slightly larger, top-aligned "detail") and 2D a wider pad (centred
    // "overview"). Because s is derived from the LIVE bounds — which include
    // every currently-expanded node — the reframe on each toggle keeps
    // everything on screen.
    const pad = mode === '3d' ? 72 : 96;
    // 0.94 safety factor leaves slack for framer-motion spring overshoot so a
    // node settling into place never briefly crosses the tile edge.
    const s = Math.min((W - pad) / worldW, (H - pad) / worldH) * 0.94;
    const cx = (bounds.minX + bounds.maxX) / 2;
    // 3D: pin the root near the top; 2D: centre vertically. Both fully fit.
    const topY = mode === '3d' ? 40 : Math.max(28, (H - worldH * s) / 2);
    return { tx: W / 2 - cx * s, ty: topY - bounds.minY * s, s };
  }, [size, bounds]);
  const tweenView = useCallback((mode: '2d' | '3d', dur = 700) => {
    cancelAnimationFrame(rafRef.current);
    const from = { ...viewRef.current };
    const to = fitTarget(mode);
    // first mount: snap
    if (!from.s || (from.tx === 0 && from.ty === 0 && from.s === 1)) {
      viewRef.current = to; applyView(); return;
    }
    // OFF-SCREEN FIX: interpolate the SCALE about a stable world-centre anchor
    // instead of lerping tx/ty independently. Lerping translate + scale
    // separately makes the content swing in an arc (it can leave the frame
    // mid-tween when a big subtree collapses and the zoom jumps). By keeping
    // the tree's world centre pinned to a smoothly-moving screen point while
    // the scale eases, the graph zooms about that anchor and never flies out.
    const cx = (bounds.minX + bounds.maxX) / 2;
    const cy = (bounds.minY + bounds.maxY) / 2;
    const fromScreen = { x: from.tx + cx * from.s, y: from.ty + cy * from.s };
    const toScreen = { x: to.tx + cx * to.s, y: to.ty + cy * to.s };
    const t0 = performance.now();
    const tick = (now: number) => {
      const e = easeInOutCubic(Math.min(1, (now - t0) / dur));
      const s = from.s + (to.s - from.s) * e;
      const sx = fromScreen.x + (toScreen.x - fromScreen.x) * e;
      const sy = fromScreen.y + (toScreen.y - fromScreen.y) * e;
      viewRef.current = { s, tx: sx - cx * s, ty: sy - cy * s };
      applyView();
      if (e < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
  }, [fitTarget, applyView, bounds]);

  // container size
  useEffect(() => {
    const el = wrapRef.current; if (!el) return;
    const ro = new ResizeObserver(() => {
      const w = el.clientWidth || 800, h = el.clientHeight || 520;
      setSize({ w, h });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // reframe on dim / data / collapse / size change
  useEffect(() => { tweenView(dim); /* eslint-disable-next-line */ }, [dim, size.w, size.h, bounds.minX, bounds.maxX, bounds.minY, bounds.maxY]);

  useEffect(() => { setHovered(hoverIndex ?? null); }, [hoverIndex]);

  /* ---- pan (drag) + wheel-zoom (when toggled on) ---- */
  useEffect(() => {
    const el = wrapRef.current; if (!el) return;
    let dragging = false, lx = 0, ly = 0, moved = false;
    const down = (e: PointerEvent) => {
      if ((e.target as HTMLElement).closest('[data-collapse-btn]')) return;
      dragging = true; moved = false; lx = e.clientX; ly = e.clientY;
      el.setPointerCapture?.(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      const dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY;
      if (Math.abs(dx) + Math.abs(dy) > 2) moved = true;
      cancelAnimationFrame(rafRef.current);
      viewRef.current.tx += dx; viewRef.current.ty += dy; applyView();
      el.style.cursor = 'grabbing';
    };
    const up = () => { dragging = false; el.style.cursor = 'grab'; void moved; };
    const wheel = (e: WheelEvent) => {
      if (!zoomOn) return;
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const mx = e.clientX - rect.left, my = e.clientY - rect.top;
      const v = viewRef.current;
      const f = e.deltaY < 0 ? 1.1 : 1 / 1.1;
      const ns = Math.max(0.15, Math.min(6, v.s * f));
      // zoom toward cursor
      v.tx = mx - (mx - v.tx) * (ns / v.s);
      v.ty = my - (my - v.ty) * (ns / v.s);
      v.s = ns; cancelAnimationFrame(rafRef.current); applyView();
    };
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointerleave', up);
    el.addEventListener('wheel', wheel, { passive: false });
    return () => {
      el.removeEventListener('pointerdown', down);
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
      el.removeEventListener('pointerleave', up);
      el.removeEventListener('wheel', wheel);
    };
  }, [zoomOn, applyView]);

  const toggle = useCallback((name: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name); else next.add(name);
      return next;
    });
  }, []);

  // sibling index for wave-stagger (children of same parent)
  const siblingOrder = useMemo(() => {
    const m = new Map<string, number>();
    const perParent = new Map<string, number>();
    for (const n of nodes) {
      const p = n.parentName || '__root';
      const k = perParent.get(p) || 0;
      m.set(n.name, k); perParent.set(p, k + 1);
    }
    return m;
  }, [nodes]);

  const fillId = dark ? 'neuFillD' : 'neuFillL';
  const shadowId = dark ? 'neuShD' : 'neuShL';

  // Smooth S-curve connector from parent's bottom edge to child's top edge,
  // exactly the soft curved links in the reference. Endpoints sit on the
  // card edges (via boxBot/boxTop) so the line never detaches on collapse.
  const edgePath = (fromDepth: number, fx: number, fy: number, toDepth: number, tx: number, ty: number) => {
    const py = fy + boxBot(fromDepth);
    const cy = ty + boxTop(toDepth);
    const midY = (py + cy) / 2;
    return `M ${fx} ${py} C ${fx} ${midY}, ${tx} ${midY}, ${tx} ${cy}`;
  };

  const serializeSVG = useCallback((title: string): { svg: string; w: number; h: number } => {
    const src = svgRef.current!;
    const clone = src.cloneNode(true) as SVGSVGElement;
    const W = size.w, H = size.h + (title ? 40 : 0);
    clone.setAttribute('width', String(W));
    clone.setAttribute('height', String(H));
    clone.setAttribute('viewBox', `0 0 ${size.w} ${H}`);
    const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    bg.setAttribute('width', String(size.w)); bg.setAttribute('height', String(H));
    bg.setAttribute('fill', dark ? '#1b222b' : '#ffffff');
    clone.insertBefore(bg, clone.firstChild);
    if (title) {
      const t = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      t.setAttribute('x', '16'); t.setAttribute('y', '26');
      t.setAttribute('font-family', theme.fontDisplay);
      t.setAttribute('font-weight', '700'); t.setAttribute('font-size', '15');
      t.setAttribute('fill', dark ? '#e8eef6' : '#1c2620');
      t.textContent = title;
      clone.appendChild(t);
      const g = clone.querySelector('g');
      if (g) g.setAttribute('transform', `translate(0 40) ${g.getAttribute('transform') || ''}`);
    }
    return { svg: new XMLSerializer().serializeToString(clone), w: W, h: H };
  }, [size, dark, theme]);

  useImperativeHandle(ref, () => ({
    exportSVG: async (title: string) => serializeSVG(title).svg,
    exportPNG: async (title: string) => {
      const { svg, w, h } = serializeSVG(title);
      const blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      try {
        const img = await new Promise<HTMLImageElement>((res, rej) => {
          const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = url;
        });
        const scale = 2;
        const cv = document.createElement('canvas');
        cv.width = w * scale; cv.height = h * scale;
        const ctx = cv.getContext('2d')!;
        ctx.fillStyle = dark ? '#1b222b' : '#ffffff';
        ctx.fillRect(0, 0, cv.width, cv.height);
        ctx.drawImage(img, 0, 0, cv.width, cv.height);
        return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
      } finally {
        URL.revokeObjectURL(url);
      }
    },
    setZoom: (on: boolean) => setZoomOn(on),
  }), [serializeSVG, dark]);

  return (
    <div ref={wrapRef} className="absolute inset-0 h-full w-full overflow-hidden" style={{ cursor: 'grab', touchAction: 'none' }}>
      <svg ref={svgRef} width="100%" height="100%" viewBox={`0 0 ${size.w} ${size.h}`} style={{ display: 'block' }}>
        <defs>
          <radialGradient id="neuFillL" cx="38%" cy="32%" r="75%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="65%" stopColor="#f2f5fa" />
            <stop offset="100%" stopColor="#dfe6f0" />
          </radialGradient>
          <radialGradient id="neuFillD" cx="38%" cy="32%" r="75%">
            <stop offset="0%" stopColor="#404b59" />
            <stop offset="70%" stopColor="#333c48" />
            <stop offset="100%" stopColor="#252c36" />
          </radialGradient>
          <filter id="neuShL" x="-60%" y="-60%" width="220%" height="220%">
            <feDropShadow dx="5" dy="7" stdDeviation="6" floodColor="#aab6c6" floodOpacity="0.6" />
            <feDropShadow dx="-4" dy="-5" stdDeviation="5" floodColor="#ffffff" floodOpacity="0.85" />
          </filter>
          <filter id="neuShD" x="-60%" y="-60%" width="220%" height="220%">
            <feDropShadow dx="5" dy="7" stdDeviation="7" floodColor="#141922" floodOpacity="0.7" />
            <feDropShadow dx="-4" dy="-5" stdDeviation="5" floodColor="#4b596b" floodOpacity="0.35" />
          </filter>
          <filter id="btnSh" x="-80%" y="-80%" width="260%" height="260%">
            <feDropShadow dx="0" dy="2" stdDeviation="2.5" floodColor={dark ? '#0d1117' : '#9aa7b8'} floodOpacity="0.55" />
          </filter>
        </defs>

        <g ref={viewGRef}>
          {/* edges */}
          <g fill="none">
            <AnimatePresence>
              {edges.map((e) => (
                <motion.g key={e.key}
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  transition={{ duration: 0.35 }}>
                  <motion.path
                    d={edgePath(e.from.depth, e.from.x, e.from.y, e.to.depth, e.to.x, e.to.y)}
                    stroke={line} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1, d: edgePath(e.from.depth, e.from.x, e.from.y, e.to.depth, e.to.x, e.to.y) }}
                    exit={{ pathLength: 0 }}
                    transition={{ type: 'spring', stiffness: 190, damping: 26 }}
                  />
                  {/* junction dots at both card edges */}
                  <motion.circle r={3.2} fill={line}
                    initial={{ opacity: 0 }} animate={{ opacity: 1, cx: e.from.x, cy: e.from.y + boxBot(e.from.depth) }} exit={{ opacity: 0 }}
                    transition={{ type: 'spring', stiffness: 190, damping: 26 }} />
                  <motion.circle r={3.2} fill={line}
                    initial={{ opacity: 0 }} animate={{ opacity: 1, cx: e.to.x, cy: e.to.y + boxTop(e.to.depth) }} exit={{ opacity: 0 }}
                    transition={{ type: 'spring', stiffness: 190, damping: 26 }} />
                </motion.g>
              ))}
            </AnimatePresence>
          </g>

          {/* nodes */}
          <AnimatePresence>
            {nodes.map((n) => {
              // Label may carry "Name|Position"; otherwise the label is the
              // name and a position is synthesised from the tier depth.
              const [rawName, rawPos] = n.name.split('|');
              const nm = (rawName || n.name).trim();
              const pos = (rawPos || (n.depth === 0 ? 'Chief Executive' : n.depth === 1 ? 'Vice President' : n.depth === 2 ? 'Director' : 'Team Member')).trim();
              const isCol = collapsed.has(n.name);
              const active = hovered === n.idx;
              const wave = (siblingOrder.get(n.name) || 0) * 0.05;
              const btnY = n.y + boxBot(n.depth);
              const pill = pillOf(siblingOrder.get(n.name) || 0);
              const clipId = `av${n.idx}`;
              return (
                <motion.g key={n.name}
                  style={{ cursor: 'default' }}
                  initial={{ x: n.parentX, y: n.parentY, scale: 0.2, opacity: 0 }}
                  animate={{ x: n.x, y: n.y, scale: active ? 1.04 : 1, opacity: 1 }}
                  exit={{ x: n.parentX, y: n.parentY, scale: 0.2, opacity: 0 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 30, delay: wave }}
                  onMouseEnter={() => { setHovered(n.idx); onHover?.(n.idx, nm); }}
                  onMouseLeave={() => { setHovered(null); onHover?.(null, null); }}
                >
                  {n.depth === 0 ? (
                    /* ---- ROOT: domed card, avatar in the arch, name + position ---- */
                    <>
                      <path
                        d={`M ${-CARD_W / 2} 40 L ${-CARD_W / 2} -18 A ${CARD_W / 2} ${CARD_W / 2 + 8} 0 0 1 ${CARD_W / 2} -18 L ${CARD_W / 2} 40 Q ${CARD_W / 2} 48 ${CARD_W / 2 - 8} 48 L ${-CARD_W / 2 + 8} 48 Q ${-CARD_W / 2} 48 ${-CARD_W / 2} 40 Z`}
                        fill={`url(#${fillId})`} filter={`url(#${shadowId})`} />
                      {/* glossy top sheen */}
                      <ellipse cx={0} cy={-42} rx={CARD_W / 2 - 10} ry={22} fill="rgba(255,255,255,0.30)" />
                      <Avatar cx={0} cy={-30} r={AV_R} dark={dark} id={clipId} seed={nm} />
                      <text y={12} textAnchor="middle" fontFamily={theme.fontBody} fontWeight={800} fontSize={12.5} letterSpacing={0.4} fill={ink}>{nm}</text>
                      <text y={30} textAnchor="middle" fontFamily={theme.fontBody} fontWeight={600} fontSize={8.5} letterSpacing={1.2} fill={muted}>{pos.toUpperCase()}</text>
                    </>
                  ) : n.depth === 1 ? (
                    /* ---- DIRECT REPORT: card, top avatar, coloured name-pill ---- */
                    <>
                      <rect x={-CARD_W / 2} y={-38} width={CARD_W} height={82} rx={16}
                        fill={`url(#${fillId})`} filter={`url(#${shadowId})`} />
                      {/* glossy top sheen */}
                      <rect x={-CARD_W / 2 + 3} y={-36} width={CARD_W - 6} height={30} rx={14} fill="rgba(255,255,255,0.24)" />
                      <Avatar cx={0} cy={-34} r={AV_R} dark={dark} id={clipId} seed={nm} />
                      <defs>
                        <linearGradient id={`pg${n.idx}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={pill.a} />
                          <stop offset="100%" stopColor={pill.b} />
                        </linearGradient>
                      </defs>
                      <rect x={-CARD_W / 2 + 12} y={-4} width={CARD_W - 24} height={26} rx={13}
                        fill={`url(#pg${n.idx})`} filter="url(#btnSh)" />
                      {/* glossy gel highlight on the accent pill (datepicker language) */}
                      <rect x={-CARD_W / 2 + 16} y={-2} width={CARD_W - 32} height={11} rx={6} fill="rgba(255,255,255,0.38)" />
                      <text y={13} textAnchor="middle" fontFamily={theme.fontBody} fontWeight={800} fontSize={11.5} letterSpacing={0.4} fill="#ffffff">{nm}</text>
                      <text y={36} textAnchor="middle" fontFamily={theme.fontBody} fontWeight={600} fontSize={8.5} letterSpacing={1.1} fill={muted}>{pos.toUpperCase()}</text>
                    </>
                  ) : (
                    /* ---- LEAF: horizontal card, name+position left, avatar right ---- */
                    <>
                      <rect x={-LEAF_W / 2} y={-26} width={LEAF_W} height={52} rx={14}
                        fill={`url(#${fillId})`} filter={`url(#${shadowId})`} />
                      {/* glossy top sheen */}
                      <rect x={-LEAF_W / 2 + 3} y={-24} width={LEAF_W - 6} height={20} rx={12} fill="rgba(255,255,255,0.22)" />
                      <text x={-LEAF_W / 2 + 18} y={-2} textAnchor="start" fontFamily={theme.fontBody} fontWeight={800} fontSize={11.5} fill={ink}>{nm}</text>
                      <text x={-LEAF_W / 2 + 18} y={13} textAnchor="start" fontFamily={theme.fontBody} fontWeight={600} fontSize={8} letterSpacing={1} fill={muted}>{pos.toUpperCase()}</text>
                      <Avatar cx={LEAF_W / 2 - 26} cy={0} r={18} dark={dark} id={clipId} seed={nm} />
                    </>
                  )}

                  {/* collapse / expand control (only when there are subordinates) */}
                  {n.directCount > 0 && (
                    <g data-collapse-btn transform={`translate(0 ${btnY - n.y})`}
                      style={{ cursor: 'pointer' }}
                      onClick={(ev) => { ev.stopPropagation(); toggle(n.name); }}>
                      <circle r={isCol ? 16 : 13} fill={dark ? '#242b34' : '#eef2f8'} />
                      {isCol ? (
                        <>
                          {/* collapsed → count pill (+N) */}
                          <rect x={-(n.descCount >= 10 ? 22 : 18)} y={-11}
                            width={(n.descCount >= 10 ? 44 : 36)} height={22} rx={11}
                            fill={pill.b} filter="url(#btnSh)" />
                          <text y={4.5} textAnchor="middle" fontFamily={theme.fontBody}
                            fontWeight={800} fontSize={11} fill="#ffffff">+{n.descCount}</text>
                        </>
                      ) : (
                        <>
                          <circle r={11} fill={dark ? '#2f3742' : '#ffffff'} stroke={line} strokeWidth={1.4} filter="url(#btnSh)" />
                          <Minus x={-7} y={-7} width={14} height={14} color={pill.b} strokeWidth={2.6} />
                        </>
                      )}
                    </g>
                  )}
                </motion.g>
              );
            })}
          </AnimatePresence>
        </g>
      </svg>

      {/* scroll-zoom toggle — same convention as the Three.js charts */}
      <button
        onClick={(e) => { e.stopPropagation(); setZoomOn((z) => !z); }}
        className={`absolute left-2 top-2 z-10 rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${zoomOn ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
        title={zoomOn ? 'Turn scroll-zoom off' : 'Turn scroll-zoom on'}
      >
        {zoomOn ? '🔍+ on' : '🔍+ off'}
      </button>
    </div>
  );
});

export default OrgChartNeu;
