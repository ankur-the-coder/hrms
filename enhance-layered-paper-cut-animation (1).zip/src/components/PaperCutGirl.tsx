import React, { useMemo } from 'react';

export interface GirlAnimRefs {
  /* face & expression (unchanged) */
  headGroup: SVGGElement | null;
  torsoGroup: SVGGElement | null;
  pupilsGroup: SVGGElement | null;
  normalEyesGroup: SVGGElement | null;
  happyEyesGroup: SVGGElement | null;
  eyelidsGroup: SVGGElement | null;
  browsGroup: SVGGElement | null;
  cheeksGroup: SVGGElement | null;
  mouthCalm: SVGPathElement | null;
  mouthCurious: SVGPathElement | null;
  mouthHappy: SVGGElement | null;
  laptopGlow: SVGPolygonElement | null;
  /* rig */
  rootGroup: SVGGElement | null;
  bodyGroup: SVGGElement | null;
  chestGroup: SVGGElement | null;
  hairGroup: SVGGElement | null;
  legRigGroup: SVGGElement | null;
  sitLegsGroup: SVGGElement | null;
  bookGroup: SVGGElement | null;
  laptopGroup: SVGGElement | null;
  lidGroup: SVGGElement | null;
  lapShutGroup: SVGGElement | null;
  lapShutBack: SVGGElement | null;
  lapShutBackInner: SVGGElement | null;
  legPaths: (SVGPathElement | null)[]; // 0..4 left, 5..9 right
  armPaths: (SVGPathElement | null)[]; // 0..3 left, 4..7 right
  handL: SVGGElement | null;
  handR: SVGGElement | null;
}

interface PaperCutGirlProps {
  animRefs: React.RefObject<GirlAnimRefs>;
  onClick?: () => void;
}

/* Deterministic PRNG for authentic scissor-cut paper edges */
function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const q = (n: number) => Math.round(n * 10) / 10;

function polygonArea(pts: [number, number][]) {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const u = pts[i];
    const v = pts[(i + 1) % pts.length];
    a += u[0] * v[1] - v[0] * u[1];
  }
  return a;
}

function orientPts(pts: [number, number][]): [number, number][] {
  return polygonArea(pts) < 0 ? pts.slice().reverse() : pts;
}

function makeCutPath(
  rawPts: [number, number][],
  rand: () => number,
  jitter = 0.65,
  step = 6.5
): string {
  const pts = orientPts(rawPts);
  let s = '';
  const n = pts.length;
  for (let i = 0; i < n; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % n];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const L = Math.hypot(dx, dy) || 1;
    const k = Math.max(1, Math.round(L / step));
    const nx = -dy / L;
    const ny = dx / L;
    for (let t = 0; t < k; t++) {
      let x = a[0] + (dx * t) / k;
      let y = a[1] + (dy * t) / k;
      if (t > 0) {
        const o = (rand() - 0.5) * 2 * jitter;
        x += nx * o;
        y += ny * o;
      }
      s += (s ? 'L' : 'M') + q(x) + ' ' + q(y);
    }
  }
  return s + 'Z';
}

function makeEllipsePts(
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  n = 20,
  rot = 0
): [number, number][] {
  const ca = Math.cos(rot);
  const sa = Math.sin(rot);
  return Array.from({ length: n }, (_, i) => {
    const ang = (i / n) * Math.PI * 2;
    const ux = Math.cos(ang) * rx;
    const uy = Math.sin(ang) * ry;
    return [cx + ux * ca - uy * sa, cy + ux * sa + uy * ca];
  });
}

const BOX = 'view-box' as const;

export const PaperCutGirl: React.FC<PaperCutGirlProps> = ({ animRefs, onClick }) => {
  const R = animRefs.current;
  const legRef = (i: number) => (el: SVGPathElement | null) => {
    R.legPaths[i] = el;
  };
  const armRef = (i: number) => (el: SVGPathElement | null) => {
    R.armPaths[i] = el;
  };

  /* Precompute every scissor-cut polygon in the exact 377x360 coordinate space */
  const paths = useMemo(() => {
    const RND = mulberry32(4815);
    const cut = (pts: [number, number][], j = 0.65, st = 6.5) =>
      makeCutPath(pts, RND, j, st);

    /* ============ 1. STACK OF 3 BOOKS (x 16..126, y 284..354) ============ */
    const bookBotCover = cut([[18, 333], [124, 333], [126, 353], [17, 353]], 0.55, 6);
    const bookBotSpine = cut([[17, 333], [36, 333], [36, 353], [17, 353]], 0.4, 5);
    const bookBotPages = cut([[35, 336], [121, 336], [121, 349], [35, 349]], 0.35, 5);
    const bookMidCover = cut([[20, 316], [122, 316], [123, 334], [19, 334]], 0.55, 6);
    const bookMidPages = cut([[26, 320], [116, 320], [116, 330], [26, 330]], 0.35, 5);
    const bookTopCover = cut([[19, 286], [120, 286], [122, 297], [18, 297]], 0.5, 6);
    const bookTopBody = cut([[19, 295], [121, 295], [122, 317], [19, 317]], 0.5, 6);
    const bookTopSpine = cut([[19, 295], [35, 295], [35, 317], [19, 317]], 0.4, 5);
    const bookTopPages = cut([[34, 297], [117, 297], [117, 314], [34, 314]], 0.35, 5);
    const bookClasp = cut([[45, 304], [53, 304], [52, 316], [46, 316]], 0.25, 4);

    /* ============ 2. CROSS-LEGGED DENIM JEANS & SHOES ============ */
    const shoeLBody = cut([[136, 336], [174, 334], [178, 351], [134, 352]], 0.5, 5);
    const shoeLSole = cut([[133, 348], [179, 347], [178, 354], [133, 354]], 0.35, 5);
    const shoeRBody = cut([[284, 334], [322, 336], [325, 352], [282, 351]], 0.5, 5);
    const shoeRSole = cut([[281, 347], [326, 348], [325, 354], [281, 354]], 0.35, 5);
    const legLeft = cut(
      [[134, 304], [188, 296], [236, 326], [226, 346], [152, 338], [130, 322]],
      0.65,
      6.5
    );
    const legLeftShadow = cut([[138, 324], [218, 332], [226, 346], [146, 340]], 0.5, 6);
    const legRight = cut(
      [[222, 314], [286, 296], [322, 308], [326, 328], [298, 344], [188, 352], [178, 336]],
      0.65,
      6.5
    );
    const legRightShadow = cut(
      [[262, 304], [320, 308], [324, 328], [296, 344], [244, 348], [278, 324]],
      0.55,
      6
    );
    const kneeCrease = cut([[192, 316], [248, 308], [254, 316], [196, 324]], 0.4, 5);

    /* ============ 3. CORAL-ROSE SWEATER, COLLAR, ARMS ============ */
    const sweaterTop = cut(
      [[156, 182], [280, 182], [302, 212], [298, 286], [136, 286], [134, 212]],
      0.65,
      6.5
    );
    const sleeveLeftShadow = cut([[130, 214], [148, 212], [150, 286], [130, 282]], 0.5, 5.5);
    const sleeveRightShadow = cut([[286, 212], [306, 214], [304, 282], [284, 286]], 0.5, 5.5);
    const collarL = cut([[190, 177], [218, 182], [212, 193], [184, 186]], 0.35, 4);
    const collarR = cut([[218, 182], [246, 177], [252, 186], [224, 193]], 0.35, 4);
    const neck = cut([[202, 166], [234, 166], [232, 186], [204, 186]], 0.35, 4);

    const handL = cut(makeEllipsePts(152, 278, 10, 7.6, 14, 0.25), 0.35, 4);
    const handR = cut(makeEllipsePts(282, 278, 10, 7.6, 14, -0.25), 0.35, 4);

    /* ============ 4. POWDER-BLUE LAPTOP ============ */
    const laptopOuter = cut([[138, 204], [294, 204], [284, 294], [148, 294]], 0.55, 6.5);
    const laptopRightShade = cut([[256, 204], [294, 204], [284, 294], [248, 294]], 0.5, 6.5);
    const laptopTopRim = cut([[138, 202], [294, 202], [293, 208], [139, 208]], 0.35, 6);
    const laptopBase = cut([[152, 291], [280, 291], [276, 300], [156, 300]], 0.45, 5.5);
    const laptopLogoOuter = cut(makeEllipsePts(216, 251, 13, 13, 18), 0.35, 4);
    const laptopLogoInner = cut(makeEllipsePts(216, 251, 8.5, 8.5, 16), 0.3, 3.5);

    /* the SAME laptop, folded shut — a solid clamshell slab she can carry */
    const lapShutTop = cut([[153, 268], [285, 266], [287, 282], [155, 284]], 0.45, 6);
    const lapShutBody = cut([[155, 280], [287, 278], [285, 298], [153, 299]], 0.45, 6);
    const lapShutShade = cut([[250, 279], [286, 278], [284, 298], [248, 299]], 0.4, 6);
    const lapShutRim = cut([[153, 266], [285, 264], [285, 271], [153, 273]], 0.3, 5);
    const lapShutLogo = cut(makeEllipsePts(220, 274, 7.5, 6, 14), 0.25, 3.5);

    /* ============ 5. CHESTNUT HAIR, FACE, EARS ============ */
    const hairBackOuter = cut(
      [
        [162, 16], [216, 12], [272, 16], [314, 48], [332, 96], [326, 138],
        [296, 146], [268, 168], [166, 168], [136, 146], [106, 138], [102, 96], [120, 48],
      ],
      0.75,
      6.5
    );
    const hairChestnutL = cut(
      [[168, 18], [218, 16], [216, 58], [168, 108], [146, 144], [112, 136], [108, 94], [126, 48]],
      0.65,
      6
    );
    const hairChestnutR = cut(
      [[218, 16], [270, 18], [308, 48], [326, 94], [320, 136], [288, 144], [268, 108], [218, 58]],
      0.65,
      6
    );
    const hairHighlightL = cut(
      [[152, 32], [198, 22], [188, 56], [146, 96], [124, 118], [122, 82]],
      0.5,
      5.5
    );
    const hairHighlightR = cut(
      [[236, 22], [282, 32], [310, 82], [308, 118], [286, 96], [246, 56]],
      0.5,
      5.5
    );
    const earL = cut(makeEllipsePts(152, 134, 11, 13, 14, -0.15), 0.35, 4);
    const earR = cut(makeEllipsePts(284, 134, 11, 13, 14, 0.15), 0.35, 4);
    const faceShadow = cut(
      [[158, 84], [218, 54], [278, 84], [278, 138], [254, 168], [218, 176], [182, 168], [158, 138]],
      0.5,
      5.5
    );
    const faceMain = cut(
      [[160, 82], [218, 52], [276, 82], [275, 135], [252, 165], [218, 173], [184, 165], [161, 135]],
      0.48,
      5.5
    );
    const bangsL = cut(
      [[218, 46], [204, 72], [176, 98], [156, 122], [150, 92], [168, 56]],
      0.5,
      5
    );
    const bangsR = cut(
      [[218, 46], [268, 56], [286, 92], [280, 122], [260, 98], [232, 72]],
      0.5,
      5
    );
    const nose = cut([[215, 128], [223, 128], [226, 142], [218, 145], [212, 142]], 0.25, 3.5);
    const cheekL = cut(makeEllipsePts(176, 142, 10.5, 6.8, 14), 0.25, 3.5);
    const cheekR = cut(makeEllipsePts(260, 142, 10.5, 6.8, 14), 0.25, 3.5);

    return {
      bookBotCover, bookBotSpine, bookBotPages, bookMidCover, bookMidPages,
      bookTopCover, bookTopBody, bookTopSpine, bookTopPages, bookClasp,
      shoeLBody, shoeLSole, shoeRBody, shoeRSole,
      legLeft, legLeftShadow, legRight, legRightShadow, kneeCrease,
      sweaterTop, sleeveLeftShadow, sleeveRightShadow, collarL, collarR, neck,
      handL, handR,
      laptopOuter, laptopRightShade, laptopTopRim, laptopBase, laptopLogoOuter, laptopLogoInner,
      lapShutTop, lapShutBody, lapShutShade, lapShutRim, lapShutLogo,
      hairBackOuter, hairChestnutL, hairChestnutR, hairHighlightL, hairHighlightR,
      earL, earR, faceShadow, faceMain, bangsL, bangsR, nose, cheekL, cheekR,
    };
  }, []);

  return (
    <svg
      viewBox="0 -90 377 450"
      width="100%"
      height="100%"
      overflow="visible"
      onClick={onClick}
      role="img"
      aria-label="A paper-cut girl walks in from the right carrying her books and laptop, sits down cross-legged, opens the laptop, then throws a paper plane out of frame."
    >
      <defs>
        <filter id="pc-layer" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow dx="0" dy="-0.9" stdDeviation="0.3" floodColor="#fffdf6" floodOpacity="0.68" />
          <feDropShadow dx="1.4" dy="3.0" stdDeviation="2.0" floodColor="#3a2412" floodOpacity="0.34" />
        </filter>
        <filter id="pc-soft" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow dx="0.8" dy="1.8" stdDeviation="1.2" floodColor="#3a2412" floodOpacity="0.26" />
        </filter>
      </defs>

      <g
        ref={(el) => {
          R.rootGroup = el;
        }}
        style={{ transformBox: BOX, transformOrigin: '218px 444px' }}
      >
        {/* ===== articulated legs — kept outside the hip lift so feet stay planted ===== */}
        <g
          ref={(el) => {
            R.legRigGroup = el;
          }}
          style={{ transformBox: BOX }}
          stroke="#3a2412"
          strokeOpacity="0.17"
          strokeWidth="1.1"
          strokeLinejoin="round"
        >
          {/* left leg */}
          <path ref={legRef(0)} fill="#66abcc" />
          <path ref={legRef(1)} fill="#1c7792" />
          <path ref={legRef(2)} fill="#66abcc" />
          <path ref={legRef(3)} fill="#635d65" />
          <path ref={legRef(4)} fill="#332a22" />
          {/* right leg (crosses in front) */}
          <path ref={legRef(5)} fill="#66abcc" />
          <path ref={legRef(6)} fill="#1b7891" />
          <path ref={legRef(7)} fill="#66abcc" />
          <path ref={legRef(8)} fill="#635d65" />
          <path ref={legRef(9)} fill="#332a22" />
        </g>

        {/* ===== everything that rides on the hip lift ===== */}
        <g
          ref={(el) => {
            R.bodyGroup = el;
          }}
          style={{ transformBox: BOX }}
        >
          <g
            ref={(el) => {
              R.torsoGroup = el;
            }}
            style={{ transformBox: BOX, transformOrigin: '218px 400px' }}
          >
            {/* the shut laptop while it is tucked under her arm — drawn behind
                the torso, then cross-faded to the copy in front once it is on
                her lap. Both share one transform, so the swap is invisible. */}
            <g
              ref={(el) => {
                R.lapShutBack = el;
              }}
              style={{ transformBox: BOX, transformOrigin: '216px 381px' }}
              filter="url(#pc-layer)"
            >
              <g
                ref={(el) => {
                  R.lapShutBackInner = el;
                }}
                style={{ transformBox: BOX, transformOrigin: '216px 388px' }}
              >
                <path fill="#86d1e8" d={paths.lapShutBody} />
                <path fill="#5fa8c4" d={paths.lapShutShade} />
                <path fill="#c0edff" d={paths.lapShutTop} />
                <path fill="#ffffff" d={paths.lapShutRim} />
                <path fill="#7f9aad" d={paths.lapShutLogo} />
                <path className="grain" d={paths.lapShutTop} />
              </g>
            </g>

            {/* ---------- chest: twists for the throw ---------- */}
            <g
              ref={(el) => {
                R.chestGroup = el;
              }}
              style={{ transformBox: BOX, transformOrigin: '218px 382px' }}
            >
              <g filter="url(#pc-layer)">
                <path fill="#e8a493" d={paths.sweaterTop} />
                <path fill="#b6594c" d={paths.sleeveLeftShadow} />
                <path fill="#b6594c" d={paths.sleeveRightShadow} />
                <path fill="#f7d2b0" d={paths.neck} />
                <path fill="#fffbe6" d={paths.collarL} />
                <path fill="#fffbe6" d={paths.collarR} />
                <path className="grain" d={paths.sweaterTop} />
              </g>

              {/* ---------- left arm: behind the head, behind the laptop ---------- */}
              <g stroke="#3a2412" strokeOpacity="0.16" strokeWidth="1" strokeLinejoin="round">
                <path ref={armRef(0)} fill="#b6594c" />
                <path ref={armRef(1)} fill="#e8a493" />
                <path ref={armRef(2)} fill="#e8a493" />
                <path ref={armRef(3)} fill="#b6594c" />
              </g>

              {/* ---------- head ---------- */}
              <g
                ref={(el) => {
                  R.headGroup = el;
                }}
                style={{ transformBox: BOX, transformOrigin: '218px 258px' }}
              >
                <g
                  ref={(el) => {
                    R.hairGroup = el;
                  }}
                  style={{ transformBox: BOX, transformOrigin: '218px 134px' }}
                  filter="url(#pc-layer)"
                >
                  <path fill="#5e281f" d={paths.hairBackOuter} />
                  <path fill="#9e695c" d={paths.hairChestnutL} />
                  <path fill="#9e695c" d={paths.hairChestnutR} />
                  <path fill="#b57d6e" d={paths.hairHighlightL} />
                  <path fill="#b57d6e" d={paths.hairHighlightR} />
                  <path className="grain" d={paths.hairBackOuter} />
                </g>

                <g filter="url(#pc-soft)">
                  <path fill="#f5cfaf" d={paths.earL} />
                  <path fill="#f5cfaf" d={paths.earR} />
                  <path
                    d="M150 130 Q155 134 151 139 M286 130 Q281 134 285 139"
                    fill="none"
                    stroke="#c98e6b"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                  />
                </g>

                <g filter="url(#pc-layer)">
                  <path fill="#f2c49e" d={paths.faceShadow} />
                  <path fill="#ffdfc0" d={paths.faceMain} />
                  <path className="grain" d={paths.faceMain} />
                </g>

                <g
                  ref={(el) => {
                    R.cheeksGroup = el;
                  }}
                  opacity="0.65"
                >
                  <path fill="#f09587" d={paths.cheekL} />
                  <path fill="#f09587" d={paths.cheekR} />
                </g>

                <g filter="url(#pc-soft)">
                  <path fill="#e3b18a" d={paths.nose} />
                </g>

                <g
                  ref={(el) => {
                    R.normalEyesGroup = el;
                  }}
                >
                  <path
                    d="M177 123 Q190 114 203 123 M235 123 Q248 114 261 123"
                    fill="none"
                    stroke="#3b150c"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                  />
                  <ellipse cx="190" cy="126" rx="8.2" ry="7.8" fill="#fffaf2" />
                  <ellipse cx="248" cy="126" rx="8.2" ry="7.8" fill="#fffaf2" />
                  <g
                    ref={(el) => {
                      R.pupilsGroup = el;
                    }}
                  >
                    <circle cx="190" cy="126.5" r="5.4" fill="#46180d" />
                    <circle cx="190" cy="126.5" r="3.1" fill="#1e0803" />
                    <circle cx="188" cy="124.2" r="1.7" fill="#ffffff" />
                    <circle cx="192.2" cy="128.4" r="0.8" fill="#ffffff" />
                    <circle cx="248" cy="126.5" r="5.4" fill="#46180d" />
                    <circle cx="248" cy="126.5" r="3.1" fill="#1e0803" />
                    <circle cx="246" cy="124.2" r="1.7" fill="#ffffff" />
                    <circle cx="250.2" cy="128.4" r="0.8" fill="#ffffff" />
                  </g>
                  <g
                    ref={(el) => {
                      R.eyelidsGroup = el;
                    }}
                    style={{ transformBox: BOX, transformOrigin: '219px 214px', transform: 'scaleY(0)' }}
                  >
                    <ellipse cx="190" cy="126" rx="9" ry="8.5" fill="#f7d2b0" />
                    <ellipse cx="248" cy="126" rx="9" ry="8.5" fill="#f7d2b0" />
                    <path
                      d="M178 127 Q190 133 202 127 M236 127 Q248 133 260 127"
                      fill="none"
                      stroke="#3b150c"
                      strokeWidth="2.3"
                      strokeLinecap="round"
                    />
                  </g>
                </g>

                <g
                  ref={(el) => {
                    R.happyEyesGroup = el;
                  }}
                  opacity="0"
                >
                  <path d="M179 128 Q190 116 201 128" fill="none" stroke="#3b150c" strokeWidth="3.2" strokeLinecap="round" />
                  <path d="M237 128 Q248 116 259 128" fill="none" stroke="#3b150c" strokeWidth="3.2" strokeLinecap="round" />
                </g>

                <g
                  ref={(el) => {
                    R.browsGroup = el;
                  }}
                >
                  <path d="M176 105 Q189 98 202 103" fill="none" stroke="#4d1d12" strokeWidth="3.2" strokeLinecap="round" />
                  <path d="M236 103 Q249 98 262 105" fill="none" stroke="#4d1d12" strokeWidth="3.2" strokeLinecap="round" />
                </g>

                <path
                  ref={(el) => {
                    R.mouthCalm = el;
                  }}
                  d="M209 152 Q219 159 229 152"
                  fill="none"
                  stroke="#b84a49"
                  strokeWidth="2.8"
                  strokeLinecap="round"
                />
                <path
                  ref={(el) => {
                    R.mouthCurious = el;
                  }}
                  d="M219 148.5 A5.2 5.8 0 1 1 218.99 148.5 Z"
                  fill="#bf5453"
                  stroke="#7a2826"
                  strokeWidth="1.6"
                  opacity="0"
                />
                <g
                  ref={(el) => {
                    R.mouthHappy = el;
                  }}
                  opacity="0"
                >
                  <path
                    d="M205 149 Q219 152 233 149 Q230 164 219 164 Q208 164 205 149 Z"
                    fill="#b84343"
                    stroke="#7a2826"
                    strokeWidth="1.8"
                    strokeLinejoin="round"
                  />
                  <path d="M211 158 Q219 154 227 158 Q224 163 219 163 Q214 163 211 158 Z" fill="#f08c8c" />
                </g>

                <g filter="url(#pc-layer)">
                  <path fill="#652e26" d={paths.bangsL} />
                  <path fill="#652e26" d={paths.bangsR} />
                  <path className="grain" d={paths.bangsL} />
                  <path className="grain" d={paths.bangsR} />
                </g>
              </g>

              {/* ---------- right arm: in front of the hair so the throw reads ---------- */}
              <g stroke="#3a2412" strokeOpacity="0.16" strokeWidth="1" strokeLinejoin="round">
                <path ref={armRef(4)} fill="#b6594c" />
                <path ref={armRef(5)} fill="#e8a493" />
                <path ref={armRef(6)} fill="#e8a493" />
                <path ref={armRef(7)} fill="#b6594c" />
              </g>

              {/* ---------- hands: wrist-parented, in the arms' own space ---------- */}
              <g
                ref={(el) => {
                  R.handL = el;
                }}
                filter="url(#pc-soft)"
                style={{ transformBox: BOX, transformOrigin: '152px 368px' }}
              >
                <path fill="#ffdfc0" d={paths.handL} />
              </g>
              <g
                ref={(el) => {
                  R.handR = el;
                }}
                filter="url(#pc-soft)"
                style={{ transformBox: BOX, transformOrigin: '282px 368px' }}
              >
                <path fill="#ffdfc0" d={paths.handR} />
              </g>
            </g>

            {/* ---------- the pre-cut crossed legs (fade in as the rig folds) ---------- */}
            <g
              ref={(el) => {
                R.sitLegsGroup = el;
              }}
              opacity="0"
            >
              <g filter="url(#pc-layer)">
                <path fill="#635d65" d={paths.shoeLBody} />
                <path fill="#332a22" d={paths.shoeLSole} />
                <path fill="#635d65" d={paths.shoeRBody} />
                <path fill="#332a22" d={paths.shoeRSole} />
              </g>
              <g filter="url(#pc-layer)">
                <path fill="#66abcc" d={paths.legLeft} />
                <path fill="#1c7792" d={paths.legLeftShadow} />
                <path className="grain" d={paths.legLeft} />
              </g>
              <g filter="url(#pc-layer)">
                <path fill="#66abcc" d={paths.legRight} />
                <path fill="#1b7891" d={paths.legRightShadow} />
                <path fill="#3d88a8" d={paths.kneeCrease} />
                <path className="grain" d={paths.legRight} />
              </g>
            </g>

            {/* ---------- laptop ---------- */}
            <polygon
              ref={(el) => {
                R.laptopGlow = el;
              }}
              points="132,198 300,198 290,298 142,298"
              fill="rgba(138, 240, 175, 0.65)"
              opacity="0"
              style={{ filter: 'blur(8px)' }}
            />
            <g
              ref={(el) => {
                R.laptopGroup = el;
              }}
              style={{ transformBox: BOX, transformOrigin: '216px 381px' }}
              filter="url(#pc-layer)"
            >
              {/* folded shut — what she carries in, and what sits on her lap
                  until the moment the lid actually lifts */}
              <g
                ref={(el) => {
                  R.lapShutGroup = el;
                }}
                style={{ transformBox: BOX, transformOrigin: '216px 388px' }}
              >
                <path fill="#86d1e8" d={paths.lapShutBody} />
                <path fill="#5fa8c4" d={paths.lapShutShade} />
                <path fill="#c0edff" d={paths.lapShutTop} />
                <path fill="#ffffff" d={paths.lapShutRim} />
                <path fill="#7f9aad" d={paths.lapShutLogo} />
                <path className="grain" d={paths.lapShutTop} />
              </g>

              <path fill="#849fb2" d={paths.laptopBase} />
              <g
                ref={(el) => {
                  R.lidGroup = el;
                }}
                style={{ transformBox: BOX, transformOrigin: '216px 381px' }}
                opacity="0"
              >
                <path fill="#c0edff" d={paths.laptopOuter} />
                <path fill="#86d1e8" d={paths.laptopRightShade} />
                <path fill="#ffffff" d={paths.laptopTopRim} />
                <path fill="#f7fcff" d={paths.laptopLogoOuter} />
                <path fill="#3d4347" d={paths.laptopLogoInner} />
                <path className="grain" d={paths.laptopOuter} />
              </g>
            </g>
          </g>

          {/* ---------- the stack of three books: carried in, then set down ---------- */}
          <g
            id="book-stack"
            ref={(el) => {
              R.bookGroup = el;
            }}
            style={{ transformBox: BOX, transformOrigin: '71px 409px' }}
          >
            <g filter="url(#pc-layer)">
              <path fill="#9f8d75" d={paths.bookBotCover} />
              <path fill="#ded7ca" d={paths.bookBotPages} />
              <path fill="#37597a" d={paths.bookBotSpine} />
              <path stroke="#b8ae9c" strokeWidth="1" d="M38 340H118 M38 345H117" />
              <path className="grain" d={paths.bookBotCover} />
            </g>
            <g filter="url(#pc-layer)">
              <path fill="#282c31" d={paths.bookMidCover} />
              <path fill="#e3dac9" d={paths.bookMidPages} />
              <path stroke="#b8ae9c" strokeWidth="1" d="M30 325H113" />
              <path className="grain" d={paths.bookMidCover} />
            </g>
            <g filter="url(#pc-layer)">
              <path fill="#663b0b" d={paths.bookTopBody} />
              <path fill="#e3d6c5" d={paths.bookTopPages} />
              <path fill="#ae8034" d={paths.bookTopSpine} />
              <path fill="#523105" d={paths.bookTopCover} />
              <path stroke="#c4b5a2" strokeWidth="1" d="M37 302H114 M37 307H114 M37 311H113" />
              <path fill="#2b2618" d={paths.bookClasp} />
              <path className="grain" d={paths.bookTopBody} />
            </g>
          </g>
        </g>
      </g>
    </svg>
  );
};
