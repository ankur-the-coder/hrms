// 3D-projected layered paper-cut bird & mail delivery renderer
// Inspired by paper-mail-hollow (1).html and the white paper-cut dove reference

export interface DioramaTargets {
  W: number;
  H: number;
  dpr: number;
  girlCx: number;
  girlTop: number;
  girlBot: number;
  girlGw: number;
  girlGh: number;
  laptopX: number;
  laptopY: number;
}

export interface FrameCallbackState {
  t: number;
  birdActive: boolean;
  birdX: number;
  birdY: number;
  mailDropped: boolean;
  envX: number;
  envY: number;
  ticketActive: boolean;
  ticketX: number;
  ticketY: number;
  ticketArrived: boolean;
  ticketArrivedTime: number;
}

/* quality switch — flipped off automatically on slow hardware */
export const DoveQ = { shadow: true };

const sh = (ctx: CanvasRenderingContext2D, c: string, b: number, o: number, dpr: number) => {
  if (DoveQ.shadow) {
    ctx.shadowColor = c;
    ctx.shadowBlur = b * dpr;
    ctx.shadowOffsetY = o * dpr;
  } else {
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;
  }
};

const PI2 = Math.PI * 2;
const clamp = (v: number, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp(t), 3);
const easeInOutCubic = (t: number) => {
  const c = clamp(t);
  return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
};

const hash = (n: number) => {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
};

interface Vec2 {
  x: number;
  y: number;
}

interface Vec3 {
  x: number;
  y: number;
  z: number;
}

const quadBez = (A: Vec2, C: Vec2, B: Vec2, t: number): Vec2 => {
  const u = 1 - t;
  return {
    x: u * u * A.x + 2 * u * t * C.x + t * t * B.x,
    y: u * u * A.y + 2 * u * t * C.y + t * t * B.y,
  };
};

// Asymmetric wingbeat timing: downstroke is faster and more powerful than recovery upstroke
const wingPhaseMap = (p: number) => (p < 0.42 ? (p / 0.42) * 0.5 : 0.5 + ((p - 0.42) / 0.58) * 0.5);

const norm3 = (a: number, b: number, c: number): Vec3 => {
  const l = Math.hypot(a, b, c) || 1;
  return { x: a / l, y: b / l, z: c / l };
};

const lerp3 = (a: Vec3, b: Vec3, t: number): Vec3 => ({
  x: lerp(a.x, b.x, t),
  y: lerp(a.y, b.y, t),
  z: lerp(a.z, b.z, t),
});

// 3D to 2D axonometric projection matching the reference bird
const proj = (p: Vec3): [number, number] => [p.x - 0.5 * p.z, -p.y + 0.16 * p.z];

// Key timeline constants (in seconds)
export const TR = 4.6; // Moment bird releases mail from beak
export const TS = 5.55; // Moment ticket begins peeling out of envelope
export const TL = 7.05; // Moment ticket enters laptop screen

// Smooth time-warping function across [0, TR] and [TR, T_EXIT] that preserves non-zero velocity at TR
function getBirdPath(t: number, tg: DioramaTargets): Vec2 {
  const { W, H, girlCx, girlTop } = tg;
  // Drop point positioned above and slightly left of the girl so the released letter drifts down beside her
  const D: Vec2 = {
    x: girlCx - Math.min(48, W * 0.04),
    y: Math.max(H * 0.18, girlTop - Math.min(105, H * 0.13)),
  };

  // Start off-screen left
  const A: Vec2 = {
    x: -Math.max(110, W * 0.09),
    y: H * 0.22,
  };

  // Control point 1 (gentle swoop in from the left)
  const C1: Vec2 = {
    x: lerp(A.x, D.x, 0.56),
    y: D.y - H * 0.055,
  };

  // Control point 2 is collinear with C1 -> D so the path tangent is 100% smooth at D!
  const tangentX = D.x - C1.x;
  const tangentY = D.y - C1.y;
  const C2: Vec2 = {
    x: D.x + tangentX * 0.62,
    y: D.y + tangentY * 0.62,
  };

  // Exit off-screen top-right
  const B: Vec2 = {
    x: W + Math.max(130, W * 0.11),
    y: Math.max(H * 0.07, D.y - H * 0.22),
  };

  if (t <= TR) {
    const u = clamp(t / TR);
    // Smooth deceleration as bird flares to drop mail, keeping ~45% cruise speed at TR
    const s = 0.68 * u + 0.32 * (1 - Math.pow(1 - u, 2.1));
    return quadBez(A, C1, D, s);
  } else {
    const u = clamp((t - TR) / 3.5);
    // Smooth acceleration out to the right matching the arrival speed at u = 0
    const s = 0.52 * u + 0.48 * u * u;
    return quadBez(D, C2, B, s);
  }
}

export function getBirdPose(t: number, tg: DioramaTargets) {
  const p0 = getBirdPath(t, tg);
  const p1 = getBirdPath(t + 0.03, tg);
  const hd = Math.atan2(p1.y - p0.y, p1.x - p0.x);
  // Subtle aerodynamic flare as the bird slows down to release the envelope from its beak
  const flare =
    t < TR
      ? clamp((t - 3.2) / 1.4)
      : clamp(1 - (t - TR) / 0.9);
  const pitch = clamp(hd * 0.72 - 0.1 - 0.38 * flare, -0.78, 0.45);
  return { x: p0.x, y: p0.y, pitch, flare };
}

export const getWingFreq = (t: number) =>
  t < 3.2
    ? 2.25
    : t < TR
    ? lerp(2.25, 3.35, (t - 3.2) / (TR - 3.2))
    : t < 5.6
    ? 3.15
    : 2.45;

// Draw a single sculpted layered paper-cut feather with rachis shaft & subtle barb texture
function drawPaperFeather(
  ctx: CanvasRenderingContext2D,
  a: [number, number],
  e: [number, number],
  wd: number,
  col: string,
  shaftCol = 'rgba(115, 96, 76, 0.36)'
) {
  const dx = e[0] - a[0];
  const dy = e[1] - a[1];
  const L = Math.hypot(dx, dy) || 1;
  const nx = (-dy / L) * (wd / 2);
  const ny = (dx / L) * (wd / 2);

  ctx.beginPath();
  ctx.moveTo(a[0] + nx * 0.92, a[1] + ny * 0.92);
  ctx.lineTo(a[0] + dx * 0.58 + nx * 1.18, a[1] + dy * 0.58 + ny * 1.18);
  // Scissor-cut slightly angled rounded feather tip like the white paper dove photo
  ctx.quadraticCurveTo(e[0] + nx * 0.52, e[1] + ny * 0.52, e[0], e[1]);
  ctx.quadraticCurveTo(
    e[0] - nx * 0.48,
    e[1] - ny * 0.48,
    a[0] + dx * 0.62 - nx * 1.12,
    a[1] + dy * 0.62 - ny * 1.12
  );
  ctx.lineTo(a[0] - nx * 0.92, a[1] - ny * 0.92);
  ctx.closePath();

  ctx.fillStyle = col;
  ctx.fill();
  ctx.stroke();

  // Central embossed paper quill/rachis line
  ctx.save();
  ctx.strokeStyle = shaftCol;
  ctx.lineWidth = 0.0055;
  ctx.beginPath();
  ctx.moveTo(a[0], a[1]);
  ctx.lineTo(a[0] + dx * 0.91, a[1] + dy * 0.91);
  ctx.stroke();
  ctx.restore();
}

// Draw 3D articulated wing (side = -1 for far wing, side = +1 for near wing)
function drawWing(ctx: CanvasRenderingContext2D, side: -1 | 1, p: number) {
  const u0 = wingPhaseMap(p);
  const v = -Math.sin(PI2 * u0);
  const up = Math.max(0, v);

  // Two-joint 3D wing kinematics from reference HTML
  const b1 = 0.1 + 0.9 * Math.cos(PI2 * u0); // Arm flap angle (+57° at top, -46° at bottom)
  const b2 = b1 - 0.6 * v; // Hand/wrist lag: curves under load on downstroke, arches on upstroke
  const s1 = 0.3 + 0.3 * up; // Sweep-back increases on recovery upstroke
  const s2 = s1 + 0.2 + 0.25 * up;
  const La = 0.47;
  const Lh = 0.60 * (1 - 0.38 * up); // Outer hand folds in slightly on upstroke

  const d1 = norm3(-s1, Math.sin(b1), Math.cos(b1));
  const d2 = norm3(-s2, Math.sin(b2), Math.cos(b2));
  d1.z *= side;
  d2.z *= side;

  const S3: Vec3 = { x: 0.12, y: 0.06, z: 0 };
  const Wr: Vec3 = { x: S3.x + d1.x * La, y: S3.y + d1.y * La, z: d1.z * La };
  const T3: Vec3 = { x: Wr.x + d2.x * Lh, y: Wr.y + d2.y * Lh, z: Wr.z + d2.z * Lh };

  // Trailing feathers bend up under aerodynamic load on downstroke, relax on upstroke
  const fb = norm3(-1, -0.25 * v - 0.08, 0);

  const fe = (r: Vec3, d: Vec3, len: number, wd: number, col: string) =>
    drawPaperFeather(
      ctx,
      proj(r),
      proj({ x: r.x + d.x * len, y: r.y + d.y * len, z: r.z + d.z * len }),
      wd,
      col
    );

  // Paper colors: near wing is warm ivory-white, far wing is slightly shaded for 3D depth
  const featA = side === 1 ? '#fbf8f0' : '#eee8d8';
  const featB = side === 1 ? '#f0eadc' : '#e3dccb';
  const covertCol = side === 1 ? '#f5f0e2' : '#e8e1d0';
  const covertTopCol = side === 1 ? '#fdfbf5' : '#f2ece0';

  ctx.lineWidth = 0.0075;
  ctx.strokeStyle = 'rgba(68, 50, 32, 0.38)';
  ctx.lineJoin = 'round';

  // 1. Secondary flight feathers (inner arm S3 -> Wr)
  for (let i = 8; i >= 0; i--) {
    const t = 0.08 + (0.92 * i) / 8;
    const len = (0.28 + 0.11 * Math.sin(Math.PI * t * 0.9)) * (0.76 + 0.24 * t);
    fe(lerp3(S3, Wr, t), fb, len, 0.076, i % 2 ? featA : featB);
  }

  // 2. Primary flight feathers (outer hand Wr -> T3, long & slotted like the paper dove photo)
  for (let i = 8; i >= 0; i--) {
    const t = i / 8;
    const m = lerp3(fb, d2, 0.18 + 0.76 * t);
    m.y += (t - 0.5) * 0.45 * up;
    const d = norm3(m.x, m.y, m.z);
    const len = (0.54 - 0.21 * t * t) * (1 - 0.24 * up);
    fe(lerp3(Wr, T3, 0.05 + 0.9 * t), d, len, 0.074, i % 2 ? featB : featA);
  }

  // 3. Greater secondary coverts (overlapping paper row)
  for (let i = 8; i >= 0; i--) {
    fe(lerp3(S3, Wr, 0.06 + (0.9 * i) / 8), fb, 0.18, 0.07, covertCol);
  }

  // 4. Greater primary coverts
  for (let i = 5; i >= 0; i--) {
    const t = i / 5;
    const m = lerp3(fb, d2, 0.3 + 0.4 * t);
    const d = norm3(m.x, m.y, m.z);
    fe(lerp3(Wr, T3, 0.05 + 0.72 * t), d, 0.17 - 0.05 * t, 0.065, covertCol);
  }

  // 5. Median & lesser shoulder coverts
  for (let i = 8; i >= 0; i--) {
    fe(lerp3(S3, Wr, 0.04 + (0.9 * i) / 8), fb, 0.1, 0.062, covertTopCol);
  }

  // 6. Sculpted leading-edge wing ridge (S3 -> Wr -> T3)
  const a = proj(S3);
  const b = proj(Wr);
  const c = proj(T3);
  ctx.lineCap = 'round';
  ctx.strokeStyle = covertTopCol;
  ctx.lineWidth = 0.048;
  ctx.beginPath();
  ctx.moveTo(a[0], a[1]);
  ctx.lineTo(b[0], b[1]);
  ctx.lineTo(c[0], c[1]);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(68, 50, 32, 0.32)';
  ctx.lineWidth = 0.008;
  ctx.stroke();
}

// Draw realistic bent & tucked coral-pink legs like the paper-cut dove reference photo
function drawTuckedLegs(ctx: CanvasRenderingContext2D, u0: number) {
  const flex = 0.025 * Math.sin(PI2 * u0);

  ctx.save();
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  // Far foot (tucked slightly higher/behind)
  ctx.strokeStyle = '#b44958';
  ctx.fillStyle = '#b44958';
  ctx.lineWidth = 0.022;
  ctx.beginPath();
  // Bent tarsus from lower belly forward to ankle, then curled toes tucked back
  ctx.moveTo(-0.08, 0.17);
  ctx.lineTo(-0.01, 0.22 + flex);
  ctx.lineTo(0.05, 0.25 + flex);
  ctx.moveTo(-0.01, 0.22 + flex);
  ctx.lineTo(0.02, 0.27 + flex);
  ctx.moveTo(-0.01, 0.22 + flex);
  ctx.lineTo(-0.04, 0.26 + flex);
  ctx.stroke();

  // Near foot (coral-rose paper cut with 3 curled forward toes + tucked hallux, matching image 1)
  ctx.strokeStyle = '#cf5c6c';
  ctx.lineWidth = 0.025;
  ctx.beginPath();
  // Upper leg hidden in feathers -> bent ankle joint -> curled toes tucked under breast
  ctx.moveTo(-0.11, 0.18);
  ctx.lineTo(-0.03, 0.235 + flex);
  // Toe 1 (inner)
  ctx.quadraticCurveTo(0.03, 0.245 + flex, 0.06, 0.275 + flex);
  // Toe 2 (middle, longest curled)
  ctx.moveTo(-0.03, 0.235 + flex);
  ctx.quadraticCurveTo(0.02, 0.265 + flex, 0.035, 0.305 + flex);
  // Toe 3 (outer curled)
  ctx.moveTo(-0.03, 0.235 + flex);
  ctx.quadraticCurveTo(-0.005, 0.275 + flex, -0.005, 0.31 + flex);
  // Rear hallux toe
  ctx.moveTo(-0.03, 0.235 + flex);
  ctx.quadraticCurveTo(-0.065, 0.26 + flex, -0.075, 0.285 + flex);
  ctx.stroke();

  // Subtle paper-cut outline around near foot
  ctx.strokeStyle = 'rgba(70, 30, 35, 0.35)';
  ctx.lineWidth = 0.006;
  ctx.stroke();

  // Feathered white paper thigh tuft overlapping top of legs (just like image 1)
  ctx.fillStyle = '#efe9da';
  ctx.strokeStyle = 'rgba(68, 50, 32, 0.35)';
  ctx.lineWidth = 0.007;
  ctx.beginPath();
  ctx.moveTo(-0.18, 0.15);
  ctx.quadraticCurveTo(-0.11, 0.23, -0.04, 0.19);
  ctx.quadraticCurveTo(-0.08, 0.14, -0.18, 0.15);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  ctx.restore();
}

// Draw sculpted dove body, fanned paper-cut tail, head, eye, and beak
function drawBirdBody(ctx: CanvasRenderingContext2D, p: number, carry: boolean) {
  const u0 = wingPhaseMap(p);
  const tilt = 0.14 * Math.sin(PI2 * u0);

  ctx.lineWidth = 0.008;
  ctx.strokeStyle = 'rgba(68, 50, 32, 0.38)';

  // 1. Fanned layered paper-cut tail feathers (7 rectrices like the white dove photo)
  for (let i = 0; i < 7; i++) {
    const a = Math.PI + (i - 3) * 0.135 + tilt;
    const len = 0.52 - Math.abs(i - 3) * 0.025;
    drawPaperFeather(
      ctx,
      [-0.4, 0.05],
      [-0.4 + Math.cos(a) * len, 0.05 + Math.sin(a) * len],
      0.105,
      i % 2 ? '#faf6ec' : '#ece5d5'
    );
  }

  // Undertail covert paper layer (pointed white paper skirt at base of tail as in image 1)
  ctx.fillStyle = '#f2ece0';
  ctx.beginPath();
  ctx.moveTo(-0.18, 0.14);
  ctx.lineTo(-0.46, 0.16 + tilt * 0.15);
  ctx.lineTo(-0.37, 0.09 + tilt * 0.1);
  ctx.lineTo(-0.44, 0.04 + tilt * 0.08);
  ctx.lineTo(-0.22, 0.03);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // 2. Bent legs tucked under the body in flight
  drawTuckedLegs(ctx, u0);

  // 3. Sculpted Dove Body & Seamless Neck/Head Silhouette
  ctx.fillStyle = '#f6f1e4';
  ctx.beginPath();
  ctx.moveTo(-0.48, 0.02);
  // Back & shoulder curve
  ctx.bezierCurveTo(-0.28, -0.18, 0.08, -0.25, 0.32, -0.21);
  // Smooth neck & crown curve up to head
  ctx.bezierCurveTo(0.41, -0.29, 0.47, -0.37, 0.55, -0.35);
  ctx.bezierCurveTo(0.62, -0.33, 0.64, -0.25, 0.61, -0.18);
  // Throat & puffed dove breast curve
  ctx.bezierCurveTo(0.56, -0.11, 0.49, -0.02, 0.41, 0.08);
  // Belly tapering back to tail
  ctx.bezierCurveTo(0.28, 0.24, -0.02, 0.25, -0.22, 0.15);
  ctx.bezierCurveTo(-0.34, 0.09, -0.42, 0.07, -0.48, 0.02);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Subtle paper-cut breast/belly shading layer
  ctx.save();
  ctx.fillStyle = 'rgba(218, 208, 190, 0.45)';
  ctx.beginPath();
  ctx.moveTo(0.41, 0.06);
  ctx.bezierCurveTo(0.28, 0.22, 0.0, 0.23, -0.21, 0.14);
  ctx.bezierCurveTo(-0.02, 0.18, 0.24, 0.15, 0.41, 0.06);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // 4. Sculpted Coral-Pink Paper Beak (parted slightly when gripping mail in beak)
  const jawOpen = carry ? 0.028 : 0.005;
  // Lower mandible
  ctx.fillStyle = '#c46c64';
  ctx.beginPath();
  ctx.moveTo(0.59, -0.22);
  ctx.lineTo(0.75, -0.19 + jawOpen);
  ctx.lineTo(0.59, -0.17);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Upper mandible (curved dove beak tip)
  ctx.fillStyle = '#dc8780';
  ctx.beginPath();
  ctx.moveTo(0.59, -0.28);
  ctx.quadraticCurveTo(0.69, -0.27, 0.77, -0.21 - jawOpen * 0.4);
  ctx.lineTo(0.59, -0.21);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // White/pinkish cere at base of dove beak
  ctx.fillStyle = '#ead4d0';
  ctx.beginPath();
  ctx.ellipse(0.61, -0.255, 0.026, 0.016, -0.2, 0, PI2);
  ctx.fill();

  // 5. Expressive Dove Eye (mauve-pink paper eye ring + dark iris + white catchlight)
  ctx.fillStyle = '#d9a0a0';
  ctx.beginPath();
  ctx.arc(0.53, -0.26, 0.036, 0, PI2);
  ctx.fill();

  ctx.fillStyle = '#251a14';
  ctx.beginPath();
  ctx.arc(0.53, -0.26, 0.021, 0, PI2);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0.537, -0.267, 0.007, 0, PI2);
  ctx.fill();
}

// Draw the bird and return the exact world coordinates of its beak tip
export function drawBird(
  ctx: CanvasRenderingContext2D,
  t: number,
  ph: number,
  Bs: number,
  dpr: number,
  tg: DioramaTargets
) {
  const p = getBirdPose(t, tg);
  const carry = t < TR;
  const bob = -0.068 * Bs * Math.sin(PI2 * wingPhaseMap(ph));

  ctx.save();
  ctx.translate(p.x, p.y + bob);
  ctx.rotate(p.pitch);
  ctx.scale(Bs, Bs);

  // Soft paper-cut shadow under the bird
  sh(ctx, 'rgba(58, 38, 18, 0.28)', 5, 3, dpr);

  // Back wing -> Body & Tucked Legs -> Near wing
  drawWing(ctx, -1, ph);
  drawBirdBody(ctx, ph, carry);
  drawWing(ctx, 1, ph);

  ctx.restore();
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  // Compute exact world coordinates of the bird's beak tip (local [0.73, -0.20])
  const bxLocal = 0.73;
  const byLocal = -0.2;
  const cosP = Math.cos(p.pitch);
  const sinP = Math.sin(p.pitch);
  const beakX = p.x + Bs * (bxLocal * cosP - byLocal * sinP);
  const beakY = p.y + bob + Bs * (bxLocal * sinP + byLocal * cosP);

  return {
    birdX: p.x,
    birdY: p.y + bob,
    beakX,
    beakY,
    pitch: p.pitch,
    rot: p.pitch * 0.45 - 0.12 + Math.sin(PI2 * wingPhaseMap(ph)) * 0.06,
  };
}

// Draw the perforated golden paper ticket
function drawTicket(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rot: number,
  w: number,
  alpha: number,
  scaleX = 1,
  dpr = 1
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.scale(scaleX, 1);
  const h = w * 0.52;

  sh(ctx, 'rgba(58, 38, 18, 0.28)', 4, 2, dpr);

  ctx.fillStyle = '#e8b865';
  ctx.beginPath();
  ctx.roundRect(-w / 2, -h / 2, w, h, w * 0.06);
  ctx.fill();

  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  ctx.strokeStyle = 'rgba(120, 80, 35, 0.48)';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Perforation line
  ctx.setLineDash([w * 0.04, w * 0.04]);
  ctx.beginPath();
  ctx.moveTo(-w * 0.2, -h * 0.42);
  ctx.lineTo(-w * 0.2, h * 0.42);
  ctx.stroke();
  ctx.setLineDash([]);

  // Ticket text lines
  ctx.strokeStyle = 'rgba(110, 70, 28, 0.55)';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(-w * 0.06, -h * 0.16);
  ctx.lineTo(w * 0.36, -h * 0.16);
  ctx.moveTo(-w * 0.06, h * 0.14);
  ctx.lineTo(w * 0.22, h * 0.14);
  ctx.stroke();

  ctx.restore();
}

// Draw the wax-sealed paper-cut envelope
function drawEnvelope(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rot: number,
  w: number,
  slide: number,
  alpha: number,
  dpr: number,
  anchorAtTop = false
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(cx, cy);
  ctx.rotate(rot);

  const h = w * 0.66;
  // When held in the bird's beak, anchor near the top edge of the envelope so the beak grips it directly!
  if (anchorAtTop) {
    ctx.translate(0, h * 0.44);
  }

  // Ticket peeking/sliding out of the envelope
  if (slide > 0) {
    drawTicket(ctx, 0, h * (0.12 - 1.02 * easeOutCubic(slide)), 0, w * 0.64, 1, 1, dpr);
  }

  sh(ctx, 'rgba(58, 38, 18, 0.32)', 5, 3, dpr);

  ctx.fillStyle = '#f8efdb';
  ctx.fillRect(-w / 2, -h / 2, w, h);

  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  ctx.strokeStyle = 'rgba(90, 64, 38, 0.42)';
  ctx.lineWidth = 1;
  ctx.strokeRect(-w / 2, -h / 2, w, h);

  // Envelope flap lines
  ctx.beginPath();
  ctx.moveTo(-w / 2, -h / 2);
  ctx.lineTo(0, h * 0.1);
  ctx.lineTo(w / 2, -h / 2);
  ctx.moveTo(-w / 2, h / 2);
  ctx.lineTo(-w * 0.14, h * 0.05);
  ctx.moveTo(w / 2, h / 2);
  ctx.lineTo(w * 0.14, h * 0.05);
  ctx.stroke();

  // Orange-red wax seal
  ctx.fillStyle = '#c8642d';
  ctx.beginPath();
  ctx.arc(0, h * 0.1, w * 0.09, 0, PI2);
  ctx.fill();

  ctx.restore();
}

// Render the complete bird + mail + ticket + dissolve sequence for time t
export function renderBirdAndMail(
  ctx: CanvasRenderingContext2D,
  t: number,
  ph: number,
  tg: DioramaTargets
): FrameCallbackState {
  const { W, H, dpr, girlBot, laptopX, laptopY } = tg;
  const u = Math.min(W, H) / 95;
  const Bs = clamp(12.2 * u, 68, 132);
  const envW = clamp(5.2 * u, 34, 56);
  const envH = envW * 0.66;

  const state: FrameCallbackState = {
    t,
    birdActive: t <= 8.2,
    birdX: 0,
    birdY: 0,
    mailDropped: t >= TR,
    envX: 0,
    envY: 0,
    ticketActive: false,
    ticketX: laptopX,
    ticketY: laptopY,
    ticketArrived: t >= TL,
    ticketArrivedTime: TL,
  };

  // Phase 1: Bird flies in from left carrying the envelope in its beak (t < TR)
  if (t < TR) {
    // Draw envelope first slightly behind upper beak, then bird, or bird then envelope gripped at beak
    const b = drawBird(ctx, t, ph, Bs, dpr, tg);
    state.birdX = b.birdX;
    state.birdY = b.birdY;

    // Envelope gripped right at (b.beakX, b.beakY)
    drawEnvelope(ctx, b.beakX, b.beakY, b.rot, envW, 0.18, 1, dpr, true);

    // Draw upper beak tip clamping over the top edge of the envelope for seamless realism
    ctx.save();
    ctx.translate(b.birdX, b.birdY);
    ctx.rotate(b.pitch);
    ctx.scale(Bs, Bs);
    ctx.fillStyle = '#dc8780';
    ctx.strokeStyle = 'rgba(68, 50, 32, 0.38)';
    ctx.lineWidth = 0.008;
    ctx.beginPath();
    ctx.moveTo(0.62, -0.26);
    ctx.quadraticCurveTo(0.7, -0.255, 0.77, -0.22);
    ctx.lineTo(0.62, -0.21);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    state.envX = b.beakX;
    state.envY = b.beakY + envH * 0.44;
    return state;
  }

  // Phase 2: Bird has released the envelope from its beak and flies up-right (t >= TR)
  if (t <= 8.4) {
    const b = drawBird(ctx, t, ph, Bs, dpr, tg);
    state.birdX = b.birdX;
    state.birdY = b.birdY;
  }

  // Compute exact beak position at the moment of release (t = TR) so drop starts seamlessly from beak
  const releasePose = getBirdPose(TR, tg);
  const cosR = Math.cos(releasePose.pitch);
  const sinR = Math.sin(releasePose.pitch);
  const releaseBeakX = releasePose.x + Bs * (0.73 * cosR - -0.2 * sinR);
  const releaseBeakY = releasePose.y + Bs * (0.73 * sinR + -0.2 * cosR);

  // Envelope center at t = TR (accounting for the top-edge anchor offset)
  const startEnvX = releaseBeakX - Math.sin(releasePose.pitch * 0.45 - 0.12) * (envH * 0.44);
  const startEnvY = releaseBeakY + Math.cos(releasePose.pitch * 0.45 - 0.12) * (envH * 0.44);

  const tau = t - TR;
  const k = 1.85;
  const groundY = girlBot - 10;
  const fallDist = Math.max(40, groundY - startEnvY);
  // Terminal-velocity air-resisted fall + gentle leaf-like sway
  const fallSpeed = fallDist / 1.45;
  const dy = fallSpeed * (tau - (1 - Math.exp(-k * tau)) / k);
  const landed = startEnvY + dy >= groundY;
  const ey = Math.min(startEnvY + dy, groundY);
  const sway = Math.sin(tau * 3.4) * 18 * Math.exp(-tau * 0.35) * (landed ? 0 : 1);
  const forwardDrift = 26 * (1 - Math.exp(-tau * 1.4));
  const ex = startEnvX + forwardDrift + sway;
  const er = landed ? -0.18 : Math.cos(tau * 3.4) * 0.42 * Math.exp(-tau * 0.3);

  state.envX = ex;
  state.envY = ey;

  const envAlpha = t < 9.8 ? 1 : clamp(1 - (t - 9.8) / 1.6);
  const slideProgress = clamp((t - (TR + 0.35)) / (TS - (TR + 0.35)));
  const ownsTicket = t < TS;

  if (envAlpha > 0) {
    drawEnvelope(ctx, ex, ey, er, envW, ownsTicket ? slideProgress : 0, envAlpha, dpr, false);
  }

  // Phase 3: Ticket peels out of the envelope and curves into the girl's laptop (TS <= t < TL)
  if (t >= TS && t < TL) {
    state.ticketActive = true;
    const tauS = TS - TR;
    const dyS = fallSpeed * (tauS - (1 - Math.exp(-k * tauS)) / k);
    const eyS = Math.min(startEnvY + dyS, groundY);
    const exS =
      startEnvX +
      26 * (1 - Math.exp(-tauS * 1.4)) +
      Math.sin(tauS * 3.4) * 18 * Math.exp(-tauS * 0.35);

    const P0: Vec2 = { x: exS, y: eyS - envH * 0.85 };
    const P1: Vec2 = { x: laptopX, y: laptopY };
    const C: Vec2 = {
      x: (P0.x + P1.x) * 0.5 - 38,
      y: Math.min(P0.y, P1.y) - 64,
    };

    const u = (t - TS) / (TL - TS);
    const e = easeInOutCubic(u);
    const q = quadBez(P0, C, P1, e);
    state.ticketX = q.x;
    state.ticketY = q.y;

    const rot = lerp(Math.sin(e * 4) * 0.45, -0.06, e);
    const tw = lerp(envW * 0.64, envW * 0.42, e);
    const sx = lerp(1, 0.78, e);
    drawTicket(ctx, q.x, q.y, rot, tw, 1, sx, dpr);
  }

  // Phase 4: Ticket dissolves into glowing paper sparkles on the laptop screen (TL <= t < TL + 1.15)
  if (t >= TL && t < TL + 1.15) {
    const e = (t - TL) / 1.15;
    const tw = envW * 0.45;
    for (let i = 0; i < 28; i++) {
      const sx = laptopX + (hash(i) - 0.5) * tw * 0.9;
      const sy = laptopY + (hash(i + 40) - 0.5) * tw * 0.45;
      const dl = hash(i + 80) * 0.38;
      const m = clamp((e - dl) / (1 - dl));
      const tx2 = laptopX + (hash(i + 120) - 0.5) * 44;
      const ty2 = laptopY + (hash(i + 160) - 0.5) * 36;
      ctx.globalAlpha = 1 - m;
      ctx.fillStyle = i % 3 ? '#e8b865' : '#7fe0a0';
      const s = (3.5 - 2.4 * m) * (u * 0.11);
      const px = lerp(sx, tx2, easeOutCubic(m)) - s / 2;
      const py = lerp(sy, ty2, easeOutCubic(m)) - s / 2 - Math.sin(m * Math.PI) * 16;
      ctx.fillRect(px, py, s, s);
    }
    ctx.globalAlpha = 1;
  }

  return state;
}
