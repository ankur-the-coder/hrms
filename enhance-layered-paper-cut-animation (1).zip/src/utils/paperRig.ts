/* ============================================================================
   paperRig.ts — the girl's body rig.
   Everything here is *motion only*: the paper-cut artwork itself is untouched.
   Coordinates are the girl's own 377 x 360 viewBox space.
   ========================================================================== */

import { TL } from './birdMailRenderer';

export const TAU = Math.PI * 2;

export const VB_W = 377;
export const VB_H = 360;
export const VB_TOP = -90; // head-room so the standing pose is never clipped
export const VB_FULL = 450;
export const GROUND_Y = 354;
export const HIP_SEATED = 62; // seated hip height above the ground line

export const HIP = { x: 218, y: 292 };
export const HIP_L = { x: 199, y: 290 };
export const HIP_R = { x: 237, y: 290 };

export const THIGH = 62;
export const SHIN = 58;
export const LEG_LEN = THIGH + SHIN;
export const KNEE_SLACK = 3.2; // keeps the stance leg from hyper-extending

export const UPPER_ARM = 46;
export const FORE_ARM = 48;
export const ARM_LEN = UPPER_ARM + FORE_ARM;

export const SHOULDER_L = { x: 152, y: 202 };
export const SHOULDER_R = { x: 284, y: 202 };

export const HAND_HOME_L = { x: 152, y: 278 };
export const HAND_HOME_R = { x: 282, y: 278 };

/* ---- film-clock timeline (seconds) ------------------------------------- */
export const GT = {
  enter: 0.22,
  walkEnd: 3.92,
  turnEnd: 4.44,
  sitEnd: 5.24,
  bookStart: 5.2,
  bookPeak: 5.62,
  bookEnd: 5.96,
  lapStart: 5.82,
  lapPeak: 6.12,
  lapEnd: 6.34,
  lidStart: 6.32,
  lidEnd: 6.82,
  typeStart: 6.9,
};

/* the throw is expressed relative to the moment the ticket lands (TL) */
export const TH = {
  cue: TL + 1.2, // 8.25 — she reaches for a paper plane
  grab: TL + 1.42,
  windEnd: TL + 1.76, // 8.81 — fully cocked
  release: TL + 2.0, // 9.05 — the plane leaves her hand
  followEnd: TL + 2.62,
  recoverEnd: TL + 3.6,
  watchEnd: TL + 5.5,
  gazeEnd: TL + 6.3,
};

export const PLANE_FLIGHT = 3.45;
export const LOOP_DURATION = TH.watchEnd + 4.0; // ≈ 16.5s

/* ---- small maths -------------------------------------------------------- */
export const clamp = (v: number, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const q = (n: number) => Math.round(n * 100) / 100;

export const smooth = (t: number) => {
  const c = clamp(t);
  return c * c * (3 - 2 * c);
};
export const ramp = (a: number, b: number, x: number) => smooth((x - a) / (b - a));
export const easeInOut = (t: number) => {
  const c = clamp(t);
  return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
};
export const easeOut = (t: number) => 1 - Math.pow(1 - clamp(t), 3);
export const easeIn = (t: number) => Math.pow(clamp(t), 2.2);
const easeOutBack = (t: number) => {
  const c = clamp(t) - 1;
  return 1 + 2.1 * c * c * c + 1.35 * c * c;
};

export interface Pt {
  x: number;
  y: number;
}

/* ---- keyframe track (piecewise smoothstep) ------------------------------ */
export function track(keys: [number, number][], t: number): number {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) {
    if (t <= keys[i + 1][0]) {
      const u = (t - keys[i][0]) / (keys[i + 1][0] - keys[i][0] || 1);
      return lerp(keys[i][1], keys[i + 1][1], smooth(u));
    }
  }
  return keys[keys.length - 1][1];
}

/* ---- two-bone IK -------------------------------------------------------- */
export function ik2(H: Pt, F: Pt, l1: number, l2: number, sign: number) {
  let dx = F.x - H.x;
  let dy = F.y - H.y;
  let d = Math.hypot(dx, dy);
  const maxD = l1 + l2 - 0.75;
  const minD = Math.abs(l1 - l2) + 0.75;
  if (d > maxD) {
    const s = maxD / (d || 1);
    dx *= s;
    dy *= s;
    d = maxD;
  } else if (d < minD) {
    const s = minD / (d || 1);
    dx *= s;
    dy *= s;
    d = minD;
  }
  const F2 = { x: H.x + dx, y: H.y + dy };
  const a = Math.atan2(dy, dx);
  const cosT = clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1);
  const ang = a + sign * Math.acos(cosT);
  return {
    mid: { x: H.x + Math.cos(ang) * l1, y: H.y + Math.sin(ang) * l1 },
    end: F2,
    ang,
  };
}

/* ---- paper-cut limb shapes --------------------------------------------- */
export function limbPath(a: Pt, b: Pt, wa: number, wb: number): string {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const L = Math.hypot(dx, dy) || 0.001;
  const ux = dx / L;
  const uy = dy / L;
  const nx = -uy;
  const ny = ux;
  const a1x = a.x + nx * wa * 0.5;
  const a1y = a.y + ny * wa * 0.5;
  const a2x = a.x - nx * wa * 0.5;
  const a2y = a.y - ny * wa * 0.5;
  const b1x = b.x + nx * wb * 0.5;
  const b1y = b.y + ny * wb * 0.5;
  const b2x = b.x - nx * wb * 0.5;
  const b2y = b.y - ny * wb * 0.5;
  const atx = a.x - ux * wa * 0.5;
  const aty = a.y - uy * wa * 0.5;
  const btx = b.x + ux * wb * 0.5;
  const bty = b.y + uy * wb * 0.5;
  return (
    `M${q(a1x)} ${q(a1y)}L${q(b1x)} ${q(b1y)}` +
    `Q${q(btx)} ${q(bty)} ${q(b2x)} ${q(b2y)}` +
    `L${q(a2x)} ${q(a2y)}Q${q(atx)} ${q(aty)} ${q(a1x)} ${q(a1y)}Z`
  );
}

export function shoePath(ank: Pt, pitch: number, sc: number): [string, string] {
  const a = Math.PI + pitch; // toe points toward -x (she faces left while walking)
  const tx = Math.cos(a);
  const ty = Math.sin(a);
  const toe = { x: ank.x + tx * 27 * sc, y: ank.y + ty * 27 * sc };
  const body = limbPath(ank, toe, 19 * sc, 14 * sc);
  const p1 = { x: ank.x + tx * 9 * sc, y: ank.y + ty * 9 * sc + 5.5 * sc };
  const p2 = { x: toe.x + tx * 1.5 * sc, y: toe.y + 5 * sc };
  const sole = limbPath(p1, p2, 13 * sc, 11 * sc);
  return [body, sole];
}

/* ========================================================================
   WALK CYCLE
   Cadence is solved from the real travel distance so the stance foot is
   planted — no moonwalking, no sliding, on any screen size.
   ======================================================================== */
export interface WalkParams {
  f: number; // step-pair cycles per second
  amp: number; // half-stride in local units
  speed: number;
  stanceFrac: number;
}

export function walkParams(dist: number, dur: number): WalkParams {
  const stanceFrac = 0.62;
  const speed = dist / Math.max(0.2, dur);
  const maxAmp = LEG_LEN * 0.42;
  let f = 1.5;
  let amp = maxAmp;
  // The half-stride must equal exactly half of the furthest the body travels
  // during any single stance — otherwise the planted foot would skate.
  for (let it = 0; it < 10; it++) {
    const win = Math.min(0.999, stanceFrac / f / Math.max(0.2, dur));
    let maxDelta = 0;
    for (let u = 0; u + win <= 1.0001; u += 0.004) {
      maxDelta = Math.max(maxDelta, progAt(u + win) - progAt(u));
    }
    amp = (maxDelta * dist) / 2;
    if (amp <= maxAmp || f > 4) {
      if (amp > maxAmp) amp = maxAmp;
      break;
    }
    f *= amp / maxAmp;
  }
  return { f, amp, speed, stanceFrac };
}

/* Root travel profile — eases out of the frame, cruises, eases to a
   standstill exactly on her mark. Integrated once, then looked up. */
const PROG_N = 240;
const speedProfile = (u: number) =>
  (0.72 + 0.28 * smooth(u / 0.14)) * (1 - 0.5 * smooth((u - 0.82) / 0.18));
const progTable = (() => {
  const tbl = new Float32Array(PROG_N + 1);
  let acc = 0;
  for (let i = 1; i <= PROG_N; i++) {
    acc += 0.5 * (speedProfile((i - 1) / PROG_N) + speedProfile(i / PROG_N)) / PROG_N;
    tbl[i] = acc;
  }
  const norm = acc || 1;
  for (let i = 0; i <= PROG_N; i++) tbl[i] /= norm;
  return tbl;
})();

function progAt(u: number) {
  const c = clamp(u);
  const g = c * PROG_N;
  const i = Math.min(PROG_N - 1, Math.floor(g));
  return lerp(progTable[i], progTable[i + 1], g - i);
}

export function rootXAt(t: number, dist: number) {
  if (t <= GT.enter) return dist;
  if (t >= GT.walkEnd) return 0;
  return dist * (1 - progAt((t - GT.enter) / (GT.walkEnd - GT.enter)));
}

interface FootState {
  x: number;
  lift: number;
  grounded: boolean;
  u: number;
}

/* ========================================================================
   POSE
   ======================================================================== */
export interface LegPose {
  hip: Pt;
  knee: Pt;
  ankle: Pt;
  pitch: number;
  thigh: string;
  thighShade: string;
  shin: string;
  shoe: string;
  sole: string;
}

export interface ArmPose {
  sh: Pt;
  elbow: Pt;
  hand: Pt;
  upper: string;
  upperShade: string;
  fore: string;
  cuff: string;
  handDx: number;
  handDy: number;
  handRot: number;
}

export type GirlPhase =
  | 'hidden'
  | 'walk'
  | 'turn'
  | 'sit'
  | 'settle'
  | 'type'
  | 'throw'
  | 'watch'
  | 'back';

export interface GirlPose {
  rootX: number;
  rootY: number;
  rootSX: number;
  rootRot: number;
  chestRot: number;
  chestX: number;
  chestY: number;
  headRot: number;
  headX: number;
  headY: number;
  hairRot: number;
  legs: [LegPose, LegPose];
  rigLegAlpha: number;
  sitLegAlpha: number;
  arms: [ArmPose, ArmPose];
  bookX: number;
  bookY: number;
  bookRot: number;
  lapX: number;
  lapY: number;
  lapRot: number;
  lapScale: number;
  lapStowed: number; // 1 = under her arm (behind her), 0 = on her lap (in front)
  lid: number;
  phase: GirlPhase;
  planeHand: { x: number; y: number; rot: number } | null;
  stepL: number; // 1 on the frame the left heel strikes
  stepR: number;
  phaseL: number;
  phaseR: number;
  bounce: number; // 0..1 impact for the sit-down
}

/* --- sit-down targets (match the pre-cut crossed-leg artwork) ------------- */
const SIT_KNEE_L = { x: 165, y: 324 };
const SIT_ANK_L = { x: 218, y: 338 };
const SIT_KNEE_R = { x: 290, y: 318 };
const SIT_ANK_R = { x: 240, y: 342 };
const SIT_PITCH_L = 0.3;
const SIT_PITCH_R = -0.3;

/* --- carried-prop transforms (offsets from their final "home" place) ------ */
const BOOK_HOME = { x: 71, y: 319 };
const BOOK_CARRY = { x: 120, y: 254 };
const BOOK_GRIP = { x: 42, y: 4 }; // where her left hand actually holds the stack
const LAP_HOME = { x: 216, y: 291 }; // hinge/slab centre of the closed laptop
const LAP_CARRY = { x: 276, y: 256 };
const LAP_CARRY_SCALE = 0.78;
const LAP_GRIP = { x: 20, y: -16 }; // right hand clamps the shut lid's near edge

function rotateAbout(p: Pt, c: Pt, deg: number): Pt {
  const r = (deg * Math.PI) / 180;
  const dx = p.x - c.x;
  const dy = p.y - c.y;
  return {
    x: c.x + dx * Math.cos(r) - dy * Math.sin(r),
    y: c.y + dx * Math.sin(r) + dy * Math.cos(r),
  };
}

export function computeGirlPose(
  t: number,
  dist: number,
  prevStep: { l: number; r: number }
): GirlPose {
  const walkDur = GT.walkEnd - GT.enter;
  const wp = walkParams(dist, walkDur);
  const rootX = rootXAt(t, dist);

  /* ---------- walk cycle (stance foot is analytically planted) ---------- */
  const cyc = t * wp.f;
  const pL = ((cyc % 1) + 1) % 1;
  const pR = (((cyc + 0.5) % 1) + 1) % 1;
  const active = t >= GT.enter && t < GT.turnEnd;
  const stanceDur = wp.stanceFrac / wp.f;
  const standBlend = ramp(GT.walkEnd, GT.walkEnd + 0.42, t);

  const footCycleExact = (p: number, side: -1 | 1): FootState => {
    if (!active) return { x: side * 13, lift: 0, grounded: true, u: 0 };
    let x: number;
    let lift = 0;
    let grounded: boolean;
    let u: number;
    if (p < wp.stanceFrac) {
      u = p / wp.stanceFrac;
      const ths = t - p / wp.f;
      x = rootXAt(ths, dist) - rootXAt(t, dist) - wp.amp;
      grounded = true;
    } else {
      u = (p - wp.stanceFrac) / (1 - wp.stanceFrac);
      const ths = t - p / wp.f;
      const toeOff = rootXAt(ths, dist) - rootXAt(ths + stanceDur, dist) - wp.amp;
      x = lerp(toeOff, -wp.amp, easeInOut(u));
      lift = Math.sin(Math.PI * Math.pow(u, 0.85)) * 27 * (1 - standBlend);
      grounded = false;
    }
    // come to a natural standstill with the feet side by side
    x = lerp(x, side * 13, standBlend);
    lift *= 1 - standBlend;
    grounded = grounded || standBlend > 0.5;
    return { x, lift, grounded, u };
  };

  const fL = footCycleExact(pL, -1);
  const fR = footCycleExact(pR, 1);

  /* ---------- hip height (natural walk bob, lowest at double support) ---------- */
  const hOf = (fx: number) =>
    Math.sqrt(Math.max(16, LEG_LEN * LEG_LEN - fx * fx)) - KNEE_SLACK;
  let standH = LEG_LEN - KNEE_SLACK;
  if (fL.grounded) standH = Math.min(standH, hOf(fL.x));
  if (fR.grounded) standH = Math.min(standH, hOf(fR.x));

  /* ---------- sit blend ---------- */
  const sitB = easeInOut(ramp(GT.turnEnd, GT.sitEnd, t));
  const sitDone = t >= GT.sitEnd;
  const hipH = lerp(standH, HIP_SEATED, sitB);
  let rootY = HIP_SEATED - hipH;

  // settle bounce the instant her hips meet the floor
  let bounce = 0;
  if (t >= GT.sitEnd && t < GT.sitEnd + 0.7) {
    const d = t - GT.sitEnd;
    bounce = Math.exp(-d * 8) * Math.sin(d * 17);
    rootY += bounce * 3.4;
  }

  /* ---------- root turn-to-camera ---------- */
  // A paper cut-out can't really rotate in 3D, so the "turn" is a gentle
  // horizontal un-squash that starts while she is still finishing her last
  // stride — never a snap on the spot.
  const sx0 = 0.86;
  const turnU = easeInOut(ramp(GT.walkEnd - 0.95, GT.turnEnd, t));
  const rootSX = lerp(sx0, 1, turnU);
  let rootRot = -1.6 * clamp((t - GT.enter) / 0.35) * (1 - turnU);

  /* ---------- chest ---------- */
  const stepBob = active ? Math.cos(TAU * pL * 2) * 2.6 : 0;
  const sway = active ? Math.sin(TAU * pL) * 3.1 : 0;
  let chestRot = active ? -5.2 * clamp((t - GT.enter) / 0.4) : 0;
  chestRot = lerp(chestRot, 0, ramp(GT.walkEnd - 0.3, GT.turnEnd, t));
  let chestX = sway * 0.5;
  let chestY = stepBob * 0.55;

  // sit: fold forward a touch, then straighten
  chestRot += Math.sin(Math.PI * clamp(ramp(GT.turnEnd, GT.sitEnd, t))) * 7;
  // placing the books: lean down-left
  const bookLean = Math.sin(Math.PI * clamp(ramp(GT.bookStart - 0.1, GT.bookEnd + 0.42, t)));
  chestRot += -18 * bookLean;
  chestX += -9 * bookLean;
  chestY += 7 * bookLean;
  // setting the laptop on her lap: small lean
  const lapLean = Math.sin(Math.PI * clamp(ramp(GT.lapStart, GT.lapEnd + 0.35, t)));
  chestRot += -4 * lapLean;
  // opening the lid: rise up a little
  const lidLean = Math.sin(Math.PI * clamp(ramp(GT.lidStart, GT.lidEnd + 0.25, t)));
  chestRot += 3 * lidLean;

  // idle typing life
  const idle = t > GT.typeStart ? 1 : 0;
  chestRot += idle ? Math.sin(t * 1.35) * 1.15 : 0;
  chestY += idle ? Math.sin(t * 2.1) * 0.9 : 0;

  /* ---------- the throw: hips, torso, shoulders and head all take part ----------
     Wind-up loads the body back and down; the release unwinds it forward and
     up; the follow-through carries past centre before it settles. The arm is
     the last link in that chain, never the only one moving. */
  let twist = 0;
  let twistX = 0;
  let twistY = 0;
  let throwRoot = 0;
  let counterL = 0; // how far the free arm swings out to balance her
  if (t >= TH.cue) {
    if (t < TH.windEnd) {
      const u = easeOut(ramp(TH.cue, TH.windEnd, t));
      twist = 21 * u;      // coils back over her right hip
      twistX = 9 * u;
      twistY = 4 * u;      // and sinks down into the load
      throwRoot = 3.4 * u;
      counterL = u;
    } else if (t < TH.release) {
      const u = Math.pow((t - TH.windEnd) / (TH.release - TH.windEnd), 0.6);
      twist = lerp(21, -24, u);
      twistX = lerp(9, -13, u);
      twistY = lerp(4, -7, u); // rises up out of the throw
      throwRoot = lerp(3.4, -3.8, u);
      counterL = lerp(1, -1, u);
    } else if (t < TH.followEnd) {
      const u = easeOut(ramp(TH.release, TH.followEnd, t));
      twist = lerp(-24, -9, u);
      twistX = lerp(-13, -5, u);
      twistY = lerp(-7, -1, u);
      throwRoot = lerp(-3.8, -1.2, u);
      counterL = lerp(-1, -0.35, u);
    } else {
      const u = easeInOut(ramp(TH.followEnd, TH.recoverEnd, t));
      twist = lerp(-9, 0, u);
      twistX = lerp(-5, 0, u);
      twistY = lerp(-1, 0, u);
      throwRoot = lerp(-1.2, 0, u);
      counterL = lerp(-0.35, 0, u);
    }
  }
  chestRot += twist;
  chestX += twistX;
  chestY += twistY;
  rootRot += throwRoot;

  /* ---------- head (secondary motion, lagged) ---------- */
  const headLag = active ? Math.sin(TAU * pL - 0.7) * 1.5 : 0;
  let headRot = -chestRot * 0.3 + headLag;
  const headY = -stepBob * 0.3 + (active ? Math.abs(Math.sin(TAU * pL)) * -1.2 : 0);
  const headX = -sway * 0.22;
  // throw: cock the head back with the wind-up, snap it after the release, recover
  let headThrow = 0;
  if (t >= TH.cue && t < TH.windEnd) headThrow = 10 * easeOut(ramp(TH.cue, TH.windEnd, t));
  else if (t >= TH.windEnd && t < TH.release + 0.18)
    headThrow = lerp(10, -13, Math.pow(clamp((t - TH.windEnd) / (TH.release + 0.18 - TH.windEnd)), 0.6));
  else if (t >= TH.release + 0.18 && t < TH.recoverEnd)
    headThrow = -13 * (1 - easeInOut(ramp(TH.release + 0.18, TH.recoverEnd, t)));
  headRot += headThrow;

  // hair follows with a lag
  const hairRot =
    -headRot * 0.22 +
    (active ? Math.sin(TAU * pL - 1.35) * 2.4 : 0) -
    headThrow * 0.35;

  /* ---------- legs (drawn outside the hip-lift group, so feet stay planted) ---------- */
  const footYBase = HIP.y + rootY + hipH; // === GROUND_Y while she is upright
  const hipDy = rootY;
  const legBlendSit = sitB;

  const buildLeg = (
    hipPt: Pt,
    fx: number,
    lift: number,
    grounded: boolean,
    u: number,
    side: -1 | 1
  ): LegPose => {
    // walking / standing foot target (root-local)
    const H = { x: hipPt.x, y: hipPt.y + hipDy };
    const walkAnk = { x: H.x + fx, y: footYBase - lift };
    const walkIk = ik2(H, walkAnk, THIGH, SHIN, 1);
    // seated target
    const sitKnee = side === -1 ? SIT_KNEE_L : SIT_KNEE_R;
    const sitAnk = side === -1 ? SIT_ANK_L : SIT_ANK_R;
    const knee = {
      x: lerp(walkIk.mid.x, sitKnee.x, legBlendSit),
      y: lerp(walkIk.mid.y, sitKnee.y, legBlendSit),
    };
    const ankle = {
      x: lerp(walkIk.end.x, sitAnk.x, legBlendSit),
      y: lerp(walkIk.end.y, sitAnk.y, legBlendSit),
    };
    let walkPitch: number;
    if (grounded) walkPitch = lerp(-0.26, 0.4, u);
    else walkPitch = lerp(0.4, -0.22, u) - 0.1;
    // a touch of ankle follow-through from the shin
    const shinAng = Math.atan2(ankle.y - knee.y, ankle.x - knee.x);
    walkPitch += (shinAng - Math.PI / 2) * -0.14;
    const pitch = lerp(walkPitch, side === -1 ? SIT_PITCH_L : SIT_PITCH_R, legBlendSit);

    // A real leg tapers: full at the hip, narrowing through the knee, slim at
    // the ankle. The thigh also starts well up inside the sweater hem so the
    // hip never reads as a stick socketed into the body.
    const dl = Math.hypot(knee.x - H.x, knee.y - H.y) || 1;
    const ux = (knee.x - H.x) / dl;
    const uy = (knee.y - H.y) / dl;
    const Hx = { x: H.x - ux * 30, y: H.y - uy * 30 };
    const Kn = { x: knee.x, y: knee.y };
    // thigh: full at the hip, softly narrowing to the knee
    const thigh = limbPath(Hx, Kn, 56, 38);
    const thighShade = limbPath(
      { x: Hx.x + 5, y: Hx.y + 7 },
      { x: Kn.x + 4, y: Kn.y + 4 },
      30,
      20
    );
    // calf: swells just below the knee, then tapers into a slim ankle
    const cx2 = lerp(Kn.x, ankle.x, 0.4);
    const cy2 = lerp(Kn.y, ankle.y, 0.4);
    const shin =
      limbPath(Kn, { x: cx2, y: cy2 }, 40, 38) +
      limbPath({ x: cx2, y: cy2 }, ankle, 38, 24);
    const sc = side === -1 ? 1.16 : 1.1;
    const [shoe, sole] = shoePath(ankle, pitch, sc);
    return { hip: H, knee, ankle, pitch, thigh, thighShade, shin, shoe, sole };
  };

  const legs: [LegPose, LegPose] = [
    buildLeg(HIP_L, fL.x, fL.lift, fL.grounded, fL.u, -1),
    buildLeg(HIP_R, fR.x, fR.lift, fR.grounded, fR.u, 1),
  ];

  const rigLegAlpha = sitDone ? Math.max(0, 1 - ramp(GT.sitEnd, GT.sitEnd + 0.24, t)) : 1;
  const sitLegAlpha = sitDone ? ramp(GT.sitEnd - 0.06, GT.sitEnd + 0.24, t) : 0;

  /* ---------- props ---------- */
  // book stack: carried against her chest → set down on the ground beside her
  const bookT = clamp((t - GT.bookStart) / (GT.bookEnd - GT.bookStart));
  let bookCx: number;
  let bookCy: number;
  let bookRot: number;
  if (t < GT.bookStart) {
    bookCx = BOOK_CARRY.x;
    bookCy = BOOK_CARRY.y;
    bookRot = -7 + Math.sin(TAU * pL) * 1.6 * (active ? 1 : 0);
  } else {
    const e = easeInOut(bookT);
    // lift slightly, carry across, set down with a small overshoot
    bookCx = lerp(BOOK_CARRY.x, BOOK_HOME.x, e) - Math.sin(Math.PI * e) * 8;
    bookCy =
      lerp(BOOK_CARRY.y, BOOK_HOME.y, e) - Math.sin(Math.PI * Math.min(1, e * 1.25)) * 22;
    bookRot = lerp(-7, 0, e);
    if (bookT >= 1) {
      const d = t - GT.bookEnd;
      bookCy += Math.exp(-d * 9) * Math.sin(d * 19) * 2.6;
      bookRot += Math.exp(-d * 8) * Math.sin(d * 15) * 1.6;
    }
  }

  // laptop: tucked under her right arm → onto her lap → lid opens
  const lapT = clamp((t - GT.lapStart) / (GT.lapEnd - GT.lapStart));
  let lapCx: number;
  let lapCy: number;
  let lapRot: number;
  let lapScale: number;
  if (t < GT.lapStart) {
    lapCx = LAP_CARRY.x;
    lapCy = LAP_CARRY.y;
    lapRot = -11 + Math.sin(TAU * pL + 0.6) * 1.4 * (active ? 1 : 0);
    lapScale = LAP_CARRY_SCALE;
  } else {
    const e = easeInOut(lapT);
    lapCx = lerp(LAP_CARRY.x, LAP_HOME.x, e) - Math.sin(Math.PI * e) * 12;
    lapCy = lerp(LAP_CARRY.y, LAP_HOME.y, e) - Math.sin(Math.PI * Math.min(1, e * 1.2)) * 16;
    lapRot = lerp(-11, 0, e);
    lapScale = lerp(LAP_CARRY_SCALE, 1, e);
    if (lapT >= 1) {
      const d = t - GT.lapEnd;
      lapCy += Math.exp(-d * 10) * Math.sin(d * 21) * 2.2;
    }
  }
  // it swaps from behind her body to in front the instant it lands on her lap
  const lapStowed = 1 - ramp(GT.lapStart + (GT.lapEnd - GT.lapStart) * 0.55, GT.lapEnd, t);
  const lid = t < GT.lidStart ? 0 : easeOutBack(ramp(GT.lidStart, GT.lidEnd, t));

  /* ---------- arms ---------- */
  // hand targets authored in root space, then converted into chest space
  const handLRoot = handTargetL(t, bookCx, bookCy, active ? pL : 0, counterL);
  const handRRoot = handTargetR(t, lapCx, lapCy, lid, active ? pR : 0);

  // hand targets are authored in body space — the same space the artwork and
  // the carried props live in, so the fingers always meet what they hold
  const toChest = (p: Pt) => rotateAbout({ x: p.x - chestX, y: p.y - chestY }, HIP, -chestRot);
  const chestToVB = (p: Pt): Pt => {
    const b = rotateAbout(p, HIP, chestRot);
    const body = { x: b.x + chestX, y: b.y + chestY + rootY };
    const dx = (body.x - HIP.x) * rootSX;
    const dy = body.y - (GROUND_Y);
    const r = (rootRot * Math.PI) / 180;
    return {
      x: HIP.x + rootX + dx * Math.cos(r) - dy * Math.sin(r),
      y: GROUND_Y + dx * Math.sin(r) + dy * Math.cos(r),
    };
  };

  const buildArm = (
    sh: Pt,
    handRoot: Pt,
    side: -1 | 1,
    handHome: Pt
  ): ArmPose => {
    const hand = toChest(handRoot);
    const r = ik2(sh, hand, UPPER_ARM, FORE_ARM, 1);
    const upper = limbPath(sh, r.mid, 23, 19);
    const upperShade = limbPath(
      { x: sh.x + 2.5, y: sh.y + 4 },
      { x: r.mid.x + 2.5, y: r.mid.y + 3 },
      12,
      9
    );
    const fore = limbPath(r.mid, r.end, 18, 14);
    const cuff = limbPath(
      { x: lerp(r.mid.x, r.end.x, 0.78), y: lerp(r.mid.y, r.end.y, 0.78) },
      r.end,
      17,
      15
    );
    const ang = Math.atan2(r.end.y - r.mid.y, r.end.x - r.mid.x);
    return {
      sh,
      elbow: r.mid,
      hand: r.end,
      upper,
      upperShade,
      fore,
      cuff,
      handDx: r.end.x - handHome.x,
      handDy: r.end.y - handHome.y,
      handRot: (ang * 180) / Math.PI - 90 + (side === -1 ? 12 : -12),
    };
  };

  const armL = buildArm(SHOULDER_L, handLRoot, -1, HAND_HOME_L);
  const armR = buildArm(SHOULDER_R, handRRoot, 1, HAND_HOME_R);

  /* ---------- the plane in her hand ---------- */
  let planeHand: GirlPose['planeHand'] = null;
  if (t >= TH.cue + 0.06 && t <= TH.release + 0.03) {
    const p = chestToVB(armR.hand);
    const el = chestToVB(armR.elbow);
    const ang = Math.atan2(p.y - el.y, p.x - el.x);
    planeHand = {
      x: p.x + Math.cos(ang) * 15,
      y: p.y + Math.sin(ang) * 15 - 4,
      rot: (ang * 180) / Math.PI,
    };
  }


  /* ---------- footstep events (heel strike = phase wrap) ---------- */
  const strike = (p: number, prev: number) =>
    active && prev > 0.72 && p < 0.3 && p < prev ? 1 : 0;
  const stepL = strike(pL, prevStep.l);
  const stepR = strike(pR, prevStep.r);

  let phase: GirlPhase = 'hidden';
  if (t < GT.enter) phase = 'hidden';
  else if (t < GT.walkEnd) phase = 'walk';
  else if (t < GT.turnEnd) phase = 'turn';
  else if (t < GT.sitEnd) phase = 'sit';
  else if (t < GT.typeStart) phase = 'settle';
  else if (t < TH.cue) phase = 'type';
  else if (t < TH.release + 0.1) phase = 'throw';
  else if (t < TH.watchEnd) phase = 'watch';
  else if (t < TH.gazeEnd) phase = 'back';
  else phase = 'type';

  return {
    rootX,
    rootY,
    rootSX,
    rootRot,
    chestRot,
    chestX,
    chestY,
    headRot,
    headX,
    headY,
    hairRot,
    legs,
    rigLegAlpha,
    sitLegAlpha,
    arms: [armL, armR],
    bookX: bookCx - BOOK_HOME.x,
    bookY: bookCy - BOOK_HOME.y,
    bookRot,
    lapX: lapCx - LAP_HOME.x,
    lapY: lapCy - LAP_HOME.y,
    lapRot,
    lapScale,
    lapStowed,
    lid,
    phase,
    planeHand,
    stepL,
    stepR,
    phaseL: pL,
    phaseR: pR,
    bounce: Math.abs(bounce),
  };
}

/* ---- hand targets ------------------------------------------------------- */
function handTargetL(t: number, bookX: number, bookY: number, p: number, counter: number): Pt {
  const bob = Math.sin(TAU * p) * 2.2;
  // she grips the stack at its right edge the whole way — carry and set-down
  const grip = { x: bookX + BOOK_GRIP.x, y: bookY + BOOK_GRIP.y };
  if (t < GT.bookEnd + 0.05) return { x: grip.x, y: grip.y + bob * 0.5 };

  // withdraws and settles beside the laptop
  const back = easeInOut(ramp(GT.bookEnd, GT.lapEnd + 0.1, t));
  const rest = {
    x: lerp(grip.x, HAND_HOME_L.x, back),
    y: lerp(grip.y, HAND_HOME_L.y, back),
  };
  if (counter === 0) return rest;
  // counterbalance: the free arm sweeps out and back as she throws
  return {
    x: rest.x + counter * -26 + Math.abs(counter) * -6,
    y: rest.y + counter * -34 - Math.abs(counter) * 10,
  };
}

function handTargetR(
  t: number,
  lapX: number,
  lapY: number,
  lid: number,
  p: number
): Pt {
  const bob = Math.sin(TAU * p + 0.6) * 2.0;
  if (t < TH.cue) {
    if (t < GT.lapStart) {
      // right hand clamps the shut lid's top edge against her hip
      return { x: lapX + LAP_GRIP.x, y: lapY + LAP_GRIP.y + bob * 0.6 };
    }
    if (t < GT.lidStart) {
      // guides the laptop onto her lap
      const e = easeInOut(ramp(GT.lapStart, GT.lidStart, t));
      return {
        x: lerp(lapX + LAP_GRIP.x, 292, e),
        y: lerp(lapY + LAP_GRIP.y, 280, e),
      };
    }
    if (t < GT.lidEnd + 0.1) {
      // fingers hooked under the lid's right edge, lifting it up and away
      const e = clamp((lid - 0.02) / 0.98);
      return { x: 292 + 10 * e, y: 280 - 48 * e };
    }
    return { x: HAND_HOME_R.x, y: HAND_HOME_R.y };
  }

  /* ---- the throw ---- */
  if (t < TH.grab) {
    const e = ramp(TH.cue, TH.grab, t);
    return { x: lerp(HAND_HOME_R.x, 316, e), y: lerp(HAND_HOME_R.y, 236, easeOut(e)) };
  }
  if (t < TH.windEnd) {
    const e = ramp(TH.grab, TH.windEnd, t);
    return { x: lerp(316, 350, easeOut(e)), y: lerp(236, 152, easeOut(e)) };
  }
  if (t < TH.release) {
    // the whip: hand sweeps up and across to the left, elbow leads
    const e = (t - TH.windEnd) / (TH.release - TH.windEnd);
    const ee = Math.pow(e, 0.72);
    return { x: lerp(350, 244, ee), y: lerp(152, 124, Math.sin(Math.PI * 0.5 * ee)) };
  }
  if (t < TH.followEnd) {
    const e = easeOut(ramp(TH.release, TH.followEnd, t));
    return { x: lerp(244, 202, e), y: lerp(124, 214, e) };
  }
  const e = easeInOut(ramp(TH.followEnd, TH.recoverEnd, t));
  return { x: lerp(202, HAND_HOME_R.x, e), y: lerp(214, HAND_HOME_R.y, e) };
}

/* ========================================================================
   PAPER PLANE — thrown up-left, one quick loop, then out to the right.
   Catmull-Rom spline + arc-length parameterisation + a speed profile so
   the launch is fast, the loop hangs, and the exit accelerates.
   ======================================================================== */
const cr = (p0: number, p1: number, p2: number, p3: number, t: number) => {
  const t2 = t * t;
  const t3 = t2 * t;
  return (
    0.5 *
    (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
  );
};

export interface PlanePath {
  at(u: number): { x: number; y: number; ang: number; sc: number };
  duration: number;
}

export function buildPlanePath(hx: number, hy: number, W: number, H: number): PlanePath {
  const pts: Pt[] = [
    { x: hx + 0.014 * W, y: hy + 0.03 * H },
    { x: hx, y: hy },
    { x: hx - 0.072 * W, y: hy - 0.145 * H },
    { x: hx - 0.15 * W, y: hy - 0.275 * H },
    { x: hx - 0.2 * W, y: hy - 0.385 * H },
    { x: hx - 0.172 * W, y: hy - 0.462 * H },
    { x: hx - 0.086 * W, y: hy - 0.478 * H },
    { x: hx - 0.034 * W, y: hy - 0.412 * H },
    { x: hx - 0.078 * W, y: hy - 0.342 * H },
    { x: hx - 0.012 * W, y: hy - 0.312 * H },
    { x: hx + 0.15 * W, y: hy - 0.372 * H },
    { x: Math.max(hx + 0.3 * W, W * 0.74), y: hy - 0.45 * H },
    { x: W + 150, y: hy - 0.52 * H },
    { x: W + 280, y: hy - 0.56 * H },
  ];

  const N = pts.length - 1;
  const SAMPLES = 26 * N;
  const xs = new Float32Array(SAMPLES + 1);
  const ys = new Float32Array(SAMPLES + 1);
  const seg = (i: number, t: number) => {
    const i0 = Math.max(0, i - 1);
    const i3 = Math.min(N, i + 2);
    return {
      x: cr(pts[i0].x, pts[i].x, pts[i + 1].x, pts[i3].x, t),
      y: cr(pts[i0].y, pts[i].y, pts[i + 1].y, pts[i3].y, t),
    };
  };
  for (let s = 0; s <= SAMPLES; s++) {
    const g = (s / SAMPLES) * N;
    const i = Math.min(N - 1, Math.floor(g));
    const p = seg(i, g - i);
    xs[s] = p.x;
    ys[s] = p.y;
  }

  // arc length
  const cum = new Float32Array(SAMPLES + 1);
  let total = 0;
  for (let s = 1; s <= SAMPLES; s++) {
    total += Math.hypot(xs[s] - xs[s - 1], ys[s] - ys[s - 1]);
    cum[s] = total;
  }

  // speed profile: explosive launch → hanging loop → accelerating exit
  const speed = (s: number) =>
    0.42 + 1.85 * Math.exp(-4.1 * s) + 0.62 * smooth((s - 0.62) / 0.38);
  const timeCum = new Float32Array(SAMPLES + 1);
  let tt = 0;
  for (let s = 1; s <= SAMPLES; s++) {
    const ds = (cum[s] - cum[s - 1]) / (total || 1);
    const sm = 0.5 * (speed(cum[s - 1] / (total || 1)) + speed(cum[s] / (total || 1)));
    tt += ds / sm;
    timeCum[s] = tt;
  }

  const duration = PLANE_FLIGHT;
  const scale = duration / (tt || 1);

  const at = (u: number) => {
    const uu = clamp(u);
    const target = uu * tt;
    let lo = 0;
    let hi = SAMPLES;
    while (lo < hi - 1) {
      const mid = (lo + hi) >> 1;
      if (timeCum[mid] < target) lo = mid;
      else hi = mid;
    }
    const span = timeCum[hi] - timeCum[lo] || 1;
    const f = (target - timeCum[lo]) / span;
    const idx = lo + f;
    const i0 = Math.floor(idx);
    const i1 = Math.min(SAMPLES, i0 + 1);
    const g = idx - i0;
    const x = lerp(xs[i0], xs[i1], g);
    const y = lerp(ys[i0], ys[i1], g);
    const k = Math.min(SAMPLES, i0 + 3);
    const k0 = Math.max(0, i0 - 3);
    const ang = Math.atan2(ys[k] - ys[k0], xs[k] - xs[k0]);
    const sFrac = cum[i0] / (total || 1);
    const v = speed(sFrac);
    return {
      x,
      y,
      ang,
      sc: clamp(0.42 + 0.58 * Math.min(1, u * 7), 0, 1) * (0.86 + 0.2 * Math.min(1, v)),
    };
  };

  void scale;
  return { at, duration };
}
