/* ============================================================================
   PaperScore — every sound in the diorama is synthesised on the fly, so there
   is nothing to download, nothing to decode and nothing that can stall a frame.
   Voices are scheduled against AudioContext time (never the rAF clock), which
   keeps them sample-accurate and completely decoupled from render load.
   ========================================================================== */

const PENT = [1, 9 / 8, 5 / 4, 3 / 2, 5 / 3, 2, 9 / 4]; // A major pentatonic ratios
const CHORDS = [
  [0, 2, 4], // A
  [3, 5, 0], // D (as 6/5 of A → sub-dominant colour)
  [1, 3, 5], // Bm-ish
  [4, 6, 1], // E
];

export class PaperScore {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private dry: GainNode | null = null;
  private wet: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private ambienceOn = false;
  private voices = 0;
  private nextChirp = 0;
  private nextPad = 0;
  private chordIdx = 0;
  private lastFlap = 0;
  enabled = false;
  ready = false;

  /* ---- boot (must be called from a user gesture the first time) ---- */
  unlock() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return true;
    }
    type WinAudio = typeof window & { webkitAudioContext?: typeof AudioContext };
    const AC = window.AudioContext || (window as WinAudio).webkitAudioContext;
    if (!AC) return false;
    const ctx = new AC();
    this.ctx = ctx;

    const master = ctx.createGain();
    master.gain.value = 0.0001;
    master.connect(ctx.destination);

    // gentle plate: two short feedback delays + a procedural impulse response
    const wet = ctx.createGain();
    wet.gain.value = 0.34;
    const conv = ctx.createConvolver();
    conv.buffer = this.makeIR(ctx, 1.9, 2.6);
    wet.connect(conv);
    conv.connect(master);

    const dry = ctx.createGain();
    dry.gain.value = 1;
    dry.connect(master);

    this.master = master;
    this.wet = wet;
    this.dry = dry;
    this.noise = this.makeNoise(ctx, 2.2);
    this.ready = true;

    master.gain.cancelScheduledValues(ctx.currentTime);
    master.gain.setValueAtTime(0.0001, ctx.currentTime);
    master.gain.exponentialRampToValueAtTime(this.enabled ? 0.5 : 0.0001, ctx.currentTime + 0.9);

    this.startAmbience();
    return true;
  }

  setEnabled(on: boolean) {
    this.enabled = on;
    if (on) {
      const ok = this.unlock();
      if (ok && this.ctx && this.master) {
        this.master.gain.cancelScheduledValues(this.ctx.currentTime);
        this.master.gain.setValueAtTime(Math.max(0.0001, this.master.gain.value), this.ctx.currentTime);
        this.master.gain.exponentialRampToValueAtTime(0.5, this.ctx.currentTime + 0.7);
      }
    } else if (this.ctx && this.master) {
      this.master.gain.cancelScheduledValues(this.ctx.currentTime);
      this.master.gain.setValueAtTime(Math.max(0.0001, this.master.gain.value), this.ctx.currentTime);
      this.master.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.35);
    }
  }

  /* ---- buffers ---- */
  private makeNoise(ctx: AudioContext, secs: number) {
    const b = ctx.createBuffer(1, Math.floor(ctx.sampleRate * secs), ctx.sampleRate);
    const d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < d.length; i++) {
      const w = Math.random() * 2 - 1;
      last = (last + 0.02 * w) / 1.02;
      d[i] = w * 0.72 + last * 3.2;
    }
    return b;
  }

  private makeIR(ctx: AudioContext, secs: number, decay: number) {
    const n = Math.floor(ctx.sampleRate * secs);
    const b = ctx.createBuffer(2, n, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = b.getChannelData(c);
      for (let i = 0; i < n; i++) {
        const t = i / n;
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, decay) * (1 - t * 0.2);
      }
    }
    return b;
  }

  private src(when: number, dur: number) {
    const ctx = this.ctx!;
    const s = ctx.createBufferSource();
    s.buffer = this.noise;
    s.loop = true;
    s.playbackRate.value = 0.85 + Math.random() * 0.3;
    const off = Math.random() * 1.4;
    s.start(when, off, dur + 0.05);
    s.stop(when + dur + 0.06);
    return s;
  }

  /* A voice budget, not a voice limit: it only ever kicks in if something
     runs away, so the story beats (ticket, throw) are never swallowed. */
  private guard(priority = false) {
    if (!this.ready || !this.enabled || !this.ctx) return false;
    if (this.ctx.state === 'suspended') void this.ctx.resume();
    if (this.voices > (priority ? 30 : 16)) return false;
    this.voices++;
    window.setTimeout(() => {
      this.voices = Math.max(0, this.voices - 1);
    }, 900);
    return true;
  }

  private when(offset = 0) {
    return this.ctx!.currentTime + Math.max(0, offset);
  }

  /* ====================================================================
     ambience — a soft wind bed and a slow music-box chord drift
     ==================================================================== */
  private startAmbience() {
    const ctx = this.ctx;
    if (!ctx || this.ambienceOn) return;
    this.ambienceOn = true;

    // wind
    const w = ctx.createBufferSource();
    w.buffer = this.noise;
    w.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 420;
    bp.Q.value = 0.7;
    const wg = ctx.createGain();
    wg.gain.value = 0.018;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.06;
    const lg = ctx.createGain();
    lg.gain.value = 0.011;
    lfo.connect(lg);
    lg.connect(wg.gain);
    const lfo2 = ctx.createOscillator();
    lfo2.frequency.value = 0.037;
    const l2g = ctx.createGain();
    l2g.gain.value = 190;
    lfo2.connect(l2g);
    l2g.connect(bp.frequency);
    w.connect(bp);
    bp.connect(wg);
    wg.connect(this.dry!);
    w.start();
    lfo.start();
    lfo2.start();

    this.nextPad = ctx.currentTime + 1.2;
    this.nextChirp = ctx.currentTime + 2.4;
  }

  /* ---- scheduler, called once per rendered frame (does no work itself) ---- */
  tick() {
    const ctx = this.ctx;
    if (!ctx || !this.enabled || !this.ambienceOn) return;
    const now = ctx.currentTime;

    if (now > this.nextPad - 0.35) {
      this.pad(this.nextPad);
      this.nextPad += 5.4 + Math.random() * 2.6;
      this.chordIdx = (this.chordIdx + 1) % CHORDS.length;
    }
    if (now > this.nextChirp - 0.4) {
      this.distantSong(this.nextChirp);
      this.nextChirp += 2.6 + Math.random() * 5.2;
    }
  }

  private pad(when: number) {
    if (!this.guard()) return;
    const ctx = this.ctx!;
    const base = 174.61; // F3
    const chord = CHORDS[this.chordIdx];
    chord.forEach((semi, i) => {
      const f = base * Math.pow(2, semi / 12) * (i === 0 ? 1 : 2);
      const o = ctx.createOscillator();
      o.type = i === 0 ? 'sine' : 'triangle';
      o.frequency.value = f;
      o.detune.value = (Math.random() - 0.5) * 7;
      const g = ctx.createGain();
      const peak = i === 0 ? 0.05 : 0.026;
      g.gain.setValueAtTime(0.0001, when);
      g.gain.exponentialRampToValueAtTime(peak, when + 1.5 + i * 0.3);
      g.gain.exponentialRampToValueAtTime(0.0001, when + 5.6);
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 1400;
      o.connect(g);
      g.connect(lp);
      lp.connect(this.dry!);
      lp.connect(this.wet!);
      o.start(when);
      o.stop(when + 5.8);
    });
  }

  /* ====================================================================
     birdsong
     ==================================================================== */
  private note(
    when: number,
    f0: number,
    f1: number,
    dur: number,
    gain: number,
    type: OscillatorType = 'sine',
    vib = 0
  ) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, when);
    o.frequency.exponentialRampToValueAtTime(Math.max(40, f1), when + dur * 0.62);
    o.frequency.exponentialRampToValueAtTime(Math.max(40, f1 * 0.94), when + dur);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(gain, when + Math.min(0.02, dur * 0.2));
    g.gain.exponentialRampToValueAtTime(gain * 0.55, when + dur * 0.55);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = (f0 + f1) * 0.55;
    bp.Q.value = 1.5;

    o.connect(g);
    g.connect(bp);
    bp.connect(this.dry!);
    bp.connect(this.wet!);

    if (vib > 0) {
      const l = ctx.createOscillator();
      l.frequency.value = 26 + Math.random() * 12;
      const lg = ctx.createGain();
      lg.gain.value = vib;
      l.connect(lg);
      lg.connect(o.frequency);
      l.start(when);
      l.stop(when + dur + 0.02);
    }
    o.start(when);
    o.stop(when + dur + 0.03);
  }

  private chirpPhrase(when: number, root: number, n: number, gain: number, bright = 1) {
    if (!this.guard()) return;
    let t = when;
    for (let i = 0; i < n; i++) {
      const a = PENT[(Math.random() * PENT.length) | 0];
      const b = PENT[(Math.random() * PENT.length) | 0];
      const f0 = root * a * bright;
      const f1 = root * b * bright;
      const dur = 0.055 + Math.random() * 0.11;
      this.note(t, f0, f1, dur, gain * (0.7 + Math.random() * 0.5), Math.random() < 0.4 ? 'triangle' : 'sine', f0 * 0.006);
      t += dur + 0.028 + Math.random() * 0.075;
      if (Math.random() < 0.22) {
        // little trill
        for (let k = 0; k < 3; k++) {
          this.note(t, f1 * 1.02, f1 * 0.99, 0.032, gain * 0.6, 'sine');
          t += 0.042;
        }
      }
    }
  }

  distantSong(when?: number) {
    if (!this.guard()) return;
    const w = when ?? this.when(0.02);
    const roots = [880, 1046.5, 784, 1318.5];
    const root = roots[(Math.random() * roots.length) | 0];
    this.chirpPhrase(w, root, 2 + ((Math.random() * 4) | 0), 0.055, 0.72 + Math.random() * 0.5);
  }

  /* the dove herself — lower, rounder, cooing, in sync with her flight */
  doveCall(kind: 'enter' | 'drop' | 'exit') {
    if (!this.guard(true)) return;
    const w = this.when(0.005);
    if (kind === 'enter') {
      this.note(w, 392, 523.25, 0.16, 0.075, 'triangle');
      this.note(w + 0.15, 523.25, 659.25, 0.2, 0.07, 'triangle');
      this.note(w + 0.4, 784, 659.25, 0.26, 0.05, 'sine');
    } else if (kind === 'drop') {
      this.note(w, 587.33, 392, 0.13, 0.07, 'triangle');
      this.note(w + 0.11, 392, 293.66, 0.3, 0.06, 'sine', 6);
      // the soft coo underneath
      this.note(w + 0.02, 196, 174.61, 0.42, 0.035, 'sine', 4);
    } else {
      this.chirpPhrase(w, 659.25, 3, 0.05, 1.35);
      this.note(w + 0.34, 880, 1318.5, 0.24, 0.032, 'sine');
    }
  }

  /* ====================================================================
     wingbeats — a feathered noise whoosh, one per downstroke
     ==================================================================== */
  flap(strength = 1) {
    if (!this.guard() || !this.ctx) return;
    const now = this.ctx.currentTime;
    if (now - this.lastFlap < 0.075) return;
    this.lastFlap = now;
    const w = now + 0.004;
    const dur = 0.16;
    const s = this.src(w, dur);
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 1.1;
    bp.frequency.setValueAtTime(1500 * strength, w);
    bp.frequency.exponentialRampToValueAtTime(340, w + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, w);
    g.gain.exponentialRampToValueAtTime(0.048 * strength, w + 0.022);
    g.gain.exponentialRampToValueAtTime(0.0001, w + dur);
    s.connect(bp);
    bp.connect(g);
    g.connect(this.dry!);
    g.connect(this.wet!);
  }

  /* ====================================================================
     paper & footsteps
     ==================================================================== */
  private knock(when: number, freq: number, gain: number, dur: number, q = 6) {
    if (!this.ctx) return;
    const o = this.ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(freq * 1.7, when);
    o.frequency.exponentialRampToValueAtTime(freq, when + dur * 0.5);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(gain, when + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'lowpass';
    bp.frequency.value = freq * q;
    o.connect(g);
    g.connect(bp);
    bp.connect(this.dry!);
    bp.connect(this.wet!);
    o.start(when);
    o.stop(when + dur + 0.02);
  }

  step(strength = 1) {
    if (!this.guard() || !this.ctx) return;
    const w = this.when(0.002);
    this.knock(w, 96, 0.05 * strength, 0.11, 3);
    const s = this.src(w, 0.07);
    const hp = this.ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 1800;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.02 * strength, w);
    g.gain.exponentialRampToValueAtTime(0.0001, w + 0.07);
    s.connect(hp);
    hp.connect(g);
    g.connect(this.dry!);
  }

  bookDown() {
    if (!this.guard(true) || !this.ctx) return;
    const w = this.when(0.002);
    this.knock(w, 132, 0.085, 0.2, 3);
    this.knock(w + 0.045, 176, 0.05, 0.16, 3);
    const s = this.src(w, 0.13);
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 2400;
    bp.Q.value = 0.8;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.03, w);
    g.gain.exponentialRampToValueAtTime(0.0001, w + 0.13);
    s.connect(bp);
    bp.connect(g);
    g.connect(this.dry!);
    g.connect(this.wet!);
  }

  lidOpen() {
    if (!this.guard(true) || !this.ctx) return;
    const w = this.when(0.002);
    const s = this.src(w, 0.24);
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 1.4;
    bp.frequency.setValueAtTime(700, w);
    bp.frequency.exponentialRampToValueAtTime(3200, w + 0.24);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, w);
    g.gain.exponentialRampToValueAtTime(0.035, w + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, w + 0.24);
    s.connect(bp);
    bp.connect(g);
    g.connect(this.dry!);
    g.connect(this.wet!);
    this.knock(w + 0.23, 420, 0.03, 0.1, 4);
  }

  ticketLand() {
    if (!this.guard(true) || !this.ctx) return;
    const w = this.when(0.002);
    // two-note music-box bell
    [1046.5, 1567.98].forEach((f, i) => {
      this.note(w + i * 0.085, f, f, 0.7 - i * 0.15, 0.075 - i * 0.015, 'sine');
      this.note(w + i * 0.085, f * 2.01, f * 2.01, 0.28, 0.022, 'triangle');
    });
    this.knock(w, 320, 0.03, 0.09, 5);
  }

  planeThrow() {
    if (!this.guard(true) || !this.ctx) return;
    const w = this.when(0.002);
    const s = this.src(w, 0.42);
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 0.9;
    bp.frequency.setValueAtTime(3400, w);
    bp.frequency.exponentialRampToValueAtTime(560, w + 0.42);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, w);
    g.gain.exponentialRampToValueAtTime(0.06, w + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, w + 0.42);
    s.connect(bp);
    bp.connect(g);
    g.connect(this.dry!);
    g.connect(this.wet!);
    this.note(w + 0.02, 659.25, 987.77, 0.16, 0.04, 'triangle');
  }

  paperFlutter() {
    if (!this.guard() || !this.ctx) return;
    const w = this.when(0.002);
    const s = this.src(w, 0.3);
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 2.4;
    bp.frequency.setValueAtTime(1600, w);
    bp.frequency.linearRampToValueAtTime(2900, w + 0.3);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, w);
    g.gain.exponentialRampToValueAtTime(0.022, w + 0.08);
    g.gain.exponentialRampToValueAtTime(0.0001, w + 0.3);
    s.connect(bp);
    bp.connect(g);
    g.connect(this.dry!);
  }

  envelopeLand() {
    if (!this.guard() || !this.ctx) return;
    const w = this.when(0.002);
    this.knock(w, 210, 0.032, 0.13, 3);
    const s = this.src(w, 0.09);
    const hp = this.ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 2600;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.016, w);
    g.gain.exponentialRampToValueAtTime(0.0001, w + 0.09);
    s.connect(hp);
    hp.connect(g);
    g.connect(this.dry!);
  }

  uiTick() {
    if (!this.guard() || !this.ctx) return;
    const w = this.when(0.001);
    this.note(w, 880, 1174.66, 0.09, 0.03, 'sine');
  }
}

export const score = new PaperScore();
