import React, { useCallback, useEffect, useRef, useState } from 'react';
import { PaperCutGirl, GirlAnimRefs } from './components/PaperCutGirl';
import {
  DioramaTargets,
  renderBirdAndMail,
  getWingFreq,
  DoveQ,
  TR,
  TS,
  TL,
} from './utils/birdMailRenderer';
import {
  GT,
  TH,
  LOOP_DURATION,
  PLANE_FLIGHT,
  computeGirlPose,
  buildPlanePath,
  clamp,
  lerp,
  ramp,
  VB_W,
  VB_H,
  VB_TOP,
  VB_FULL,
  type PlanePath,
} from './utils/paperRig';
import { score } from './utils/audio';

/* Deterministic PRNG for scissor-cut paper geometry */
function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const q = (n: number) => Math.round(n * 100) / 100;
const q1 = (n: number) => Math.round(n * 10) / 10;

const INTRO_HOLD = 1.85; // the sheets land first, then the film clock starts
const REDUCE =
  typeof window !== 'undefined' &&
  window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/* parallax depth per sheet — the reference's own curve: pow(depth/8, 1.15) * S */
const DEPTH: Record<string, number> = {
  hang: 1.0,
  l1: 1.7,
  l2: 2.5,
  l3: 3.5,
  l4: 4.5,
  l5: 5.7,
  l6: 6.6,
  girl: 6.6,
  l7: 8.4,
  col: 1.9,
  brand: 3.4,
  leaves: 5.2,
};

interface Leaf {
  el: HTMLDivElement;
  on: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  vr: number;
  ph: number;
  sz: number;
  depth: number;
  ambient: boolean;
}

export default function App() {
  const [showPassword, setShowPassword] = useState(false);
  const [authBtnText, setAuthBtnText] = useState('Initialize auth');
  const [soundOn, setSoundOn] = useState(false);
  const [said, setSaid] = useState('');

  const grainImgRef = useRef<SVGImageElement | null>(null);
  const tagGrainRef = useRef<SVGSVGElement | null>(null);
  const hangRef = useRef<HTMLDivElement | null>(null);
  const l1Ref = useRef<HTMLDivElement | null>(null);
  const l2Ref = useRef<HTMLDivElement | null>(null);
  const l3Ref = useRef<HTMLDivElement | null>(null);
  const l4Ref = useRef<HTMLDivElement | null>(null);
  const l5Ref = useRef<HTMLDivElement | null>(null);
  const l6Ref = useRef<HTMLDivElement | null>(null);
  const l7Ref = useRef<HTMLDivElement | null>(null);
  const logoSvgRef = useRef<SVGSVGElement | null>(null);
  const leavesRef = useRef<HTMLDivElement | null>(null);

  const colRef = useRef<HTMLDivElement | null>(null);
  const brandRef = useRef<HTMLDivElement | null>(null);
  const ctaRef = useRef<HTMLDivElement | null>(null);

  const girlWrapRef = useRef<HTMLDivElement | null>(null);
  const girlShadowRef = useRef<HTMLDivElement | null>(null);
  const birdCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const msgPosRef = useRef<HTMLDivElement | null>(null);
  const msgRef = useRef<HTMLDivElement | null>(null);
  const ringRef = useRef<HTMLDivElement | null>(null);
  const planeRef = useRef<SVGSVGElement | null>(null);

  const girlAnimRefs = useRef<GirlAnimRefs>({
    headGroup: null,
    torsoGroup: null,
    pupilsGroup: null,
    normalEyesGroup: null,
    happyEyesGroup: null,
    eyelidsGroup: null,
    browsGroup: null,
    cheeksGroup: null,
    mouthCalm: null,
    mouthCurious: null,
    mouthHappy: null,
    laptopGlow: null,
    rootGroup: null,
    bodyGroup: null,
    chestGroup: null,
    hairGroup: null,
    legRigGroup: null,
    sitLegsGroup: null,
    bookGroup: null,
    laptopGroup: null,
    lidGroup: null,
    lapShutGroup: null,
    lapShutBack: null,
    lapShutBackInner: null,
    legPaths: new Array(10).fill(null),
    armPaths: new Array(8).fill(null),
    handL: null,
    handR: null,
  });

  const stateRef = useRef({
    T: 0,
    hold: -1,
    intro: INTRO_HOLD,
    ph: 0,
    prevPh: 0,
    lastNow: performance.now(),
    ringTriggered: false,
    msgTriggered: false,
    lastDotTime: 0,
    headAngle: -2,
    pupilX: 0,
    pupilY: 0,
    browY: 0,
    curiousAlpha: 0,
    happyAlpha: 0,
    px: 0,
    py: 0,
    tx: 0,
    ty: 0,
    lastInput: -1e9,
    tagA: -2.4,
    tagV: 0,
    ctaA: 1.6,
    ctaV: 0,
    lastPX: null as number | null,
    lastPT: 0,
    stepPrev: { l: 0, r: 0 },
    plane: null as PlanePath | null,
    planeBuiltFor: -1,
    enterDist: 900,
    frames: 0,
    acc: 0,
    quality: 0,
    leaves: [] as Leaf[],
    fired: {} as Record<string, boolean>,
    targets: {
      W: typeof window !== 'undefined' ? window.innerWidth : 1280,
      H: typeof window !== 'undefined' ? window.innerHeight : 800,
      dpr: 1,
      girlCx: 900,
      girlTop: 480,
      girlBot: 640,
      girlGw: 168,
      girlGh: 160,
      girlLeft: 800,
      girlWrapTop: 400,
      girlWrapH: 200,
      laptopX: 855,
      laptopY: 575,
      M: 60,
      S: 30,
      U: 10,
      port: false,
    } as DioramaTargets & {
      girlLeft: number;
      girlWrapTop: number;
      girlWrapH: number;
      M: number;
      S: number;
      U: number;
      port: boolean;
    },
  });

  const fire = (key: string, fn: () => void) => {
    const f = stateRef.current.fired;
    if (!f[key]) {
      f[key] = true;
      fn();
    }
  };

  const restartAnimation = useCallback((hard = true) => {
    const st = stateRef.current;
    st.T = 0;
    st.ph = 0;
    st.prevPh = 0;
    st.intro = REDUCE ? 0.25 : hard ? INTRO_HOLD : 0.5;
    st.ringTriggered = false;
    st.msgTriggered = false;
    st.lastDotTime = 0;
    st.plane = null;
    st.planeBuiltFor = -1;
    st.fired = {};

    if (msgRef.current) msgRef.current.classList.remove('on');
    if (msgPosRef.current) msgPosRef.current.style.opacity = '0';
    if (ringRef.current) {
      ringRef.current.style.opacity = '0';
      ringRef.current.classList.remove('on');
    }
    if (planeRef.current) planeRef.current.style.opacity = '0';
    document.querySelectorAll('.dot').forEach((d) => d.remove());

    // re-cut: the sheets lift back in from the bottom
    if (hard && !REDUCE) {
      const sheets = [l1Ref, l2Ref, l3Ref, l4Ref, l5Ref, l6Ref, l7Ref];
      sheets.forEach((r) => {
        const el = r.current;
        if (!el) return;
        el.classList.remove('place');
        void el.offsetWidth;
        el.classList.add('place');
      });
    }
  }, []);

  useEffect(() => {
    const st = stateRef.current;

    /* ---------- paper grain ---------- */
    const makeGrain = () => {
      const c = document.createElement('canvas');
      c.width = c.height = 160;
      const g = c.getContext('2d');
      if (!g) return;
      const id = g.createImageData(160, 160);
      const d = id.data;
      const R = mulberry32(77);
      for (let i = 0; i < d.length; i += 4) {
        const n = R();
        if (n < 0.5) {
          d[i] = 74;
          d[i + 1] = 52;
          d[i + 2] = 30;
          d[i + 3] = (0.5 - n) * 46;
        } else {
          d[i] = 255;
          d[i + 1] = 251;
          d[i + 2] = 240;
          d[i + 3] = (n - 0.5) * 40;
        }
      }
      g.putImageData(id, 0, 0);
      for (let k = 0; k < 90; k++) {
        g.strokeStyle = k % 3 ? 'rgba(255, 252, 242, 0.2)' : 'rgba(96, 66, 36, 0.13)';
        g.lineWidth = 0.6;
        g.beginPath();
        const x = R() * 160;
        const y = R() * 160;
        const a = R() * 6.28;
        const l = 4 + R() * 14;
        g.moveTo(x, y);
        g.quadraticCurveTo(
          x + Math.cos(a + 0.6) * l * 0.5,
          y + Math.sin(a + 0.6) * l * 0.5,
          x + Math.cos(a) * l,
          y + Math.sin(a) * l
        );
        g.stroke();
      }
      const url = c.toDataURL();
      grainImgRef.current?.setAttribute('href', url);
      if (tagGrainRef.current) {
        const img = tagGrainRef.current.querySelector('image');
        img?.setAttribute('href', url);
      }
    };
    makeGrain();

    /* ---------- scissor-cut geometry ---------- */
    let R = mulberry32(1);
    const rr = (a: number, b: number) => a + (b - a) * R();

    const ar = (p: [number, number][]) => {
      let a = 0;
      for (let i = 0; i < p.length; i++) {
        const u = p[i];
        const v = p[(i + 1) % p.length];
        a += u[0] * v[1] - v[0] * u[1];
      }
      return a;
    };
    const or = (p: [number, number][]) => (ar(p) < 0 ? p.slice().reverse() : p);
    const trace = (p: [number, number][], j: number, s: number) => {
      let out = '';
      const n = p.length;
      for (let i = 0; i < n; i++) {
        const a = p[i];
        const b = p[(i + 1) % n];
        const dx = b[0] - a[0];
        const dy = b[1] - a[1];
        const L = Math.hypot(dx, dy) || 1;
        const k = Math.max(1, Math.round(L / s));
        const nx = -dy / L;
        const ny = dx / L;
        for (let t = 0; t < k; t++) {
          let x = a[0] + (dx * t) / k;
          let y = a[1] + (dy * t) / k;
          if (t) {
            const o = (R() - 0.5) * 2 * j;
            x += nx * o;
            y += ny * o;
          }
          out += (out ? 'L' : 'M') + q1(x) + ' ' + q1(y);
        }
      }
      return out + 'Z';
    };
    const cut = (p: [number, number][], j = 0.7, s = 7) => trace(or(p), j, s);
    const poly = (p: [number, number][]) => {
      const op = or(p);
      return 'M' + op.map((a) => q1(a[0]) + ' ' + q1(a[1])).join('L') + 'Z';
    };
    const circ = (cx: number, cy: number, r: number, n?: number): [number, number][] => {
      const count = n || Math.max(10, (r * 1.2) | 0);
      return Array.from({ length: count }, (_, i) => {
        const a = (i / count) * 6.283;
        return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
      });
    };
    const wave = (b: number, A: number[], Ls: number[]) => {
      const ph = A.map(() => R() * 6.28);
      return (x: number) => {
        let y = b;
        A.forEach((a, i) => {
          y += a * Math.sin((x / Ls[i]) * 6.283 + ph[i]);
        });
        return y;
      };
    };

    const M = 96;
    const buildLogo = () => {
      if (!logoSvgRef.current) return;
      R = mulberry32(42);
      let s = '';
      s += `<path fill="#3b2b1d" d="${poly([
        [58.6, 110], [58.8, 64], [61.2, 64], [61.4, 110],
      ])}${poly([[59, 76], [40, 64], [41.5, 62], [60, 73]])}${poly([
        [61, 76], [80, 64], [78.5, 62], [60, 73],
      ])}"/>`;
      const discs: [number, number, number, string][] = [
        [28, 58, 19, '#c8642d'], [94, 56, 19, '#274e52'], [34, 34, 14, '#9bb89b'],
        [87, 32, 14, '#d98a5b'], [60, 32, 27, '#5f7f5b'], [60, 68, 17, '#d9a45b'],
        [44, 66, 12, '#efc27d'], [78, 68, 12, '#3d6a50'],
      ];
      for (const [x, y, r, c] of discs) s += `<path fill="${c}" d="${cut(circ(x, y, r), 0.6, 4)}"/>`;
      s += `<path fill="#3b2b1d" d="${cut([[14, 108], [60, 104], [106, 108], [60, 112]], 0.4, 5)}"/>`;
      s += `<path fill="url(#g)" d="${cut(circ(60, 32, 27), 0.2, 50)}"/>`;
      logoSvgRef.current.innerHTML = s;
    };

    const setLayerSvg = (
      ref: React.RefObject<HTMLDivElement | null>,
      W: number,
      H: number,
      P: number,
      html: string
    ) => {
      const el = ref.current;
      if (!el) return;
      const svg = el.querySelector('svg');
      if (!svg) return;
      el.style.left = `${-P}px`;
      el.style.top = `${-P}px`;
      el.style.width = `${W + 2 * P}px`;
      el.style.height = `${H + 2 * P}px`;
      svg.setAttribute('viewBox', `${-P} ${-P} ${W + 2 * P} ${H + 2 * P}`);
      svg.innerHTML = html;
    };

    const mk = (f: string, d: string) =>
      `<path fill="${f}" d="${d}"/><path class="grain" d="${d}"/>`;

    const buildSceneAndLayout = () => {
      const W = Math.max(320, window.innerWidth);
      const H = Math.max(420, window.innerHeight);
      const S = Math.min(W, H) * 0.042;
      const P = Math.ceil(S * 1.35 + 14);
      const dprBase = Math.min(2, window.devicePixelRatio || 1);
      const dpr = st.quality >= 1 ? Math.min(1.25, dprBase) : dprBase;
      const port = W < 760 || H > W * 1.1;
      const GY = H * (port ? 0.86 : 0.8);

      if (birdCanvasRef.current) {
        birdCanvasRef.current.width = Math.round(W * dpr);
        birdCanvasRef.current.height = Math.round(H * dpr);
      }

      R = mulberry32(1847);
      const U = Math.sqrt(W * H) / 100;

      const ridge = (f: (x: number) => number, bot: number, s = 9) => {
        const p: [number, number][] = [];
        for (let x = -M; x <= W + M + s; x += s) p.push([x, f(x) + (R() - 0.5) * 1.6]);
        p.push([W + M + s, bot], [-M, bot]);
        return poly(p);
      };
      const pine = (cx: number, by: number, h: number, w: number) => {
        const n = h > 200 ? 7 : h > 80 ? 5 : 4;
        const tip = by - h;
        const stp = (h * 0.92) / (n + 0.45);
        const j = Math.max(0.45, h / 520);
        const sp = Math.max(5, h / 70);
        let d = '';
        for (let i = 0; i < n; i++) {
          const top = tip + i * stp;
          const bot = tip + (i + 1.45) * stp;
          const b = w * 0.5 * (0.26 + 0.74 * Math.pow((i + 1) / n, 0.9));
          const hr = b * rr(0.92, 1.08);
          const hl = b * rr(0.92, 1.08);
          d += cut(
            [
              [cx, top], [cx + hr, bot], [cx + hr * 0.5, bot - stp * 0.28],
              [cx, bot - stp * 0.18], [cx - hl * 0.5, bot - stp * 0.28], [cx - hl, bot],
            ],
            j,
            sp
          );
        }
        const t = Math.max(1.4, w * 0.055);
        return (
          d + cut([[cx - t, by + 4], [cx - t, by - h * 0.12], [cx + t, by - h * 0.12], [cx + t, by + 4]], 0.3, 8)
        );
      };
      const blade = (x: number, y: number, h: number, l: number, w: number) =>
        poly([
          [x - w / 2, y], [x + l * 0.5 - w * 0.3, y - h * 0.55], [x + l, y - h],
          [x + l * 0.5 + w * 0.3, y - h * 0.55], [x + w / 2, y],
        ]);

      /* sheet 1 — far mountain ridge */
      const f1 = wave(H * 0.41, [H * 0.032, H * 0.015], [W * 1.1, W * 0.4]);
      setLayerSvg(l1Ref, W, H, P, mk('#dfdec3', ridge(f1, H + M)));

      /* sheet 2 — second hill with distant pines */
      const f2 = wave(H * 0.5, [H * 0.034, H * 0.014], [W * 0.9, W * 0.3]);
      let d2 = ridge(f2, H + M);
      for (let x = -M; x < W + M; x += rr(6, 16)) {
        if (Math.sin((x / W) * 8.5) + Math.sin((x / W) * 21) * 0.5 > 0.35) {
          const h = rr(2, 4) * U;
          d2 += pine(x, f2(x) + 3, h, h * 0.55);
        }
      }
      setLayerSvg(l2Ref, W, H, P, mk('#bdcfb2', d2));

      /* sheet 3 — mid forest ridge */
      const f3 = wave(H * 0.56, [H * 0.014, H * 0.007], [W * 0.7, W * 0.23]);
      let d3 = ridge(f3, H + M);
      for (let x = -M; x < W + M; ) {
        const h = rr(3.6, 7.4) * U;
        const w = h * rr(0.46, 0.58);
        d3 += pine(x, f3(x) + 4, h, w);
        x += w * rr(0.42, 0.8);
      }
      setLayerSvg(l3Ref, W, H, P, mk('#9bb89b', d3));

      /* sheet 4 — rolling meadow */
      const f4 = wave(H * 0.62, [H * 0.008, H * 0.004], [W * 0.8, W * 0.25]);
      setLayerSvg(l4Ref, W, H, P, mk('#7e9c74', ridge(f4, H + M, 10)));

      /* sheet 5 — tall framing pines */
      let d5 = '';
      const framingPines: [number, number, number][] = port
        ? [[1.02, 0.5, 0.34], [0.04, 0.4, 0.3]]
        : [[0.99, 0.9, 0.25], [0.935, 0.54, 0.21]];
      for (const [gx, gh, gw] of framingPines) {
        d5 += pine(W * gx, GY + 6, H * gh, Math.min(H * gh * 0.42, W * gw));
      }
      setLayerSvg(l5Ref, W, H, P, mk('#274e52', d5));

      /* sheet 6 — ochre ground, tufts, pebbles, fallen leaves */
      const gnd = wave(GY, [H * 0.006, H * 0.003], [W * 0.7, W * 0.22]);
      const d6 = ridge(gnd, H + M, 8);
      let tufts = '';
      let pebbles = '';
      let leaves1 = '';
      let leaves2 = '';
      for (let x = -M; x < W + M; x += rr(18, 60)) {
        const y = gnd(x) + 2;
        for (let k = 0; k < 4; k++) {
          tufts += blade(x + k * 2.2, y + 2, rr(0.9, 2.1) * U, rr(-0.6, 0.6) * U, rr(2, 3.4));
        }
      }
      for (let i = 0; i < 10; i++) {
        const x = rr(0.03, 0.97) * W;
        const y = gnd(x) + rr(1, 6) * U;
        const r = rr(0.3, 0.7) * U;
        pebbles += cut(
          circ(x, y, r, 9).map(([a, b]) => [a, y + (b - y) * 0.6]),
          0.25,
          3
        );
      }
      for (let i = 0; i < W / 45; i++) {
        const x = rr(-0.02, 1.02) * W;
        const y = gnd(x) + U * 2 + Math.pow(R(), 1.3) * (H * 0.97 - gnd(x) - U * 2);
        const sz = rr(0.45, 0.9) * U;
        const a = R() * 3.1;
        const ca = Math.cos(a);
        const sa = Math.sin(a);
        const lp: [number, number][] = (
          [[-1, 0], [-0.3, -0.42], [0.35, -0.36], [1, 0], [0.3, 0.4], [-0.35, 0.36]] as [number, number][]
        ).map(([u, v]) => [x + (u * ca - v * sa * 0.8) * sz, y + (u * sa + v * ca * 0.8) * sz * 0.62]);
        if (R() < 0.6) leaves1 += cut(lp, 0.2, 3);
        else leaves2 += cut(lp, 0.2, 3);
      }
      setLayerSvg(
        l6Ref,
        W,
        H,
        P,
        `<path fill="#d9a45b" d="${d6}"/><path fill="#c9713a" d="${leaves1}"/><path fill="#b98f4c" d="${leaves2}"/><path fill="#8a9a55" d="${tufts}"/><path fill="#e9dcc0" d="${pebbles}"/><path class="grain" d="${d6}"/>`
      );

      /* sheet 7 — foreground grass silhouette */
      const g8 = wave(H * 0.965, [H * 0.006], [W * 0.5]);
      let d8 = ridge(g8, H + M, 9);
      let b2 = '';
      for (let x = -M; x < W + M; x += rr(3.5, 8)) {
        const s = Math.abs(x - W / 2) / (W / 2);
        const h = H * (0.012 + 0.1 * Math.pow(clamp(s, 0, 1.2), 2.4)) * rr(0.4, 1);
        const b = blade(x, g8(x) + 6, h, rr(-0.38, 0.38) * h, rr(4, 9));
        if (R() < 0.3) b2 += b;
        else d8 += b;
      }
      setLayerSvg(
        l7Ref,
        W,
        H,
        P,
        `<path fill="#3d6a50" d="${b2}"/><path fill="#1f4245" d="${d8}"/><path class="grain" d="${d8}${b2}"/>`
      );

      /* hanging sun & clouds */
      const rays: [number, number][] = [];
      for (let i = 0; i < 44; i++) {
        const a = (i / 44) * 6.283;
        const r = i % 2 ? 47 : 58;
        rays.push([Math.cos(a) * r, Math.sin(a) * r]);
      }
      const sd = clamp(Math.min(W, H) * 0.14, 68, 138);
      const sunSvg = `<svg viewBox="-62 -62 124 124" width="${q1(sd)}" height="${q1(sd)}">
        <path fill="#c8642d" d="${cut(rays, 0.5, 5)}"/>
        <path fill="#d9a45b" d="${cut(circ(0, 0, 42, 40), 0.5, 5)}"/>
        <path fill="#e6b772" d="${cut(circ(-4, -5, 29, 30), 0.4, 5)}"/>
        <path class="grain" d="${cut(circ(0, 0, 42, 40), 0.2, 16)}"/>
      </svg>`;

      const makeCloudPath = (sc: number, ox = 0, oy = 0) => {
        let d = '';
        const puffs: [number, number, number][] = [[-30, 4, 17], [-9, -9, 24], [16, -5, 20], [35, 6, 13]];
        for (const [x, y, r] of puffs) d += cut(circ((x + ox) * sc, (y + oy) * sc, r * sc, 22), 0.5, 5);
        return (
          d +
          cut([
            [(-46 + ox) * sc, (20 + oy) * sc], [(-46 + ox) * sc, (6 + oy) * sc],
            [(48 + ox) * sc, (6 + oy) * sc], [(48 + ox) * sc, (20 + oy) * sc],
          ], 0.5, 6)
        );
      };

      const hangingItems: [number, number, string | number, number][] = [
        [port ? 0.22 : 0.31, port ? 0.1 : 0.11, 0, 0.145],
        [port ? 0.42 : 0.45, port ? 0.17 : 0.18, 0, 0.175],
        [port ? 0.58 : 0.56, port ? 0.08 : 0.085, 0, 0.125],
        [port ? 0.76 : 0.67, port ? 0.11 : 0.095, sunSvg, sd],
        [port ? 0.86 : 0.8, port ? 0.19 : 0.16, 0, 0.16],
        [port ? 0.93 : 0.91, port ? 0.23 : 0.22, 0, 0.13],
      ];

      if (hangRef.current) {
        hangRef.current.style.width = `${W}px`;
        hangRef.current.style.height = `${H}px`;
        hangRef.current.innerHTML = hangingItems
          .map(([x, y, customSvg, s], k) => {
            const w = customSvg ? s : Math.min(W, H) * s * 1.1;
            const len = H * y;
            const backCloud = customSvg ? '' : makeCloudPath(1, 3.5, -2.5);
            const frontCloud = customSvg ? '' : makeCloudPath(1, 0, 0);
            const innerObj =
              typeof customSvg === 'string'
                ? `<div class="halo"></div>${customSvg}`
                : `<svg viewBox="-56 -40 112 66" width="${q1(w)}" height="${q1(w * 0.58)}">
                    <path fill="#efe4cc" d="${backCloud}"/>
                    <path fill="#fbf6ea" d="${frontCloud}"/>
                    <path class="grain" d="${frontCloud}"/>
                  </svg>`;
            return `<div class="hang" style="left:${q1(W * x)}px;--len:${q1(len)}px">
              <div class="swing" style="--sd:${4.2 + k * 0.95}s;--dl:-${k * 1.3}s">
                <span class="string"></span>
                <div class="obj">${innerObj}</div>
              </div>
            </div>`;
          })
          .join('');
      }

      /* ---------- the girl's placement ---------- */
      const AR = VB_W / VB_H;
      const FX = 0.5742;
      const FY = 0.6978;
      const gh = clamp(port ? Math.min(H * 0.21, (W * 0.36) / AR) : Math.min(H * 0.265, (W * 0.19) / AR), 125, 215);
      const gw = gh * AR;
      const cx = W * (port ? 0.52 : 0.71);
      const bot = gnd(cx) + 8;
      // the sheet is taller than the seated figure so she can stand up inside it
      const wrapH = gh * (VB_FULL / VB_H);
      const wrapTop = bot - ((354 - VB_TOP) / VB_FULL) * wrapH;
      const top = wrapTop + ((8 - VB_TOP) / VB_FULL) * wrapH;
      const left = cx - gw / 2;

      if (girlWrapRef.current) {
        Object.assign(girlWrapRef.current.style, {
          left: `${q1(left)}px`,
          top: `${q1(wrapTop)}px`,
          width: `${q1(gw)}px`,
          height: `${q1(wrapH)}px`,
        });
      }
      if (girlShadowRef.current) {
        Object.assign(girlShadowRef.current.style, {
          left: `${q1(cx - gw * 0.52)}px`,
          top: `${q1(bot - 8)}px`,
          width: `${q1(gw * 1.04)}px`,
          height: '15px',
        });
      }

      const laptopX = left + FX * gw;
      const laptopY = wrapTop + ((FY * VB_H - VB_TOP) / VB_FULL) * wrapH;

      // how far she has to walk to come in from beyond the right edge
      const enterDist = ((W + 40 - left) / gw) * VB_W;

      Object.assign(st.targets, {
        W, H, dpr,
        girlCx: cx, girlTop: top, girlBot: bot, girlGw: gw, girlGh: gh,
        girlLeft: left, girlWrapTop: wrapTop, girlWrapH: wrapH,
        laptopX, laptopY, M: P, S, U, port,
      });
      st.enterDist = enterDist;
      st.plane = null;
      st.planeBuiltFor = -1;
      buildLeaves(W, H, U);
    };

    /* ---------- falling paper leaves ---------- */
    const LEAF_SHAPES = [
      'M0 -9C5 -6 6 1 0 9C-6 1 -5 -6 0 -9Z',
      'M0 -9L2.5 -4L6.5 -5L4.5 0L7 3L2 3.5L0 9L-2 3.5L-7 3L-4.5 0L-6.5 -5L-2.5 -4Z',
      'M0 -9C3 -7 4.5 -3 3.5 0C5 2 4 6 0 9C-4 6 -5 2 -3.5 0C-4.5 -3 -3 -7 0 -9Z',
    ];
    const LEAF_CLS = ['lf-a', 'lf-b', 'lf-c', 'lf-a', 'lf-b'];

    const spawnLeaf = (l: Leaf, x: number, y: number, burst = false, U = 10) => {
      l.on = true;
      l.x = x;
      l.y = y;
      l.vx = burst ? (Math.random() * 2 - 1) * 80 : 8 + Math.random() * 18;
      l.vy = burst ? -20 - Math.random() * 50 : 18 + Math.random() * 16;
      l.rot = Math.random() * 360;
      l.vr = (Math.random() * 2 - 1) * 90;
      l.sz = (0.8 + Math.random() * 0.7) * clamp(U / 9, 0.7, 1.4);
      l.depth = 0.55 + Math.random() * 0.9;
      l.el.style.opacity = '1';
    };

    const buildLeaves = (W: number, H: number, U: number) => {
      const host = leavesRef.current;
      if (!host) return;
      const n = st.quality >= 2 ? 0 : W < 640 ? 9 : st.quality >= 1 ? 12 : 20;
      host.innerHTML = '';
      st.leaves = [];
      for (let i = 0; i < n; i++) {
        const el = document.createElement('div');
        el.className = 'leaf';
        el.innerHTML = `<svg viewBox="-10 -10 20 20" width="20" height="20"><path class="${
          LEAF_CLS[i % 5]
        }" d="${LEAF_SHAPES[i % 3]}"/><path class="lf-v" d="M0 -7V8"/></svg>`;
        host.appendChild(el);
        const l: Leaf = {
          el, on: false, x: 0, y: 0, vx: 0, vy: 0, rot: 0, vr: 0,
          ph: Math.random() * 6, sz: 1, depth: 1, ambient: true,
        };
        st.leaves.push(l);
        spawnLeaf(l, Math.random() * W, Math.random() * H * 0.9, false, U);
      }
    };

    const stepLeaves = (dt: number, t: number, W: number, H: number, U: number, parX: number, parY: number) => {
      const slow = REDUCE ? 0.35 : 1;
      for (const l of st.leaves) {
        if (!l.on) continue;
        l.vy += (30 - l.vy) * dt * 1.4;
        l.vx += (14 - l.vx) * dt * 0.8;
        l.x += (l.vx + Math.sin(t * 1.3 + l.ph) * 34) * dt * slow;
        l.y += l.vy * dt * slow;
        l.rot += l.vr * dt * slow;
        const flip = Math.sin(t * 2.1 + l.ph) * 62;
        l.el.style.transform = `translate3d(${q(l.x + parX * l.depth)}px,${q(
          l.y + parY * l.depth * 0.55
        )}px,0) rotate(${q(l.rot)}deg) rotateY(${q(flip)}deg) scale(${l.sz.toFixed(2)})`;
        if (l.y > H + 30 || l.x > W + 40) spawnLeaf(l, -30 + Math.random() * W * 0.9, -30, false, U);
      }
    };

    buildLogo();
    buildSceneAndLayout();
    restartAnimation(true);

    let resizeTimer = 0;
    const onResize = () => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(() => buildSceneAndLayout(), 130);
    };

    const onPointerMove = (e: PointerEvent) => {
      const tg = st.targets;
      const now = performance.now();
      st.tx = clamp((e.clientX / tg.W - 0.5) * 2, -1, 1);
      st.ty = clamp((e.clientY / tg.H - 0.5) * 2, -1, 1);
      if (st.lastPX !== null) {
        const v = (e.clientX - st.lastPX) / Math.max(8, now - st.lastPT);
        st.tagV += -v * 9;
        st.ctaV += v * 4.5;
      }
      st.lastPX = e.clientX;
      st.lastPT = now;
      st.lastInput = now;
    };
    const onPointerLeave = () => {
      st.lastPX = null;
    };
    const onClick = (e: MouseEvent) => {
      const el = e.target as HTMLElement | null;
      const onUI = !!el?.closest?.('.col, .chips, #girl-wrap');
      st.tagV += (Math.random() - 0.5) * (onUI ? 8 : 26);
      st.ctaV += (Math.random() - 0.5) * 12;
      if (onUI) return;
      // a little burst of leaves where you click
      const tg = st.targets;
      const f = Math.pow(DEPTH.leaves / 8, 1.15) * tg.S;
      let n = 0;
      for (const l of st.leaves) {
        if (n >= 3) break;
        spawnLeaf(l, e.clientX - st.px * f, e.clientY - st.py * f * 0.55, true, tg.U);
        n++;
      }
    };

    window.addEventListener('resize', onResize);
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    window.addEventListener('pointerleave', onPointerLeave);
    window.addEventListener('click', onClick);

    /* ---------- the frame ---------- */
    let rafId = 0;
    let appliedQuality = 0;
    const layers: [React.RefObject<HTMLDivElement | null>, string][] = [
      [hangRef, 'hang'], [l1Ref, 'l1'], [l2Ref, 'l2'], [l3Ref, 'l3'],
      [l4Ref, 'l4'], [l5Ref, 'l5'], [l6Ref, 'l6'], [l7Ref, 'l7'],
    ];
    const depthCache = layers.map(([, k]) => Math.pow(DEPTH[k] / 8, 1.15));

    const frame = (now: number) => {
      rafId = requestAnimationFrame(frame);
      const tg = st.targets;
      let dt = Math.min(0.05, (now - st.lastNow) / 1000);
      st.lastNow = now;
      if (dt <= 0) dt = 1 / 60;
      const clock = now / 1000;

      /* adaptive quality — keeps old hardware honest without dropping the look */
      st.frames++;
      st.acc += dt;
      if (st.frames >= 70) {
        const avg = st.acc / st.frames;
        st.frames = 0;
        st.acc = 0;
        if (avg > 0.034 && st.quality < 2) st.quality = 2;
        else if (avg > 0.0235 && st.quality < 1) st.quality = 1;
        else if (avg < 0.0155 && st.quality > 0) st.quality = 0;
        else if (avg > 0.019 && st.quality === 0 && DoveQ.shadow) st.quality = 1;
        if (st.quality !== appliedQuality) {
          appliedQuality = st.quality;
          DoveQ.shadow = st.quality === 0;
          document.body.classList.toggle('q2', st.quality >= 2);
          buildSceneAndLayout();
        }
      }

      /* film clock (holds while the sheets land) */
      if (st.hold >= 0) st.T = st.hold;
      else if (st.intro > 0) st.intro -= dt;
      else {
        st.T += dt;
        if (st.T > LOOP_DURATION) restartAnimation(false);
      }
      const T = st.T;

      /* pointer parallax with a slow idle drift, exactly like the reference */
      if (!REDUCE && performance.now() - st.lastInput > 3500) {
        st.tx = Math.sin(clock * 0.19) * 0.42;
        st.ty = Math.sin(clock * 0.13 + 1) * 0.18;
      }
      const k = 1 - Math.exp(-dt * (REDUCE ? 9 : 3.4));
      st.px += (st.tx - st.px) * k;
      st.py += (st.ty - st.py) * k;
      const S = tg.S;

      for (let i = 0; i < layers.length; i++) {
        const el = layers[i][0].current;
        if (!el) continue;
        const f = depthCache[i] * S;
        el.style.transform = `translate3d(${q(-st.px * f)}px, ${q(-st.py * f * 0.55)}px, 0)`;
      }
      const girlF = Math.pow(DEPTH.girl / 8, 1.15) * S;
      const girlParX = -st.px * girlF;
      const girlParY = -st.py * girlF * 0.55;

      /* the login column drifts a little; the bookmark swings properly */
      if (colRef.current) {
        const f = Math.pow(DEPTH.col / 8, 1.15) * S;
        colRef.current.style.transform = `translate3d(${q(-st.px * f)}px, ${q(-st.py * f * 0.5)}px, 0)`;
      }
      const tagRest = REDUCE ? 0 : -2.2 + Math.sin(clock * 0.6) * 0.6;
      st.tagV += (-(st.tagA - tagRest) * 26 - st.tagV * 2.6) * dt;
      st.tagA = clamp(st.tagA + st.tagV * dt, -16, 16);
      if (brandRef.current) {
        const f = Math.pow(DEPTH.brand / 8, 1.15) * S;
        brandRef.current.style.transform = `translate3d(${q(-st.px * f)}px, ${q(
          -st.py * f * 0.4
        )}px, 0) rotate(${st.tagA.toFixed(2)}deg)`;
      }
      const ctaRest = REDUCE ? 0 : 1.4 + Math.sin(clock * 0.47 + 1.2) * 0.7;
      st.ctaV += (-(st.ctaA - ctaRest) * 19 - st.ctaV * 2.3) * dt;
      st.ctaA = clamp(st.ctaA + st.ctaV * dt, -11, 11);
      if (ctaRef.current) ctaRef.current.style.transform = `rotate(${st.ctaA.toFixed(2)}deg)`;

      /* leaves */
      stepLeaves(dt, clock, tg.W, tg.H, tg.U, girlParX * 0.8, girlParY * 0.8);

      /* ---------- the girl ---------- */
      const pose = computeGirlPose(T, st.enterDist, st.stepPrev);
      st.stepPrev = { l: pose.phaseL, r: pose.phaseR };
      const gR = girlAnimRefs.current;

      if (gR.rootGroup) {
        gR.rootGroup.style.transform = `translate3d(${q(pose.rootX)}px,0,0) rotate(${q(
          pose.rootRot
        )}deg) scale(${pose.rootSX.toFixed(3)}, 1)`;
      }
      if (gR.bodyGroup) gR.bodyGroup.style.transform = `translate3d(0,${q(pose.rootY)}px,0)`;
      if (gR.chestGroup)
        gR.chestGroup.style.transform = `translate3d(${q(pose.chestX)}px,${q(
          pose.chestY
        )}px,0) rotate(${q(pose.chestRot)}deg)`;
      if (gR.legRigGroup) {
        gR.legRigGroup.setAttribute('opacity', pose.rigLegAlpha.toFixed(3));
        const L = pose.legs;
        const d = [
          L[0].thigh, L[0].thighShade, L[0].shin, L[0].shoe, L[0].sole,
          L[1].thigh, L[1].thighShade, L[1].shin, L[1].shoe, L[1].sole,
        ];
        for (let i = 0; i < 10; i++) gR.legPaths[i]?.setAttribute('d', d[i]);
      }
      if (gR.sitLegsGroup) gR.sitLegsGroup.setAttribute('opacity', pose.sitLegAlpha.toFixed(3));

      const A = pose.arms;
      const ad = [
        A[0].upperShade, A[0].upper, A[0].fore, A[0].cuff,
        A[1].upperShade, A[1].upper, A[1].fore, A[1].cuff,
      ];
      for (let i = 0; i < 8; i++) gR.armPaths[i]?.setAttribute('d', ad[i]);
      if (gR.handL)
        gR.handL.style.transform = `translate(${q(A[0].handDx)}px,${q(A[0].handDy)}px) rotate(${q(
          A[0].handRot * 0.25
        )}deg)`;
      if (gR.handR)
        gR.handR.style.transform = `translate(${q(A[1].handDx)}px,${q(A[1].handDy)}px) rotate(${q(
          A[1].handRot * 0.25
        )}deg)`;

      if (gR.bookGroup)
        gR.bookGroup.style.transform = `translate(${q(pose.bookX)}px,${q(pose.bookY)}px) rotate(${q(
          pose.bookRot
        )}deg)`;
      const lapT = `translate(${q(pose.lapX)}px,${q(pose.lapY)}px) rotate(${q(
        pose.lapRot
      )}deg) scale(${pose.lapScale.toFixed(3)})`;
      if (gR.laptopGroup) {
        gR.laptopGroup.style.transform = lapT;
        gR.laptopGroup.setAttribute('opacity', (1 - pose.lapStowed).toFixed(3));
      }
      if (gR.lapShutBack) {
        gR.lapShutBack.style.transform = lapT;
        gR.lapShutBack.setAttribute('opacity', pose.lapStowed.toFixed(3));
      }
      // Clamshell: the shut slab hinges down out of sight exactly as the open
      // lid hinges up, so there is never a frame of flat "bars".
      const lidO = clamp(pose.lid, 0, 1.08);
      const unfold = clamp(lidO / 0.34);
      const shutT = `scaleY(${(1 - 0.72 * unfold).toFixed(3)})`;
      if (gR.lapShutGroup) {
        gR.lapShutGroup.setAttribute('opacity', (1 - unfold).toFixed(3));
        gR.lapShutGroup.style.transform = shutT;
      }
      if (gR.lapShutBackInner) gR.lapShutBackInner.style.transform = shutT;
      if (gR.lidGroup) {
        gR.lidGroup.setAttribute('opacity', clamp(lidO / 0.16).toFixed(3));
        gR.lidGroup.style.transform = `scaleY(${(0.04 + 0.96 * lidO).toFixed(3)})`;
      }

      // walk-in footsteps / sitting / props
      if (pose.stepL) score.step(0.85);
      if (pose.stepR) score.step(0.85);
      if (T >= GT.sitEnd) fire('sit', () => score.step(1.25));
      if (T >= GT.bookEnd) fire('book', () => score.bookDown());
      if (T >= GT.lidStart) fire('lid', () => score.lidOpen());

      // she fades up as she walks on and fades away before the loop re-cuts
      const girlAlpha = (
        ramp(-0.05, 0.34, T) * (1 - ramp(LOOP_DURATION - 0.75, LOOP_DURATION - 0.08, T))
      ).toFixed(3);
      if (girlWrapRef.current) {
        girlWrapRef.current.style.opacity = girlAlpha;
        girlWrapRef.current.style.transform = `translate3d(${q(girlParX)}px, ${q(girlParY)}px, 0)`;
      }
      if (girlShadowRef.current) {
        const sxPx = (pose.rootX / VB_W) * tg.girlGw;
        girlShadowRef.current.style.opacity = girlAlpha;
        girlShadowRef.current.style.transform = `translate3d(${q(
          girlParX + sxPx
        )}px, ${q(girlParY)}px, 0) scaleX(${(0.72 + 0.28 * pose.rootSX).toFixed(3)})`;
      }

      /* ---------- the dove, the envelope and the ticket ---------- */
      const freq = getWingFreq(T);
      st.prevPh = st.ph;
      st.ph = (st.ph + dt * freq) % 1;

      const cv = birdCanvasRef.current;
      const ctx = cv?.getContext('2d');
      let birdState = {
        t: T, birdActive: false, birdX: -999, birdY: 0, mailDropped: false,
        envX: 0, envY: 0, ticketActive: false, ticketX: tg.laptopX, ticketY: tg.laptopY,
        ticketArrived: false, ticketArrivedTime: TL,
      };
      if (ctx && st.intro <= 0) {
        ctx.setTransform(tg.dpr, 0, 0, tg.dpr, 0, 0);
        ctx.clearRect(0, 0, tg.W, tg.H);
        ctx.save();
        ctx.translate(girlParX, girlParY);
        birdState = renderBirdAndMail(ctx, T, st.ph, tg);
        ctx.restore();
      } else if (ctx) {
        ctx.setTransform(tg.dpr, 0, 0, tg.dpr, 0, 0);
        ctx.clearRect(0, 0, tg.W, tg.H);
      }

      // wingbeat whoosh, in step with the downstroke
      if (st.intro <= 0 && T < 8.35 && birdState.birdX > -60) {
        const p0 = st.prevPh;
        const p1 = st.ph;
        const delta = p1 >= p0 ? p1 - p0 : p1 + 1 - p0;
        const rel = ((0.21 - p0) % 1 + 1) % 1;
        if (rel < delta) score.flap(T < TR ? 1 : 0.72);
      }
      if (T >= 0.02) fire('birdIn', () => score.doveCall('enter'));
      if (T >= TR) fire('drop', () => score.doveCall('drop'));
      if (T >= TS) fire('peel', () => score.paperFlutter());
      if (T >= TR + 1.5) fire('envLand', () => score.envelopeLand());
      if (T >= TR + 2.6) fire('birdOut', () => score.doveCall('exit'));
      if (T >= TL) fire('ticket', () => score.ticketLand());

      /* ---------- ring, badge, paper plane ---------- */
      const lxPar = tg.laptopX + girlParX;
      const lyPar = tg.laptopY + girlParY;

      if (T >= TL && !st.ringTriggered) {
        st.ringTriggered = true;
        st.msgTriggered = true;
        if (ringRef.current) {
          ringRef.current.style.left = `${q1(lxPar)}px`;
          ringRef.current.style.top = `${q1(lyPar)}px`;
          ringRef.current.classList.remove('on');
          void ringRef.current.offsetWidth;
          ringRef.current.classList.add('on');
        }
        if (msgRef.current && msgPosRef.current) {
          msgRef.current.classList.remove('on');
          void msgRef.current.offsetWidth;
          msgRef.current.classList.add('on');
          msgPosRef.current.style.opacity = '1';
        }
        setSaid('Ticket created. Reference UB-2419 is queued for your desk.');
      }

      if (st.msgTriggered && msgPosRef.current) {
        msgPosRef.current.style.left = `${q1(lxPar - tg.girlGw * 0.2)}px`;
        msgPosRef.current.style.top = `${q1(tg.girlTop + girlParY - 4)}px`;
        if (T > TL + 4.2) {
          const fade = Math.max(0, 1 - (T - (TL + 4.2)) * 1.6);
          msgPosRef.current.style.opacity = String(fade);
        }
      }

      /* ---- plane: first in her hand, then flying ---- */
      const toScreen = (vx: number, vy: number) => ({
        x: tg.girlLeft + girlParX + (vx / VB_W) * tg.girlGw,
        y: tg.girlWrapTop + girlParY + ((vy - VB_TOP) / VB_FULL) * tg.girlWrapH,
      });

      if (planeRef.current) {
        let shown = false;
        if (pose.planeHand) {
          const s = toScreen(pose.planeHand.x, pose.planeHand.y);
          planeRef.current.style.transform = `translate(${q(s.x)}px,${q(s.y)}px) rotate(${q(
            pose.planeHand.rot - 8
          )}deg) scale(0.86,0.86)`;
          planeRef.current.style.opacity = String(ramp(TH.cue + 0.06, TH.cue + 0.24, T));
          shown = true;
        }
        if (T >= TH.release) {
          if (st.planeBuiltFor !== Math.round(tg.W)) {
            const hs = pose.planeHand
              ? toScreen(pose.planeHand.x, pose.planeHand.y)
              : toScreen(244, 126);
            st.plane = buildPlanePath(hs.x, hs.y, tg.W, tg.H);
            st.planeBuiltFor = Math.round(tg.W);
          }
          const u = clamp((T - TH.release) / PLANE_FLIGHT);
          if (st.plane && u <= 1) {
            const p = st.plane.at(u);
            planeRef.current.style.transform = `translate(${q(p.x)}px,${q(p.y)}px) rotate(${q(
              (p.ang * 180) / Math.PI
            )}deg) scale(${p.sc.toFixed(3)},${p.sc.toFixed(3)})`;
            planeRef.current.style.opacity = u > 0.965 ? String(clamp((1 - u) / 0.035)) : '1';
            shown = true;
            if (T - st.lastDotTime > 0.085 && u < 0.93) {
              st.lastDotTime = T;
              const dot = document.createElement('i');
              dot.className = 'dot';
              dot.style.left = `${q1(p.x)}px`;
              dot.style.top = `${q1(p.y)}px`;
              document.body.appendChild(dot);
              window.setTimeout(() => dot.remove(), 1450);
            }
          }
          fire('throw', () => score.planeThrow());
        }
        if (!shown) planeRef.current.style.opacity = '0';
      }

      /* ---------- face: gaze, blink, expression ---------- */
      const refs = girlAnimRefs.current;
      const birdWeight = ramp(1.0, 1.7, T) * (1 - ramp(TR - 0.15, TR + 0.25, T));
      const dropWeight = ramp(TR, TR + 0.3, T) * (1 - ramp(TL - 0.1, TL + 0.2, T));
      const celebrating = T >= TL && T < TL + 4.4;
      const planeWeight =
        ramp(TH.release - 0.35, TH.release + 0.2, T) * (1 - ramp(TH.watchEnd, TH.gazeEnd, T));

      let planeX = tg.laptopX;
      let planeY = tg.laptopY - 60;
      if (st.plane && T >= TH.release) {
        const p = st.plane.at(clamp((T - TH.release) / PLANE_FLIGHT));
        planeX = p.x - girlParX;
        planeY = p.y - girlParY;
      } else if (pose.planeHand) {
        const s = toScreen(pose.planeHand.x, pose.planeHand.y);
        planeX = s.x - girlParX;
        planeY = s.y - girlParY;
      }

      let targetHeadDeg = Math.sin(clock * 3.1) * 1.4;
      let targetPupilX = Math.sin(clock * 4.2) * 1.4;
      let targetPupilY = 2.6;
      let targetBrowY = 0;
      let targetCurious = 0;
      let targetHappy = 0;

      const eyeY = tg.girlTop + tg.girlGh * 0.34;

      if (birdWeight > 0.02) {
        const dx = birdState.birdX - tg.girlCx;
        const dy = birdState.birdY - eyeY;
        targetHeadDeg = lerp(targetHeadDeg, clamp((dx / tg.W) * 20, -12, 12), birdWeight);
        targetPupilX = lerp(targetPupilX, clamp((dx / 220) * 3.4, -3.4, 3.4), birdWeight);
        targetPupilY = lerp(targetPupilY, clamp((dy / 170) * 3.2, -3.6, 1.0), birdWeight);
        targetBrowY = -3.8 * birdWeight;
        targetCurious = birdWeight;
      }
      if (dropWeight > 0.02) {
        const focusX = birdState.ticketActive ? birdState.ticketX : birdState.envX;
        const focusY = birdState.ticketActive ? birdState.ticketY : birdState.envY;
        const dx = focusX - tg.girlCx;
        const dy = focusY - eyeY;
        targetHeadDeg = lerp(targetHeadDeg, clamp((dx / 240) * 8, -8, 8), dropWeight);
        targetPupilX = lerp(targetPupilX, clamp((dx / 160) * 2.8, -3, 3), dropWeight);
        targetPupilY = lerp(targetPupilY, clamp((dy / 120) * 2.8, -1.5, 3), dropWeight);
        targetBrowY = lerp(targetBrowY, -2.5, dropWeight);
        targetCurious = Math.max(targetCurious, 0.28 * dropWeight);
      }
      if (planeWeight > 0.02) {
        const dx = planeX - tg.girlCx;
        const dy = planeY - eyeY;
        targetHeadDeg = lerp(targetHeadDeg, clamp((dx / 300) * 15, -13, 13), planeWeight);
        targetPupilX = lerp(targetPupilX, clamp((dx / 240) * 3.2, -3.4, 3.4), planeWeight);
        targetPupilY = lerp(targetPupilY, clamp((dy / 200) * 3.2, -3.8, 1.2), planeWeight);
        targetBrowY = lerp(targetBrowY, -3.2, planeWeight);
        targetHappy = Math.max(targetHappy, 0.85 * planeWeight);
      }
      if (celebrating) {
        const bounce = Math.sin((T - TL) * 9) * Math.exp(-(T - TL) * 0.8) * 4.5;
        targetHeadDeg += bounce * (1 - planeWeight);
        targetBrowY = Math.min(targetBrowY, -3.6);
        targetHappy = Math.max(targetHappy, 1 - planeWeight * 0.4);
      }
      // walking in: eyes forward, chin level
      if (T < GT.sitEnd) {
        const w = (1 - ramp(GT.typeStart - 0.8, GT.typeStart, T)) * (1 - birdWeight) * (1 - dropWeight);
        targetPupilY = lerp(targetPupilY, 0.4, w);
        targetHeadDeg = lerp(targetHeadDeg, pose.headRot * 0.4, w * 0.6);
      }
      // the wind-up squint of concentration
      if (T >= TH.cue && T < TH.release) {
        const w = ramp(TH.cue, TH.windEnd, T);
        targetBrowY = lerp(targetBrowY, -1.2, w);
        targetCurious = Math.max(targetCurious, 0.5 * w);
      }

      const sm = 1 - Math.exp(-dt * 8.5);
      st.headAngle = lerp(st.headAngle, targetHeadDeg, sm);
      st.pupilX = lerp(st.pupilX, targetPupilX, sm);
      st.pupilY = lerp(st.pupilY, targetPupilY, sm);
      st.browY = lerp(st.browY, targetBrowY, sm);
      st.curiousAlpha = lerp(st.curiousAlpha, targetCurious, sm);
      st.happyAlpha = lerp(st.happyAlpha, targetHappy, sm);

      if (refs.headGroup)
        refs.headGroup.style.transform = `translate(${q(pose.headX)}px,${q(
          pose.headY
        )}px) rotate(${q(st.headAngle + pose.headRot)}deg)`;
      if (refs.hairGroup)
        refs.hairGroup.style.transform = `rotate(${q(pose.hairRot)}deg)`;
      if (refs.torsoGroup) {
        const breath = Math.sin(clock * 2.3) * 0.7;
        const happyBounce = celebrating
          ? Math.abs(Math.sin((T - TL) * 7.5)) * Math.exp(-(T - TL) * 0.9) * -2.8
          : 0;
        refs.torsoGroup.style.transform = `translateY(${q(breath + happyBounce + pose.bounce * 1.4)}px)`;
      }
      if (refs.pupilsGroup)
        refs.pupilsGroup.style.transform = `translate(${q(st.pupilX)}px, ${q(st.pupilY)}px)`;
      if (refs.browsGroup) refs.browsGroup.style.transform = `translateY(${q(st.browY)}px)`;

      const blinkCycle = clock % 3.4;
      const isBlinking = blinkCycle > 3.24 && blinkCycle < 3.38;
      if (refs.eyelidsGroup)
        refs.eyelidsGroup.style.transform = `scaleY(${isBlinking ? 1 : 0})`;

      if (refs.normalEyesGroup && refs.happyEyesGroup) {
        refs.normalEyesGroup.setAttribute('opacity', String(clamp(1 - st.happyAlpha * 1.25)));
        refs.happyEyesGroup.setAttribute('opacity', String(clamp(st.happyAlpha * 1.15)));
      }
      const calmAlpha = clamp(1 - st.curiousAlpha - st.happyAlpha);
      refs.mouthCalm?.setAttribute('opacity', String(calmAlpha));
      refs.mouthCurious?.setAttribute('opacity', String(st.curiousAlpha));
      refs.mouthHappy?.setAttribute('opacity', String(st.happyAlpha));
      refs.cheeksGroup?.setAttribute('opacity', String(0.6 + st.happyAlpha * 0.35));

      // typing hands live in the rig now; the fingers only tap once she is at the keyboard
      const typing = T > GT.typeStart && T < TH.cue ? 1 : T >= TH.recoverEnd ? 1 : 0;
      if (typing && refs.handL) {
        const extra = Math.sin(clock * 15) * 1.5;
        refs.handL.style.transform += ` translateY(${extra.toFixed(2)}px)`;
      }
      if (typing && refs.handR) {
        const extra = Math.cos(clock * 17) * 1.5;
        refs.handR.style.transform += ` translateY(${extra.toFixed(2)}px)`;
      }

      if (refs.laptopGlow) {
        const glowAlpha =
          T >= TL && T < TL + 3.2
            ? Math.sin(clamp((T - TL) / 3.2) * Math.PI) * 0.75
            : T >= GT.lidStart && T < GT.lidEnd
            ? 0.18 * ramp(GT.lidStart, GT.lidEnd, T)
            : 0;
        refs.laptopGlow.setAttribute('opacity', glowAlpha.toFixed(2));
      }

      score.tick();
    };

    rafId = requestAnimationFrame(frame);

    // debug hook: lets an automated browser freeze the film clock on any beat
    (window as unknown as Record<string, unknown>).__setT = (v: number) => {
      st.intro = 0;
      st.T = v;
      st.hold = v;
    };

    const onVisibility = () => {
      if (document.hidden) {
        cancelAnimationFrame(rafId);
        rafId = 0;
      } else if (!rafId) {
        st.lastNow = performance.now();
        rafId = requestAnimationFrame(frame);
      }
    };
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      cancelAnimationFrame(rafId);
      rafId = 0;
      window.removeEventListener('resize', onResize);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerleave', onPointerLeave);
      window.removeEventListener('click', onClick);
      document.removeEventListener('visibilitychange', onVisibility);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [restartAnimation]);

  /* ---------- sound gate (browsers need a gesture) ---------- */
  useEffect(() => {
    const unlock = () => {
      if (soundOn) score.unlock();
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, [soundOn]);

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    score.setEnabled(next);
    if (next) {
      score.unlock();
      window.setTimeout(() => score.distantSong(), 220);
      setSaid('Ambience on: wind, birdsong and paper.');
    } else {
      setSaid('Ambience muted.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    restartAnimation(true);
    score.uiTick();
    setAuthBtnText('Authenticating…');
    setSaid('Authenticating. The dove is fetching your ticket.');
    window.setTimeout(() => setAuthBtnText('Initialize auth'), 1800);
  };

  const replay = () => {
    restartAnimation(true);
    score.uiTick();
    setSaid('Scene replayed.');
  };

  return (
    <>
      <svg width="0" height="0" style={{ position: 'absolute' }} aria-hidden="true">
        <defs>
          <pattern id="g" patternUnits="userSpaceOnUse" width="160" height="160">
            <image ref={grainImgRef} id="gi" width="160" height="160" />
          </pattern>
        </defs>
      </svg>

      <div className="sky" />
      <div className="sky-tint" />

      {/* hanging sun & paper clouds */}
      <div className="layer" id="hang" ref={hangRef} style={{ zIndex: 1 }} />

      {/* nine-ish sheets of hand-cut paper, lifting in from the bottom */}
      <div className="layer cut place" ref={l1Ref} style={{ zIndex: 2, ['--i' as string]: 0, ['--sh' as string]: 3, ['--lift' as string]: '96px' }}>
        <svg />
      </div>
      <div className="layer cut place" ref={l2Ref} style={{ zIndex: 3, ['--i' as string]: 1, ['--sh' as string]: 3, ['--lift' as string]: '88px' }}>
        <svg />
      </div>
      <div className="layer cut place" ref={l3Ref} style={{ zIndex: 4, ['--i' as string]: 2, ['--sh' as string]: 4, ['--lift' as string]: '80px' }}>
        <svg />
      </div>
      <div className="layer cut place" ref={l4Ref} style={{ zIndex: 5, ['--i' as string]: 3, ['--sh' as string]: 4, ['--lift' as string]: '72px' }}>
        <svg />
      </div>
      <div className="layer cut place" ref={l5Ref} style={{ zIndex: 6, ['--i' as string]: 4, ['--sh' as string]: 5, ['--lift' as string]: '64px' }}>
        <svg />
      </div>
      <div className="layer cut place" ref={l6Ref} style={{ zIndex: 7, ['--i' as string]: 5, ['--sh' as string]: 6, ['--lift' as string]: '56px' }}>
        <svg />
      </div>

      {/* ground shadow + the girl */}
      <div id="gs" ref={girlShadowRef} />
      <div id="girl-wrap" ref={girlWrapRef} title="Click to replay the delivery">
        <PaperCutGirl animRefs={girlAnimRefs} onClick={replay} />
      </div>

      {/* foreground grass */}
      <div className="layer cut place" ref={l7Ref} style={{ zIndex: 12, ['--i' as string]: 6, ['--sh' as string]: 8, ['--lift' as string]: '112px' }}>
        <svg />
      </div>

      {/* falling paper leaves */}
      <div id="leaves" ref={leavesRef} />

      {/* dove + mail */}
      <canvas
        id="bird-canvas"
        ref={birdCanvasRef}
        aria-label="A white paper dove flies in from the left carrying a letter, drops it beside the girl, and exits to the right."
      />

      {/* layered paper-cut confirmation badge */}
      <div className="fx" id="msgPos" ref={msgPosRef}>
        <div id="msg" ref={msgRef}>
          <span className="sheet sheet-a" />
          <span className="sheet sheet-b" />
          <span className="sheet sheet-c" />
          <div className="face">
            <span className="stub">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path
                  d="M3 7.5l18-1.2v6a2.4 2.4 0 000 4.8v2.6L3 18.4v-5a2.4 2.4 0 000-4.8z"
                  fill="#f8efdb"
                  opacity="0.92"
                />
                <path
                  d="M8.4 12.6l2.5 2.5 4.9-5.2"
                  fill="none"
                  stroke="#c8642d"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
            <span className="copy">
              <b>
                Ticket <em>created</em>
              </b>
              <i>#UB-2419 · queued</i>
            </span>
            <span className="seal">✓</span>
          </div>
        </div>
      </div>
      <div className="fx" id="ring" ref={ringRef} />
      <svg className="fx" id="pl" ref={planeRef} width="38" height="30" viewBox="0 0 38 30">
        <path fill="#fbf4e4" stroke="#b89a6a" strokeWidth="0.7" d="M0 14L38 0L26 30L18 18Z" />
        <path fill="#e3d4b3" d="M18 18L38 0L20 22Z" />
      </svg>

      {/* ---------- the login column ---------- */}
      <div className="col" ref={colRef}>
        <div className="col-in">
          <div className="brand" ref={brandRef}>
            <div className="tag">
              <span className="hole" />
              <span className="knot" />
              <div className="tag-stack">
                <span />
                <span />
              </div>
              <svg className="tag-grain" ref={tagGrainRef} aria-hidden="true">
                <image width="100%" height="100%" />
              </svg>
              <svg ref={logoSvgRef} id="logo" viewBox="0 0 120 112" role="img" aria-label="UbiDesk logo" />
              <div className="word">
                Ubi<i>Desk</i>
              </div>
              <p>Sign in to your desk</p>
              <span className="rule" />
            </div>
          </div>

          <form className="auth-form" onSubmit={handleSubmit} autoComplete="off">
            <label htmlFor="uid" className="pcs" style={{ ['--d' as string]: '0.72s' }}>
              Enter ID // Email
            </label>
            <div className="fld pcs" style={{ ['--d' as string]: '0.8s' }}>
              <input id="uid" placeholder="UID // e.g. admin" autoComplete="username" />
            </div>

            <label htmlFor="pw" className="pcs" style={{ ['--d' as string]: '0.9s' }}>
              Enter password
            </label>
            <div className="fld pcs" style={{ ['--d' as string]: '0.98s' }}>
              <input
                id="pw"
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••••••"
                autoComplete="current-password"
              />
              <button
                type="button"
                id="eye"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                onClick={() => {
                  setShowPassword((p) => !p);
                  score.uiTick();
                }}
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                  <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" />
                  <circle cx="12" cy="12" r="3" />
                  {!showPassword && <path id="slash" d="M4 4l16 16" />}
                </svg>
              </button>
            </div>

            <a
              className="forgot pcs"
              style={{ ['--d' as string]: '1.06s' }}
              href="#forgot"
              onClick={(e) => {
                e.preventDefault();
                replay();
              }}
            >
              Forgot password?
            </a>

            <div className="cta pcs" ref={ctaRef} style={{ ['--d' as string]: '1.16s' }}>
              <div className="fld">
                <button type="submit" id="go">
                  {authBtnText}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

      {/* plate caption, bottom left — the diorama's own label */}
      <div className="plate pcs" style={{ ['--d' as string]: '1.5s' }}>
        <b>Plate IV · The helpdesk diorama</b>
        <span>
          Nine sheets of hand-cut paper, one dove with a letter in its beak, and a
          girl who walks in, sits down and throws your ticket out of the frame.
        </span>
      </div>

      <div className="chips">
        <button
          type="button"
          className="chip pcs"
          style={{ ['--d' as string]: '1.38s' }}
          aria-pressed={soundOn}
          onClick={toggleSound}
          title="Toggle the diorama's ambience"
        >
          {soundOn ? (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
              <path d="M4 9.5h3.2L12 5.4v13.2L7.2 14.5H4z" fill="currentColor" stroke="none" />
              <path d="M15.6 9.2a4 4 0 010 5.6M18.2 6.6a7.6 7.6 0 010 10.8" />
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
              <path d="M4 9.5h3.2L12 5.4v13.2L7.2 14.5H4z" fill="currentColor" stroke="none" />
              <path d="M16.4 9.6l4.4 4.8M20.8 9.6l-4.4 4.8" />
            </svg>
          )}
          {soundOn ? 'Sound on' : 'Sound off'}
        </button>
        <button type="button" className="chip pcs" style={{ ['--d' as string]: '1.46s' }} onClick={replay}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
            <path d="M20 12a8 8 0 11-2.6-5.9" />
            <path d="M20 4v4.6h-4.6" />
          </svg>
          Replay
        </button>
      </div>

      <div className="vig" />
      <p className="sr" role="status" aria-live="polite">
        {said}
      </p>
    </>
  );
}
