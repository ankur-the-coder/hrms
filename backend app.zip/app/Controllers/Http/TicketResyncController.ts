import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class TicketResyncController {
  /**
   * POST /tickets/uid/:uid/resync-mail
   * Unauthenticated — no agentAuth middleware.
   * Fetches the full conversation from Outlook, replaces all existing
   * ticket_messages/ticket_attachments for that ticket, and only uploads
   * attachments that are absent from the S3 bucket.
   */
  public async resyncByUid({ params, response }: HttpContextContract) {
    const uid = String(params.uid || '').replace(/^#/, '').trim()
    if (!uid) {
      return response.status(400).json({ status: false, error: 'ticket uid required' })
    }

    try {
      const { default: TicketResyncService } = await import('App/Services/TicketResyncService')
      const result = await TicketResyncService.resyncByUid(uid)
      return response.status(200).json(result)
    } catch (err: any) {
      // Structured error thrown from TicketResyncService (plain object with status + message)
      if (err && typeof err === 'object' && err.status) {
        return response.status(err.status).json({ status: false, error: err.message })
      }
      console.error(`[TicketResyncController][resyncByUid] uid=${uid} failed:`, err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Re-sync failed' })
    }
  }

  /**
   * POST /tickets/:id/resync-mail
   * Same behaviour but keyed by internal ticket ID instead of UID.
   * Also unauthenticated.
   */
  public async resyncById({ params, response }: HttpContextContract) {
    const ticketId = Number(params.id)
    if (!ticketId || isNaN(ticketId)) {
      return response.status(400).json({ status: false, error: 'valid ticket id required' })
    }

    try {
      const { default: TicketResyncService } = await import('App/Services/TicketResyncService')
      const result = await TicketResyncService.resyncById(ticketId)
      return response.status(200).json(result)
    } catch (err: any) {
      if (err && typeof err === 'object' && err.status) {
        return response.status(err.status).json({ status: false, error: err.message })
      }
      console.error(`[TicketResyncController][resyncById] id=${ticketId} failed:`, err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Re-sync failed' })
    }
  }
}
