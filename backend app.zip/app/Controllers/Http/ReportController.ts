import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import ReportService from 'App/Services/ReportService'

export default class ReportController {

  /**
   * GET /reports/360
   * Comprehensive 360-degree ticket report.
   * Strictly filters out soft-deleted tickets (`deleted_at IS NULL`).
   */
  public async getReport({ request, response }: HttpContextContract) {
    try {
      const filters = {
        startDate: request.input('startDate'),
        endDate: request.input('endDate'),
        source: request.input('source'),
        priority: request.input('priority'),
        agentId: request.input('agentId'),
        status: request.input('status'),
      }

      const data = await ReportService.get360Report(filters)
      return response.status(200).json({ status: true, data })
    } catch (err: any) {
      console.error('[ReportController][getReport] failed:', err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Failed to generate report' })
    }
  }

  /**
   * GET /reports/export
   * Generates a CSV export of summary KPIs & agent leaderboard for the selected window.
   */
  public async exportCsv({ request, response }: HttpContextContract) {
    try {
      const filters = {
        startDate: request.input('startDate'),
        endDate: request.input('endDate'),
        source: request.input('source'),
        priority: request.input('priority'),
        agentId: request.input('agentId'),
        status: request.input('status'),
      }

      const report = await ReportService.get360Report(filters)
      const lines: string[] = []

      // Section 1: Executive KPIs
      lines.push('--- EXECUTIVE SUMMARY ---')
      lines.push(`Report Window,${report.window.startDate} to ${report.window.endDate}`)
      lines.push(`Total Volume,${report.kpis.total}`)
      lines.push(`Closed Tickets,${report.kpis.closed}`)
      lines.push(`Open Backlog,${report.kpis.open}`)
      lines.push(`On Hold,${report.kpis.onHold}`)
      lines.push(`Escalated,${report.kpis.escalated}`)
      lines.push(`Reopened Tickets,${report.kpis.reopened} (${report.kpis.reopenRate}%)`)
      lines.push(`Resolution Rate,${report.kpis.resolutionRate}%`)
      lines.push(`Avg CSAT Score,${report.kpis.avgCsat || 'N/A'}`)
      lines.push(`Avg First Response Time (seconds),${report.kpis.avgFrtSeconds}`)
      lines.push(`Avg Resolution Time (seconds),${report.kpis.avgResolutionSeconds}`)
      lines.push('')

      // Section 2: Agent Performance Leaderboard
      lines.push('--- AGENT LEADERBOARD ---')
      lines.push('Agent Name,Role,Assigned,Closed,Open,Reopened,Resolution Rate (%),Avg CSAT,Avg Resolution Time (s)')
      for (const a of report.agentLeaderboard) {
        lines.push(`"${a.name}","${a.role}",${a.assigned},${a.closed},${a.open},${a.reopened},${a.resolutionRate}%,${a.avgCsat || 'N/A'},${a.avgResolutionSeconds || 0}`)
      }
      lines.push('')

      // Section 3: Channel Breakdown
      lines.push('--- INBOUND CHANNELS ---')
      lines.push('Channel,Total,Share (%),Closed,Open,Avg Resolution Time (s)')
      for (const c of report.channels) {
        lines.push(`"${c.source}",${c.total},${c.pct}%,${c.closed},${c.open},${c.avgResolutionSeconds || 0}`)
      }
      lines.push('')

      // Section 4: Top Organizations
      lines.push('--- TOP CLIENT ORGANIZATIONS ---')
      lines.push('Organization Name,Total Tickets,Closed,Open,Avg CSAT,VIP Priority')
      for (const o of report.topOrganizations) {
        lines.push(`"${o.orgName}",${o.ticketCount},${o.closedCount},${o.openCount},${o.avgRating || 'N/A'},${o.isHighPriority ? 'YES' : 'NO'}`)
      }

      const csvContent = lines.join('\n')
      response.header('Content-Type', 'text/csv')
      response.header('Content-Disposition', `attachment; filename="ubidesk-report-${Date.now()}.csv"`)
      return response.send(csvContent)
    } catch (err: any) {
      console.error('[ReportController][exportCsv] failed:', err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Failed to export CSV' })
    }
  }

  /**
   * GET /reports/schedules
   * List all configured report schedules.
   */
  public async listSchedules({ response }: HttpContextContract) {
    try {
      const schedules = await ReportService.getSchedules()
      return response.status(200).json({ status: true, schedules })
    } catch (err: any) {
      // If table doesn't exist yet before user runs SQL
      if (err?.code === 'ER_NO_SUCH_TABLE') {
        return response.status(200).json({
          status: true,
          schedules: [],
          notice: 'report_schedules table not created yet. Please execute the provided SQL.',
        })
      }
      console.error('[ReportController][listSchedules] failed:', err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Failed to load schedules' })
    }
  }

  /**
   * POST /reports/schedules
   * Create a new automated email report schedule.
   */
  public async createSchedule({ request, response }: HttpContextContract) {
    try {
      const body = request.all()
      if (!body.name || !body.recipients) {
        return response.status(400).json({ status: false, error: 'Name and email recipients are required' })
      }

      const currentAgent = (request as any).agent
      const schedule = await ReportService.createSchedule({
        name: String(body.name || ''),
        recipients: String(body.recipients || ''),
        frequency: body.frequency || 'weekly',
        day_of_week: body.day_of_week !== undefined ? Number(body.day_of_week) : 1,
        time_of_day: String(body.time_of_day || '09:00'),
        timezone: body.timezone || 'Asia/Kolkata',
        date_range: body.date_range || 'last_7_days',
        include_sections: body.include_sections,
        is_active: body.is_active !== undefined ? Boolean(body.is_active) : true,
        created_by: currentAgent?.id,
      })

      return response.status(201).json({ status: true, schedule })
    } catch (err: any) {
      console.error('[ReportController][createSchedule] failed:', err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Failed to create schedule' })
    }
  }

  /**
   * PUT /reports/schedules/:id
   * Update an existing report schedule.
   */
  public async updateSchedule({ params, request, response }: HttpContextContract) {
    try {
      const id = Number(params.id)
      if (!id || isNaN(id)) {
        return response.status(400).json({ status: false, error: 'Valid schedule ID required' })
      }

      const schedule = await ReportService.updateSchedule(id, request.all())
      return response.status(200).json({ status: true, schedule })
    } catch (err: any) {
      console.error('[ReportController][updateSchedule] failed:', err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Failed to update schedule' })
    }
  }

  /**
   * DELETE /reports/schedules/:id
   * Remove a report schedule.
   */
  public async deleteSchedule({ params, response }: HttpContextContract) {
    try {
      const id = Number(params.id)
      if (!id || isNaN(id)) {
        return response.status(400).json({ status: false, error: 'Valid schedule ID required' })
      }

      await ReportService.deleteSchedule(id)
      return response.status(200).json({ status: true, message: 'Schedule deleted successfully' })
    } catch (err: any) {
      console.error('[ReportController][deleteSchedule] failed:', err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Failed to delete schedule' })
    }
  }

  /**
   * POST /reports/schedules/:id/run
   * Force-run a schedule right now (immediate email dispatch test).
   */
  public async triggerScheduleNow({ params, response }: HttpContextContract) {
    try {
      const id = Number(params.id)
      if (!id || isNaN(id)) {
        return response.status(400).json({ status: false, error: 'Valid schedule ID required' })
      }

      const result = await ReportService.runSchedule(id)
      return response.status(200).json({ ...result, status: true })
    } catch (err: any) {
      console.error('[ReportController][triggerScheduleNow] failed:', err?.message)
      return response.status(500).json({ status: false, error: err?.message || 'Failed to send scheduled report' })
    }
  }
}
