import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import TicketMacroService from 'App/Services/TicketMacroService'

export default class MacroController {
  public async list() {
    return JSON.stringify(await TicketMacroService.list())
  }

  public async create({ request }: HttpContextContract) {
    const agent = (request as any).agent
    const macro = await TicketMacroService.create({
      name: request.input('name'),
      description: request.input('description'),
      setStatus: request.input('setStatus'),
      setPriority: request.input('setPriority'),
      setAssignedTo: request.input('setAssignedTo'),
      cannedReply: request.input('cannedReply'),
      createdBy: agent?.id,
    })
    return JSON.stringify(macro)
  }

  public async update({ params, request }: HttpContextContract) {
    const macro = await TicketMacroService.update(Number(params.id), {
      name: request.input('name'),
      description: request.input('description'),
      setStatus: request.input('setStatus'),
      setPriority: request.input('setPriority'),
      setAssignedTo: request.input('setAssignedTo'),
      cannedReply: request.input('cannedReply'),
      isActive: request.input('isActive'),
    })
    return JSON.stringify(macro)
  }

  public async remove({ params }: HttpContextContract) {
    return JSON.stringify(await TicketMacroService.remove(Number(params.id)))
  }
}
