import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import TicketFeedbackService from 'App/Services/TicketFeedbackService'

/**
 * All routes here are PUBLIC (no agentAuth) — they're reached by a customer
 * clicking a link in the ticket-closure email, not by a logged-in agent.
 * Access is gated by the per-ticket `feedback_token` (a random 48-char hex
 * string), never by the guessable ticket_uid.
 */
export default class TicketFeedbackController {
  // GET /feedback?t=<token>&r=<1-5>
  public async ratingClick({ request, response }: HttpContextContract) {
    const token = String(request.input('t', ''))
    const rating = Number(request.input('r'))
    const html = await TicketFeedbackService.handleRatingClick(token, rating)
    response.header('Content-Type', 'text/html')
    return response.send(html)
  }

  // POST /feedback/submit
  public async submit({ request, response }: HttpContextContract) {
    const token = String(request.input('t', ''))
    const html = await TicketFeedbackService.submitFeedback(token, {
      likedMost: request.input('likedMost'),
      improve: request.input('improve'),
      explanation: request.input('explanation'),
    })
    response.header('Content-Type', 'text/html')
    return response.send(html)
  }

  // GET /feedback/reopen?t=<token>
  public async reopenClick({ request, response }: HttpContextContract) {
    const token = String(request.input('t', ''))
    const html = await TicketFeedbackService.handleReopenClick(token)
    response.header('Content-Type', 'text/html')
    return response.send(html)
  }

  // POST /feedback/reopen/message
  public async reopenMessage({ request, response }: HttpContextContract) {
    const token = String(request.input('t', ''))
    const message = String(request.input('message', ''))
    const html = await TicketFeedbackService.submitReopenMessage(token, message)
    response.header('Content-Type', 'text/html')
    return response.send(html)
  }

  // ============================================================
  // JSON API for the standalone Angular /feedback page. Same public,
  // token-gated access as the HTML routes above — just returns data.
  // ============================================================

  // GET /api/feedback/view?t=<token>&r=<1-5>&reopen=1
  public async viewApi({ request, response }: HttpContextContract) {
    const token = String(request.input('t', ''))
    const rating = request.input('r') ? Number(request.input('r')) : undefined
    const reopen = ['1', 'true'].includes(String(request.input('reopen', '')))
    const data = await TicketFeedbackService.getViewData(token, rating, reopen)
    if (!data.found) return response.status(404).send(data)
    return response.send(data)
  }

  // POST /api/feedback/submit
  public async submitApi({ request, response }: HttpContextContract) {
    const token = String(request.input('t', ''))
    const data = await TicketFeedbackService.submitFeedbackData(token, {
      likedMost: request.input('likedMost'),
      improve: request.input('improve'),
      explanation: request.input('explanation'),
    })
    if (!data.found) return response.status(404).send(data)
    return response.send(data)
  }

  // POST /api/feedback/reopen-message
  public async reopenMessageApi({ request, response }: HttpContextContract) {
    const token = String(request.input('t', ''))
    const message = String(request.input('message', ''))
    const data = await TicketFeedbackService.submitReopenMessageData(token, message)
    if (!data.found) return response.status(404).send(data)
    return response.send(data)
  }
}