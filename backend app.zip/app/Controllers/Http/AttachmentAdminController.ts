import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Database from '@ioc:Adonis/Lucid/Database'

import AttachmentMigrationService from 'App/Services/AttachmentMigrationService'
import { isS3Url, deleteObjectFromS3, extractS3KeyFromUrl, listAllBucketObjects, S3ObjectSummary } from 'App/Helper/StorageS3'
import Application from '@ioc:Adonis/Core/Application'
import { existsSync } from 'fs'
import fs from 'fs/promises'
import path from 'path'

// File-extension groupings used by the `type` filter on GET /admin/attachments
// below. Plain SQL (MySQL REGEXP) fragments applied straight in the query —
// not pulled into Node and bucketed client-side — so pagination/counts stay
// correct against the filtered set.
const IMAGE_EXT_REGEXP = '\\.(jpg|jpeg|jfif|png|gif|webp|svg|bmp|tif|tiff|heic|heif)$'
const VIDEO_EXT_REGEXP = '\\.(mp4|webm|ogg|mov|m4v)$'
const DOC_EXT_REGEXP = '\\.(pdf|docx?|xlsx?|csv|pptx?|txt|log|json|md|xml|sql)$'

// Full-bucket listing is a real S3 walk (paginated ListObjectsV2 calls) —
// fine for an admin diagnostics page, not fine to re-run on every keystroke
// in the search box or every page click. Cached in-process for a few
// minutes; `?refresh=true` on GET /admin/attachments/bucket-audit bypasses it.
let bucketListCache: { objects: S3ObjectSummary[]; fetchedAt: number } | null = null
const BUCKET_LIST_CACHE_TTL_MS = 5 * 60 * 1000

async function getBucketObjectsCached(forceRefresh: boolean): Promise<S3ObjectSummary[]> {
  const isStale = !bucketListCache || (Date.now() - bucketListCache.fetchedAt) > BUCKET_LIST_CACHE_TTL_MS
  if (forceRefresh || isStale) {
    const objects = await listAllBucketObjects()
    bucketListCache = { objects, fetchedAt: Date.now() }
  }
  return bucketListCache!.objects
}

// Applies the GET /admin/attachments search/type filters to a fresh
// ticket_attachments↔tickets query builder. Called twice per request (once
// for the COUNT, once for the actual page of rows) — always pass a NEW
// builder in (see baseAttachmentsQuery below) rather than trying to clone
// one, so the two calls can't drift.
//
// Uses plain `like`/`not like` operators throughout — NOT Lucid's
// whereILike/whereNotILike helpers. Those helpers append a hardcoded
// `COLLATE utf8_bin` to the comparison, which MySQL rejects outright
// against utf8mb4 columns ("COLLATE utf8_bin is not valid for CHARACTER
// SET utf8mb4") — this DB's default charset. A bare `like` needs no
// COLLATE override; MySQL's default utf8mb4 collations are already
// case-insensitive. Same fix applied in ContactService.getContacts and
// TicketService's ticket search, which hit the identical error.
function applyAttachmentFilters(q: any, search: string, type: string) {
  if (search) {
    const like = `%${search}%`
    q.where((sub: any) => {
      sub.where('ta.file_name', 'like', like)
        .orWhere('t.ticket_uid', 'like', like)
        .orWhere('t.subject', 'like', like)
        .orWhere('t.customer_name', 'like', like)
        .orWhere('t.customer_email', 'like', like)
    })
  }
  if (type === 'image') {
    q.where((sub: any) => {
      sub.where('ta.content_type', 'like', 'image/%').orWhereRaw('ta.file_name REGEXP ?', [IMAGE_EXT_REGEXP])
    })
  } else if (type === 'video') {
    q.where((sub: any) => {
      sub.where('ta.content_type', 'like', 'video/%').orWhereRaw('ta.file_name REGEXP ?', [VIDEO_EXT_REGEXP])
    })
  } else if (type === 'document') {
    q.whereRaw('ta.file_name REGEXP ?', [DOC_EXT_REGEXP])
  } else if (type === 'other') {
    q.whereRaw('ta.file_name NOT REGEXP ?', [IMAGE_EXT_REGEXP])
      .whereRaw('ta.file_name NOT REGEXP ?', [VIDEO_EXT_REGEXP])
      .whereRaw('ta.file_name NOT REGEXP ?', [DOC_EXT_REGEXP])
      .where((sub: any) => {
        sub.whereNull('ta.content_type')
          .orWhere((s2: any) => s2.whereNot('ta.content_type', 'like', 'image/%').whereNot('ta.content_type', 'like', 'video/%'))
      })
  }
  return q
}

// Fresh query builder joining ticket_attachments to its parent ticket —
// call this once per use (count vs. page of rows) instead of sharing/
// cloning a builder instance.
function baseAttachmentsQuery() {
  return Database.from('ticket_attachments as ta').leftJoin('tickets as t', 't.id', 'ta.ticket_id')
}

function stableLocalAttachmentId(storagePath: string): number {
  let hash = 5381
  for (let i = 0; i < storagePath.length; i++) hash = ((hash << 5) + hash) ^ storagePath.charCodeAt(i)
  return Math.abs(hash | 0) || 1
}

function guessContentType(fileName: string): string {
  const ext = path.extname(fileName).toLowerCase()
  const types: Record<string, string> = {
    '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.jfif': 'image/jpeg', '.png': 'image/png',
    '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.bmp': 'image/bmp',
    '.tif': 'image/tiff', '.tiff': 'image/tiff', '.heic': 'image/heic', '.heif': 'image/heif',
    '.pdf': 'application/pdf', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.xls': 'application/vnd.ms-excel', '.csv': 'text/csv', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.doc': 'application/msword', '.txt': 'text/plain', '.log': 'text/plain', '.json': 'application/json',
    '.xml': 'application/xml', '.md': 'text/markdown', '.sql': 'application/sql',
    '.mp4': 'video/mp4', '.webm': 'video/webm', '.ogg': 'video/ogg', '.mov': 'video/quicktime', '.m4v': 'video/mp4',
    '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.m4a': 'audio/mp4', '.aac': 'audio/aac',
    '.zip': 'application/zip', '.rar': 'application/vnd.rar', '.7z': 'application/x-7z-compressed',
  }
  return types[ext] || 'application/octet-stream'
}

async function walkLocalAttachmentFiles(dir: string, relativeBase = ''): Promise<Array<{ fileName: string; storagePath: string; size: number; createdAt: string }>> {
  if (!existsSync(dir)) return []
  const entries = await fs.readdir(dir, { withFileTypes: true })
  const rows: Array<{ fileName: string; storagePath: string; size: number; createdAt: string }> = []

  for (const entry of entries) {
    if (entry.name === '.DS_Store') continue
    const fullPath = path.join(dir, entry.name)
    const relativePath = relativeBase ? path.posix.join(relativeBase, entry.name) : entry.name
    if (entry.isDirectory()) {
      rows.push(...await walkLocalAttachmentFiles(fullPath, relativePath))
    } else if (entry.isFile()) {
      const stat = await fs.stat(fullPath)
      rows.push({
        fileName: entry.name,
        storagePath: path.posix.join('ticket-attachments', relativePath),
        size: stat.size,
        createdAt: (stat.birthtimeMs > 0 ? stat.birthtime : stat.mtime).toISOString(),
      })
    }
  }

  return rows
}


export default class AttachmentAdminController {

  // GET /admin/attachments — paginated, searchable browser over every
  // attachment ubiDesk actually TRACKS, i.e. every row in ticket_attachments
  // (joined to its parent ticket for ticket_uid/subject/customer_name/
  // customer_email context), regardless of whether the underlying file
  // lives on S3 or (for not-yet-migrated legacy rows) local disk. This is
  // the "Tracked (from tickets)" tab — DB-driven on purpose, which is what
  // surfaces is_broken and the ticket/customer context per row. The
  // separate "S3 Bucket (all files)" tab (bucketAudit below) is the raw,
  // un-joined ListObjectsV2 walk instead.
  //
  // Query params: offset, limit, search (matches file name, ticket UID/
  // subject, or customer name/email), type ('image' | 'video' | 'document'
  // | 'other').
  public async list({ request, response }: HttpContextContract) {
    const offset = Number(request.input('offset', 0))
    const limit = Math.min(Number(request.input('limit', 40)), 100)
    const search = String(request.input('search', '')).trim()
    const type = String(request.input('type', '')).trim()

    try {
      const countRow = await applyAttachmentFilters(baseAttachmentsQuery(), search, type)
        .count('ta.id as c')
        .first()
      const total = Number(countRow?.c || 0)

      const rows = await applyAttachmentFilters(baseAttachmentsQuery(), search, type)
        .select(
          'ta.id', 'ta.ticket_id', 'ta.message_id', 'ta.file_name', 'ta.content_type',
          'ta.size', 'ta.storage_path', 'ta.created_at', 'ta.is_broken',
          't.ticket_uid', 't.subject as ticket_subject', 't.customer_name', 't.customer_email',
        )
        .orderBy('ta.created_at', 'desc')
        .offset(offset)
        .limit(limit)

      return response.ok({ status: true, data: rows, totalRecords: total })
    } catch (err: any) {
      console.error('[AttachmentAdminController][list] query failed:', err.message)
      return response.internalServerError({ status: false, msg: 'Failed to load tracked attachments — check server logs.' })
    }
  }

  // POST /admin/attachments/delete — { ids: number[] }. Removes each row's
  // underlying file (S3 object, or local-disk file for still-unmigrated
  // legacy rows) and its ticket_attachments row. Best-effort per file: one
  // failed delete doesn't stop the rest, and the response reports exactly
  // which ids succeeded/failed so the UI can show what actually happened.
  public async remove({ request, response }: HttpContextContract) {
    const ids: number[] = (request.input('ids', []) as any[]).map(Number).filter((n) => Number.isFinite(n))
    if (!ids.length) return response.badRequest({ status: false, msg: '`ids` (non-empty array) is required.' })

    const rows = await Database.from('ticket_attachments').whereIn('id', ids)

    const deleted: number[] = []
    const failed: { id: number; error: string }[] = []

    for (const row of rows) {
      try {
        if (isS3Url(row.storage_path)) {
          await deleteObjectFromS3(row.storage_path)
        } else {
          // Legacy, not-yet-migrated attachment — same local path
          // convention AttachmentMigrationService uses.
          const localPath = Application.publicPath('uploads', row.storage_path)
          if (existsSync(localPath)) await fs.unlink(localPath)
        }
        await Database.from('ticket_attachments').where('id', row.id).delete()
        deleted.push(row.id)
      } catch (err: any) {
        console.error(`[AttachmentAdminController][remove] failed to delete attachment id=${row.id}:`, err.message)
        failed.push({ id: row.id, error: err.message })
      }
    }

    // Any requested id that didn't match a row at all (already deleted,
    // bad id) — report it so the UI doesn't silently swallow it.
    const foundIds = new Set(rows.map((r) => r.id))
    const localFiles = await walkLocalAttachmentFiles(Application.publicPath('uploads', 'ticket-attachments'))
    const localById = new Map(localFiles.map((file) => [stableLocalAttachmentId(file.storagePath), file]))
    for (const id of ids) {
      if (foundIds.has(id)) continue
      const local = localById.get(id)
      if (!local) {
        failed.push({ id, error: 'Attachment not found.' })
        continue
      }
      try {
        const absolutePath = Application.publicPath('uploads', local.storagePath)
        if (existsSync(absolutePath)) await fs.unlink(absolutePath)
        deleted.push(id)
      } catch (err: any) {
        failed.push({ id, error: err.message })
      }
    }

    return response.ok({ status: failed.length === 0, deleted, failed })
  }

  // POST /admin/attachments/migrate-legacy
  // One-time backfill: uploads every still-on-local-disk ticket attachment to
  // S3 and rewrites its storage_path. Safe to call more than once — already-
  // migrated rows (storage_path already an http(s) URL) are skipped.
  //
  // Fire-and-forget on purpose: with a lot of old tickets (especially videos)
  // this can run well past a normal HTTP/gateway timeout. Watch server logs
  // for progress + the final summary instead of waiting on the response.
  public async migrateLegacy({ response }: HttpContextContract) {
    const pending = await Database.from('ticket_attachments').whereRaw("storage_path NOT LIKE 'http%'").count('* as c').first()
    const total = Number(pending?.c || 0)

    AttachmentMigrationService.migrateLegacyAttachmentsToS3().catch((err) => {
      console.error('[AttachmentAdminController] migrateLegacy background run failed:', err.message)
    })

    return response.ok({
      status: true,
      msg: `Migration started for ${total} legacy attachment(s) — see server logs for progress and the final summary.`,
      total,
    })
  }

  // GET /admin/attachments/broken — current snapshot of flagged-broken attachments, for a quick manual review.
  public async listBroken({ response }: HttpContextContract) {
    const rows = await Database.from('ticket_attachments')
      .where('is_broken', true)
      .select('id', 'ticket_id', 'message_id', 'file_name', 'storage_path', 'repair_attempts', 'last_checked_at')
      .orderBy('last_checked_at', 'desc')
      .limit(500)

    return response.ok({ status: true, count: rows.length, attachments: rows })
  }

  // POST /admin/attachments/dev/check-now — run the health-check/repair pass
  // immediately instead of waiting up to 6h for the scheduler's next tick.
  public async devCheckNow({ response }: HttpContextContract) {
    // console.log('[AttachmentAdminController][dev] manually triggering checkAndRepairBrokenAttachments()')
    const summary = await AttachmentMigrationService.checkAndRepairBrokenAttachments()
    return response.ok({ status: true, msg: 'Health check complete.', summary })
  }

  // GET /admin/attachments/bucket-audit — independent, ground-truth view of
  // the S3 bucket itself, walked directly via ListObjectsV2 rather than
  // read from ticket_attachments. Two things this catches that the
  // DB-driven list() above can't:
  //   1. Orphaned files — something got uploaded but its ticket_attachments
  //      row was later deleted (or never created), so it's silently taking
  //      up space with nothing pointing at it anymore.
  //   2. A true total bucket size — summing ticket_attachments.size only
  //      covers what we're tracking, not what's actually sitting in S3.
  //
  // Query params: offset, limit, search (matches on the S3 key/file name),
  // filter ('tracked' | 'untracked' | '' for all), refresh ('true' to
  // bypass the 5-minute cache and force a fresh S3 walk).
  public async bucketAudit({ request, response }: HttpContextContract) {
    const offset = Number(request.input('offset', 0))
    const limit = Math.min(Number(request.input('limit', 50)), 200)
    const search = String(request.input('search', '')).trim().toLowerCase()
    const filterMode = String(request.input('filter', '')).trim()
    const forceRefresh = String(request.input('refresh', '')) === 'true'

    let allObjects: S3ObjectSummary[]
    try {
      allObjects = await getBucketObjectsCached(forceRefresh)
    } catch (err: any) {
      console.error('[AttachmentAdminController][bucketAudit] failed to list bucket:', err.message)
      return response.internalServerError({ status: false, msg: 'Failed to list S3 bucket — check server logs.' })
    }

    // Cross-reference every bucket object against ticket_attachments (by S3
    // key, pulled back out of the stored URL) so we know which ones are
    // actually referenced by a ticket vs. orphaned.
    const trackedRows = await Database.from('ticket_attachments').select('storage_path', 'ticket_id', 'file_name')
    const trackedByKey = new Map<string, { ticketId: number; fileName: string }>()
    for (const row of trackedRows) {
      const key = extractS3KeyFromUrl(row.storage_path)
      if (key) trackedByKey.set(key, { ticketId: row.ticket_id, fileName: row.file_name })
    }

    const enriched = allObjects.map((obj) => {
      const tracked = trackedByKey.get(obj.key)
      const bucket = process.env.S3_AttachmentBucket
      const region = process.env.S3_REGION
      const url = region && bucket
        ? `https://${bucket}.s3.${region}.amazonaws.com/${obj.key}`
        : bucket
          ? `https://${bucket}.s3.amazonaws.com/${obj.key}`
          : ''
      return {
        key: obj.key,
        fileName: obj.key.split('/').pop() || obj.key,
        size: obj.size,
        lastModified: obj.lastModified,
        tracked: !!tracked,
        ticketId: tracked?.ticketId ?? null,
        url,
        contentType: guessContentType(obj.key),
      }
    })

    // Aggregate over the FULL bucket (not just the current filtered/paged
    // slice below) so the summary numbers stay accurate regardless of
    // whatever search/filter/pagination the UI is currently showing.
    const totalBucketSizeBytes = enriched.reduce((sum, o) => sum + o.size, 0)
    const trackedObjects = enriched.filter((o) => o.tracked)
    const untrackedObjects = enriched.filter((o) => !o.tracked)
    const trackedSizeBytes = trackedObjects.reduce((sum, o) => sum + o.size, 0)
    const untrackedSizeBytes = untrackedObjects.reduce((sum, o) => sum + o.size, 0)

    let filtered = enriched
    if (filterMode === 'tracked') filtered = trackedObjects
    else if (filterMode === 'untracked') filtered = untrackedObjects
    if (search) filtered = filtered.filter((o) => o.key.toLowerCase().includes(search))

    filtered = [...filtered].sort((a, b) => new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime())

    return response.ok({
      status: true,
      data: filtered.slice(offset, offset + limit),
      totalRecords: filtered.length,
      summary: {
        totalObjects: enriched.length,
        totalBucketSizeBytes,
        trackedObjects: trackedObjects.length,
        trackedSizeBytes,
        untrackedObjects: untrackedObjects.length,
        untrackedSizeBytes,
        cachedAt: bucketListCache?.fetchedAt ?? null,
      },
    })
  }
}