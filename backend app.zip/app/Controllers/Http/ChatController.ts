import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import ChatValidator from 'App/Validators/ChatValidator'
import ChatService from 'App/Services/ChatService'

export default class ChatController {


 



}