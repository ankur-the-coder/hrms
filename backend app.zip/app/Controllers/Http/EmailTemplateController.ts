import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import EmailTemplateValidator from 'App/Validators/EmailTemplateValidator'
import EmailTemplateService, { EmailTemplateKey } from 'App/Services/EmailTemplateService'

const VALID_KEYS: EmailTemplateKey[] = ['auto_ticket_response', 'ticket_closure', 'agent_footer_default']

function assertAdmin(request: any) {
  if (request.agent?.role !== 'admin') throw new Error('Admin only')
}

function assertValidKey(key: string): asserts key is EmailTemplateKey {
  if (!VALID_KEYS.includes(key as EmailTemplateKey)) throw new Error('Unknown template key')
}

export default class EmailTemplateController {
  /** GET /email-templates — any logged-in agent can read (footer editor needs the default as a starting point) */
  public async list() {
    return JSON.stringify(await EmailTemplateService.listAll())
  }

  /** POST /email-templates/:key/update — admin only */
  public async update({ request, params }: HttpContextContract) {
    assertAdmin(request)
    assertValidKey(params.key)
    const { html } = await request.validate(EmailTemplateValidator.update)
    return JSON.stringify(await EmailTemplateService.update(params.key, html, (request as any).agent.id))
  }

  /** POST /email-templates/:key/reset — admin only */
  public async reset({ request, params }: HttpContextContract) {
    assertAdmin(request)
    assertValidKey(params.key)
    return JSON.stringify(await EmailTemplateService.resetToDefault(params.key, (request as any).agent.id))
  }
}