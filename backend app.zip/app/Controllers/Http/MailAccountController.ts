import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Env from '@ioc:Adonis/Core/Env'
import Database from '@ioc:Adonis/Lucid/Database'
import MailAccountService from 'App/Services/MailAccountService'
import AuthTracer from 'App/Helper/AuthTracer'
import GraphWebhookNotificationService from 'App/Services/Graphwebhooknotificationservice'
import EmailToTicketService from 'App/Services/EmailToTicketService'

export default class MailAccountController {

  // GET /mail-accounts/connect — redirect the browser into Microsoft's OAuth consent screen.
  public async connect({ response }: HttpContextContract) {
    return response.redirect(MailAccountService.getAuthUrl())
  }

  // GET /mail-accounts/callback — Microsoft redirects here with ?code=...
public async callback({ request, response }: HttpContextContract) {
  const code = request.input('code')
  const tracer = new AuthTracer()
  tracer.step('callback_received', {
    hasCode: !!code,
    query: request.qs(),
    host: request.host(),
    protocol: request.protocol(),
    forwardedFor: request.header('x-forwarded-for'),
    forwardedProto: request.header('x-forwarded-proto'),
  })

  if (!code) {
    tracer.finish('failed')
    return response.status(400).send('Authentication failed — no code received.')
  }

  try {
    const email = await MailAccountService.handleCallback(code, undefined, tracer)
    tracer.finish('ok')
    return response.redirect(
      `${Env.get('FRONTEND_URL')}/settings/mail-accounts?mailConnected=${encodeURIComponent(email)}&traceId=${tracer.id}`
    )
  } catch (error: any) {
    console.error('[MailAccountController] callback failed:', error?.response?.data ?? error.message)
    tracer.finish('failed')
    return response.redirect(`${Env.get('FRONTEND_URL')}/settings/mail-accounts?mailConnectError=1&traceId=${tracer.id}`)
  }
}

  // GET /mail-accounts/debug/:traceId — fetch the full step-by-step trace for
  // a connect attempt. Frontend reads `traceId` off the redirect above and
  // hits this to display/log the whole thing.
  public async debugTrace({ params, response }: HttpContextContract) {
    const trace = AuthTracer.read(params.traceId)
    if (!trace) return response.notFound({ status: false, msg: 'Trace not found (expired, invalid id, or never written).' })
    return response.ok(trace)
  }

  // GET /mail-accounts — list connected mailboxes (no tokens returned)
  public async list() {
    return JSON.stringify(await MailAccountService.listAccounts())
  }

  // POST /mail-accounts/:id/disconnect
  public async disconnect({ params }: HttpContextContract) {
    return JSON.stringify(await MailAccountService.disconnect(Number(params.id)))
  }

  // POST /mail-accounts/:id/set-default — admin picks which connected mailbox
  // is used for auto-responses (e.g. the WhatsApp -> email ticket ack).
  public async setDefault({ params, response }: HttpContextContract) {
    const result = await MailAccountService.setDefault(Number(params.id))
    if (!result.status) return response.notFound(result)
    return response.ok(result)
  }

  // POST /mail/webhook — Microsoft Graph change notifications

  public async webhook({ request, response }: HttpContextContract) {
     console.log('[Graph Webhook] raw payload:', JSON.stringify(request.all(), null, 2))
    // validation handshake when the subscription is first created
    const validationToken = request.input('validationToken')
    console.log('this is validationtoken', validationToken)
    if (validationToken) {
      response.header('Content-Type', 'text/plain')
      return response.status(200).send(validationToken)
    }

    const notifications = request.input('value') as any[]
    console.log('this is notification', notifications)
    if (!notifications?.length) {
      return response.status(202).send('')
    }


    let notificationIds: number[] = []
    try {
      notificationIds = await GraphWebhookNotificationService.recordNotifications(notifications)
    } catch (err: any) {
   
      console.error('[MailAccountController] failed to persist incoming webhook notifications — NOT acking, Graph should retry:', err.message)
      return response.status(500).send('')
    }

    response.status(202).send('')

    setImmediate(async () => {
      await GraphWebhookNotificationService.processByIds(notificationIds)
    })
  }

  // ───────────────────────── Dev-only helpers for testing auto-renewal ─────────────────────────
  // Not mounted in production — see the NODE_ENV guard in ChatRoute.ts.

  // POST /mail-accounts/dev/:id/expire-soon — force subscription_expires_at to
  // 2 minutes from now, so you can watch the renewal scheduler pick it up
  // without waiting hours for a real Graph subscription to near expiry.
  public async devExpireSoon({ params, response }: HttpContextContract) {
    const id = Number(params.id)
    const expiresAt = new Date(Date.now() + 2 * 60 * 1000)
    const updated = await Database.from('mail_accounts').where('id', id).update({
      subscription_expires_at: expiresAt,
      updated_at: new Date(),
    })
    if (!updated) return response.notFound({ status: false, msg: 'Account not found' })
    console.log(`[MailAccountController][dev] forced mail_account id=${id} subscription_expires_at -> ${expiresAt.toISOString()} (2 min from now)`)
    return response.ok({ status: true, msg: `subscription_expires_at set to ${expiresAt.toISOString()}`, id, subscription_expires_at: expiresAt })
  }

  // POST /mail-accounts/dev/trigger-renewal — run the renewal check right now
  // instead of waiting for the interval, so you don't have to sit around.
  public async devTriggerRenewal({ response }: HttpContextContract) {
    console.log('[MailAccountController][dev] manually triggering renewExpiringSubscriptions()')
    await MailAccountService.renewExpiringSubscriptions()
    return response.ok({ status: true, msg: 'Renewal check triggered — see server logs.' })
  }

  // POST /admin/mail/reconcile?days=10 — on-demand run of
  // EmailToTicketService.reconcileMailHistory(). Walks every connected
  // mailbox's Inbox + Sent Items for the last `days` days and files in any
  // missing message/ticket it finds, without touching ticket status and
  // without sending any auto-ack email (see reconcileMailHistory's own
  // doc-comment for the full safety guarantees).
  //
  // Fire-and-forget, same pattern as migrateLegacy above: with several
  // mailboxes and a wide window this can run well past a normal HTTP
  // timeout. The response returns immediately; watch server logs (or call
  // this again later) for the per-mailbox summary
  // (ticketsCreated/messagesFilled/failed).
  public async reconcileMailHistory({ request, response }: HttpContextContract) {
    const days = Math.min(Math.max(Number(request.input('days', 10)) || 10, 1), 60)

    console.log(`[MailAccountController][reconcileMailHistory] starting on-demand reconciliation for the last ${days} day(s)`)
    EmailToTicketService.reconcileMailHistory(days)
      .then((results) => console.log('[MailAccountController][reconcileMailHistory] finished:', results))
      .catch((err) => console.error('[MailAccountController][reconcileMailHistory] failed:', err.message))

    return response.ok({
      status: true,
      msg: `Reconciliation started for the last ${days} day(s) across every connected mailbox — check server logs for the per-mailbox summary (tickets created / messages filled / failures) once it finishes.`,
      days,
    })
  }
}