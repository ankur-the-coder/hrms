import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import ContactService from 'App/Services/ContactService'

export default class ContactController {
  public async list({ request }: HttpContextContract) {
    return JSON.stringify(await ContactService.getContacts(
      Number(request.input('offset', 0)),
      Number(request.input('limit', 50)),
      request.input('search', ''),
      !!request.input('highPriorityOnly', false),
    ))
  }

  public async setPriority({ request }: HttpContextContract) {
    const id = Number(request.input('id'))
    const isHighPriority = !!request.input('isHighPriority')
    if (!id) return JSON.stringify({ status: false, msg: '`id` is required.' })
    const result = await ContactService.setPriority(id, isHighPriority)
    // Bumps every open ticket for this contact too (see
    // ContactService.setPriority) — push the same live-refresh events every
    // other ticket-mutating endpoint fires, so an agent already looking at
    // the ticket list sees the new priority without a manual refresh.
    if (result.status && result.updatedTickets) {
      const { io } = await import('../../../start/socket')
      io.emit('tickets_updated')
      io.emit('dashboard_stats_stale')
    }
    return JSON.stringify(result)
  }
}