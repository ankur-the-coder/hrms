import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Database from '@ioc:Adonis/Lucid/Database'
import TicketValidator from 'App/Validators/TicketValidator'
import TicketService from 'App/Services/TicketService'
import { uploadBufferToS3 } from 'App/Helper/StorageS3'
import { readFile } from 'node:fs/promises'

const VALID_STATUSES = ['open', 'on_hold', 'escalated', 'closed']

// Agents attach files to a reply BEFORE the message itself is created (the
// upload happens as soon as they pick a file in the composer, same UX as
// most chat/ticketing tools) — so this cap protects the upload step itself,
// independent of anything TicketService.addMessage later does with the
// resulting storage_path. Kept comfortably under Graph's ~3MB practical
// limit for inline (base64-in-JSON) message.attachments — see
// EmailToTicketService.buildGraphFileAttachments for why that matters for
// email sends specifically.
const MAX_ATTACHMENT_SIZE_BYTES = 15 * 1024 * 1024 // 15MB

/** Small manual guard for the new bulk-style endpoints — avoids touching
 *  the existing TicketValidator.ts, whose schema definitions I don't have
 *  in front of me. Swap these for real validator rules if you'd rather
 *  keep everything going through TicketValidator. */
function requireIdArray(input: any): number[] {
  const ids = Array.isArray(input) ? input.map(Number) : []
  if (!ids.length || ids.some((n) => Number.isNaN(n))) throw new Error('`ids` must be a non-empty array of numbers')
  return ids
}

export default class TicketController {
public async create({ request }: HttpContextContract) {
  const data = await request.validate(TicketValidator.createTicket)
  // Route now requires agentAuth (see Routes/ChatRoute.ts) specifically so
  // we know who's creating this ticket — needed below both to attribute
  // the opening message to the right agent and to resolve their personal
  // signature/footer.
  const requester = (request as any).agent

  // Agent explicitly picked someone in the Add Ticket modal — resolve the
  // name server-side (don't trust a client-supplied name) rather than
  // leaving assignment to the support-owner auto-assign fallback below.
  let assignedAgentName: string | null = null
  if (data.assignedTo) {
    const agent = await Database.from('support_agents').where('id', data.assignedTo).first()
    assignedAgentName = agent?.name ?? null
  }

  let ticket = await TicketService.createTicket({ ...data, assignedAgentName })

  // Manual creation is only ever reached through this HTTP endpoint (email/
  // WhatsApp intake call TicketService.createTicket directly and do their
  // own identification beforehand) — so it's safe to always run it here,
  // regardless of which "Channel" the agent picked in the Add Ticket modal.
  // finalizeManualTicketCreation only auto-assigns via support_owner_id
  // when the ticket isn't already assigned, so an explicit pick above is
  // left untouched. It no longer sends an auto-response email — see below.
  ticket = await TicketService.finalizeManualTicketCreation(ticket.id).catch((err) => {
    console.error(`[TicketController] manual-ticket finalization failed for ticket ${ticket.id}:`, err.message)
    return ticket
  })

  // The agent's own typed message (with attachments + their signature
  // footer) replaces the old auto-response — sent straight to the customer
  // as a real first reply. No-ops if the agent left the message blank and
  // attached nothing.
  ticket = await TicketService.sendManualTicketInitialMessage(
    ticket.id, data.message, data.attachments, requester
  ).catch((err) => {
    console.error(`[TicketController] initial message send failed for ticket ${ticket.id}:`, err.message)
    return ticket
  })

  const { io } = await import('../../../start/socket')
  io.emit('tickets_updated')
  io.emit('dashboard_stats_stale')

  return JSON.stringify(ticket)
}

/**
 * Lets the Add Ticket modal show the agent the real ticket ID *before*
 * they hit Submit. The same value is round-tripped back as `ticketUid` in
 * the create payload, so what's shown while creating is guaranteed to be
 * what actually gets saved (see TicketService.createTicket's reuse logic).
 */
public async nextUid({}: HttpContextContract) {
  const ticketUid = await TicketService.generateTicketUid()
  return JSON.stringify({ ticketUid })
}

  public async list({ request }: HttpContextContract) {
    const offset = Number(request.input('offset', 0))
    const limit  = Number(request.input('limit', 20))
    const status = request.input('status', '')
    const priority = request.input('priority', '')
    const resolvedToday = request.input('resolvedToday', false)
    const unassignedOnly = request.input('unassignedOnly', false) || request.input('unassigned', false)
    const source = request.input('source', '')
    const search = request.input('search', '')
    const unreadOnly = request.input('unreadOnly', false)
    const includeSpam = request.input('includeSpam', false)
    const deletedOnly = request.input('deletedOnly', false)
    const requester = (request as any).agent
    // Admin-only "Assigned To" filter — comma-separated agent ids
    // (?assignedTo=3,7,12). Re-checked server-side (not just hidden in the
    // UI): a non-admin's assignedTo is always ignored, same as before.
    const assignedToRaw = request.input('assignedTo', '')
    const assignedTo = requester?.role === 'admin' && assignedToRaw
      ? String(assignedToRaw).split(',').map((v: string) => Number(v)).filter((v: number) => Number.isFinite(v))
      : []
    // Organization-wise / contact-wise filters (Ticket List page) and the
    // star-rating filter behind the "Ratings" tab's dropdown. All four are
    // multi-select — comma-separated on the wire (?orgId=3,7&rating=4,5),
    // same convention as assignedTo above.
    const orgIdRaw = request.input('orgId', '')
    const orgId = orgIdRaw
      ? String(orgIdRaw).split(',').map((v: string) => Number(v)).filter((v: number) => Number.isFinite(v))
      : []
    const contactEmailRaw = request.input('contactEmail', '')
    const contactEmail = contactEmailRaw ? String(contactEmailRaw).split(',').filter(Boolean) : []
    const contactPhoneRaw = request.input('contactPhone', '')
    const contactPhone = contactPhoneRaw ? String(contactPhoneRaw).split(',').filter(Boolean) : []
    const ratingRaw = request.input('rating', '')
    const rating = ratingRaw
      ? String(ratingRaw).split(',').map((v: string) => Number(v)).filter((v: number) => Number.isFinite(v))
      : []
    // NEW: full sort control — whitelisted against a fixed column map inside
    // TicketService.getTickets, so anything unrecognized here just falls
    // back to the existing default (last_message_at desc).
    const sortBy = request.input('sortBy', '')
    const sortOrder = request.input('sortOrder', '')
    return JSON.stringify(await TicketService.getTickets(offset, limit, {
      status, priority, resolvedToday: resolvedToday === 'true' || resolvedToday === true, unassignedOnly: unassignedOnly === 'true' || unassignedOnly === true, source, search, unreadOnly, includeSpam, deletedOnly, assignedTo,
      orgId, contactEmail, contactPhone, rating, sortBy, sortOrder,
      requesterId: requester?.id,
      requesterRole: requester?.role,
    }))
  }

  public async statusCounts({ request }: HttpContextContract) {
    const requester = (request as any).agent
    return JSON.stringify(await TicketService.getStatusCounts(requester?.id, requester?.role))
  }

  /**
   * Powers the ticket-list "Organization" filter dropdown. Distinct from
   * OrganizationController.list (which pulls from the shared legacy
   * `Organization` table for the dedicated Organizations tab) — this reads
   * straight off `tickets.sender_org_id` / `tickets.sender_org_name`, so it
   * only ever lists orgs that actually have a ticket on file (open, closed,
   * or deleted — no status filter applied) and can never drift out of sync
   * with what agents actually see in the ticket list.
   */
  public async ticketOrganizations({ request }: HttpContextContract) {
    const search = request.input('search', '')
    return JSON.stringify(await TicketService.getTicketOrganizations(search))
  }

  public async detail({ params }: HttpContextContract) {
    const ticketId = Number(params.id)
    const result = await TicketService.getTicketById(ticketId)
    // Automatically trigger conversation sync in background for email tickets
    if (result?.ticket?.mail_conversation_id) {
      import('App/Services/EmailToTicketService').then(({ default: EmailToTicketService }) => {
        EmailToTicketService.syncFullConversation(ticketId).catch(() => null)
      }).catch(() => null)
    }
    return JSON.stringify(result)
  }

  public async updateStatus({ request }: HttpContextContract) {
    const { id, status, sendClosureMessage } = await request.validate(TicketValidator.updateTicket)
    const ticket = await TicketService.updateStatus(id, status!, !!sendClosureMessage)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    io.emit('dashboard_stats_stale')
    return JSON.stringify(ticket)
  }

  public async dashboardStats({ request }: HttpContextContract) {
    const widgetKey = request.input('widgetKey', undefined)
    const days = Number(request.input('days', 7))
    const requester = (request as any).agent
    return JSON.stringify(await TicketService.getDashboardStats(widgetKey, requester?.id, requester?.role, days))
  }

  public async updateDetails({ request }: HttpContextContract) {
    const data = await request.validate(TicketValidator.updateDetails)
    const ticket = await TicketService.updateTicketDetails(data.id, data)

    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(ticket)
  }

  public async assign({ request }: HttpContextContract) {
    const { ticketId, agentId, agentName } = await request.validate(TicketValidator.assignTicket)
    const ticket = await TicketService.assignTicket(ticketId, agentId, agentName, (request as any).agent)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(ticket)
  }

public async addMessage({ request }: HttpContextContract) {
  const data = await request.validate(TicketValidator.addMessage)
  console.log('[addMessage] requester=', (request as any).agent)
  return JSON.stringify(await TicketService.addMessage({ ...data, requester: (request as any).agent }))
}

  // ============================================================
  // OUTBOUND ATTACHMENTS
  // ============================================================
  /**
   * Agent-side upload for an attachment to go OUT with a reply. Deliberately
   * decoupled from addMessage(): the frontend uploads the file the moment
   * the agent picks it (so they see progress/errors immediately and can
   * remove it before sending), then passes the returned {fileName,
   * contentType, size, storagePath} back in the addMessage payload once
   * they actually hit Send — TicketService.addMessage links it to the new
   * message row at that point (see attachments handling there).
   *
   * multipart/form-data, field name "file". Returns the same shape
   * TicketAttachment rows already use elsewhere (ticket-detail.ts's
   * attachmentUrl() reads storage_path as-is), just without an id/ticket_id/
   * message_id yet since no message exists until Send.
   */
  public async uploadAttachment({ request, response }: HttpContextContract) {
    const file = request.file('file', { size: `${MAX_ATTACHMENT_SIZE_BYTES}` })
    if (!file) {
      return response.status(400).send({ status: false, msg: 'No file provided (expected multipart field "file").' })
    }
    if (!file.isValid) {
      return response.status(400).send({ status: false, msg: file.errors.map((e) => e.message).join('; ') || 'Invalid file.' })
    }
    if (!file.tmpPath) {
      return response.status(400).send({ status: false, msg: 'Upload failed — no temp path from multipart handler.' })
    }

    try {
      const buffer = await readFile(file.tmpPath)
      const contentType = file.headers?.['content-type'] || (file.type && file.subtype ? `${file.type}/${file.subtype}` : 'application/octet-stream')
      const safeName = (file.clientName || 'attachment').replace(/[/\\]/g, '_')
      const key = `agent-uploads/${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeName}`
      const storagePath = await uploadBufferToS3(key, buffer, contentType)

      return response.send({
        status: true,
        fileName: safeName,
        contentType,
        size: buffer.length,
        storagePath,
      })
    } catch (err: any) {
      console.error('[TicketController] uploadAttachment failed:', err.message)
      return response.status(500).send({ status: false, msg: 'Upload failed — please try again.' })
    }
  }

  public async remove({ request }: HttpContextContract) {
    if ((request as any).agent.role !== 'admin') return JSON.stringify({ status: false, msg: 'Admin only' })
    const id = Number(request.input('id'))
    const result = await TicketService.softDeleteTicket(id)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(result)
  }

  // ============================================================
  // READ / UNREAD
  // ============================================================
  public async markRead({ params }: HttpContextContract) {
    const result = await TicketService.markRead(Number(params.id))
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(result)
  }

  public async markUnread({ params }: HttpContextContract) {
    const result = await TicketService.markUnread(Number(params.id))
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(result)
  }

  // ============================================================
  // BULK
  // ============================================================
  public async bulkAssign({ request }: HttpContextContract) {
    const ids = requireIdArray(request.input('ids'))
    const agentId = Number(request.input('agentId'))
    const agentName = String(request.input('agentName'))
    const result = await TicketService.bulkAssign(ids, agentId, agentName, (request as any).agent)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(result)
  }

  public async bulkUpdateStatus({ request }: HttpContextContract) {
    const ids = requireIdArray(request.input('ids'))
    const status = String(request.input('status'))
    if (!VALID_STATUSES.includes(status)) return JSON.stringify({ status: false, msg: `Invalid status: ${status}` })
    const result = await TicketService.bulkUpdateStatus(ids, status)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(result)
  }

  public async bulkDelete({ request }: HttpContextContract) {
    if ((request as any).agent.role !== 'admin') return JSON.stringify({ status: false, msg: 'Admin only' })
    const ids = requireIdArray(request.input('ids'))
    const result = await TicketService.bulkDelete(ids)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(result)
  }

  public async markSpam({ request }: HttpContextContract) {
    const ids = requireIdArray(request.input('ids'))
    const spam = request.input('spam', true)
    const result = await TicketService.markSpam(ids, !!spam)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(result)
  }

  public async merge({ request }: HttpContextContract) {
    const sourceIds = requireIdArray(request.input('sourceIds'))
    const targetId = Number(request.input('targetId'))
    const ticket = await TicketService.mergeTickets(sourceIds, targetId, (request as any).agent)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(ticket)
  }

  public async updateResolution({ params, request }: HttpContextContract) {
    const resolutionCode = request.input('resolutionCode', undefined)
    const resolutionNotes = request.input('resolutionNotes', undefined)
    const ticket = await TicketService.updateResolution(Number(params.id), resolutionCode, resolutionNotes)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(ticket)
  }

  public async bulkApplyMacro({ request }: HttpContextContract) {
    const ids = requireIdArray(request.input('ids'))
    const macroId = Number(request.input('macroId'))
    const { default: TicketMacroService } = await import('app/Services/TicketMacroService')
    const result = await TicketMacroService.apply(ids, macroId, (request as any).agent)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    return JSON.stringify(result)
  }

  public async pendingTickets({ request }: HttpContextContract) {
    const offset = Number(request.input('offset', 0))
    const limit  = Number(request.input('limit', 7))
    const days = Number(request.input('days', 7))
    const requester = (request as any).agent
    const [rows, total] = await Promise.all([
      TicketService.getPendingTickets(offset, limit, requester?.id, requester?.role, days),
      TicketService.getPendingTicketsCount(requester?.id, requester?.role, days),
    ])
    return JSON.stringify({ rows, total })
  }

  public async chartsOverview({ request }: HttpContextContract) {
    const days = Number(request.input('days', 7))
    const requester = (request as any).agent
    const [statusDist, priorityDist, sourceDist, trend, agentWorkload, avgFirstResponseMinutes, ticketsByCategory, slaCompliance] = await Promise.all([
      TicketService.getStatusDistribution(requester?.id, requester?.role, days),
      TicketService.getPriorityDistribution(requester?.id, requester?.role, days),
      TicketService.getSourceDistribution(requester?.id, requester?.role, days),
      TicketService.getTicketsTrend(days, requester?.id, requester?.role),
      TicketService.getAgentWorkload(),    // universal — not role- or day-scoped, it's a live snapshot
      TicketService.getAvgFirstResponseTime(requester?.id, requester?.role, days),
      TicketService.getTicketsByCategory(requester?.id, requester?.role, days),
      TicketService.getSlaCompliance(requester?.id, requester?.role, days),
    ])
    return JSON.stringify({ statusDist, priorityDist, sourceDist, trend, agentWorkload, avgFirstResponseMinutes, ticketsByCategory, slaCompliance })
  }

  // ============================================================
  // DEV / TESTING ONLY — generate dummy tickets, no emails sent.
  // GET /dev/seed-tickets?count=200
  // ============================================================
  public async seedDummyTickets({ request }: HttpContextContract) {
    const count = Math.min(Math.max(Number(request.input('count', 200)) || 200, 1), 1000)
    const result = await TicketService.generateDummyTickets(count)
    const { io } = await import('../../../start/socket')
    io.emit('tickets_updated')
    io.emit('dashboard_stats_stale')
    return JSON.stringify(result)
  }

  // TicketController.ts
public async restore({ request }: HttpContextContract) {
  if ((request as any).agent.role !== 'admin') return JSON.stringify({ status: false, msg: 'Admin only' })
  const id = Number(request.input('id'))
  const result = await TicketService.restoreTicket(id)
  const { io } = await import('../../../start/socket')
  io.emit('tickets_updated')
  io.emit('dashboard_stats_stale')
  return JSON.stringify(result)
}

  /**
   * POST /tickets/:id/sync-mail
   * Triggers a full Outlook conversation sync for the given email ticket.
   * Fetches all messages from Microsoft Graph for the ticket's conversationId,
   * deduplicates against ticket_messages, and inserts any missing ones.
   * Safe to call repeatedly — never duplicates messages and never sends
   * auto-acknowledgement emails for backfilled history.
   */
  public async syncMail({ params, response }: HttpContextContract) {
    const ticketId = Number(params.id)
    if (!ticketId || isNaN(ticketId)) {
      return response.status(400).json({ status: false, error: 'Invalid ticket ID' })
    }

    try {
      const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
      const result = await EmailToTicketService.syncFullConversation(ticketId)
      return response.status(200).json({
        status: true,
        synced: result.synced,
        totalInConversation: result.totalInConversation,
        alreadyExisting: result.alreadyExisting,
      })
    } catch (err: any) {
      console.error(`[TicketController][syncMail] ticket #${ticketId} sync failed:`, err?.response?.data ?? err.message)
      return response.status(200).json({ status: false, synced: 0, error: err?.message || 'Sync failed' })
    }
  }


    /**
   * Standalone diagnostic endpoint.
   */
  public async rawMailByUid({ params, response }: HttpContextContract) {
    const uid = String(params.uid || '').replace(/^#/, '').trim()
    if (!uid) return response.status(400).json({ status: false, error: 'ticket uid required' })

    const ticket = await Database.from('tickets').where('ticket_uid', uid).first()
    if (!ticket) return response.status(404).json({ status: false, error: `No ticket found for uid ${uid}` })
    if (ticket.source !== 'email' || !ticket.mail_conversation_id) {
      return response.status(400).json({ status: false, error: `Ticket ${uid} has no mail conversation (source=${ticket.source})` })
    }

    try {
      const { default: MailAccountService } = await import('App/Services/MailAccountService')
      const axios = (await import('axios')).default

      const mailboxEmail = ticket.mailbox_email || (await MailAccountService.getDefaultAccount())?.email
      if (!mailboxEmail) return response.status(400).json({ status: false, error: 'No mailbox associated with this ticket' })

      const token = await MailAccountService.getValidAccessToken(mailboxEmail)
      if (!token) return response.status(502).json({ status: false, error: `Could not obtain access token for ${mailboxEmail}` })

      const GRAPH = 'https://graph.microsoft.com/v1.0'
      const select = 'id,subject,from,toRecipients,ccRecipients,bccRecipients,receivedDateTime,sentDateTime,uniqueBody,body,bodyPreview,conversationId,internetMessageId,hasAttachments'
      const conversationId = ticket.mail_conversation_id

      const messageMap = new Map<string, any>()
      let url: string | null =
       `${GRAPH}/me/messages?$filter=conversationId eq '${encodeURIComponent(conversationId)}'&$select=${select}&$top=100`
      while (url) {
        const { data }: any = await axios.get(url, {
          headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' },
        })
        for (const item of data.value ?? []) messageMap.set(item.id, item)
        url = data['@odata.nextLink'] ?? null
      }

      const messages = Array.from(messageMap.values()).sort(
        (a, b) => new Date(a.receivedDateTime || a.sentDateTime).getTime() - new Date(b.receivedDateTime || b.sentDateTime).getTime()
      )

      return response.status(200).json({
        status: true,
        ticket: { id: ticket.id, ticket_uid: ticket.ticket_uid, mailbox_email: mailboxEmail, conversation_id: conversationId },
        totalMessages: messages.length,
        messages,
      })
    } catch (err: any) {
      return response.status(200).json({ status: false, error: err?.response?.data ?? err.message })
    }
  }
  
}