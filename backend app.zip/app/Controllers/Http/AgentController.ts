import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import AgentValidator from 'App/Validators/AgentValidator'
import AgentService from 'App/Services/AgentService'
import HtmlSanitizer from 'App/Helper/HtmlSanitizer'

function assertAdmin(request: any) {
  if (request.agent?.role !== 'admin') throw new Error('Admin only')
}

export default class AgentController {
  public async list() {
    return JSON.stringify(await AgentService.list())
  }
  public async create({ request }: HttpContextContract) {
    assertAdmin(request)
    const data = await request.validate(AgentValidator.create)
    return JSON.stringify(await AgentService.create(data))
  }
  public async update({ request }: HttpContextContract) {
    assertAdmin(request)
    const data = await request.validate(AgentValidator.update)
    return JSON.stringify(await AgentService.update(data.id, data)) 
  }
  public async remove({ request }: HttpContextContract) {
    assertAdmin(request)
    return JSON.stringify(await AgentService.remove(Number(request.input('id'))))
  }

  /** GET /agents/:id/signature — accessible by owner agent OR admin */
  public async getSignature({ request, response }: HttpContextContract) {
    const targetId = Number((request as any).param('id') ?? request.input('id'))
    const requester = (request as any).agent
    if (!requester) return response.unauthorized({ error: 'Unauthorized' })
    if (requester.role !== 'admin' && Number(requester.id) !== targetId) {
      return response.forbidden({ error: 'Forbidden' })
    }
    return JSON.stringify(await AgentService.getSignature(targetId))
  }

  /** POST /agents/:id/signature — accessible by owner agent OR admin */
  public async updateSignature({ request, response }: HttpContextContract) {
    const targetId = Number((request as any).param('id') ?? request.input('id'))
    const requester = (request as any).agent
    if (!requester) return response.unauthorized({ error: 'Unauthorized' })
    if (requester.role !== 'admin' && Number(requester.id) !== targetId) {
      return response.forbidden({ error: 'Forbidden' })
    }
    const signatureHtml: string = HtmlSanitizer.sanitize(request.input('signature_html') ?? '')
    return JSON.stringify(await AgentService.updateSignature(targetId, signatureHtml))
  }
}