import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import SettingsService from 'App/Services/SettingsService'

export default class SettingsController {
  public async list() {
    return JSON.stringify(await SettingsService.getAll())
  }
  public async update({ request }: HttpContextContract) {
    if ((request as any).agent.role !== 'admin') return JSON.stringify({ status: false, msg: 'Admin only' })
    const { key, value } = request.only(['key', 'value'])
    return JSON.stringify(await SettingsService.set(key, value, (request as any).agent.id))
  }
}