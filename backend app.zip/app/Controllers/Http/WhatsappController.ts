import { HttpContext } from '@adonisjs/core/build/standalone'
import WhatsappService from 'App/Services/WhatsappService'
import { io } from '../../../start/socket'

// This controller is transport-only: parse the HTTP request, call
// WhatsappService for all business logic, translate the result into an HTTP
// response and (where relevant) socket events. No DB/axios calls live here
// anymore — see App/Services/WhatsappService.ts.
export default class WhatsappWebhooksController {
  // 1. Verification handshake from Meta
  public async verify({ request, response }: HttpContext) {
    const mode = request.input('hub.mode')
    const token = request.input('hub.verify_token')
    const challenge = request.input('hub.challenge')

    // [WA-TRACE V0] Fires on EVERY verify handshake attempt, pass or fail.
    // If you click "Verify and save" in Meta and this line never appears in
    // your console at all, Meta isn't reaching this server — same class of
    // problem as W0 never firing for messages (stale ngrok URL, tunnel down,
    // wrong port). If it DOES fire but verification still fails, the token
    // mismatch below tells you why.
    console.log(`[WA-TRACE V0] verify hit — mode="${mode}" token="${token}"`)

    if (WhatsappService.verifyHandshake(mode, token)) {
      console.log('✅ Meta Webhook Verified Successfully')
      return response.status(200).send(challenge)
    }
    console.error(`[WA-TRACE V0-FAIL] handshake rejected — token "${token}" does not match expected WA_VERIFY_TOKEN`)
    return response.status(403)
  }

  // 2. Handle incoming WhatsApp messages from customers
  //
  // Meta expects a fast 200 (it will retry — repeatedly — if it doesn't get
  // one quickly). The old version awaited the ENTIRE pipeline (DB lookups,
  // an SMTP send, an outbound Graph API call) before responding, which
  // regularly took 30-55s. That caused Meta to fire duplicate webhook
  // deliveries for the same message, which in turn raced each other into
  // creating multiple tickets for one message.
  //
  // Fix: `claim()` does exactly one fast, atomic, indexed DB insert to
  // dedupe on Meta's message id — nothing else. We respond to Meta
  // immediately after that. All the slow work (ticket creation,
  // identification, auto-email, auto-WhatsApp ack) happens afterwards, off
  // the request/response cycle, and can never turn into an HTTP 500 back to
  // Meta (which would itself trigger yet another retry).
  public async handle({ request, response }: HttpContext) {
    const body = request.body()

    // Delivery/read receipts arrive as their own payload shape — `statuses`,
    // not `messages` — and aren't tickets, so they skip the claim/dedupe
    // pipeline entirely. Same fast-200-then-work-in-background pattern below.
    // [WA-TRACE W0] Everything Meta sent us for this webhook call. If you
    // NEVER see this log line when you know a message was delivered/read,
    // the problem is upstream of our code entirely — Meta isn't calling our
    // webhook URL for status events (check the Meta App's webhook field
    // subscriptions, and that the URL Meta has on file is actually this
    // server, not a stale ngrok/tunnel URL).
    console.log('[WA-TRACE W0] raw webhook body:', JSON.stringify(body))

    const statusEvent = body?.entry?.[0]?.changes?.[0]?.value?.statuses?.[0]
    if (statusEvent) {
      // [WA-TRACE W1] The specific status event we parsed out. `id` here
      // MUST exactly match a `graph_message_id` already stored on some row
      // in ticket_messages, or W3 below will report "NOT FOUND".
      console.log('[WA-TRACE W1] statusEvent parsed:', JSON.stringify(statusEvent))
      response.status(200).send('EVENT_RECEIVED')
      WhatsappService.updateDeliveryStatus(statusEvent)
        .then((result) => {
          // [WA-TRACE W6] null here means updateDeliveryStatus decided NOT
          // to update anything (message not found, or an out-of-order/
          // duplicate status that ranked lower than what's already stored).
          console.log('[WA-TRACE W6] updateDeliveryStatus result:', result ? JSON.stringify(result.message) : 'null (no-op — see W3/W4 logs for why)')
          if (result) io.to(`ticket_${result.ticketId}`).emit('message_updated', result.message)
        })
        .catch((err) => console.error('[WA-TRACE W6-ERR] status update threw:', err))
      return
    }

    let claim: Awaited<ReturnType<typeof WhatsappService.claim>>
    try {
      claim = await WhatsappService.claim(body)
    } catch (err) {
      // Even a failure to claim must not surface as non-200 to Meta.
      console.error('[WhatsappController] claim() failed:', err)
      return response.status(200).send('EVENT_RECEIVED')
    }

    // Ack Meta right away — whether this was a duplicate retry, an
    // irrelevant payload, or a message we just claimed. Nothing below
    // this line is allowed to block the response.
    response.status(200).send('EVENT_RECEIVED')

    if (!claim.ok) return // duplicate delivery of an already-claimed message, or not a message event — nothing more to do

    WhatsappService.processClaimedMessage(claim)
      .then((result) => {
        if (!result.handled) return
        if (result.isNewTicket) {
          io.emit('tickets_updated')
        } else if (result.lastMessage) {
          io.to(`ticket_${result.ticket.id}`).emit('new_ticket_message', result.lastMessage)
          io.emit('ticket_bump', { ticketId: result.ticket.id })
        }
        io.emit('dashboard_stats_stale')

        // Auto-response messages (only present for a new, identified sender)
        if (result.autoEmailMessage) {
          io.to(`ticket_${result.ticket.id}`).emit('new_ticket_message', result.autoEmailMessage)
        }
        if (result.autoWhatsAppMessage) {
          io.to(`ticket_${result.ticket.id}`).emit('new_ticket_message', result.autoWhatsAppMessage)
        }
      })
      .catch((err) => {
        // This is now the ONLY place a failure in the pipeline can land.
        // It must never be re-thrown — Meta already has its 200.
        console.error('[WhatsappController] background WhatsApp processing failed:', err)
      })
  }

  // 3. Send an outbound WhatsApp message (used by "New Chat" AND by replies
  // inside an existing conversation thread). See WhatsappService.sendOutbound
  // for why this endpoint is dispatch-only and doesn't write to ticket_messages.
  public async send({ request, response }: HttpContext) {
    const { ticketId, recipientPhone, messageText } = request.only(['ticketId', 'recipientPhone', 'messageText'])

    if (!messageText) {
      return response.badRequest({ success: false, error: 'messageText is required.' })
    }

    try {
      const data = await WhatsappService.sendOutbound({ ticketId, recipientPhone, messageText })
      return response.ok({ success: true, data })
    } catch (error: any) {
      const apiMessage = error.response?.data?.error?.message
        || (error instanceof Error ? error.message : 'An unexpected error occurred')
      return response.badRequest({ success: false, error: apiMessage })
    }
  }

  public async list({ response }: HttpContext) {
    return response.ok(await WhatsappService.listActiveAccounts())
  }

  public async connect({ request, response, auth }: HttpContext & { auth?: any }) {
    const { phoneNumberId, wabaId, displayPhoneNumber, accessToken } = request.only([
      'phoneNumberId', 'wabaId', 'displayPhoneNumber', 'accessToken'
    ])

    if (!phoneNumberId || !accessToken) {
      return response.badRequest({ message: 'Phone Number ID and Access Token are required.' })
    }

    try {
      const { verifiedName } = await WhatsappService.connectAccount({
        phoneNumberId, wabaId, displayPhoneNumber, accessToken, agentId: auth?.user?.id || null,
      })
      return response.ok({ success: true, verifiedName })
    } catch (error: any) {
      const apiMessage = error.response?.data?.error?.message || error.message || 'Meta API verification failed.'
      return response.badRequest({
        message: `Failed to authenticate with Meta Graph API: ${apiMessage}`
      })
    }
  }

  public async disconnect({ params, response }: HttpContext) {
    await WhatsappService.disconnectAccount(params.id)
    return response.ok({ success: true })
  }

  public async retryMessage({ params, response }: HttpContext) {
    const result = await WhatsappService.retryMessage(params.messageId)

    if ('notFound' in result) return response.notFound({ message: 'Message not found' })
    if ('notFailed' in result) return response.badRequest({ message: 'Message is not in a failed state.' })
    if ('ticketNotFound' in result) return response.notFound({ message: 'Ticket not found' })
    if ('unknownChannel' in result) return response.badRequest({ message: 'Unknown channel for this message.' })

    io.to(`ticket_${result.ticketId}`).emit('message_updated', result.updated)
    return response.ok({ success: result.success, message: result.updated })
  }
}