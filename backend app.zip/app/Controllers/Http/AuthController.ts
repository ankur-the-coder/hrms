import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import AuthValidator from 'App/Validators/AuthValidator'
import AuthService from 'App/Services/AuthService'

export default class AuthController {
  public async login({ request }: HttpContextContract) {
    const { username, password, force } = await request.validate(AuthValidator.login)
    return JSON.stringify(await AuthService.login(username, password, !!force))
  }

  public async logout({ request }: HttpContextContract) {
  const agent = (request as any).agent
  return JSON.stringify(await AuthService.logout(agent.id))
}
}