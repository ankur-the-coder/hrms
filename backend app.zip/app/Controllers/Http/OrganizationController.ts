import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import OrganizationService from 'App/Services/OrganizationService'

export default class OrganizationController {
  public async list({ request }: HttpContextContract) {
    const offset = Number(request.input('offset', 0))
    const limit = Number(request.input('limit', 50))
    const search = request.input('search', '')
    const highPriorityOnly = !!request.input('highPriorityOnly', false)
    // NEW: ?withTicketsOnly=true — used by the ticket-list "Organization"
    // filter dropdown, which should only ever offer orgs that actually own
    // at least one ticket (open, closed, or deleted). The Organizations
    // settings tab itself still calls this without the flag, unaffected.
    const withTicketsOnly = !!request.input('withTicketsOnly', false)
    return JSON.stringify(await OrganizationService.listOrganizations(offset, limit, search, highPriorityOnly, withTicketsOnly))
  }

  public async setPriority({ request }: HttpContextContract) {
    const orgId = Number(request.input('orgId'))
    const orgName = request.input('orgName', null)
    const isHighPriority = !!request.input('isHighPriority')
    const requester = (request as any).agent
    if (!orgId) return JSON.stringify({ status: false, msg: '`orgId` is required.' })
    const result = await OrganizationService.setPriority(orgId, orgName, isHighPriority, requester?.id)
    // Same reasoning as ContactController.setPriority — push a live refresh
    // when this flip just bumped one or more open tickets.
    if (result.status && result.updatedTickets) {
      const { io } = await import('../../../start/socket')
      io.emit('tickets_updated')
      io.emit('dashboard_stats_stale')
    }
    return JSON.stringify(result)
  }
}