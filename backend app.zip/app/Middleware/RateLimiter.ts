import type { HttpContextContract } from "@ioc:Adonis/Core/HttpContext";
import Redis from "@ioc:Adonis/Addons/Redis";
export default class RateLimiter {
  public async handle(
    { request, response }: HttpContextContract,
    next: () => Promise<void>
  ) {
 
    let setTimeLimit = 10; // Expiry time in seconds
    let numberOfRequest = 30;
    let empId;
    let params = request.all();
    let parameterFilter = Object.keys(params);
    parameterFilter = parameterFilter.filter(
      (row) =>
        row == "empid" ||
        row == "uid" ||
        row == "Empid" ||
        row == "empId" ||
        row == "EmpId" ||
        row == "employeeId" ||
        row == "eId" ||
        row == "userId" ||
        row == "ExternalId"
    );
    empId = request.input(parameterFilter[0]);
    const redisId = `Global:${empId}`;
    // Atomic operation: Set key with expiry if it doesn't exist
    let isNewKey = await Redis.set(redisId, 1, "EX", setTimeLimit, "NX");
    let requests;
    if (isNewKey === "OK") {
      // Key was newly created with value 1
      requests = 1;
    } else {
      // Key already exists, increment it
      requests = await Redis.incr(redisId);
      // Ensure the key always has an expiration
      let ttl = await Redis.ttl(redisId);
      if (ttl === -1) {
        await Redis.expire(redisId, setTimeLimit);
      }
    }
    if (requests > numberOfRequest) {
      console.log("Request limit exceeded");
      return response.status(429).send({ message: "Request limit exceeded" });
    }
    await next();
  }
}
