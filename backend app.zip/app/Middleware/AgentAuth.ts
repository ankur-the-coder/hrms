import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import AuthService from 'App/Services/AuthService'

export default class AgentAuth {
  public async handle({ request, response }: HttpContextContract, next: () => Promise<void>) {
    const header = request.header('authorization') || ''
    const token = header.replace(/^Bearer\s+/i, '')
    const agent = await AuthService.getAgentFromToken(token)
    if (!agent) return response.status(401).send({ status: false, msg: 'Unauthorized' })
    ;(request as any).agent = agent
    await next()
  }
}