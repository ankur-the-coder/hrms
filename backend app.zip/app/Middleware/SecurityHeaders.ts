import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class SecurityHeaders {
  public async handle({ response }: HttpContextContract, next: () => Promise<void>) {
    response.header('X-Content-Type-Options', 'nosniff')
    response.header('X-Frame-Options', 'DENY')
    response.header('Content-Security-Policy', "default-src 'self'; frame-ancestors 'none'; script-src 'self'")
    response.header('Referrer-Policy', 'no-referrer')
    await next()
  }
}
