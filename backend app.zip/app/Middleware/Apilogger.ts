import type { HttpContextContract } from "@ioc:Adonis/Core/HttpContext";
import { DateTime } from "luxon";
import Logger from "@ioc:Adonis/Core/Logger";
import Database from "@ioc:Adonis/Lucid/Database";

interface ApiMetrics {
  endpoint: string;
  method: string;
  responseTime: number;
  statusCode: number;
  userIP: string;
  userAgent: string;
  timestamp: string;
  userId?: number | string | null;
  errorMessage?: string;
  requestSize: number;
  responseSize?: number;
  memoryUsage: number;
  platform?: string;
}

export default class Apilogger {
  constructor() {
    console.log("✅ API Logger Middleware Initialized");
  }

  public async handle(
    { request, response }: HttpContextContract,
    // { request, response, auth }: HttpContextContract,
    next: () => Promise<void>
  ) {
    const startTime = process.hrtime.bigint();
    const startMemory = process.memoryUsage();
    const requestSize = JSON.stringify(request.body() || {}).length || 0;

    let errorMessage: string | undefined;
    let statusCode = 200;

    try {
      await next();
      statusCode = response.getStatus();
    } catch (error) {
      statusCode = error.status || 500;
      errorMessage = error.message;
      throw error;
    } finally {
      const endTime = process.hrtime.bigint();
      const endMemory = process.memoryUsage();
      const responseTime = Number(endTime - startTime) / 1000000; // ms

      const metrics: ApiMetrics = {
        endpoint: request.url(),
        method: request.method(),
        responseTime,
        statusCode,
        userIP: request.ip(),
        userAgent: request.header("user-agent") || "",
        timestamp: DateTime.now().toISO(),
        // userId: auth.user ? auth.user.id : null,
        errorMessage,
        requestSize,
        responseSize: response.getHeader("content-length")
          ? parseInt(response.getHeader("content-length") as string)
          : 0,
        memoryUsage: endMemory.heapUsed - startMemory.heapUsed,
        platform: request.header("platform") || "Web 2.0",
      };

      await this.storeMetrics(metrics);
      await this.updateAggregatedStats(metrics);

      this.logMetrics(metrics);
    }
  }

  /** Store individual API request */
  private async storeMetrics(metrics: ApiMetrics) {
    try {
      await Database.table("api_logs").insert({
        endpoint: metrics.endpoint,
        method: metrics.method,
        response_time: metrics.responseTime,
        status_code: metrics.statusCode,
        user_ip: metrics.userIP,
        user_agent: metrics.userAgent,
        timestamp: metrics.timestamp,
        user_id: metrics.userId,
        error_message: metrics.errorMessage || null,
        request_size: metrics.requestSize,
        response_size: metrics.responseSize,
        memory_usage: metrics.memoryUsage,
        created_at: DateTime.now().toSQL(),
        updated_at: DateTime.now().toSQL(),
        platform: metrics.platform || "Web 2.0",
      });
    } catch (error) {
      Logger.error("❌ Failed to store API metrics:", error);
    }
  }

  /** Update daily/hourly/global aggregated stats */
  private async updateAggregatedStats(metrics: ApiMetrics) {
    const dateKey = DateTime.now().toFormat("yyyy-MM-dd");
    const hourKey = DateTime.now().toFormat("yyyy-MM-dd-HH");

    try {
      // Daily endpoint stats
      await Database.rawQuery(
        `
        INSERT INTO api_stats (endpoint, method, date_key, hour_key, count, total_time, avg_time, errors, slow_queries, platform, created_at, updated_at)
        VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
          count = count + 1,
          total_time = total_time + VALUES(total_time),
          avg_time = total_time / count,
          errors = errors + VALUES(errors),
          slow_queries = slow_queries + VALUES(slow_queries),
          updated_at = NOW()
        `,
        [
          metrics.endpoint,
          metrics.method,
          dateKey,
          hourKey,
          metrics.responseTime,
          metrics.responseTime,
          metrics.statusCode >= 400 ? 1 : 0,
          metrics.responseTime > 1000 ? 1 : 0,
          metrics.platform || "Web 2.0",
        ]
      );

      // Global daily stats
      await Database.rawQuery(
        `
        INSERT INTO api_stats (endpoint, method, date_key, hour_key, count, total_time, avg_time, platform, created_at, updated_at)
        VALUES ('GLOBAL', 'ALL', ?, ?, 1, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
          count = count + 1,
          total_time = total_time + VALUES(total_time),
          avg_time = total_time / count,
          updated_at = NOW()
        `,
        [dateKey, hourKey, metrics.responseTime, metrics.responseTime, metrics.platform || "Web 2.0"]
      );
    } catch (error) {
      Logger.error("❌ Failed to update aggregated stats:", error);
    }
  }

  private logMetrics(metrics: ApiMetrics) {
    const logData = {
      endpoint: metrics.endpoint,
      method: metrics.method,
      responseTime: `${metrics.responseTime.toFixed(2)}ms`,
      status: metrics.statusCode,
      userIP: metrics.userIP,
      timestamp: metrics.timestamp,
      userId: metrics.userId,
      memoryDelta: `${(metrics.memoryUsage / 1024 / 1024).toFixed(2)}MB`,
      platform: metrics.platform || "Web 2.0",
    };

    if (metrics.errorMessage) {
      logData["error"] = metrics.errorMessage;
    }

    console.log("\n📊 API Metrics:", logData);
  }
}


// import type { HttpContextContract } from "@ioc:Adonis/Core/HttpContext";
// import { DateTime } from "luxon";
// import Logger from "@ioc:Adonis/Core/Logger";
// import Database from "@ioc:Adonis/Lucid/Database";

// interface ApiMetrics {
//   endpoint: string;
//   method: string;
//   responseTime: number;
//   statusCode: number;
//   userIP: string;
//   userAgent: string;
//   timestamp: string;
//   userId?: number | string | null;
//   errorMessage?: string;
//   requestSize: number;
//   responseSize?: number;
//   memoryUsage: number;
// }

// export default class Apilogger {
//   constructor() {
//     console.log("✅ API Logger Middleware Initialized");
//   }

//   public async handle(
//     { request, response }: HttpContextContract,
//     // { request, response, auth }: HttpContextContract,
//     next: () => Promise<void>
//   ) {
//     const startTime = process.hrtime.bigint();
//     const startMemory = process.memoryUsage();
//     const requestSize = JSON.stringify(request.body() || {}).length || 0;

//     let errorMessage: string | undefined;
//     let statusCode = 200;

//     try {
//       await next();
//       statusCode = response.getStatus();
//     } catch (error) {
//       statusCode = error.status || 500;
//       errorMessage = error.message;
//       throw error;
//     } finally {
//       const endTime = process.hrtime.bigint();
//       const endMemory = process.memoryUsage();
//       const responseTime = Number(endTime - startTime) / 1000000; // ms

//       const metrics: ApiMetrics = {
//         endpoint: request.url(),
//         method: request.method(),
//         responseTime,
//         statusCode,
//         userIP: request.ip(),
//         userAgent: request.header("user-agent") || "",
//         timestamp: DateTime.now().toISO(),
//         // userId: auth.user ? auth.user.id : null,
//         errorMessage,
//         requestSize,
//         responseSize: response.getHeader("content-length")
//           ? parseInt(response.getHeader("content-length") as string)
//           : 0,
//         memoryUsage: endMemory.heapUsed - startMemory.heapUsed,
//       };

//       await this.storeMetrics(metrics);
//       await this.updateAggregatedStats(metrics);

//       this.logMetrics(metrics);
//     }
//   }

//   /** Store individual API request */
//   private async storeMetrics(metrics: ApiMetrics) {
//     try {
//       await Database.table("api_logs").insert({
//         endpoint: metrics.endpoint,
//         method: metrics.method,
//         response_time: metrics.responseTime,
//         status_code: metrics.statusCode,
//         user_ip: metrics.userIP,
//         user_agent: metrics.userAgent,
//         timestamp: metrics.timestamp,
//         user_id: metrics.userId,
//         error_message: metrics.errorMessage || null,
//         request_size: metrics.requestSize,
//         response_size: metrics.responseSize,
//         memory_usage: metrics.memoryUsage,
//         created_at: DateTime.now().toSQL(),
//         updated_at: DateTime.now().toSQL(),
//       });
//     } catch (error) {
//       Logger.error("❌ Failed to store API metrics:", error);
//     }
//   }

//   /** Update daily/hourly/global aggregated stats */
//   private async updateAggregatedStats(metrics: ApiMetrics) {
//     const dateKey = DateTime.now().toFormat("yyyy-MM-dd");
//     const hourKey = DateTime.now().toFormat("yyyy-MM-dd-HH");

//     try {
//       // Daily endpoint stats
//       await Database.rawQuery(
//         `
//         INSERT INTO api_stats (endpoint, method, date_key, hour_key, count, total_time, avg_time, errors, slow_queries, created_at, updated_at)
//         VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, NOW(), NOW())
//         ON DUPLICATE KEY UPDATE 
//           count = count + 1,
//           total_time = total_time + VALUES(total_time),
//           avg_time = total_time / count,
//           errors = errors + VALUES(errors),
//           slow_queries = slow_queries + VALUES(slow_queries),
//           updated_at = NOW()
//         `,
//         [
//           metrics.endpoint,
//           metrics.method,
//           dateKey,
//           hourKey,
//           metrics.responseTime,
//           metrics.responseTime,
//           metrics.statusCode >= 400 ? 1 : 0,
//           metrics.responseTime > 1000 ? 1 : 0,
//         ]
//       );

//       // Global daily stats
//       await Database.rawQuery(
//         `
//         INSERT INTO api_stats (endpoint, method, date_key, hour_key, count, total_time, avg_time, created_at, updated_at)
//         VALUES ('GLOBAL', 'ALL', ?, ?, 1, ?, ?, NOW(), NOW())
//         ON DUPLICATE KEY UPDATE 
//           count = count + 1,
//           total_time = total_time + VALUES(total_time),
//           avg_time = total_time / count,
//           updated_at = NOW()
//         `,
//         [dateKey, hourKey, metrics.responseTime, metrics.responseTime]
//       );
//     } catch (error) {
//       Logger.error("❌ Failed to update aggregated stats:", error);
//     }
//   }

//   private logMetrics(metrics: ApiMetrics) {
//     const logData = {
//       endpoint: metrics.endpoint,
//       method: metrics.method,
//       responseTime: `${metrics.responseTime.toFixed(2)}ms`,
//       status: metrics.statusCode,
//       userIP: metrics.userIP,
//       timestamp: metrics.timestamp,
//       userId: metrics.userId,
//       memoryDelta: `${(metrics.memoryUsage / 1024 / 1024).toFixed(2)}MB`,
//     };

//     if (metrics.errorMessage) {
//       logData["error"] = metrics.errorMessage;
//     }

//     console.log("\n📊 API Metrics:", logData);
//   }
// }
