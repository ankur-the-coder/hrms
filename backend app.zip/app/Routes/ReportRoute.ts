import Route from '@ioc:Adonis/Core/Route'

// ──────────────────────────────────────────────────────────────────────────────
// Comprehensive 360° Reports & Report Schedules Routes
// Gated by agentAuth middleware to ensure only authenticated agents/admins access reports.
// ──────────────────────────────────────────────────────────────────────────────

Route.group(() => {
  // 360° Detailed Analytics
  Route.get('/reports/360', 'ReportController.getReport')
  Route.get('/reports/export', 'ReportController.exportCsv')

  // Automated Email Report Schedules
  Route.get('/reports/schedules', 'ReportController.listSchedules')
  Route.post('/reports/schedules', 'ReportController.createSchedule')
  Route.put('/reports/schedules/:id', 'ReportController.updateSchedule')
  Route.delete('/reports/schedules/:id', 'ReportController.deleteSchedule')
  Route.post('/reports/schedules/:id/run', 'ReportController.triggerScheduleNow')
}).middleware(['agentAuth'])
