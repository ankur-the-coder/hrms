import Route from "@ioc:Adonis/Core/Route";
import seed from "App/Helper/SeedEmailTemplate";

// BUG FIX: MailAccountController is bound via lazy string routes below
// ('MailAccountController.connect' etc.), which Adonis only resolves/imports
// on the FIRST matching HTTP request — not at boot. That means
// MailAccountService.ts (which self-starts the subscription auto-renewal
// scheduler on module load) was never actually being imported unless someone
// happened to hit a /mail-accounts/* route after a fresh restart. This route
// file, by contrast, IS required eagerly at boot (that's how routes get
// registered at all) — so a bare import here forces MailAccountService to
// load, and its scheduler, at server startup every time.
import "App/Services/MailAccountService"

// Same reasoning as above — AttachmentMigrationService self-starts the
// broken-attachment health-check scheduler (runs every 6h) on module load,
// so it needs an eager import too, or it'd only start once someone happened
// to hit one of the /admin/attachments/* routes below.
import "App/Services/AttachmentMigrationService"

// Same reasoning again — GraphWebhookNotificationService self-starts the
// webhook-notification retry scheduler (recovers anything left 'pending'/
// 'failed' by a crash or a transient Graph error) on module load, and it
// also runs one catch-up pass immediately at boot.


Route.post('/agent/login', 'AuthController.login')
// agentAuth added: TicketController.create now needs to know which agent is
// creating the ticket (attributes the opening message + resolves their
// signature footer). Only the Add Ticket modal ever calls this endpoint,
// and it already sends the auth header, so this doesn't break any caller.
Route.post('/tickets/create',        'TicketController.create').middleware(['agentAuth'])
// Lets the Add Ticket modal fetch+display the real ticket ID before Submit.
Route.get('/tickets/next-uid',       'TicketController.nextUid').middleware(['agentAuth'])
// agentAuth is required here — without it (request as any).agent is undefined,
// which breaks agent-scoping in TicketService.getTickets() and returns all
// tickets to every role instead of restricting non-admins to their own + unassigned.
Route.get('/tickets',                'TicketController.list').middleware(['agentAuth'])
Route.get('/tickets/status-counts',  'TicketController.statusCounts').middleware(['agentAuth'])
// Powers the ticket-list "Organization" filter dropdown — distinct orgs
// pulled straight off tickets.sender_org_name/sender_org_id (see
// TicketService.getTicketOrganizations), NOT the legacy Organization
// table used by OrganizationController below. Must stay registered before
// the '/tickets/:id' catch-all right after this, or Adonis would match
// "/tickets/organizations" as :id='organizations' and hit .detail() instead.
Route.get('/tickets/organizations',  'TicketController.ticketOrganizations').middleware(['agentAuth'])
Route.get('/tickets/:id',            'TicketController.detail').middleware(['agentAuth'])
// Route.get('/tickets/dashboard/stats','TicketController.dashboardStats')
Route.get('/contacts', 'ContactController.list')
// Organizations tab (sidebar-nav.ts: sits inside the existing "Contacts"
// page as a second tab, not a separate nav item) — pulls straight from the
// shared legacy `Organization` table. Same auth shape as /contacts above.
Route.get('/organizations', 'OrganizationController.list')
Route.get('/dev/seed-templates', async ({ request }) => {
  const update = request.qs().update
  const result = await seed(update)
  return result
})
// Dev-only: generate N dummy tickets for load/UI testing. No emails are sent.
// Example: GET /dev/seed-tickets?count=200
Route.get('/dev/seed-tickets', 'TicketController.seedDummyTickets')
Route.group(() => {
  Route.get('/connect', 'MailAccountController.connect')
  Route.get('/callback', 'MailAccountController.callback')
  Route.get('/', 'MailAccountController.list')
  Route.post('/:id/disconnect', 'MailAccountController.disconnect')
  Route.post('/:id/set-default', 'MailAccountController.setDefault') 
  Route.get('/debug/:traceId', 'MailAccountController.debugTrace')

  // Dev-only: test the subscription auto-renewal scheduler without waiting
  // hours/days for a real subscription to near expiry.
  //   1) POST /mail-accounts/dev/:id/expire-soon   — sets subscription_expires_at to 2 min from now
  //   2) watch server logs — the scheduler ticks every SUBSCRIPTION_RENEWAL_CHECK_INTERVAL_MS (default 5 min)
  //      and will pick it up + renew it automatically, OR:
  //   3) POST /mail-accounts/dev/trigger-renewal   — force an immediate renewal check instead of waiting

    Route.post('/dev/:id/expire-soon', 'MailAccountController.devExpireSoon')
    Route.post('/dev/trigger-renewal', 'MailAccountController.devTriggerRenewal')

}).prefix('/mail-accounts')

// Separate top-level path because this exact URL is what you register with
// Microsoft Graph as `notificationUrl` — keep it stable.
Route.post('/mail/webhook', 'MailAccountController.webhook')

// ============================================================
// Public feedback / rating / reopen widget — reached from links in the
// ticket-closure email. No agentAuth: access is gated by the per-ticket
// feedback_token in the `t` query param instead.
// ============================================================
Route.get('/feedback', 'TicketFeedbackController.ratingClick')
Route.post('/feedback/submit', 'TicketFeedbackController.submit')
Route.get('/feedback/reopen', 'TicketFeedbackController.reopenClick')
Route.post('/feedback/reopen/message', 'TicketFeedbackController.reopenMessage')

// JSON API for the standalone Angular /feedback page (email buttons now link
// to the frontend, which calls these instead of loading server-rendered HTML).
Route.get('/api/feedback/view', 'TicketFeedbackController.viewApi')
Route.post('/api/feedback/submit', 'TicketFeedbackController.submitApi')
Route.post('/api/feedback/reopen-message', 'TicketFeedbackController.reopenMessageApi')
Route.post('/tickets/update', 'TicketController.updateDetails').middleware(['agentAuth'])
Route.get('/api/webhooks/whatsapp', 'WhatsappController.verify')
Route.post('/api/webhooks/whatsapp', 'WhatsappController.handle')
Route.post('/api/whatsapp/send', 'WhatsappController.send')
Route.get('/tickets/dashboard/stats',   'TicketController.dashboardStats').middleware(['agentAuth'])
Route.get('/tickets/dashboard/pending', 'TicketController.pendingTickets').middleware(['agentAuth'])
Route.get('/tickets/dashboard/charts',  'TicketController.chartsOverview').middleware(['agentAuth'])
 


  Route.get('/whatsapp/accounts', 'WhatsappController.list') 
  Route.post('/whatsapp/accounts', 'WhatsappController.connect')
  Route.delete('/whatsapp/accounts/:id', 'WhatsappController.disconnect')
  Route.post('/api/tickets/messages/:messageId/retry', 'WhatsappController.retryMessage')


Route.post('/agent/logout', 'AuthController.logout').middleware(['agentAuth'])

// ============================================================
// S3 attachment migration + broken-attachment health check.
//   - migrate-legacy: one-time backfill of old local-disk attachments to S3
//   - broken:         quick read-only look at what's currently flagged broken
//   - dev/check-now:  force an immediate health-check pass instead of
//                      waiting for the 6h scheduler tick (see
//                      AttachmentMigrationService.ts)
// ============================================================
Route.group(() => {
  Route.post('/migrate-legacy', 'AttachmentAdminController.migrateLegacy')
  Route.get('/broken',          'AttachmentAdminController.listBroken')
  Route.post('/dev/check-now',  'AttachmentAdminController.devCheckNow')
  // NEW: "Attachments" sidebar page — browse/search every attachment ever
  // saved (across all tickets) and delete unwanted ones.
  Route.get('/',        'AttachmentAdminController.list')
  Route.post('/delete', 'AttachmentAdminController.remove')
  // NEW: independent S3-bucket audit — every object actually sitting in
  // the bucket, cross-referenced against ticket_attachments, with total
  // bucket size / tracked size / untracked (orphaned) size.
  Route.get('/bucket-audit', 'AttachmentAdminController.bucketAudit')
}).prefix('/admin/attachments').middleware(['agentAuth'])

// ============================================================
// On-demand mail-history reconciliation — replays the last N days of every
// connected mailbox's Inbox + Sent Items and files in any ticket/message
// EmailToTicketService's live paths missed (subscription downtime, an
// agent replying straight from Outlook, etc). Never touches ticket status,
// never duplicates a message (dedup is solely by graph_message_id), and
// never sends an auto-ack email for a backfilled first message — see
// EmailToTicketService.reconcileMailHistory's doc-comment for the full
// guarantees. Fire-and-forget: the response comes back immediately, the
// actual work + summary land in server logs.
// ============================================================
Route.post('/admin/mail/reconcile', 'MailAccountController.reconcileMailHistory').middleware(['agentAuth'])

// Per-ticket "Sync with Outlook" — fetches the full conversation thread from
// Microsoft Graph and backfills any missing messages (both customer and agent)
// without duplicating existing ones or sending auto-ack emails.
// Must be registered BEFORE the /tickets/:id catch-all in the agentAuth group below.
Route.post('/tickets/:id/sync-mail', 'TicketController.syncMail').middleware(['agentAuth'])


Route.group(() => {
  Route.post('/tickets/assign',  'TicketController.assign')
  Route.post('/tickets/delete',  'TicketController.remove')
    Route.post('/tickets/restore', 'TicketController.restore') 
  Route.post('/tickets/message', 'TicketController.addMessage')
  Route.post('/tickets/attachments/upload', 'TicketController.uploadAttachment')
  Route.post('/tickets/status',  'TicketController.updateStatus')

  // --- NEW: Zoho-style card list actions ---
  Route.post('/tickets/:id/read',        'TicketController.markRead')
  Route.post('/tickets/:id/unread',      'TicketController.markUnread')
  Route.post('/tickets/:id/resolution',  'TicketController.updateResolution')
  Route.post('/tickets/merge',           'TicketController.merge')

  // --- NEW: bulk-select action bar ---
  Route.post('/tickets/bulk/assign',      'TicketController.bulkAssign')
  Route.post('/tickets/bulk/status',      'TicketController.bulkUpdateStatus')
  Route.post('/tickets/bulk/delete',      'TicketController.bulkDelete')
  Route.post('/tickets/bulk/spam',        'TicketController.markSpam')
  Route.post('/tickets/bulk/apply-macro', 'TicketController.bulkApplyMacro')

  // --- NEW: macros ---
  Route.get('/macros',             'MacroController.list')
  Route.post('/macros/create',     'MacroController.create')
  Route.post('/macros/:id/update', 'MacroController.update')
  Route.post('/macros/:id/delete', 'MacroController.remove')

  Route.get('/agents',           'AgentController.list')
  Route.post('/agents/create',   'AgentController.create')
  Route.post('/agents/update',   'AgentController.update')
  Route.post('/agents/delete',   'AgentController.remove')
  Route.get('/agents/:id/signature',  'AgentController.getSignature')
  Route.post('/agents/:id/signature', 'AgentController.updateSignature')

  Route.get('/settings',         'SettingsController.list')
  Route.post('/settings/update', 'SettingsController.update')

  Route.get('/email-templates',              'EmailTemplateController.list')
  Route.post('/email-templates/:key/update', 'EmailTemplateController.update')
  Route.post('/email-templates/:key/reset',  'EmailTemplateController.reset')


  Route.post('/contacts/priority',      'ContactController.setPriority')
  Route.post('/organizations/priority', 'OrganizationController.setPriority')
}).middleware(['agentAuth'])

Route.get('/tickets/uid/:uid/raw-mail', 'TicketController.rawMailByUid')