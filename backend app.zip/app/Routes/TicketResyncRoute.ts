import Route from '@ioc:Adonis/Core/Route'

// ──────────────────────────────────────────────────────────────────────────────
// Ticket Re-sync Routes
// These endpoints are intentionally UNAUTHENTICATED — matching the pattern of
// GET /tickets/uid/:uid/raw-mail — so the re-sync can be triggered from the
// panel (which sends the request directly) without requiring an agent token.
// Access is gated on the frontend by the "enable_ticket_resync" toggle in the
// Agents & Admins settings panel instead.
//
// NOTE: Both routes must be registered BEFORE any agentAuth catch-alls in
// ChatRoute.ts to avoid being swallowed by a generic :id pattern.
// ──────────────────────────────────────────────────────────────────────────────

// Re-sync by ticket UID (e.g. "UBI-162090")
Route.post('/tickets/uid/:uid/resync-mail', 'TicketResyncController.resyncByUid')

// Re-sync by internal ticket ID (integer)
Route.post('/tickets/:id/resync-mail', 'TicketResyncController.resyncById')
