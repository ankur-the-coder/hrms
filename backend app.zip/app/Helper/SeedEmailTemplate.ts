// backend_app/app/Helper/seedEmailTemplates.ts — run once, then delete
import Database from '@ioc:Adonis/Lucid/Database'

const AUTO_TICKET_RESPONSE_DEFAULT = 
`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin:0; padding:0; -webkit-text-size-adjust:100%; }
    @media only screen and (max-width:600px) {
      .ubis-wrapper { padding:0 !important; }
      .ubis-card { border-radius:0 !important; box-shadow:none !important; }
      .ubis-body, .ubis-footer { padding:24px 20px !important; }
      .ubis-h1 { font-size:18px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">

  <table width="100%" cellpadding="0" cellspacing="0" class="ubis-wrapper" style="width:100%;background:#f8fafc;padding:32px 16px;">
    <tr>
      <td align="center">
        <table width="100%" cellpadding="0" cellspacing="0" class="ubis-container" style="max-width:520px;margin:0 auto;width:100%;">

          <!-- Top Brand Header -->
          <tr>
            <td style="padding-bottom:20px; text-align:left;">
              <table cellpadding="0" cellspacing="0" style="display:inline-block;vertical-align:middle;">
                <tr>
                  <td style="vertical-align:middle;padding-right:8px;">
                 <img src="https://ubihrmimages.s3.ap-south-1.amazonaws.com/10/division/35.jpg?r=16289015" alt="Logo" width="24" height="24" style="display:block;border-radius:6px;object-fit:cover;" />
                  </td>
                  <td style="vertical-align:middle;">
                    <span style="font-size:18px;font-weight:700;color:#0f172a;letter-spacing:-0.5px;">ubi<span style="color:#10b981;">Support</span></span>
                    <span style="font-size:12px;color:#64748b;margin-left:8px;font-weight:500;">• &nbsp;Helpdesk</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Main Premium Card -->
          <tr>
            <td class="ubis-card" style="background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 4px 20px rgba(15,23,42,0.03);overflow:hidden;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="ubis-body" style="padding:32px 32px 24px;">

                    <table cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
                      <tr>
                        <td style="background:#e6f4ea;border-radius:20px;padding:4px 12px;vertical-align:middle;">
                          <span style="display:inline-block;width:6px;height:6px;background:#10b981;border-radius:50%;margin-right:6px;vertical-align:middle;"></span>
                          <span style="font-size:11px;font-weight:600;color:#059669;text-transform:uppercase;letter-spacing:0.5px;vertical-align:middle;">Ticket Created</span>
                        </td>
                      </tr>
                    </table>

  <h1 class="ubis-h1" style="margin:0 0 6px;color:#0f172a;font-size:20px;font-weight:700;letter-spacing:-0.3px;">Hi {{customer_name:first}}!</h1>
                    <p class="ubis-sub" style="margin:0;color:#64748b;font-size:13px;line-height:1.5;">Thanks for reaching out! We have received your request and automatically logged it into our support system.</p>

                    <hr style="border:0;border-top:1px solid #f1f5f9;margin:24px 0;" />

                    <p style="margin:0 0 12px;font-size:11px;font-weight:700;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;">Ticket Details</p>
                    <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:10px;background:#ffffff;overflow:hidden;">
                      <tr>
                        <td style="padding:14px 16px;background:#f8fafc;">
                          <div style="font-size:11px;color:#94a3b8;margin-bottom:2px;text-transform:uppercase;letter-spacing:0.5px;">Ticket Reference Number</div>
                          <div style="font-size:16px;color:#0f172a;font-weight:700;letter-spacing:-0.3px;">#{{ticket_uid}}</div>
                        </td>
                      </tr>
                    </table>

                    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:16px;">
                      <tr>
                        <td style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:14px 16px;font-size:13px;color:#0369a1;line-height:1.5;">
                          <strong style="display:block;margin-bottom:4px;color:#0284c7;">Need to add anything else?</strong>
                          Our team is on it and will get back to you shortly. Just reply directly to this email to add updates or attachments — it will stay attached to this ticket.
                        </td>
                      </tr>
                    </table>

                  </td>
                </tr>

                <!-- Footer -->
                <tr>
                  <td class="ubis-footer" style="background:#f8fafc;padding:24px 32px;border-top:1px solid #e2e8f0;">
                    <p class="ubis-footer-title" style="font-size:13px;color:#374151;font-weight:700;margin:0 0 14px;">Need Assistance?</p>

                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">India Support</strong>
                      📞 <a href="tel:+916264345425" style="color:#0284c7;text-decoration:none;font-weight:500;">+91 6264345425</a>
                    </div>
                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">Overseas Support</strong>
                      📞 <a href="tel:+971555524131" style="color:#0284c7;text-decoration:none;font-weight:500;">+971 55-5524131</a>
                    </div>
                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">Email Us</strong>
                      ✉️ <a href="mailto:ubihrmsupport@ubitechsolutions.com" style="color:#0284c7;text-decoration:none;font-weight:500;">ubihrmsupport@ubitechsolutions.com</a>
                    </div>

                    <div class="ubis-divider" style="height:1px;background:#e2e8f0;margin:14px 0;"></div>

                    <p style="margin:0;font-size:11px;color:#94a3b8;line-height:1.5;text-align:center;">
                      Automated confirmation via <strong style="color:#64748b;font-weight:600;">ubiSupport Engine</strong><br>
                      Please retain your ticket ID when replying.
                    </p>
                    <p class="ubis-copyright" style="margin-top:10px;text-align:center;font-size:11px;color:#94a3b8;">&copy; 2026 ubiSupport. All rights reserved.</p>
                  </td>
                </tr>

              </table>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
 
</body> 
</html> ` 

const TICKET_CLOSURE_DEFAULT = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin:0; padding:0; background:#f1f5f9; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; color:#334155; }
    .wrapper { padding:40px 20px; }
    .card { max-width:600px; margin:0 auto; background:#ffffff; border:1px solid #e2e8f0; border-radius:16px; padding:32px; box-shadow:0 4px 6px -1px rgba(0,0,0,0.05); }
    .email-header { display:flex; justify-content:space-between; align-items:center; padding-bottom:20px; border-bottom:1px solid #f1f5f9; margin-bottom:24px; }
    .logo { font-size:18px; font-weight:800; color:#0f172a; }
    .logo span { color:#10b981; }
    .logo .subtext { font-size:14px; font-weight:400; color:#64748b; }
    .badge { background:#fef3c7; color:#b45309; font-size:12px; font-weight:700; padding:6px 12px; border-radius:20px; letter-spacing:0.02em; }
    .greeting { font-size:18px; font-weight:700; margin-bottom:16px; color:#0f172a; }
    .tag { background:#e0e7ff; color:#4338ca; padding:2px 8px; border-radius:6px; font-family:monospace; font-size:14px; }
    .email-body p { margin:0 0 16px 0; color:#334155; font-size:15px; }
    .reopen-row { text-align:center; margin:20px 0 4px; }
    .reopen-btn { display:inline-block; background:#f8fafc; border:1px solid #e2e8f0; color:#334155; text-decoration:none; font-size:13px; font-weight:600; padding:10px 18px; border-radius:8px; }
    .csat-container { margin-top:20px; padding:20px 8px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; text-align:center; }
    .csat-title { font-size:14px; font-weight:700; color:#0f172a; margin-bottom:6px; }
    .csat-subtitle { font-size:12px; color:#64748b; margin-bottom:16px; }
    .csat-buttons { display:flex; justify-content:center; gap:6px; flex-wrap:wrap; }
    .csat-btn { display:inline-flex; flex-direction:column; align-items:center; justify-content:center; text-decoration:none; background:#ffffff; border:1px solid #e2e8f0; flex:1; min-width:95px; padding:10px 4px; border-radius:8px; font-size:11px; font-weight:600; color:#334155; }
    .csat-btn .emoji { font-size:22px; margin-bottom:4px; line-height:1; }
    .email-footer { border-top:1px solid #f1f5f9; margin-top:28px; padding-top:20px; text-align:center; font-size:12px; color:#94a3b8; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <div class="email-header">
        <div class="logo">ubi<span>Support</span> <span class="subtext">• Helpdesk</span></div>
        <div class="badge">✓ TICKET RESOLVED</div>
      </div>

      <div class="email-body">
        <div class="greeting">Hi <span class="tag">{{customer_name:first}}</span>,</div>
        <p>Ticket <span class="tag">#{{ticket_uid}}</span> has been resolved and closed.</p>
        <p>If your issue requires further attention or isn't completely resolved, simply reply to this email — our team will automatically reopen your ticket and assist you right away.</p>

        <div class="reopen-row">
          <a href="{{reopen_url}}" target="_blank" class="reopen-btn">↺ Reopen ticket</a>
        </div>

        <div class="csat-container">
          <div class="csat-title">How satisfied were you with your experience?</div>
          <div class="csat-subtitle">Click an option below to send us your feedback</div>
          <div class="csat-buttons">
            <a href="{{rating_url_1}}" target="_blank" class="csat-btn"><span class="emoji">😡</span><span>Very Unsatisfied</span></a>
            <a href="{{rating_url_2}}" target="_blank" class="csat-btn"><span class="emoji">🙁</span><span>Unsatisfied</span></a>
            <a href="{{rating_url_3}}" target="_blank" class="csat-btn"><span class="emoji">😐</span><span>Neutral</span></a>
            <a href="{{rating_url_4}}" target="_blank" class="csat-btn"><span class="emoji">🙂</span><span>Satisfied</span></a>
            <a href="{{rating_url_5}}" target="_blank" class="csat-btn"><span class="emoji">🤩</span><span>Very Satisfied</span></a>
          </div>
        </div>

        <p style="margin-top:24px;margin-bottom:0;">Warm regards,<br><strong>ubiDesk Support Manager</strong></p>
      </div>

      <div class="email-footer">© ubiDesk Support Manager. All rights reserved.</div>
    </div>
  </div>
</body>
</html>`

const DEFAULT_AGENT_FOOTER = `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px;line-height:1.5;color:#334155;">
  <p style="margin:0 0 2px 0;font-weight:700;color:#0f172a;">{{agent_name}}</p>
  <p style="margin:0;color:#64748b;font-size:12px;">Customer Support | ubiDesk</p> 
</div>`      

const AGENT_FOOTER_DEFAULT = `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px;line-height:1.5;color:#334155;">
  <p style="margin:0 0 2px 0;font-weight:700;color:#0f172a;">{{agent_name}}</p>
  <p style="margin:0;color:#64748b;font-size:12px;">Customer Support | ubiDesk</p>
</div>`

export default async function seed(updateQuery?: string) {
  if (updateQuery) {
    const result = await Database.rawQuery(updateQuery)
    return result
  }

  // const rows = [
  //   { template_key: 'auto_ticket_response', html: AUTO_TICKET_RESPONSE_DEFAULT, default_html: AUTO_TICKET_RESPONSE_DEFAULT },
  //   { template_key: 'ticket_closure',        html: TICKET_CLOSURE_DEFAULT,       default_html: TICKET_CLOSURE_DEFAULT },
  //   { template_key: 'agent_footer_default',  html: AGENT_FOOTER_DEFAULT,         default_html: AGENT_FOOTER_DEFAULT },
  // ]
  // for (const r of rows) {
  //   const exists = await Database.from('email_templates').where('template_key', r.template_key).first()
  //   if (!exists) await Database.table('email_templates').insert({ ...r, updated_at: new Date() })
  // }
  console.log('email_templates seeded')
}