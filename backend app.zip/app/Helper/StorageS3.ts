import AWS from 'aws-sdk'
import axios from 'axios'

let s3Client: AWS.S3 | null = null

const PUBLIC_PREFIX = 'public'

function getClient(): AWS.S3 {
  if (s3Client) return s3Client

  const accessKeyId = process.env.S3_AttKEY
  const secretAccessKey = process.env.S3_AttSECRET
  const region = process.env.S3_REGION

  console.log('[StorageS3][getClient] initializing S3 client', {
    accessKeyIdPresent: !!accessKeyId,
    accessKeyIdPrefix: accessKeyId ? accessKeyId.slice(0, 4) + '***' : null,
    secretAccessKeyPresent: !!secretAccessKey,
    region,
  })

  if (!accessKeyId || !secretAccessKey || !region) {
    console.error('[StorageS3][getClient] missing one or more required env vars: S3_AttKEY, S3_AttSECRET, S3_REGION')
  }

  AWS.config.update({ accessKeyId, secretAccessKey, region })

  s3Client = new AWS.S3()
  return s3Client
}

function toPublicKey(key: string): string {
  const clean = key.replace(/^\/+/, '')
  const finalKey = clean.startsWith(`${PUBLIC_PREFIX}/`) ? clean : `${PUBLIC_PREFIX}/${clean}`
  console.log('[StorageS3][toPublicKey]', { inputKey: key, finalKey })
  return finalKey
}

export async function uploadBufferToS3(key: string, buffer: Buffer, contentType?: string): Promise<string> {
  console.log('[StorageS3][uploadBufferToS3] called', {
    key,
    bufferSizeBytes: buffer?.length,
    contentType,
  })

  const s3 = getClient()
  const bucket = process.env.S3_AttachmentBucket

  if (!bucket) {
    console.error('[StorageS3][uploadBufferToS3] S3_AttachmentBucket env var is not set — aborting upload')
    throw new Error('S3_AttachmentBucket env var is not set')
  }

  const publicKey = toPublicKey(key)
  const resolvedContentType = contentType || 'application/octet-stream'

  console.log('[StorageS3][uploadBufferToS3] resolved target', { bucket, publicKey, resolvedContentType })

  let uploadResult: AWS.S3.PutObjectOutput
  try {
    uploadResult = await s3
      .putObject({
        Bucket: bucket,
        Key: publicKey,
        Body: buffer,
        ContentType: resolvedContentType,
      })
      .promise()
    console.log('[StorageS3][uploadBufferToS3] putObject succeeded', {
      bucket,
      publicKey,
      eTag: uploadResult.ETag,
      versionId: uploadResult.VersionId,
    })
  } catch (err: any) {
    console.error('[StorageS3][uploadBufferToS3] putObject FAILED', {
      bucket,
      publicKey,
      code: err.code,
      statusCode: err.statusCode,
      message: err.message,
      requestId: err.requestId,
    })
    throw err
  }

  try {
    const verifiedObject = await s3
      .headObject({
        Bucket: bucket,
        Key: publicKey,
      })
      .promise()
    console.log('[StorageS3][uploadBufferToS3] headObject confirms object exists in bucket', {
      bucket,
      publicKey,
      sizeInBytes: verifiedObject.ContentLength,
      contentType: verifiedObject.ContentType,
      lastModified: verifiedObject.LastModified,
      eTag: verifiedObject.ETag,
    })
  } catch (err: any) {
    console.error('[StorageS3][uploadBufferToS3] headObject FAILED — object may not actually be in the bucket', {
      bucket,
      publicKey,
      code: err.code,
      statusCode: err.statusCode,
      message: err.message,
      requestId: err.requestId,
    })
  }

  const region = process.env.S3_REGION
  const url = region
    ? `https://${bucket}.s3.${region}.amazonaws.com/${publicKey}`
    : `https://${bucket}.s3.amazonaws.com/${publicKey}`

  console.log('[StorageS3][uploadBufferToS3] constructed public URL', { url })

  const reachability = await checkUrlReachableVerbose(url)

  console.log('[StorageS3][uploadBufferToS3] public URL reachability check', {
    url,
    reachable: reachability.reachable,
    statusCode: reachability.statusCode,
    errorCode: reachability.errorCode,
  })

  if (!reachability.reachable) {
    if (reachability.statusCode === 403) {
      console.error('[StorageS3][uploadBufferToS3] ROOT CAUSE: got HTTP 403 AccessDenied on a freshly-uploaded object. The object exists (headObject succeeded above via IAM credentials) but S3 is refusing anonymous GetObject. This is a bucket-level permissions issue, not an upload issue — check: (1) bucket policy grants s3:GetObject on ' + bucket + '/' + PUBLIC_PREFIX + '/* to Principal *, (2) Block Public Access setting "Block public access to buckets and objects granted through new public bucket policies" is OFF for this bucket, (3) no explicit Deny statement in the bucket policy or an attached SCP overriding it.', { bucket, publicKey, url })
    } else if (reachability.statusCode === 404) {
      console.error('[StorageS3][uploadBufferToS3] got HTTP 404 on a freshly-uploaded object — this points at a key/path mismatch (wrong bucket, wrong region endpoint, or key casing) rather than a permissions issue.', { bucket, publicKey, url })
    } else {
      console.error('[StorageS3][uploadBufferToS3] public URL unreachable for an unexpected reason — see errorCode/statusCode above.', { bucket, publicKey, url })
    }
  }

  return url
}

export function isS3Url(storagePath: string): boolean {
  return /^https?:\/\//i.test(storagePath)
}

/**
 * Pulls the raw S3 key back out of one of our stored public URLs (the same
 * shape uploadBufferToS3 returns). Shared by deleteObjectFromS3 below and
 * by AttachmentAdminController's bucket audit, which needs to match
 * ticket_attachments rows back up against raw bucket listings.
 */
export function extractS3KeyFromUrl(url: string): string | null {
  try {
    return decodeURIComponent(new URL(url).pathname.replace(/^\/+/, ''))
  } catch {
    return null
  }
}

export interface S3ObjectSummary {
  key: string
  size: number
  lastModified: string
  eTag: string
}

/**
 * Lists every object under a prefix (default: the whole `public/` folder we
 * upload attachments into) directly from S3 — the raw ground truth,
 * independent of whatever ticket_attachments happens to have rows for.
 * Catches two things a DB-driven listing can't: files that got uploaded but
 * whose DB row was later deleted (or never created), and an accurate total
 * bucket size (summing ticket_attachments.size only covers what we're
 * tracking, not what's actually sitting in the bucket).
 *
 * Paginates through the full bucket — a single ListObjectsV2 call caps out
 * at 1000 keys — so nothing on a large bucket gets silently truncated.
 */
export async function listAllBucketObjects(prefix: string = PUBLIC_PREFIX): Promise<S3ObjectSummary[]> {
  const s3 = getClient()
  const bucket = process.env.S3_AttachmentBucket
  if (!bucket) {
    console.error('[StorageS3][listAllBucketObjects] S3_AttachmentBucket env var is not set — aborting list')
    throw new Error('S3_AttachmentBucket env var is not set')
  }

  const objects: S3ObjectSummary[] = []
  let continuationToken: string | undefined
  let pageCount = 0

  do {
    let page: AWS.S3.ListObjectsV2Output
    try {
      page = await s3.listObjectsV2({
        Bucket: bucket,
        Prefix: prefix,
        ContinuationToken: continuationToken,
        MaxKeys: 1000,
      }).promise()
    } catch (err: any) {
      console.error('[StorageS3][listAllBucketObjects] listObjectsV2 FAILED', {
        bucket, prefix, pageCount, code: err.code, statusCode: err.statusCode, message: err.message,
      })
      throw err
    }

    pageCount++
    for (const obj of page.Contents ?? []) {
      if (!obj.Key) continue
      // Skip zero-byte "folder marker" pseudo-objects (created when someone
      // makes an empty "folder" in the S3 console) — not real files, and
      // they'd otherwise show up as junk 0-byte rows in the audit.
      if (obj.Key.endsWith('/') && (obj.Size ?? 0) === 0) continue
      objects.push({
        key: obj.Key,
        size: obj.Size ?? 0,
        lastModified: obj.LastModified ? obj.LastModified.toISOString() : '',
        eTag: obj.ETag ?? '',
      })
    }

    continuationToken = page.IsTruncated ? page.NextContinuationToken : undefined
  } while (continuationToken)

  console.log(`[StorageS3][listAllBucketObjects] fetched ${objects.length} object(s) across ${pageCount} page(s) under prefix "${prefix}"`)
  return objects
}

/**
 * Deletes an object from S3 given the full public URL we stored in
 * ticket_attachments.storage_path (the same shape uploadBufferToS3 returns:
 * `https://<bucket>.s3.<region>.amazonaws.com/<key>` or the bucket-less
 * `https://<bucket>.s3.amazonaws.com/<key>` form). Pulls the key back out of
 * the URL path rather than requiring the caller to track it separately.
 * No-op-safe: S3's DeleteObject is idempotent (deleting a key that's already
 * gone still returns success), so callers don't need to check existence first.
 */
export async function deleteObjectFromS3(url: string): Promise<void> {
  const bucket = process.env.S3_AttachmentBucket
  if (!bucket) {
    console.error('[StorageS3][deleteObjectFromS3] S3_AttachmentBucket env var is not set — aborting delete')
    throw new Error('S3_AttachmentBucket env var is not set')
  }

  let key: string
  try {
    const extracted = extractS3KeyFromUrl(url)
    if (!extracted) throw new Error('URL parsing returned null')
    key = extracted
  } catch (err: any) {
    console.error('[StorageS3][deleteObjectFromS3] could not parse key out of URL — aborting delete', { url, message: err.message })
    throw new Error(`Could not parse S3 key from URL: ${url}`)
  }

  const s3 = getClient()
  console.log('[StorageS3][deleteObjectFromS3] deleting', { bucket, key, url })
  try {
    await s3.deleteObject({ Bucket: bucket, Key: key }).promise()
    console.log('[StorageS3][deleteObjectFromS3] deleteObject succeeded', { bucket, key })
  } catch (err: any) {
    console.error('[StorageS3][deleteObjectFromS3] deleteObject FAILED', {
      bucket, key, code: err.code, statusCode: err.statusCode, message: err.message, requestId: err.requestId,
    })
    throw err
  }
}

async function checkUrlReachableVerbose(url: string): Promise<{ reachable: boolean; statusCode: number | null; errorCode: string | null }> {
  try {
    const res = await axios.head(url, { timeout: 8000, validateStatus: () => true })
    const reachable = res.status >= 200 && res.status < 300
    return { reachable, statusCode: res.status, errorCode: null }
  } catch (err: any) {
    console.error('[StorageS3][checkUrlReachableVerbose] request threw', {
      url,
      code: err.code,
      message: err.message,
    })
    return { reachable: false, statusCode: null, errorCode: err.code || 'UNKNOWN' }
  }
}

export async function isUrlReachable(url: string): Promise<boolean> {
  const result = await checkUrlReachableVerbose(url)
  return result.reachable
}

export default { uploadBufferToS3, isS3Url, isUrlReachable, deleteObjectFromS3, extractS3KeyFromUrl, listAllBucketObjects }