import Mail from "@ioc:Adonis/Addons/Mail";
import { parsePhoneNumber, PhoneNumber } from 'libphonenumber-js';

  export default class Helper {
  
  
  public static async sendEmail(
    email: any,
    subject: string,
    messages: any,
    headers: any,
    appName = "ubiHRM",
    fromperson = "noreply",
   cc?: string
  ) {
   let email_new =email
    // Create an SES client
    //return true;
    console.log(appName,'appName=====');
    
    
   
    let  fromperson_new = fromperson+'@notify.ubihrm.com';
       console.log(fromperson_new,'fromperson_new=====');
      
      try{
    const getmail = await Mail.use("smtp").send(
      (message) => {
        message
          .from(fromperson_new, appName)
          .to(email_new)
          .subject(subject)
          .header(headers, headers)
          .html(`${messages}`);
          if (cc) message.cc(cc)
        //message.textView('emails/welcome.plain', {})
        //.htmlView('emails/welcome', { fullName: 'Virk' })
      },
      {
        oTags: ["signup"],
      }
    );
    return getmail;
  }catch(e){
    console.log(e); 
    return e;
  }
      
    
    
  }

    public static encode5t(str: any) {
    if (str == "") {
      return "";
    }
    for (let i = 0; i < 5; i++) {
      str = Buffer.from(str).toString("base64");
      str = str.split("").reverse().join("");
    }
    return str;
  }


 public static  extractInlineImages(html: string): { html: string; attachments: any[] } {
  const attachments: any[] = []
  let i = 0
  const outHtml = html.replace(
    /(<img[^>]*\ssrc=["'])data:([^;]+);base64,([^"']+)(["'][^>]*>)/gi,
    (_match, before, mime, base64, after) => {
      const cid = `ubi-inline-${Date.now()}-${i++}`
      attachments.push({
        '@odata.type': '#microsoft.graph.fileAttachment',
        name: `image-${i}.${(mime.split('/')[1] || 'png').split('+')[0]}`,
        contentType: mime,
        contentId: cid,
        isInline: true,
        contentBytes: base64,
      })
      return `${before}cid:${cid}${after}`
    }
  )
  return { html: outHtml, attachments }
}

/** Escapes plain text for HTML, then turns any [label](https://url) token
 *  (inserted via the Reply box's "Insert link" button) into a real <a> tag. */
 public static linkifyMarkdown(text: string): string {
  const escaped = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  return escaped.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, (_m, label, url) =>
    `<a href="${url}" style="color:#4f46e5;text-decoration:underline;">${label}</a>`
  )
}


  public static decode5t(str: string) {
    if (str == null || str == "" || str == "null") {
      return (str = "");
    }
    for (let i = 0; i < 5; i++) {
      str = str.split("").reverse().join("");
      str = Buffer.from(str, "base64").toString("utf-8");
    }
    return str;
  }


  public static getNationalNumber(whatsappNumber: string): string | null {
  if (!whatsappNumber) return null;

  // Prepend '+' if missing, since WhatsApp strips it
  const formattedInput = whatsappNumber.startsWith('+') 
    ? whatsappNumber 
    : `+${whatsappNumber}`;

  try {
    const phoneNumber: PhoneNumber | undefined = parsePhoneNumber(formattedInput);

    if (phoneNumber && phoneNumber.isValid()) {
      // Returns ONLY the national digits (e.g., "9876543210" or "5551234567")
      return phoneNumber.nationalNumber as string;
    }
  } catch (error) {
    console.error(`Failed to parse phone number: ${whatsappNumber}`, error);
  }

  return null;
}

public static stripEmailFooter(html: string): string {
  if (!html) return html
  return html.replace(/<!--\s*Footer\s*-->\s*<tr>[\s\S]*?<\/tr>/i, '')
}

/** Plain-text rendering of an HTML (or already-plain) message body, for use
 * inside cross-channel reference previews. Not a full email->text renderer —
 * just enough to make a short, readable quote. */
public static stripHtmlToText(html: string): string {
  if (!html) return ''
  return html
    .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi, '')
    .replace(/<(br|\/p|\/div|\/tr|\/li)\s*\/?>/gi, ' ')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
}

/**
 * Cross-channel reply referencing. When an agent replies to a message on a
 * DIFFERENT channel than the one it originated on, the destination channel
 * has no native way to show "this is about that" (WhatsApp has no concept of
 * quoting a non-WhatsApp message; a fresh email has no visual thread tie to a
 * WhatsApp bubble) — so we inject a short, readable reference into the
 * outbound content itself. Same-channel replies are left untouched, since
 * same-channel threading (Graph reply-to / WA native context) already
 * carries that context natively.
 *
 * The agent sees the arrows/quote UI in ubiDesk and knows exactly which
 * message this is about — the customer doesn't have that screen, so the
 * reference has to stand on its own: a bare snippet of their own "Hello"
 * tells them nothing. We anchor it with a date/time instead of decoration —
 * no emoji (renders as a literal glyph in ubiDesk's own plain-text bubble,
 * and isn't guaranteed to render cleanly on every WhatsApp client either),
 * no markdown syntax that doesn't get parsed outside WhatsApp's own app.
 */
public static applyCrossChannelReference(
  message: string,
  related: { channel?: string | null; message?: string | null; created_at?: string | Date | null } | null | undefined,
  targetChannel: 'email' | 'whatsapp'
): string {
  if (!related || !related.channel || related.channel === targetChannel) return message
  const preview = Helper.stripHtmlToText(related.message || '').slice(0, 160)
  if (!preview) return message
  const truncated = preview.length >= 160 ? `${preview}…` : preview
  const when = related.created_at ? Helper.formatReferenceTimestamp(related.created_at) : null
  const whenSuffix = when ? ` (${when})` : ''

  if (targetChannel === 'whatsapp') {
    // Plain text only — WhatsApp text messages can't render HTML.
    return `Replying to your email${whenSuffix}: "${truncated}"\n\n${message}`
  }

  // targetChannel === 'email', related was a WhatsApp message.
  const escaped = truncated.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  const quote = `<div style="border-left:3px solid #25d366;margin:0 0 12px 0;padding:6px 10px;` +
    `background:#f8fafc;border-radius:6px;font-size:12.5px;line-height:1.5;">` +
    `<div style="font-weight:600;color:#0f172a;margin-bottom:2px;">Replying to your WhatsApp message${whenSuffix}</div>` +
    `<div style="color:#475569;">"${escaped}"</div></div>`
  return quote + message
}

/** e.g. "10 Aug, 5:07 PM" — enough for a customer to place which message a
 * cross-channel reference is about, without assuming their timezone matches
 * the server's (uses the account's configured display timezone if set). */
private static formatReferenceTimestamp(value: string | Date): string { 
  try {
    const d = value instanceof Date ? value : new Date(value)
    if (Number.isNaN(d.getTime())) return ''
    return new Intl.DateTimeFormat('en-US', {
      day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true,
    }).format(d)
  } catch {
    return ''
  }
}
}