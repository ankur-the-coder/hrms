/**
 * Ticket classifier v2 — rebuilt from actual production ticket subjects
 * (303 real rows analyzed). Key changes from the old inline version that
 * lived in TicketService (Billing/Access/Account/Technical, first-match
 * keyword list): that version put 73.6% of real tickets into "Other"
 * because its categories were generic SaaS boilerplate, not this product's
 * domain (HRMS: attendance, leave, payroll, biometric sync, integrations).
 *
 * What changed:
 * 1. Categories now match the real domain (Attendance, Leave & Holidays,
 *    Payroll & Billing, Access & Credentials, Integration & API, Setup &
 *    Onboarding, HRMS Configuration).
 * 2. Word-boundary matching instead of raw `.includes()`, so "off" doesn't
 *    fire inside "office" and "issue" doesn't fire inside "reissue".
 * 3. Weighted scoring across ALL categories instead of "first keyword
 *    list wins" — whichever category has the strongest, most specific
 *    signal wins, not whichever was listed first.
 * 4. A noise/non-ticket pre-filter — calendar invites, auto-reply
 *    receipts, out-of-office bounces, and internal test subjects get
 *    tagged separately instead of forced into a support category
 *    (~23% of rows in the sample data).
 * 5. "Escalation" is a signal that bumps priority rather than a category
 *    that competes with the real topic (e.g. "Strong Escalation:
 *    Razorpay & Payroll Impact" is a Payroll ticket that's escalated).
 * 6. Returns a confidence score + matched keywords, so low-confidence
 *    classifications can be routed to a review queue instead of filed
 *    under a guess.
 * 7. Classifies on subject + first message body, not subject alone — many
 *    real subjects ("Request on Meeting", "Discussion call") carry no
 *    topic signal at all; the content is only in the body.
 */

export type Category =
  | 'Attendance'
  | 'Leave & Holidays'
  | 'Payroll & Billing'
  | 'Access & Credentials'
  | 'Integration & API'
  | 'Setup & Onboarding'
  | 'HRMS Configuration'
  | 'Technical'
  | 'Internal / Noise'
  | 'Other'

export interface ClassificationResult {
  category: Category
  confidence: number // 0–1, relative strength of the winning score vs. total signal found
  matchedKeywords: string[]
  suggestPriorityBump: boolean // true if escalation language was detected
  needsReview: boolean // true when confidence is too low to trust automatically
}

interface CategoryRule {
  category: Exclude<Category, 'Internal / Noise' | 'Other'>
  keywords: string[]
  weight?: number // default 1 — bump for keywords that are rarely ambiguous
}

// Patterns seen repeatedly in production data that are NOT support requests
// at all: auto-reply receipts, calendar invites/bounces, internal test tickets.
const NOISE_PATTERNS: RegExp[] = [
  /^\[##\d+##\]/i, // "[##20690##] Your reply has been received" — 33/303 rows in sample data
  /your reply has been received/i,
  /^(updated )?invitation:/i,
  /^(accepted|declined|tentative):/i,
  /^(out of office|automatic reply|auto-?reply)/i,
  /^undeliverable:/i,
  /^test(ing)?\b/i,
  /^test subject/i,
  /weekly round ?up/i,
  /privacy policy update/i,
]

const ESCALATION_PATTERN =
  /\b(escalation|escalate|urgent|unresolved|dedicated poc|refund request|strong escalation)\b/i

const CATEGORY_RULES: CategoryRule[] = [
  {
    category: 'Payroll & Billing',
    weight: 2,
    keywords: [
      'payroll', 'salary', 'salary slip', 'razorpay', 'invoice', 'billing',
      'refund', 'payment', 'subscription', 'pricing', 'renewal', 'ot calculation',
    ],
  },
  {
    category: 'Attendance',
    weight: 2,
    keywords: [
      'attendance', 'biometric', 'punch in', 'punch out', 'punch',
      'geo fencing', 'geo-fencing', 'geofencing', 'face reading', 'sync',
      'syncing', 'regularization', 'shift change', 'night shift', 'kiosk',
    ],
  },
  {
    category: 'Leave & Holidays',
    weight: 2,
    keywords: [
      'leave', 'holiday', 'comp-off', 'comp off', 'weekly off', 'lwd',
      'wfh', 'work from home', 'outdoor duty', 'leave approval', 'leave balance',
    ],
  },
  {
    category: 'Access & Credentials',
    weight: 2,
    keywords: [
      'login', 'log in', 'password', 'credentials', 'locked out',
      'access denied', 'permission', 'otp', 'unlock', 'sign in',
      'unable to login', 'not working',
    ],
  },
  {
    category: 'Integration & API',
    weight: 2,
    keywords: [
      'api', 'integration', 'essl', 'webhook', 'not reflecting',
      'time out', 'timeout', 'no data',
    ],
  },
  {
    category: 'Setup & Onboarding',
    keywords: [
      'set up', 'setup', 'onboarding', 'training', 'demo', 'kick off',
      'kickoff', 'org id', 'set up initiation', 'product training',
    ],
  },
  {
    category: 'HRMS Configuration',
    keywords: [
      'kra', 'kpi', 'policy', 'configure', 'configuration',
      'reporting manager', 'update details', 'profile', 'settings',
      'deactivate', 'delete account', 'add employee', 'exited employee',
    ],
  },
  {
    // Catch-all for generic technical language that doesn't hit a more
    // specific domain category above (checked last, low weight).
    category: 'Technical',
    weight: 0.75,
    keywords: [
      'error', 'bug', 'crash', 'broken', 'fail', 'failed', 'exception',
      'down', 'cannot', "can't", 'issue', 'unable to',
    ],
  },
]

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function keywordRegex(phrase: string): RegExp {
  // Word-boundary-safe even for multi-word phrases and phrases with punctuation like "comp-off".
  return new RegExp(`(?<![a-z0-9])${escapeRegex(phrase)}(?![a-z0-9])`, 'i')
}

export default class TicketClassifier {
  /**
   * @param subject  Ticket subject line.
   * @param bodyText Plain-text of the first customer message, if available.
   *                 Strongly recommended — many real subjects carry no topic
   *                 signal ("Discussion call", "Request on Meeting").
   */
  public static classify(subject: string, bodyText = ''): ClassificationResult {
    const subjectClean = (subject || '').trim()
    const haystack = `${subjectClean} ${bodyText}`.toLowerCase()

    for (const pattern of NOISE_PATTERNS) {
      if (pattern.test(subjectClean)) {
        return {
          category: 'Internal / Noise',
          confidence: 1,
          matchedKeywords: [],
          suggestPriorityBump: false,
          needsReview: false,
        }
      }
    }

    const scores = new Map<Category, { score: number; matched: string[] }>()

    for (const rule of CATEGORY_RULES) {
      const weight = rule.weight ?? 1
      for (const kw of rule.keywords) {
        if (keywordRegex(kw).test(haystack)) {
          const entry = scores.get(rule.category) ?? { score: 0, matched: [] }
          entry.score += weight
          entry.matched.push(kw)
          scores.set(rule.category, entry)
        }
      }
    }

    const suggestPriorityBump = ESCALATION_PATTERN.test(haystack)

    if (scores.size === 0) {
      return {
        category: 'Other',
        confidence: 0,
        matchedKeywords: [],
        suggestPriorityBump,
        needsReview: true,
      }
    }

    const ranked = [...scores.entries()].sort((a, b) => b[1].score - a[1].score)
    const [topCategory, topEntry] = ranked[0]
    const totalScore = ranked.reduce((sum, [, v]) => sum + v.score, 0)
    const confidence = topEntry.score / totalScore

    // Low confidence = multiple categories matched about equally hard, or
    // only a single weak/generic keyword (e.g. bare "Technical" match) fired.
    const needsReview = confidence < 0.6 || (topEntry.score < 1 && ranked.length === 1)

    return {
      category: topCategory,
      confidence: Number(confidence.toFixed(2)),
      matchedKeywords: topEntry.matched,
      suggestPriorityBump,
      needsReview,
    }
  }

  /**
   * Strips the small subset of HTML that shows up in ticket_messages.message
   * down to plain text, for feeding into classify() alongside the subject.
   * Mirrors EmailToTicketService.htmlToPlainText's approach (kept local here
   * rather than importing a private method from another service).
   */
  public static htmlToPlainText(html: string | null | undefined): string {
    if (!html) return ''
    return html
      .replace(/<img[^>]*>/gi, '')
      .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi, '')
      .replace(/<(br|\/p|\/div|\/tr)\s*\/?>/gi, '\n')
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\n{3,}/g, '\n\n')
      .replace(/[ \t]{2,}/g, ' ')
      .trim()
  }
}