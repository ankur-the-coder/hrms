import fs from 'fs'
import path from 'path'
import crypto from 'crypto'

/**
 * Request-scoped tracer for the Outlook OAuth + webhook-subscribe flow.
 *
 * Writes an incrementally-updated JSON file to disk per trace, keyed by a
 * random id, so it survives even if the process crashes or restarts mid-flow,
 * and works correctly regardless of PM2 cluster mode (any worker can serve
 * the debug read, since it's file-backed, not in-memory).
 *
 * Usage:
 *   const tracer = new AuthTracer()
 *   tracer.step('callback_received', { query: request.qs() })
 *   ...
 *   tracer.error('token_exchange', err)
 *   tracer.finish('ok')
 */

const TRACE_DIR = path.join(process.cwd(), 'tmp', 'auth-traces')

function ensureDir() {
  if (!fs.existsSync(TRACE_DIR)) fs.mkdirSync(TRACE_DIR, { recursive: true })
}

/** Redacts secrets/tokens so the trace is safe to send to the frontend. Keeps enough (length/prefix) to verify a value is non-empty/changed without leaking it. */
export function redact(value: unknown): string {
  if (value === undefined || value === null) return String(value)
  const str = String(value)
  if (str.length <= 8) return '***'
  return `${str.slice(0, 4)}...${str.slice(-4)} (len:${str.length})`
}

export default class AuthTracer {
  public readonly id: string
  private steps: any[] = []
  private startedAt: number

  constructor() {
    this.id = crypto.randomUUID()
    this.startedAt = Date.now()
    ensureDir()
    this.step('trace_started', {
      pid: process.pid,
      nodeEnv: process.env.NODE_ENV,
      // Helps catch "stale build" deploy issues: mtime of this very file's
      // compiled JS on disk, so you can see if a running worker is older
      // than the source you just pushed.
      compiledFileMtime: this.getSelfMtime(),
      hostname: require('os').hostname(),
    })
  }

  private getSelfMtime() {
    try {
      // __filename here is the compiled JS in /build at runtime
      return fs.statSync(__filename).mtime.toISOString()
    } catch {
      return null
    }
  }

  public step(name: string, data: Record<string, any> = {}) {
    const entry = {
      step: name,
      t: new Date().toISOString(),
      elapsedMs: Date.now() - this.startedAt,
      ...data,
    }
    this.steps.push(entry)
    console.log(`[AuthTrace:${this.id}] ${name}`, JSON.stringify(data))
    this.persist()
    return entry
  }

  public error(name: string, err: any, extra: Record<string, any> = {}) {
    const entry = {
      step: name,
      t: new Date().toISOString(),
      elapsedMs: Date.now() - this.startedAt,
      error: true,
      message: err?.message,
      // Axios errors: capture the actual HTTP exchange that failed, since
      // that's almost always the thing you actually need to see.
      httpStatus: err?.response?.status,
      httpStatusText: err?.response?.statusText,
      responseData: err?.response?.data,
      requestMethod: err?.config?.method,
      requestUrl: err?.config?.url,
      stack: err?.stack,
      ...extra,
    }
    this.steps.push(entry)
    console.error(`[AuthTrace:${this.id}] ERROR ${name}`, JSON.stringify(entry))
    this.persist()
    return entry
  }

  public finish(status: 'ok' | 'failed') {
    this.step('trace_finished', { status, totalMs: Date.now() - this.startedAt })
  }

  private persist() {
    try {
      const file = path.join(TRACE_DIR, `${this.id}.json`)
      fs.writeFileSync(file, JSON.stringify({ id: this.id, steps: this.steps }, null, 2))
    } catch (e) {
      // Never let tracing itself break the auth flow.
      console.error('[AuthTracer] failed to persist trace:', (e as any)?.message)
    }
  }

  public static read(traceId: string): any {
    // traceId comes from a query param — sanitize before touching the filesystem.
    if (!/^[a-f0-9-]{36}$/i.test(traceId)) return null
    const file = path.join(TRACE_DIR, `${traceId}.json`)
    if (!fs.existsSync(file)) return null
    return JSON.parse(fs.readFileSync(file, 'utf-8'))
  }
}