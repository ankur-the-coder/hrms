/**
 * Baseline HTML sanitizer for user-supplied rich content (agent footers,
 * email templates). Strips script/iframe/object/embed/link/meta tags,
 * inline event-handler attributes, and javascript: URLs.
 *
 * This is a best-effort regex pass, not a full parser — for production use
 * swap in a proper library (e.g. `sanitize-html`) for robust coverage.
 */
export default class HtmlSanitizer {
  public static sanitize(html: string): string {
    if (!html) return ''
    return html
      .replace(/<(script|iframe|object|embed|link|meta)[^>]*>[\s\S]*?<\/\1>/gi, '')
      .replace(/<(script|iframe|object|embed|link|meta)[^>]*\/?>/gi, '')
      .replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '')
      .replace(/(href|src)\s*=\s*(["'])\s*javascript:[^"']*\2/gi, '$1="#"')
  }
}