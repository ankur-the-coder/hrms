import { schema, rules } from '@ioc:Adonis/Core/Validator'

export default class AgentValidator {
  public static create = {
    schema: schema.create({
      name:     schema.string({ trim: true }),
      username: schema.string({ trim: true }),
      password: schema.string({ trim: true }, [rules.minLength(6)]),
      role:     schema.enum(['admin', 'agent'] as const),
    })
  }
  public static update = {
    schema: schema.create({
      id:       schema.number(),
      name:     schema.string.optional({ trim: true }),
      username: schema.string.optional({ trim: true }),
      password: schema.string.optional({ trim: true }, [rules.minLength(6)]),
      role:     schema.enum.optional(['admin', 'agent'] as const),
      isActive: schema.boolean.optional(),
    })
  }
}