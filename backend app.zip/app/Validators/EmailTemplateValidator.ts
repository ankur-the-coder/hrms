import { schema } from '@ioc:Adonis/Core/Validator'

export default class EmailTemplateValidator {
  public static update = {
    schema: schema.create({
      html: schema.string({}, []),
    })
  }
}