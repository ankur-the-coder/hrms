import { schema, rules } from '@ioc:Adonis/Core/Validator'

export default class TicketValidator {
public static createTicket = {
  schema: schema.create({
    customerName:  schema.string({ trim: true }),
    customerPhone: schema.string.optional({ trim: true }),
    customerEmail: schema.string.optional({ trim: true }, [rules.email()]),
    subject:       schema.string.optional({ trim: true }),   // ← add this
    source:        schema.enum(['whatsapp', 'email', 'phone', 'manual'] as const),
    priority:      schema.enum.optional(['low', 'medium', 'high'] as const),
    // Renamed from `description` — this is now the agent's own opening
    // message to the customer (replaces the old auto-response), so it's
    // optional: an agent can create a bare ticket with no message at all.
    // NOTE: kept as a distinct key from the legacy `description` field
    // that EmailToTicketService/WhatsappService still pass straight into
    // TicketService.createTicket() for inbound intake — those paths are
    // untouched by this rename.
    message:       schema.string.optional({ trim: true }),
    // Client-generated/pre-fetched ticket UID (see GET /tickets/next-uid) —
    // lets the Add Ticket modal show the real ID *before* Submit is
    // clicked, and guarantees what's shown is what's actually saved.
    ticketUid:      schema.string.optional({ trim: true }),
    widgetKey:      schema.string.optional({ trim: true }),
    conversationId: schema.number.optional(),
    ccRecipients:  schema.array.optional().members(schema.string({ trim: true }, [rules.email()])),
    bccRecipients: schema.array.optional().members(schema.string({ trim: true }, [rules.email()])),
    assignedTo:    schema.number.optional(),
    // Files the agent attached in the Add Ticket modal before Submit — same
    // shape/flow as addMessage's `attachments` (uploaded ahead of time via
    // POST /tickets/attachments/upload).
    attachments: schema.array.optional().members(
      schema.object().members({
        fileName:    schema.string({ trim: true }),
        contentType: schema.string.optional({ trim: true }),
        size:        schema.number.optional(),
        storagePath: schema.string({ trim: true }),
      })
    ),
  })
}

  public static updateTicket = {
    schema: schema.create({
      id:                 schema.number(),
   status: schema.enum.optional(['open', 'on_hold', 'escalated', 'closed'] as const),
      priority:           schema.enum.optional(['low', 'medium', 'high'] as const),
      sendClosureMessage: schema.boolean.optional(),
    })
  }


  public static assignTicket = {
    schema: schema.create({
      ticketId:  schema.number(),
      agentId:   schema.number(),
      agentName: schema.string({ trim: true }),
    })
  }

  public static updateDetails = { 
  schema: schema.create({
    id:            schema.number(),
    customerName:  schema.string.optional({ trim: true }),
    customerPhone: schema.string.optional({ trim: true }),
    customerEmail: schema.string.optional({ trim: true }, [rules.email()]),
    priority:      schema.enum.optional(['low', 'medium', 'high'] as const),
  status: schema.enum.optional(['open', 'on_hold', 'escalated', 'closed'] as const),
    source:        schema.enum.optional(['whatsapp', 'email', 'phone', 'manual'] as const),
  })
}

public static addMessage = { 
  schema: schema.create({
    ticketId: schema.number(),
    sender:   schema.enum(['customer', 'agent', 'system'] as const),
    type:     schema.enum(['reply', 'internal_note'] as const),
    message:  schema.string({ trim: true }),
    replyMode: schema.enum.optional(['reply', 'reply_all', 'reply_selected', 'forward'] as const),
    channel:   schema.enum.optional(['email', 'whatsapp'] as const),
    recipients: schema.object.optional().members({
      to: schema.array.optional().members(schema.string()),
      cc: schema.array.optional().members(schema.string()),
    }),
    // Populated from TicketController.uploadAttachment's response, one entry
    // per file the agent attached before hitting Send. See
    // TicketService.addMessage for how these become ticket_attachments rows
    // and get forwarded to the outbound email/WhatsApp send.
    attachments: schema.array.optional().members(
      schema.object().members({
        fileName:    schema.string({ trim: true }),
        contentType: schema.string.optional({ trim: true }),
        size:        schema.number.optional(),
        storagePath: schema.string({ trim: true }),
      })
    ),
  })
}
}