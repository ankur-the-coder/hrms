import { schema, rules } from '@ioc:Adonis/Core/Validator'

export default class AuthValidator {
  public static login = {
    schema: schema.create({
      username: schema.string({ trim: true }, [rules.required()]),
      password: schema.string({}, [rules.required()]),
      device:   schema.string.optional({ trim: true }),
      force:    schema.boolean.optional(),
    })
  }
}