import { schema, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class ChatValidator {
  constructor(protected ctx: HttpContextContract) {}
  public schema = schema.create({})

 public static startSession = {
    schema: schema.create({
      id: schema.number.optional(), // Sent when updating an existing session (e.g. changing intent to meeting or sales)
      visitorName: schema.string({ trim: true }),
      visitorPhone: schema.string.optional(), 
      visitorEmail: schema.string.optional({ trim: true }, [rules.email()]),
      visitorIp: schema.string.optional(),
      widgetKey: schema.string({ trim: true }),
      intent: schema.string.optional(),
      notes: schema.string.optional(),
    })
  }


}