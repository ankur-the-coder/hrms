import Database from '@ioc:Adonis/Lucid/Database'
import HtmlSanitizer from 'App/Helper/HtmlSanitizer'

export type EmailTemplateKey = 'auto_ticket_response' | 'ticket_closure' | 'agent_footer_default'

export default class EmailTemplateService {
  public static async listAll() {
    return Database.from('email_templates').select('template_key', 'html', 'default_html', 'updated_at')
  }

  public static async get(key: EmailTemplateKey): Promise<string> {
    const row = await Database.from('email_templates').where('template_key', key).first()
    return row?.html ?? ''
  }

  public static async update(key: EmailTemplateKey, html: string, updatedBy: number) {
    const clean = HtmlSanitizer.sanitize(html)
    const updated = await Database.from('email_templates').where('template_key', key).update({
      html: clean,
      updated_by: updatedBy,
      updated_at: new Date(),
    })
    if (!updated) {
      await Database.table('email_templates').insert({
        template_key: key,
        html: clean,
        default_html: clean,
        updated_by: updatedBy,
        updated_at: new Date(),
      })
    }
    return { status: true }
  }

  public static async resetToDefault(key: EmailTemplateKey, updatedBy: number) {
    const row = await Database.from('email_templates').where('template_key', key).first()
    if (!row) return { status: false, msg: 'Unknown template key' }
    await Database.from('email_templates').where('template_key', key).update({
      html: row.default_html,
      updated_by: updatedBy,
      updated_at: new Date(),
    })
    return { status: true, html: row.default_html }
  }
}
