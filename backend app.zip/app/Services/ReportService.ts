import Database from '@ioc:Adonis/Lucid/Database'
import MailAccountService from 'App/Services/MailAccountService'

export interface ReportFilters {
  startDate?: string
  endDate?: string
  source?: string
  priority?: string
  agentId?: number | string
  status?: string
}

export interface ReportSchedule {
  id?: number
  name: string
  recipients: string
  frequency: 'daily' | 'weekly' | 'weekday' | 'monthly'
  day_of_week?: number
  time_of_day: string
  timezone?: string
  date_range: 'last_7_days' | 'last_14_days' | 'last_30_days' | 'yesterday' | 'last_week' | 'last_month'
  include_sections?: string[]
  is_active?: boolean | number
  created_by?: number
  last_run_at?: Date | string | null
  last_run_status?: 'success' | 'failed' | null
  last_error?: string | null
  created_at?: Date | string
  updated_at?: Date | string
}

export default class ReportService {

  // ─── HELPER: Date range resolver ──────────────────────────────────────────
  public static resolveDateRange(range: string): { start: Date; end: Date; label: string } {
    const end = new Date()
    const start = new Date()

    switch (range) {
      case 'today':
        start.setHours(0, 0, 0, 0)
        return { start, end, label: 'Today' }
      case 'yesterday': {
        const yStart = new Date()
        yStart.setDate(yStart.getDate() - 1)
        yStart.setHours(0, 0, 0, 0)
        const yEnd = new Date()
        yEnd.setDate(yEnd.getDate() - 1)
        yEnd.setHours(23, 59, 59, 999)
        return { start: yStart, end: yEnd, label: 'Yesterday' }
      }
      case 'last_week': {
        start.setDate(start.getDate() - 7)
        start.setHours(0, 0, 0, 0)
        return { start, end, label: 'Last Week' }
      }
      case 'last_14_days': {
        start.setDate(start.getDate() - 14)
        start.setHours(0, 0, 0, 0)
        return { start, end, label: 'Last 14 Days' }
      }
      case 'last_30_days': {
        start.setDate(start.getDate() - 30)
        start.setHours(0, 0, 0, 0)
        return { start, end, label: 'Last 30 Days' }
      }
      case 'last_month': {
        start.setMonth(start.getMonth() - 1)
        start.setDate(1)
        start.setHours(0, 0, 0, 0)
        const mEnd = new Date(start.getFullYear(), start.getMonth() + 1, 0, 23, 59, 59, 999)
        return { start, end: mEnd, label: 'Last Month' }
      }
      case 'last_7_days':
      default: {
        start.setDate(start.getDate() - 7)
        start.setHours(0, 0, 0, 0)
        return { start, end, label: 'Last 7 Days' }
      }
    }
  }

  // ─── 360° EXHAUSTIVE REPORT AGGREGATOR ────────────────────────────────────
  public static async get360Report(filters: ReportFilters = {}) {
    // 1. Resolve date window
    let startDate: Date
    let endDate: Date

    if (filters.startDate && filters.endDate) {
      startDate = new Date(filters.startDate)
      endDate = new Date(filters.endDate)
      if (isNaN(startDate.getTime())) startDate = new Date(Date.now() - 7 * 86400000)
      if (isNaN(endDate.getTime())) endDate = new Date()
      // If same day or YYYY-MM-DD string, set end of day
      if (filters.endDate.length === 10) {
        endDate.setHours(23, 59, 59, 999)
      }
    } else {
      const resolved = this.resolveDateRange('last_7_days')
      startDate = resolved.start
      endDate = resolved.end
    }

    const startIso = startDate.toISOString().slice(0, 19).replace('T', ' ')
    const endIso = endDate.toISOString().slice(0, 19).replace('T', ' ')

    // Build base filter query builder helper
    const applyBaseFilters = (query: any) => {
      query.whereNull('deleted_at')
      query.whereBetween('created_at', [startIso, endIso])

      if (filters.source && filters.source !== 'all') {
        query.where('source', filters.source)
      }
      if (filters.priority && filters.priority !== 'all') {
        query.where('priority', filters.priority)
      }
      if (filters.agentId && filters.agentId !== 'all') {
        query.where('assigned_to', Number(filters.agentId))
      }
      if (filters.status && filters.status !== 'all') {
        query.where('status', filters.status)
      }
    }

    // ── 1. EXECUTIVE KPIS ───────────────────────────────────────────────────
    const kpiRow = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereBetween('created_at', [startIso, endIso])
      .select(
        Database.raw('COUNT(*) as total'),
        Database.raw("SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_count"),
        Database.raw("SUM(CASE WHEN status = 'on_hold' THEN 1 ELSE 0 END) as on_hold_count"),
        Database.raw("SUM(CASE WHEN status = 'escalated' THEN 1 ELSE 0 END) as escalated_count"),
        Database.raw("SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_count"),
        Database.raw('SUM(CASE WHEN reopen_count > 0 THEN 1 ELSE 0 END) as reopened_count'),
        Database.raw("SUM(CASE WHEN assigned_to IS NULL AND status != 'closed' THEN 1 ELSE 0 END) as unassigned_count"),
        Database.raw('SUM(CASE WHEN is_spam = 1 THEN 1 ELSE 0 END) as spam_count'),
        Database.raw('SUM(CASE WHEN rating IS NOT NULL THEN 1 ELSE 0 END) as rating_count'),
        Database.raw('AVG(rating) as avg_csat')
      )
      .first()

    const total = Number(kpiRow?.total || 0)
    const openCount = Number(kpiRow?.open_count || 0)
    const onHoldCount = Number(kpiRow?.on_hold_count || 0)
    const escalatedCount = Number(kpiRow?.escalated_count || 0)
    const closedCount = Number(kpiRow?.closed_count || 0)
    const reopenedCount = Number(kpiRow?.reopened_count || 0)
    const unassignedCount = Number(kpiRow?.unassigned_count || 0)
    const spamCount = Number(kpiRow?.spam_count || 0)
    const ratingCount = Number(kpiRow?.rating_count || 0)
    const avgCsat = kpiRow?.avg_csat ? Number(Number(kpiRow.avg_csat).toFixed(2)) : null

    const resolutionRate = total > 0 ? Number(((closedCount / total) * 100).toFixed(1)) : 0
    const reopenRate = closedCount > 0 ? Number(((reopenedCount / closedCount) * 100).toFixed(1)) : 0

    // ── 2. BACKLOG AGING (Currently unresolved tickets) ─────────────────────
    const agingRows = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereIn('status', ['open', 'on_hold', 'escalated'])
      .select(
        Database.raw("SUM(CASE WHEN created_at >= NOW() - INTERVAL 24 HOUR THEN 1 ELSE 0 END) as under_24h"),
        Database.raw("SUM(CASE WHEN created_at >= NOW() - INTERVAL 72 HOUR AND created_at < NOW() - INTERVAL 24 HOUR THEN 1 ELSE 0 END) as days_1_3"),
        Database.raw("SUM(CASE WHEN created_at >= NOW() - INTERVAL 168 HOUR AND created_at < NOW() - INTERVAL 72 HOUR THEN 1 ELSE 0 END) as days_4_7"),
        Database.raw("SUM(CASE WHEN created_at < NOW() - INTERVAL 168 HOUR THEN 1 ELSE 0 END) as over_7d")
      )
      .first()

    const backlogAging = {
      under24h: Number(agingRows?.under_24h || 0),
      days1To3: Number(agingRows?.days_1_3 || 0),
      days4To7: Number(agingRows?.days_4_7 || 0),
      over7d: Number(agingRows?.over_7d || 0),
    }

    // ── 3. SLA & TIMING (FRT & MTTR) ────────────────────────────────────────
    // First Response Time (time to first agent reply message)
    const frtQuery = Database.from('tickets as t')
      .join('ticket_messages as m', (join) => {
        join.on('m.ticket_id', 't.id')
          .andOnVal('m.sender', 'agent')
          .andOnVal('m.type', 'reply')
      })
      .whereNull('t.deleted_at')
      .whereBetween('t.created_at', [startIso, endIso])
      .groupBy('t.id', 't.created_at')
      .select('t.id', Database.raw('TIMESTAMPDIFF(SECOND, t.created_at, MIN(m.created_at)) as frt_seconds'))
      .havingRaw('frt_seconds >= 0')

    const frtRows = await frtQuery
    let avgFrtSeconds = 0
    let medianFrtSeconds = 0
    if (frtRows.length > 0) {
      const sum = frtRows.reduce((acc: number, r: any) => acc + Number(r.frt_seconds), 0)
      avgFrtSeconds = Math.round(sum / frtRows.length)
      const sorted = frtRows.map((r: any) => Number(r.frt_seconds)).sort((a: number, b: number) => a - b)
      const mid = Math.floor(sorted.length / 2)
      medianFrtSeconds = sorted.length % 2 !== 0 ? sorted[mid] : Math.round((sorted[mid - 1] + sorted[mid]) / 2)
    }

    // Mean Time to Resolution (MTTR) for closed tickets
    const mttrRows = await Database.from('tickets')
      .whereNull('deleted_at')
      .where('status', 'closed')
      .whereBetween('created_at', [startIso, endIso])
      .select(Database.raw('TIMESTAMPDIFF(SECOND, created_at, updated_at) as resolution_seconds'))
      .havingRaw('resolution_seconds >= 0')

    let avgResolutionSeconds = 0
    let medianResolutionSeconds = 0
    if (mttrRows.length > 0) {
      const sum = mttrRows.reduce((acc: number, r: any) => acc + Number(r.resolution_seconds), 0)
      avgResolutionSeconds = Math.round(sum / mttrRows.length)
      const sorted = mttrRows.map((r: any) => Number(r.resolution_seconds)).sort((a: number, b: number) => a - b)
      const mid = Math.floor(sorted.length / 2)
      medianResolutionSeconds = sorted.length % 2 !== 0 ? sorted[mid] : Math.round((sorted[mid - 1] + sorted[mid]) / 2)
    }

    // ── 4. CSAT METRICS & DIRECT FEEDBACK ───────────────────────────────────
    const csatDistributionRows = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereBetween('created_at', [startIso, endIso])
      .whereNotNull('rating')
      .groupBy('rating')
      .select('rating', Database.raw('COUNT(*) as count'))

    const csatDist: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }
    for (const row of csatDistributionRows) {
      csatDist[Number(row.rating)] = Number(row.count)
    }

    const recentFeedback = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereNotNull('rating')
      .where((q) => {
        q.whereNotNull('rating_liked_most').orWhereNotNull('rating_improve_feedback')
      })
      .orderBy('rating_submitted_at', 'desc')
      .limit(8)
      .select(
        'id',
        'ticket_uid',
        'customer_name',
        'rating',
        'rating_liked_most',
        'rating_improve_feedback',
        'rating_submitted_at'
      )

    // ── 5. AGENT PERFORMANCE LEADERBOARD ────────────────────────────────────
    const agents = await Database.from('support_agents')
      .where('is_active', 1)
      .select('id', 'name', 'username', 'role')

    const agentStatsRows = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereBetween('created_at', [startIso, endIso])
      .whereNotNull('assigned_to')
      .groupBy('assigned_to')
      .select(
        'assigned_to',
        Database.raw('COUNT(*) as assigned_count'),
        Database.raw("SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_count"),
        Database.raw("SUM(CASE WHEN status != 'closed' THEN 1 ELSE 0 END) as open_count"),
        Database.raw('SUM(CASE WHEN reopen_count > 0 THEN 1 ELSE 0 END) as reopen_count'),
        Database.raw("AVG(CASE WHEN status = 'closed' THEN TIMESTAMPDIFF(SECOND, created_at, updated_at) ELSE NULL END) as avg_resolution_seconds"),
        Database.raw('AVG(rating) as avg_csat'),
        Database.raw('SUM(CASE WHEN rating IS NOT NULL THEN 1 ELSE 0 END) as csat_count')
      )

    const agentStatsMap = new Map<number, any>()
    for (const r of agentStatsRows) {
      agentStatsMap.set(Number(r.assigned_to), r)
    }

    const agentLeaderboard = agents.map((a: any) => {
      const s = agentStatsMap.get(a.id)
      const assigned = Number(s?.assigned_count || 0)
      const closed = Number(s?.closed_count || 0)
      const open = Number(s?.open_count || 0)
      const reopened = Number(s?.reopen_count || 0)
      const avgRes = s?.avg_resolution_seconds ? Math.round(Number(s.avg_resolution_seconds)) : null
      const csat = s?.avg_csat ? Number(Number(s.avg_csat).toFixed(2)) : null
      const csatReviews = Number(s?.csat_count || 0)
      const rate = assigned > 0 ? Number(((closed / assigned) * 100).toFixed(1)) : 0

      return {
        agentId: a.id,
        name: a.name,
        username: a.username,
        role: a.role,
        assigned,
        closed,
        open,
        reopened,
        resolutionRate: rate,
        avgResolutionSeconds: avgRes,
        avgCsat: csat,
        csatReviews,
      }
    }).sort((a: any, b: any) => b.closed - a.closed)

    // ── 6. CHANNEL / SOURCE ANALYSIS ────────────────────────────────────────
    const channelRows = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereBetween('created_at', [startIso, endIso])
      .groupBy('source')
      .select(
        'source',
        Database.raw('COUNT(*) as total'),
        Database.raw("SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_count"),
        Database.raw("SUM(CASE WHEN status != 'closed' THEN 1 ELSE 0 END) as open_count"),
        Database.raw("AVG(CASE WHEN status = 'closed' THEN TIMESTAMPDIFF(SECOND, created_at, updated_at) ELSE NULL END) as avg_resolution_seconds")
      )

    const channels = channelRows.map((r: any) => ({
      source: r.source,
      total: Number(r.total),
      pct: total > 0 ? Number(((Number(r.total) / total) * 100).toFixed(1)) : 0,
      closed: Number(r.closed_count),
      open: Number(r.open_count),
      avgResolutionSeconds: r.avg_resolution_seconds ? Math.round(Number(r.avg_resolution_seconds)) : null,
    }))

    // ── 7. PRIORITY BREAKDOWN ───────────────────────────────────────────────
    const priorityRows = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereBetween('created_at', [startIso, endIso])
      .groupBy('priority')
      .select(
        'priority',
        Database.raw('COUNT(*) as total'),
        Database.raw("SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_count"),
        Database.raw("SUM(CASE WHEN status != 'closed' THEN 1 ELSE 0 END) as open_count")
      )

    const priorities = priorityRows.map((r: any) => ({
      priority: r.priority,
      total: Number(r.total),
      pct: total > 0 ? Number(((Number(r.total) / total) * 100).toFixed(1)) : 0,
      closed: Number(r.closed_count),
      open: Number(r.open_count),
    }))

    // ── 8. DAILY VOLUME TRENDS (Created vs Closed vs Reopened) ──────────────
    const trendCreatedQ = Database.from('tickets')
      .whereNull('deleted_at')
      .whereBetween('created_at', [startIso, endIso])
    if (filters.source && filters.source !== 'all') trendCreatedQ.where('source', filters.source)
    if (filters.priority && filters.priority !== 'all') trendCreatedQ.where('priority', filters.priority)
    if (filters.agentId && filters.agentId !== 'all') trendCreatedQ.where('assigned_to', Number(filters.agentId))
    const trendCreated = await trendCreatedQ
      .groupByRaw("DATE_FORMAT(created_at, '%Y-%m-%d')")
      .select(Database.raw("DATE_FORMAT(created_at, '%Y-%m-%d') as day"), Database.raw('COUNT(*) as count'))

    const trendClosedQ = Database.from('tickets')
      .whereNull('deleted_at')
      .where('status', 'closed')
      .whereBetween('updated_at', [startIso, endIso])
    if (filters.source && filters.source !== 'all') trendClosedQ.where('source', filters.source)
    if (filters.priority && filters.priority !== 'all') trendClosedQ.where('priority', filters.priority)
    if (filters.agentId && filters.agentId !== 'all') trendClosedQ.where('assigned_to', Number(filters.agentId))
    const trendClosed = await trendClosedQ
      .groupByRaw("DATE_FORMAT(updated_at, '%Y-%m-%d')")
      .select(Database.raw("DATE_FORMAT(updated_at, '%Y-%m-%d') as day"), Database.raw('COUNT(*) as count'))

    const trendReopenedQ = Database.from('tickets')
      .whereNull('deleted_at')
      .whereNotNull('last_reopened_at')
      .whereBetween('last_reopened_at', [startIso, endIso])
    if (filters.source && filters.source !== 'all') trendReopenedQ.where('source', filters.source)
    if (filters.priority && filters.priority !== 'all') trendReopenedQ.where('priority', filters.priority)
    if (filters.agentId && filters.agentId !== 'all') trendReopenedQ.where('assigned_to', Number(filters.agentId))
    const trendReopened = await trendReopenedQ
      .groupByRaw("DATE_FORMAT(last_reopened_at, '%Y-%m-%d')")
      .select(Database.raw("DATE_FORMAT(last_reopened_at, '%Y-%m-%d') as day"), Database.raw('COUNT(*) as count'))

    const extractDayStr = (val: any): string => {
      if (!val) return ''
      if (typeof val === 'string') {
        const m = val.match(/\d{4}-\d{2}-\d{2}/)
        return m ? m[0] : val.slice(0, 10)
      }
      if (val instanceof Date) {
        return val.toISOString().slice(0, 10)
      }
      return String(val).slice(0, 10)
    }

    // Build timeline points for all days in window
    const createdMap = new Map<string, number>()
    for (const r of trendCreated) {
      const k = extractDayStr(r.day)
      if (k) createdMap.set(k, Number(r.count))
    }
    const closedMap = new Map<string, number>()
    for (const r of trendClosed) {
      const k = extractDayStr(r.day)
      if (k) closedMap.set(k, Number(r.count))
    }
    const reopenedMap = new Map<string, number>()
    for (const r of trendReopened) {
      const k = extractDayStr(r.day)
      if (k) reopenedMap.set(k, Number(r.count))
    }

    const dailyTrends: any[] = []
    const cur = new Date(startDate)
    cur.setUTCHours(0, 0, 0, 0)
    const endBound = new Date(endDate)

    while (cur <= endBound) {
      const iso = cur.toISOString().slice(0, 10)
      const label = cur.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })
      dailyTrends.push({
        date: iso,
        label,
        created: createdMap.get(iso) || 0,
        closed: closedMap.get(iso) || 0,
        reopened: reopenedMap.get(iso) || 0,
      })
      cur.setUTCDate(cur.getUTCDate() + 1)
    }

    // ── 9. PEAK INFLUX HEATMAP (Hourly 00:00 to 23:00) ──────────────────────
    const hourlyQ = Database.from('tickets')
      .whereNull('deleted_at')
      .whereBetween('created_at', [startIso, endIso])
    if (filters.source && filters.source !== 'all') hourlyQ.where('source', filters.source)
    if (filters.priority && filters.priority !== 'all') hourlyQ.where('priority', filters.priority)
    if (filters.agentId && filters.agentId !== 'all') hourlyQ.where('assigned_to', Number(filters.agentId))
    const hourlyRows = await hourlyQ
      .groupByRaw('HOUR(created_at)')
      .select(Database.raw('HOUR(created_at) as hour'), Database.raw('COUNT(*) as count'))

    const hourlyMap = new Map<number, number>()
    for (const r of hourlyRows) hourlyMap.set(Number(r.hour), Number(r.count))

    const hourlyHeatmap: any[] = []
    for (let h = 0; h < 24; h++) {
      const count = hourlyMap.get(h) || 0
      const ampm = h >= 12 ? 'PM' : 'AM'
      const displayH = h % 12 === 0 ? 12 : h % 12
      hourlyHeatmap.push({
        hour: h,
        label: `${displayH} ${ampm}`,
        count,
        pct: total > 0 ? Number(((count / total) * 100).toFixed(1)) : 0,
      })
    }

    // ── 10. TOP ORGANIZATIONS ───────────────────────────────────────────────
    const orgRows = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereBetween('created_at', [startIso, endIso])
      .whereNotNull('sender_org_name')
      .where('sender_org_name', '!=', '')
      .groupBy('sender_org_name', 'sender_org_id')
      .orderBy('ticket_count', 'desc')
      .limit(10)
      .select(
        'sender_org_name as org_name',
        'sender_org_id as org_id',
        Database.raw('COUNT(*) as ticket_count'),
        Database.raw("SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_count"),
        Database.raw("SUM(CASE WHEN status != 'closed' THEN 1 ELSE 0 END) as open_count"),
        Database.raw('AVG(rating) as avg_rating')
      )

    // Check VIP / Priority flags
    let priorityOrgIds = new Set<number>()
    try {
      const pOrgs = await Database.from('ticket_priority_organizations').where('is_high_priority', 1).select('org_id')
      priorityOrgIds = new Set(pOrgs.map((p: any) => Number(p.org_id)))
    } catch {
      // Table might not exist or empty
    }

    const topOrganizations = orgRows.map((r: any) => ({
      orgName: r.org_name,
      orgId: r.org_id,
      ticketCount: Number(r.ticket_count),
      closedCount: Number(r.closed_count),
      openCount: Number(r.open_count),
      avgRating: r.avg_rating ? Number(Number(r.avg_rating).toFixed(1)) : null,
      isHighPriority: r.org_id ? priorityOrgIds.has(Number(r.org_id)) : false,
    }))

    // ── 11. RESOLUTION CODES ────────────────────────────────────────────────
    const resolutionCodeRows = await Database.from('tickets')
      .whereNull('deleted_at')
      .where('status', 'closed')
      .whereBetween('created_at', [startIso, endIso])
      .groupBy('resolution_code')
      .select(
        'resolution_code',
        Database.raw('COUNT(*) as count')
      )

    const resolutionCodes = resolutionCodeRows.map((r: any) => ({
      code: r.resolution_code || 'Unspecified',
      count: Number(r.count),
    })).sort((a: any, b: any) => b.count - a.count)

    return {
      window: {
        startDate: startIso,
        endDate: endIso,
        daysCount: dailyTrends.length,
      },
      kpis: {
        total,
        open: openCount,
        onHold: onHoldCount,
        escalated: escalatedCount,
        closed: closedCount,
        reopened: reopenedCount,
        unassigned: unassignedCount,
        spam: spamCount,
        resolutionRate,
        reopenRate,
        ratingCount,
        avgCsat,
        avgFrtSeconds,
        medianFrtSeconds,
        avgResolutionSeconds,
        medianResolutionSeconds,
      },
      backlogAging,
      csat: {
        average: avgCsat,
        totalRated: ratingCount,
        responseRate: closedCount > 0 ? Number(((ratingCount / closedCount) * 100).toFixed(1)) : 0,
        distribution: csatDist,
        recentFeedback,
      },
      agentLeaderboard,
      channels,
      priorities,
      dailyTrends,
      hourlyHeatmap,
      topOrganizations,
      resolutionCodes,
    }
  }

  // ─── SCHEDULES CRUD ───────────────────────────────────────────────────────
  public static async getSchedules() {
    return Database.from('report_schedules')
      .orderBy('created_at', 'desc')
  }

  public static async getScheduleById(id: number) {
    return Database.from('report_schedules').where('id', id).first()
  }

  public static async createSchedule(data: {
    name: string
    recipients: string
    frequency: string
    day_of_week?: number
    time_of_day: string
    timezone?: string
    date_range: string
    include_sections?: any
    is_active?: boolean
    created_by?: number
  }) {
    const [id] = await Database.table('report_schedules').insert({
      name: data.name,
      recipients: data.recipients,
      frequency: data.frequency || 'weekly',
      day_of_week: data.day_of_week ?? 1,
      time_of_day: data.time_of_day || '09:00',
      timezone: data.timezone || 'Asia/Kolkata',
      date_range: data.date_range || 'last_7_days',
      include_sections: data.include_sections ? JSON.stringify(data.include_sections) : null,
      is_active: data.is_active !== undefined ? (data.is_active ? 1 : 0) : 1,
      created_by: data.created_by || null,
      created_at: new Date(),
      updated_at: new Date(),
    })
    return this.getScheduleById(id)
  }

  public static async updateSchedule(id: number, data: Partial<ReportSchedule>) {
    const updatePayload: any = { updated_at: new Date() }
    if (data.name !== undefined) updatePayload.name = data.name
    if (data.recipients !== undefined) updatePayload.recipients = data.recipients
    if (data.frequency !== undefined) updatePayload.frequency = data.frequency
    if (data.day_of_week !== undefined) updatePayload.day_of_week = data.day_of_week
    if (data.time_of_day !== undefined) updatePayload.time_of_day = data.time_of_day
    if (data.timezone !== undefined) updatePayload.timezone = data.timezone
    if (data.date_range !== undefined) updatePayload.date_range = data.date_range
    if (data.include_sections !== undefined) {
      updatePayload.include_sections = typeof data.include_sections === 'string'
        ? data.include_sections
        : JSON.stringify(data.include_sections)
    }
    if (data.is_active !== undefined) updatePayload.is_active = data.is_active ? 1 : 0

    await Database.from('report_schedules').where('id', id).update(updatePayload)
    return this.getScheduleById(id)
  }

  public static async deleteSchedule(id: number) {
    return Database.from('report_schedules').where('id', id).delete()
  }

  // ─── EXECUTE / DISPATCH SCHEDULE ──────────────────────────────────────────
  public static async runSchedule(id: number) {
    const schedule = await this.getScheduleById(id)
    if (!schedule) throw new Error(`Schedule #${id} not found`)

    // Extract recipients
    const recipientList = String(schedule.recipients || '')
      .split(/[,;\s]+/)
      .map(e => e.trim())
      .filter(e => e.includes('@'))

    if (recipientList.length === 0) {
      throw new Error(`No valid email recipients configured for schedule "${schedule.name}"`)
    }

    const primaryTo = recipientList[0]
    const ccEmails = recipientList.slice(1)

    // Generate 360 report data for this schedule's configured date range
    const rangeInfo = this.resolveDateRange(schedule.date_range || 'last_7_days')
    const reportData = await this.get360Report({
      startDate: rangeInfo.start.toISOString(),
      endDate: rangeInfo.end.toISOString(),
    })

    // Render HTML template
    const html = this.generateHtmlReport(reportData, schedule.name, rangeInfo.label)
    const subject = `📊 [ubiDesk] ${schedule.name} - ${rangeInfo.label} Report`

    try {
      await MailAccountService.sendMail({
        toEmail: primaryTo,
        ccEmails: ccEmails.length ? ccEmails : undefined,
        subject,
        html,
      })

      await Database.from('report_schedules').where('id', id).update({
        last_run_at: new Date(),
        last_run_status: 'success',
        last_error: null,
        updated_at: new Date(),
      })

      return {
        status: true,
        message: `Report sent to ${recipientList.length} recipient(s)`,
        recipients: recipientList,
        runAt: new Date(),
      }
    } catch (err: any) {
      console.error(`[ReportService][runSchedule] failed for schedule #${id}:`, err?.message)
      await Database.from('report_schedules').where('id', id).update({
        last_run_at: new Date(),
        last_run_status: 'failed',
        last_error: err?.message || 'Unknown error during email dispatch',
        updated_at: new Date(),
      })
      throw err
    }
  }

  // ─── AUTOMATED CRON SWEEP ─────────────────────────────────────────────────
  public static async processPendingSchedules() {
    try {
      const schedules = await Database.from('report_schedules').where('is_active', 1)
      if (!schedules || schedules.length === 0) return

      const now = new Date()
      // Evaluate in Asia/Kolkata (or default)
      const options: Intl.DateTimeFormatOptions = {
        timeZone: 'Asia/Kolkata',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        weekday: 'narrow', // or getDay()
      }
      const timeStr = now.toLocaleTimeString('en-GB', { timeZone: 'Asia/Kolkata', hour12: false }).slice(0, 5) // "HH:MM"
      const dayOfWeek = now.getDay() // 0=Sunday, 1=Monday...

      for (const s of schedules) {
        // Target time match
        const targetTime = (s.time_of_day || '09:00').slice(0, 5)
        if (targetTime !== timeStr) continue

        // Frequency match
        let shouldRun = false
        if (s.frequency === 'daily') {
          shouldRun = true
        } else if (s.frequency === 'weekday') {
          shouldRun = dayOfWeek >= 1 && dayOfWeek <= 5
        } else if (s.frequency === 'weekly') {
          const scheduledDay = Number(s.day_of_week ?? 1)
          shouldRun = dayOfWeek === scheduledDay
        } else if (s.frequency === 'monthly') {
          shouldRun = now.getDate() === 1
        }

        if (!shouldRun) continue

        // Debounce: ensure it hasn't run within the last 50 minutes
        if (s.last_run_at) {
          const diffMs = now.getTime() - new Date(s.last_run_at).getTime()
          if (diffMs < 50 * 60 * 1000) continue
        }

        console.log(`[ReportService][cron] Triggering scheduled report #${s.id} "${s.name}"...`)
        try {
          await this.runSchedule(s.id)
        } catch (scheduleErr: any) {
          console.error(`[ReportService][cron] Error running schedule #${s.id}:`, scheduleErr?.message)
        }
      }
    } catch (err: any) {
      // If table doesn't exist yet before user runs SQL, log silently
      if (err?.code === 'ER_NO_SUCH_TABLE') return
      console.error('[ReportService][processPendingSchedules] cron error:', err?.message)
    }
  }

  // ─── EMAIL HTML REPORT GENERATOR ──────────────────────────────────────────
  public static generateHtmlReport(data: any, scheduleName: string, rangeLabel: string): string {
    const kpis = data.kpis
    const formatDuration = (seconds: number) => {
      if (!seconds || seconds <= 0) return '0m'
      const h = Math.floor(seconds / 3600)
      const m = Math.floor((seconds % 3600) / 60)
      if (h > 0) return `${h}h ${m}m`
      return `${m}m`
    }

    const agentsHtml = (data.agentLeaderboard || []).slice(0, 6).map((a: any) => `
      <tr style="border-bottom: 1px solid #f1f5f9;">
        <td style="padding: 10px 12px; font-weight: 600; color: #1e293b;">${a.name}</td>
        <td style="padding: 10px 12px; text-align: center; color: #475569;">${a.assigned}</td>
        <td style="padding: 10px 12px; text-align: center; font-weight: 700; color: #10b981;">${a.closed}</td>
        <td style="padding: 10px 12px; text-align: center; color: #6366f1;">${a.resolutionRate}%</td>
        <td style="padding: 10px 12px; text-align: center; color: #f59e0b;">${a.avgCsat ? '★ ' + a.avgCsat : '—'}</td>
        <td style="padding: 10px 12px; text-align: center; color: #64748b;">${formatDuration(a.avgResolutionSeconds)}</td>
      </tr>
    `).join('')

    const channelsHtml = (data.channels || []).map((c: any) => `
      <div style="flex: 1; min-width: 110px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 12px; text-align: center; margin: 4px;">
        <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #64748b;">${c.source}</div>
        <div style="font-size: 18px; font-weight: 800; color: #0f172a; margin: 4px 0;">${c.total}</div>
        <div style="font-size: 11px; color: #10b981; font-weight: 600;">${c.pct}% share</div>
      </div>
    `).join('')

    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${scheduleName}</title>
</head>
<body style="margin: 0; padding: 24px; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #334155;">
  <div style="max-width: 680px; margin: 0 auto; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(15, 23, 42, 0.05);">
    
    <!-- Header -->
    <div style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); padding: 28px 24px; color: #ffffff;">
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
          <span style="background: rgba(255,255,255,0.2); font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; padding: 4px 10px; border-radius: 20px;">Automated Ticket Digest</span>
          <h1 style="margin: 10px 0 4px 0; font-size: 22px; font-weight: 800; color: #ffffff;">${scheduleName}</h1>
          <p style="margin: 0; font-size: 13px; opacity: 0.9;">Covering period: <strong>${rangeLabel}</strong></p>
        </div>
      </div>
    </div>

    <div style="padding: 24px;">

      <!-- Executive KPI Cards -->
      <h2 style="font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; margin: 0 0 12px 0;">Executive Snapshot</h2>
      <table style="width: 100%; border-collapse: separate; border-spacing: 8px; margin-bottom: 20px;">
        <tr>
          <td style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px; text-align: center; width: 25%;">
            <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase;">Total Volume</div>
            <div style="font-size: 24px; font-weight: 800; color: #0f172a; margin-top: 4px;">${kpis.total}</div>
          </td>
          <td style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px; padding: 14px; text-align: center; width: 25%;">
            <div style="font-size: 11px; font-weight: 700; color: #047857; text-transform: uppercase;">Resolved / Closed</div>
            <div style="font-size: 24px; font-weight: 800; color: #065f46; margin-top: 4px;">${kpis.closed}</div>
            <div style="font-size: 10px; color: #059669; font-weight: 600;">${kpis.resolutionRate}% rate</div>
          </td>
          <td style="background: #eef2ff; border: 1px solid #c7d2fe; border-radius: 10px; padding: 14px; text-align: center; width: 25%;">
            <div style="font-size: 11px; font-weight: 700; color: #4338ca; text-transform: uppercase;">Active Backlog</div>
            <div style="font-size: 24px; font-weight: 800; color: #3730a3; margin-top: 4px;">${kpis.open + kpis.onHold + kpis.escalated}</div>
            <div style="font-size: 10px; color: #4f46e5; font-weight: 600;">${kpis.escalated} escalated</div>
          </td>
          <td style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 10px; padding: 14px; text-align: center; width: 25%;">
            <div style="font-size: 11px; font-weight: 700; color: #b45309; text-transform: uppercase;">CSAT Satisfaction</div>
            <div style="font-size: 24px; font-weight: 800; color: #92400e; margin-top: 4px;">${kpis.avgCsat ? '★ ' + kpis.avgCsat : '—'}</div>
            <div style="font-size: 10px; color: #d97706; font-weight: 600;">${kpis.ratingCount} reviews</div>
          </td>
        </tr>
      </table>

      <!-- Turnaround & SLA Metrics -->
      <table style="width: 100%; border-collapse: separate; border-spacing: 8px; margin-bottom: 24px;">
        <tr>
          <td style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px 16px;">
            <div style="font-size: 11px; font-weight: 600; color: #64748b;">Avg First Response Time</div>
            <div style="font-size: 16px; font-weight: 700; color: #1e293b; margin-top: 2px;">${formatDuration(kpis.avgFrtSeconds)}</div>
          </td>
          <td style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px 16px;">
            <div style="font-size: 11px; font-weight: 600; color: #64748b;">Avg Full Resolution Time</div>
            <div style="font-size: 16px; font-weight: 700; color: #1e293b; margin-top: 2px;">${formatDuration(kpis.avgResolutionSeconds)}</div>
          </td>
          <td style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px 16px;">
            <div style="font-size: 11px; font-weight: 600; color: #64748b;">Reopen Rate</div>
            <div style="font-size: 16px; font-weight: 700; color: ${kpis.reopenRate > 15 ? '#ef4444' : '#1e293b'}; margin-top: 2px;">${kpis.reopenRate}% (${kpis.reopened} tickets)</div>
          </td>
        </tr>
      </table>

      <!-- Channel Distribution -->
      <h2 style="font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; margin: 20px 0 10px 0;">Volume by Inbound Channel</h2>
      <div style="display: flex; flex-wrap: wrap; margin-bottom: 24px;">
        ${channelsHtml}
      </div>

      <!-- Agent Leaderboard -->
      <h2 style="font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; margin: 20px 0 10px 0;">Agent Performance Leaderboard</h2>
      <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 24px; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
        <thead>
          <tr style="background: #f1f5f9; color: #475569; text-align: left;">
            <th style="padding: 10px 12px; font-weight: 700;">Agent</th>
            <th style="padding: 10px 12px; font-weight: 700; text-align: center;">Assigned</th>
            <th style="padding: 10px 12px; font-weight: 700; text-align: center;">Closed</th>
            <th style="padding: 10px 12px; font-weight: 700; text-align: center;">Res. Rate</th>
            <th style="padding: 10px 12px; font-weight: 700; text-align: center;">CSAT</th>
            <th style="padding: 10px 12px; font-weight: 700; text-align: center;">Avg Time</th>
          </tr>
        </thead>
        <tbody>
          ${agentsHtml}
        </tbody>
      </table>

    </div>

    <!-- Footer -->
    <div style="background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 18px 24px; text-align: center; font-size: 12px; color: #94a3b8;">
      Generated automatically by <strong>ubiDesk Ticket Manager</strong> on ${new Date().toUTCString()}.
      <br>Non-deleted tickets only. Data is strictly synchronized from live operations.
    </div>

  </div>
</body>
</html>`
  }
}
