import Database from '@ioc:Adonis/Lucid/Database'
import axios from 'axios'
import MailAccountService from 'App/Services/MailAccountService'
import MailIdentificationService from 'App/Services/MailIdentificationService'
import HtmlSanitizer from 'App/Helper/HtmlSanitizer'
import crypto from 'crypto'
import Application from '@ioc:Adonis/Core/Application'
import Helper from 'App/Helper/helper'
import { uploadBufferToS3 } from 'App/Helper/StorageS3'

const GRAPH = 'https://graph.microsoft.com/v1.0'

/**
 * True if `email` belongs to ANY of our own actively-connected mailboxes —
 * not just whichever mailbox is currently being processed.
 *
 * ROOT CAUSE of the panel still showing a phantom duplicate message even
 * after a reply is correctly addressed to the customer: when a ticket has
 * more than one of our own mailboxes on it (e.g. a second support inbox
 * CC'd on the thread), sending a reply that CCs that second mailbox makes
 * Graph deliver a copy into ITS Inbox too. That second mailbox's own
 * webhook subscription then sees an email from a sender that isn't itself
 * (it's the FIRST mailbox) and — with no way to know that sender is also
 * "us" — files it as a genuine new customer message on the same ticket.
 * One reply, two rows. Checking against every connected mailbox (not only
 * the one currently receiving the notification) closes that gap.
 */
async function isOwnMailbox(email: string): Promise<boolean> {
  const match = await Database.from('mail_accounts')
    .where('is_active', 1)
    .whereRaw('LOWER(email) = ?', [email.toLowerCase()])
    .first()
  return !!match
}

/** Resolves {{customer_name}} / {{customer_name:first|last|full|last_first}} against a full name. */
export function formatCustomerName(fullName: string | null | undefined, variant?: string): string {
  const name = (fullName ?? '').trim()
  if (!name) return 'there'
  const parts = name.split(/\s+/)
  const first = parts[0]
  const last = parts.length > 1 ? parts[parts.length - 1] : ''
  switch (variant) {
    case 'first': return first
    case 'last': return last || first
    case 'last_first': return last ? `${last}, ${first}` : first
    case 'full':
    default: return name
  }
}

export function substituteCustomerName(html: string, fullName: string | null | undefined): string {
  return html.replace(/\{\{customer_name(?::(\w+))?\}\}/g, (_match, variant) => formatCustomerName(fullName, variant))
}

export function substituteTicketTemplate(
  html: string,
  fullName: string | null | undefined,
  ticketUid: string | null | undefined,
  configuredMessage?: string          // NEW
): string {
  const firstName = formatCustomerName(fullName, 'first')
  return substituteCustomerName(html, fullName)
    .split('{{greeting_line}}').join(`Hi ${firstName}!`)
    .split('{{configured_message}}').join(
      configuredMessage ?? 'Thanks for reaching out! We have received your email and automatically logged it into our support system.'
    )
    .split('{{ticket_uid}}').join(ticketUid ?? '')
}

type ExistingAttachment = { file_name: string; size: number; storage_path: string }
type PendingAttachment = { fileName: string; contentType: string; size: number; storagePath: string }

// In-memory, same-process claim set. The DB check inside
// processIncomingMessage() below (`processed_mail_messages`) is a
// select-then-much-later-insert pattern — the actual insert doesn't happen
// until after fetching the message from Graph, resolving attachments,
// creating/appending the ticket message, and sending any auto-ack, which is
// several seconds of async work. If two callers ask for the SAME
// graphMessageId close together (e.g. boot-time catch-up and
// subscription-renewal catch-up both discovering the same message right
// after a restart, since both scan overlapping time windows), both can pass
// the DB check before either has inserted, and both proceed — producing a
// duplicate ticket_messages row. This synchronous set closes that race for
// calls within this process, which is what was actually happening here.
const messagesCurrentlyProcessing = new Set<string>()

interface InFlightOutboundSend {
  ticketId: number
  msgId: number
  expiresAt: number
}
const inFlightOutboundSends = new Map<number, InFlightOutboundSend>()

interface InFlightAutoAck {
  ticketId: number
  systemMsgId?: number
  expiresAt: number
}
const inFlightAutoAcks = new Map<number, InFlightAutoAck>()

export default class EmailToTicketService {
  public static registerInFlightAutoAck(ticketId: number, systemMsgId?: number) {
    inFlightAutoAcks.set(ticketId, {
      ticketId,
      systemMsgId,
      expiresAt: Date.now() + 2 * 60 * 1000,
    })
  }

  public static consumeInFlightAutoAck(ticketId: number): InFlightAutoAck | null {
    const item = inFlightAutoAcks.get(ticketId)
    if (!item) return null
    inFlightAutoAcks.delete(ticketId)
    if (Date.now() > item.expiresAt) return null
    return item
  }

  public static registerInFlightOutboundSend(ticketId: number, msgId: number) {
    inFlightOutboundSends.set(ticketId, {
      ticketId,
      msgId,
      expiresAt: Date.now() + 2 * 60 * 1000,
    })
  }

  public static consumeInFlightOutboundSend(ticketId: number): number | null {
    const item = inFlightOutboundSends.get(ticketId)
    if (!item) return null
    inFlightOutboundSends.delete(ticketId)
    if (Date.now() > item.expiresAt) return null
    return item.msgId
  }

  /**
   * Entry point — called for every Graph "new message" notification
   * (from the live webhook) and every message found during catch-up sync.
   * `mailboxEmail` is the connected inbox that received it.
   * `graphMessageId` is the Graph message id (NOT our own ticket_messages id).
   *
   * Thin wrapper that claims `graphMessageId` in the in-memory lock (see
   * `messagesCurrentlyProcessing` above) before doing any real work, so
   * concurrent callers for the same message within this process can't both
   * proceed. The actual processing lives in `processIncomingMessage()`.
   */
  public static async handleIncomingMessage(mailboxEmail: string, graphMessageId: string) {
    if (messagesCurrentlyProcessing.has(graphMessageId)) {
      console.log(`[EmailToTicketService] skipping graph message ${graphMessageId} for ${mailboxEmail} — already being processed by a concurrent call`)
      return
    }
    messagesCurrentlyProcessing.add(graphMessageId)
    try {
      await this.processIncomingMessage(mailboxEmail, graphMessageId)
    } finally {
      messagesCurrentlyProcessing.delete(graphMessageId)
    }
  }

  /**
   * Entry point for a Sent Items notification — a message the agent sent
   * straight from Outlook (or, harmlessly, one already sent through this
   * panel, which also lands in Sent Items and re-fires this same webhook).
   * Same in-memory locking pattern as handleIncomingMessage, keyed
   * separately (`sent:` prefix) since Inbox and Sent Items graphMessageIds
   * are unrelated but there's no reason to risk sharing a lock namespace.
   */
  public static async handleSentMessage(mailboxEmail: string, graphMessageId: string) {
    const lockKey = `sent:${graphMessageId}`
    if (messagesCurrentlyProcessing.has(lockKey)) {
      console.log(`[EmailToTicketService] skipping sent graph message ${graphMessageId} for ${mailboxEmail} — already being processed by a concurrent call`)
      return
    }
    messagesCurrentlyProcessing.add(lockKey)
    try {
      await this.processSentMessage(mailboxEmail, graphMessageId)
    } finally {
      messagesCurrentlyProcessing.delete(lockKey)
    }
  }

  /**
   * Design decision confirmed for this feature: when a Sent-Items message
   * doesn't match any existing ticket's conversationId, auto-create a new
   * ticket from it — same treatment as a customer's first-contact email,
   * just with sender/recipient reversed.
   */
  private static async processSentMessage(mailboxEmail: string, graphMessageId: string) {
    // Dedup — covers BOTH a reply sent through this panel (see
    // TicketService.addMessage's graph_message_id patch after
    // EmailToTicketService.sendAgentReplyByEmail resolves) and the older
    // reactive backfill in processIncomingMessage (`originalAgentMessage`),
    // which can independently insert the same Graph message if the
    // customer happened to reply before this webhook fired. Either way, if
    // a ticket_messages row already carries this graph_message_id, there's
    // nothing to do.
    const alreadyLogged = await Database.from('ticket_messages').where('graph_message_id', graphMessageId).first()
    if (alreadyLogged) return

    const account = await Database.from('mail_accounts').where('email', mailboxEmail).where('is_active', 1).first()
    if (!account) return

    const token = await MailAccountService.getValidAccessToken(mailboxEmail)
    if (!token) return

    const { data: message } = await axios.get(
      `${GRAPH}/me/messages/${graphMessageId}?$select=id,subject,from,toRecipients,ccRecipients,bccRecipients,sentDateTime,uniqueBody,body,bodyPreview,conversationId,internetMessageId,hasAttachments`,
      { headers: {
          Authorization: `Bearer ${token}`,
          Prefer: 'outlook.body-content-type="html"',
      } }
    )

    // Safety guard — this subscription only ever watches the mailbox's own
    // Sent Items, so `from` should always be the mailbox itself. If it
    // isn't (delegate send, shared-mailbox quirk), bail rather than risk
    // misattributing the message to the wrong ticket direction.
    const fromEmail: string | undefined = message.from?.emailAddress?.address
    if (!fromEmail || fromEmail.toLowerCase() !== mailboxEmail.toLowerCase()) return

    const toEmail: string | undefined = message.toRecipients?.[0]?.emailAddress?.address
    const toName: string = message.toRecipients?.[0]?.emailAddress?.name || toEmail || 'Unknown Recipient'
    if (!toEmail) return

    const bodyHtml: string = message.uniqueBody?.content ?? ''
    const bodyText: string = bodyHtml ? this.htmlToPlainText(bodyHtml) : (message.bodyPreview ?? '')

    const existingTicket = await Database.from('tickets').where('mail_conversation_id', message.conversationId).first()
    console.log(`[EmailToTicketService][processSentMessage][conversationId-match] graphMessageId=${graphMessageId} conversationId=${message.conversationId ?? '(MISSING)'} matchedExistingTicket=${existingTicket ? `#${existingTicket.id} (${existingTicket.ticket_uid})` : 'NONE — will create a new ticket'}`)

    // Only apply connected_at cutoff when auto-creating brand new tickets from old history
    if (!existingTicket && new Date(message.sentDateTime) < new Date(account.connected_at)) return

    const ccPlusToEmails = (): string[] => [
      ...(message.ccRecipients ?? []).map((r: any) => r.emailAddress.address as string),
      ...(message.toRecipients ?? []).map((r: any) => r.emailAddress.address as string),
    ].filter((e) => e.toLowerCase() !== mailboxEmail.toLowerCase())

    if (existingTicket) {
      // 1. Dedup against an automated acknowledgement email sent by the system.
      // When a ticket is created from an incoming email, the system sends an auto-ack reply.
      // Microsoft Graph puts that reply in Sent Items and fires a webhook.
      // We link graph_message_id to the single system note row ("Auto-reply sent: Ticket ...")
      // instead of creating a second "agent" message with the full HTML template!
      const autoAck = this.consumeInFlightAutoAck(existingTicket.id)
      if (autoAck) {
        console.log(`[EmailToTicketService][processSentMessage] linking auto-ack graphMessageId=${graphMessageId} to system message on ticket #${existingTicket.id}`)
        if (autoAck.systemMsgId) {
          await Database.from('ticket_messages').where('id', autoAck.systemMsgId).update({
            graph_message_id: graphMessageId,
            delivery_status: 'sent',
          })
        }
        return
      }

      const recentAutoAckMsg = await Database.from('ticket_messages')
        .where('ticket_id', existingTicket.id)
        .where('sender', 'system')
        .whereNull('graph_message_id')
        .where('created_at', '>=', new Date(Date.now() - 3 * 60 * 1000))
        .orderBy('id', 'desc')
        .first()

      if (recentAutoAckMsg && recentAutoAckMsg.message.includes('Auto-reply sent:')) {
        console.log(`[EmailToTicketService][processSentMessage] linking auto-reply graphMessageId=${graphMessageId} to system message #${recentAutoAckMsg.id} on ticket #${existingTicket.id}`)
        await Database.from('ticket_messages').where('id', recentAutoAckMsg.id).update({
          graph_message_id: graphMessageId,
          delivery_status: 'sent',
        })
        return
      }

      // 2. Dedup against an agent reply sent through this panel.
      // When an agent sends a reply from the panel, TicketService.addMessage inserts
      // the message row before Graph finishes sending. When Graph's Sent Items webhook
      // triggers, we must link graphMessageId to that existing row instead of inserting
      // a phantom duplicate.
      const inFlightMsgId = this.consumeInFlightOutboundSend(existingTicket.id)
      let panelMsg = inFlightMsgId
        ? await Database.from('ticket_messages').where('id', inFlightMsgId).first()
        : null

      if (!panelMsg) {
        panelMsg = await Database.from('ticket_messages')
          .where('ticket_id', existingTicket.id)
          .where('sender', 'agent')
          .whereNull('graph_message_id')
          .where('created_at', '>=', new Date(Date.now() - 3 * 60 * 1000))
          .orderBy('id', 'desc')
          .first()
      }

      if (panelMsg) {
        console.log(`[EmailToTicketService][processSentMessage] linking graphMessageId=${graphMessageId} to existing panel message #${panelMsg.id} on ticket #${existingTicket.id}`)
        await Database.from('ticket_messages').where('id', panelMsg.id).update({
          graph_message_id: graphMessageId,
          delivery_status: 'sent',
          to_recipients: JSON.stringify((message.toRecipients ?? []).map((r: any) => r.emailAddress.address)),
          cc_recipients: JSON.stringify((message.ccRecipients ?? []).map((r: any) => r.emailAddress.address)),
          bcc_recipients: JSON.stringify((message.bccRecipients ?? []).map((r: any) => r.emailAddress.address)),
        })

        await Database.from('tickets').where('id', existingTicket.id).update({
          last_message_at: new Date(message.sentDateTime),
          agent_last_active_at: new Date(),
          updated_at: new Date(),
        })

        await this.upsertCcParticipants(existingTicket.id, ccPlusToEmails()).catch((err: any) =>
          console.error('[EmailToTicketService][processSentMessage] CC upsert failed:', err.message)
        )

        const updated = await Database.from('ticket_messages').where('id', panelMsg.id).first()
        const { io } = await import('../../start/socket')
        io.to(`ticket_${existingTicket.id}`).emit('message_updated', updated)
        return
      }

      // Same undelete-on-new-activity behavior TicketService.addMessage
      // applies to agent sends generally — an Outlook-direct reply on a
      // ticket someone deleted should bring it back too.
      if (existingTicket.deleted_at) {
        await Database.from('tickets').where('id', existingTicket.id).update({ deleted_at: null, status: 'open', updated_at: new Date() })
      }

      const { html: resolvedHtml, attachments: pending } =
        await this.resolveInlineAttachments(token, graphMessageId, existingTicket.id, bodyHtml, message.body?.content)

      const [msgId] = await Database.table('ticket_messages').insert({
        ticket_id: existingTicket.id,
        sender: 'agent',
        type: 'reply',
        message: resolvedHtml || bodyText || '(Original message content could not be retrieved from Outlook.)',
        // Sent straight from Outlook, not through the panel — we know an
        // agent sent it (from == the connected mailbox) but not reliably
        // WHICH agent, so sender_name/agent_id are left null rather than
        // guessing (same convention the originalAgentMessage backfill
        // above already uses).
        sender_name: null,
        sender_email: null,
        to_recipients: JSON.stringify((message.toRecipients ?? []).map((r: any) => r.emailAddress.address)),
        cc_recipients: JSON.stringify((message.ccRecipients ?? []).map((r: any) => r.emailAddress.address)),
        bcc_recipients: JSON.stringify((message.bccRecipients ?? []).map((r: any) => r.emailAddress.address)),
        channel: 'email',
        delivery_status: 'sent',
        graph_message_id: graphMessageId,
        created_at: new Date(message.sentDateTime),
      })
      const attachments = await this.persistPendingAttachments(existingTicket.id, msgId, pending)

      await Database.from('tickets').where('id', existingTicket.id).update({
        last_message_at: new Date(message.sentDateTime),
        agent_last_active_at: new Date(),
        updated_at: new Date(),
      })

      await this.upsertCcParticipants(existingTicket.id, ccPlusToEmails()).catch((err: any) =>
        console.error('[EmailToTicketService][processSentMessage] CC upsert failed:', err.message)
      )

      const saved = await Database.from('ticket_messages').where('id', msgId).first()
      const { io } = await import('../../start/socket')
      io.to(`ticket_${existingTicket.id}`).emit('new_ticket_message', { ...saved, attachments })
      io.emit('ticket_bump', { ticketId: existingTicket.id })
      io.emit('dashboard_stats_stale')
      return
    }

    // No existing ticket for this conversation -> auto-create one, mirroring
    // the first-contact-email path in processIncomingMessage below, with
    // sender/recipient reversed (the agent composed this fresh in Outlook).
    const identification = await MailIdentificationService.identifySender(toEmail).catch((err) => {
      console.error(`[EmailToTicketService][processSentMessage] identification failed for ${toEmail}, proceeding as unidentified:`, err.message)
      return { type: 'unidentified' as const, orgId: null, employeeId: null, logoUrl: null, name: null, orgName: null, supportOwnerId: null }
    })

    let assignedAgent: { id: number; name: string } | null = null
    if ((identification as any).supportOwnerId) {
      const ownerAgent = await Database.from('support_agents')
        .where('support_owner_id', (identification as any).supportOwnerId)
        .where('is_active', 1)
        .first()
      if (ownerAgent) assignedAgent = { id: ownerAgent.id, name: ownerAgent.name }
    }

    const { default: TicketService } = await import('App/Services/TicketService')
    let ticket
    try {
      ticket = await TicketService.createTicket({
        customerName: toName,
        customerEmail: toEmail,
        source: 'email',
        priority: 'medium',
        subject: message.subject || null,
        description: bodyText,
        mailConversationId: message.conversationId,
        mailboxEmail,
        senderIdentification: identification.type,
        senderOrgId: identification.orgId,
        senderOrgName: identification.orgName,
        senderEmployeeId: identification.employeeId,
        senderLogoUrl: identification.logoUrl,
        assignedTo: assignedAgent?.id ?? null,
        assignedAgentName: assignedAgent?.name ?? null,
        toRecipients: (message.toRecipients ?? []).map((r: any) => r.emailAddress.address),
        ccRecipients: (message.ccRecipients ?? []).map((r: any) => r.emailAddress.address),
        bccRecipients: (message.bccRecipients ?? []).map((r: any) => r.emailAddress.address),
        graphMessageId,
      })
    } catch (err: any) {
      console.error(`[EmailToTicketService][processSentMessage] ticket creation failed for ${toEmail}:`, err.message)
      return
    }

    // createTicket() always stores the opening message as sender:'customer'
    // (its normal caller is a customer's inbound email) — fix it up since
    // this one was actually sent BY the mailbox.
    const firstMessage = await Database.from('ticket_messages').where('ticket_id', ticket.id).orderBy('created_at', 'asc').first()
    if (firstMessage) {
      await Database.from('ticket_messages').where('id', firstMessage.id).update({
        sender: 'agent',
        sender_name: null,
        sender_email: null,
        channel: 'email',
        delivery_status: 'sent',
        created_at: new Date(message.sentDateTime),
      })
      if (bodyHtml) {
        const { html: resolvedHtml, attachments: pending } =
          await this.resolveInlineAttachments(token, graphMessageId, ticket.id, bodyHtml, message.body?.content)
        if (resolvedHtml) {
          await Database.from('ticket_messages').where('id', firstMessage.id).update({ message: resolvedHtml })
        }
        await this.persistPendingAttachments(ticket.id, firstMessage.id, pending)
      }
    }

    await this.upsertCcParticipants(ticket.id, ccPlusToEmails()).catch((err: any) =>
      console.error(`[EmailToTicketService][processSentMessage] CC participant upsert failed for ticket ${ticket.id}:`, err.message)
    )

    const { io } = await import('../../start/socket')
    io.emit('tickets_updated')
    io.emit('dashboard_stats_stale')
  }

  // ───────────────────────── Historical reconciliation (one-off / on-demand) ─────────────────────────
  /**
   * Replays the last `days` days of Inbox + Sent Items for every connected
   * mailbox and files in anything not already recorded — silently. Covers
   * two distinct gaps: (1) a whole conversation that never got a ticket at
   * all (subscription was down, or a message was sent directly from
   * Outlook before the Sent Items subscription existed), and (2) a ticket
   * that DOES exist but is missing one or more messages in the middle of
   * its trail (same causes, on a conversation that otherwise got through).
   *
   * Deliberately conservative, per explicit requirement:
   *  - Dedup is solely by graph_message_id already present on a
   *    ticket_messages row — if it's there, this never touches that
   *    message again, so re-running this (including after a partial
   *    failure) is always safe and never duplicates anything.
   *  - NEVER changes ticket status — no reopening closed/resolved
   *    tickets, no un-deleting. A ticket's current state is left exactly
   *    as an agent left it; only its message history is repaired.
   *  - NEVER sends any email — no auto-ack for a backfilled first-contact
   *    message. This is silent history repair, not a live event, so
   *    nothing should go out to a customer as a side effect of running it.
   *  - Processes strictly oldest-first per mailbox so a brand-new
   *    ticket's "first" message is genuinely the earliest one found, and
   *    every inserted message carries its real historical timestamp
   *    instead of "now".
   */
  public static async reconcileMailHistory(days = 10): Promise<{ mailbox: string; ticketsCreated: number; messagesFilled: number; failed: number }[]> {
    const accounts = await Database.from('mail_accounts').where('is_active', 1)
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
    const results: { mailbox: string; ticketsCreated: number; messagesFilled: number; failed: number }[] = []

    for (const account of accounts) {
      const summary = { mailbox: account.email, ticketsCreated: 0, messagesFilled: 0, failed: 0 }
      try {
        const token = await MailAccountService.getValidAccessToken(account.email)
        if (!token) {
          console.error(`[EmailToTicketService][reconcile] no valid token for ${account.email}, skipping`)
          results.push(summary)
          continue
        }

        const [inboxMessages, sentMessages] = await Promise.all([
          this.fetchFolderSince(token, "mailFolders('Inbox')", since, 'receivedDateTime'),
          this.fetchFolderSince(token, "mailFolders('SentItems')", since, 'sentDateTime'),
        ])

        const combined = [
          ...inboxMessages.map((m: any) => ({ ...m, __direction: 'inbound' as const, __at: m.receivedDateTime })),
          ...sentMessages.map((m: any) => ({ ...m, __direction: 'sent' as const, __at: m.sentDateTime })),
        ].sort((a, b) => new Date(a.__at).getTime() - new Date(b.__at).getTime())

        console.log(`[EmailToTicketService][reconcile] ${account.email}: ${inboxMessages.length} inbox + ${sentMessages.length} sent-items message(s) in the last ${days}d — replaying chronologically`)

        for (const msg of combined) {
          try {
            const outcome = await this.reconcileOneMessage(account.email, token, msg, msg.__direction)
            if (outcome === 'ticket_created') summary.ticketsCreated++
            if (outcome === 'message_filled') summary.messagesFilled++
          } catch (err: any) {
            summary.failed++
            console.error(`[EmailToTicketService][reconcile] failed on message ${msg.id} (${msg.__direction}) for ${account.email}:`, err?.response?.data ?? err.message)
          }
        }
      } catch (err: any) {
        console.error(`[EmailToTicketService][reconcile] failed for ${account.email}:`, err?.response?.data ?? err.message)
      }
      results.push(summary)
    }

    if (results.some((r) => r.ticketsCreated || r.messagesFilled)) {
      const { io } = await import('../../start/socket')
      io.emit('tickets_updated')
      io.emit('dashboard_stats_stale')
    }

    console.log(`[EmailToTicketService][reconcile] done:`, results)
    return results
  }

  /** Pages through a Graph folder's messages filtered on `dateField >= since`, following @odata.nextLink until exhausted. */
  private static async fetchFolderSince(token: string, folderPath: string, since: Date, dateField: 'receivedDateTime' | 'sentDateTime') {
    const select = 'id,subject,from,toRecipients,ccRecipients,bccRecipients,receivedDateTime,sentDateTime,uniqueBody,body,bodyPreview,conversationId,internetMessageId,hasAttachments'
    let url: string | null =
      `${GRAPH}/me/${folderPath}/messages?$filter=${dateField} ge ${since.toISOString()}&$select=${select}&$orderby=${dateField} asc&$top=100`
    const all: any[] = []
    while (url) {
      const { data }: any = await axios.get(url, {
        headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' },
      })
      all.push(...(data.value ?? []))
      url = data['@odata.nextLink'] ?? null
    }
    return all
  }

  /**
   * Syncs the complete conversation thread for a ticket from Microsoft Graph API,
   * capturing all past and present exchanges (both customer and agent emails)
   * so agents never have to visit Outlook to check past chats.
   */
  public static async syncFullConversation(ticketId: number): Promise<{
    synced: number
    totalInConversation: number
    alreadyExisting: number
  }> {
    const ticket = await Database.from('tickets').where('id', ticketId).first()
    if (!ticket) {
      throw new Error(`Ticket #${ticketId} not found`)
    }

    if (!ticket.mail_conversation_id) {
      return { synced: 0, totalInConversation: 0, alreadyExisting: 0 }
    }

    const mailboxEmail = ticket.mailbox_email || (await MailAccountService.getDefaultAccount())?.email
    if (!mailboxEmail) {
      throw new Error(`No mailbox email associated with ticket #${ticketId}`)
    }

    const token = await MailAccountService.getValidAccessToken(mailboxEmail)
    if (!token) {
      throw new Error(`Could not obtain valid access token for mailbox ${mailboxEmail}`)
    }

    const select = 'id,subject,from,toRecipients,ccRecipients,bccRecipients,receivedDateTime,sentDateTime,uniqueBody,body,bodyPreview,conversationId,internetMessageId,hasAttachments'
    const conversationId = ticket.mail_conversation_id

    const messageMap = new Map<string, any>()

    // 1. Fetch all messages matching this conversationId across the mailbox
    try {
      let url: string | null =
        `${GRAPH}/me/messages?$filter=conversationId eq '${encodeURIComponent(conversationId)}'&$select=${select}&$orderby=receivedDateTime asc&$top=100`
      while (url) {
        const { data }: any = await axios.get(url, {
          headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' },
        })
        const items = data.value ?? []
        for (const item of items) {
          messageMap.set(item.id, item)
        }
        url = data['@odata.nextLink'] ?? null
      }
    } catch (err: any) {
      console.warn(`[EmailToTicketService][syncFullConversation] /me/messages conversation filter failed or lagged:`, err?.response?.data ?? err.message)
    }

    // 2. Also check recent Inbox & SentItems to guard against substrate search index lag
    try {
      const [recentInbox, recentSent] = await Promise.all([
        axios.get(
          `${GRAPH}/me/mailFolders('Inbox')/messages?$select=${select}&$orderby=receivedDateTime desc&$top=50`,
          { headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' } }
        ).catch(() => ({ data: { value: [] } })),
        axios.get(
          `${GRAPH}/me/mailFolders('SentItems')/messages?$select=${select}&$orderby=sentDateTime desc&$top=50`,
          { headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' } }
        ).catch(() => ({ data: { value: [] } })),
      ])

      const extraItems = [...(recentInbox.data?.value ?? []), ...(recentSent.data?.value ?? [])]
      for (const item of extraItems) {
        if (item.conversationId === conversationId) {
          messageMap.set(item.id, item)
        }
      }
    } catch (err: any) {
      console.warn(`[EmailToTicketService][syncFullConversation] folder fallback check failed:`, err?.response?.data ?? err.message)
    }

    const allMessages = Array.from(messageMap.values())
    allMessages.sort((a, b) => {
      const timeA = new Date(a.sentDateTime || a.receivedDateTime).getTime()
      const timeB = new Date(b.sentDateTime || b.receivedDateTime).getTime()
      return timeA - timeB
    })

    let synced = 0
    let alreadyExisting = 0

    for (const msg of allMessages) {
      const fromAddr = msg.from?.emailAddress?.address || ''
      const isFromUs = fromAddr.toLowerCase() === mailboxEmail.toLowerCase() || (await isOwnMailbox(fromAddr))
      const direction: 'inbound' | 'sent' = isFromUs ? 'sent' : 'inbound'

      try {
        const outcome = await this.reconcileOneMessage(mailboxEmail, token, msg, direction)
        if (outcome === 'message_filled') {
          synced++
        } else if (outcome === 'skipped') {
          alreadyExisting++
        }
      } catch (err: any) {
        console.error(`[EmailToTicketService][syncFullConversation] failed to reconcile message ${msg.id}:`, err?.response?.data ?? err.message)
      }
    }

    if (synced > 0) {
      const { io } = await import('../../start/socket')
      io.to(`ticket_${ticketId}`).emit('ticket_bump', { ticketId })
      io.emit('tickets_updated')
      io.emit('dashboard_stats_stale')
    }

    console.log(`[EmailToTicketService][syncFullConversation] Ticket #${ticketId} sync complete: ${synced} new messages synced, ${alreadyExisting} existing, total ${allMessages.length}`)
    return {
      synced,
      totalInConversation: allMessages.length,
      alreadyExisting,
    }
  }

  // ───────────────────────── Self-healing repair (boot-time / on-reopen) ─────────────────────────
  /**
   * Corrects, in place, whatever a historical bug already got wrong on
   * messages that ARE recorded — as opposed to reconcileMailHistory/
   * syncFullConversation above, which only fill in messages that are
   * missing entirely. Two concrete things this repairs, both caused by
   * bugs now fixed further up this file (so this exists purely to clean up
   * data written before those fixes):
   *
   *  1. Wrong timestamp — a message recorded back when the live inbound
   *     path's Graph query didn't request `sentDateTime` at all, so it
   *     silently fell back to `receivedDateTime` (which can trail the
   *     real send time by hours). Re-fetching the message and comparing
   *     against its true `sentDateTime`/`receivedDateTime` catches this.
   *  2. Signature images filed as standalone attachments — a message
   *     recorded back when the inline-image check only looked at
   *     `uniqueBody`, so a signature block trimmed out of that (but still
   *     present in the full `body`) produced bogus "noname" attachment
   *     rows. Re-checking against the full body and, if a stored
   *     attachment turns out to be genuinely inline after all, removing
   *     its ticket_attachments row (the S3 object itself is left alone —
   *     this is a metadata/classification fix, not a storage cleanup).
   *
   * Deliberately conservative, same guarantees as reconcileMailHistory:
   * never changes ticket status, never sends mail, never touches message
   * content/ordering beyond the two corrections above, and is always safe
   * to re-run (a message that's already correct is simply left untouched).
   */
  public static async repairOpenTicketMessages(): Promise<{ ticketsChecked: number; messagesFixed: number; failed: number }> {
    const tickets = await Database.from('tickets')
      .where('source', 'email')
      .whereNull('deleted_at')
      .whereNotIn('status', ['closed', 'resolved'])
      .whereNotNull('mail_conversation_id')
      .select('id')

    const summary = { ticketsChecked: 0, messagesFixed: 0, failed: 0 }
    for (const t of tickets) {
      try {
        const result = await this.repairTicketMessages(t.id)
        summary.ticketsChecked++
        summary.messagesFixed += result.fixed
      } catch (err: any) {
        summary.failed++
        console.error(`[EmailToTicketService][repair] failed for ticket #${t.id}:`, err?.response?.data ?? err.message)
      }
    }
    console.log(`[EmailToTicketService][repair] boot-time repair done: ${summary.ticketsChecked} open ticket(s) checked, ${summary.messagesFixed} message(s) corrected, ${summary.failed} failed`)
    return summary
  }

  /**
   * Repairs every recorded email message on a single ticket. Called for
   * all open tickets at boot (see repairOpenTicketMessages above) and for
   * one specific ticket whenever it gets reopened (see
   * TicketService.reopenByCustomer), per the requirement that a
   * newly-reopened ticket gets the same check applied at that moment.
   */
  public static async repairTicketMessages(ticketId: number): Promise<{ checked: number; fixed: number }> {
    const ticket = await Database.from('tickets').where('id', ticketId).first()
    if (!ticket || ticket.source !== 'email' || !ticket.mailbox_email) return { checked: 0, fixed: 0 }

    const token = await MailAccountService.getValidAccessToken(ticket.mailbox_email)
    if (!token) {
      console.error(`[EmailToTicketService][repair] no valid token for ${ticket.mailbox_email} — skipping ticket #${ticketId}`)
      return { checked: 0, fixed: 0 }
    }

    const messages = await Database.from('ticket_messages')
      .where('ticket_id', ticketId)
      .where('channel', 'email')
      .whereNotNull('graph_message_id')

    let fixed = 0
    for (const row of messages) {
      try {
        const changed = await this.repairOneMessage(token, ticketId, row)
        if (changed) fixed++
      } catch (err: any) {
        console.error(`[EmailToTicketService][repair] failed for ticket_messages#${row.id} (graph_message_id=${row.graph_message_id}):`, err?.response?.data ?? err.message)
      }
    }
    return { checked: messages.length, fixed }
  }

  /** Re-fetches one message from Graph and corrects its stored timing/attachments if they've drifted. Returns true if anything changed. */
  private static async repairOneMessage(token: string, ticketId: number, row: any): Promise<boolean> {
    const select = 'id,receivedDateTime,sentDateTime,uniqueBody,body,hasAttachments'
    const message = await axios
      .get(`${GRAPH}/me/messages/${row.graph_message_id}?$select=${select}`, {
        headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' },
      })
      .then((r) => r.data)
      .catch((err: any) => {
        // A 404 just means the message has since been deleted/moved out of
        // the mailbox — nothing left to repair against, not a real failure.
        if (err?.response?.status === 404) return null
        throw err
      })
    if (!message) return false

    let changed = false

    // 1. Timing correction.
    const occurredAt = new Date(message.sentDateTime || message.receivedDateTime)
    if (!isNaN(occurredAt.getTime()) && Math.abs(new Date(row.created_at).getTime() - occurredAt.getTime()) > 5000) {
      await Database.from('ticket_messages').where('id', row.id).update({ created_at: occurredAt })
      changed = true
      console.log(`[EmailToTicketService][repair] ticket_messages#${row.id}: corrected created_at (was ${row.created_at}, now ${occurredAt.toISOString()})`)
    }

    // 2. Attachment-classification correction — only worth checking if
    //    this message actually has any standalone attachment rows to
    //    re-examine.
    const storedAttachments = await Database.from('ticket_attachments').where('message_id', row.id)
    if (storedAttachments.length && message.hasAttachments) {
      const uniqueBodyHtml: string = message.uniqueBody?.content || ''
      const fullBodyHtml: string = message.body?.content || ''
      const { data: graphAttachments } = await axios.get(`${GRAPH}/me/messages/${row.graph_message_id}/attachments`, {
        headers: { Authorization: `Bearer ${token}` },
      })

      for (const att of graphAttachments.value ?? []) {
        if (att['@odata.type'] !== '#microsoft.graph.fileAttachment' || att.isInline !== true) continue
        const stored = storedAttachments.find((a: any) => a.file_name === att.name && a.size === att.size)
        if (!stored) continue

        const isGenuinelyInline = this.isReferencedInline(uniqueBodyHtml, att.contentId, att.name, fullBodyHtml)
        if (!isGenuinelyInline) continue

        // This attachment IS genuinely embedded in the mail — it should
        // never have gotten its own downloadable-attachment row. Drop the
        // row (leaving the already-uploaded S3 object in place — this is
        // purely a classification fix) so it stops appearing as a chip.
        await Database.from('ticket_attachments').where('id', stored.id).delete()
        changed = true
        console.log(`[EmailToTicketService][repair] ticket_messages#${row.id}: removed bogus attachment row for genuinely-inline "${att.name}"`)
      }
    }

    return changed
  }

  /**
   * Files a single historical message in if it isn't already recorded.
   * `direction` is which folder it was found in — 'inbound' (Inbox) or
   * 'sent' (Sent Items) — used only to decide sender attribution, since a
   * single unfiltered 10-day window necessarily mixes both.
   */
  private static async reconcileOneMessage(
    mailboxEmail: string,
    token: string,
    message: any,
    direction: 'inbound' | 'sent'
  ): Promise<'ticket_created' | 'message_filled' | 'skipped'> {
    const occurredAt = new Date(message.sentDateTime || message.receivedDateTime)

    const already = await Database.from('ticket_messages').where('graph_message_id', message.id).first()
    if (already) {
      const updates: any = {}
      if (occurredAt && !isNaN(occurredAt.getTime()) && Math.abs(new Date(already.created_at).getTime() - occurredAt.getTime()) > 5000) {
        updates.created_at = occurredAt
      }
      if (!already.channel) {
        updates.channel = 'email'
      }
      if (Object.keys(updates).length > 0) {
        await Database.from('ticket_messages').where('id', already.id).update(updates)
      }
      return 'skipped'
    }

    const conversationId = message.conversationId
    if (!conversationId) return 'skipped'

    const isInbound = direction === 'inbound'
    const fromEmail: string | undefined = message.from?.emailAddress?.address
    if (!fromEmail) return 'skipped'

    // Same conventions the live paths use: an Inbox message from any of our
    // OWN connected mailboxes (not just this one — see isOwnMailbox above)
    // is a CC'd copy of our own send, not customer mail; a Sent Items
    // message NOT from the mailbox shouldn't be possible but is skipped
    // defensively rather than misattributed.
    if (isInbound && (await isOwnMailbox(fromEmail))) return 'skipped'
    if (!isInbound && fromEmail.toLowerCase() !== mailboxEmail.toLowerCase()) return 'skipped'

    const bodyHtml: string = message.uniqueBody?.content ?? ''
    const bodyText: string = bodyHtml ? this.htmlToPlainText(bodyHtml) : (message.bodyPreview ?? '')

    const toRecipientEmails = (message.toRecipients ?? []).map((r: any) => r.emailAddress.address)
    const ccRecipientEmails = (message.ccRecipients ?? []).map((r: any) => r.emailAddress.address)
    const bccRecipientEmails = (message.bccRecipients ?? []).map((r: any) => r.emailAddress.address)
    const ccAndToForParticipants = [...ccRecipientEmails, ...toRecipientEmails].filter(
      (e: string) => e.toLowerCase() !== mailboxEmail.toLowerCase() && e.toLowerCase() !== fromEmail.toLowerCase()
    )

    const existingTicket = await Database.from('tickets').where('mail_conversation_id', conversationId).first()

    if (existingTicket) {
      if (!isInbound) {
        // Dedup for sent items: check if there's an unlinked system auto-reply or agent message on this ticket
        const unlinkedSystemAutoAck = await Database.from('ticket_messages')
          .where('ticket_id', existingTicket.id)
          .where('sender', 'system')
          .whereNull('graph_message_id')
          .where('created_at', '>=', new Date(occurredAt.getTime() - 5 * 60 * 1000))
          .where('created_at', '<=', new Date(occurredAt.getTime() + 5 * 60 * 1000))
          .first()
        if (unlinkedSystemAutoAck && unlinkedSystemAutoAck.message.includes('Auto-reply sent:')) {
          await Database.from('ticket_messages').where('id', unlinkedSystemAutoAck.id).update({
            graph_message_id: message.id,
            delivery_status: 'sent',
          })
          return 'message_filled'
        }

        const unlinkedPanelMsg = await Database.from('ticket_messages')
          .where('ticket_id', existingTicket.id)
          .where('sender', 'agent')
          .whereNull('graph_message_id')
          .where('created_at', '>=', new Date(occurredAt.getTime() - 5 * 60 * 1000))
          .where('created_at', '<=', new Date(occurredAt.getTime() + 5 * 60 * 1000))
          .orderBy('id', 'desc')
          .first()
        if (unlinkedPanelMsg) {
          await Database.from('ticket_messages').where('id', unlinkedPanelMsg.id).update({
            graph_message_id: message.id,
            delivery_status: 'sent',
          })
          return 'message_filled'
        }
      }

      // Gap-fill only — status, deleted_at, assignment etc. are left
      // completely untouched. Only the missing message itself is added.
      const { html: resolvedHtml, attachments: pending } =
        await this.resolveInlineAttachments(token, message.id, existingTicket.id, bodyHtml, message.body?.content)

      const insertRow: any = {
        ticket_id: existingTicket.id,
        sender: isInbound ? 'customer' : 'agent',
        type: 'reply',
        message: resolvedHtml || bodyText || '(Original message content could not be retrieved from Outlook.)',
        // Same convention as the live Sent Items handler / the reactive
        // originalAgentMessage backfill: we know an agent sent it (from ==
        // the connected mailbox) but not reliably WHICH agent, since it
        // came from Outlook directly rather than the panel.
        sender_name: isInbound ? (message.from?.emailAddress?.name || fromEmail) : null,
        sender_email: isInbound ? fromEmail : null,
        to_recipients: JSON.stringify(toRecipientEmails),
        cc_recipients: JSON.stringify(ccRecipientEmails),
        bcc_recipients: JSON.stringify(bccRecipientEmails),
        channel: 'email',
        graph_message_id: message.id,
        created_at: occurredAt,
      }
      if (!isInbound) insertRow.delivery_status = 'sent'
      const [msgId] = await Database.table('ticket_messages').insert(insertRow)
      await this.persistPendingAttachments(existingTicket.id, msgId, pending)

      await Database.table('processed_mail_messages').insert({
        graph_message_id: message.id,
        mailbox_email: mailboxEmail,
        conversation_id: conversationId,
        ticket_id: existingTicket.id,
        processed_at: new Date(),
      }).catch(() => null)

      const saved = await Database.from('ticket_messages').where('id', msgId).first()
      const atts = await Database.from('ticket_attachments').where('message_id', msgId)
      const { io } = await import('../../start/socket')
      io.to(`ticket_${existingTicket.id}`).emit('new_ticket_message', { ...saved, attachments: atts })

      // Only ever push last_message_at FORWARD — a gap-filled older
      // message shouldn't make the ticket look more recently active than
      // it genuinely is, but a gap-filled message that turns out to be the
      // newest thing on the ticket should still be reflected.
      if (!existingTicket.last_message_at || occurredAt > new Date(existingTicket.last_message_at)) {
        await Database.from('tickets').where('id', existingTicket.id).update({ last_message_at: occurredAt })
      }

      await this.upsertCcParticipants(existingTicket.id, ccAndToForParticipants).catch((err: any) =>
        console.error('[EmailToTicketService][reconcile] CC upsert failed:', err.message)
      )

      return 'message_filled'
    }

    // No ticket for this conversation at all -> create one silently. No
    // auto-ack email — this is history, not a live event.
    const customerEmail: string | undefined = isInbound ? fromEmail : message.toRecipients?.[0]?.emailAddress?.address
    const customerName: string = isInbound
      ? (message.from?.emailAddress?.name || fromEmail)
      : (message.toRecipients?.[0]?.emailAddress?.name || customerEmail || 'Unknown Recipient')
    if (!customerEmail) return 'skipped'

    const identification = await MailIdentificationService.identifySender(customerEmail).catch((err) => {
      console.error(`[EmailToTicketService][reconcile] identification failed for ${customerEmail}, proceeding as unidentified:`, err.message)
      return { type: 'unidentified' as const, orgId: null, employeeId: null, logoUrl: null, name: null, orgName: null, supportOwnerId: null }
    })

    let assignedAgent: { id: number; name: string } | null = null
    if ((identification as any).supportOwnerId) {
      const ownerAgent = await Database.from('support_agents')
        .where('support_owner_id', (identification as any).supportOwnerId)
        .where('is_active', 1)
        .first()
      if (ownerAgent) assignedAgent = { id: ownerAgent.id, name: ownerAgent.name }
    }

    const { default: TicketService } = await import('App/Services/TicketService')
    let ticket
    try {
      ticket = await TicketService.createTicket({
        customerName,
        customerEmail,
        source: 'email',
        priority: 'medium',
        subject: message.subject || null,
        description: bodyText,
        mailConversationId: conversationId,
        mailboxEmail,
        senderIdentification: identification.type,
        senderOrgId: identification.orgId,
        senderOrgName: identification.orgName,
        senderEmployeeId: identification.employeeId,
        senderLogoUrl: identification.logoUrl,
        assignedTo: assignedAgent?.id ?? null,
        assignedAgentName: assignedAgent?.name ?? null,
        toRecipients: toRecipientEmails,
        ccRecipients: ccRecipientEmails,
        bccRecipients: bccRecipientEmails,
        graphMessageId: message.id,
      })
    } catch (err: any) {
      console.error(`[EmailToTicketService][reconcile] ticket creation failed for ${customerEmail}:`, err.message)
      return 'skipped'
    }

    // createTicket() dates everything "now" and always assumes the opener
    // was the customer — backdate to when the message actually happened,
    // and fix sender attribution if it was actually the agent.
    await Database.from('tickets').where('id', ticket.id).update({ created_at: occurredAt, last_message_at: occurredAt })
    const firstMessage = await Database.from('ticket_messages').where('ticket_id', ticket.id).orderBy('created_at', 'asc').first()
    if (firstMessage) {
      const patch: any = { created_at: occurredAt }
      if (!isInbound) {
        patch.sender = 'agent'
        patch.sender_name = null
        patch.sender_email = null
        patch.delivery_status = 'sent'
      }
      await Database.from('ticket_messages').where('id', firstMessage.id).update(patch)

      if (bodyHtml) {
        const { html: resolvedHtml, attachments: pending } =
          await this.resolveInlineAttachments(token, message.id, ticket.id, bodyHtml, message.body?.content)
        if (resolvedHtml) {
          await Database.from('ticket_messages').where('id', firstMessage.id).update({ message: resolvedHtml })
        }
        await this.persistPendingAttachments(ticket.id, firstMessage.id, pending)
      }
    }

    await this.upsertCcParticipants(ticket.id, ccAndToForParticipants).catch((err: any) =>
      console.error(`[EmailToTicketService][reconcile] CC participant upsert failed for ticket ${ticket.id}:`, err.message)
    )

    return 'ticket_created'
  }

  private static async processIncomingMessage(mailboxEmail: string, graphMessageId: string) {
    // 1. Dedup — webhook retries / catch-up overlap must be a no-op.
    const already = await Database.from('processed_mail_messages').where('graph_message_id', graphMessageId).first()
    if (already) return

    const account = await Database.from('mail_accounts').where('email', mailboxEmail).where('is_active', 1).first()
    if (!account) return

    const token = await MailAccountService.getValidAccessToken(mailboxEmail)
    if (!token) return

   const { data: message } = await axios.get(
  // BUG FIX: `sentDateTime` was missing from this $select entirely, so
  // `msgDate` below silently fell back to `receivedDateTime` for every
  // live inbound message. Those two can legitimately differ by hours
  // (mail relayed through gateways/forwarding rules, delivery queuing,
  // etc.), which is exactly what produced a ticket-panel timestamp that
  // didn't match what the customer's own Outlook shows for the same
  // email. `body` (the full, untrimmed HTML) is also added — used only
  // as a fallback reference when deciding whether a Graph attachment is
  // genuinely inline (see resolveInlineAttachments), since `uniqueBody`
  // can trim a reply's signature block along with the quoted history it's
  // meant to strip, which was causing signature logos/social icons to be
  // misfiled as regular downloadable attachments.
  `${GRAPH}/me/messages/${graphMessageId}?$select=id,subject,from,receivedDateTime,sentDateTime,uniqueBody,body,bodyPreview,conversationId,internetMessageId,hasAttachments,toRecipients,ccRecipients,bccRecipients`,
      { headers: {
          Authorization: `Bearer ${token}`,
          // HTML (not text) so we keep `cid:` references — needed both to
          // tell a freshly-dropped inline image apart from quoted-history
          // images, and now also to preserve the original formatting/image
          // placement when we store the message.
          Prefer: 'outlook.body-content-type="html"',
      } }
    )
  console.log("this is incoming message",message)
    const fromEmail: string | undefined = message.from?.emailAddress?.address
    const fromName: string = message.from?.emailAddress?.name || fromEmail || 'Unknown Sender'
    if (!fromEmail) return

    // 2. Ignore mail sent BY any of our own connected mailboxes (e.g. our
    //    own auto-reply or another support inbox's send landing back in a
    //    shared/CC'd view). Prevents an infinite loop AND the phantom
    //    duplicate message described above — checked against every active
    //    mailbox, not just this one, since the sender may be a DIFFERENT
    //    mailbox we also monitor.
    if (await isOwnMailbox(fromEmail)) return

    // uniqueBody is HTML (see Prefer header above) and excludes the quoted
    // trail — it's exactly the customer's newly-typed content, formatting
    // and all. bodyText is only a plain-text fallback for the rare case
    // there's no HTML body at all.
    const bodyHtml: string = message.uniqueBody?.content ?? ''
    const bodyText: string = bodyHtml ? this.htmlToPlainText(bodyHtml) : (message.bodyPreview ?? '')

    // 3. Same conversation already has a ticket? -> append, don't create a new ticket.
    const existingTicket = await Database.from('tickets').where('mail_conversation_id', message.conversationId).first()

    // [DIAGNOSTIC] The other end of the conversationId lifecycle
    console.log(`[EmailToTicketService][processIncomingMessage][conversationId-match] graphMessageId=${graphMessageId} incomingConversationId=${message.conversationId ?? '(MISSING)'} matchedExistingTicket=${existingTicket ? `#${existingTicket.id} (${existingTicket.ticket_uid})` : 'NONE — will create a new ticket'}`)

    // 4. For brand-new conversations, do not auto-create tickets from mail older than connected_at
    if (!existingTicket && new Date(message.receivedDateTime) < new Date(account.connected_at)) return

    if (existingTicket) {
      const { default: TicketService } = await import('App/Services/TicketService')

      // If the ticket was closed or resolved, automatically reopen it when customer replies.
      // Routed through reopenByCustomer() (instead of a raw status update) so this reply
      // actually counts toward reopen_count / last_reopened_at / the activity log — the
      // same bookkeeping the feedback-page "Reopen ticket" button and negative-rating flow
      // already get. A raw `update({ status: 'open' })` here reopened the ticket visually
      // but silently left it out of reopen stats/filters.
      if (['closed', 'resolved'].includes(existingTicket.status)) {
        const reopened = await TicketService.reopenByCustomer(existingTicket.id)
        existingTicket.status = reopened?.status ?? 'open'
        existingTicket.reopen_count = reopened?.reopen_count ?? existingTicket.reopen_count
      }

      // Resolve inline/body-embedded images to real files and rewrite the
      // HTML to point at their persisted URLs — this preserves the original
      // mail's structure/formatting/image placement instead of flattening
      // it to plain text with separate attachment chips.
      const { html: resolvedHtml, attachments: pending } =
        await this.resolveInlineAttachments(token, graphMessageId, existingTicket.id, bodyHtml, message.body?.content)

      const msgDate = new Date(message.sentDateTime || message.receivedDateTime || Date.now())
      const saved = await TicketService.addMessage({
        ticketId: existingTicket.id,
        sender: 'customer',
        type: 'reply',
        message: resolvedHtml || bodyText,
        senderName: fromName,
        senderEmail: fromEmail,
        toRecipients: (message.toRecipients ?? []).map((r: any) => r.emailAddress.address),
        ccRecipients: (message.ccRecipients ?? []).map((r: any) => r.emailAddress.address),
        bccRecipients: (message.bccRecipients ?? []).map((r: any) => r.emailAddress.address),
        graphMessageId,
        channel: 'email',
        createdAt: msgDate,
      })

      await Database.from('tickets').where('id', existingTicket.id).update({
        last_message_at: msgDate,
        updated_at: new Date(),
      })

      const attachments = await this.persistPendingAttachments(existingTicket.id, saved.id, pending)

      await Database.table('processed_mail_messages').insert({
        graph_message_id: graphMessageId,
        mailbox_email: mailboxEmail,
        conversation_id: message.conversationId,
        ticket_id: existingTicket.id,
        processed_at: new Date(),
      })

      // Upsert any new CC participants (e.g. someone added mid-thread)
      const allCcEmails: string[] = [
        ...(message.ccRecipients ?? []).map((r: any) => r.emailAddress.address as string),
        ...(message.toRecipients ?? []).map((r: any) => r.emailAddress.address as string),
      ].filter(e => e.toLowerCase() !== mailboxEmail.toLowerCase() && e.toLowerCase() !== fromEmail.toLowerCase())

      await this.upsertCcParticipants(existingTicket.id, allCcEmails).catch(err =>
        console.error('[EmailToTicketService] CC upsert failed:', err.message)
      )

      // Resolve the sender's profile image and emit with the message
      const senderAvatar = await this.resolveSenderAvatar(fromEmail).catch(() => null)

      const { io } = await import('../../start/socket')
      io.to(`ticket_${existingTicket.id}`).emit('new_ticket_message', { ...saved, attachments, sender_avatar_url: senderAvatar })
      io.emit('ticket_bump', { ticketId: existingTicket.id })
      io.emit('dashboard_stats_stale')
      return
    }

    // 5. New conversation -> identify the sender, then raise a new ticket.
    const identification = await MailIdentificationService.identifySender(fromEmail).catch((err) => {
      console.error(`[EmailToTicketService] identification failed for ${fromEmail}, proceeding as unidentified:`, err.message)
      return { type: 'unidentified' as const, orgId: null, employeeId: null, logoUrl: null, name: null, orgName: null, supportOwnerId: null }
    })

    // FIX: catches the case where an agent emailed the customer directly
    // from Outlook (bypassing the panel entirely) and the customer's reply
    // is what we're processing right now. Before this fix, that reply
    // still correctly created a ticket + sent the auto-response (nothing
    // wrong there), but the agent's own opening message — the thing that
    // actually started the conversation — was never fetched from Outlook
    // at all, so it never appeared in the ticket thread, and the ticket's
    // subject was left as "Re: <subject>" (taken from the reply) instead
    // of the true original subject.
    //
    // Look for any OTHER message already in this same Graph conversationId
    // that was sent FROM this mailbox — i.e. the agent's manual opener —
    // and, if one exists, capture it so it can be inserted as the first
    // message in the ticket thread below, and its (un-prefixed) subject
    // used for the ticket instead of the reply's "Re: ..." subject.
    //
    // Queries Sent Items specifically (not the general /me/messages
    // collection) — that's the mailbox's Sent Items folder is exactly
    // where Outlook stores a copy of a manually-composed message by
    // default (saveToSentItems), so it's the reliable place to look,
    // rather than depending on whatever folders the unscoped /me/messages
    // collection happens to cover. Falls back to the unscoped collection
    // only if nothing turns up there (e.g. a custom mail rule moved it, or
    // saveToSentItems was off for that send).
    let originalAgentMessage: {
      graphId: string; subject: string | null; bodyHtml: string; fullBodyHtml?: string
      sentAt: string; toRecipients: string[]
    } | null = null
    let candidateMessages: any[] = []
    try {
      // ROOT CAUSE of "agent's manually-sent opener never shows up": this
      // used to query with `$filter=conversationId eq '...'`. ANY $filter
      // (or $search) on Graph's /messages collection is served off the
      // substrate search index, not the live mailbox — and that index is
      // well documented to lag behind reality, worst right after a message
      // is sent. The customer typically replies within seconds of the
      // agent's manual send, our webhook fires almost immediately, and this
      // lookup was racing the index: it ran before the just-sent Sent Items
      // message had been indexed, so the filter matched zero rows. That's
      // indistinguishable in the logs from "no prior message exists" — it
      // just silently fell through to "treating as a genuine first-contact
      // email" every time, which is exactly the symptom reported (only the
      // client's reply visible, agent's opener missing).
      //
      // Fix: drop $filter entirely. A plain, unfiltered listing (ordered
      // by sentDateTime, most recent first) reads the mailbox directly —
      // no search index involved — so it reflects a message sent seconds
      // ago immediately. We match conversationId ourselves in JS instead
      // of asking Graph to do it. A short retry is kept as cheap insurance
      // in case of genuine (rare) propagation delay on the listing itself;
      // this all runs in async webhook processing, so the extra latency
      // costs nothing user-facing.
      const selectFields = 'id,subject,from,toRecipients,sentDateTime,receivedDateTime,uniqueBody,conversationId'

      // No $filter — matches conversationId client-side against a plain,
      // unfiltered listing (see root-cause note above).
      const fetchConversationFrom = async (path: string) => {
        const { data } = await axios.get(
          `${GRAPH}/me/${path}/messages?$select=${selectFields}&$orderby=sentDateTime desc&$top=50`,
          { headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' } }
        )
        return ((data?.value ?? []) as any[]).filter((m: any) => m.conversationId === message.conversationId)
      }

      const attempts = [0, 1500, 3500] // ms delay before each attempt — gives the (rare) case of listing-level lag room to resolve
      for (const delay of attempts) {
        if (delay) await new Promise((resolve) => setTimeout(resolve, delay))
        candidateMessages = await fetchConversationFrom("mailFolders('SentItems')")
        console.log(`[EmailToTicketService] SentItems conversation lookup for ${message.conversationId} (after ${delay}ms): ${candidateMessages.length} message(s)`)
        if (candidateMessages.length) break
      }

      if (!candidateMessages.length) {
        // Fallback — unscoped collection, in case the original didn't land
        // in Sent Items for some reason (custom rule, shared-mailbox quirk, etc.)
        candidateMessages = await fetchConversationFrom('messages')
        console.log(`[EmailToTicketService] unscoped conversation lookup fallback for ${message.conversationId}: ${candidateMessages.length} message(s)`)
      }

      const priorAgentMessages = candidateMessages
        .filter((m: any) =>
          m.id !== graphMessageId &&
          (m.from?.emailAddress?.address ?? '').toLowerCase() === mailboxEmail.toLowerCase()
        )
        .sort((a: any, b: any) =>
          new Date(a.sentDateTime ?? a.receivedDateTime).getTime() - new Date(b.sentDateTime ?? b.receivedDateTime).getTime()
        )
      const earliest = priorAgentMessages[0]
      if (earliest) {
        // Cheap single-message follow-up fetch (not part of the 50-message
        // listing above, to keep that bulk call light) just to get this one
        // message's full untrimmed `body` — used only as the inline-image
        // fallback reference, same reasoning as everywhere else in this file.
        const fullBodyHtml = await axios
          .get(`${GRAPH}/me/messages/${earliest.id}?$select=body`, { headers: { Authorization: `Bearer ${token}` } })
          .then((r) => r.data?.body?.content as string | undefined)
          .catch(() => undefined)
        originalAgentMessage = {
          graphId: earliest.id,
          subject: earliest.subject ?? null,
          bodyHtml: earliest.uniqueBody?.content ?? '',
          fullBodyHtml,
          sentAt: earliest.sentDateTime ?? earliest.receivedDateTime,
          toRecipients: (earliest.toRecipients ?? []).map((r: any) => r.emailAddress.address),
        }
      } else {
        console.log(`[EmailToTicketService] no prior agent-sent message found in conversation ${message.conversationId} — treating as a genuine first-contact email.`)
      }
    } catch (err: any) {
      console.error(`[EmailToTicketService] lookup for a prior manually-sent agent message failed (non-fatal, proceeding without it):`, err?.response?.data ?? err.message)
    }

    // Auto-assign: this org's Organization.supportowner_id maps to a
    // support_agents row via support_agents.support_owner_id (set at boot —
    // see start/socket.ts). No match (unidentified sender, or an owner id
    // with no matching/active agent yet) just leaves the ticket unassigned.
    let assignedAgent: { id: number; name: string } | null = null
    if ((identification as any).supportOwnerId) {
      const ownerAgent = await Database.from('support_agents')
        .where('support_owner_id', (identification as any).supportOwnerId)
        .where('is_active', 1)
        .first()
      if (ownerAgent) assignedAgent = { id: ownerAgent.id, name: ownerAgent.name }
    }

    const { default: TicketService } = await import('App/Services/TicketService')
    let ticket
    try {
ticket = await TicketService.createTicket({
  customerName: fromName,
  customerEmail: fromEmail,
  source: 'email',
  priority: 'medium',
    // Use the true original subject (from the agent's manually-sent
    // opener) when we found one, instead of this reply's "Re: ..." subject.
    subject: originalAgentMessage?.subject || message.subject || null,
  description: bodyText,
  mailConversationId: message.conversationId,
  mailboxEmail,
  senderIdentification: identification.type,
  senderOrgId: identification.orgId,
  senderOrgName: identification.orgName,
  senderEmployeeId: identification.employeeId,
  senderLogoUrl: identification.logoUrl,
  assignedTo: assignedAgent?.id ?? null,
  assignedAgentName: assignedAgent?.name ?? null,
  toRecipients: (message.toRecipients ?? []).map((r: any) => r.emailAddress.address),
  ccRecipients: (message.ccRecipients ?? []).map((r: any) => r.emailAddress.address),
  bccRecipients: (message.bccRecipients ?? []).map((r: any) => r.emailAddress.address),
  graphMessageId,
})
    } catch (err: any) {
      console.error(`[EmailToTicketService] ticket creation failed for ${fromEmail}:`, err.message)
      return
    }

    const incomingOccurredAt = new Date(message.sentDateTime || message.receivedDateTime || Date.now())

    const firstMessage = await Database.from('ticket_messages')
      .where('ticket_id', ticket.id)
      .orderBy('created_at', 'asc')
      .first()

    if (firstMessage) {
      await Database.from('ticket_messages').where('id', firstMessage.id).update({
        created_at: incomingOccurredAt,
        channel: 'email',
      })
    }
    await Database.from('tickets').where('id', ticket.id).update({
      created_at: incomingOccurredAt,
      last_message_at: incomingOccurredAt,
    })

    // Now that ticket.id exists, resolve inline images/attachments and
    // upgrade the first message from the plain-text placeholder to the
    // original HTML with image srcs pointed at the persisted files.
    if (firstMessage && bodyHtml) {
      const { html: resolvedHtml, attachments: pending } =
        await this.resolveInlineAttachments(token, graphMessageId, ticket.id, bodyHtml, message.body?.content)

      if (resolvedHtml) {
        await Database.from('ticket_messages').where('id', firstMessage.id).update({ message: resolvedHtml })
      }
      await this.persistPendingAttachments(ticket.id, firstMessage.id, pending)
    }

    // Insert the agent's manually-sent opener (found above) as its own
    // message, dated to when it was actually sent — earlier than the
    // customer's reply above — so it sorts to the top of the thread and
    // the agent can see what they originally wrote to the customer.
    if (originalAgentMessage) {
      const { html: resolvedAgentHtml, attachments: agentPending } = originalAgentMessage.bodyHtml
        ? await this.resolveInlineAttachments(token, originalAgentMessage.graphId, ticket.id, originalAgentMessage.bodyHtml, originalAgentMessage.fullBodyHtml)
        : { html: '', attachments: [] as PendingAttachment[] }

      const [agentMsgId] = await Database.table('ticket_messages').insert({
        ticket_id: ticket.id,
        sender: 'agent',
        type: 'reply',
        // We know an agent sent this (from == the connected mailbox) but
        // not reliably WHICH agent, since it went out through Outlook
        // directly rather than the panel — sender_name/agent_id are left
        // null rather than guessing.
        message: resolvedAgentHtml || originalAgentMessage.bodyHtml || '(Original message content could not be retrieved from Outlook.)',
        to_recipients: JSON.stringify(originalAgentMessage.toRecipients),
        cc_recipients: JSON.stringify([]),
        bcc_recipients: JSON.stringify([]),
        channel: 'email',
        delivery_status: 'sent',
        graph_message_id: originalAgentMessage.graphId,
        created_at: new Date(originalAgentMessage.sentAt),
      })
      await this.persistPendingAttachments(ticket.id, agentMsgId, agentPending)
    }

    await Database.table('processed_mail_messages').insert({
      graph_message_id: graphMessageId,
      mailbox_email: mailboxEmail,
      conversation_id: message.conversationId,
      ticket_id: ticket.id,
      processed_at: new Date(),
    })

    // Identify all CC + To recipients and save to ticket_cc_participants
    const newTicketCcEmails: string[] = [
      ...(message.ccRecipients ?? []).map((r: any) => r.emailAddress.address as string),
      ...(message.toRecipients ?? []).map((r: any) => r.emailAddress.address as string),
    ].filter(e => e.toLowerCase() !== mailboxEmail.toLowerCase() && e.toLowerCase() !== fromEmail.toLowerCase())

    await this.upsertCcParticipants(ticket.id, newTicketCcEmails).catch(err =>
      console.error('[EmailToTicketService] CC participant identification failed:', err.message)
    )

    // 6. Auto-acknowledge rule:
    // Avoid sending automated message when chat is picked up in between the conversations.
    // It will ONLY be sent when conversation is freshly started by the customer, NOT by agent.
    const isStartedByAgent = Boolean(originalAgentMessage) || candidateMessages.some((m: any) => {
      const sender = m.from?.emailAddress?.address?.toLowerCase()
      return sender === mailboxEmail.toLowerCase()
    })
    const hasPriorMessages = candidateMessages.some((m: any) => m.id !== graphMessageId)
    const isReplySubject = /^(re|fwd|fw):\s*/i.test((message.subject || '').trim())
    const { io } = await import('../../start/socket')
    const isFreshCustomerConversation = !isStartedByAgent && !hasPriorMessages && !isReplySubject

    if (isFreshCustomerConversation) {
      const savedReply = await TicketService.addMessage({
        ticketId: ticket.id,
        sender: 'system',          // NOT 'agent' — addMessage only forwards email for sender==='agent', so this can't loop
        type: 'reply',
        message: `Auto-reply sent: Ticket ${ticket.ticket_uid} created, customer notified by email.`,
      })
      io.to(`ticket_${ticket.id}`).emit('new_ticket_message', savedReply)

      this.registerInFlightAutoAck(ticket.id, savedReply.id)

      await this.sendAutoAcknowledgement(mailboxEmail, token, graphMessageId, ticket.ticket_uid, identification)
        .catch((err) => console.error(`[EmailToTicketService] auto-ack failed for ticket ${ticket.ticket_uid}:`, err?.response?.data ?? err.message))
    } else {
      console.log(`[EmailToTicketService] Skipping auto-acknowledgement for ticket #${ticket.id} (${ticket.ticket_uid}) — conversation was ongoing or started by agent (isStartedByAgent=${isStartedByAgent}, hasPriorMessages=${hasPriorMessages}, isReplySubject=${isReplySubject})`)
    }

    // Automatically sync the full conversation so all past exchanges in this thread
    // from start to present are immediately captured and in the correct order.
    await this.syncFullConversation(ticket.id).catch((err: any) => {
      console.error(`[EmailToTicketService] initial syncFullConversation failed for ticket #${ticket.id}:`, err?.message)
    })

    io.emit('tickets_updated')
    io.emit('dashboard_stats_stale')
  }

  /**
   * Identify a list of emails via MailIdentificationService and upsert them
   * into ticket_cc_participants (skip any already saved for this ticket).
   */
public static async upsertCcParticipants(ticketId: number, emails: string[]): Promise<void> {
  if (!emails.length) return
  const { default: MailIdentificationService } = await import('App/Services/MailIdentificationService')

  // Find which emails are already saved for this ticket
  const existingRows = await Database.from('ticket_cc_participants')
    .where('ticket_id', ticketId)
    .select('email')

  const existingSet = new Set(existingRows.map((row) => row.email.toLowerCase()))

  const newEmails = emails.filter(e => !existingSet.has(e.toLowerCase()))
  if (!newEmails.length) return

  const identified = await MailIdentificationService.identifyMany(newEmails)
  const rows = identified.map(p => ({
    ticket_id: ticketId,
    email: p.email,
    name: p.name ?? null,
    avatar_url: p.avatarUrl ?? null,
    org_id: p.orgId ?? null,
    employee_id: p.employeeId ?? null,
    created_at: new Date(),
  })) 

  if (rows.length) await Database.table('ticket_cc_participants').insert(rows)
}

  /**
   * Resolve an email to its EmployeeMaster profile image URL.
   * Returns null if not found or ImageName is empty.
   */
  private static async resolveSenderAvatar(email: string): Promise<string | null> {
    const { default: MailIdentificationService } = await import('App/Services/MailIdentificationService')
    const results = await MailIdentificationService.identifyMany([email])
    return results[0]?.avatarUrl ?? null
  }

private static async sendAutoAcknowledgement(
  mailboxEmail: string,
  token: string,
  graphMessageId: string,
  ticketUid: string,
  identification: import('App/Services/MailIdentificationService').SenderIdentification
) {
  const { default: EmailTemplateService } = await import('App/Services/EmailTemplateService')
  const templateHtml = await EmailTemplateService.get('auto_ticket_response')

  const greetingName =
    identification.type === 'employee' && identification.name ? identification.name
    : identification.type === 'organization' && identification.name ? identification.name
    : null

const comment = substituteTicketTemplate(templateHtml, greetingName, ticketUid)
  const { html: commentHtml, attachments } = Helper.extractInlineImages(comment)

  await axios.post(
    `${GRAPH}/me/messages/${graphMessageId}/reply`,
    { message: { body: { contentType: 'HTML', content: commentHtml }, attachments } },
    { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } }
  )
}

  /**
   * Downloads each agent-uploaded attachment (from its public S3
   * storage_path) and shapes it into a Microsoft Graph `fileAttachment`
   * object (base64 `contentBytes`) so it can be dropped straight onto a
   * `message.attachments` array for /reply, /forward, or draft-create calls.
   *
   * Best-effort per file: a single attachment that fails to download (bad
   * URL, S3 hiccup, etc) is logged and skipped rather than failing the
   * whole send — the agent's typed reply should still go out.
   */
  // Made public (was private) so TicketService.sendManualTicketInitialMessage
  // can reuse the exact same Graph attachment-building logic for a brand
  // new ticket's opening message, instead of duplicating it.
  public static async buildGraphFileAttachments(
    // Accepts either the camelCase shape (TicketController.uploadAttachment's
    // response) or the raw ticket_attachments row shape (file_name/
    // mime_type/storage_path) — TicketService.addMessage's `savedAttachments`
    // comes straight out of the DB, so normalize both here rather than
    // making every caller remember to re-map first.
    attachments?: Array<{
      fileName?: string; file_name?: string
      contentType?: string | null; mime_type?: string | null
      size?: number | null
      storagePath?: string; storage_path?: string
    }>
  ): Promise<Array<{ '@odata.type': string; name: string; contentType: string; contentBytes: string }>> {
    if (!attachments?.length) return []

    const results = await Promise.all(
      attachments.map(async (raw) => {
        const fileName = raw.fileName ?? raw.file_name ?? 'attachment'
        const contentType = raw.contentType ?? raw.mime_type ?? 'application/octet-stream'
        const storagePath = raw.storagePath ?? raw.storage_path
        if (!storagePath) {
          console.error(`[EmailToTicketService] attachment "${fileName}" has no storage path — skipping it on this send.`)
          return null
        }
        try {
          const res = await axios.get(storagePath, { responseType: 'arraybuffer', timeout: 20000 })
          const contentBytes = Buffer.from(res.data).toString('base64')
          return {
            '@odata.type': '#microsoft.graph.fileAttachment',
            name: fileName,
            contentType: contentType || 'application/octet-stream',
            contentBytes,
          }
        } catch (err: any) {
          console.error(`[EmailToTicketService] failed to fetch attachment "${fileName}" from ${storagePath} — skipping it on this send:`, err.message)
          return null
        }
      })
    )
    return results.filter((r): r is NonNullable<typeof r> => r !== null)
  }

  /**
   * Called when an AGENT replies to an email-sourced ticket from ubiDesk —
   * sends the reply back out through the original mailbox on the same Graph
   * thread. Hook this from socket.ts's `ticket_message` handler.
   */
/**
 * Finds the most recent message sent FROM this mailbox in a given Graph
 * conversation, by listing Sent Items directly (no $filter — see the
 * root-cause note on the near-identical lookup in processIncomingMessage:
 * Graph's $filter/$search runs against a search index that lags right
 * after a send, so an unfiltered listing matched client-side is what
 * actually reads current state). Returns a shape compatible with a
 * `processed_mail_messages` row (just the one field callers need:
 * `graph_message_id`) so it can stand in for `lastInbound` interchangeably.
 */
private static async findLastSentMessageInConversation(mailboxEmail: string, conversationId: string): Promise<{ graph_message_id: string; internet_message_id?: string } | null> {
  try {
    const token = await MailAccountService.getValidAccessToken(mailboxEmail)
    if (!token) return null
    const { data } = await axios.get(
      `${GRAPH}/me/mailFolders('SentItems')/messages?$select=id,conversationId,sentDateTime,internetMessageId&$orderby=sentDateTime desc&$top=50`,
      { headers: { Authorization: `Bearer ${token}` } }
    )
    const match = ((data?.value ?? []) as any[]).find((m: any) => m.conversationId === conversationId)
    return match ? { graph_message_id: match.id, internet_message_id: match.internetMessageId } : null
  } catch (err: any) {
    console.error(`[EmailToTicketService][findLastSentMessageInConversation] lookup failed for ${mailboxEmail}/${conversationId}:`, err?.response?.data ?? err.message)
    return null
  }
}

/**
 * Post-send lookup for /reply and /forward, which Graph answers with an
 * empty body — unlike the compose-fresh path (MailAccountService.sendMail),
 * there's no id in the response to capture directly. Retries briefly since
 * this runs immediately after the POST and the mailbox listing can very
 * occasionally lag by a second or so.
 *
 * This is what lets the new Sent Items webhook handler
 * (EmailToTicketService.handleSentMessage) recognize "this message was
 * already sent through the panel, don't create a duplicate ticket message"
 * — without a graph_message_id captured here, every panel-sent reply would
 * look identical to a genuine direct-from-Outlook send.
 */
private static async resolveJustSentMessageId(mailboxEmail: string, conversationId: string): Promise<{ graphMessageId?: string; internetMessageId?: string }> {
  for (const delay of [0, 1200, 2500]) {
    if (delay) await new Promise((resolve) => setTimeout(resolve, delay))
    const found = await this.findLastSentMessageInConversation(mailboxEmail, conversationId)
    if (found) return { graphMessageId: found.graph_message_id, internetMessageId: found.internet_message_id }
  }
  console.warn(`[EmailToTicketService][resolveJustSentMessageId] could not resolve a Sent Items id for ${mailboxEmail}/${conversationId} after retries — dedup against a direct-from-Outlook resend of this same message won't be possible for this send.`)
  return {}
}

public static async sendAgentReplyByEmail(
  ticketId: number,
  message: string,
  mode: 'reply' | 'reply_all' | 'reply_selected' | 'forward' = 'reply',
  recipients?: { to?: string[]; cc?: string[]; bcc?: string[] },
  agentId?: number,
  attachments?: Array<{
    fileName?: string; file_name?: string
    contentType?: string | null; mime_type?: string | null
    size?: number | null
    storagePath?: string; storage_path?: string
  }>,
  outboundMessageId?: number
): Promise<{ graphMessageId?: string; internetMessageId?: string }> {
  if (outboundMessageId) {
    this.registerInFlightOutboundSend(ticketId, outboundMessageId)
  }

  const ticket = await Database.from('tickets').where('id', ticketId).first()
  if (!ticket) throw new Error(`Ticket ${ticketId} not found`)

  // Resolved once up front — reused by every send path below (fresh
  // compose, reply, reply_all, reply_selected, forward) so an attachment
  // goes out no matter which branch this particular reply takes.
  const graphAttachments = await this.buildGraphFileAttachments(attachments)

  // Fetch agent's personal footer/signature from DB and append to message.
  // Falls back to the org-wide `agent_footer_default` template (Settings >
  // Messaging > Message Footer) when the acting agent hasn't configured a
  // personal one yet, so a reply is never sent with no footer at all.
  let signatureHtml = ''
  if (!agentId) {
    console.warn(`[EmailToTicketService] sendAgentReplyByEmail called without an agentId for ticket ${ticketId} — footer will fall back to the org default.`)
  } else {
    const agent = await Database.from('support_agents').select('signature_html', 'name').where('id', agentId).first()
    if (agent?.signature_html?.trim()) {
      signatureHtml = agent.signature_html.trim().split('{{agent_name}}').join(agent.name ?? '')
    }
  }
  if (!signatureHtml) {
    const { default: EmailTemplateService } = await import('App/Services/EmailTemplateService')
    const defaultFooter = await EmailTemplateService.get('agent_footer_default')
    if (defaultFooter?.trim()) signatureHtml = defaultFooter.trim()
  }

  // Build the HTML comment: typed message body + optional signature footer
  const isHtmlMessage = /<[a-z][\s\S]*>/i.test(message)
  const messageBody = isHtmlMessage
    ? message
    : `<p style="margin:0 0 12px 0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:14px;line-height:1.6;color:#1e293b;">${Helper.linkifyMarkdown(message).replace(/\n/g, '<br/>')}</p>`
  const comment = signatureHtml
    ? `${messageBody}<div style="margin-top:16px;border-top:1px solid #e2e8f0;padding-top:12px;">${signatureHtml}</div>`
    : messageBody

  // No existing Graph thread to reply into (e.g. a WhatsApp-origin ticket) —
  // compose a fresh email to the customer instead, same mechanism as the
  // auto-ack email in WhatsappService.sendAutoEmail.
  if (!ticket.mailbox_email || !ticket.mail_conversation_id) {
    if (!ticket.customer_email) {
      throw new Error(`Cannot send email reply for ticket ${ticketId}: no mail thread and no customer_email on record.`)
    }
    const sendResult = await MailAccountService.sendMail({
      toEmail: ticket.customer_email,
      subject: `Re: Your support ticket ${ticket.ticket_uid}`,
      html: comment,
      // ROOT CAUSE of "cc person never got the mail": this compose-fresh
      // path used to ignore recipients?.cc/bcc entirely — only the
      // Graph /reply branches further down handled CC/BCC, so any send
      // that fell into "compose fresh" (see the next fix below — that
      // happens far more than it should) silently dropped the CC.
      ccEmails: recipients?.cc,
      bccEmails: recipients?.bcc,
      attachments: graphAttachments,
    })
    return { graphMessageId: sendResult.messageId as string, internetMessageId: sendResult.internetMessageId }
  }

  const lastInbound = await Database.from('processed_mail_messages')
    .where('conversation_id', ticket.mail_conversation_id)
    .orderBy('processed_at', 'desc')
    .first()

  // ROOT CAUSE of "same ticket generating a new message trail on the
  // client side" (and the customer's reply to it landing on a BRAND NEW
  // ticket instead of this one): this used to treat "no inbound message
  // recorded yet" as equivalent to "no thread exists at all" and fall
  // through to composing an entirely fresh email — different subject, no
  // References/In-Reply-To headers, and Graph therefore assigns it a
  // completely new conversationId that's never persisted back onto the
  // ticket. That's exactly what happens whenever an agent sends a second
  // message before the customer has replied to the first one.
  //
  // Fix: before giving up, look for the actual last message already in
  // THIS conversation, sent from this mailbox (i.e. something we already
  // sent — likely the ticket's opening message) via Sent Items, and Graph
  // /reply into that instead. That keeps the same conversationId and
  // proper thread headers, so the client shows one thread and the
  // ticket's mail_conversation_id stays valid for matching later replies.
  // Only if nothing turns up there do we fall back to composing fresh.
  let threadAnchor = lastInbound
  if (!threadAnchor) {
    threadAnchor = await this.findLastSentMessageInConversation(ticket.mailbox_email, ticket.mail_conversation_id)
    if (threadAnchor) {
      console.log(`[EmailToTicketService][sendAgentReplyByEmail] ticket=${ticket.ticket_uid} no inbound message yet — replying into last Sent Items message ${threadAnchor.graph_message_id} to preserve the thread instead of composing fresh`)
    }
  }

  // No inbound message on this thread yet, AND nothing sent from this
  // mailbox in this conversation either (genuinely nothing to reply to) —
  // compose fresh as a last resort.
  if (!threadAnchor) {
    const sendResult = await MailAccountService.sendMail({
      toEmail: ticket.customer_email,
      subject: `Re: Your support ticket ${ticket.ticket_uid}`,
      html: comment,
      ccEmails: recipients?.cc,
      bccEmails: recipients?.bcc,
      attachments: graphAttachments,
    })
    return { graphMessageId: sendResult.messageId as string, internetMessageId: sendResult.internetMessageId }
  }
  const lastInboundOrAnchor = threadAnchor

  const token = await MailAccountService.getValidAccessToken(ticket.mailbox_email)
  if (!token) return {}

  const toEmailAddress = (addr: string) => ({ emailAddress: { address: addr } })
  const uniqueEmails = (emails: Array<string | null | undefined>) => {
    const seen = new Set<string>()
    return emails
      .map((email) => (email ?? '').trim())
      .filter((email) => {
        if (!email) return false
        const key = email.toLowerCase()
        if (seen.has(key)) return false
        seen.add(key)
        return true
      })
  }

  if (mode === 'forward') {
    // timeout added — same reasoning as the reply/reply_all/reply_selected
    // call below and WhatsappOutboundService.sendText: an unbounded Graph
    // call here is what let a slow-but-successful send masquerade as a
    // failure once TicketService.addMessage stopped blocking the socket
    // ack on it.
    const forwardBody: any = { comment, toRecipients: (recipients?.to ?? []).map(toEmailAddress) }
    // Graph's /forward action already carries over the ORIGINAL message's
    // attachments automatically — this only needs to add any NEW files the
    // agent attached to this particular forward.
    if (graphAttachments.length) forwardBody.message = { attachments: graphAttachments }
    await axios.post(
      `${GRAPH}/me/messages/${lastInboundOrAnchor.graph_message_id}/forward`,
      forwardBody,
      { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, timeout: 15000 }
    )
    return await this.resolveJustSentMessageId(ticket.mailbox_email, ticket.mail_conversation_id)
  }

  const endpoint = 'reply'
  const body: any = { comment }

  if (mode === 'reply_all') {
    const ccParticipants = await Database.from('ticket_cc_participants').where('ticket_id', ticketId)
    const mailbox = (ticket.mailbox_email ?? '').toLowerCase()
    const customer = ticket.customer_email ?? null
    const customerKey = (customer ?? '').toLowerCase()
    const explicitTo = uniqueEmails([customer])
    const explicitCc = uniqueEmails([
      ...(recipients?.to ?? []),
      ...(recipients?.cc ?? []),
      ...ccParticipants.map((p: any) => p.email),
    ]).filter((email) => {
      const key = email.toLowerCase()
      return key !== mailbox && key !== customerKey
    })

    body.message = {
      toRecipients: explicitTo.map(toEmailAddress),
      ccRecipients: explicitCc.map(toEmailAddress),
    }
  }

  // reply_selected restricts recipients explicitly.
  if (mode === 'reply_selected') {
    body.message = {
      toRecipients: (recipients?.to ?? []).map(toEmailAddress),
      ccRecipients: (recipients?.cc ?? []).map(toEmailAddress),
    }
  }

  // plain reply: ALWAYS set toRecipients explicitly — never rely on
  // Graph's default for POST /reply.
  //
  // ROOT CAUSE of "reply from the panel goes to Outlook mail itself" (and,
  // as a direct knock-on effect, "panel shows 2 messages for 1 send"):
  // this used to leave `message.toRecipients` unset here, so Graph fell
  // back to its default — addressing the reply to the SENDER of whatever
  // message we're replying into (`lastInboundOrAnchor`). That's harmless
  // when the anchor is a genuine customer email (sender = customer). But
  // on a ticket with no customer reply yet — e.g. the opening message was
  // sent straight from Outlook instead of through this panel, or the
  // agent has already sent one or more panel replies with nothing back
  // from the customer yet — `threadAnchor` falls back to the last message
  // THIS MAILBOX itself sent (see `findLastSentMessageInConversation`
  // above), whose sender is the mailbox. A plain reply into that anchor
  // therefore silently addressed itself back to the mailbox instead of
  // the customer.
  //
  // Worse, that self-addressed send is what produced the phantom second
  // message: if the reply's CC list included another connected/monitored
  // mailbox, THAT mailbox's own inbox subscription saw a brand-new email
  // from a different sender (this mailbox) on the same conversationId,
  // and processIncomingMessage filed it as a second, separate "customer"
  // message on the same ticket — even though only one reply was actually
  // sent. Always setting toRecipients here (falling back to the ticket's
  // on-file customer_email) removes the self-address entirely, which
  // removes both symptoms at once.
  if (mode === 'reply') {
    const to = recipients?.to?.length ? recipients.to : [ticket.customer_email]
    const cc = recipients?.cc ?? []
    const bcc = recipients?.bcc ?? []
    body.message = { ...(body.message ?? {}), toRecipients: uniqueEmails(to).map(toEmailAddress) }
    if (cc.length) body.message.ccRecipients = cc.map(toEmailAddress)
    if (bcc.length) body.message.bccRecipients = bcc.map(toEmailAddress)
  }

  // BCC for reply_all and reply_selected — Graph doesn't carry BCC over
  // automatically, so we must always set it explicitly when the agent added any.
  if ((mode === 'reply_all' || mode === 'reply_selected') && (recipients?.bcc ?? []).length) {
    body.message = { ...(body.message ?? {}), bccRecipients: (recipients!.bcc!).map(toEmailAddress) }
  }

  // Attach any agent-uploaded files. `/reply` accepts a partial `message`
  // resource alongside `comment` — merge onto whatever `body.message` the
  // recipient-scoping above already built (plain `reply` mode has none yet).
  if (graphAttachments.length) {
    body.message = { ...(body.message ?? {}), attachments: graphAttachments }
  }

  await axios.post(
    `${GRAPH}/me/messages/${lastInboundOrAnchor.graph_message_id}/${endpoint}`,
    body,
    { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, timeout: 15000 }
  )
  return await this.resolveJustSentMessageId(ticket.mailbox_email, ticket.mail_conversation_id)
}

  /**
   * Plain-text fallback only — used when a message has no HTML uniqueBody at
   * all. The normal path now preserves HTML (see resolveInlineAttachments),
   * so this no longer runs for the common case.
   */
  private static htmlToPlainText(html: string): string {
    if (!html) return ''
    return html
      .replace(/<img[^>]*>/gi, '')
      .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi, '')
      .replace(/<(br|\/p|\/div|\/tr)\s*\/?>/gi, '\n')
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\n{3,}/g, '\n\n')
      .replace(/[ \t]{2,}/g, ' ')
      .trim()
  }

  /**
   * True if `contentId` is actually referenced (via `cid:...`) inside the
   * given HTML. Used to tell a genuinely-new inline image apart from an old
   * one that the mail client is just re-embedding as part of the quoted
   * thread. Normalizes both sides (strip angle brackets, lowercase) since
   * different mail clients/relays format Content-IDs slightly differently.
   */
  /**
   * Sends the ticket-closure email using the admin-configured DB template.
   * Called once, from TicketService.updateStatus, when the agent has
   * explicitly opted in via the "send closure email" checkbox on that
   * specific ticket — this is the ONLY place a closure email gets sent.
   */
public static async sendTicketClosureEmail(ticketId: number) {
    const logPrefix = `[TicketClosureEmail][Ticket ID: ${ticketId}]`
    console.log(`${logPrefix} Function initiated.`)

    try {
      // 1. Fetch ticket from Database
      const ticket = await Database.from('tickets').where('id', ticketId).first()

      if (!ticket) {
        console.warn(`${logPrefix} Aborted: Ticket not found in database.`)
        return
      }

      if (ticket.source !== 'email') {
        console.info(`${logPrefix} Aborted: Ticket source is '${ticket.source}', expected 'email'.`)
        return
      }

      if (!ticket.mailbox_email) {
        console.warn(`${logPrefix} Aborted: Missing mailbox_email on ticket.`)
        return
      }

      if (!ticket.mail_conversation_id) {
        console.warn(`${logPrefix} Aborted: Missing mail_conversation_id on ticket.`)
        return
      }

      console.log(`${logPrefix} Valid ticket found. Mailbox: ${ticket.mailbox_email}, Conversation ID: ${ticket.mail_conversation_id}`)

      // 2. Fetch last inbound message
      const lastInbound = await Database.from('processed_mail_messages')
        .where('conversation_id', ticket.mail_conversation_id)
        .orderBy('processed_at', 'desc')
        .first()

      if (!lastInbound) {
        console.warn(`${logPrefix} Aborted: No processed inbound mail messages found for conversation_id: ${ticket.mail_conversation_id}`)
        return
      }

      console.log(`${logPrefix} Found last inbound message. Graph Message ID: ${lastInbound.graph_message_id}`)

      // 3. Obtain access token
      console.log(`${logPrefix} Requesting access token for ${ticket.mailbox_email}...`)
      const token = await MailAccountService.getValidAccessToken(ticket.mailbox_email)

      if (!token) {
        console.error(`${logPrefix} Aborted: Failed to retrieve a valid access token for ${ticket.mailbox_email}`)
        return
      }

      // 4. Load email template
      console.log(`${logPrefix} Loading email template 'ticket_closure'...`)
      const { default: EmailTemplateService } = await import('App/Services/EmailTemplateService')
      const templateHtml = await EmailTemplateService.get('ticket_closure')

      if (!templateHtml || !templateHtml.trim()) {
        console.error(`${logPrefix} Aborted: Email template 'ticket_closure' is empty or missing.`)
        return
      }

      // 5. Build feedback links and substitute variables
      let comment = substituteTicketTemplate(templateHtml, ticket.customer_name, ticket.ticket_uid ?? '')

      console.log(`${logPrefix} Generating feedback links...`)
      const { default: TicketFeedbackService } = await import('App/Services/TicketFeedbackService')
      const links = await TicketFeedbackService.buildFeedbackLinks(ticket.id)

      comment = comment
        .split('{{reopen_url}}').join(links.reopenUrl)
        .split('{{rating_url_1}}').join(links.rating1)
        .split('{{rating_url_2}}').join(links.rating2)
        .split('{{rating_url_3}}').join(links.rating3)
        .split('{{rating_url_4}}').join(links.rating4)
        .split('{{rating_url_5}}').join(links.rating5)

      // 6. Extract inline images & attachments
      const { html: commentHtml, attachments } = Helper.extractInlineImages(comment)
      console.log(`${logPrefix} Prepared body content (${commentHtml.length} chars) with ${attachments?.length || 0} attachment(s).`)

      // 7. Dispatch reply via Graph API
      const endpoint = `${GRAPH}/me/messages/${lastInbound.graph_message_id}/reply`
      console.log(`${logPrefix} Sending reply via Graph API to message ${lastInbound.graph_message_id}...`)

      await axios.post(
        endpoint,
        { message: { body: { contentType: 'HTML', content: commentHtml }, attachments } },
        { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } }
      )

      console.log(`${logPrefix} Successfully sent ticket closure email!`)

    } catch (error: any) {
      console.error(`${logPrefix} Error occurred while sending closure email:`, {
        message: error?.message,
        status: error?.response?.status,
        responseData: error?.response?.data,
        stack: error?.stack,
      })
    }
  }

  /**
   * `html` is normally `uniqueBody` (the trimmed, "just what the customer
   * typed" content). `fallbackHtml`, when given, is the message's full,
   * untrimmed `body` — checked only if `html` doesn't already contain the
   * reference. This matters because Outlook's uniqueBody heuristic doesn't
   * only strip quoted history: on some replies it also trims the sender's
   * own trailing signature block (logo/social-icon images and all) along
   * with it. Graph's `/attachments` endpoint still returns those images
   * (they're real MIME parts of the full message either way), so without
   * this fallback they'd fail the "is it actually referenced anywhere"
   * check and get misfiled as standalone downloadable attachments — which
   * is exactly what happened to a signature's logo + 3 social icons
   * showing up as 4 unwanted attachment chips even though Outlook itself
   * never displays them as attachments.
   */
  private static isReferencedInline(html: string, contentId?: string, fileName?: string, fallbackHtml?: string): boolean {
    const check = (body: string): boolean => {
      if (!body) return false
      if (contentId) {
        const cid = contentId.replace(/[<>]/g, '').toLowerCase()
        if (body.toLowerCase().includes(`cid:${cid}`) || body.toLowerCase().includes(cid)) return true
      }
      if (fileName && body.toLowerCase().includes(fileName.toLowerCase())) return true
      return false
    }
    return check(html) || check(fallbackHtml || '')
  }

  /**
   * Baseline HTML sanitizer for customer-supplied mail content. Strips
   * script/iframe/object/embed/link/meta tags, inline event-handler
   * attributes, and javascript: URLs.
   *
   * This is a best-effort regex pass, not a full parser — for production use
   * swap in a proper library (e.g. `sanitize-html` or DOMPurify server-side)
   * for robust coverage. Whichever you use, ALSO render this HTML inside a
   * sandboxed iframe on the frontend (e.g. <iframe sandbox="allow-same-origin">
   * with no "allow-scripts") as defense-in-depth — you're now displaying raw
   * HTML from an untrusted, external source (the customer's mail client),
   * so backend sanitization alone shouldn't be the only safeguard.
   */
  private static sanitizeHtml(html: string): string {
    return HtmlSanitizer.sanitize(html)
  }

  /**
   * Resolves every inline/body-embedded image in `uniqueBodyHtml` to a real,
   * hosted file — swapping `cid:...` and `data:...;base64,...` sources for
   * the persisted URL, IN PLACE, so the returned HTML keeps the customer's
   * original formatting and image placement exactly as sent.
   *
   * Writes attachment files to disk immediately (needed to build the URLs
   * for the rewrite), but returns them as `pending` records rather than
   * inserting them into ticket_attachments — the caller doesn't have a
   * ticket_messages row (and therefore a message_id to attach them to) yet
   * at this point. Call persistPendingAttachments() once the message is saved.
   *
   * Dedupes against attachments already stored for the ticket (by
   * file_name + size) and reuses their existing storage_path instead of
   * writing a duplicate file — this is also what stops Outlook/Gmail
   * re-embedding an earlier message's inline image on every subsequent
   * reply from generating a fresh copy each time.
   */
  private static async resolveInlineAttachments(
    token: string,
    graphMessageId: string,
    ticketId: number,
    uniqueBodyHtml: string,
    fullBodyHtml?: string
  ): Promise<{ html: string; attachments: PendingAttachment[] }> {
    if (!uniqueBodyHtml) return { html: '', attachments: [] }

    const existing: ExistingAttachment[] = await Database.from('ticket_attachments')
      .where('ticket_id', ticketId)
      .select('file_name', 'size', 'storage_path')

    const findExisting = (name: string, size: number) =>
      existing.find((e) => e.file_name === name && e.size === size)

    const pending: PendingAttachment[] = []
    let html = uniqueBodyHtml

    const writeFile = async (fileName: string, buffer: Buffer, contentType?: string) => {
      const safeName = `${Date.now()}_${fileName}`.replace(/[^a-zA-Z0-9._-]/g, '_')
      const key = `ticket-attachments/${ticketId}/${safeName}`
      // relPath is now a full S3 URL (not a local-disk-relative path) — it's
      // stored as-is in ticket_attachments.storage_path and used as-is when
      // rewriting inline <img> src values below.
      return uploadBufferToS3(key, buffer, contentType)
    }

    // 1. Real Graph-side attachments (explicit files + inline images that
    //    became an actual MIME part). Always fetched — message.hasAttachments
    //    has been observed to report false even when one genuinely exists
    //    (e.g. mail relayed through Gmail's SMTP gateway).
    const { data } = await axios.get(`${GRAPH}/me/messages/${graphMessageId}/attachments`, {
      headers: { Authorization: `Bearer ${token}` },
    })

    // DIAGNOSTIC: log exactly what Graph returned before any filtering —
    // when an attachment goes missing from a ticket, this is the first
    // thing to check (was it in Graph's response at all, and how was it
    // flagged?).
    console.log(
      `[EmailToTicketService][resolveInlineAttachments] Graph returned ${(data.value ?? []).length} attachment(s) for message ${graphMessageId}:`,
      (data.value ?? []).map((a: any) => ({ name: a.name, type: a['@odata.type'], isInline: a.isInline, contentId: a.contentId, size: a.size }))
    )

    for (const att of data.value ?? []) {
      if (att['@odata.type'] !== '#microsoft.graph.fileAttachment') continue

      // BUG FIX: Gmail-originated mail relayed through Graph sometimes flags
      // a perfectly ordinary, standalone file attachment as isInline: true
      // even though nothing in the HTML body actually references it by cid
      // or name (observed: a real image AND a .sql file both came back
      // isInline=true with no matching cid in the body, and both silently
      // vanished — the old code did `continue` here, dropping the
      // attachment entirely with no record of it anywhere).
      //
      // Only treat an attachment as "genuinely inline" (rewrite its src into
      // the HTML, skip giving it its own ticket_attachments row) when we can
      // actually find a cid/name match in the body. If Graph says isInline
      // but nothing in the body points at it, fall back to treating it as a
      // normal downloadable attachment instead of discarding it.
      const claimsInline = att.isInline === true
      const isGenuinelyInline = claimsInline && this.isReferencedInline(html, att.contentId, att.name, fullBodyHtml)
      if (claimsInline && !isGenuinelyInline) {
        console.warn(
          `[EmailToTicketService][resolveInlineAttachments] attachment "${att.name}" (contentId=${att.contentId}) is flagged isInline=true by Graph but isn't referenced anywhere in the message body — treating it as a regular attachment instead of dropping it. ticket=${ticketId} message=${graphMessageId}`
        )
      }

      const originalName = att.name || att.contentId || `inline_image_${Date.now()}.png`
      const dupe = findExisting(originalName, att.size)
      const relPath = dupe ? dupe.storage_path : await writeFile(originalName, Buffer.from(att.contentBytes, 'base64'), att.contentType)

      // relPath is a full S3 URL now, so it's used as-is (no more `/uploads/` prefix).
      if (isGenuinelyInline) {
        if (att.contentId) {
          const cid = att.contentId.replace(/[<>]/g, '')
          html = html.replace(new RegExp(`cid:${this.escapeRegex(cid)}`, 'gi'), relPath)
          html = html.replace(new RegExp(`src=["']${this.escapeRegex(cid)}["']`, 'gi'), `src="${relPath}"`)
        }
        if (att.name) {
          html = html.replace(new RegExp(`src=["']${this.escapeRegex(att.name)}["']`, 'gi'), `src="${relPath}"`)
        }
      }

      // CHANGED: an inline image that just got embedded into the HTML above
      // must NOT also become a separate ticket_attachments row — that's what
      // was causing it to render twice (inline + attachment chip).
      if (!dupe && !isGenuinelyInline) {
        pending.push({ fileName: originalName, contentType: att.contentType, size: att.size, storagePath: relPath })
        existing.push({ file_name: originalName, size: att.size, storage_path: relPath })
      } else if (!dupe && isGenuinelyInline) {
        existing.push({ file_name: originalName, size: att.size, storage_path: relPath }) // still dedupe-track it, just don't attach it
      }
    }

    // 2. Images embedded directly as base64 data URIs (some clients embed a
    //    dropped-in image this way instead of as a real MIME part — no
    //    hasAttachments flag or Graph attachment entry for these at all).
    //    Named by content hash so a genuinely repeated image reuses the same
    //    file instead of writing (and referencing) a fresh copy.
    let match: RegExpMatchArray | null
    while ((match = html.match(/data:([a-zA-Z0-9.+-]+\/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=]+)/))) {
      const [fullMatch, mimeType, base64Data] = match
      const buffer = Buffer.from(base64Data, 'base64')
      const hash = crypto.createHash('md5').update(buffer).digest('hex').slice(0, 12)
      const ext = mimeType.split('/')[1]?.replace(/[^a-z0-9]/gi, '') || 'png'
      const fileName = `pasted-image-${hash}.${ext}`

      const dupe = findExisting(fileName, buffer.length)
      const relPath = dupe ? dupe.storage_path : await writeFile(fileName, buffer, mimeType)
      html = html.split(fullMatch).join(relPath)

      if (!dupe) {
        pending.push({ fileName, contentType: mimeType, size: buffer.length, storagePath: relPath })
        existing.push({ file_name: fileName, size: buffer.length, storage_path: relPath })
      }
    }
const beforeCidCleanup = html
html = html.replace(/<img[^>]+src=["']cid:[^"']*["'][^>]*>/gi, '') 
if (html !== beforeCidCleanup) {
  // This only fires now for a cid: reference that had NO matching attachment
  // at all in Graph's response (a genuine orphan) — not for the
  // isInline-mismatch case above, which is now recovered as a regular
  // attachment instead of reaching here. Still worth a loud log: the image
  // is being removed from the message body with no fallback.
  console.warn(`[EmailToTicketService][resolveInlineAttachments] removed an <img> tag whose cid: reference had no matching Graph attachment at all — image lost from message body. ticket=${ticketId} message=${graphMessageId}`)
}

return { html: this.sanitizeHtml(html), attachments: pending }
  }

  /** Inserts the attachment records collected by resolveInlineAttachments now that a ticket_messages row (and its id) exists. */
  private static async persistPendingAttachments(ticketId: number, ticketMessageId: number, pending: PendingAttachment[]) {
    for (const p of pending) {
      try {
        await Database.table('ticket_attachments').insert({
          ticket_id: ticketId,
          message_id: ticketMessageId,
          file_name: p.fileName,
          content_type: p.contentType,
          size: p.size,
          storage_path: p.storagePath,
          created_at: new Date(),
        })
      } catch (err: any) {
        // BUG FIX: this loop previously had no try/catch — one attachment
        // failing to insert (bad data, constraint violation, etc.) threw
        // and silently skipped every attachment after it in the same
        // message with no log at all. Now each attachment is independent.
        console.error(`[EmailToTicketService][persistPendingAttachments] insert failed for "${p.fileName}" on ticket=${ticketId} message=${ticketMessageId}:`, err.message)
      }
    }
    return Database.from('ticket_attachments').where('message_id', ticketMessageId)
  }

  /** Content-IDs often contain regex metacharacters (+, ., (, ) etc.) — without
 * escaping them, new RegExp(`cid:${cid}`) can silently fail to match, leaving
 * the inline image's src as an unloadable `cid:` URL that just renders broken
 * with its alt text. This is what was happening to signature logos. */
private static escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

/** Pulls any data: URI <img> out of the HTML and turns it into a Graph inline
 *  attachment referenced by cid: — data: URIs get stripped by mail clients,
 *  but a real inline attachment renders correctly. */


}