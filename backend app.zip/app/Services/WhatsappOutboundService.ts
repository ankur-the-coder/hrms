import Database from '@ioc:Adonis/Lucid/Database'
import axios from 'axios'

/**
 * Thin outbound-only wrapper around the Meta Graph WhatsApp API.
 * Pulled out of WhatsappController so it can be called from services
 * (TicketService, WhatsappController itself) without needing an HttpContext.
 */
export default class WhatsappOutboundService {
  /**
   * @param toPhone            Customer's WhatsApp number.
   * @param text               Message body.
   * @param contextMessageId   Meta wamid to natively quote (only pass this when
   *                           the message being quoted actually originated on
   *                           WhatsApp — i.e. it has a real graph_message_id).
   * @param ticketMessageId    The just-inserted ticket_messages row id for this
   *                           outbound send. When provided, the wamid Meta
   *                           returns is written back onto that row so a LATER
   *                           reply can natively quote THIS message too.
   */
  public static async sendText(
    toPhone: string,
    text: string,
    contextMessageId?: string | null,
    ticketMessageId?: number | null
  ): Promise<void> {
    const account = await Database.from('whatsapp_accounts')
      .where('is_active', 1)
      .orderBy('id', 'desc')
      .first()

    if (!account) {
      console.error('[WhatsappOutboundService] No active WhatsApp account connected — message not sent.')
      return
    }

    const payload: Record<string, any> = {
      messaging_product: 'whatsapp',
      to: toPhone,
      type: 'text',
      text: { body: text },
    }
    if (contextMessageId) {
      payload.context = { message_id: contextMessageId }
    }

    // [WA-TRACE S0] Exactly which account/token we're about to send with.
    // getActiveAccount()'s query always picks the MOST RECENTLY created
    // is_active=1 row — if you re-authenticated and an old row is still
    // marked active for some reason, this line tells you which one actually
    // won. Token is masked; compare the first/last chars against what you
    // pasted into "Authenticate WhatsApp Business Account" to catch a stale
    // or wrong token being used.
    const maskedToken = account.access_token ? `${account.access_token.slice(0, 8)}...${account.access_token.slice(-6)}` : 'MISSING'
    console.log(`[WA-TRACE S0] sending via accountId=${account.id} phone_number_id=${account.phone_number_id} token=${maskedToken} to="${toPhone}"`)

    try {
      // timeout added — this call used to be able to hang indefinitely,
      // which (before TicketService.addMessage stopped awaiting it) was
      // enough on its own to make the frontend's 8s ack wait time out even
      // though the message might still have gone out successfully a few
      // seconds later. Now that the send is backgrounded this mainly
      // bounds how long a message can sit invisibly in-flight before the
      // UI is told it failed.
      const response = await axios.post(
        `https://graph.facebook.com/v19.0/${account.phone_number_id}/messages`,
        payload,
        { headers: { Authorization: `Bearer ${account.access_token}`, 'Content-Type': 'application/json' }, timeout: 15000 }
      )
const apiResponse = response.data
if (apiResponse?.error) {
  console.error('[WhatsappOutboundService] Graph API returned an error payload:', apiResponse.error)
  throw new Error(apiResponse.error.message || 'WhatsApp API returned an error')
}
      const waMessageId: string | undefined = response.data?.messages?.[0]?.id
      // [WA-TRACE S3] The wamid Meta handed back for this send, straight from
      // the API response. This is the value that MUST later show up
      // verbatim as `statusEvent.id` in [WA-TRACE W1/W2] when Meta reports
      // delivered/read for this same message.
      console.log(`[WA-TRACE S3] Graph API returned wamid="${waMessageId}" (len ${waMessageId?.length}) for ticketMessageId=${ticketMessageId}`)
      if (waMessageId && ticketMessageId) {
        await Database.from('ticket_messages')
          .where('id', ticketMessageId)
          .update({ graph_message_id: waMessageId })
          .then(async () => {
            // [WA-TRACE S4] Read the row straight back after the write. If
            // `savedLen` here is SHORTER than the `len` logged in S3 above,
            // the graph_message_id column is truncating the value on save —
            // that's the truncation bug: `ALTER TABLE ticket_messages MODIFY
            // graph_message_id VARCHAR(255);` (or TEXT) fixes it.
            const row = await Database.from('ticket_messages').where('id', ticketMessageId).first()
            console.log(`[WA-TRACE S4] graph_message_id after save: "${row?.graph_message_id}" (len ${row?.graph_message_id?.length})`)
          })
          .catch((err) => {
            // Never let this bookkeeping failure surface as a send failure —
            // the message already went out successfully at this point.
            console.error(`[WA-TRACE S4-ERR] failed to save wamid for message ${ticketMessageId}:`, err.message)
          })
      } else {
        console.log(`[WA-TRACE S3-WARN] missing waMessageId or ticketMessageId — graph_message_id will NOT be saved for this send, so status webhooks for it can never match`)
      }
    } catch (err: any) {
      // [WA-TRACE S5-DETAIL] The ACTUAL Meta error — HTTP status + the
      // specific error object Graph API returned. This is the line to paste
      // when a send fails; TicketService's S5-ERR log only has err.message
      // ("Request failed with status code 400"), which tells you nothing
      // about WHY it failed (wrong recipient, bad token, missing permission,
      // etc — they're all generic 400s to axios).
      console.error(
        `[WA-TRACE S5-DETAIL] send failed — httpStatus=${err.response?.status} error=`,
        JSON.stringify(err.response?.data?.error ?? { message: err.message })
      )
      throw err
    }
  }

  /**
   * Sends a reply that has one or more agent-uploaded attachments. Each
   * attachment's storage_path is already a PUBLIC S3 URL (see
   * StorageS3.toPublicKey), so Meta's Cloud API can fetch it directly by
   * `link` — no separate upload-to-Meta step needed.
   *
   * WhatsApp media messages don't have a distinct "type + attachments"
   * shape — each API call is exactly one media message, and only image/
   * video/document messages support a caption. So: the typed text rides as
   * the caption on the FIRST attachment when possible; any attachment
   * after that (or an audio-only first attachment, which has no caption
   * support) goes out as its own message, and leftover text that couldn't
   * ride as a caption is sent as a separate text message so it's never
   * silently dropped.
   */
  public static async sendWithAttachments(
    toPhone: string,
    text: string,
    attachments: Array<{
      fileName?: string; file_name?: string
      contentType?: string | null; mime_type?: string | null
      storagePath?: string; storage_path?: string
    }>,
    contextMessageId?: string | null,
    ticketMessageId?: number | null
  ): Promise<void> {
    const account = await Database.from('whatsapp_accounts')
      .where('is_active', 1)
      .orderBy('id', 'desc')
      .first()

    if (!account) {
      console.error('[WhatsappOutboundService] No active WhatsApp account connected — message not sent.')
      return
    }

    const normalized = attachments
      .map((a) => ({
        fileName: a.fileName ?? a.file_name ?? 'attachment',
        contentType: a.contentType ?? a.mime_type ?? 'application/octet-stream',
        url: a.storagePath ?? a.storage_path,
      }))
      .filter((a): a is { fileName: string; contentType: string; url: string } => !!a.url)

    if (!normalized.length) {
      // Nothing actually made it through normalization (bad rows) — fall
      // back to a plain text send rather than sending nothing at all.
      return this.sendText(toPhone, text, contextMessageId, ticketMessageId)
    }

    const waTypeFor = (contentType: string): 'image' | 'video' | 'audio' | 'document' => {
      if (contentType.startsWith('image/')) return 'image'
      if (contentType.startsWith('video/')) return 'video'
      if (contentType.startsWith('audio/')) return 'audio'
      return 'document'
    }

    let wamidForRow: string | undefined
    let captionCarried = false

    for (let i = 0; i < normalized.length; i++) {
      const a = normalized[i]
      const waType = waTypeFor(a.contentType)
      const isFirst = i === 0
      const mediaObj: Record<string, any> = { link: a.url }
      if (waType === 'document') mediaObj.filename = a.fileName
      if (isFirst && text && waType !== 'audio') {
        mediaObj.caption = text
        captionCarried = true
      }

      const payload: Record<string, any> = {
        messaging_product: 'whatsapp',
        to: toPhone,
        type: waType,
        [waType]: mediaObj,
      }
      if (isFirst && contextMessageId) payload.context = { message_id: contextMessageId }

      try {
        const response = await axios.post(
          `https://graph.facebook.com/v19.0/${account.phone_number_id}/messages`,
          payload,
          { headers: { Authorization: `Bearer ${account.access_token}`, 'Content-Type': 'application/json' }, timeout: 20000 }
        )
        if (response.data?.error) {
          console.error('[WhatsappOutboundService] Graph API returned an error payload:', response.data.error)
          throw new Error(response.data.error.message || 'WhatsApp API returned an error')
        }
        const waMessageId: string | undefined = response.data?.messages?.[0]?.id
        if (isFirst) wamidForRow = waMessageId
      } catch (err: any) {
        console.error(`[WhatsappOutboundService] attachment send failed ("${a.fileName}"):`, err.response?.data ?? err.message)
        throw err
      }
    }

    // Text existed but couldn't ride as a caption (e.g. first attachment
    // was audio) — send it as its own message so it isn't lost.
    if (text && !captionCarried) {
      await this.sendText(toPhone, text, contextMessageId, ticketMessageId)
    }

    if (wamidForRow && ticketMessageId) {
      await Database.from('ticket_messages')
        .where('id', ticketMessageId)
        .update({ graph_message_id: wamidForRow })
        .catch((err) => {
          console.error(`[WhatsappOutboundService] failed to save wamid for message ${ticketMessageId}:`, err.message)
        })
    }
  }
}