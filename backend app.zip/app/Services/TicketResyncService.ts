import Database from '@ioc:Adonis/Lucid/Database'
import axios from 'axios'
import MailAccountService from 'App/Services/MailAccountService'
import HtmlSanitizer from 'App/Helper/HtmlSanitizer'
import crypto from 'crypto'
import { uploadBufferToS3, isUrlReachable, extractS3KeyFromUrl } from 'App/Helper/StorageS3'
import AWS from 'aws-sdk'

const GRAPH = 'https://graph.microsoft.com/v1.0'

type PendingAttachment = { fileName: string; contentType: string; size: number; storagePath: string }
type ExistingAttachment = { file_name: string; size: number; storage_path: string }

// ─── S3 helper ───────────────────────────────────────────────────────────────

/**
 * Checks whether an attachment already exists in the S3 bucket using its
 * stored URL. Returns true if the object is reachable, false otherwise.
 */
async function existsInBucket(storagePath: string): Promise<boolean> {
  if (!storagePath) return false
  const bucket = process.env.S3_AttachmentBucket
  if (!bucket) return false

  // If it looks like an S3 URL, verify it exists via headObject (more reliable
  // than an HTTP GET which may 403 on a private bucket policy).
  const key = extractS3KeyFromUrl(storagePath)
  if (!key) return false

  const accessKeyId = process.env.S3_AttKEY
  const secretAccessKey = process.env.S3_AttSECRET
  const region = process.env.S3_REGION
  if (!accessKeyId || !secretAccessKey || !region) return false

  const s3 = new AWS.S3()
  try {
    await s3.headObject({ Bucket: bucket, Key: key }).promise()
    return true
  } catch (err: any) {
    if (err.code === 'NotFound' || err.statusCode === 404) return false
    // On other errors (permission denied etc.) fall back to HTTP check.
    return isUrlReachable(storagePath)
  }
}

// ─── Duplicate detection helpers ─────────────────────────────────────────────

/**
 * Outlook sometimes delivers the same physical email multiple times in a
 * conversation thread (e.g. mailbox CC'd on its own send, or a relay that
 * duplicates the message). We deduplicate on two levels:
 *
 * 1. `internetMessageId` – a globally unique RFC 5322 Message-ID header. If
 *    two Graph messages share one, they are identical mails; keep the first.
 *
 * 2. Content-level hash – sometimes two messages share different Graph IDs
 *    and different `internetMessageId`s yet carry byte-for-byte identical
 *    `uniqueBody` content AND came from the same sender within 60 seconds.
 *    This catches the most common "Sent Items + Inbox copy" duplication that
 *    the Graph conversation filter can expose.
 */
function deduplicateMessages(messages: any[]): any[] {
  const seenInternetMessageIds = new Set<string>()
  const seenContentKeys = new Set<string>()
  const out: any[] = []

  for (const msg of messages) {
    // Level 1: internetMessageId
    const mid = (msg.internetMessageId || '').trim()
    if (mid && seenInternetMessageIds.has(mid)) {
      console.log(`[TicketResyncService][dedup] dropping duplicate internetMessageId=${mid} (graph_id=${msg.id})`)
      continue
    }

    // Level 2: (sender email) + (uniqueBody content hash) + (rounded timestamp ±60 s)
    const sender = (msg.from?.emailAddress?.address || '').toLowerCase()
    const bodyRaw = msg.uniqueBody?.content || msg.bodyPreview || ''
    const bodyHash = crypto.createHash('md5').update(bodyRaw).digest('hex')
    // Round timestamp to 60-second bucket to absorb minor clock skew
    const ts = new Date(msg.sentDateTime || msg.receivedDateTime).getTime()
    const tsBucket = Math.floor(ts / 60000)
    const contentKey = `${sender}:${bodyHash}:${tsBucket}`

    if (seenContentKeys.has(contentKey)) {
      console.log(`[TicketResyncService][dedup] dropping content-duplicate graph_id=${msg.id} sender=${sender} tsBucket=${tsBucket}`)
      continue
    }

    if (mid) seenInternetMessageIds.add(mid)
    seenContentKeys.add(contentKey)
    out.push(msg)
  }

  return out
}

// ─── HTML helpers ─────────────────────────────────────────────────────────────

function htmlToPlainText(html: string): string {
  return html
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/&quot;/g, '"')
    .trim()
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function isReferencedInline(html: string, contentId?: string, name?: string, fullBodyHtml?: string): boolean {
  const bodies = [html, fullBodyHtml].filter(Boolean) as string[]
  for (const body of bodies) {
    if (contentId) {
      const cid = contentId.replace(/[<>]/g, '')
      if (body.includes(`cid:${cid}`) || body.includes(cid)) return true
    }
    if (name && body.includes(name)) return true
  }
  return false
}

// ─── Attachment resolution ────────────────────────────────────────────────────

/**
 * Resolves Graph attachments for one message.
 *
 * For each attachment:
 *  - If the exact file already exists in the bucket (matched by file_name +
 *    size against `existingInBucket`), we reuse its URL and skip uploading.
 *  - Otherwise we upload the buffer to S3 and use the new URL.
 *
 * Returns { html (with cid: refs rewritten), attachments (pending rows) }.
 */
async function resolveAttachments(
  token: string,
  graphMessageId: string,
  ticketId: number,
  uniqueBodyHtml: string,
  fullBodyHtml: string | undefined,
  existingInBucket: ExistingAttachment[]
): Promise<{ html: string; attachments: PendingAttachment[] }> {
  if (!uniqueBodyHtml) return { html: '', attachments: [] }

  const findExisting = (name: string, size: number) =>
    existingInBucket.find(e => e.file_name === name && e.size === size)

  const pending: PendingAttachment[] = []
  let html = uniqueBodyHtml

  const writeFile = async (fileName: string, buffer: Buffer, contentType?: string): Promise<string> => {
    const safeName = `${Date.now()}_${fileName}`.replace(/[^a-zA-Z0-9._-]/g, '_')
    const key = `ticket-attachments/${ticketId}/${safeName}`
    return uploadBufferToS3(key, buffer, contentType)
  }

  // Fetch Graph attachments for this message
  let graphAtts: any[] = []
  try {
    const { data } = await axios.get(`${GRAPH}/me/messages/${graphMessageId}/attachments`, {
      headers: { Authorization: `Bearer ${token}` },
    })
    graphAtts = data.value ?? []
    console.log(
      `[TicketResyncService][resolveAttachments] Graph returned ${graphAtts.length} attachment(s) for message ${graphMessageId}:`,
      graphAtts.map((a: any) => ({ name: a.name, type: a['@odata.type'], isInline: a.isInline, size: a.size }))
    )
  } catch (err: any) {
    console.warn(`[TicketResyncService][resolveAttachments] failed to fetch attachments for message ${graphMessageId}:`, err?.response?.data ?? err.message)
  }

  for (const att of graphAtts) {
    if (att['@odata.type'] !== '#microsoft.graph.fileAttachment') continue

    const claimsInline = att.isInline === true
    const isGenuinelyInline = claimsInline && isReferencedInline(html, att.contentId, att.name, fullBodyHtml)

    const originalName = att.name || att.contentId || `inline_image_${Date.now()}.png`
    const dupe = findExisting(originalName, att.size)

    // Check if duplicate exists in bucket; if so, reuse it; otherwise upload
    let relPath: string
    if (dupe) {
      const inBucket = await existsInBucket(dupe.storage_path)
      if (inBucket) {
        console.log(`[TicketResyncService][resolveAttachments] reusing existing bucket object for "${originalName}" size=${att.size}`)
        relPath = dupe.storage_path
      } else {
        console.log(`[TicketResyncService][resolveAttachments] DB row exists for "${originalName}" but NOT in bucket — re-uploading`)
        relPath = await writeFile(originalName, Buffer.from(att.contentBytes, 'base64'), att.contentType)
      }
    } else {
      relPath = await writeFile(originalName, Buffer.from(att.contentBytes, 'base64'), att.contentType)
    }

    // Rewrite inline cid: references in HTML
    if (isGenuinelyInline) {
      if (att.contentId) {
        const cid = att.contentId.replace(/[<>]/g, '')
        html = html.replace(new RegExp(`cid:${escapeRegex(cid)}`, 'gi'), relPath)
        html = html.replace(new RegExp(`src=["']${escapeRegex(cid)}["']`, 'gi'), `src="${relPath}"`)
      }
      if (att.name) {
        html = html.replace(new RegExp(`src=["']${escapeRegex(att.name)}["']`, 'gi'), `src="${relPath}"`)
      }
    }

    // Only add to pending (downloadable chip) if not genuinely inline
    if (!isGenuinelyInline) {
      pending.push({ fileName: originalName, contentType: att.contentType, size: att.size, storagePath: relPath })
      existingInBucket.push({ file_name: originalName, size: att.size, storage_path: relPath })
    } else if (!dupe) {
      // Track for dedup even if inline
      existingInBucket.push({ file_name: originalName, size: att.size, storage_path: relPath })
    }
  }

  // Handle base64 data: URI images embedded directly in the HTML
  let match: RegExpMatchArray | null
  while ((match = html.match(/data:([a-zA-Z0-9.+-]+\/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=]+)/))) {
    const [fullMatch, mimeType, base64Data] = match
    const buffer = Buffer.from(base64Data, 'base64')
    const hash = crypto.createHash('md5').update(buffer).digest('hex').slice(0, 12)
    const ext = mimeType.split('/')[1]?.replace(/[^a-z0-9]/gi, '') || 'png'
    const fileName = `pasted-image-${hash}.${ext}`

    const dupe = findExisting(fileName, buffer.length)
    let relPath: string
    if (dupe) {
      const inBucket = await existsInBucket(dupe.storage_path)
      relPath = inBucket ? dupe.storage_path : await writeFile(fileName, buffer, mimeType)
    } else {
      relPath = await writeFile(fileName, buffer, mimeType)
    }
    html = html.split(fullMatch).join(relPath)

    if (!dupe) {
      pending.push({ fileName, contentType: mimeType, size: buffer.length, storagePath: relPath })
      existingInBucket.push({ file_name: fileName, size: buffer.length, storage_path: relPath })
    }
  }

  // Strip any leftover cid: img tags that had no matching attachment in Graph
  html = html.replace(/<img[^>]+src=["']cid:[^"']*["'][^>]*>/gi, '')

  return { html: HtmlSanitizer.sanitize(html), attachments: pending }
}

// ─── Main service ─────────────────────────────────────────────────────────────

export interface ResyncResult {
  status: true
  ticketId: number
  ticketUid: string
  totalMessages: number
  messagesInserted: number
  attachmentsUploaded: number
  attachmentsReused: number
}

export default class TicketResyncService {

  /**
   * Full conversation re-sync by ticket UID (e.g. "UBI-162090").
   */
  public static async resyncByUid(uid: string): Promise<ResyncResult> {
    const ticket = await Database.from('tickets').where('ticket_uid', uid.replace(/^#/, '').trim()).first()
    if (!ticket) throw new Object({ status: 404, message: `No ticket found for uid ${uid}` })
    return this.resyncById(ticket.id)
  }

  /**
   * Full conversation re-sync by internal ticket ID.
   *
   * Steps:
   *  1. Fetch all conversation messages from Graph (with duplicate filtering).
   *  2. In a DB transaction: delete old ticket_messages + ticket_attachments.
   *  3. For each message, resolve & upload only new/absent attachments.
   *  4. Insert fresh ticket_messages + ticket_attachments rows.
   *  5. Update tickets.last_message_at.
   *  6. Broadcast socket events.
   */
  public static async resyncById(ticketId: number): Promise<ResyncResult> {
    const ticket = await Database.from('tickets').where('id', ticketId).first()
    if (!ticket) throw new Object({ status: 404, message: `No ticket found for id ${ticketId}` })
    if (ticket.source !== 'email' || !ticket.mail_conversation_id) {
      throw new Object({ status: 400, message: `Ticket ${ticket.ticket_uid} is not an email ticket or has no conversation ID` })
    }

    const mailboxEmail: string = ticket.mailbox_email || (await MailAccountService.getDefaultAccount())?.email
    if (!mailboxEmail) throw new Object({ status: 400, message: 'No mailbox associated with this ticket' })

    const token = await MailAccountService.getValidAccessToken(mailboxEmail)
    if (!token) throw new Object({ status: 502, message: `Could not obtain access token for ${mailboxEmail}` })

    // ── Step 1: Fetch messages from Graph ────────────────────────────────────
    const conversationId = ticket.mail_conversation_id
    const select = 'id,subject,from,toRecipients,ccRecipients,bccRecipients,receivedDateTime,sentDateTime,uniqueBody,body,bodyPreview,conversationId,internetMessageId,hasAttachments'

    const messageMap = new Map<string, any>()

    // Primary: conversation filter (covers the whole thread)
    try {
      let url: string | null =
        `${GRAPH}/me/messages?$filter=conversationId eq '${encodeURIComponent(conversationId)}'&$select=${select}&$top=100`
      while (url) {
        const { data }: any = await axios.get(url, {
          headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' },
        })
        for (const item of data.value ?? []) messageMap.set(item.id, item)
        url = data['@odata.nextLink'] ?? null
      }
    } catch (err: any) {
      console.warn(`[TicketResyncService][resyncById] conversation filter failed:`, err?.response?.data ?? err.message)
    }

    // Fallback: recent Inbox + Sent Items to catch index-lag gaps
    try {
      const [inboxRes, sentRes] = await Promise.all([
        axios.get(`${GRAPH}/me/mailFolders('Inbox')/messages?$select=${select}&$orderby=receivedDateTime desc&$top=50`, {
          headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' },
        }).catch(() => ({ data: { value: [] } })),
        axios.get(`${GRAPH}/me/mailFolders('SentItems')/messages?$select=${select}&$orderby=sentDateTime desc&$top=50`, {
          headers: { Authorization: `Bearer ${token}`, Prefer: 'outlook.body-content-type="html"' },
        }).catch(() => ({ data: { value: [] } })),
      ])
      for (const item of [...(inboxRes.data?.value ?? []), ...(sentRes.data?.value ?? [])]) {
        if (item.conversationId === conversationId) messageMap.set(item.id, item)
      }
    } catch (err: any) {
      console.warn(`[TicketResyncService][resyncById] folder fallback failed:`, err?.response?.data ?? err.message)
    }

    // Sort chronologically, then deduplicate
    const sorted = Array.from(messageMap.values()).sort(
      (a, b) => new Date(a.sentDateTime || a.receivedDateTime).getTime() - new Date(b.sentDateTime || b.receivedDateTime).getTime()
    )
    const messages = deduplicateMessages(sorted)

    console.log(`[TicketResyncService][resyncById] ticket #${ticketId} (${ticket.ticket_uid}): fetched ${sorted.length}, after dedup: ${messages.length}`)

    // ── Step 2: Collect existing bucket objects (for dedup/reuse) ─────────────
    // We collect the full set of existing ticket_attachments so that we can
    // reuse any S3 object that's already uploaded without re-uploading it.
    const existingInBucket: ExistingAttachment[] = await Database.from('ticket_attachments')
      .where('ticket_id', ticketId)
      .select('file_name', 'size', 'storage_path')

    // ── Step 3: Process messages & resolve attachments ────────────────────────
    // Do this BEFORE the transaction so we don't hold the DB trx open while
    // performing potentially slow S3 operations.
    type ProcessedMessage = {
      msg: any
      resolvedHtml: string
      bodyText: string
      attachments: PendingAttachment[]
      direction: 'inbound' | 'sent'
    }

    const processed: ProcessedMessage[] = []
    let attachmentsUploaded = 0
    let attachmentsReused = 0

    for (const msg of messages) {
      const fromEmail = (msg.from?.emailAddress?.address || '').toLowerCase()
      const isFromUs = fromEmail === mailboxEmail.toLowerCase()
      const direction: 'inbound' | 'sent' = isFromUs ? 'sent' : 'inbound'

      const uniqueBodyHtml: string = msg.uniqueBody?.content ?? ''
      const fullBodyHtml: string = msg.body?.content ?? ''

      const existingCountBefore = existingInBucket.length

      const { html: resolvedHtml, attachments } = await resolveAttachments(
        token, msg.id, ticketId, uniqueBodyHtml, fullBodyHtml, existingInBucket
      )

      attachmentsUploaded += attachments.length
      // Any item added to existingInBucket that was reused (came from existing DB rows)
      // doesn't count as "uploaded" — we track that via the outer loop below
      const newlyTracked = existingInBucket.length - existingCountBefore
      attachmentsReused += (newlyTracked - attachments.length)

      const bodyText = uniqueBodyHtml ? htmlToPlainText(uniqueBodyHtml) : (msg.bodyPreview ?? '')

      processed.push({ msg, resolvedHtml, bodyText, attachments, direction })
    }

    // ── Step 4: DB transaction — replace messages + attachments ───────────────
    await Database.transaction(async trx => {
      // Delete in correct order (attachments ref messages)
      await trx.from('ticket_attachments').where('ticket_id', ticketId).delete()
      await trx.from('ticket_messages').where('ticket_id', ticketId).delete()

      let latestOccurredAt: Date | null = null

      for (const { msg, resolvedHtml, bodyText, attachments, direction } of processed) {
        const occurredAt = new Date(msg.sentDateTime || msg.receivedDateTime)
        if (!latestOccurredAt || occurredAt > latestOccurredAt) latestOccurredAt = occurredAt

        const insertRow: any = {
          ticket_id: ticketId,
          sender: direction === 'inbound' ? 'customer' : 'agent',
          type: 'reply',
          message: resolvedHtml || bodyText || '(Original message content could not be retrieved from Outlook.)',
          sender_name: direction === 'inbound' ? (msg.from?.emailAddress?.name || msg.from?.emailAddress?.address || null) : null,
          sender_email: direction === 'inbound' ? (msg.from?.emailAddress?.address || null) : null,
          to_recipients: JSON.stringify((msg.toRecipients ?? []).map((r: any) => r.emailAddress.address)),
          cc_recipients: JSON.stringify((msg.ccRecipients ?? []).map((r: any) => r.emailAddress.address)),
          bcc_recipients: JSON.stringify((msg.bccRecipients ?? []).map((r: any) => r.emailAddress.address)),
          channel: 'email',
          graph_message_id: msg.id,
          created_at: occurredAt,
        }
        if (direction === 'sent') insertRow.delivery_status = 'sent'

        const [msgId] = await trx.table('ticket_messages').insert(insertRow)

        // Insert attachment rows
        for (const att of attachments) {
          try {
            await trx.table('ticket_attachments').insert({
              ticket_id: ticketId,
              message_id: msgId,
              file_name: att.fileName,
              content_type: att.contentType,
              size: att.size,
              storage_path: att.storagePath,
              created_at: new Date(),
            })
          } catch (err: any) {
            console.error(`[TicketResyncService] attachment insert failed for "${att.fileName}":`, err.message)
          }
        }
      }

      // Update last_message_at
      if (latestOccurredAt) {
        await trx.from('tickets').where('id', ticketId).update({ last_message_at: latestOccurredAt })
      }
    })

    console.log(`[TicketResyncService][resyncById] ticket #${ticketId} (${ticket.ticket_uid}): re-sync complete. messages=${messages.length}, attachmentsUploaded=${attachmentsUploaded}, attachmentsReused=${attachmentsReused}`)

    // ── Step 5: Broadcast socket events ──────────────────────────────────────
    try {
      const { io } = await import('../../start/socket')
      io.to(`ticket_${ticketId}`).emit('ticket_bump', { ticketId })
      io.emit('tickets_updated')
      io.emit('dashboard_stats_stale')
    } catch (err: any) {
      console.warn('[TicketResyncService] socket broadcast failed:', err.message)
    }

    return {
      status: true,
      ticketId,
      ticketUid: ticket.ticket_uid,
      totalMessages: messages.length,
      messagesInserted: messages.length,
      attachmentsUploaded,
      attachmentsReused,
    }
  }
}
