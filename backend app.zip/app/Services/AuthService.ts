import Database from '@ioc:Adonis/Lucid/Database'
import Hash from '@ioc:Adonis/Core/Hash'
import { randomUUID } from 'crypto'

export default class AuthService {
  public static async login(username: string, password: string, force = false) {
    const agent = await Database.from('support_agents').where('username', username).first()
    if (!agent || !agent.is_active) return { status: false, msg: 'Invalid credentials' }

    const valid = await Hash.verify(agent.password, password)
    if (!valid) return { status: false, msg: 'Invalid credentials' }

    if (agent.current_socket_id && !force) {
      return { status: true, data: { alreadyLoggedIn: true, currentDevice: agent.current_device } }
    }

    const token = randomUUID()
    await Database.from('support_agents').where('id', agent.id).update({ auth_token: token })

    return { 
      status: true,
      data: { token, name: agent.name, role: agent.role, agentId: agent.id, alreadyLoggedIn: false },
    }
  }

  public static async logout(agentId: number) {
    await Database.from('support_agents').where('id', agentId).update({ auth_token: null, current_socket_id: null, current_device: null })
    return { status: true }
  }

  /** Resolves the caller from `Authorization: Bearer <token>` — the single source of truth for who's making the request. */
  public static async getAgentFromToken(token?: string) {
    if (!token) return null
    return Database.from('support_agents').where('auth_token', token).where('is_active', 1).first()
  }
}