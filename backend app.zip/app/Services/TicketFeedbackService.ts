import Database from '@ioc:Adonis/Lucid/Database'
import Env from '@ioc:Adonis/Core/Env'
import crypto from 'crypto'
import TicketService from 'App/Services/TicketService'

export type RatingTier = 'positive' | 'neutral' | 'negative'

function escapeHtml(str: string | null | undefined): string {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

function tierFor(rating: number): RatingTier {
  if (rating >= 4) return 'positive'
  if (rating === 3) return 'neutral'
  return 'negative'
}

const RATING_LABELS: Record<number, string> = {
  1: 'Very Unsatisfied',
  2: 'Unsatisfied',
  3: 'Neutral',
  4: 'Satisfied',
  5: 'Very Satisfied',
}

export default class TicketFeedbackService {
  /** Base URL the *server-rendered* fallback pages point at — same var used for the Graph webhook URL. */
  private static baseUrl(): string {
    return (Env.get('PUBLIC_URL') as string)?.replace(/\/$/, '') || ''
  }

  /**
   * Base URL of the standalone Angular app. The closure-email buttons now point
   * here instead of straight at the backend, so the customer lands on the
   * rich `/feedback` frontend page (which then talks to the JSON API below)
   * rather than the old server-rendered HTML.
   */
  private static frontendUrl(): string {
    return (Env.get('FRONTEND_URL') as string)?.replace(/\/$/, '') || this.baseUrl()
  }

  /** Generates the ticket's feedback_token if it doesn't have one yet, and returns it. */
  public static async ensureFeedbackToken(ticketId: number): Promise<string> {
    const ticket = await Database.from('tickets').where('id', ticketId).first()
    if (ticket?.feedback_token) return ticket.feedback_token
    const token = crypto.randomBytes(24).toString('hex')
    await Database.from('tickets').where('id', ticketId).update({ feedback_token: token })
    return token
  }

  /** Builds the 6 links (Reopen + 5 rating buttons) for the closure email. */
  public static async buildFeedbackLinks(ticketId: number) {
    const token = await this.ensureFeedbackToken(ticketId)
    const app = this.frontendUrl()
    return {
      reopenUrl: `${app}/feedback?t=${token}&reopen=1`,
      rating1: `${app}/feedback?t=${token}&r=1`,
      rating2: `${app}/feedback?t=${token}&r=2`,
      rating3: `${app}/feedback?t=${token}&r=3`,
      rating4: `${app}/feedback?t=${token}&r=4`,
      rating5: `${app}/feedback?t=${token}&r=5`,
    }
  }

  private static async getByToken(token: string) {
    return Database.from('tickets').where('feedback_token', token).first()
  }

  /** Customer-safe conversation — replies only, internal notes are never shown. */
  private static async getPublicConversation(ticketId: number) {
    return Database.from('ticket_messages')
      .where('ticket_id', ticketId)
      .where('type', 'reply')
      .orderBy('created_at', 'asc')
      .select('sender', 'sender_name', 'message', 'created_at')
  }

  // ============================================================
  // GET /feedback  — a rating button was clicked
  // ============================================================
  public static async handleRatingClick(token: string, rating: number): Promise<string> {
    const ticket = await this.getByToken(token)
    if (!ticket) return this.renderNotFound()
    if (!rating || rating < 1 || rating > 5) return this.renderNotFound()

    await Database.from('tickets').where('id', ticket.id).update({
      rating,
      rating_submitted_at: new Date(),
    })

    const tier = tierFor(rating)
    if (tier === 'negative') {
      await TicketService.reopenByCustomer(ticket.id)
    }

    const messages = await this.getPublicConversation(ticket.id)
    return this.renderRatingPage(ticket, rating, tier, messages)
  }

  // ============================================================
  // POST /feedback/submit — the "what did you like / what can we improve /
  // what went wrong" form
  // ============================================================
  public static async submitFeedback(token: string, data: { likedMost?: string; improve?: string; explanation?: string }) {
    const ticket = await this.getByToken(token)
    if (!ticket) return this.renderNotFound()

    const patch: any = {}
    if (data.likedMost !== undefined) patch.rating_liked_most = data.likedMost.slice(0, 2000)
    if (data.improve !== undefined) patch.rating_improve_feedback = data.improve.slice(0, 2000)
    if (Object.keys(patch).length) await Database.from('tickets').where('id', ticket.id).update(patch)

    if (data.explanation?.trim()) {
      await TicketService.addMessage({
        ticketId: ticket.id,
        sender: 'customer',
        type: 'reply',
        message: escapeHtml(data.explanation.trim()).replace(/\n/g, '<br>'),
        senderName: ticket.customer_name,
        senderEmail: ticket.customer_email,
      })
    }

    const { io } = await import('../../start/socket')
    io.emit('tickets_updated')

    return this.renderThanks(ticket, tierFor(ticket.rating ?? 3))
  }

  // ============================================================
  // GET /feedback/reopen — the standalone "Reopen ticket" button
  // ============================================================
  public static async handleReopenClick(token: string): Promise<string> {
    const ticket = await this.getByToken(token)
    if (!ticket) return this.renderNotFound()
    const reopened = await TicketService.reopenByCustomer(ticket.id)
    const messages = await this.getPublicConversation(ticket.id)
    return this.renderReopenedPage(reopened ?? ticket, messages)
  }

  // ============================================================
  // POST /feedback/reopen/message — "message further" box on the reopened page
  // ============================================================
  public static async submitReopenMessage(token: string, message: string) {
    const ticket = await this.getByToken(token)
    if (!ticket) return this.renderNotFound()
    if (message?.trim()) {
      await TicketService.addMessage({
        ticketId: ticket.id,
        sender: 'customer',
        type: 'reply',
        message: escapeHtml(message.trim()).replace(/\n/g, '<br>'),
        senderName: ticket.customer_name,
        senderEmail: ticket.customer_email,
      })
      const { io } = await import('../../start/socket')
      io.emit('tickets_updated')
    }
    const fresh = await Database.from('tickets').where('id', ticket.id).first()
    const messages = await this.getPublicConversation(ticket.id)
    return this.renderReopenedPage(fresh, messages, true)
  }

  // ============================================================
  // JSON API — powers the standalone Angular /feedback page. Same access
  // rules as the HTML endpoints above (gated by feedback_token only), just
  // returns data instead of a rendered page.
  // ============================================================

  /** Strips internal columns before a ticket row goes to the customer's browser. */
  private static toPublicTicket(ticket: any) {
    return {
      ticketUid: ticket.ticket_uid,
      subject: ticket.subject,
      status: ticket.status,
      priority: ticket.priority,
      source: ticket.source,
      customerName: ticket.customer_name,
      assignedAgentName: ticket.assigned_agent_name,
      createdAt: ticket.created_at,
      updatedAt: ticket.updated_at,
      reopenCount: ticket.reopen_count ?? 0,
      lastReopenedAt: ticket.last_reopened_at,
      rating: ticket.rating,
      ratingSubmittedAt: ticket.rating_submitted_at,
      ratingLikedMost: ticket.rating_liked_most,
      ratingImproveFeedback: ticket.rating_improve_feedback,
    }
  }

  /** GET /api/feedback/view?t=&r=&reopen= — single entry point for the frontend page load. */
  public static async getViewData(token: string, rating?: number, reopen?: boolean) {
    const ticket = await this.getByToken(token)
    if (!ticket) return { found: false as const }

    // A rating link was clicked — record it (mirrors handleRatingClick).
    if (rating && rating >= 1 && rating <= 5) {
      const tier = tierFor(rating)
      await Database.from('tickets').where('id', ticket.id).update({
        rating,
        rating_submitted_at: new Date(),
      })
      if (tier === 'negative') await TicketService.reopenByCustomer(ticket.id)

      const fresh = await Database.from('tickets').where('id', ticket.id).first()
      const messages = await this.getPublicConversation(ticket.id)
      return {
        found: true as const,
        mode: 'rating' as const,
        tier,
        ratingLabel: RATING_LABELS[rating],
        ticket: this.toPublicTicket(fresh),
        messages,
      }
    }

    // The standalone "Reopen ticket" button was clicked.
    if (reopen) {
      const reopened = await TicketService.reopenByCustomer(ticket.id)
      const messages = await this.getPublicConversation(ticket.id)
      return {
        found: true as const,
        mode: 'reopen' as const,
        ticket: this.toPublicTicket(reopened ?? ticket),
        messages,
      }
    }

    // Plain link (e.g. a page refresh) — read-only view, no side effects.
    const messages = await this.getPublicConversation(ticket.id)
    return {
      found: true as const,
      mode: 'view' as const,
      tier: ticket.rating ? tierFor(ticket.rating) : null,
      ticket: this.toPublicTicket(ticket),
      messages,
    }
  }

  /** POST /api/feedback/submit — same "liked most / improve / explanation" form, JSON in/out. */
  public static async submitFeedbackData(token: string, data: { likedMost?: string; improve?: string; explanation?: string }) {
    const ticket = await this.getByToken(token)
    if (!ticket) return { found: false as const }

    const patch: any = {}
    if (data.likedMost !== undefined) patch.rating_liked_most = data.likedMost.slice(0, 2000)
    if (data.improve !== undefined) patch.rating_improve_feedback = data.improve.slice(0, 2000)
    if (Object.keys(patch).length) await Database.from('tickets').where('id', ticket.id).update(patch)

    if (data.explanation?.trim()) {
      await TicketService.addMessage({
        ticketId: ticket.id,
        sender: 'customer',
        type: 'reply',
        message: escapeHtml(data.explanation.trim()).replace(/\n/g, '<br>'),
        senderName: ticket.customer_name,
        senderEmail: ticket.customer_email,
      })
    }

    const { io } = await import('../../start/socket')
    io.emit('tickets_updated')

    const fresh = await Database.from('tickets').where('id', ticket.id).first()
    const messages = await this.getPublicConversation(ticket.id)
    return {
      found: true as const,
      tier: tierFor(fresh.rating ?? 3),
      ticket: this.toPublicTicket(fresh),
      messages,
    }
  }

  /** POST /api/feedback/reopen-message — "message further" box, JSON in/out. */
  public static async submitReopenMessageData(token: string, message: string) {
    const ticket = await this.getByToken(token)
    if (!ticket) return { found: false as const }

    if (message?.trim()) {
      await TicketService.addMessage({
        ticketId: ticket.id,
        sender: 'customer',
        type: 'reply',
        message: escapeHtml(message.trim()).replace(/\n/g, '<br>'),
        senderName: ticket.customer_name,
        senderEmail: ticket.customer_email,
      })
      const { io } = await import('../../start/socket')
      io.emit('tickets_updated')
    }

    const fresh = await Database.from('tickets').where('id', ticket.id).first()
    const messages = await this.getPublicConversation(ticket.id)
    return {
      found: true as const,
      ticket: this.toPublicTicket(fresh),
      messages,
    }
  }

  // ============================================================
  // HTML rendering (legacy fallback — kept so any closure emails already
  // sent before this change, which still point at the backend, keep working)
  // ============================================================
  private static shell(badgeText: string, badgeColor: string, bodyHtml: string): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ubiSupport</title>
<style>
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#f1f5f9;margin:0;padding:40px 16px;color:#334155;line-height:1.6;}
  .wrap{max-width:600px;margin:0 auto;}
  .card{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:32px;box-shadow:0 4px 6px -1px rgba(0,0,0,.05);}
  .header{display:flex;justify-content:space-between;align-items:center;padding-bottom:20px;border-bottom:1px solid #f1f5f9;margin-bottom:24px;}
  .logo{font-size:18px;font-weight:800;color:#0f172a;}
  .logo span{color:#10b981;}
  .badge{background:${badgeColor}1a;color:${badgeColor};font-size:12px;font-weight:700;padding:6px 12px;border-radius:20px;}
  h1{font-size:18px;font-weight:700;margin:0 0 12px;color:#0f172a;}
  p{margin:0 0 14px;font-size:14px;color:#475569;}
  textarea{width:100%;box-sizing:border-box;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;font-family:inherit;font-size:14px;resize:vertical;min-height:80px;margin-bottom:14px;}
  label{display:block;font-size:12.5px;font-weight:600;color:#334155;margin-bottom:6px;}
  .btn{display:inline-block;background:#10b981;color:#fff;border:none;padding:11px 22px;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;text-decoration:none;}
  .ticket-ref{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px 18px;margin:18px 0;font-size:13px;color:#64748b;}
  .ticket-ref strong{color:#0f172a;font-family:monospace;font-size:15px;}
  .thread{margin-top:24px;border-top:1px solid #f1f5f9;padding-top:20px;}
  .thread h2{font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:#94a3b8;margin:0 0 14px;}
  .msg{border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;margin-bottom:10px;font-size:13.5px;}
  .msg.customer{background:#f8fafc;}
  .msg.agent{background:#eff6ff;}
  .msg.system{background:#fefce8;}
  .msg .meta{font-size:11px;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;letter-spacing:.03em;}
  .footer{text-align:center;font-size:12px;color:#94a3b8;margin-top:28px;}
</style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <div class="header">
        <div class="logo">ubi<span>Support</span></div>
        <div class="badge">${badgeText}</div>
      </div>
      ${bodyHtml}
    </div>
    <div class="footer">&copy; ubiDesk Support Manager. All rights reserved.</div>
  </div>
</body>
</html>`
  }

  private static renderThread(messages: any[]): string {
    if (!messages.length) return ''
    const rows = messages.map((m) => `
      <div class="msg ${escapeHtml(m.sender)}">
        <div class="meta">${escapeHtml(m.sender_name || m.sender)} &middot; ${new Date(m.created_at).toLocaleString()}</div>
        <div>${m.message}</div>
      </div>`).join('')
    return `<div class="thread"><h2>Conversation history</h2>${rows}</div>`
  }

  private static ticketRef(ticket: any): string {
    return `<div class="ticket-ref">
      Ticket reference <strong>#${escapeHtml(ticket.ticket_uid)}</strong>
      ${ticket.subject ? `<br>${escapeHtml(ticket.subject)}` : ''}
      <br>Status: ${escapeHtml(ticket.status)}
    </div>`
  }

  private static renderRatingPage(ticket: any, rating: number, tier: RatingTier, messages: any[]): string {
    const first = (ticket.customer_name || 'there').split(' ')[0]
    const token = ticket.feedback_token

    if (tier === 'positive') {
      return this.shell(`${RATING_LABELS[rating]}`, '#10b981', `
        <h1>Thanks for the ${rating}-star rating, ${escapeHtml(first)}! 🎉</h1>
        <p>We're glad we could help. A couple of quick questions, if you have a moment:</p>
        <form method="POST" action="/feedback/submit">
          <input type="hidden" name="t" value="${escapeHtml(token)}">
          <label>What did you like the most?</label>
          <textarea name="likedMost" placeholder="e.g. quick response, agent was helpful..."></textarea>
          <label>What can we improve further?</label>
          <textarea name="improve" placeholder="Anything we could do better?"></textarea>
          <button class="btn" type="submit">Submit feedback</button>
        </form>
        ${this.ticketRef(ticket)}
        ${this.renderThread(messages)}
      `)
    }

    if (tier === 'neutral') {
      return this.shell('Neutral', '#f59e0b', `
        <h1>Thanks for rating us ${escapeHtml(first)}</h1>
        <p>We'd love to do better next time — what can we improve?</p>
        <form method="POST" action="/feedback/submit">
          <input type="hidden" name="t" value="${escapeHtml(token)}">
          <label>What can we improve?</label>
          <textarea name="improve" placeholder="Tell us what would have made this better..."></textarea>
          <button class="btn" type="submit">Submit feedback</button>
        </form>
        ${this.ticketRef(ticket)}
        ${this.renderThread(messages)}
      `)
    }

    // negative — already reopened by handleRatingClick()
    return this.shell('Ticket Reopened', '#ef4444', `
      <h1>We're sorry to hear that ${escapeHtml(first)}</h1>
      <p>We've reopened ticket <strong>#${escapeHtml(ticket.ticket_uid)}</strong> and our team will follow up shortly.
      Could you tell us what went wrong and how we can resolve it for you?</p>
      <form method="POST" action="/feedback/submit">
        <input type="hidden" name="t" value="${escapeHtml(token)}">
        <label>What went wrong?</label>
        <textarea name="explanation" placeholder="Please explain what happened and what you need..."></textarea>
        <button class="btn" type="submit">Send to our team</button>
      </form>
      ${this.ticketRef(ticket)}
      ${this.renderThread(messages)}
    `)
  }

  private static renderReopenedPage(ticket: any, messages: any[], afterMessage = false): string {
    const first = (ticket.customer_name || 'there').split(' ')[0]
    return this.shell('Ticket Reopened', '#ef4444', `
      <h1>We've reopened your ticket, ${escapeHtml(first)}.</h1>
      <p>${afterMessage
        ? "Thanks — we've added your message to the ticket."
        : "You can message us further below and we'll resolve your issue as quickly as possible."}</p>
      <form method="POST" action="/feedback/reopen/message">
        <input type="hidden" name="t" value="${escapeHtml(ticket.feedback_token)}">
        <label>Add a message</label>
        <textarea name="message" placeholder="Tell us more..."></textarea>
        <button class="btn" type="submit">Send message</button>
      </form>
      ${this.ticketRef(ticket)}
      ${this.renderThread(messages)}
    `)
  }

  private static renderThanks(ticket: any, tier: RatingTier): string {
    return this.shell('Thank you', '#10b981', `
      <h1>Thanks for your feedback!</h1>
      <p>${tier === 'negative'
        ? `We've sent your message to our team — ticket #${escapeHtml(ticket.ticket_uid)} is reopened and someone will get back to you shortly.`
        : "We really appreciate you taking the time to help us improve."}</p>
      ${this.ticketRef(ticket)}
    `)
  }

  private static renderNotFound(): string {
    return this.shell('Not found', '#94a3b8', `
      <h1>This link isn't valid</h1>
      <p>This feedback link has expired or is invalid. If you need help, please reply to your original support email.</p>
    `)
  }
}