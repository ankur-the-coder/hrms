import Database from '@ioc:Adonis/Lucid/Database'
import axios from 'axios'
import TicketService from 'App/Services/TicketService'
import WhatsAppIdentificationService from 'App/Services/WhatsAppIdentificationService'
import { uploadBufferToS3 } from 'App/Helper/StorageS3'

const GRAPH_VERSION = 'v19.0'
// WhatsApp media types that arrive with an `{id, mime_type, caption?}` object
// at message[message.type] instead of message.text.body.
const MEDIA_TYPES = ['image', 'video', 'audio', 'document', 'sticker'] as const

// Kept as a single source of truth — WhatsappController.verify() checks incoming
// requests against this, and connectAccount() stores the same value as the
// account's webhook_verify_token, so both stay in sync automatically.
export const WA_VERIFY_TOKEN = 'ubi_wa_verify_token'

export type IncomingResult =
  | { handled: false }
  | {
      handled: true
      isNewTicket: boolean
      ticket: any
      identification: any | null
      /** Set only when replying into an existing ticket (isNewTicket === false). */
      lastMessage?: any
      /** Set only when a brand-new ticket was auto-responded to (identified sender). */
      autoEmailMessage?: any
      autoWhatsAppMessage?: any
    }

export default class WhatsappService {
  // ───────────────────────── Webhook verification (Meta handshake) ─────────────────────────
  public static verifyHandshake(mode: string, token: string): boolean {
    return mode === 'subscribe' && token === WA_VERIFY_TOKEN
  }

  // ───────────────────────── Dedup guard — Meta retries webhooks, one wamid = one processed event, ever ─────────────────────────
  //
  // IMPORTANT: this is no longer a "check, then later insert" pattern. Meta's
  // 3 retries arrive close together and were racing each other: all 3 passed
  // the old isDuplicate() check before any of them had gotten around to
  // inserting into processed_whatsapp_messages (that insert used to happen
  // only *after* ticket creation). Each one then created its own ticket, and
  // only the LAST insert into processed_whatsapp_messages hit the unique-key
  // violation — which was also uncaught, so it bubbled up as an HTTP 500,
  // which made Meta retry *again*.
  //
  // tryClaim() fixes both problems: it's a single atomic INSERT on the
  // unique key, done as the very first thing, before any identification or
  // ticket-creation work. Only one concurrent request can ever win it.
  private static async tryClaim(waMessageId: string, phoneNumberId: string, fromPhone: string): Promise<boolean> {
    try {
      await Database.table('processed_whatsapp_messages').insert({
        whatsapp_message_id: waMessageId,
        phone_number_id: phoneNumberId,
        from_phone: fromPhone,
        ticket_id: null,
        processed_at: new Date(),
      })
      return true // we own this message — nobody else can process it
    } catch (err: any) {
      if (err.code === 'ER_DUP_ENTRY') return false // another (retry) request already claimed it
      throw err
    }
  }

  private static async attachTicketToClaim(waMessageId: string, ticketId: number) {
    await Database.from('processed_whatsapp_messages')
      .where('whatsapp_message_id', waMessageId)
      .update({ ticket_id: ticketId })
  }

  private static async getActiveAccount() {
    const account = await Database.from('whatsapp_accounts').where('is_active', 1).orderBy('id', 'desc').first()
    if (!account) throw new Error('No active WhatsApp account is connected.')
    return account
  }

  // ───────────────────────── Inbound media (images/docs/video/audio/stickers) ─────────────────────────
  /**
   * WhatsApp webhook payloads never carry a directly-downloadable URL — only a
   * `media.id`. You have to:
   *   1. GET /{media-id} (with your access token) → a short-lived CDN url
   *   2. GET that CDN url (same access token) → the actual bytes
   * Both steps must use the SAME account's token as the one Meta sent the
   * webhook for, so we resolve the active account fresh rather than trusting
   * anything in the payload.
   *
   * ASSUMPTION — I don't have your `ticket_attachments` migration/model, so
   * the insert below uses ticket_id / message_id / storage_path / file_name /
   * mime_type / size, matching what ticket-detail.ts already reads
   * (`${apiUrl}/uploads/${a.storage_path}`). Send me that migration/model if
   * any column name differs and I'll line this up exactly.
   */
  private static async saveInboundMedia(ticketId: number, messageId: number, mediaPayload: { id: string; mime_type?: string; caption?: string; filename?: string }) {
    try {
      const account = await this.getActiveAccount()

      const metaRes = await axios.get(`https://graph.facebook.com/${GRAPH_VERSION}/${mediaPayload.id}`, {
        headers: { Authorization: `Bearer ${account.access_token}` },
        timeout: 15000,
      })
      const { url: cdnUrl, mime_type: mimeType } = metaRes.data as { url: string; mime_type: string }

      const fileRes = await axios.get(cdnUrl, {
        headers: { Authorization: `Bearer ${account.access_token}` },
        responseType: 'arraybuffer',
        timeout: 20000,
      })

      const ext = (mediaPayload.filename?.split('.').pop()) || (mimeType?.split('/')[1] || 'bin').split('+')[0]
      const fileName = mediaPayload.filename || `wa-${mediaPayload.id}.${ext}`
      const storageName = `${Date.now()}-${mediaPayload.id}.${ext}`
      const key = `whatsapp/${storageName}`

      // storage_path now holds the full S3 URL (was a local uploads/-relative
      // path) — ticket-detail.ts's attachmentUrl() was updated to use it as-is.
      const storagePath = await uploadBufferToS3(key, Buffer.from(fileRes.data), mimeType)

      const [attachmentId] = await Database.table('ticket_attachments').insert({
        ticket_id: ticketId,
        message_id: messageId,
        file_name: fileName,
        content_type: mimeType || mediaPayload.mime_type || null,
        size: Buffer.byteLength(fileRes.data),
        storage_path: storagePath,
        created_at: new Date(),
      })

      return Database.from('ticket_attachments').where('id', attachmentId).first()
    } catch (err: any) {
      // Never let a media-download failure break the ticket/message that already
      // exists — the customer's text/caption is already saved either way.
      console.error(`[WhatsappService] failed to save inbound media ${mediaPayload.id} for ticket ${ticketId}:`, err.message)
      return null
    }
  }

  // ───────────────────────── Inbound webhook ─────────────────────────
  /**
   * Parses one Meta webhook payload and applies all ticket-side effects:
   *  - dedup via processed_whatsapp_messages
   *  - find-or-create the ticket for this phone number
   *  - identify the sender (employee / organization / unidentified)
   *  - for a brand-new, IDENTIFIED sender only: auto-email + auto-WhatsApp ack,
   *    each recorded as its own ticket_messages row (so retry/audit works)
   *  - unidentified senders: the ticket is still created (so agents see it),
   *    but nothing is auto-sent — flagged instead for manual follow-up
   *
   * Deliberately does NOT touch sockets — the controller (which already owns
   * the `io` import) decides what to emit based on the shape of this result.
   */
  // ───────────────────────── Phase 1: claim (fast, blocking, safe to await before responding to Meta) ─────────────────────────
  // Does ONE indexed unique-key insert and nothing else. Call this, respond
  // 200 to Meta, THEN call processClaimedMessage() in the background.
  public static async claim(body: any): Promise<
    | { ok: false }
    | { ok: true; body: any; entry: any; contact: any; message: any }
  > {
    if (body.object !== 'whatsapp_business_account') {
      // [WA-TRACE W1a] W0 logged the raw body already — if this fires, check
      // what body.object actually was there. Almost always means the wrong
      // webhook field delivered something unexpected.
      console.log(`[WA-TRACE W1a] claim() bailing — body.object="${body.object}" (expected "whatsapp_business_account")`)
      return { ok: false }
    }

    const entry = body.entry?.[0]?.changes?.[0]?.value
    const contact = entry?.contacts?.[0]
    const message = entry?.messages?.[0]
    if (!message) {
      // [WA-TRACE W1b] Normal for delivery/read receipts (handled separately
      // above) and for other subscribed fields (account_update, security,
      // etc). Only chase this if you expected an actual inbound message here.
      console.log('[WA-TRACE W1b] claim() bailing — no entry.messages[0] in payload (not a message event)')
      return { ok: false }
    }

    const claimed = await this.tryClaim(message.id, entry?.metadata?.phone_number_id || '', message.from)
    if (!claimed) {
      // [WA-TRACE W1c] Meta retried a webhook for a message id we already
      // hold — expected/harmless, Meta always retries a few times regardless.
      console.log(`[WA-TRACE W1c] claim() bailing — message.id="${message.id}" already claimed (duplicate Meta retry)`)
      return { ok: false }
    }

    // [WA-TRACE W2] We now OWN this message and are about to process it. If
    // you never see W2 for a message you know arrived: W0 never fired = Meta
    // isn't calling you at all; W1a/W1b/W1c fired = it arrived but got
    // filtered out here (read the specific reason logged).
    console.log(`[WA-TRACE W2] claimed message.id="${message.id}" from="${message.from}" type="${message.type}"`)

    return { ok: true, body, entry, contact, message }
  }

  // ───────────────────────── Phase 2: everything slow — DB writes, identification, auto-email, auto-WhatsApp ack ─────────────────────────
  // Runs AFTER the controller has already sent Meta its 200. Never throw out
  // of here uncaught — the controller wraps this in .catch() as a last
  // resort, but each sub-step below also fails soft on its own so one bad
  // send (email/WhatsApp) never blocks the rest.
  public static async processClaimedMessage(claim: { entry: any; contact: any; message: any }): Promise<IncomingResult> {
    const { entry, contact, message } = claim
    const fromPhone = message.from
    const customerName = contact?.profile?.name || `WhatsApp User (${fromPhone})`
    const messageType: string = message.type || 'text'
    const isMedia = (MEDIA_TYPES as readonly string[]).includes(messageType)
    const mediaPayload = isMedia ? message[messageType] : null
    const messageText = message.text?.body || mediaPayload?.caption || (isMedia ? `[${messageType}]` : '[Media/Attachment]')

    let ticket = await Database.from('tickets')
      .where('customer_phone', 'like', `%${fromPhone.slice(-10)}%`)
      .where('source', 'whatsapp')
      .whereNull('deleted_at')
      .orderBy('id', 'desc')
      .first()

    let isNewTicket = false
    let identification: any = null
    let lastMessage: any

    if (!ticket) {
      isNewTicket = true
      identification = await WhatsAppIdentificationService.identifyByPhone(fromPhone).catch(() => null)

      ticket = await TicketService.createTicket({
        customerName: identification?.name || customerName,
        customerPhone: fromPhone,
        customerEmail: identification?.employeeEmail || identification?.orgEmail || null,
        source: 'whatsapp',
        priority: 'medium',
        description: messageText,
        graphMessageId: message.id,
        senderIdentification: identification?.type ?? 'unidentified',
        senderOrgId: identification?.orgId ?? null,
        senderOrgName: identification?.orgName ?? null,
        senderEmployeeId: identification?.employeeId ?? null,
        senderOrgUrl: identification?.logoUrl ?? null,
        senderUrl: identification?.profileUrl || identification?.logoUrl || null,
      })

      if (isMedia && mediaPayload?.id && ticket.description_message_id) {
        await this.saveInboundMedia(ticket.id, ticket.description_message_id, mediaPayload)
      }
    } else {
      // If the ticket was closed (or resolved), route the reopen through
      // reopenByCustomer() so a client's WhatsApp reply counts toward
      // reopen_count / last_reopened_at / the activity log — same as the
      // email-reply path (EmailToTicketService) and the feedback-page
      // "Reopen ticket" button. A plain `update({ status: 'open' })` here
      // reopened the ticket visually but never counted it as reopened.
      if (['closed', 'resolved'].includes(ticket.status)) {
        const reopened = await TicketService.reopenByCustomer(ticket.id)
        ticket.status = reopened?.status ?? 'open'
        ticket.reopen_count = reopened?.reopen_count ?? ticket.reopen_count
      } else if (ticket.status !== 'open') {
        await Database.from('tickets').where('id', ticket.id).update({ status: 'open', updated_at: new Date() })
        ticket.status = 'open'
      }
      lastMessage = await TicketService.addMessage({
        ticketId: ticket.id,
        sender: 'customer',
        type: 'reply',
        message: messageText,
        senderName: customerName,
        graphMessageId: message.id,
      })

      if (isMedia && mediaPayload?.id && lastMessage?.id) {
        const attachment = await this.saveInboundMedia(ticket.id, lastMessage.id, mediaPayload)
        if (attachment) lastMessage = { ...lastMessage, attachments: [attachment] }
      }
    }

    // The row for this wamid already exists (inserted atomically in claim()) —
    // just attach the ticket id to it now that we know it.
    await this.attachTicketToClaim(message.id, ticket.id)

    const result: IncomingResult = { handled: true, isNewTicket, ticket, identification, lastMessage }

    // Gate on identification: unidentified senders get a ticket (for visibility
    // + the red "urgent" flag in the UI) but no automated reply on either channel.
    if (isNewTicket && identification && identification.type !== 'unidentified') {
      const { emailMessage, whatsappMessage } = await this.dispatchNewTicketNotifications(ticket, identification, fromPhone)
      result.autoEmailMessage = emailMessage
      result.autoWhatsAppMessage = whatsappMessage
    }

    // [WA-TRACE W3] Full backend pipeline completed for this message. If
    // this fires but the reply still never shows up in the panel UI, the
    // bug is on the frontend/socket side (check the browser's socket
    // connection and that it actually joined the `ticket_${id}` room) —
    // NOT in this backend pipeline.
    console.log(`[WA-TRACE W3] processClaimedMessage done — ticketId=${ticket.id} isNewTicket=${isNewTicket} autoNotified=${!!result.autoWhatsAppMessage}`)

    return result
  }

  // ───────────────────────── Auto-response for a new, identified ticket ─────────────────────────
  private static async dispatchNewTicketNotifications(ticket: any, identification: any, fromPhone: string) {
    const emailResult = await this.sendAutoEmail(ticket, identification)
    const emailMessage = await TicketService.addMessage({
      ticketId: ticket.id,
      sender: 'system',
      type: 'reply',
      message: emailResult.displayHtml || emailResult.html || `Auto-response email to ${emailResult.toEmail || 'recipient'}`,
      // Links this email back to the inbound WhatsApp message it was triggered
      // by — this is what makes the cross-channel arrow render on the frontend.
      relatedMessageId: ticket.description_message_id,
      toRecipients: emailResult.toEmail ? [emailResult.toEmail] : [],
      ccRecipients: emailResult.ccEmail ? [emailResult.ccEmail] : [],
      channel: 'email',
      deliveryStatus: emailResult.status,
      failureReason: emailResult.status === 'failed' ? emailResult.reason : null,
    })

    const waResult = await this.sendAckWhatsApp(ticket, fromPhone)
    const whatsappMessage = await TicketService.addMessage({
      ticketId: ticket.id,
      sender: 'system',
      type: 'reply',
      message: waResult.text,
      channel: 'whatsapp',
      deliveryStatus: waResult.status,
      failureReason: waResult.status === 'failed' ? waResult.reason : null,
    })

    return { emailMessage, whatsappMessage }
  }

  private static async sendAutoEmail(ticket: any, identification: any) {
    const toEmail = identification?.employeeEmail || identification?.orgEmail
    if (!toEmail) return { status: 'failed' as const, reason: 'No employee or organization email on record.', toEmail: undefined, ccEmail: undefined }

    // Employee found -> CC the organization (identification.orgEmail is always
    // populated by WhatsAppIdentificationService.identifyByPhone from
    // Organization.Email once the employee's OrganizationId is resolved — see
    // that file, lines ~42-55). Organization-only match -> no CC needed, the
    // "to" is already the org.
    // const ccEmail = identification?.type === 'employee' ? identification?.orgEmail : undefined
    const ccEmail = "ankursharmaiitm@gmail.com"

    try {
      const { default: EmailTemplateService } = await import('App/Services/EmailTemplateService')
      const { substituteTicketTemplate } = await import('App/Services/EmailToTicketService')
      const { default: Helper } = await import('App/Helper/helper')
      const templateHtml = await EmailTemplateService.get('auto_ticket_response')
      const html = substituteTicketTemplate(templateHtml, identification?.name, ticket.ticket_uid)
      const subject = `Your support ticket ${ticket.ticket_uid}`

      let mailboxEmail: string | undefined
      let conversationId: string | undefined
      try {
        // Preferred: send from the connected Outlook account marked default
        // (or whichever one an admin picked in Settings > Mail Accounts).
        const { default: MailAccountService } = await import('App/Services/MailAccountService')
        const sendResult = await MailAccountService.sendMail({ toEmail, ccEmail, subject, html })
        mailboxEmail = sendResult.mailboxEmail
        conversationId = sendResult.conversationId
      } catch (outlookErr: any) {
        // No Outlook account connected yet, or the send itself failed —
        // fall back to the SMTP relay so the customer still gets a reply.
        // console.error('[WhatsappService] Outlook send failed, falling back to SMTP:', outlookErr.message)
        // await Helper.sendEmail(toEmail, subject, html, 'X-Ticket-Uid', 'ubiSupport', 'noreply', ccEmail)
      }

      // Persist the thread so later agent replies from ubiDesk can Graph-reply
      // into it instead of having no conversation to attach to.
      if (mailboxEmail && conversationId) {
        await Database.from('tickets').where('id', ticket.id).update({ mailbox_email: mailboxEmail, mail_conversation_id: conversationId })
      }

      // displayHtml is footer-stripped — this is what shows in the ticket/chat
      // panel. `html` (full, footer included) is what actually goes to the customer.
      return { status: 'sent' as const, toEmail, ccEmail, html, displayHtml: Helper.stripEmailFooter(html) }
    } catch (err: any) {
      return { status: 'failed' as const, reason: (err.message || 'Email send failed').slice(0, 250), toEmail, ccEmail: undefined }
    }
  }

  private static async sendAckWhatsApp(ticket: any, fromPhone: string) {
    const ackText = `Thanks! Your support ticket number is *${ticket.ticket_uid}*.\n\nWe've also emailed you the details — please continue the conversation there.\n\nIs there anything else you'd like to share? Just send it here and we'll add it to your ticket.`
    try {
      await this.sendWhatsAppText(fromPhone, ackText)
      return { status: 'sent' as const, text: ackText }
    } catch (err: any) {
      const reason = err.response?.data?.error?.message || err.message || 'WhatsApp send failed'
      return { status: 'failed' as const, reason: reason.slice(0, 250), text: ackText }
    }
  }

  // ───────────────────────── Delivery/read receipts (Meta `statuses` webhook events) ─────────────────────────
  // Meta sends these as a SEPARATE webhook payload from inbound messages —
  // entry.changes[0].value.statuses[0], not .messages[0]. One event per
  // status hop (sent -> delivered -> read), matched back to our row via the
  // wamid we saved in graph_message_id when we sent it (see
  // WhatsappOutboundService.sendText).
  private static readonly STATUS_RANK: Record<string, number> = { sent: 1, delivered: 2, read: 3 }

  public static async updateDeliveryStatus(statusEvent: { id: string; status: string }): Promise<{ ticketId: number; message: any } | null> {
    const newStatus = statusEvent.status
    // [WA-TRACE W2] Confirms we're inside this function with a usable status string.
    console.log(`[WA-TRACE W2] updateDeliveryStatus called — wamid="${statusEvent.id}" (len ${statusEvent.id?.length}) newStatus="${newStatus}"`)
    if (!['sent', 'delivered', 'read', 'failed'].includes(newStatus)) {
      console.log(`[WA-TRACE W2-SKIP] unrecognized status "${newStatus}" — ignored`)
      return null
    }

    const msg = await Database.from('ticket_messages').where('graph_message_id', statusEvent.id).first()
    // [WA-TRACE W3] THE key checkpoint. If this logs "NOT FOUND", either:
    //   (a) graph_message_id was never saved for this message (check
    //       WA-TRACE S3/S4 in WhatsappOutboundService for that send), or
    //   (b) it WAS saved but got truncated by the column's max length, so it
    //       no longer matches the full wamid Meta sends back here — compare
    //       the wamid length logged in W2 above against
    //       `SHOW COLUMNS FROM ticket_messages LIKE 'graph_message_id'`.
    if (!msg) {
      console.log(`[WA-TRACE W3] NOT FOUND — no ticket_messages row has graph_message_id="${statusEvent.id}"`)
      return null
    }
    console.log(`[WA-TRACE W3] FOUND — msg.id=${msg.id} current delivery_status="${msg.delivery_status}" stored graph_message_id len=${msg.graph_message_id?.length}`)

    // Never let a late/out-of-order "sent" or "delivered" event downgrade a
    // tick that's already showing "read" — only move forward.
    if (newStatus !== 'failed' && this.STATUS_RANK[newStatus] <= this.STATUS_RANK[msg.delivery_status]) {
      // [WA-TRACE W4-SKIP] If you see THIS every time and never see W5, the
      // rank comparison is rejecting every update — check whether
      // msg.delivery_status is something STATUS_RANK doesn't recognize
      // (undefined maps to `undefined`, and `<= undefined` is always false,
      // so that's fine — but a typo'd/legacy status string stored in the DB
      // would also break this silently).
      console.log(`[WA-TRACE W4-SKIP] rank(${newStatus})=${this.STATUS_RANK[newStatus]} <= rank(${msg.delivery_status})=${this.STATUS_RANK[msg.delivery_status]} — not applying (stale/duplicate/out-of-order)`)
      return null
    }

    await Database.from('ticket_messages').where('id', msg.id).update({ delivery_status: newStatus })
    const updated = await Database.from('ticket_messages').where('id', msg.id).first()
    // [WA-TRACE W5] If this DOESN'T show delivery_status === newStatus, the
    // UPDATE itself silently failed to persist — classic symptom of the
    // column being a MySQL ENUM that doesn't include 'delivered'/'read' as
    // valid values (non-strict SQL mode swallows the invalid value instead
    // of throwing). Run `SHOW COLUMNS FROM ticket_messages LIKE
    // 'delivery_status'` and confirm the enum/type allows all 4 values.
    console.log(`[WA-TRACE W5] update applied — msg.id=${msg.id} delivery_status now="${updated.delivery_status}" (expected "${newStatus}")`)
    return { ticketId: msg.ticket_id, message: updated }
  }

  // ───────────────────────── Raw Graph API send ─────────────────────────
  public static async sendWhatsAppText(to: string, text: string) {
    const account = await this.getActiveAccount()
    await axios.post(
      `https://graph.facebook.com/${GRAPH_VERSION}/${account.phone_number_id}/messages`,
      { messaging_product: 'whatsapp', to, type: 'text', text: { body: text } },
      { headers: { Authorization: `Bearer ${account.access_token}`, 'Content-Type': 'application/json' }, timeout: 15000 }
    )
  }

  /**
   * Dispatch-only outbound send used by "New Chat" AND by replies inside an
   * existing conversation thread. Credentials are pulled from the DB — never
   * trust the frontend to supply phoneNumberId/accessToken.
   *
   * NOTE: does NOT write to ticket_messages. Persistence for "New Chat" already
   * happens in TicketController.create, and persistence for replies already
   * happens in the `ticket_message` Socket.io handler. Writing here too would
   * create duplicate message rows/UI bubbles.
   */
  public static async sendOutbound(params: { ticketId?: number; recipientPhone?: string; messageText: string }) {
    let recipientPhone = params.recipientPhone
    if (!recipientPhone && params.ticketId) {
      const ticket = await Database.from('tickets').where('id', params.ticketId).first()
      recipientPhone = ticket?.customer_phone
    }
    if (!recipientPhone) {
      throw new Error('recipientPhone is required (or pass a valid ticketId with a stored customer_phone).')
    }

    const account = await this.getActiveAccount()
    const apiResponse = await axios.post(
      `https://graph.facebook.com/${GRAPH_VERSION}/${account.phone_number_id}/messages`,
      { messaging_product: 'whatsapp', to: recipientPhone, type: 'text', text: { body: params.messageText } },
      { headers: { Authorization: `Bearer ${account.access_token}`, 'Content-Type': 'application/json' }, timeout: 15000 }
    )
    return apiResponse.data
  }

  // ───────────────────────── Account management ─────────────────────────
  public static async listActiveAccounts() {
    return Database.from('whatsapp_accounts')
      .where('is_active', 1)
      .select('id', 'phone_number_id', 'waba_id', 'display_phone_number', 'verified_name', 'connected_at')
  }

  public static async connectAccount(params: {
    phoneNumberId: string
    wabaId?: string
    displayPhoneNumber?: string
    accessToken: string
    agentId?: number | null
  }) {
    const metaRes = await axios.get(`https://graph.facebook.com/${GRAPH_VERSION}/${params.phoneNumberId}`, {
      headers: { Authorization: `Bearer ${params.accessToken}` },
    })

    const verifiedName = metaRes.data?.verified_name || metaRes.data?.display_phone_number || 'WhatsApp Account'
    const actualPhoneNumber = params.displayPhoneNumber || metaRes.data?.display_phone_number || params.phoneNumberId

    await Database.rawQuery(
      `INSERT INTO whatsapp_accounts
        (phone_number_id, waba_id, display_phone_number, verified_name, access_token, webhook_verify_token, is_active, connected_by_agent_id, connected_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW(), NOW(), NOW())
       ON DUPLICATE KEY UPDATE
        waba_id = VALUES(waba_id),
        display_phone_number = VALUES(display_phone_number),
        verified_name = VALUES(verified_name),
        access_token = VALUES(access_token),
        is_active = 1,
        updated_at = NOW()`,
      [params.phoneNumberId, params.wabaId || '', actualPhoneNumber, verifiedName, params.accessToken, WA_VERIFY_TOKEN, params.agentId ?? null]
    )

    return { verifiedName }
  }

  public static async disconnectAccount(id: number) {
    await Database.from('whatsapp_accounts').where('id', id).update({ is_active: 0, updated_at: new Date() })
  }

  // ───────────────────────── Retry a failed outbound message ─────────────────────────
  public static async retryMessage(messageId: number) {
    const msg = await Database.from('ticket_messages').where('id', messageId).first()
    if (!msg) return { notFound: true as const }
    if (msg.delivery_status !== 'failed') return { notFailed: true as const }

    const ticket = await Database.from('tickets').where('id', msg.ticket_id).first()
    if (!ticket) return { ticketNotFound: true as const }

    let result: { status: 'sent' | 'failed'; reason?: string }

    if (msg.channel === 'email') {
      // ROOT CAUSE of a retried email going out from the wrong address with
      // a broken thread: this used to call Helper.sendEmail — a raw SMTP
      // send from a hardcoded noreply@notify.ubihrm.com address, completely
      // bypassing the ticket's actual connected mailbox and Graph
      // conversation. That's a DIFFERENT, disconnected email, not a retry
      // of the one that failed. Retrying an email reply must go back out
      // the same way a normal reply does — through the ticket's own
      // mailbox, on the same Graph thread — so it reuses
      // EmailToTicketService.sendAgentReplyByEmail with exactly what was
      // stored on this row (recipients, reply mode, the agent who sent it,
      // and any attachments), the same as a fresh send.
      const toRecipients: string[] = msg.to_recipients ? JSON.parse(msg.to_recipients) : []
      const ccRecipients: string[] = msg.cc_recipients ? JSON.parse(msg.cc_recipients) : []
      const bccRecipients: string[] = msg.bcc_recipients ? JSON.parse(msg.bcc_recipients) : []
      if (!toRecipients.length && !ticket.customer_email) {
        result = { status: 'failed', reason: 'No recipient stored on this message.' }
      } else {
        try {
          const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
          const attachmentRows = await Database.from('ticket_attachments').where('message_id', msg.id)
          await EmailToTicketService.sendAgentReplyByEmail(
            msg.ticket_id,
            msg.message,
            (msg.reply_mode as 'reply' | 'reply_all' | 'reply_selected' | 'forward') || 'reply',
            { to: toRecipients, cc: ccRecipients, bcc: bccRecipients },
            msg.agent_id ?? undefined,
            attachmentRows.map((a: any) => ({
              fileName: a.file_name, contentType: a.content_type, size: a.size, storagePath: a.storage_path,
            })),
            msg.id
          )
          result = { status: 'sent' }
        } catch (err: any) {
          result = { status: 'failed', reason: (err.response?.data?.error?.message || err.message || 'Retry failed').slice(0, 250) }
        }
      }
    } else if (msg.channel === 'whatsapp') {
      try {
        await this.sendWhatsAppText(ticket.customer_phone, msg.message)
        result = { status: 'sent' }
      } catch (err: any) {
        const reason = err.response?.data?.error?.message || err.message || 'Retry failed'
        result = { status: 'failed', reason: reason.slice(0, 250) }
      }
    } else {
      return { unknownChannel: true as const }
    }

    await Database.from('ticket_messages').where('id', msg.id).update({
      delivery_status: result.status,
      failure_reason: result.status === 'failed' ? result.reason : null,
      retry_count: Database.raw('retry_count + 1'),
    })
    const updated = await Database.from('ticket_messages').where('id', msg.id).first()

    return { updated, ticketId: ticket.id, success: result.status === 'sent' }
  }
}