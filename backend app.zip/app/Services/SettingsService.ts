import Database from '@ioc:Adonis/Lucid/Database'

const DEFAULTS: Record<string, string> = {
  auto_respond_message: 'Thanks for reaching out! We have received your email and automatically logged it into our support system.',
}

export default class SettingsService {
  public static async getAll() {
    const rows = await Database.from('app_settings')
    const result = { ...DEFAULTS }
    for (const r of rows) result[r.setting_key] = r.setting_value
    return result
  }

  public static async get(key: string) {
    const row = await Database.from('app_settings').where('setting_key', key).first()
    return row?.setting_value ?? DEFAULTS[key] ?? null
  }

  public static async set(key: string, value: string, agentId: number) {
    const existing = await Database.from('app_settings').where('setting_key', key).first()
    if (existing) {
      await Database.from('app_settings').where('setting_key', key).update({ setting_value: value, updated_by: agentId, updated_at: new Date() })
    } else {
      await Database.table('app_settings').insert({ setting_key: key, setting_value: value, updated_by: agentId, updated_at: new Date() })
    }
    return { status: true }
  }
}