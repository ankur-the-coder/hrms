import Database from '@ioc:Adonis/Lucid/Database'
import { io } from '../../start/socket'
import Helper from 'App/Helper/helper'

export default class ChatService {


public static async getDeletedSessions(offset = 0) {
  const sessions = await Database.from('chat_sessions')
    .whereNotNull('deleted_at')
    .orderBy('deleted_at', 'desc')
    .limit(10).offset(offset)

  const [{ total }] = await Database.from('chat_sessions')
    .whereNotNull('deleted_at').count('* as total')

  return { status: true, data: sessions, total: Number(total) }
}

public static async deleteSession(sessionId: number) {
  const session = await Database.from('chat_sessions').where('id', sessionId).first()
  if (!session) return { status: false, msg: 'Session not found' }

  await Database.from('chat_sessions').where('id', sessionId).update({
    deleted_at: new Date(),  
    deleted_widget_key: session.widget_key,
  })
  io.emit('queue_updated')
  return { status: true, msg: 'Session moved to deleted' }
}



} 