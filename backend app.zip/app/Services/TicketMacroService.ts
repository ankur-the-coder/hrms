import Database from '@ioc:Adonis/Lucid/Database'
import TicketService from 'App/Services/TicketService'

export default class TicketMacroService {
  public static async list() {
    return Database.from('ticket_macros').where('is_active', 1).orderBy('name', 'asc')
  }

  public static async create(data: {
    name: string; description?: string
    setStatus?: string; setPriority?: string; setAssignedTo?: number
    cannedReply?: string; createdBy?: number
  }) {
    const [id] = await Database.table('ticket_macros').insert({
      name: data.name,
      description: data.description ?? null,
      set_status: data.setStatus ?? null,
      set_priority: data.setPriority ?? null,
      set_assigned_to: data.setAssignedTo ?? null,
      canned_reply: data.cannedReply ?? null,
      created_by: data.createdBy ?? null,
      created_at: new Date(),
      updated_at: new Date(),
    })
    return Database.from('ticket_macros').where('id', id).first()
  }

  public static async update(id: number, data: {
    name?: string; description?: string
    setStatus?: string; setPriority?: string; setAssignedTo?: number
    cannedReply?: string; isActive?: boolean
  }) {
    const patch: any = { updated_at: new Date() }
    if (data.name !== undefined) patch.name = data.name
    if (data.description !== undefined) patch.description = data.description
    if (data.setStatus !== undefined) patch.set_status = data.setStatus
    if (data.setPriority !== undefined) patch.set_priority = data.setPriority
    if (data.setAssignedTo !== undefined) patch.set_assigned_to = data.setAssignedTo
    if (data.cannedReply !== undefined) patch.canned_reply = data.cannedReply
    if (data.isActive !== undefined) patch.is_active = data.isActive ? 1 : 0
    await Database.from('ticket_macros').where('id', id).update(patch)
    return Database.from('ticket_macros').where('id', id).first()
  }

  public static async remove(id: number) {
    await Database.from('ticket_macros').where('id', id).update({ is_active: 0, updated_at: new Date() })
    return { status: true }
  }

  /** Applies a macro's field changes + canned reply to every ticket in ticketIds. */
  public static async apply(ticketIds: number[], macroId: number, requester: any) {
    const macro = await Database.from('ticket_macros').where('id', macroId).where('is_active', 1).first()
    if (!macro) throw new Error('Macro not found')

    for (const ticketId of ticketIds) {
      const patch: any = { updated_at: new Date() }
      if (macro.set_status) patch.status = macro.set_status
      if (macro.set_priority) patch.priority = macro.set_priority
      if (Object.keys(patch).length > 1) {
        await Database.from('tickets').where('id', ticketId).update(patch)
      }
      if (macro.set_assigned_to) {
        const agent = await Database.from('support_agents').where('id', macro.set_assigned_to).first()
        if (agent) {
          await TicketService.assignTicket(ticketId, macro.set_assigned_to, agent.name, requester).catch(() => {})
        }
      }
      if (macro.canned_reply) {
        await TicketService.addMessage({
          ticketId, sender: 'agent', type: 'reply', message: macro.canned_reply, requester,
        }).catch((err) => console.error(`[TicketMacroService] canned reply failed for ticket ${ticketId}:`, err.message))
      }
    }
    return { status: true, count: ticketIds.length }
  }
}
