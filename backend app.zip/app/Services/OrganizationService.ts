import Database from '@ioc:Adonis/Lucid/Database'

/**
 * Backs the new "Organizations" tab (sibling to Contacts). Unlike
 * ContactController's ticket_contacts (which we own and populate
 * ourselves from inbound tickets), `Organization` is the shared legacy
 * ERP table — every org that has ever signed up, not just ones that have
 * raised a support ticket. So this lists straight from `Organization`
 * rather than deriving from tickets.
 *
 * Priority is tracked separately in `ticket_priority_organizations` (see
 * migrations/2026_08_20_priority_contacts_and_organizations.sql) — we
 * never write to `Organization` itself. That's the one join kept below;
 * it's what backs the "Mark High Priority" toggle on this page. Everything
 * else — including lead/support owner — now comes straight off
 * `Organization` (leadowner_id / supportowner_id columns) with no other
 * table involved, since those name-lookup joins weren't indexed and were
 * a big part of why this listing was slow.
 */
export default class OrganizationService {
  public static async listOrganizations(offset = 0, limit = 20, search = '', highPriorityOnly = false, withTicketsOnly = false) {
    const trimmedSearch = search.trim()

    const countQuery = Database.from('Organization as o').where('o.delete_sts', 0)
    const rowsQuery = Database.from('Organization as o').where('o.delete_sts', 0)

    if (highPriorityOnly) {
      countQuery.innerJoin('ticket_priority_organizations as p', 'p.org_id', 'o.Id').where('p.is_high_priority', 1)
      rowsQuery.leftJoin('ticket_priority_organizations as p', 'p.org_id', 'o.Id').where('p.is_high_priority', 1)
    } else {
      rowsQuery.leftJoin('ticket_priority_organizations as p', 'p.org_id', 'o.Id')
    }

    // NEW: restrict to organizations that actually own at least one ticket
    // — open, closed, OR deleted (deliberately no deleted_at/is_spam
    // filter here; "holds any ticket" means any row at all in `tickets`
    // with this org as sender_org_id). Used by the ticket-list
    // "Organization" filter dropdown, which has no use for an org that's
    // never actually raised a ticket.
    if (withTicketsOnly) {
      const hasTicket = (b: any) => b.whereExists((sub: any) =>
        sub.from('tickets as t').whereRaw('t.sender_org_id = o.Id')
      )
      countQuery.where(hasTicket)
      rowsQuery.where(hasTicket)
    }

    if (trimmedSearch) {
      const applySearch = (b: any) => {
        b.where('o.Name', 'like', `%${trimmedSearch}%`)
          .orWhere('o.Email', 'like', `%${trimmedSearch}%`)
      }
      countQuery.where(applySearch)
      rowsQuery.where(applySearch)
    }

    // Count and data run concurrently instead of one after the other —
    // they're independent reads, so awaiting them in sequence was doubling
    // round-trip latency on every request for no reason.
    const [total, rows] = await Promise.all([
      countQuery.count('o.Id as total').first(),
      rowsQuery
        .select(
          'o.Id as orgId',
          'o.Name as orgName',
          'o.Email as orgEmail',
          'o.leadowner_id as leadOwnerId',
          'o.supportowner_id as supportOwnerId',
          Database.raw('COALESCE(p.is_high_priority, 0) as is_high_priority'),
        )
        .orderBy('o.Name', 'asc')
        .offset(offset)
        .limit(limit),
    ])

    return {
      data: rows,
      totalRecords: Number(total?.total ?? 0),
    }
  }

  /**
   * Flip (or set) the high-priority flag for an org. Upserts — most orgs
   * won't have a row here until the first time an agent flags them.
   *
   * Same "open and incoming" rule as ContactService.setPriority: turning
   * this ON also bumps every currently non-closed ticket already open for
   * this org (matched via tickets.sender_org_id) to priority='high', not
   * just tickets created after this point. Turning it OFF doesn't walk
   * existing tickets back down.
   */
  public static async setPriority(orgId: number, orgName: string | null, isHighPriority: boolean, agentId?: number) {
    const existing = await Database.from('ticket_priority_organizations').where('org_id', orgId).first()
    if (existing) {
      await Database.from('ticket_priority_organizations').where('org_id', orgId).update({
        is_high_priority: isHighPriority ? 1 : 0,
        org_name: orgName ?? existing.org_name,
        marked_by: agentId ?? existing.marked_by,
        updated_at: new Date(),
      })
    } else {
      await Database.table('ticket_priority_organizations').insert({
        org_id: orgId,
        org_name: orgName,
        is_high_priority: isHighPriority ? 1 : 0,
        marked_by: agentId ?? null,
        created_at: new Date(),
        updated_at: new Date(),
      })
    }

    let updatedTickets = 0
    if (isHighPriority) {
      // Same Lucid `.update()` typing quirk as ContactService.setPriority —
      // normalize before assigning to `number`.
      const result = await Database.from('tickets')
        .where('sender_org_id', orgId)
        .whereNot('status', 'closed')
        .update({ priority: 'high', updated_at: new Date() })
      updatedTickets = Array.isArray(result) ? result.length : Number(result)
    }

    return { status: true, orgId, is_high_priority: isHighPriority, updatedTickets }
  }

  /** Used by TicketService.createTicket to decide the default priority. */
  public static async isHighPriority(orgId?: number | null): Promise<boolean> {
    if (!orgId) return false
    const row = await Database.from('ticket_priority_organizations')
      .where('org_id', orgId)
      .where('is_high_priority', 1)
      .first()
    return !!row
  }
}