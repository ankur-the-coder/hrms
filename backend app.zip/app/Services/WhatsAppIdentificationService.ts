import TestUtils from '@ioc:Adonis/Core/TestUtils';
import Database from '@ioc:Adonis/Lucid/Database'
import Helper from 'App/Helper/helper';
import MailIdentificationService from 'App/Services/MailIdentificationService'

export type WaSenderIdentification =
  | { type: 'employee'; orgId: number; employeeId: number; employeeEmail: string | null; orgEmail: string | null; name: string; orgName: string; logoUrl: string; profileUrl: string }
  | { type: 'organization'; orgId: number; employeeId: null; employeeEmail: null; orgEmail: string | null; name: string; orgName: string; logoUrl: string }
  | { type: 'unidentified'; orgId: null; employeeId: null; employeeEmail: null; orgEmail: null; name: null; orgName: null; logoUrl: null }

export default class WhatsAppIdentificationService {


  public static async identifyByPhone(rawPhone: string): Promise<WaSenderIdentification> {
const digits = Helper.getNationalNumber(rawPhone)
if (!digits) return this.unidentified()

// 1. Encode the target digits once in-memory
const encodedPhoneNumber = Helper.encode5t(digits)

// 2. Search EmployeeMaster using indexed exact match on the encoded value
let employee = await Database.from('EmployeeMaster')
  .where('CurrentContactNumber', encodedPhoneNumber)
  .select('Id', 'OrganizationId', 'FirstName', 'LastName', 'ImageName', 'CompanyEmail', 'CurrentEmailId')
  .first()

// 3. Fallback: Search UserMaster using indexed exact match on the encoded value
if (!employee) {
  const userRow = await Database.from('UserMaster')
    .where('username_mobile', encodedPhoneNumber)
    .select('EmployeeId')
    .first()

  if (userRow?.EmployeeId) {
    employee = await Database.from('EmployeeMaster')
      .where('Id', userRow.EmployeeId)
      .select('Id', 'OrganizationId', 'FirstName', 'LastName', 'ImageName', 'CompanyEmail', 'CurrentEmailId')
      .first()
  }
}

    if (employee) {
      const org = await Database.from('Organization').where('Id', employee.OrganizationId)
        .select('Id', 'Name', 'Email', 'AltEmail').first()

      const employeeEmail =  (Helper.decode5t(employee.CurrentEmailId)) || employee.CompanyEmail 
      const fullName = employee.FirstName || ''
      const profileUrl = MailIdentificationService.buildProfileImageUrl(employee.OrganizationId, employee.ImageName) || ''
      const logoUrl = await MailIdentificationService.getPreferredLogo(String(employee.OrganizationId), employee.Id) || ''
     console.log('this is profile Url:',profileUrl, "logo Url:",logoUrl)
      return {
        type: 'employee', orgId: employee.OrganizationId, employeeId: employee.Id,
        employeeEmail: employeeEmail || null, orgEmail: org?.Email || null,
        name: fullName, orgName: org?.Name || '', logoUrl, profileUrl
      }
    }

    // 3. No employee anywhere -> Organization.PhoneNumber / AltPhoneNumber (plain text)
    const org = await Database.from('Organization')
      .where('PhoneNumber', 'like', `%${digits}`)
      .orWhere('AltPhoneNumber', 'like', `%${digits}`)
      .select('Id', 'Name', 'Email', 'AltEmail')
      .first()

    if (org) {
      const logoUrl = await MailIdentificationService.getPreferredLogo(String(org.Id))
      return {
        type: 'organization', orgId: org.Id, employeeId: null,
        employeeEmail: null, orgEmail: org.Email || null,
        name: org.Name, orgName: org.Name, logoUrl,
      }
    }

    return this.unidentified()
  }



  private static unidentified(): WaSenderIdentification {
    return { type: 'unidentified', orgId: null, employeeId: null, employeeEmail: null, orgEmail: null, name: null, orgName: null, logoUrl: null }
  }


}