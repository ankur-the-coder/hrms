import Database from '@ioc:Adonis/Lucid/Database'

export default class ContactService {
// ContactService.ts — corrected
public static async upsertFromTicket(data: { name: string; phone?: string; email?: string; source: string }) {
  const existing = await Database.from('ticket_contacts')
    .where((q) => {
      if (data.phone) q.orWhere('phone', data.phone)
      if (data.email) q.orWhere('email', data.email)
    })
    .first()

  if (existing) {
    await Database.from('ticket_contacts').where('id', existing.id).update({
      last_seen_at: new Date(), ticket_count: existing.ticket_count + 1, name: data.name,
    })
  } else {
    await Database.table('ticket_contacts').insert({   // ← .table() not .from()
      name: data.name, phone: data.phone ?? null, email: data.email ?? null,
      source: data.source, first_seen_at: new Date(), last_seen_at: new Date(), ticket_count: 1,
    })
  }
}

  public static async getContacts(offset = 0, limit = 50, search = '', highPriorityOnly = false) {
    const q = Database.from('ticket_contacts')
    // Plain `like` (not Lucid's whereLike/whereILike helpers) — those
    // helpers force `COLLATE utf8_bin` onto the comparison, which MySQL
    // rejects outright against utf8mb4 columns ("COLLATE utf8_bin is not
    // valid for CHARACTER SET utf8mb4"). A bare `like` lets MySQL use the
    // column's own (already case-insensitive, _ci) collation instead.
    if (search) {
      const term = `%${search}%`
      q.where((b) => b.where('name', 'like', term).orWhere('phone', 'like', term).orWhere('email', 'like', term))
    }
    if (highPriorityOnly) q.where('is_high_priority', 1)
    return q.orderBy('last_seen_at', 'desc').offset(offset).limit(limit)
  }

  /**
   * Flip (or set) the high-priority flag for a contact. When turning it
   * ON, also bumps every currently non-closed ticket already open for this
   * contact to priority='high' — matches the stated rule ("all the OPEN
   * and incoming tickets"), not just tickets created after this point.
   * Turning it OFF deliberately does NOT walk existing tickets back down;
   * an agent may have manually raised one of them for unrelated reasons.
   */
  public static async setPriority(id: number, isHighPriority: boolean) {
    const contact = await Database.from('ticket_contacts').where('id', id).first()
    if (!contact) return { status: false, msg: 'Contact not found' }

    await Database.from('ticket_contacts').where('id', id).update({ is_high_priority: isHighPriority ? 1 : 0 })

    let updatedTickets = 0
    if (isHighPriority) {
      // Lucid's `.update()` types as `any[]` (some drivers return affected
      // rows/ids, others an empty array) rather than the row count directly
      // — normalize instead of assigning it straight to a `number`.
      const result = await Database.from('tickets')
        .where((q) => {
          if (contact.phone) q.orWhere('customer_phone', contact.phone)
          if (contact.email) q.orWhere('customer_email', contact.email)
        })
        .whereNot('status', 'closed')
        .update({ priority: 'high', updated_at: new Date() })
      updatedTickets = Array.isArray(result) ? result.length : Number(result)
    }

    return { status: true, id, is_high_priority: isHighPriority, updatedTickets }
  }

  /**
   * Used by TicketService.createTicket to decide the default priority for
   * a new/incoming ticket — matched the same way upsertFromTicket() finds
   * an existing contact (by phone OR email).
   */
  public static async isHighPriority(phone?: string | null, email?: string | null): Promise<boolean> {
    if (!phone && !email) return false
    const existing = await Database.from('ticket_contacts')
      .where((q) => {
        if (phone) q.orWhere('phone', phone)
        if (email) q.orWhere('email', email)
      })
      .where('is_high_priority', 1)
      .first()
    return !!existing
  }
}