import Database from '@ioc:Adonis/Lucid/Database'
import Helper from 'App/Helper/helper'
import TicketClassifier from 'App/Helper/TicketClassifier'
import { randomUUID } from 'node:crypto'

const VALID_STATUSES = ['open', 'on_hold', 'escalated', 'closed'] as const

// Shared scope for every dashboard widget: excludes deleted/spam tickets,
// restricts to the selected day window (by created_at), and — for the
// widgets that are meant to be per-agent (not the explicitly "universal"
// ones: getTicketsTrend, getAgentWorkload) — restricts to the requester's
// own assigned tickets (+ unassigned) unless they're an admin. Same
// visibility rule getTickets()/getStatusCounts() already use.
function applyDashboardScope(q: any, requesterId?: number, requesterRole?: string, days = 7) {
  q.whereRaw('created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)', [Math.max(1, days) - 1])
  if (requesterRole && requesterRole !== 'admin') {
    q.where((b: any) => {
      b.whereNull('assigned_to')
      if (requesterId !== undefined) b.orWhere('assigned_to', requesterId)
    })
  }
  return q
}

export default class TicketService {

  /**
   * A ticket's default priority bumps to 'high' when the customer is tied
   * to a contact OR an organization that's been flagged "High Priority"
   * (Contacts tab / new Organizations tab). Checked on every create path —
   * manual, email intake, and WhatsApp intake all funnel through
   * createTicket(). Deliberately unconditional per the business rule ("all
   * open/incoming tickets from a flagged contact or org default to high")
   * — an agent can still change it afterwards from the ticket detail view,
   * this only sets what it starts as.
   */
  private static async resolveDefaultPriority(data: any): Promise<'low' | 'medium' | 'high'> {
    if (data.priority === 'high') return 'high' // already explicit, nothing to resolve
    try {
      const { default: ContactService } = await import('App/Services/ContactService')
      const { default: OrganizationService } = await import('App/Services/OrganizationService')
      const [contactFlagged, orgFlagged] = await Promise.all([
        ContactService.isHighPriority(data.customerPhone, data.customerEmail),
        OrganizationService.isHighPriority(data.senderOrgId),
      ])
      if (contactFlagged || orgFlagged) return 'high'
    } catch (err: any) {
      console.error('[TicketService] priority-flag lookup failed — falling back to requested/default priority:', err.message)
    }
    return data.priority ?? 'medium'
  }

  /**
   * Generates a fresh, guaranteed-unique ticket_uid. Pulled out of
   * createTicket() so the Add Ticket modal can fetch one up front (GET
   * /tickets/next-uid) and show the agent the real ID *before* they hit
   * Submit — createTicket() then reuses that exact value instead of
   * generating a second, different one.
   */
  public static async generateTicketUid(): Promise<string> {
    for (let attempt = 0; attempt < 5; attempt++) {
      const uid = `UBI-${String(Date.now()).slice(-6)}`
      const clash = await Database.from('tickets').where('ticket_uid', uid).first()
      if (!clash) return uid
      await new Promise((resolve) => setTimeout(resolve, 2)) // nudge Date.now() forward, then retry
    }
    // Extremely unlikely fallback if the timestamp-based id kept colliding.
    return `UBI-${randomUUID().slice(0, 8).toUpperCase()}`
  }

  public static async createTicket(data: any) {
    console.log('this is data inside createTicket',data)
    // Reuse the UID the Add Ticket modal already showed the agent
    // (data.ticketUid, from GET /tickets/next-uid) as long as it's still
    // free — falls back to generating a new one for every other caller
    // (email intake, WhatsApp intake, dummy generator) and for the rare
    // case that UID got claimed by another ticket in the meantime.
    const uid = data.ticketUid && !(await Database.from('tickets').where('ticket_uid', data.ticketUid).first())
      ? data.ticketUid
      : await this.generateTicketUid()
    const resolvedPriority = await this.resolveDefaultPriority(data)
    const [id] = await Database.table('tickets').insert({
      ticket_uid: uid,
      customer_name: data.customerName,
      customer_phone: data.customerPhone ?? null,
      customer_email: data.customerEmail ?? null,
      source: data.source,
      // Was hardcoded to 'open' — manual ticket creation from the frontend
      // modal always got 'open' no matter what status was picked in the
      // dropdown. Now respects data.status (validated against the same
      // VALID_STATUSES the update-status endpoint uses), still defaulting
      // to 'open' for automated intake paths (email/WhatsApp) that never
      // pass a status at all.
      status: VALID_STATUSES.includes(data.status) ? data.status : 'open',
      is_read: 0, // new tickets always start unread
      // ROOT CAUSE of "new ticket shows up at the bottom instead of the
      // top": getTickets() orders by `last_message_at DESC`, and this
      // column was never set at creation — leaving it NULL. MySQL sorts
      // NULLs as the lowest value, so in DESC order a brand-new ticket
      // sank to the very end of the list until its first addMessage() call
      // (which does set it) finally happened. Setting it here means a
      // fresh ticket sorts to the top immediately, same as any ticket that
      // just received a new message.
      last_message_at: new Date(),
      priority: resolvedPriority,
      mail_conversation_id: data.mailConversationId ?? null,
      mailbox_email: data.mailboxEmail ?? null,
      sender_identification: data.senderIdentification ?? null,
      sender_org_id: data.senderOrgId ?? null,
      sender_org_name: data.senderOrgName ?? null,
      sender_employee_id: data.senderEmployeeId ?? null,
  sender_logo_url: data.senderLogoUrl ?? null,
      sender_emp_url: data.senderEmpUrl ?? null,
      assigned_to: data.assignedTo ?? null,
      assigned_agent_name: data.assignedAgentName ?? null,
      created_at: new Date(),
      updated_at: new Date(),
       subject: data.subject ?? null,
    })

    let descriptionMessageId: number | null = null
    // BUG FIX: this used to be `if (data.description)` — a plain truthiness
    // check. EmailToTicketService derives `description` by stripping the
    // <img> tag out of the HTML body (see htmlToPlainText) before it ever
    // gets here — so a customer email whose ENTIRE body is a single inline
    // image (no typed text at all) produces an empty string. An empty
    // string is falsy, so this block was skipped completely: no
    // ticket_messages row got created for the message at all. Downstream,
    // EmailToTicketService looks up `firstMessage` and only calls
    // resolveInlineAttachments()/persistPendingAttachments() `if
    // (firstMessage && bodyHtml)` — with no row to find, firstMessage was
    // undefined, so the inline image AND any real attachments on that same
    // message were never fetched from Outlook or uploaded to S3 at all.
    // This is why the bug only ever showed up on image/attachment-only
    // messages with no typed body text, and never on a normal reply.
    //
    // `!= null` creates the row whenever a description was actually
    // supplied (including ''), and only skips it when the field was never
    // passed at all — every current caller (email intake, WhatsApp intake,
    // manual ticket creation, the dummy-ticket generator) always passes a
    // description string, so this is a strict widening, not a behavior
    // change for any existing non-empty-body path.
    if (data.description != null) {
     const [msgId] =  await Database.table('ticket_messages').insert({
        ticket_id: id,
        sender: 'customer',
        type: 'reply',
        message: data.description,
        sender_name: data.customerName ?? null,
        sender_email: data.customerEmail ?? null,
        to_recipients: JSON.stringify(data.toRecipients ?? []),
        cc_recipients: JSON.stringify(data.ccRecipients ?? []),
        bcc_recipients: JSON.stringify(data.bccRecipients ?? []),
        graph_message_id: data.graphMessageId ?? null,
        created_at: new Date(),
      })
      descriptionMessageId = msgId    
    }

    const { default: ContactService } = await import('App/Services/ContactService')
    await ContactService.upsertFromTicket({
      name: data.customerName,
      phone: data.customerPhone,
      email: data.customerEmail,
      source: data.source,
    }).catch(() => {})

    // Mirror the CC recipients into ticket_cc_participants (same table/path
    // the email-intake flow uses) so the panel's "CC" chip on the ticket
    // detail view actually shows them — previously they only lived on the
    // ticket_messages row, which is enough to send the mail but invisible
    // in the UI.
    if (data.ccRecipients?.length) {
      const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
      await EmailToTicketService.upsertCcParticipants(id, data.ccRecipients).catch((err: any) =>
        console.error(`[TicketService] CC participant upsert failed for ticket ${id}:`, err.message)
      )
    }

    // Ticket was auto-assigned at creation time (support-owner match on
    // email intake, or manual-creation auto-assign) — log it as the first
    // link in ticket_assignment_history. Without this, a later reassignment
    // shows only the new agent's name instead of "Ashad → Jatin".
    if (data.assignedTo) {
      await Database.table('ticket_assignment_history').insert({
        ticket_id: id,
        agent_id: data.assignedTo,
        agent_name: data.assignedAgentName ?? null,
        assigned_by: null, // system/auto-assigned, not a specific requester
        created_at: new Date(),
      })
    }

    const ticketRow = await Database.from('tickets').where('id', id).first()
    // description_message_id isn't a persisted column on `tickets` — merged in
    // here so callers (e.g. WhatsappService) can set relatedMessageId on an
    // auto-response and get cross-channel arrow pairing on the frontend.
    return { ...ticketRow, description_message_id: descriptionMessageId }
  }

  /**
   * List tickets for the card view. Adds thread_count (all messages) and
   * comment_count (internal_note messages only) via subqueries, and
   * excludes spam / merged-away tickets unless explicitly asked for.
   */
public static async getTickets(offset = 0, limit = 20, filters: any = {}) {
  const q = Database.from('tickets')
    .select('tickets.*')
    .select(
      Database.raw(`
        CASE
          WHEN tickets.priority = 'high' THEN 'high'
          WHEN EXISTS (
            SELECT 1 FROM ticket_priority_organizations tpo
            WHERE tpo.org_id = tickets.sender_org_id 
              AND tpo.is_high_priority = 1
          ) THEN 'high'
          WHEN EXISTS (
            SELECT 1 FROM ticket_contacts tc
            WHERE tc.is_high_priority = 1
              AND (
                (tickets.customer_email IS NOT NULL AND tc.email = tickets.customer_email)
                OR (tickets.customer_phone IS NOT NULL AND tc.phone = tickets.customer_phone)
              )
          ) THEN 'high'
          ELSE tickets.priority
        END AS computed_priority
      `)
    )
    .select(
      Database.raw(
        `(SELECT COUNT(*) FROM ticket_messages tm WHERE tm.ticket_id = tickets.id) AS thread_count`
      )
    )
    .select(
      Database.raw(
        `(SELECT COUNT(*) FROM ticket_messages tm2 WHERE tm2.ticket_id = tickets.id AND tm2.type = 'internal_note') AS comment_count`
      )
    )
    .select(
      Database.raw(
        `(SELECT GROUP_CONCAT(agent_name ORDER BY created_at ASC SEPARATOR '||') FROM ticket_assignment_history tah WHERE tah.ticket_id = tickets.id) AS assignment_chain_raw`
      )
    )

  if (!filters.includeSpam) q.where('is_spam', 0)
  
  if (filters.resolvedToday || filters.status === 'resolved_today') {
    q.where('status', 'closed').whereRaw('DATE(updated_at) = CURDATE()')
  } else if (filters.status === 'reopened') {
    // FIX: a ticket that was reopened and then closed again should show up
    // in "Closed", not linger in "Re-opened" forever just because
    // reopen_count is still > 0 from history. "Re-opened" is now strictly
    // "currently open/on_hold/escalated AND has been reopened at least
    // once" — the moment it's closed again it belongs to the Closed tab
    // (and getStatusCounts below matches this exactly).
    q.where('reopen_count', '>', 0).whereNot('status', 'closed')
  } else if (filters.status === 'rated') {
    q.whereNotNull('rating')
  } else if (filters.status) {
    q.where('status', filters.status)
  }

  if (filters.priority) {
    if (filters.priority === 'high') {
      q.where((b) =>
        b
          .where('tickets.priority', 'high')
          .orWhereExists((sub) =>
            sub
              .from('ticket_priority_organizations as tpo')
              .whereRaw('tpo.org_id = tickets.sender_org_id AND tpo.is_high_priority = 1')
          )
          .orWhereExists((sub) =>
            sub
              .from('ticket_contacts as tc')
              .whereRaw(
                'tc.is_high_priority = 1 AND ((tickets.customer_email IS NOT NULL AND tc.email = tickets.customer_email) OR (tickets.customer_phone IS NOT NULL AND tc.phone = tickets.customer_phone))'
              )
          )
      )
    } else {
      q.where('tickets.priority', filters.priority)
    }
  }
  
  if (filters.unassignedOnly) {
    q.whereNull('assigned_to')
  }

  if (filters.source) q.where('source', filters.source)
  if (filters.unreadOnly) q.where('is_read', 0)
  
  if (filters.deletedOnly) {
    q.whereNotNull('deleted_at')
  } else {
    q.whereNull('deleted_at')
  }
  
  if (filters.search) {
    // Plain `like`, not Lucid's whereILike — whereILike forces
    // `COLLATE utf8_bin` onto the comparison, which MySQL rejects against
    // utf8mb4 columns. Bare `like` uses the column's own (already
    // case-insensitive) collation instead. See ContactService.getContacts
    // for the same fix — the ticket_contacts search hit this same error.
    const term = `%${filters.search}%`
    q.where((b) =>
      b
        .where('customer_name', 'like', term)
        .orWhere('ticket_uid', 'like', term)
        .orWhere('customer_phone', 'like', term)
        .orWhere('customer_email', 'like', term)
        .orWhere('sender_org_name', 'like', term)
        .orWhere('subject', 'like', term)
    )
  }

  if (filters.requesterRole && filters.requesterRole !== 'admin') {
    q.where((b) => b.whereNull('assigned_to').orWhere('assigned_to', filters.requesterId))
  }

  // Admin-only "Assigned To" filter (see TicketController.list — non-admin
  // requests never reach here with a populated assignedTo array).
  if (filters.assignedTo?.length) {
    q.whereIn('assigned_to', filters.assignedTo)
  }

  // Organization-wise filter — matched on tickets.sender_org_id (the same
  // column the "high priority org" join above already uses), so this lines
  // up exactly with the org a ticket is attributed to on the Organizations
  // tab. Multi-select: whereIn against however many orgs were picked.
  if (filters.orgId?.length) {
    q.whereIn('tickets.sender_org_id', filters.orgId)
  }

  // Contact-wise filter — a ticket has no contactId FK, so match the same
  // way ContactService itself resolves a contact (by email OR phone).
  // Frontend sends whichever identifier(s) each selected contact actually
  // has; multi-select, so any of the emails/phones in either list is
  // enough to match.
  if (filters.contactEmail?.length || filters.contactPhone?.length) {
    q.where((b) => {
      if (filters.contactEmail?.length) b.orWhereIn('tickets.customer_email', filters.contactEmail)
      if (filters.contactPhone?.length) b.orWhereIn('tickets.customer_phone', filters.contactPhone)
    })
  }

  // Star-rating filter for the "Ratings" tab — applied whenever one or more
  // rating values are passed (not only when status==='rated'), so the same
  // param works regardless of which tab triggered it. Multi-select: e.g.
  // rating=4,5 matches either.
  if (filters.rating?.length) {
    q.whereIn('tickets.rating', filters.rating)
  }

  // NEW: full sort control for the ticket list. Defaults preserved exactly
  // (last_message_at desc) when the frontend sends nothing. `computed_priority`
  // is a SELECTed alias (see above) — MySQL allows ORDER BY on a SELECTed
  // alias, so sorting by "priority" respects the same org/contact
  // high-priority overrides the list itself displays, not just the raw
  // column. Whitelisted against a fixed column map so arbitrary/unsafe
  // input can never reach ORDER BY directly.
  const SORTABLE_COLUMNS: Record<string, string> = {
    last_message_at: 'tickets.last_message_at',
    created_at: 'tickets.created_at',
    updated_at: 'tickets.updated_at',
    priority: 'computed_priority',
    status: 'tickets.status',
    customer_name: 'tickets.customer_name',
    ticket_uid: 'tickets.ticket_uid',
    subject: 'tickets.subject',
    rating: 'tickets.rating',
    source: 'tickets.source',
  }
  const sortColumn = SORTABLE_COLUMNS[filters.sortBy as string] ?? 'tickets.last_message_at'
  const sortOrder = String(filters.sortOrder).toLowerCase() === 'asc' ? 'asc' : 'desc'
  // Priority is a text enum ('low'|'medium'|'high') — sort it by severity,
  // not alphabetically, in whichever direction was requested.
  if (sortColumn === 'computed_priority') {
    q.orderByRaw(`FIELD(computed_priority, 'low','medium','high') ${sortOrder}`)
  } else {
    q.orderBy(sortColumn, sortOrder)
  }
  // Stable, deterministic tie-break so equal-sort-value rows (e.g. several
  // tickets with the same priority, or same null rating) don't reorder
  // between pages as new tickets arrive mid-scroll.
  q.orderBy('tickets.id', 'desc')

  return (await q.offset(offset).limit(limit)).map((row: any) => {
    const { assignment_chain_raw, computed_priority, ...rest } = row
    return {
      ...rest,
      priority: computed_priority || rest.priority,
      assignmentHistory: assignment_chain_raw
        ? assignment_chain_raw.split('||').map((agent_name: string) => ({ agent_name }))
        : [],
    }
  })
}

  /**
   * Distinct list of organizations that actually have a ticket on file —
   * derived straight from tickets.sender_org_id / sender_org_name instead
   * of a join back to the legacy `Organization` table (see
   * OrganizationService.listOrganizations, used by the dedicated
   * Organizations tab). Backs the ticket-list "Organization" filter
   * dropdown: that dropdown was missing orgs that clearly had tickets
   * because it went through Organization + a whereExists join instead of
   * just reading the column tickets already carries.
   *
   * No status/is_spam/deleted_at filter — an org counts if it has ANY row
   * in `tickets` at all, open, closed, or deleted.
   */
  public static async getTicketOrganizations(search = '') {
    const q = Database.from('tickets')
      .whereNotNull('sender_org_id')
      .whereNotNull('sender_org_name')
      .select('sender_org_id as orgId', 'sender_org_name as orgName')
      .groupBy('sender_org_id', 'sender_org_name')
      .orderBy('sender_org_name', 'asc')

    const trimmedSearch = search.trim()
    if (trimmedSearch) {
      q.where('sender_org_name', 'like', `%${trimmedSearch}%`)
    }

    return await q
  }

  /** Per-tab counts for the ticket list header — same visibility rule as getTickets. */
  public static async getStatusCounts(requesterId?: number, requesterRole?: string) {
    const base = () => {
      const q = Database.from('tickets').where('is_spam', 0).whereNull('deleted_at')
      if (requesterRole && requesterRole !== 'admin') {
   q.where((b) => {
  b.whereNull('assigned_to')
  if (requesterId !== undefined) {
    b.orWhere('assigned_to', requesterId)
  }
})
      }
      return q
    }
    const [all, open, onHold, escalated, closed, reopened, rated] = await Promise.all([
      base().count('* as c').first(),
      base().where('status', 'open').count('* as c').first(),
      base().where('status', 'on_hold').count('* as c').first(),
      base().where('status', 'escalated').count('* as c').first(),
      base().where('status', 'closed').count('* as c').first(),
      // FIX: same rule as getTickets' 'reopened' branch — a ticket that's
      // been reopened but is closed again now counts under Closed, not
      // Re-opened.
      base().where('reopen_count', '>', 0).whereNot('status', 'closed').count('* as c').first(),
      base().whereNotNull('rating').count('* as c').first(),
    ])
    return {
      all: Number(all.c), open: Number(open.c), on_hold: Number(onHold.c),
      escalated: Number(escalated.c), closed: Number(closed.c),
      reopened: Number(reopened.c), rated: Number(rated.c),
    }
  }

  public static async getTicketById(id: number) {
    const ticket = await Database.from('tickets').where('id', id).first()
    const messages = await Database.from('ticket_messages').where('ticket_id', id).orderBy('created_at', 'asc').orderBy('id', 'asc')
    const attachments = await Database.from('ticket_attachments').where('ticket_id', id)
    let ccParticipants = await Database.from('ticket_cc_participants').where('ticket_id', id)
    const assignmentHistory = await Database.from('ticket_assignment_history')
      .where('ticket_id', id).orderBy('created_at', 'asc').select('agent_name', 'created_at')

    // Opening a ticket marks it read.
    if (ticket && !ticket.is_read) {
      await Database.from('tickets').where('id', id).update({ is_read: 1 })
      ticket.is_read = 1
    }

    const safeParseList = (val: any): string[] => {
      if (!val) return []
      if (Array.isArray(val)) return val
      try {
        const parsed = JSON.parse(val)
        return Array.isArray(parsed) ? parsed : []
      } catch {
        return []
      }
    }

    // Auto-detect any CC participants present in messages (e.g. non-originator customer replies or CC recipients)
    if (ticket) {
      const primaryEmail = (ticket.customer_email || '').toLowerCase().trim()
      const mailboxEmail = (ticket.mailbox_email || '').toLowerCase().trim()
      const existingEmails = new Set(ccParticipants.map((p: any) => (p.email || '').toLowerCase().trim()))

      const missingEmails = new Set<string>()
      for (const m of messages) {
        if (m.sender === 'customer' && m.sender_email) {
          const s = m.sender_email.toLowerCase().trim()
          if (s && s !== primaryEmail && s !== mailboxEmail && !existingEmails.has(s)) {
            missingEmails.add(s)
          }
        }
        for (const rec of [...safeParseList(m.to_recipients), ...safeParseList(m.cc_recipients)]) {
          const r = String(rec || '').toLowerCase().trim()
          if (r && r !== primaryEmail && r !== mailboxEmail && !existingEmails.has(r)) {
            missingEmails.add(r)
          }
        }
      }

      if (missingEmails.size > 0) {
        const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
        await EmailToTicketService.upsertCcParticipants(id, Array.from(missingEmails)).catch(() => null)
        ccParticipants = await Database.from('ticket_cc_participants').where('ticket_id', id)
      }
    }

    const withAttachments = messages.map(m => ({
      ...m,
      attachments: attachments.filter(a => a.message_id === m.id),
      to_recipients: safeParseList(m.to_recipients),
      cc_recipients: safeParseList(m.cc_recipients),
      bcc_recipients: safeParseList(m.bcc_recipients),
    }))

    const lastInbound = [...withAttachments].reverse().find(m => m.sender === 'customer')
    return {
      ticket: { ...ticket, assignmentHistory },
      messages: withAttachments,
      ccParticipants,
      replyRecipients: lastInbound
        ? { to: lastInbound.to_recipients, cc: lastInbound.cc_recipients, bcc: lastInbound.bcc_recipients }
        : { to: [], cc: [], bcc: [] },
    }
  }

  public static async addMessage(data: {
    ticketId: number; sender: string; type: string; message: string
    senderName?: string; senderEmail?: string
    toRecipients?: string[]; ccRecipients?: string[]; bccRecipients?: string[]; graphMessageId?: string
    replyMode?: 'reply' | 'reply_all' | 'reply_selected' | 'forward'
    recipients?: { to?: string[]; cc?: string[] }
    requester?: any
    agentId?: number
    channel?: string
    deliveryStatus?: 'sent' | 'failed'
    failureReason?: string | null
    relatedMessageId?: number | null
    createdAt?: Date | string
    // Inline (body-embedded) image metadata for on-demand Graph fetch — see
    // EmailToTicketService.resolveInlineAttachments(). Never rendered as a
    // separate attachment chip, only used to resolve `/uploads/...` URLs
    // already baked into `message` back to a live Outlook attachment.
    inlineAttachments?: { fileName: string; contentType: string; size: number; storagePath: string; graphAttachmentId: string }[]
    // Files the AGENT attached to this outgoing reply — uploaded ahead of
    // time via TicketController.uploadAttachment (see there for why it's a
    // separate step). Turned into ticket_attachments rows below, then
    // handed to the email/WhatsApp send paths so they actually go out with
    // the message instead of only ever showing up on inbound messages.
    attachments?: { fileName: string; contentType?: string; size?: number; storagePath: string }[]
  }) {
    if (data.sender === 'agent') await this.assertCanActOnTicket(data.ticketId, data.requester)

    const forwardTo = data.replyMode === 'forward' && data.recipients?.to?.length
      ? (data.recipients.to as string[]).join(', ')
      : null

    // For an agent reply that's crossing channels (e.g. replying via WhatsApp
    // to an email-origin message, or vice versa), fold a short reference to
    // the original message into the content itself — same-channel target
    // gets no destination that natively shows "this is about that". We do
    // this once, up front, so the ticket_messages row we store matches
    // exactly what goes out to the customer (no drift between the ubiDesk
    // panel and the actual sent message).
    let ticket: any = null
    let relatedMsg: any = null
    let effectiveChannel: string | undefined
    let storedMessage = data.message

    if (data.sender === 'agent' && data.type === 'reply') {
      ticket = await Database.from('tickets').where('id', data.ticketId).first()
      effectiveChannel = data.channel ?? ticket?.source
      relatedMsg = data.relatedMessageId
        ? await Database.from('ticket_messages').where('id', data.relatedMessageId).first()
        : null
      if (effectiveChannel === 'email' || effectiveChannel === 'whatsapp') {
        storedMessage = Helper.applyCrossChannelReference(data.message, relatedMsg, effectiveChannel)
      }
    }

    const [msgId] = await Database.table('ticket_messages').insert({
      ticket_id: data.ticketId, sender: data.sender, type: data.type, message: storedMessage,
      sender_name: data.sender === 'agent' ? data.requester?.name : data.senderName,
      sender_email: data.sender === 'agent' ? null : data.senderEmail,
      agent_id: data.sender === 'agent' ? data.requester?.id : null,
      to_recipients: JSON.stringify(data.toRecipients ?? []),
      cc_recipients: JSON.stringify(data.ccRecipients ?? []),
      bcc_recipients: JSON.stringify(data.bccRecipients ?? []),
      graph_message_id: data.graphMessageId ,
      reply_mode: data.replyMode ,
      forward_to: forwardTo,
      channel: data.channel ?? (data.sender === 'agent' ? undefined : 'email'),
      delivery_status: data.deliveryStatus ?? (data.sender === 'customer' ? 'sent' : undefined),
      failure_reason: data.failureReason ,
      related_message_id: data.relatedMessageId ,
      created_at: data.createdAt ? new Date(data.createdAt) : new Date(),
    })

    // Link any agent-uploaded files to the message row we just created.
    // Deliberately best-effort: a broken attachment insert shouldn't stop
    // the message itself (which already exists) from going out.
    let savedAttachments: any[] = []
    if (data.attachments?.length) {
      try {
        const rows = data.attachments.map((a) => ({
          ticket_id: data.ticketId,
          message_id: msgId,
          file_name: a.fileName,
          content_type: a.contentType ?? null,
          size: a.size ?? null,
          storage_path: a.storagePath,
          created_at: new Date(),
        }))
        await Database.table('ticket_attachments').insert(rows)
        savedAttachments = await Database.from('ticket_attachments').where('message_id', msgId)
      } catch (err: any) {
        console.error(`[TicketService] failed to save outbound attachments for message ${msgId}:`, err.message)
      }
    }

    const patch: any = { last_message_at: new Date() }
    if (data.sender === 'agent') patch.agent_last_active_at = new Date()
    if (data.sender === 'customer') patch.is_read = 0 // new inbound message re-opens "unread"

    // Auto-restore: a new message from the agent or the customer on a
    // soft-deleted ticket means it's active again — undelete it AND put it
    // back in Open (not whatever status it was closed/escalated/etc. at
    // before deletion — a ticket that's back in play after being deleted
    // should land back at the front of the queue, not silently sit
    // "resolved"/"closed" with an unread reply behind it). Deliberately
    // excludes sender === 'system' (auto-forward copies, closure notices,
    // etc.) — those shouldn't resurrect a ticket someone intentionally
    // deleted.
    let restoredFromDeleted = false
    let autoAssigned = false
    const current = ticket ?? await Database.from('tickets').where('id', data.ticketId).first()

    if (data.sender === 'agent' || data.sender === 'customer') {
      if (current?.deleted_at) {
        patch.deleted_at = null
        patch.status = 'open'
        restoredFromDeleted = true
      }
    }

    // Auto-assign: if someone replies to an unassigned ticket, auto-assign
    // that ticket to the agent who made the reply.
    if (data.sender === 'agent' && !current?.assigned_to) {
      const actingAgentId = data.requester?.id ?? data.agentId
      const actingAgentName = data.requester?.name ?? data.senderName
      if (actingAgentId) {
        patch.assigned_to = actingAgentId
        if (actingAgentName) patch.assigned_agent_name = actingAgentName
        autoAssigned = true

        await Database.table('ticket_assignment_history').insert({
          ticket_id: data.ticketId,
          agent_id: actingAgentId,
          agent_name: actingAgentName ?? null,
          assigned_by: actingAgentId,
          created_at: new Date(),
        }).catch((err: any) => console.error(`[TicketService] auto-assignment history failed for ticket ${data.ticketId}:`, err.message))
      }
    }

    await Database.from('tickets').where('id', data.ticketId).update(patch)

    if (restoredFromDeleted || autoAssigned) {
      const { io } = await import('../../start/socket')
      io.emit('tickets_updated')
      io.emit('dashboard_stats_stale')
    }

    // Mirror any new CC recipients into ticket_cc_participants so the CC chip
    // in the ticket header reflects addresses the agent added in the reply drawer.
    // Best-effort: a failure here must not block the reply from going out.
    if (data.ccRecipients?.length) {
      const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
      await EmailToTicketService.upsertCcParticipants(data.ticketId, data.ccRecipients).catch((err: any) =>
        console.error(`[TicketService] CC participant upsert failed for ticket ${data.ticketId}:`, err.message)
      )
    }

if (data.sender === 'agent' && data.type === 'reply') {
      if (effectiveChannel === 'email') {
        const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
        // requester?.id is the normal source (set server-side from the session/socket
        // auth); data.agentId is a fallback for callers that only have the raw id.
        const effectiveAgentId = data.requester?.id ?? data.agentId
        // NOT awaited — see the WhatsApp branch below for why. The Graph
        // send happens in the background; addMessage() returns (and the
        // socket ack fires) as soon as the row is inserted, and the result
        // of the send is patched onto the row + broadcast via
        // message_updated once it's known.
        EmailToTicketService.sendAgentReplyByEmail(
          data.ticketId, storedMessage, data.replyMode ?? 'reply', data.recipients, effectiveAgentId, savedAttachments, msgId
        )
          // Persist the resolved Graph message id onto this row once the send
          // completes. This is what lets the Sent Items webhook handler
          // (EmailToTicketService.handleSentMessage) recognize a reply sent
          // through this panel and skip it, instead of logging it a second
          // time as if it were sent directly from Outlook.
          .then((sendResult) => Database.from('ticket_messages').where('id', msgId).update({
            delivery_status: 'sent',
            ...(sendResult?.graphMessageId ? { graph_message_id: sendResult.graphMessageId } : {}),
          }))
          .catch(async (err) => {
            console.error(`[TicketService] outbound email reply failed for ticket ${data.ticketId}:`, err.message)
            await Database.from('ticket_messages').where('id', msgId).update({
              delivery_status: 'failed',
              failure_reason: (err.response?.data?.error?.message || err.message || 'Email send failed').slice(0, 250),
            })
          })
          .then(async () => {
            const { io } = await import('../../start/socket')
            const updated = await Database.from('ticket_messages').where('id', msgId).first()
            io.to(`ticket_${data.ticketId}`).emit('message_updated', updated)
          })
          .catch((err) => console.error(`[TicketService] email delivery-status patch failed for msg ${msgId}:`, err.message))
// TicketService.addMessage — replace the swallow-only .catch with update-on-both-outcomes
} else if (effectiveChannel === 'whatsapp') {
  const { default: WhatsappOutboundService } = await import('App/Services/WhatsappOutboundService')
  // graph_message_id is shared storage for BOTH the Outlook Graph message id
  // (email) and the Meta wamid (WhatsApp) — only trust it as a WA context id
  // when the related message actually originated on WhatsApp. Passing an
  // email's Graph id here as a WA context.message_id makes Meta reject the
  // whole send, which is why cross-channel WA replies were silently failing.
  const waContextId = relatedMsg?.channel === 'whatsapp' ? (relatedMsg.graph_message_id ?? null) : null
  // [WA-TRACE S1] Confirms we're about to send, and with what msgId — this
  // is the row that graph_message_id / delivery_status will land on.
  console.log(`[WA-TRACE S1] sending WA message — ticketId=${data.ticketId} msgId=${msgId} to=${ticket?.customer_phone}`)
  // IMPORTANT: intentionally NOT awaited. This used to be `await
  // WhatsappOutboundService.sendText(...)...`, which meant addMessage()
  // (and therefore the 'ticket_message' socket ack — see socket.ts) sat
  // blocked on the live Meta Graph API call before ever resolving. Meta's
  // API has no bound on how long it can take, and the socket ack is only
  // given an 8s window client-side — so a slow-but-eventually-successful
  // Graph call was enough on its own to make the frontend show "Failed"
  // (ack timeout) on a message that actually sent fine a moment later.
  // Firing this without awaiting lets the DB insert + ack return
  // immediately; the WhatsApp send result is patched onto the row and
  // pushed to clients separately via message_updated, same as before.
  const waSend = savedAttachments.length
    ? WhatsappOutboundService.sendWithAttachments(ticket?.customer_phone, storedMessage, savedAttachments, waContextId, msgId)
    : WhatsappOutboundService.sendText(ticket?.customer_phone, storedMessage, waContextId, msgId)
  waSend
    .then(() => {
      // [WA-TRACE S5] Confirms the Graph API call itself succeeded (this
      // runs before graph_message_id is necessarily confirmed saved — see
      // S3/S4 in WhatsappOutboundService for that).
      console.log(`[WA-TRACE S5] send succeeded for msgId=${msgId} — setting delivery_status=sent`)
      return Database.from('ticket_messages').where('id', msgId).update({ delivery_status: 'sent' })
    })
    .catch(async (err) => {
      // NOTE: err.message here is always a useless generic axios string
      // ("Request failed with status code 400") — the real Meta error object
      // is logged separately as [WA-TRACE S5-DETAIL] inside
      // WhatsappOutboundService.sendText's own catch block. Look there for
      // WHY it failed; this line just confirms WHICH ticket/message it was.
      console.error(`[WA-TRACE S5-ERR] outbound WhatsApp reply failed for ticket ${data.ticketId} msgId=${msgId} (see WA-TRACE S5-DETAIL above for the actual reason):`, err.message)
      await Database.from('ticket_messages').where('id', msgId).update({
        delivery_status: 'failed',
        failure_reason: (err.response?.data?.error?.message || err.message || 'WhatsApp send failed').slice(0, 250),
      })
    })
    .then(async () => {
      const { io } = await import('../../start/socket')
      const updated = await Database.from('ticket_messages').where('id', msgId).first()
      // [WA-TRACE S6] What we're emitting as message_updated right after
      // send. Note the frontend won't have this msgId in its list yet at
      // this point (it only has the optimistic placeholder) — that's
      // expected, this event is effectively a no-op on the frontend. The
      // REAL row (with this same delivery_status baked in) arrives moments
      // later via new_ticket_message from socket.ts — see W7 below.
      console.log(`[WA-TRACE S6] emitting message_updated (post-send) — msgId=${msgId} delivery_status="${updated.delivery_status}" graph_message_id="${updated.graph_message_id}"`)
      io.to(`ticket_${data.ticketId}`).emit('message_updated', updated)
    })
    .catch((err) => console.error(`[TicketService] WA delivery-status patch failed for msg ${msgId}:`, err.message))
}
    }

    const finalRow = await Database.from('ticket_messages').where('id', msgId).first()
    // Bolt attachments onto the returned row (not a persisted column) so
    // whatever receives this straight from addMessage — the HTTP response,
    // or a socket handler that echoes it back — doesn't have to do a
    // separate round trip just to render what was just sent.
    return { ...finalRow, attachments: savedAttachments }
  }

  public static async updateStatus(id: number, status: string, sendClosureMessage = false) {
    if (!VALID_STATUSES.includes(status as any)) throw new Error(`Invalid status: ${status}`)
    const prevTicket = await Database.from('tickets').where('id', id).first()
    await Database.from('tickets').where('id', id).update({ status, updated_at: new Date() })

    const justClosed = prevTicket && status === 'closed' && prevTicket.status !== 'closed'
    if (justClosed && sendClosureMessage && prevTicket.source === 'email') {
      const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
      await EmailToTicketService.sendTicketClosureEmail(id).catch((err) => {
        console.error(`[TicketService] Failed to send ticket closure email for ticket ${id}:`, err.message)
      })
    }

    return Database.from('tickets').where('id', id).first()
  }

  /**
   * Reopens a ticket on the CUSTOMER's own action — clicking "Reopen ticket"
   * in a closure email, or picking "Unsatisfied"/"Very unsatisfied" on the
   * rating widget. No-ops (returns the ticket unchanged) if it isn't
   * currently closed, so refreshing the confirmation page doesn't inflate
   * reopen_count. Logged with actor_agent_id = null so the activity trail
   * reads as customer-initiated, not an agent action.
   */
  public static async reopenByCustomer(id: number) {
    const ticket = await Database.from('tickets').where('id', id).first()
    if (!ticket) return null
    if (['closed', 'resolved'].includes(ticket.status)) {
      await Database.from('tickets').where('id', id).update({
        status: 'open',
        // A customer reopening a closed ticket is a strong signal something
        // was missed — bump priority so it doesn't sit in the queue at its
        // old (possibly low/medium) priority.
        priority: 'high',
        reopen_count: (ticket.reopen_count ?? 0) + 1,
        last_reopened_at: new Date(),
        is_read: 0,
        updated_at: new Date(),
      })
      await Database.table('ticket_activity_logs').insert({
        ticket_id: id,
        action: 'reopened',
        actor_agent_id: null,
        actor_agent_name: 'Customer',
        from_value: ticket.status,
        to_value: 'open',
        created_at: new Date(),
      })
      const { io } = await import('../../start/socket')
      io.emit('tickets_updated')
      io.emit('dashboard_stats_stale')

      // Per requirement: any ticket that gets reopened gets the same
      // timing/attachment self-healing check boot-time repair runs for all
      // open tickets, applied right away rather than waiting for the next
      // restart. Fire-and-forget — reopening shouldn't wait on a Graph
      // round-trip, and a failure here is logged, not surfaced to the caller.
      import('App/Services/EmailToTicketService')
        .then(({ default: EmailToTicketService }) => EmailToTicketService.repairTicketMessages(id))
        .catch((err: any) => console.error(`[TicketService][reopenByCustomer] repair pass failed for ticket #${id}:`, err?.response?.data ?? err.message))
    }
    return Database.from('tickets').where('id', id).first()
  }

public static async getDashboardStats(widgetKey?: string, requesterId?: number, requesterRole?: string, days = 7) {
    const safeDays = Math.max(1, days)
    const baseQuery = () => {
      const q = Database.from('tickets').whereNull('deleted_at').where('is_spam', 0)
      if (widgetKey) q.where('widget_key', widgetKey)
      if (requesterRole && requesterRole !== 'admin') {
        q.where((b: any) => {
          b.whereNull('assigned_to')
          if (requesterId !== undefined) b.orWhere('assigned_to', requesterId)
        })
      }
      return q
    }

    const currentQ = baseQuery().whereRaw('created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)', [safeDays - 1])
    const prevQ = baseQuery().whereRaw(
      'created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY) AND created_at < DATE_SUB(CURDATE(), INTERVAL ? DAY)',
      [2 * safeDays - 1, safeDays - 1]
    )

    const [
      [curOpen], [curClosed], [curResolvedToday], [curHighPriority], [curUnassigned],
      [prevOpen], [prevClosed], [prevResolvedToday], [prevHighPriority], [prevUnassigned]
    ] = await Promise.all([
      currentQ.clone().where('status', 'open').count('* as c'),
      currentQ.clone().where('status', 'closed').count('* as c'),
      currentQ.clone().where('status', 'closed').whereRaw('DATE(updated_at) = CURDATE()').count('* as c'),
      currentQ.clone().where('priority', 'high').whereNotIn('status', ['closed']).count('* as c'),
      currentQ.clone().whereNull('assigned_to').whereNotIn('status', ['closed']).count('* as c'),

      prevQ.clone().where('status', 'open').count('* as c'),
      prevQ.clone().where('status', 'closed').count('* as c'),
      prevQ.clone().where('status', 'closed').whereRaw('DATE(updated_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)').count('* as c'),
      prevQ.clone().where('priority', 'high').whereNotIn('status', ['closed']).count('* as c'),
      prevQ.clone().whereNull('assigned_to').whereNotIn('status', ['closed']).count('* as c'),
    ])

    const calcPct = (cur: number, prev: number) => {
      if (prev === 0) return cur > 0 ? 100 : 0
      return Math.round(((cur - prev) / prev) * 100)
    }

    const openCount = Number(curOpen?.c || 0)
    const closedCount = Number(curClosed?.c || 0)
    const resolvedTodayCount = Number(curResolvedToday?.c || 0)
    const highPriorityCount = Number(curHighPriority?.c || 0)
    const unassignedCount = Number(curUnassigned?.c || 0)

    const prevOpenCount = Number(prevOpen?.c || 0)
    const prevClosedCount = Number(prevClosed?.c || 0)
    const prevResolvedTodayCount = Number(prevResolvedToday?.c || 0)
    const prevHighPriorityCount = Number(prevHighPriority?.c || 0)
    const prevUnassignedCount = Number(prevUnassigned?.c || 0)

    const comparisonText = safeDays === 1 ? 'from yesterday' : `vs prev ${safeDays}D`

    return {
      open: openCount,
      closed: closedCount,
      resolvedToday: resolvedTodayCount,
      unassigned: unassignedCount,
      highPriority: highPriorityCount,
      comparisonText,
      changes: {
        openPct: calcPct(openCount, prevOpenCount),
        closedPct: calcPct(closedCount, prevClosedCount),
        resolvedTodayPct: calcPct(resolvedTodayCount, prevResolvedTodayCount),
        unassignedPct: calcPct(unassignedCount, prevUnassignedCount),
        highPriorityPct: calcPct(highPriorityCount, prevHighPriorityCount),
      }
    }
  }

  /**
   * Pending tickets (open / on_hold / escalated), ranked longest → shortest
   * waiting time. "Pending since" = last activity (last_message_at) if we
   * have it, else created_at.
   */
public static async getPendingTickets(offset = 0, limit = 7, requesterId?: number, requesterRole?: string, days = 7) {
  const q = Database.from('tickets')
    .whereNull('deleted_at')
    .where('is_spam', 0)
    .where('status', 'open')
  
  applyDashboardScope(q, requesterId, requesterRole, days)
  
  const rows = await q
    .select(
      'id', 'ticket_uid', 'customer_name', 'status', 'priority', 'assigned_agent_name',
      'sender_org_name', 'sender_logo_url', 'created_at'
    )
    .orderBy('created_at', 'asc')
    .offset(offset)
    .limit(limit)

  const now = Date.now()
  return rows.map((r) => ({
    ...r,
    pending_since: r.created_at,
    pending_minutes: Math.max(0, Math.round((now - new Date(r.created_at).getTime()) / 60000)),
  }))
}

public static async getPendingTicketsCount(requesterId?: number, requesterRole?: string, days = 7) {
  const q = Database.from('tickets')
    .whereNull('deleted_at')
    .where('is_spam', 0)
    .where('status', 'open')

  applyDashboardScope(q, requesterId, requesterRole, days)

  const [row] = await q.count('* as c')
  return Number(row.c || 0)
}

  public static async getStatusDistribution(requesterId?: number, requesterRole?: string, days = 7) {
    const q = Database.from('tickets').whereNull('deleted_at').where('is_spam', 0)
    applyDashboardScope(q, requesterId, requesterRole, days)
    return q.select('status').count('* as count').groupBy('status')
  }

  public static async getPriorityDistribution(requesterId?: number, requesterRole?: string, days = 7) {
    const q = Database.from('tickets').whereNull('deleted_at').where('is_spam', 0).whereNotIn('status', ['closed'])
    applyDashboardScope(q, requesterId, requesterRole, days)
    return q.select('priority').count('* as count').groupBy('priority')
  }

  public static async getSourceDistribution(requesterId?: number, requesterRole?: string, days = 7) {
    const q = Database.from('tickets').whereNull('deleted_at').where('is_spam', 0)
    applyDashboardScope(q, requesterId, requesterRole, days)
    return q.select('source').count('* as count').groupBy('source')
  }

  /**
   * Average time from ticket creation to the first agent reply, in minutes
   * — over tickets in the requester's scope + selected day window. Basic
   * "created → first agent message" delta; doesn't yet account for
   * business hours/SLA targets, just a straight average.
   */
  public static async getAvgFirstResponseTime(requesterId?: number, requesterRole?: string, days = 7): Promise<number | null> {
    const roleClause = requesterRole && requesterRole !== 'admin'
      ? 'AND (t.assigned_to IS NULL OR t.assigned_to = ?)'
      : ''
    const bindings: any[] = [Math.max(1, days) - 1]
    if (roleClause) bindings.push(requesterId ?? -1)

    const [row] = (await Database.rawQuery(
      `SELECT AVG(TIMESTAMPDIFF(MINUTE, t.created_at, fr.first_reply_at)) as avg_minutes
       FROM tickets t
       JOIN (
         SELECT ticket_id, MIN(created_at) as first_reply_at
         FROM ticket_messages
         WHERE sender = 'agent'
         GROUP BY ticket_id
       ) fr ON fr.ticket_id = t.id
       WHERE t.deleted_at IS NULL AND t.is_spam = 0
         AND t.created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
         ${roleClause}`,
      bindings
    ) as any)[0]

    return row?.avg_minutes !== null && row?.avg_minutes !== undefined ? Math.round(Number(row.avg_minutes)) : null
  }

  /**
   * Buckets every ticket in scope into a category and returns counts +
   * percentages. Classification is delegated to TicketClassifier, using
   * the subject plus the ticket's first message body (stripped of HTML) —
   * many real subjects ("Discussion call", "Request on Meeting") carry no
   * topic signal on their own, so the body is what actually drives most
   * classifications. See TicketClassifier.ts for the category list and
   * matching logic.
   */
  public static async getTicketsByCategory(requesterId?: number, requesterRole?: string, days = 7) {
    // Correlated subquery (not a join) for the first message body, so
    // applyDashboardScope's unqualified `created_at`/`assigned_to` still
    // resolve to the `tickets` table unambiguously — ticket_messages also
    // has a `created_at` column, which a join would make ambiguous.
    const q = Database.from('tickets').whereNull('deleted_at').where('is_spam', 0)
    applyDashboardScope(q, requesterId, requesterRole, days)
    const rows = await q.select(
      'subject',
      Database.raw(
        `(SELECT tm.message FROM ticket_messages tm WHERE tm.ticket_id = tickets.id ORDER BY tm.created_at ASC LIMIT 1) as first_message`
      )
    )

    const counts: Record<string, number> = {
      Attendance: 0,
      'Leave & Holidays': 0,
      'Payroll & Billing': 0,
      'Access & Credentials': 0,
      'Integration & API': 0,
      'Setup & Onboarding': 0,
      'HRMS Configuration': 0,
      Technical: 0,
      'Internal / Noise': 0,
      Other: 0,
    }
    for (const r of rows) {
      const bodyText = TicketClassifier.htmlToPlainText(r.first_message)
      const { category } = TicketClassifier.classify(r.subject, bodyText)
      counts[category]++
    }

    const total = rows.length || 1
    return Object.entries(counts)
      .map(([category, count]) => ({ category, count, pct: Math.round((count / total) * 100) }))
      .sort((a, b) => b.count - a.count)
  }

  /**
   * % of rated tickets (in scope + day window) with a rating of 4 or 5 —
   * "SLA met" defined as a positive customer rating, same threshold
   * TicketFeedbackService.tierFor() uses for its 'positive' tier. Tickets
   * with no rating submitted yet are excluded from the denominator (an
   * unrated ticket isn't a compliance failure, just unknown).
   */
  public static async getSlaCompliance(requesterId?: number, requesterRole?: string, days = 7): Promise<{ pct: number; rated: number }> {
    const base = () => {
      const q = Database.from('tickets').whereNull('deleted_at').where('is_spam', 0).whereNotNull('rating')
      applyDashboardScope(q, requesterId, requesterRole, days)
      return q
    }
    const [[{ c: rated }], [{ c: met }]] = await Promise.all([
      base().count('* as c'),
      base().where('rating', '>=', 4).count('* as c'),
    ])
    const ratedNum = Number(rated), metNum = Number(met)
    return { pct: ratedNum ? Math.round((metNum / ratedNum) * 100) : 0, rated: ratedNum }
  }

  /** Created vs closed tickets per day, last N days — powers the trend chart. */
  public static async getTicketsTrend(days = 14, requesterId?: number, requesterRole?: string) {
    const base = () => {
      const q = Database.from('tickets').whereNull('deleted_at').where('is_spam', 0)
      if (requesterRole && requesterRole !== 'admin') {
        q.where((b: any) => {
          b.whereNull('assigned_to')
          if (requesterId !== undefined) b.orWhere('assigned_to', requesterId)
        })
      }
      return q
    }

    const created = await base()
      .whereRaw('created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)', [Math.max(1, days) - 1])
      .select(Database.raw('DATE(created_at) as day'))
      .count('* as count').groupByRaw('DATE(created_at)')

    const closed = await base()
      .where('status', 'closed')
      .whereRaw('updated_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)', [Math.max(1, days) - 1])
      .select(Database.raw('DATE(updated_at) as day'))
      .count('* as count').groupByRaw('DATE(updated_at)')

    return { created, closed }
  }

  /** Open workload per agent — who's currently carrying the most tickets. */
public static async getAgentWorkload() {
  return Database.from('tickets as t')
    .leftJoin('support_agents as a', 't.assigned_to', 'a.id')
    .whereNull('t.deleted_at')
    .where('t.is_spam', 0)
    .whereIn('t.status', ['open', 'on_hold', 'escalated'])
    .select(
      'a.id',
      Database.raw("COALESCE(a.name, 'Unassigned') as name")
    )
    .count('t.id as count')
    .groupBy('a.id', 'a.name')
    .orderBy('count', 'desc')
}

  public static async updateTicketDetails(id: number, data: {
    customerName?: string; customerPhone?: string; customerEmail?: string
    priority?: string; status?: string; source?: string
  }) {
    if (data.status && !VALID_STATUSES.includes(data.status as any)) throw new Error(`Invalid status: ${data.status}`)
    const patch: any = { updated_at: new Date() }
    if (data.customerName !== undefined)  patch.customer_name  = data.customerName
    if (data.customerPhone !== undefined) patch.customer_phone = data.customerPhone
    if (data.customerEmail !== undefined) patch.customer_email = data.customerEmail
    if (data.priority !== undefined)      patch.priority       = data.priority
    if (data.status !== undefined)        patch.status         = data.status
    if (data.source !== undefined)        patch.source         = data.source

    await Database.from('tickets').where('id', id).update(patch)
    return Database.from('tickets').where('id', id).first()
  }

  public static async softDeleteTicket(id: number) {
    await Database.from('tickets').where('id', id).update({ deleted_at: new Date(), updated_at: new Date() })
    return { status: true, msg: 'Ticket deleted' }
  }

  public static async assignTicket(ticketId: number, agentId: number, agentName: string, requester: any) {
    if (!requester) throw new Error('Could not identify the requesting agent — try again after refreshing.')
    const ticket = await Database.from('tickets').where('id', ticketId).first()
    if (!ticket) throw new Error('Ticket not found')

    const isAdmin = requester.role === 'admin'
    const isOwner = ticket.assigned_to && Number(ticket.assigned_to) === Number(requester.id)
    const isUnassigned = !ticket.assigned_to

    // Was: agents could ONLY ever assign a ticket to themselves, which made
    // "transfer to another agent" impossible. Now: an agent can pick up an
    // unassigned ticket for themselves, or transfer a ticket they currently
    // own to anyone else (another agent or admin). They still can't touch
    // a ticket owned by a different agent.
    if (!isAdmin && !isUnassigned && !isOwner) {
      throw new Error('This ticket is picked up by another agent')
    }

    await Database.from('tickets').where('id', ticketId).update({
      status: ticket.status === 'open' ? 'open' : ticket.status,
      assigned_to: agentId,
      assigned_agent_name: agentName,
      agent_last_active_at: new Date(),
      ...(ticket.assigned_to && Number(ticket.assigned_to) !== Number(agentId)
        ? { prev_assigned_to: ticket.assigned_to, prev_assigned_agent_name: ticket.assigned_agent_name }
        : {}),
    })

    // Full transfer chain (unlike prev_assigned_to, which only remembers one
    // hop back) — this is what lets the frontend render
    // "Mansi → Deepak → Sonam" instead of just the last two.
    await Database.table('ticket_assignment_history').insert({
      ticket_id: ticketId,
      agent_id: agentId,
      agent_name: agentName,
      assigned_by: requester.id ?? null,
      created_at: new Date(),
    })

    return Database.from('tickets').where('id', ticketId).first()
  }

  public static async assertCanActOnTicket(ticketId: number, requester?: any) {
    if (!requester || requester.role === 'admin') return
    const ticket = await Database.from('tickets').where('id', ticketId).first()
    if (ticket?.assigned_to && Number(ticket.assigned_to) !== Number(requester.id)) {
      throw new Error('This ticket is picked up by another agent')
    }
  }

  // ============================================================
  // READ / UNREAD
  // ============================================================
  public static async markRead(id: number) {
    await Database.from('tickets').where('id', id).update({ is_read: 1 })
    return { status: true }
  }

  public static async markUnread(id: number) {
    await Database.from('tickets').where('id', id).update({ is_read: 0 })
    return { status: true }
  }

  // ============================================================
  // SPAM
  // ============================================================
  public static async markSpam(ticketIds: number[], spam: boolean) {
    await Database.from('tickets').whereIn('id', ticketIds).update({ is_spam: spam ? 1 : 0, updated_at: new Date() })
    return { status: true, count: ticketIds.length }
  }

  // ============================================================
  // MERGE
  //   Folds every message/attachment/cc-participant from each source
  //   ticket into the target ticket, then soft-deletes the sources.
  // ============================================================
  public static async mergeTickets(sourceIds: number[], targetId: number, requester: any) {
    if (sourceIds.includes(targetId)) throw new Error('Cannot merge a ticket into itself')
    const target = await Database.from('tickets').where('id', targetId).whereNull('deleted_at').first()
    if (!target) throw new Error('Target ticket not found')

    await Database.transaction(async (trx) => {
      for (const sourceId of sourceIds) {
        const source = await trx.from('tickets').where('id', sourceId).whereNull('deleted_at').first()
        if (!source) continue

        await trx.from('ticket_messages').where('ticket_id', sourceId).update({ ticket_id: targetId })
        await trx.from('ticket_attachments').where('ticket_id', sourceId).update({ ticket_id: targetId })
        await trx.from('ticket_cc_participants').where('ticket_id', sourceId).update({ ticket_id: targetId })

        await trx.from('tickets').where('id', sourceId).update({
          deleted_at: new Date(),
          merged_into_ticket_id: targetId,
          updated_at: new Date(),
        })

        await trx.table('ticket_activity_logs').insert({
          ticket_id: targetId,
          action: 'status_changed',
          actor_agent_id: requester?.id ?? null,
          actor_agent_name: requester?.name ?? null,
          from_value: `merged from #${source.ticket_uid}`,
          to_value: null,
          created_at: new Date(),
        })
      }
      await trx.from('tickets').where('id', targetId).update({ last_message_at: new Date() })
    })

    return Database.from('tickets').where('id', targetId).first()
  }

  // ============================================================
  // RESOLUTION
  // ============================================================
  public static async updateResolution(id: number, resolutionCode?: string, resolutionNotes?: string) {
    const patch: any = { updated_at: new Date() }
    if (resolutionCode !== undefined) patch.resolution_code = resolutionCode
    if (resolutionNotes !== undefined) patch.resolution_notes = resolutionNotes
    await Database.from('tickets').where('id', id).update(patch)
    return Database.from('tickets').where('id', id).first()
  }

  // ============================================================
  // BULK OPERATIONS
  // ============================================================
  public static async bulkAssign(ticketIds: number[], agentId: number, agentName: string, requester: any) {
    const results: any[] = []
    for (const id of ticketIds) {
      try { results.push(await this.assignTicket(id, agentId, agentName, requester)) }
      catch (e: any) { results.push({ id, error: e.message }) }
    }
    return results
  }

  public static async bulkUpdateStatus(ticketIds: number[], status: string) {
    if (!VALID_STATUSES.includes(status as any)) throw new Error(`Invalid status: ${status}`)
    await Database.from('tickets').whereIn('id', ticketIds).update({ status, updated_at: new Date() })
    return { status: true, count: ticketIds.length }
  }

  public static async bulkDelete(ticketIds: number[]) {
    await Database.from('tickets').whereIn('id', ticketIds).update({ deleted_at: new Date(), updated_at: new Date() })
    return { status: true, count: ticketIds.length }
  }


/**
 * Runs after a ticket is created manually from the Add Ticket modal:
 * resolves sender identification (org/employee match) and auto-assigns via
 * support_owner_id when nobody was explicitly picked in the modal.
 *
 * IMPORTANT: this used to ALSO send a templated "Your support ticket has
 * been created" auto-response email — that's been removed. Per the updated
 * Add Ticket flow, no automated response is ever sent; instead the agent's
 * own opening message (typed in the modal) is sent as a real reply — see
 * sendManualTicketInitialMessage(), called separately by
 * TicketController.create right after this.
 */
public static async finalizeManualTicketCreation(ticketId: number) {
  const ticket = await Database.from('tickets').where('id', ticketId).first()
  if (!ticket || !ticket.customer_email) return ticket

  const { default: MailIdentificationService } = await import('App/Services/MailIdentificationService')
  const identification = await MailIdentificationService.identifyByEmailEmployeeFirst(ticket.customer_email).catch((err) => {
    console.error(`[TicketService] manual identification failed for ${ticket.customer_email}:`, err.message)
    return { type: 'unidentified' as const, orgId: null, employeeId: null, logoUrl: null, name: null, orgName: null, orgEmail: null, supportOwnerId: null }
  })

  await Database.from('tickets').where('id', ticketId).update({
    sender_identification: identification.type,
    sender_org_id: identification.orgId,
    sender_org_name: identification.orgName,
    sender_employee_id: identification.employeeId,
    sender_logo_url: identification.logoUrl,
  })

  // Auto-assign by support_owner_id — same rule the email-intake path uses
  // (EmailToTicketService), just applied to manually-created tickets. Only
  // kicks in if nobody already assigned this ticket by hand.
  if (!ticket.assigned_to && (identification as any).supportOwnerId) {
    const ownerAgent = await Database.from('support_agents')
      .where('support_owner_id', (identification as any).supportOwnerId)
      .where('is_active', 1)
      .first()
    if (ownerAgent) {
      await Database.from('tickets').where('id', ticketId).update({
        assigned_to: ownerAgent.id,
        assigned_agent_name: ownerAgent.name,
        agent_last_active_at: new Date(),
      })
      await Database.table('ticket_assignment_history').insert({
        ticket_id: ticketId,
        agent_id: ownerAgent.id,
        agent_name: ownerAgent.name,
        assigned_by: null,
        created_at: new Date(),
      })
      ticket.assigned_to = ownerAgent.id
      ticket.assigned_agent_name = ownerAgent.name
    }
  }

  // NOTE: this used to build+send a templated "auto_ticket_response" email
  // right here (draft, Graph/SMTP send, mail_conversation_id patch, system
  // message insert). That's gone — no automated response is sent anymore.
  // See sendManualTicketInitialMessage() below for what replaced it.
  return Database.from('tickets').where('id', ticketId).first()
}

/**
 * Sends the agent's own opening message (typed in the Add Ticket modal) to
 * the customer as a real outbound reply — this is what replaced the old
 * "auto_ticket_response" auto-email. Mirrors
 * EmailToTicketService.sendAgentReplyByEmail's footer-resolution and
 * attachment-building so this message looks identical to any other agent
 * reply (personal signature, falling back to the org default footer), but
 * is written as its own method (rather than routed through addMessage)
 * because:
 *   - it must NOT go through assertCanActOnTicket's "picked up by another
 *     agent" gate — creating the ticket is always allowed for whoever
 *     created it, regardless of who it ends up auto-assigned to.
 *   - it needs to capture the resulting mail_conversation_id/mailbox_email
 *     onto the ticket itself (same as the old auto-response used to) so a
 *     customer's reply threads back onto this ticket correctly.
 *
 * No-ops quietly (returns the ticket unchanged) if there's no message text
 * and no attachments — an agent can create a bare ticket with nothing to
 * send yet.
 */
public static async sendManualTicketInitialMessage(
  ticketId: number,
  message: string | null | undefined,
  attachments: Array<{ fileName: string; contentType?: string; size?: number; storagePath: string }> = [],
  requester?: { id?: number; name?: string } | null
) {
  const ticket = await Database.from('tickets').where('id', ticketId).first()
  if (!ticket) return ticket
  if (!message?.trim() && !attachments?.length) return ticket

  const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
  const { default: MailAccountService } = await import('App/Services/MailAccountService')
  const { default: Helper } = await import('App/Helper/helper')

  // Agent's personal footer, falling back to the org-wide default — exact
  // same resolution EmailToTicketService.sendAgentReplyByEmail uses for
  // every other reply, so the opening message on a manually-created ticket
  // is indistinguishable from a normal one.
  let signatureHtml = ''
  if (requester?.id) {
    const agent = await Database.from('support_agents').select('signature_html', 'name').where('id', requester.id).first()
    if (agent?.signature_html?.trim()) {
      signatureHtml = agent.signature_html.trim().split('{{agent_name}}').join(agent.name ?? requester.name ?? '')
    }
  }
  if (!signatureHtml) {
    const { default: EmailTemplateService } = await import('App/Services/EmailTemplateService')
    const defaultFooter = await EmailTemplateService.get('agent_footer_default')
    if (defaultFooter?.trim()) signatureHtml = defaultFooter.trim()
  }

  const text = message?.trim() ?? ''
  const isHtmlMessage = /<[a-z][\s\S]*>/i.test(text)
  const messageBody = isHtmlMessage
    ? text
    : `<p style="margin:0 0 12px 0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:14px;line-height:1.6;color:#1e293b;">${Helper.linkifyMarkdown(text).replace(/\n/g, '<br/>')}</p>`

  // Ticket number goes IN the body the customer actually reads, not just
  // the subject line — subjects get stripped/lost on forwards, replies
  // from a different client, mobile notification previews, etc. This is
  // the one durable place it's guaranteed to be seen and easy to quote
  // back when they reply.
  const ticketRefBanner = `<p style="margin:0 0 14px 0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px;color:#64748b;">Ticket ID: <strong style="color:#1e293b;">${ticket.ticket_uid}</strong></p>`

  const html = signatureHtml
    ? `${ticketRefBanner}${messageBody}<div style="margin-top:16px;border-top:1px solid #e2e8f0;padding-top:12px;">${signatureHtml}</div>`
    : `${ticketRefBanner}${messageBody}`

  const graphAttachments = await EmailToTicketService.buildGraphFileAttachments(attachments)

  let deliveryStatus: 'sent' | 'failed' = 'sent'
  let failureReason: string | null = null
  let sendResult: { conversationId?: string; mailboxEmail?: string } = {}

  if (ticket.customer_email) {
    try {
      sendResult = await MailAccountService.sendMail({
        toEmail: ticket.customer_email,
        subject: ticket.subject ? `${ticket.subject} [${ticket.ticket_uid}]` : `Your support ticket ${ticket.ticket_uid}`,
        html,
        attachments: graphAttachments,
      })
      // [DIAGNOSTIC] What sendManualTicketInitialMessage actually received
      // back from MailAccountService.sendMail — the other end of the "catch"
      // (see the [conversationId-catch]/[conversationId-return] logs inside
      // sendMail itself). If conversationId is missing here despite those
      // logs showing it was returned, the problem is in this hand-off, not
      // in Graph's response.
      console.log(`[TicketService][sendManualTicketInitialMessage][conversationId-catch] ticket=${ticket.ticket_uid} sendResult.conversationId=${sendResult.conversationId ?? '(MISSING)'} sendResult.mailboxEmail=${sendResult.mailboxEmail ?? '(MISSING)'}`)
    } catch (outlookErr: any) {
      // ROOT CAUSE of "backend failed to catch sufficient id/information,
      // leading to failure of subsequent messages": when the Outlook/Graph
      // send fails (even after MailAccountService.sendMail's own retries)
      // and we fall back to SMTP, this SMTP path sends from a completely
      // unrelated address (noreply@notify.ubihrm.com — see Helper.sendEmail)
      // that nobody is polling for replies. `sendResult` never gets a
      // conversationId, so `mail_conversation_id` never gets set on the
      // ticket below — meaning every reply the customer sends afterwards
      // can NEVER be matched back to this ticket (see
      // EmailToTicketService.processIncomingMessage's
      // `where('mail_conversation_id', message.conversationId)` lookup).
      // The old code left this completely silent: deliveryStatus stayed
      // 'sent' (the SMTP send itself succeeded) with nothing recorded
      // anywhere to show the ticket's reply-thread is actually broken.
      //
      // Fix: keep sending via SMTP as a last resort so the customer still
      // gets *a* reply, but always leave a clear, persisted trail — both in
      // the logs and on the message itself — so agents/devs can see this
      // ticket has no working thread and know to investigate the Outlook
      // connection / manually re-send once it's back.
      console.error(`[TicketService][DEGRADED-THREAD] Outlook send failed for ticket ${ticket.ticket_uid} — falling back to SMTP. This ticket will NOT be able to receive threaded customer replies until re-sent via Outlook:`, outlookErr.message)
      try {
        await Helper.sendEmail(ticket.customer_email, `Your support ticket ${ticket.ticket_uid}`, html, 'X-Ticket-Uid', 'ubiSupport', 'noreply')
        failureReason = 'Sent via SMTP fallback (Outlook unavailable) — no mail thread established, customer replies will not be auto-tracked'
      } catch (smtpErr: any) {
        deliveryStatus = 'failed'
        failureReason = (smtpErr.message || 'Email send failed').slice(0, 250)
      }
    }
  } else {
    deliveryStatus = 'failed'
    failureReason = 'No customer email on file'
  }

  // Same reasoning as the old auto-response: without this the ticket never
  // gets a mail_conversation_id, so a customer reply can't be matched back
  // onto this ticket and creates a brand new one instead.
  //
  // [DIAGNOSTIC] The actual persist-or-not decision point — logs whether we're
  // about to write mail_conversation_id onto the ticket row, or skipping it
  // entirely (which is exactly the state that leaves a ticket unable to ever
  // match a future customer reply).
  console.log(`[TicketService][sendManualTicketInitialMessage][conversationId-persist-decision] ticket=${ticket.ticket_uid} willPersist=${!!sendResult.conversationId} conversationId=${sendResult.conversationId ?? '(none — mail_conversation_id will stay unset)'}`)
  if (sendResult.conversationId) {
    await Database.from('tickets').where('id', ticketId).update({
      mail_conversation_id: sendResult.conversationId,
      mailbox_email: sendResult.mailboxEmail,
    })
  }

  const [msgId] = await Database.table('ticket_messages').insert({
    ticket_id: ticketId,
    sender: 'agent',
    type: 'reply',
    message: html,
    sender_name: requester?.name ?? null,
    agent_id: requester?.id ?? null,
    to_recipients: JSON.stringify(ticket.customer_email ? [ticket.customer_email] : []),
    cc_recipients: JSON.stringify([]),
    bcc_recipients: JSON.stringify([]),
    channel: 'email',
    delivery_status: deliveryStatus,
    failure_reason: failureReason,
    created_at: new Date(),
  })

  if (attachments?.length) {
    try {
      await Database.table('ticket_attachments').insert(attachments.map((a) => ({
        ticket_id: ticketId,
        message_id: msgId,
        file_name: a.fileName,
        content_type: a.contentType ?? null,
        size: a.size ?? null,
        storage_path: a.storagePath,
        created_at: new Date(),
      })))
    } catch (err: any) {
      console.error(`[TicketService] failed to save initial-message attachments for ticket ${ticketId}:`, err.message)
    }
  }

  await Database.from('tickets').where('id', ticketId).update({
    last_message_at: new Date(),
    agent_last_active_at: new Date(),
  })

  return Database.from('tickets').where('id', ticketId).first()
}

  // ============================================================
  // DEV / TESTING ONLY
  // ============================================================
  /**
   * Generates `count` dummy tickets for UI/load testing. Goes through the
   * normal createTicket() path (so counts, filters, assignment-history etc.
   * all behave like real data) but deliberately skips
   * finalizeManualTicketCreation / sendManualTicketInitialMessage — no
   * emails are sent.
   */


public static async generateDummyTickets(count: number) {
  const firstNames = ['Amit', 'Priya', 'Rahul', 'Sneha', 'Vikram', 'Neha', 'Arjun', 'Pooja', 'Karan', 'Divya']
  const lastNames = ['Sharma', 'Verma', 'Gupta', 'Iyer', 'Patel', 'Reddy', 'Singh', 'Nair', 'Joshi', 'Mehta']
  const subjects = [
    'Unable to login to my account', 'Invoice discrepancy for last month', 'Feature request: dark mode',
    'App crashing on startup', 'Need help resetting password', 'Payment not reflecting',
    'Question about pricing plans', 'Export not working as expected', 'Slow response on dashboard',
    'Request for account upgrade',
  ]
  const statuses = ['open', 'on_hold', 'escalated', 'closed'] as const
  const priorities = ['low', 'medium', 'high'] as const
  const sources = ['manual', 'phone'] as const
  const senderIdentifications = ['organization', 'employee', 'unidentified'] as const
  const resolutionCodes = ['resolved', 'duplicate', 'not_reproducible', 'workaround_provided', 'wont_fix']

  const agents = await Database.from('support_agents').where('is_active', 1).select('id', 'name')

  const created: any[] = []
  for (let i = 0; i < count; i++) {
    const fn = firstNames[Math.floor(Math.random() * firstNames.length)]
    const ln = lastNames[Math.floor(Math.random() * lastNames.length)]
    const name = `${fn} ${ln}`
    const emailSafe = `${fn}.${ln}.${Date.now()}${i}`.toLowerCase().replace(/\s+/g, '')
    const agent = agents.length && Math.random() > 0.35
      ? agents[Math.floor(Math.random() * agents.length)]
      : null
    const prevAgent = agents.length && Math.random() > 0.7
      ? agents[Math.floor(Math.random() * agents.length)]
      : null

    const ticket = await this.createTicket({
      customerName: name,
      customerEmail: `${emailSafe}@example-dummy.test`,
      customerPhone: `9${Math.floor(100000000 + Math.random() * 899999999)}`,
      subject: subjects[Math.floor(Math.random() * subjects.length)],
      description: 'This is an auto-generated dummy ticket for testing purposes.',
      source: sources[Math.floor(Math.random() * sources.length)],
      priority: priorities[Math.floor(Math.random() * priorities.length)],
      assignedTo: agent?.id ?? null,
      assignedAgentName: agent?.name ?? null,
    })

    // createTicket only covers the original core fields — everything the schema
    // has grown since then gets backfilled here so dummy tickets exercise the
    // full column set, not just "Open" with nothing else set.
    const status = statuses[Math.floor(Math.random() * statuses.length)]
    const isClosed = status === 'closed'
    const reopenCount = isClosed && Math.random() > 0.7 ? Math.floor(Math.random() * 3) + 1 : 0

  const updatePayload: Record<string, any> = {
      updated_at: new Date(),
      is_read: Math.random() > 0.2 ? 1 : 0,
      is_spam: Math.random() > 0.95 ? 1 : 0,
      sender_identification: senderIdentifications[Math.floor(Math.random() * senderIdentifications.length)],
      reopen_count: reopenCount,
      last_reopened_at: reopenCount > 0 ? new Date() : null,
      due_date: Math.random() > 0.5
        ? new Date(Date.now() + Math.floor(Math.random() * 7) * 86400000)
        : null,
      agent_last_active_at: agent ? new Date() : null,
      prev_assigned_to: prevAgent?.id ?? null,
      prev_assigned_agent_name: prevAgent?.name ?? null,
      deleted_at: null,
      rating: Math.floor(Math.random() * 5) + 1,
      rating_submitted_at: new Date(),
      rating_liked_most: 'Quick response time.',
      rating_improve_feedback: 'Nothing, all good.',
    }

    if (status !== 'open') {
      updatePayload.status = status
    }

    if (isClosed) {
      updatePayload.resolution_code = resolutionCodes[Math.floor(Math.random() * resolutionCodes.length)]
      updatePayload.resolution_notes = 'Auto-resolved as part of dummy ticket generation.'

      if (Math.random() > 0.4) {
        updatePayload.feedback_token = randomUUID().replace(/-/g, '')
      }
    }

    if (status !== 'open') {
      updatePayload.status = status
    }

    if (isClosed) {
      updatePayload.resolution_code = resolutionCodes[Math.floor(Math.random() * resolutionCodes.length)]
      updatePayload.resolution_notes = 'Auto-resolved as part of dummy ticket generation.'

      if (Math.random() > 0.4) {
        updatePayload.feedback_token = randomUUID().replace(/-/g, '')

        if (Math.random() > 0.3) {
          updatePayload.rating = Math.floor(Math.random() * 5) + 1
          updatePayload.rating_submitted_at = new Date()
          updatePayload.rating_liked_most = 'Quick response time.'
          updatePayload.rating_improve_feedback = 'Nothing, all good.'
        }
      }
    }

    await Database.from('tickets').where('id', ticket.id).update(updatePayload)
    created.push(ticket.id)
  }

  return { status: true, created: created.length, ticketIds: created }
}

public static async restoreTicket(id: number) { 
  await Database.from('tickets').where('id', id).update({ deleted_at: null, updated_at: new Date() })
  return { status: true, msg: 'Ticket restored' }
}

/**
 * Boot-time counterpart to the auto-restore logic in addMessage() above.
 * That logic only fires for messages that arrive *while the app is
 * running* — a ticket that received a customer/agent reply while the
 * server happened to be down (deploy, crash, restart) would sit deleted
 * forever with an unread reply behind it, since nothing was listening to
 * un-delete it at the time. This sweeps every currently-deleted ticket
 * once at boot and restores (to Open) any that have an agent/customer
 * message timestamped after their deleted_at — i.e. a reply that came in
 * during the deleted window. Returns the restored ticket IDs so the
 * caller can kick off a scoped attachment health-check on just those
 * tickets (see AttachmentMigrationService.checkAndRepairAttachmentsForTickets).
 */
public static async reconcileDeletedTicketsOnBoot(): Promise<number[]> {
  const deletedTickets = await Database.from('tickets').whereNotNull('deleted_at').select('id', 'deleted_at')
  if (deletedTickets.length === 0) return []

  const restored: number[] = []
  for (const t of deletedTickets) {
    const laterMessage = await Database.from('ticket_messages')
      .where('ticket_id', t.id)
      .whereIn('sender', ['agent', 'customer'])
      .where('created_at', '>', t.deleted_at)
      .first()
    if (!laterMessage) continue

    await Database.from('tickets').where('id', t.id).update({ deleted_at: null, status: 'open' })
    restored.push(t.id)
  }

  if (restored.length) {
    console.log(`[TicketService][boot-reconcile] restored ${restored.length} deleted ticket(s) that received a message while deleted:`, restored)
    const { io } = await import('../../start/socket')
    io.emit('tickets_updated')
    io.emit('dashboard_stats_stale')
  }

  return restored
}
}