import Database from '@ioc:Adonis/Lucid/Database'
import Env from '@ioc:Adonis/Core/Env'
import fs from 'fs'
import Helper from 'App/Helper/helper';

export type SenderIdentification =
  | { type: 'organization'; orgId: number; employeeId: null; logoUrl: string; name: string; orgName: string; supportOwnerId: number | null }
  | { type: 'employee'; orgId: number; employeeId: number; logoUrl: string; name: string; orgName: string; supportOwnerId: number | null }
  | { type: 'unidentified'; orgId: null; employeeId: null; logoUrl: null; name: null; orgName: null; supportOwnerId: null }

  export type ManualTicketIdentification =
  | { type: 'employee'; orgId: number; employeeId: number; logoUrl: string; name: string; orgName: string; orgEmail: string | null; supportOwnerId: number | null }
  | { type: 'organization'; orgId: number; employeeId: null; logoUrl: string; name: string; orgName: string; orgEmail: string | null; supportOwnerId: number | null }
  | { type: 'unidentified'; orgId: null; employeeId: null; logoUrl: null; name: null; orgName: null; orgEmail: null; supportOwnerId: null }

export default class MailIdentificationService {
  /**
   * 1. Organization.Email match -> if Organization.Logo is present, resolve via
   *    getPreferredLogo(orgId) and return.
   * 2. Otherwise (no org match, OR org matched but Logo column empty) -> look up
   *    EmployeeMaster by CompanyEmail / CurrentEmailId. If found, resolve via
   *    getPreferredLogo(orgId, employeeId).
   * 3. Otherwise -> unidentified.
   */
public static async identifySender(email: string): Promise<SenderIdentification> {
  const logPrefix = `[identifySender]`
  console.info(`${logPrefix} Starting sender identification for email: "${email}"`)

  try {
    const normalizedEmail = email.trim().toLowerCase()
    const normalizedEmailEncoded = Helper.encode5t(normalizedEmail) 

    console.debug(`${logPrefix} Normalized Email: "${normalizedEmail}", Encoded: "${normalizedEmailEncoded}"`)

    // 1. Check Organization
    console.debug(`${logPrefix} Step 1: Querying Organization table...`) 
    const org = await Database.from('Organization')
      .where('Email', normalizedEmail)
      .select('Id', 'Logo', 'Name', 'supportowner_id')
      .first()

    if (org && org.Logo) {
      console.info(`${logPrefix} Match found in Organization table (Org ID: ${org.Id}, Name: "${org.Name}")`)
      
      console.debug(`${logPrefix} Fetching preferred logo for Org ID: ${org.Id}...`)
      const logoUrl = await this.getPreferredLogo(org.Id)

      console.info(`${logPrefix} Successfully identified sender as Organization.`)
      return {
        type: 'organization',
        orgId: org.Id,
        employeeId: null,
        logoUrl,
        name: org.Name,
        orgName: org.Name,
        supportOwnerId: org.supportowner_id ?? null,
      }
    }

    console.debug(`${logPrefix} Step 1 finished: No Organization match found with a valid logo.`)

    // 2. Check employee by CompanyEmail (uses idx_employee_email)
    console.debug(`${logPrefix} Step 2: Querying EmployeeMaster by CompanyEmail...`)
    let employee = await Database.from('EmployeeMaster as E')
      .join('Organization as O', 'O.Id', 'E.OrganizationId')
      .where('E.CompanyEmail', normalizedEmail)
      .select(
        'E.Id',
        'E.OrganizationId',
        'E.FirstName',
        'E.LastName',
        'E.ImageName',
        'O.Name as OrgName',
        'O.supportowner_id'
      )
      .first()

    if (employee) {
      console.info(`${logPrefix} Match found in EmployeeMaster via CompanyEmail (Employee ID: ${employee.Id})`)
    } else {
      // 3. If not found, check encoded CurrentEmailId (uses CurrentEmailId index)
      console.debug(`${logPrefix} Step 3: No match via CompanyEmail. Querying EmployeeMaster by Encoded CurrentEmailId...`)
      employee = await Database.from('EmployeeMaster as E')
        .join('Organization as O', 'O.Id', 'E.OrganizationId')
        .where('E.CurrentEmailId', normalizedEmailEncoded)
        .select(
          'E.Id',
          'E.OrganizationId',
          'E.FirstName',
          'E.LastName',
          'E.ImageName',
          'O.Name as OrgName',
          'O.supportowner_id'
        )
        .first()

      if (employee) {
        console.info(`${logPrefix} Match found in EmployeeMaster via CurrentEmailId (Employee ID: ${employee.Id})`)
      }
    }

    if (employee) {
      console.debug(`${logPrefix} Fetching profile logo for Org ID: ${employee.OrganizationId}, Employee ID: ${employee.Id}...`)
      const profilePic = this.buildProfileImageUrl(employee.OrganizationId, employee.ImageName)
      const logoUrl = profilePic || (await this.getPreferredLogo(employee.OrganizationId, employee.Id))

      const fullName = [employee.FirstName, employee.LastName].filter(Boolean).join(' ')
      console.info(`${logPrefix} Successfully identified sender as Employee: "${fullName}" (ID: ${employee.Id})`)

      return {
        type: 'employee',
        orgId: employee.OrganizationId,
        employeeId: employee.Id,
        logoUrl,
        name: fullName,
        orgName: employee.OrgName,
        supportOwnerId: employee.supportowner_id ?? null,
      }
    }

    // 4. Fallback: Unidentified
    console.warn(`${logPrefix} Identification complete: No match found for email "${normalizedEmail}". Returning unidentified.`)
    return {
      type: 'unidentified',
      orgId: null,
      employeeId: null,
      logoUrl: null,
      name: null,
      orgName: null,
      supportOwnerId: null,
    }

  } catch (error) {
    console.error(`${logPrefix} Error occurred during execution for email "${email}":`, error)
    throw error
  }
}

  // --- verbatim from the existing app, unchanged behavior ---
  public static async getPreferredLogo(orgId:string, userId: number | null = null) {
    let companyLogo = ''
    let whiteLabelingStatus = 0
    let groupCompaniesStatus = 0
    let divLogo = ''
    let HrmLink = ''
    let url = 'https://angular.ubihrm.com/public/uploads/41516/41516.png'

    if (userId) {
      const result = await Database.from('EmployeeMaster as E')
        .join('Organization as O', 'E.OrganizationId', 'O.Id')
        .leftJoin('DivisionMaster as D', 'E.Division', 'D.Id')
        .where('E.Id', userId)
        .where('E.OrganizationId', orgId)
        .select(
          'O.Logo as companyLogo',
          'O.white_labeling_sts as whiteLabelingStatus',
          'O.groupcompanies_sts as groupCompaniesStatus',
          'D.Logo as divLogo',
          'O.HrmLink as hrmLink'
        )
        .first()
      if (result) {
        companyLogo = result.companyLogo
        whiteLabelingStatus = result.whiteLabelingStatus
        groupCompaniesStatus = result.groupCompaniesStatus
        divLogo = result.divLogo
        HrmLink = result.hrmLink
      }
    } else {
      const org = await Database.from('Organization')
        .where('Id', orgId)
        .select('Logo as companyLogo', 'white_labeling_sts as whiteLabelingStatus', 'groupcompanies_sts as groupCompaniesStatus', 'HrmLink as hrmLink')
        .first()
      if (org) {
        companyLogo = org.companyLogo
        whiteLabelingStatus = org.whiteLabelingStatus
        groupCompaniesStatus = org.groupCompaniesStatus
        HrmLink = org.hrmLink
      }
    }

    if (groupCompaniesStatus == 1 && divLogo) {
      if (Env.get('LOCATION') == 'local') {
        const filePath = `public/uploads/${orgId}/division/${divLogo}`
        if (await fs.existsSync(filePath)) {
          url = `${Env.get('URL1')}public/uploads/${orgId}/division/${divLogo}`
        }
      } else {
        url = `${Env.get('PROFILEIMG')}${orgId}/division/${divLogo}?r=${Math.floor(Math.random() * 16777215)}`
      }
    } else if (companyLogo) {
      url = `${Env.get('ImageCDN')}public/uploads/${orgId}/${companyLogo}`
    } else if (whiteLabelingStatus == 1 && HrmLink) {
      url = HrmLink
    }
    return url
  }
  /**
   * Build a profile image URL from EmployeeMaster.ImageName
   * Pattern: PROFILEIMG + orgId + "/" + imageName
   */
  public static buildProfileImageUrl(orgId: string | number, imageName: string | null | undefined): string | null {
    if (!imageName) return null
    const base = Env.get('PROFILEIMG', '')
    if (!base) return null
    return `${base}${orgId}/${imageName}` 
  }

  /**
   * Identify a list of CC email addresses in bulk.
   * Looks up each email in EmployeeMaster (CompanyEmail) and Organization.
   * Returns an array of resolved participants — unidentified ones still
   * appear with just their email (name = null, avatarUrl = null).
   */
  public static async identifyMany(emails: string[]): Promise<Array<{
    email: string
    name: string | null
    avatarUrl: string | null
    orgId: number | null
    employeeId: number | null
  }>> {
    if (!emails.length) return []

    const results: Array<{
      email: string; name: string | null; avatarUrl: string | null
      orgId: number | null; employeeId: number | null
    }> = []

    for (const email of emails) {
      try {
        const normalizedEmail = email.trim().toLowerCase()
        const Helper = (await import('App/Helper/helper')).default
        const encoded = Helper.encode5t(normalizedEmail)

        // Try EmployeeMaster first (CompanyEmail then CurrentEmailId)
        let emp = await Database.from('EmployeeMaster as E')
          .where('E.CompanyEmail', normalizedEmail)
          .select('E.Id', 'E.OrganizationId', 'E.FirstName', 'E.LastName', 'E.ImageName')
          .first()

        if (!emp) {
          emp = await Database.from('EmployeeMaster as E')
            .where('E.CurrentEmailId', encoded)
            .select('E.Id', 'E.OrganizationId', 'E.FirstName', 'E.LastName', 'E.ImageName')
            .first()
        }

        if (emp) {
          const fullName = [emp.FirstName, emp.LastName].filter(Boolean).join(' ') || null
          const avatarUrl = this.buildProfileImageUrl(emp.OrganizationId, emp.ImageName)
          results.push({ email, name: fullName, avatarUrl, orgId: emp.OrganizationId, employeeId: emp.Id })
          continue
        }

        // Try Organization table
        const org = await Database.from('Organization')
          .where('Email', normalizedEmail)
          .select('Id', 'Name')
          .first()

        if (org) {
          results.push({ email, name: org.Name, avatarUrl: null, orgId: org.Id, employeeId: null })
          continue
        }

        // Unidentified
        results.push({ email, name: null, avatarUrl: null, orgId: null, employeeId: null })
      } catch (err: any) {
        console.error(`[identifyMany] Failed to identify ${email}:`, err.message)
        results.push({ email, name: null, avatarUrl: null, orgId: null, employeeId: null })
      }
    }

    return results
  }


   public static async identifyByEmailEmployeeFirst(email: string): Promise<ManualTicketIdentification> {
    const normalizedEmail = email.trim().toLowerCase()
    const normalizedEmailEncoded = Helper.encode5t(normalizedEmail)

    let employee = await Database.from('EmployeeMaster as E')
      .where('E.CompanyEmail', normalizedEmail)
      .select('E.Id', 'E.OrganizationId', 'E.FirstName', 'E.LastName', 'E.ImageName')
      .first()

    if (!employee) {
      employee = await Database.from('EmployeeMaster as E')
        .where('E.CurrentEmailId', normalizedEmailEncoded)
        .select('E.Id', 'E.OrganizationId', 'E.FirstName', 'E.LastName', 'E.ImageName')
        .first()
    }

    if (employee) {
      const org = await Database.from('Organization')
        .where('Id', employee.OrganizationId)
        .select('Name', 'Email', 'supportowner_id')
        .first()

      const profilePic = this.buildProfileImageUrl(employee.OrganizationId, employee.ImageName)
      const logoUrl = profilePic || (await this.getPreferredLogo(employee.OrganizationId, employee.Id))
      const fullName = [employee.FirstName, employee.LastName].filter(Boolean).join(' ')

      return {
        type: 'employee',
        orgId: employee.OrganizationId,
        employeeId: employee.Id,
        logoUrl,
        name: fullName,
        orgName: org?.Name ?? '',
        orgEmail: org?.Email ?? null,
        supportOwnerId: org?.supportowner_id ?? null,
      }
    }

    const org = await Database.from('Organization')
      .where('Email', normalizedEmail)
      .select('Id', 'Name', 'Email', 'supportowner_id')
      .first()

    if (org) {
      const logoUrl = await this.getPreferredLogo(org.Id)
      return {
        type: 'organization',
        orgId: org.Id,
        employeeId: null,
        logoUrl,
        name: org.Name,
        orgName: org.Name,
        orgEmail: org.Email ?? null,
        supportOwnerId: org.supportowner_id ?? null,
      }
    }

    return { type: 'unidentified', orgId: null, employeeId: null, logoUrl: null, name: null, orgName: null, orgEmail: null, supportOwnerId: null }
  }
}