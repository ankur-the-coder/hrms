import Database from '@ioc:Adonis/Lucid/Database'
import Hash from '@ioc:Adonis/Core/Hash'

export default class AgentService {
  public static async list() {
    return Database.from('support_agents')
      .select('id', 'name', 'username', 'role', 'is_active', 'signature_html', 'created_at')
      .orderBy('name', 'asc')
  }

  public static async create(data: { name: string; username: string; password: string; role: string }) {
    const [id] = await Database.table('support_agents').insert({
      name: data.name, username: data.username, password: await Hash.make(data.password),
      role: data.role, is_active: 1, created_at: new Date(), updated_at: new Date(),
    })
    return Database.from('support_agents').select('id', 'name', 'username', 'role', 'is_active', 'signature_html').where('id', id).first()
  }

  public static async update(id: number, data: any) {
    const patch: any = { updated_at: new Date() }
    if (data.name) patch.name = data.name
    if (data.username) patch.username = data.username
    if (data.password) patch.password = await Hash.make(data.password)
    if (data.role) patch.role = data.role
    if (data.isActive !== undefined) patch.is_active = data.isActive ? 1 : 0
    await Database.from('support_agents').where('id', id).update(patch)
    return Database.from('support_agents').select('id', 'name', 'username', 'role', 'is_active', 'signature_html').where('id', id).first()
  }

  public static async remove(id: number) {
    // Don't hard-delete — reassign their open tickets to unassigned instead of orphaning FK rows.
    await Database.from('tickets').where('assigned_to', id).update({ assigned_to: null, assigned_agent_name: null })
    await Database.from('support_agents').where('id', id).delete()
    return { status: true }
  }

  public static async getSignature(agentId: number) {
    const agent = await Database.from('support_agents').select('signature_html').where('id', agentId).first()
    return { signatureHtml: agent?.signature_html ?? null }
  }

  public static async updateSignature(agentId: number, signatureHtml: string) {
    await Database.from('support_agents').where('id', agentId).update({
      signature_html: signatureHtml,
      updated_at: new Date(),
    })
    return { status: true }
  }
}