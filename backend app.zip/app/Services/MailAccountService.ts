import Database from '@ioc:Adonis/Lucid/Database'
import Env from '@ioc:Adonis/Core/Env'
import Encryption from '@ioc:Adonis/Core/Encryption'
import axios from 'axios'
import AuthTracer, { redact } from 'App/Helper/AuthTracer'

/**
 * Persistence + lifecycle for connected Outlook mailboxes.
 * This is the DB-backed replacement for server.js's db.json helpers
 * (getDb/saveDb/saveTokens/getValidAccessToken/createWebhookSubscription).
 */
export default class MailAccountService {
  static GRAPH = 'https://graph.microsoft.com/v1.0'
  static TOKEN_URL = 'https://login.microsoftonline.com/common/oauth2/v2.0/token'
  static SCOPES = [
    'openid',
    'https://graph.microsoft.com/User.Read',
    'https://graph.microsoft.com/Mail.Read',
    'https://graph.microsoft.com/Mail.ReadWrite',
    'https://graph.microsoft.com/Mail.Send',
    'offline_access',
  ].join(' ')

  public static getAuthUrl(state?: string) {
    const params = new URLSearchParams({
      client_id: Env.get('MS_CLIENT_ID'),
      response_type: 'code',
      redirect_uri: Env.get('MS_REDIRECT_URI'),
      response_mode: 'query',
      scope: this.SCOPES,
      ...(state ? { state } : {}),
    })
    return `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?${params.toString()}`
  }

  /** Exchange an OAuth `code` for tokens, then upsert the mailbox row. */
  public static async handleCallback(code: string, connectedByAgentId?: number, tracer?: AuthTracer) {
    // Snapshot exactly what this running process has in memory for every env
    // var this flow depends on — the single most useful thing for catching a
    // stale build / stale PM2 worker after a deploy.
    tracer?.step('env_snapshot', {
      MS_CLIENT_ID: redact(Env.get('MS_CLIENT_ID')),
      MS_REDIRECT_URI: Env.get('MS_REDIRECT_URI'),
      PUBLIC_URL: Env.get('PUBLIC_URL'),
      FRONTEND_URL: Env.get('FRONTEND_URL'),
      notificationUrlThatWillBeUsed: `${Env.get('PUBLIC_URL')}/mail/webhook`,
    })

    tracer?.step('token_exchange_request', {
      url: this.TOKEN_URL,
      redirect_uri: Env.get('MS_REDIRECT_URI'),
      scope: this.SCOPES,
      code: redact(code),
    })

    let tokenRes
    try {
      tokenRes = await axios.post(
        this.TOKEN_URL,
        new URLSearchParams({
          client_id: Env.get('MS_CLIENT_ID'),
          scope: this.SCOPES,
          code,
          redirect_uri: Env.get('MS_REDIRECT_URI'),
          grant_type: 'authorization_code',
          client_secret: Env.get('MS_CLIENT_SECRET'),
        }),
        { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
      )
    } catch (err: any) {
      tracer?.error('token_exchange', err)
      throw err
    }

    const accessToken = tokenRes.data.access_token
    const refreshToken = tokenRes.data.refresh_token
    tracer?.step('token_exchange_response', {
      status: tokenRes.status,
      tokenType: tokenRes.data.token_type,
      expiresIn: tokenRes.data.expires_in,
      scopeGranted: tokenRes.data.scope,
      accessToken: redact(accessToken),
      refreshTokenPresent: !!refreshToken,
    })

    tracer?.step('graph_me_request', { url: `${this.GRAPH}/me` })
    let profile
    try {
      profile = await axios.get(`${this.GRAPH}/me`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
    } catch (err: any) {
      tracer?.error('graph_me_request', err)
      throw err
    }

    const email: string | undefined = profile.data.mail || profile.data.userPrincipalName
    tracer?.step('graph_me_response', {
      status: profile.status,
      email,
      displayName: profile.data.displayName,
    })
    if (!email) {
      const err = new Error('Could not retrieve user email address from Microsoft Graph.')
      tracer?.error('graph_me_response', err, { rawProfile: profile.data })
      throw err
    }

    const now = new Date()
    const existing = await Database.from('mail_accounts').where('email', email).first()
    tracer?.step('db_lookup', { email, existingAccountId: existing?.id ?? null })

    if (existing) {
      await Database.from('mail_accounts').where('id', existing.id).update({
        access_token: Encryption.encrypt(accessToken),
        refresh_token: Encryption.encrypt(refreshToken),
        // re-connecting preserves original connected_at cursor (or sets now if none)
        connected_at: existing.connected_at || now,
        webhook_failed: 0,
        is_active: 1,
        updated_at: now,
      })
      tracer?.step('db_updated_existing', { id: existing.id, email })
    } else {
      const anyAccount = await Database.from('mail_accounts').first()
      const isFirstAccount = !anyAccount

      await Database.table('mail_accounts').insert({
        email,
        display_name: profile.data.displayName ?? null,
        access_token: Encryption.encrypt(accessToken),
        refresh_token: Encryption.encrypt(refreshToken),
        token_updated_at: now,
        connected_at: now,
        is_active: 1,
        // First mailbox ever connected becomes the default sender automatically;
        // later connections stay non-default until an admin picks one in Settings.
        is_default: isFirstAccount ? 1 : 0,
        connected_by_agent_id: connectedByAgentId ?? null,
        created_at: now,
        updated_at: now,
      })
      tracer?.step('db_inserted_new', { email, isFirstAccount })
    }

    // Real-time webhook — Inbox (customer mail) + Sent Items (so a message
    // an agent sends straight from Outlook, not through this panel, is
    // captured too instead of being silently lost — see
    // createSentItemsSubscription).
    await this.createWebhookSubscription(email, accessToken, tracer)
    await this.createSentItemsSubscription(email, accessToken, tracer)

    return email
  }

  /** Returns a live access token, refreshing silently if it's stale (>50 min old). */
  public static async getValidAccessToken(email: string): Promise<string | null> {
    const account = await Database.from('mail_accounts').where('email', email).where('is_active', 1).first()
    if (!account) return null

    const ageMinutes = (Date.now() - new Date(account.token_updated_at).getTime()) / 60000
    if (ageMinutes < 50) {
      return Encryption.decrypt(account.access_token)
    }

try {
  const refreshToken = String(Encryption.decrypt(account.refresh_token))   // CHANGED: decrypt() returns unknown — cast to string
  const res = await axios.post(
    this.TOKEN_URL,
    new URLSearchParams({
      client_id: Env.get('MS_CLIENT_ID'),
      scope: this.SCOPES,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
      client_secret: Env.get('MS_CLIENT_SECRET'),
    }),
    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
  )

  const newAccessToken = res.data.access_token
  const newRefreshToken = res.data.refresh_token || refreshToken

  await Database.from('mail_accounts').where('id', account.id).update({
    access_token: Encryption.encrypt(newAccessToken),
    refresh_token: Encryption.encrypt(newRefreshToken),
    token_updated_at: new Date(),
    updated_at: new Date(),
  })

  return newAccessToken
} catch (err: any) {                                                       // CHANGED: err: any
  console.error(`[MailAccountService] silent refresh failed for ${email}:`, err?.response?.data ?? err.message)
  return null
}
  }

  /**
   * Best-effort delete of a Graph subscription. Used before creating a
   * replacement so we never end up with two live subscriptions on the same
   * mailbox+resource at once — see createWebhookSubscription's comment for
   * why that matters. Swallows 404s (already gone/expired) since that's a
   * success outcome for our purposes, not an error.
   */
  private static async deleteSubscription(subscriptionId: string, accessToken: string): Promise<void> {
    try {
      await axios.delete(`${this.GRAPH}/subscriptions/${subscriptionId}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
      console.log(`[MailAccountService] deleted old subscription ${subscriptionId}`)
    } catch (err: any) {
      // 404 just means Graph already expired/removed it — not an error.
      if (err?.response?.status !== 404) {
        console.error(`[MailAccountService] could not delete old subscription ${subscriptionId} (non-fatal):`, err?.response?.data ?? err.message)
      }
    }
  }

  public static async createWebhookSubscription(email: string, accessToken: string, tracer?: AuthTracer) {
    const notificationUrl = `${Env.get('PUBLIC_URL')}/mail/webhook`
    try {
      // ROOT CAUSE of "why so many null/failed rows in graph_webhook_notifications":
      // this used to always POST a brand-new subscription without ever
      // deleting whichever one this mailbox already had. The OLD
      // subscription doesn't expire for up to 48h, so for that whole window
      // BOTH the old and new subscription are live and Graph fires every
      // notification through both — but `mail_accounts.subscription_id`
      // only ever stores the latest one, so every notification carrying the
      // orphaned old id fails `findBySubscriptionId` forever (confirmed in
      // the exported table: two subscription ids delivering the exact same
      // graph_message_id at the same timestamp — one processes fine, the
      // other permanently fails with "no active mailbox for subscription").
      //
      // Fix: look up whatever subscription_id this mailbox currently has on
      // file and delete it FIRST, before creating the replacement, so at
      // most one subscription is ever live per mailbox.
      const existing = await Database.from('mail_accounts').where('email', email).first()
      if (existing?.subscription_id) {
        await this.deleteSubscription(existing.subscription_id, accessToken)
      }

      const expiry = new Date()
      expiry.setHours(expiry.getHours() + 48) // Graph max ~4230 min (~2.9 days)

      // Independently probe our own webhook endpoint right before asking Graph
      // to hit it — if THIS fails, the problem is proven to be reachability
      // (proxy/deploy), not Graph or your app logic at all.
      try {
        const probe = await axios.post(
          `${notificationUrl}?validationToken=self-probe-${Date.now()}`,
          {},
          { timeout: 8000, validateStatus: () => true }
        )
        tracer?.step('self_probe_notification_url', {
          notificationUrl,
          status: probe.status,
          body: typeof probe.data === 'string' ? probe.data.slice(0, 200) : probe.data,
        })
      } catch (probeErr: any) {
        tracer?.error('self_probe_notification_url', probeErr, { notificationUrl })
      }

      tracer?.step('webhook_subscribe_request', {
        url: `${this.GRAPH}/subscriptions`,
        notificationUrl,
        resource: "me/mailFolders('Inbox')/messages",
        expirationDateTime: expiry.toISOString(),
      })

      const res = await axios.post(
        `${this.GRAPH}/subscriptions`,
        {
          changeType: 'created',
          notificationUrl,
          resource: "me/mailFolders('Inbox')/messages",
          expirationDateTime: expiry.toISOString(),
        },
        { headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' } }
      )

      tracer?.step('webhook_subscribe_response', {
        status: res.status,
        subscriptionId: res.data.id,
        expirationDateTime: res.data.expirationDateTime,
      })

      await Database.from('mail_accounts').where('email', email).update({
        subscription_id: res.data.id,
        subscription_expires_at: new Date(res.data.expirationDateTime),
        webhook_failed: 0,
        updated_at: new Date(),
      })
      return true
    } catch (err:any) {
      console.error(`[MailAccountService] webhook subscribe failed for ${email}:`, err?.response?.data ?? err.message)
      tracer?.error('webhook_subscribe_request', err, { notificationUrl })
      await Database.from('mail_accounts').where('email', email).update({ webhook_failed: 1, updated_at: new Date() })
      return false
    }
  }

  /**
   * Second subscription per mailbox, watching Sent Items instead of Inbox.
   *
   * ROOT CAUSE this exists to fix: the Inbox subscription above only fires
   * for NEW INCOMING mail. A message an agent composes and sends directly
   * from Outlook (not through this panel) lands in Sent Items, which
   * nothing was watching — Graph had no subscription to fire from, so
   * there was no notification to miss; it was never sent one in the first
   * place. That's why such a message never appeared on the panel unless
   * the customer happened to reply (which triggered a reactive, one-off
   * Sent Items search — see the `originalAgentMessage` lookup in
   * processIncomingMessage). This subscription makes it real-time and
   * unconditional instead of "only if the customer replies first".
   *
   * Same orphan-prevention as createWebhookSubscription: deletes this
   * mailbox's existing Sent Items subscription (if any) before creating
   * the replacement, so at most one is ever live.
   */
  public static async createSentItemsSubscription(email: string, accessToken: string, tracer?: AuthTracer) {
    const notificationUrl = `${Env.get('PUBLIC_URL')}/mail/webhook`
    try {
      const existing = await Database.from('mail_accounts').where('email', email).first()
      if (existing?.sent_items_subscription_id) {
        await this.deleteSubscription(existing.sent_items_subscription_id, accessToken)
      }

      const expiry = new Date()
      expiry.setHours(expiry.getHours() + 48)

      const res = await axios.post(
        `${this.GRAPH}/subscriptions`,
        {
          changeType: 'created',
          notificationUrl,
          resource: "me/mailFolders('SentItems')/messages",
          expirationDateTime: expiry.toISOString(),
        },
        { headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' } }
      )

      tracer?.step('sent_items_subscribe_response', {
        status: res.status,
        subscriptionId: res.data.id,
        expirationDateTime: res.data.expirationDateTime,
      })

      await Database.from('mail_accounts').where('email', email).update({
        sent_items_subscription_id: res.data.id,
        sent_items_subscription_expires_at: new Date(res.data.expirationDateTime),
        updated_at: new Date(),
      })
      return true
    } catch (err: any) {
      console.error(`[MailAccountService] Sent Items webhook subscribe failed for ${email}:`, err?.response?.data ?? err.message)
      tracer?.error('sent_items_subscribe_request', err, { notificationUrl })
      return false
    }
  }

  /** Sent Items counterpart to renewSubscriptionInPlace — see that method's comment. */
  public static async renewSentItemsSubscriptionInPlace(email: string, accessToken: string): Promise<boolean> {
    const account = await Database.from('mail_accounts').where('email', email).first()
    if (!account?.sent_items_subscription_id) return false

    try {
      const expiry = new Date()
      expiry.setHours(expiry.getHours() + 48)
      const res = await axios.patch(
        `${this.GRAPH}/subscriptions/${account.sent_items_subscription_id}`,
        { expirationDateTime: expiry.toISOString() },
        { headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' } }
      )
      await Database.from('mail_accounts').where('email', email).update({
        sent_items_subscription_expires_at: new Date(res.data.expirationDateTime),
        updated_at: new Date(),
      })
      console.log(`[MailAccountService] renewed Sent Items subscription ${account.sent_items_subscription_id} in place for ${email}, new expiry ${res.data.expirationDateTime}`)
      return true
    } catch (err: any) {
      console.error(`[MailAccountService] Sent Items in-place renewal failed for ${email} (will fall back to create-new):`, err?.response?.data ?? err.message)
      return false
    }
  }

  /**
   * Preferred renewal path — PATCH the existing subscription's
   * expirationDateTime instead of creating a whole new one. This is
   * Microsoft's documented renewal pattern and — unlike
   * createWebhookSubscription — never has a window where two
   * subscriptions are simultaneously live, because no new subscription is
   * ever created. Returns false (without touching anything) if there's no
   * existing subscription to extend, or if Graph rejects the PATCH (e.g.
   * it already fully expired) — callers should fall back to
   * createWebhookSubscription in that case.
   */
  public static async renewSubscriptionInPlace(email: string, accessToken: string): Promise<boolean> {
    const account = await Database.from('mail_accounts').where('email', email).first()
    if (!account?.subscription_id) return false

    try {
      const expiry = new Date()
      expiry.setHours(expiry.getHours() + 48)
      const res = await axios.patch(
        `${this.GRAPH}/subscriptions/${account.subscription_id}`,
        { expirationDateTime: expiry.toISOString() },
        { headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' } }
      )
      await Database.from('mail_accounts').where('email', email).update({
        subscription_expires_at: new Date(res.data.expirationDateTime),
        webhook_failed: 0,
        updated_at: new Date(),
      })
      console.log(`[MailAccountService] renewed subscription ${account.subscription_id} in place for ${email}, new expiry ${res.data.expirationDateTime}`)
      return true
    } catch (err: any) {
      console.error(`[MailAccountService] in-place renewal failed for ${email} (will fall back to create-new):`, err?.response?.data ?? err.message)
      return false
    }
  }

  /**
   * Cron target: renew any subscription expiring within the next 6 hours.
   * Also triggers a catch-up fetch for any mail that arrived while the
   * subscription was down/expired — see `catchUpSinceLastExpiry()`.
   */
  public static async renewExpiringSubscriptions() {
    const cutoff = new Date(Date.now() + 6 * 60 * 60 * 1000)

    // Broadened to also catch a mailbox whose Sent Items subscription is
    // expiring soon even if its Inbox one still has plenty of runway —
    // otherwise such an account would never be selected here at all, and
    // the Sent Items branch below (which re-checks each subscription
    // independently) would never get the chance to run.
    const accounts = await Database.from('mail_accounts')
      .where('is_active', 1)
      .where((q) =>
        q
          .whereNull('subscription_id')
          .orWhereNull('subscription_expires_at')
          .orWhere('subscription_expires_at', '<', cutoff)
          .orWhereNull('sent_items_subscription_id')
          .orWhereNull('sent_items_subscription_expires_at')
          .orWhere('sent_items_subscription_expires_at', '<', cutoff)
      )

    console.log(
      `[MailAccountService][renewal] checked for expiring subscriptions (cutoff=${cutoff.toISOString()}) — ${accounts.length} account(s) need renewal`,
      accounts.map((a: any) => ({ id: a.id, email: a.email, subscription_expires_at: a.subscription_expires_at }))
    )

    for (const account of accounts) {
      console.log(`[MailAccountService][renewal] renewing subscription for ${account.email} (was expiring ${account.subscription_expires_at})`)
      const token = await this.getValidAccessToken(account.email)
      if (!token) {
        console.error(`[MailAccountService][renewal] FAILED for ${account.email} — could not obtain a valid access token (refresh token likely invalid/expired)`)
        continue
      }

      // Capture the OLD expiry before renewing — createWebhookSubscription()
      // overwrites subscription_expires_at with the new one, so this is our
      // only chance to know how far back the outage window goes.
      const previousExpiresAt: Date | null = account.subscription_expires_at ? new Date(account.subscription_expires_at) : null

      // Prefer extending the SAME subscription in place (no window where
      // two subscriptions are simultaneously live — see
      // createWebhookSubscription's comment on the orphaned-subscription
      // bug this avoids). Only create a brand new subscription if that's
      // not possible (e.g. it already fully expired and Graph 404s the PATCH).
      let ok = await this.renewSubscriptionInPlace(account.email, token)
      if (!ok) {
        ok = await this.createWebhookSubscription(account.email, token)
      }
      console.log(`[MailAccountService][renewal] ${ok ? 'SUCCESS' : 'FAILED'} renewing subscription for ${account.email}`)

      if (ok) {
        await this.catchUpSinceLastExpiry(account.id, account.email, token, previousExpiresAt)
      }

      // Sent Items subscription — same expiring-soon check and same
      // prefer-in-place-then-recreate fallback as the Inbox one above.
      // Evaluated per-account (using the same freshly-fetched token)
      // rather than as a separate DB scan, since accounts needing renewal
      // won't always line up between the two subscriptions.
      const sentItemsExpiresAt: Date | null = account.sent_items_subscription_expires_at
        ? new Date(account.sent_items_subscription_expires_at)
        : null
      const sentItemsNeedsRenewal = !account.sent_items_subscription_id || !sentItemsExpiresAt || sentItemsExpiresAt < cutoff
      if (sentItemsNeedsRenewal) {
        console.log(`[MailAccountService][renewal] renewing Sent Items subscription for ${account.email} (was expiring ${sentItemsExpiresAt?.toISOString() ?? '(none on record)'})`)
        let sentOk = await this.renewSentItemsSubscriptionInPlace(account.email, token)
        if (!sentOk) {
          sentOk = await this.createSentItemsSubscription(account.email, token)
        }
        console.log(`[MailAccountService][renewal] ${sentOk ? 'SUCCESS' : 'FAILED'} renewing Sent Items subscription for ${account.email}`)
      }
    }
  }

  /**
   * After a subscription is renewed, fetch any mail that arrived while it
   * was down — Graph never sent webhook notifications for that window, so
   * those messages would otherwise be silently missed.
   *
   * "Since" is:
   *   1. the subscription's previous expiry time, if one was on record, else
   *   2. the timestamp of the last message we saved for this mailbox
   *      (`processed_mail_messages.processed_at`), if any, else
   *   3. the mailbox's connected_at (nothing to catch up from before that
   *      anyway — see the same guard in handleIncomingMessage).
   */
  private static async catchUpSinceLastExpiry(
    accountId: number,
    mailboxEmail: string,
    accessToken: string,
    previousExpiresAt: Date | null
  ) {
    let since: Date
    let sinceSource: string

    if (previousExpiresAt) {
      since = previousExpiresAt
      sinceSource = 'previous subscription_expires_at'
    } else {
      const lastMessage = await Database.from('processed_mail_messages')
        .where('mailbox_email', mailboxEmail)
        .orderBy('processed_at', 'desc')
        .first()

      if (lastMessage?.processed_at) {
        since = new Date(lastMessage.processed_at)
        sinceSource = 'last saved message (processed_mail_messages.processed_at)'
      } else {
        const account = await Database.from('mail_accounts').where('id', accountId).first()
        since = account ? new Date(account.connected_at) : new Date(0)
        sinceSource = 'mailbox connected_at (no prior expiry or saved message on record)'
      }
    }

    console.log(
      `[MailAccountService][renewal][catch-up] fetching mail for ${mailboxEmail} received since ${since.toISOString()} (source: ${sinceSource})`
    )

    try {
      const res = await axios.get(
        `${this.GRAPH}/me/mailFolders('Inbox')/messages?$filter=receivedDateTime gt ${since.toISOString()}&$select=id,conversationId,receivedDateTime&$orderby=receivedDateTime asc`,
        { headers: { Authorization: `Bearer ${accessToken}` } }
      )
      const messages = res.data.value ?? []
      console.log(`[MailAccountService][renewal][catch-up] found ${messages.length} message(s) for ${mailboxEmail} possibly missed while the subscription was down`)

      const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
      for (const msg of messages) {
        try {
          await EmailToTicketService.handleIncomingMessage(mailboxEmail, msg.id)
        } catch (err: any) {
          console.error(`[MailAccountService][renewal][catch-up] failed to process message ${msg.id} for ${mailboxEmail}:`, err?.response?.data ?? err.message)
        }
      }

      await Database.from('mail_accounts').where('id', accountId).update({ last_synced_at: new Date(), updated_at: new Date() })
      console.log(`[MailAccountService][renewal][catch-up] done for ${mailboxEmail} — processed ${messages.length} message(s)`)
    } catch (err: any) {
      console.error(`[MailAccountService][renewal][catch-up] fetch failed for ${mailboxEmail}:`, err?.response?.data ?? err.message)
    }
  }

  /**
   * Resolves a Graph subscriptionId back to its mailbox — checking BOTH the
   * Inbox and Sent Items subscription columns, since a mailbox now has two
   * live subscriptions (see createSentItemsSubscription). Returns which
   * folder actually matched (`matchedFolder`) so the webhook processor can
   * route the notification to the right handler (customer mail vs. an
   * agent's own Outlook send) instead of assuming everything is Inbox.
   *
   * ROOT CAUSE this fixes: before this, only `subscription_id` (Inbox) was
   * checked, so every Sent Items notification failed to resolve any
   * mailbox at all and was permanently marked 'failed' with "no active
   * mailbox for subscription X" — the Sent Items subscription was being
   * created successfully but nothing was ever listening for its results.
   */
  public static async findBySubscriptionId(subscriptionId: string) {
    const inboxMatch = await Database.from('mail_accounts')
      .where('subscription_id', subscriptionId)
      .where('is_active', 1)
      .first()
    if (inboxMatch) return { ...inboxMatch, matchedFolder: 'inbox' as const }

    const sentItemsMatch = await Database.from('mail_accounts')
      .where('sent_items_subscription_id', subscriptionId)
      .where('is_active', 1)
      .first()
    if (sentItemsMatch) return { ...sentItemsMatch, matchedFolder: 'sentItems' as const }

    return null
  }

  public static async listAccounts() {
    const rows = await Database.from('mail_accounts')
      .where('is_active', 1)
      .select('id', 'email', 'display_name', 'connected_at', 'subscription_expires_at', 'webhook_failed', 'last_synced_at', 'is_default')
    return rows // tokens intentionally excluded
  }

  // ───────────────────────── Default mailbox (used for auto-responses, e.g. the WhatsApp -> email ack) ─────────────────────────
  /** The admin-picked default, or — if none picked yet — the first mailbox ever connected. */
  public static async getDefaultAccount() {
    const account = await Database.from('mail_accounts')
      .where('is_active', 1)
      .orderBy('is_default', 'desc')
      .orderBy('connected_at', 'asc')
      .first()
    return account || null
  }

  public static async setDefault(id: number) {
    const account = await Database.from('mail_accounts').where('id', id).where('is_active', 1).first()
    if (!account) return { status: false, msg: 'Account not found' }

    await Database.transaction(async (trx) => {
      await trx.from('mail_accounts').update({ is_default: 0 })
      await trx.from('mail_accounts').where('id', id).update({ is_default: 1, updated_at: new Date() })
    })
    return { status: true, msg: 'Default mailbox updated' }
  }

  // ───────────────────────── Outbound mail via Microsoft Graph ─────────────────────────
  /** Sends from the default mailbox unless accountId is given explicitly. Throws if no account is available/reachable. */
  public static async sendMail(params: {
    toEmail: string; subject: string; html: string; ccEmail?: string; accountId?: number
    // ccEmails/bccEmails: proper multi-recipient support. ccEmail (singular)
    // is kept for backward compatibility with existing callers and is
    // merged in alongside ccEmails if both happen to be passed.
    ccEmails?: string[]; bccEmails?: string[]
    // Already-built Graph fileAttachment objects (see
    // EmailToTicketService.buildGraphFileAttachments) — this is the
    // "compose fresh" path (no existing thread to /reply into), used e.g.
    // for a WhatsApp-origin ticket's first email or an agent reply before
    // the customer has replied to the auto-ack yet.
    attachments?: Array<{ '@odata.type': string; name: string; contentType: string; contentBytes: string }>
  }) {
    const account = params.accountId
      ? await Database.from('mail_accounts').where('id', params.accountId).where('is_active', 1).first()
      : await this.getDefaultAccount()

    if (!account) throw new Error('No active Outlook account is connected.')

    const token = await this.getValidAccessToken(account.email)
    if (!token) throw new Error(`Could not get a valid Graph token for ${account.email}.`)
    console.log('about to trigger graph api',params)

    // Dedup + drop empties/whitespace once, up front — shared by cc/bcc below.
    const uniqueEmails = (emails: Array<string | null | undefined>) => {
      const seen = new Set<string>()
      return emails
        .map((e) => (e ?? '').trim())
        .filter((e) => {
          if (!e) return false
          const key = e.toLowerCase()
          if (seen.has(key)) return false
          seen.add(key)
          return true
        })
    }
    const ccAll = uniqueEmails([params.ccEmail, ...(params.ccEmails ?? [])])
    const bccAll = uniqueEmails(params.bccEmails ?? [])

    // Two-step send (create draft, then /send) instead of the /sendMail action —
    // /sendMail returns no body, so it's impossible to learn the resulting
    // message id / conversationId. Creating the draft first gives us both
    // before sending, so callers can persist a thread to reply into later.
    // Attachments can be included directly in the draft-create body (same
    // fileAttachment shape Graph accepts on /reply and /forward).
    //
    // This pattern IS correct — it's the standard workaround for /sendMail's
    // empty response body. What was missing (and is the actual root cause of
    // tickets silently losing their reply-thread — see callers'
    // "sufficient id/information" symptom) is everything below: retrying
    // transient failures instead of giving up on the first blip, cleaning up
    // the orphaned draft if /send fails after it was created, and treating a
    // response with no conversationId as a hard failure instead of silently
    // handing callers back an incomplete result they might not check.
    let draftId: string | null = null
    let conversationId: string | undefined
    let lastErr: any = null

    // MAX_ATTEMPTS=2 (one retry) — enough to ride out a single transient
    // 429/5xx from Graph without turning a routine blip into a ticket that
    // permanently can't receive customer replies (see
    // TicketService.sendManualTicketInitialMessage's SMTP fallback, which is
    // exactly that failure mode: it sends from an unrelated noreply address
    // nobody is polling, so mail_conversation_id never gets set and every
    // later reply from the customer creates a brand-new ticket instead of
    // appending to this one).
    const MAX_ATTEMPTS = 2
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      try {
        const draft = await axios.post(
          `${this.GRAPH}/me/messages`,
          {
            subject: params.subject,
            body: { contentType: 'HTML', content: params.html },
            toRecipients: [{ emailAddress: { address: params.toEmail } }],
            ...(ccAll.length ? { ccRecipients: ccAll.map((e) => ({ emailAddress: { address: e } })) } : {}),
            ...(bccAll.length ? { bccRecipients: bccAll.map((e) => ({ emailAddress: { address: e } })) } : {}),
            ...(params.attachments?.length ? { attachments: params.attachments } : {}),
          },
          { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, timeout: 15000 }
        )
        draftId = draft.data.id
        conversationId = draft.data.conversationId
        const internetMessageId: string | undefined = draft.data.internetMessageId

        // [DIAGNOSTIC] Exactly the point where we try to "catch" conversationId
        // straight off the draft-create response — logs the raw id fields Graph
        // handed back so we can see directly whether conversationId came through
        // or arrived empty/undefined.
        console.log(`[MailAccountService][sendMail][conversationId-catch] account=${account.email} attempt=${attempt} draftId=${draftId} conversationId=${conversationId ?? '(MISSING)'} rawDraftKeys=${Object.keys(draft.data ?? {}).join(',')}`)

        // A draft with no conversationId is useless to us — the whole point
        // of this two-step dance is to capture it before sending. Fail loudly
        // here rather than letting a caller silently store `undefined` and
        // discover it later when a customer reply can't be matched to any
        // ticket.
        if (!conversationId) throw new Error(`Graph returned no conversationId for draft ${draftId}`)

        try {
          await axios.post(
            `${this.GRAPH}/me/messages/${draftId}/send`,
            {},
            { headers: { Authorization: `Bearer ${token}` }, timeout: 15000 }
          )
        } catch (sendErr: any) {
          // The draft exists but never got sent — clean it up (best-effort)
          // so it doesn't sit in Drafts forever as an orphan, then surface a
          // clear error. Without this, a /send failure left a dangling draft
          // AND threw an error indistinguishable from "nothing happened at
          // all", which is what made this so hard to diagnose.
          await axios.delete(`${this.GRAPH}/me/messages/${draftId}`, { headers: { Authorization: `Bearer ${token}` } }).catch((delErr: any) => {
            console.error(`[MailAccountService] orphaned draft ${draftId} could not be cleaned up for ${account.email}:`, delErr?.response?.data ?? delErr.message)
          })
          throw new Error(`Draft ${draftId} was created but /send failed: ${sendErr?.response?.data?.error?.message ?? sendErr.message}`)
        }

        // [DIAGNOSTIC] Confirms conversationId survived the /send call intact
        // (it's read from the same closure variable, not re-fetched from Graph
        // post-send — this line proves what's actually being returned/persisted).
        console.log(`[MailAccountService][sendMail][conversationId-return] account=${account.email} returning conversationId=${conversationId} messageId(draftId, may go stale after send)=${draftId}`)

        return { fromAccount: account.email, mailboxEmail: account.email, conversationId, messageId: draftId, internetMessageId }
      } catch (err: any) {
        lastErr = err
        const status = err?.response?.status
        const transient = status === 429 || (status && status >= 500)
        console.error(`[MailAccountService] sendMail attempt ${attempt}/${MAX_ATTEMPTS} failed for ${account.email}${transient ? ' (transient, will retry)' : ''}:`, err?.response?.data ?? err.message)
        if (!transient || attempt === MAX_ATTEMPTS) throw lastErr
        await new Promise((resolve) => setTimeout(resolve, 1000 * attempt)) // 1s, then 2s
      }
    }

    // Unreachable — the loop above always returns or throws — but keeps TS happy.
    throw lastErr ?? new Error('sendMail failed for an unknown reason')
  }

  public static async disconnect(id: number) {
    const account = await Database.from('mail_accounts').where('id', id).first()
    if (!account) return { status: false, msg: 'Account not found' }

    if (account.subscription_id) {
      const token = await this.getValidAccessToken(account.email)
      if (token) {
        await axios.delete(`${this.GRAPH}/subscriptions/${account.subscription_id}`, {
          headers: { Authorization: `Bearer ${token}` },
        }).catch(() => {}) // best-effort
      }
    }

    await Database.from('mail_accounts').where('id', id).update({ is_active: 0, subscription_id: null, updated_at: new Date() })
    return { status: true, msg: 'Mailbox disconnected' }
  }

  /**
   * Boot-time + safety-net sync for messages missed while the server was
   * down — checks every active mailbox for mail received between its last
   * known point (`last_synced_at`, falling back to `connected_at` if it's
   * never synced) and now.
   *
   * NOTE: like `renewExpiringSubscriptions()` used to be, this function
   * existed but was never actually invoked anywhere in the app — no boot
   * hook called it. See the call in `start/socket.ts` (inside the
   * `if (!alreadyBound)` guard) which now runs this once per real server
   * boot.
   */
  public static async performCatchUpSync() {
    const accounts = await Database.from('mail_accounts').where('is_active', 1)
    console.log(`[MailAccountService][boot-catch-up] server starting — checking ${accounts.length} active mailbox(es) for missed mail`)

    for (const account of accounts) {
      try {
        const since = account.last_synced_at
          ? new Date(account.last_synced_at).toISOString()
          : new Date(account.connected_at).toISOString() // never before the connect cursor

        console.log(`[MailAccountService][boot-catch-up] ${account.email}: checking mail received since ${since} (source: ${account.last_synced_at ? 'last_synced_at' : 'connected_at, never synced before'})`)

        const token = await this.getValidAccessToken(account.email)
        if (!token) {
          console.error(`[MailAccountService][boot-catch-up] FAILED for ${account.email} — could not obtain a valid access token`)
          continue
        }

        // 1. Inbox (incoming customer mail)
        const inboxRes = await axios.get(
          `${this.GRAPH}/me/mailFolders('Inbox')/messages?$filter=receivedDateTime gt ${since}&$select=id,conversationId,receivedDateTime&$orderby=receivedDateTime asc`,
          { headers: { Authorization: `Bearer ${token}` } }
        ).catch(() => ({ data: { value: [] } }))
        const inboxMessages = inboxRes.data?.value ?? []

        // 2. Sent Items (outbound agent mail sent from Outlook)
        const sentRes = await axios.get(
          `${this.GRAPH}/me/mailFolders('SentItems')/messages?$filter=sentDateTime gt ${since}&$select=id,conversationId,sentDateTime&$orderby=sentDateTime asc`,
          { headers: { Authorization: `Bearer ${token}` } }
        ).catch(() => ({ data: { value: [] } }))
        const sentMessages = sentRes.data?.value ?? []

        console.log(`[MailAccountService][boot-catch-up] ${account.email}: found ${inboxMessages.length} inbox + ${sentMessages.length} sent-items message(s) received while server was down`)

        const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')
        for (const msg of inboxMessages) {
          try {
            await EmailToTicketService.handleIncomingMessage(account.email, msg.id)
          } catch (err: any) {
            console.error(`[MailAccountService][boot-catch-up] failed to process inbox message ${msg.id} for ${account.email}:`, err?.response?.data ?? err.message)
          }
        }
        for (const msg of sentMessages) {
          try {
            await EmailToTicketService.handleSentMessage(account.email, msg.id)
          } catch (err: any) {
            console.error(`[MailAccountService][boot-catch-up] failed to process sent message ${msg.id} for ${account.email}:`, err?.response?.data ?? err.message)
          }
        }

        await Database.from('mail_accounts').where('id', account.id).update({ last_synced_at: new Date(), updated_at: new Date() })
        console.log(`[MailAccountService][boot-catch-up] ${account.email}: done — processed ${inboxMessages.length + sentMessages.length} message(s)`)
      } catch (err:any) {
        console.error(`[MailAccountService][boot-catch-up] failed for ${account.email}:`, err?.response?.data ?? err.message)
      }
    }
  }

  /**
   * Requested safeguard: an independent hourly check, separate from both the
   * live webhook and its retry queue (see GraphWebhookNotificationService),
   * that re-fetches the previous hour of mail directly from Graph for every
   * connected mailbox and cross-checks it against `processed_mail_messages`.
   * Anything that slipped through both the webhook AND its retries (e.g. a
   * subscription silently went stale, or a notification's retries were all
   * exhausted) gets processed here instead of staying lost indefinitely.
   *
   * Scoped to a single trailing hour for both Inbox and Sent Items so it
   * recovers any missed customer or agent emails.
   */
  public static async verifyPreviousHourSync() {
    const accounts = await Database.from('mail_accounts').where('is_active', 1)
    const windowEnd = new Date()
    const windowStart = new Date(windowEnd.getTime() - 60 * 60 * 1000)
    console.log(`[MailAccountService][hourly-verify] checking ${accounts.length} mailbox(es) for mail received/sent between ${windowStart.toISOString()} and ${windowEnd.toISOString()}`)

    const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')

    for (const account of accounts) {
      try {
        const token = await this.getValidAccessToken(account.email)
        if (!token) {
          console.error(`[MailAccountService][hourly-verify] FAILED for ${account.email} — could not obtain a valid access token`)
          continue
        }

        const [inboxRes, sentRes] = await Promise.all([
          axios.get(
            `${this.GRAPH}/me/mailFolders('Inbox')/messages?$filter=receivedDateTime ge ${windowStart.toISOString()} and receivedDateTime le ${windowEnd.toISOString()}&$select=id,conversationId,receivedDateTime&$orderby=receivedDateTime asc&$top=200`,
            { headers: { Authorization: `Bearer ${token}` } }
          ).catch(() => ({ data: { value: [] } })),
          axios.get(
            `${this.GRAPH}/me/mailFolders('SentItems')/messages?$filter=sentDateTime ge ${windowStart.toISOString()} and sentDateTime le ${windowEnd.toISOString()}&$select=id,conversationId,sentDateTime&$orderby=sentDateTime asc&$top=200`,
            { headers: { Authorization: `Bearer ${token}` } }
          ).catch(() => ({ data: { value: [] } })),
        ])

        const inboxMessages = inboxRes.data?.value ?? []
        const sentMessages = sentRes.data?.value ?? []

        let recovered = 0
        for (const msg of inboxMessages) {
          const already = await Database.from('processed_mail_messages').where('graph_message_id', msg.id).first()
          if (already) continue
          recovered++
          console.warn(`[MailAccountService][hourly-verify] ${account.email}: inbox message ${msg.id} was never processed by the webhook or its retries — processing now`)
          await EmailToTicketService.handleIncomingMessage(account.email, msg.id).catch((err: any) =>
            console.error(`[MailAccountService][hourly-verify] failed to process recovered inbox message ${msg.id} for ${account.email}:`, err?.response?.data ?? err.message)
          )
        }

        for (const msg of sentMessages) {
          const already = await Database.from('ticket_messages').where('graph_message_id', msg.id).first()
          if (already) continue
          recovered++
          console.warn(`[MailAccountService][hourly-verify] ${account.email}: sent message ${msg.id} was never processed — processing now`)
          await EmailToTicketService.handleSentMessage(account.email, msg.id).catch((err: any) =>
            console.error(`[MailAccountService][hourly-verify] failed to process recovered sent message ${msg.id} for ${account.email}:`, err?.response?.data ?? err.message)
          )
        }

        console.log(`[MailAccountService][hourly-verify] ${account.email}: checked ${inboxMessages.length} inbox + ${sentMessages.length} sent message(s) from the last hour, recovered ${recovered} missed`)
      } catch (err: any) {
        console.error(`[MailAccountService][hourly-verify] failed for ${account.email}:`, err?.response?.data ?? err.message)
      }
    }
  }
}

// ───────────────────────── Subscription auto-renewal scheduler ─────────────────────────
// ROOT CAUSE of "subscription expired but didn't renew": `renewExpiringSubscriptions()`
// above was dead code — nothing in the app ever called it. There was no cron entry,
// no scheduler, no boot hook. This starts a self-contained interval, right here in the
// service module, so it runs regardless of how the rest of the app is wired up.
//
// Override the interval for local testing via env, e.g. in .env:
//   SUBSCRIPTION_RENEWAL_CHECK_INTERVAL_MS=20000   (check every 20s)
const RENEWAL_CHECK_INTERVAL_MS = Number(process.env.SUBSCRIPTION_RENEWAL_CHECK_INTERVAL_MS) || 5 * 60 * 1000 // default: every 5 min

let renewalSchedulerStarted = false

function startSubscriptionRenewalScheduler() {
  if (renewalSchedulerStarted) return // guard against double-start on hot reload
  renewalSchedulerStarted = true

  console.log(`[MailAccountService][renewal-scheduler] starting — checking every ${Math.round(RENEWAL_CHECK_INTERVAL_MS / 1000)}s`)

  const tick = async () => {
    console.log('[MailAccountService][renewal-scheduler] tick — checking for expiring subscriptions...')
    try {
      await MailAccountService.renewExpiringSubscriptions()
    } catch (err: any) {
      console.error('[MailAccountService][renewal-scheduler] tick failed:', err?.response?.data ?? err.message)
    }
  }

  tick() // also run once immediately at boot instead of waiting for the first interval
  setInterval(tick, RENEWAL_CHECK_INTERVAL_MS)
}

startSubscriptionRenewalScheduler()

// ───────────────────────── Hourly "previous hour" verification safeguard ─────────────────────────
// Requested safeguard — runs independently of the webhook and its retry
// queue, re-checking the last hour of mail directly against Graph so a
// silently-stale subscription or an exhausted retry doesn't go unnoticed.
//
// Override the interval for local testing via env, e.g. in .env:
//   MAIL_HOURLY_VERIFY_INTERVAL_MS=20000   (check every 20s)
const HOURLY_VERIFY_INTERVAL_MS = Number(process.env.MAIL_HOURLY_VERIFY_INTERVAL_MS) || 60 * 60 * 1000 // default: every 1h

let hourlyVerifySchedulerStarted = false

function startHourlyVerifyScheduler() {
  if (hourlyVerifySchedulerStarted) return // guard against double-start on hot reload
  hourlyVerifySchedulerStarted = true

  console.log(`[MailAccountService][hourly-verify-scheduler] starting — checking every ${Math.round(HOURLY_VERIFY_INTERVAL_MS / 60000)}min`)

  const tick = async () => {
    console.log('[MailAccountService][hourly-verify-scheduler] tick — verifying previous hour of mail...')
    try {
      await MailAccountService.verifyPreviousHourSync()
    } catch (err: any) {
      console.error('[MailAccountService][hourly-verify-scheduler] tick failed:', err?.response?.data ?? err.message)
    }
  }

  // Deliberately NOT running immediately at boot — performCatchUpSync
  // (invoked separately from start/socket.ts) already covers "since last
  // sync" right at startup; running this too would just duplicate that on
  // every restart. First run happens after the first full interval.
  setInterval(tick, HOURLY_VERIFY_INTERVAL_MS)
}

startHourlyVerifyScheduler()