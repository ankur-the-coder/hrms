import Database from '@ioc:Adonis/Lucid/Database'
import Application from '@ioc:Adonis/Core/Application'
import axios from 'axios'
import fs from 'fs/promises'
import { existsSync } from 'fs'
import path from 'path'
import MailAccountService from 'App/Services/MailAccountService'
import { uploadBufferToS3, isS3Url, isUrlReachable } from 'App/Helper/StorageS3'

const GRAPH = 'https://graph.microsoft.com/v1.0'

// Stop retrying a permanently-unrecoverable attachment (source email/message
// deleted, WhatsApp-origin with no email to fall back to, etc) instead of
// hammering Graph every 6 hours forever. Override in .env if needed:
//   ATTACHMENT_MAX_REPAIR_ATTEMPTS=10
const MAX_REPAIR_ATTEMPTS = Number(process.env.ATTACHMENT_MAX_REPAIR_ATTEMPTS) || 5

type AttachmentRow = {
  id: number
  ticket_id: number
  message_id: number
  file_name: string
  content_type: string | null
  size: number | null
  storage_path: string
  repair_attempts: number
  is_broken: boolean
}

/**
 * Handles two related but separate jobs:
 *
 *   1. migrateLegacyAttachmentsToS3()  — ONE-TIME backfill. Walks every
 *      ticket_attachments row still pointing at a local `public/uploads/...`
 *      file (saved before the app switched to S3) and uploads it to S3,
 *      rewriting storage_path to the new URL. Safe to re-run — anything
 *      already migrated (storage_path is already an http(s) URL) is skipped.
 *
 *   2. checkAndRepairBrokenAttachments() — RECURRING (every 6h, see the
 *      scheduler at the bottom of this file). HEAD-checks every already-
 *      migrated attachment to catch ones that silently went missing from S3
 *      (deleted object, bucket policy change, interrupted upload, etc), and
 *      double-checks any attachment still stuck on local disk in case that
 *      file has gone missing too. Anything broken gets re-fetched straight
 *      from the original source email via Microsoft Graph (same mechanism
 *      EmailToTicketService already uses for inline images) and re-uploaded
 *      to S3. Attachments with no recoverable email source (WhatsApp-origin,
 *      or the ticket has no graph_message_id on file) are flagged but left
 *      alone — there's nothing to re-fetch them from.
 */
export default class AttachmentMigrationService {
  // ───────────────────────── One-time backfill ─────────────────────────

  public static async migrateLegacyAttachmentsToS3() {
    const rows: AttachmentRow[] = await Database.from('ticket_attachments').whereRaw("storage_path NOT LIKE 'http%'")

    const summary = { total: rows.length, migrated: 0, missingOnDisk: 0, failed: 0 }
    console.log(`[AttachmentMigrationService][migrate] starting — ${rows.length} legacy attachment(s) to check.`)

    let processed = 0
    for (const row of rows) {
      const result = await this.migrateOneLegacyRow(row)
      if (result === 'migrated') summary.migrated++
      else if (result === 'missing') summary.missingOnDisk++
      else summary.failed++

      processed++
      if (processed % 25 === 0) {
        console.log(`[AttachmentMigrationService][migrate] progress: ${processed}/${rows.length}`)
      }
    }

    console.log('[AttachmentMigrationService][migrate] finished:', summary)
    return summary
  }

  /** Migrates a single legacy (local-disk) row. Returns 'migrated' | 'missing' | 'failed'. Shared by the bulk job and the opportunistic sweep inside the health check. */
  private static async migrateOneLegacyRow(row: AttachmentRow): Promise<'migrated' | 'missing' | 'failed'> {
    try {
      // Adonis serves the `public/` folder at the site root, so a stored
      // path like `ticket-attachments/12/foo.png` (or a bare legacy filename)
      // lives on disk at public/uploads/<storage_path> — matching what
      // ticket-detail.ts's attachmentUrl() has always requested it at
      // (`${apiUrl}/uploads/${storage_path}`).
      const localPath = Application.publicPath('uploads', row.storage_path)

      if (!existsSync(localPath)) {
        await Database.from('ticket_attachments').where('id', row.id).update({
          is_broken: true,
          last_checked_at: new Date(),
        })
        console.warn(`[AttachmentMigrationService][migrate] missing on disk — flagged broken: attachment id=${row.id} ticket=${row.ticket_id} path=${localPath}`)
        return 'missing'
      }

      const buffer = await fs.readFile(localPath)
      const safeName = `${Date.now()}_${path.basename(row.storage_path)}`.replace(/[^a-zA-Z0-9._-]/g, '_')
      const key = `ticket-attachments/${row.ticket_id}/${safeName}`
      const s3Url = await uploadBufferToS3(key, buffer, row.content_type || undefined)

      await Database.from('ticket_attachments').where('id', row.id).update({
        storage_path: s3Url,
        is_broken: false,
        last_checked_at: new Date(),
      })
      return 'migrated'
    } catch (err: any) {
      await Database.from('ticket_attachments').where('id', row.id).update({ last_checked_at: new Date() })
      console.error(`[AttachmentMigrationService][migrate] failed for attachment id=${row.id}:`, err.message)
      return 'failed'
    }
  }

  // ───────────────────────── Recurring health check ─────────────────────────

  public static async checkAndRepairBrokenAttachments() {
    const summary = { checked: 0, migratedOpportunistically: 0, brokenFound: 0, repaired: 0, unrecoverable: 0, skippedMaxAttempts: 0 }

    const allRows: AttachmentRow[] = await Database.from('ticket_attachments')
    console.log(`[AttachmentMigrationService][health-check] starting — ${allRows.length} attachment(s) to verify.`)

    for (const row of allRows) {
      if (row.repair_attempts >= MAX_REPAIR_ATTEMPTS) {
        summary.skippedMaxAttempts++
        continue
      }

      summary.checked++

      if (!isS3Url(row.storage_path)) {
        // Still on local disk. If it hasn't been migrated yet, opportunistically
        // migrate it now (self-heals anything the one-time backfill missed or
        // that predates that run) rather than waiting for someone to re-run
        // migrateLegacyAttachmentsToS3() by hand. If the local file is gone,
        // migrateOneLegacyRow already flags it broken — fall through to repair.
        const result = await this.migrateOneLegacyRow(row)
        if (result === 'migrated') {
          summary.migratedOpportunistically++
          continue
        }
        if (result === 'failed') continue // transient (S3 error etc) — leave it, next tick retries
        // result === 'missing' → treat exactly like a broken S3 object below
      } else {
        const reachable = await isUrlReachable(row.storage_path)
        if (reachable) {
          if (row.is_broken) {
            await Database.from('ticket_attachments').where('id', row.id).update({ is_broken: false, last_checked_at: new Date() })
          } else {
            await Database.from('ticket_attachments').where('id', row.id).update({ last_checked_at: new Date() })
          }
          continue
        }
      }

      summary.brokenFound++
      const repaired = await this.attemptRepairFromEmail(row)
      if (repaired) summary.repaired++
      else summary.unrecoverable++
    }

    console.log('[AttachmentMigrationService][health-check] finished:', summary)
    return summary
  }

  /**
   * Re-fetches one broken attachment straight from the original inbound
   * email via Microsoft Graph (same `/messages/{id}/attachments` endpoint
   * EmailToTicketService.resolveInlineAttachments() already uses) and
   * re-uploads it to S3. Only works for email-origin tickets whose source
   * message is still on the mailbox — there's no equivalent "refetch" path
   * for WhatsApp media (Meta's media URLs/IDs expire) or for tickets created
   * before graph_message_id was being recorded, so those are left flagged
   * broken rather than silently dropped.
   */
  private static async attemptRepairFromEmail(row: AttachmentRow): Promise<boolean> {
    const message = await Database.from('ticket_messages').where('id', row.message_id).first()
    const ticket = await Database.from('tickets').where('id', row.ticket_id).first()
    const nextAttempts = (row.repair_attempts || 0) + 1

    if (!message?.graph_message_id || !ticket?.mailbox_email) {
      await Database.from('ticket_attachments').where('id', row.id).update({
        is_broken: true,
        last_checked_at: new Date(),
        repair_attempts: nextAttempts,
      })
      console.warn(`[AttachmentMigrationService][repair] no recoverable email source for attachment id=${row.id} (ticket #${row.ticket_id}, source=${ticket?.source ?? 'unknown'}) — cannot re-fetch. attempt ${nextAttempts}/${MAX_REPAIR_ATTEMPTS}`)
      return false
    }

    try {
      const token = await MailAccountService.getValidAccessToken(ticket.mailbox_email)
      if (!token) throw new Error(`no valid access token for mailbox ${ticket.mailbox_email}`)

      const { data } = await axios.get(`${GRAPH}/me/messages/${message.graph_message_id}/attachments`, {
        headers: { Authorization: `Bearer ${token}` },
      })

      const match = (data.value ?? []).find((a: any) =>
        a['@odata.type'] === '#microsoft.graph.fileAttachment' && a.name === row.file_name
      )
      if (!match) throw new Error(`"${row.file_name}" is no longer present on source message ${message.graph_message_id}`)

      const buffer = Buffer.from(match.contentBytes, 'base64')
      const safeName = `${Date.now()}_${row.file_name}`.replace(/[^a-zA-Z0-9._-]/g, '_')
      const key = `ticket-attachments/${row.ticket_id}/${safeName}`
      const s3Url = await uploadBufferToS3(key, buffer, match.contentType || row.content_type || undefined)

      await Database.from('ticket_attachments').where('id', row.id).update({
        storage_path: s3Url,
        is_broken: false,
        last_checked_at: new Date(),
        repair_attempts: nextAttempts,
      })
      console.log(`[AttachmentMigrationService][repair] repaired attachment id=${row.id} (ticket #${row.ticket_id}) from source email. attempt ${nextAttempts}/${MAX_REPAIR_ATTEMPTS}`)
      return true
    } catch (err: any) {
      await Database.from('ticket_attachments').where('id', row.id).update({
        is_broken: true,
        last_checked_at: new Date(),
        repair_attempts: nextAttempts,
      })
      console.error(`[AttachmentMigrationService][repair] failed for attachment id=${row.id} (ticket #${row.ticket_id}):`, err?.response?.data ?? err.message, `attempt ${nextAttempts}/${MAX_REPAIR_ATTEMPTS}`)
      return false
    }
  }
  /**
   * Same repair logic as checkAndRepairBrokenAttachments() above, scoped to
   * a specific set of tickets instead of the whole table. Used by the
   * boot-time deleted-ticket reconciliation (see
   * TicketService.reconcileDeletedTicketsOnBoot) — when a ticket comes back
   * from being deleted, its attachments haven't necessarily been touched by
   * the regular 6h sweep, so check them immediately rather than waiting up
   * to 6h for a broken image/attachment to surface.
   */
  public static async checkAndRepairAttachmentsForTickets(ticketIds: number[]) {
    const summary = { checked: 0, migratedOpportunistically: 0, brokenFound: 0, repaired: 0, unrecoverable: 0, skippedMaxAttempts: 0 }
    if (!ticketIds.length) return summary

    const rows: AttachmentRow[] = await Database.from('ticket_attachments').whereIn('ticket_id', ticketIds)
    console.log(`[AttachmentMigrationService][ticket-scoped-check] starting — ${rows.length} attachment(s) across ${ticketIds.length} restored ticket(s).`)

    for (const row of rows) {
      if (row.repair_attempts >= MAX_REPAIR_ATTEMPTS) {
        summary.skippedMaxAttempts++
        continue
      }

      summary.checked++

      if (!isS3Url(row.storage_path)) {
        const result = await this.migrateOneLegacyRow(row)
        if (result === 'migrated') {
          summary.migratedOpportunistically++
          continue
        }
        if (result === 'failed') continue
      } else {
        const reachable = await isUrlReachable(row.storage_path)
        if (reachable) {
          if (row.is_broken) {
            await Database.from('ticket_attachments').where('id', row.id).update({ is_broken: false, last_checked_at: new Date() })
          } else {
            await Database.from('ticket_attachments').where('id', row.id).update({ last_checked_at: new Date() })
          }
          continue
        }
      }

      summary.brokenFound++
      const repaired = await this.attemptRepairFromEmail(row)
      if (repaired) summary.repaired++
      else summary.unrecoverable++
    }

    console.log('[AttachmentMigrationService][ticket-scoped-check] finished:', summary)
    return summary
  }
}

// ───────────────────────── Broken-attachment health-check scheduler ─────────────────────────
// Same self-contained-interval pattern as MailAccountService's subscription
// auto-renewal scheduler — runs regardless of how the rest of the app is
// wired up, as long as this module gets imported once at boot (see the
// eager import added to ChatRoute.ts).
//
// Override the interval for local testing via env, e.g. in .env:
//   ATTACHMENT_HEALTH_CHECK_INTERVAL_MS=20000   (check every 20s)
const HEALTH_CHECK_INTERVAL_MS = Number(process.env.ATTACHMENT_HEALTH_CHECK_INTERVAL_MS) || 6 * 60 * 60 * 1000 // default: every 6 hours

let healthCheckSchedulerStarted = false

function startAttachmentHealthCheckScheduler() {
  if (healthCheckSchedulerStarted) return // guard against double-start on hot reload
  healthCheckSchedulerStarted = true

  console.log(`[AttachmentMigrationService][health-check-scheduler] starting — checking every ${Math.round(HEALTH_CHECK_INTERVAL_MS / 3600000)}h`)

  const tick = async () => {
    console.log('[AttachmentMigrationService][health-check-scheduler] tick — scanning for broken attachments...')
    try {
      await AttachmentMigrationService.checkAndRepairBrokenAttachments()
    } catch (err: any) {
      console.error('[AttachmentMigrationService][health-check-scheduler] tick failed:', err?.response?.data ?? err.message)
    }
  }

  // Deliberately NOT running immediately at boot (unlike the renewal
  // scheduler) — this job can be heavy on a large ticket_attachments table
  // and boot time shouldn't pay for it. First run happens after the first
  // full interval; use the /admin/attachments/dev/check-now route to force
  // an immediate run for testing instead.
  setInterval(tick, HEALTH_CHECK_INTERVAL_MS)
}

startAttachmentHealthCheckScheduler()