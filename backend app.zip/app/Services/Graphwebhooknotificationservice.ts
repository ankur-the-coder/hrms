import Database from '@ioc:Adonis/Lucid/Database'

/**
 * Durability layer for incoming Microsoft Graph webhook notifications.
 *
 * ROOT CAUSE this fixes: MailAccountController.webhook used to ack Graph
 * with a 202 and then process the notification in a fire-and-forget
 * `setImmediate(...)` — nothing was ever written to disk first. If the
 * server crashed or restarted in the gap between the ack and that async
 * callback actually running (or the callback threw before reaching
 * EmailToTicketService.handleIncomingMessage), the notification was gone
 * forever: Graph considered it delivered (we'd already ack'd), so it never
 * retried, and we had no record the notification ever existed.
 *
 * Fix: every notification is written to `graph_webhook_notifications`
 * (status='pending') BEFORE we ack Graph at all. Processing then happens
 * against that durable row — if it fails or the process dies mid-flight,
 * the row is left in a re-driveable state ('pending' or 'failed') and the
 * retry scheduler at the bottom of this file (plus a run at boot) will
 * pick it back up. Nothing is lost unless the row itself fails to write,
 * in which case the controller does NOT ack, so Graph retries delivery.
 */
const MAX_ATTEMPTS = 5

export default class GraphWebhookNotificationService {
  /**
   * Persists the raw notifications synchronously (called BEFORE the
   * controller acks Graph). Returns the ids of the rows just inserted, for
   * the immediate best-effort processing pass. Malformed notifications
   * (no resourceData.id — nothing we could ever act on) are still worth
   * recording for visibility, but are marked 'failed' immediately rather
   * than sitting in 'pending' forever wasting retry attempts.
   */
  public static async recordNotifications(notifications: any[]): Promise<number[]> {
    console.log('this is notification received inside recordNotification', notifications)
    const ids: number[] = []
    for (const notification of notifications) {
      const graphMessageId: string | undefined = notification?.resourceData?.id
      const row = {
        subscription_id: notification?.subscriptionId ?? null,
        mailbox_email: null as string | null,
        graph_message_id: graphMessageId ?? null,
        change_type: notification?.changeType ?? null,
        raw_payload: JSON.stringify(notification),
        status: graphMessageId ? 'pending' : 'failed',
        attempts: 0,
        last_error: graphMessageId ? null : 'Malformed notification — missing resourceData.id',
        received_at: new Date(),
        created_at: new Date(),
        updated_at: new Date(),
      }
      const [id] = await Database.table('graph_webhook_notifications').insert(row)
      ids.push(id)
    }
    return ids
  }

  /** Processes a specific set of just-recorded notification ids (the normal, happy-path call from the webhook controller). */
  public static async processByIds(ids: number[]) {
    for (const id of ids) {
      console.log('processing by Id', id)
      await this.processOne(id)
    }
  }

  /**
   * Re-drives anything still 'pending' or 'failed' (with attempts left) —
   * called once at boot (covers rows stranded by a crash) and on the
   * recurring timer below (covers transient Graph/API failures).
   */
  public static async processPending() {
    const rows = await Database.from('graph_webhook_notifications')
      .whereIn('status', ['pending', 'failed'])
      .where('attempts', '<', MAX_ATTEMPTS)
      .whereNotNull('graph_message_id')
      .orderBy('id', 'asc')
    if (rows.length) {
      console.log(`[GraphWebhookNotificationService] retry pass — ${rows.length} notification(s) still pending/failed`)
    }
    for (const row of rows) {
      await this.processOne(row.id)
    }
  }

  private static async processOne(id: number) {
    const row = await Database.from('graph_webhook_notifications').where('id', id).first()
    if (!row || row.status === 'processed' || !row.graph_message_id) return

    await Database.from('graph_webhook_notifications').where('id', id).update({
      status: 'processing',
      attempts: row.attempts + 1,
      updated_at: new Date(),
    })

    try {
      const payload = typeof row.raw_payload === 'string' ? JSON.parse(row.raw_payload) : row.raw_payload

      const { default: MailAccountService } = await import('App/Services/MailAccountService')
      const { default: EmailToTicketService } = await import('App/Services/EmailToTicketService')

      const account = await MailAccountService.findBySubscriptionId(payload.subscriptionId)
      if (!account) throw new Error(`no active mailbox for subscription ${payload.subscriptionId}`)

      // Route by which subscription actually matched — Inbox notifications
      // are customer mail (existing path); Sent Items notifications are an
      // agent's own send (from Outlook directly OR via this panel) and need
      // the separate handler, since handleIncomingMessage explicitly
      // ignores mail sent by the mailbox itself.
      if (account.matchedFolder === 'sentItems') {
        await EmailToTicketService.handleSentMessage(account.email, row.graph_message_id)
      } else {
        await EmailToTicketService.handleIncomingMessage(account.email, row.graph_message_id)
      }

      await Database.from('graph_webhook_notifications').where('id', id).update({
        status: 'processed',
        mailbox_email: account.email,
        processed_at: new Date(),
        updated_at: new Date(),
      })
    } catch (err: any) {
      const message = (err?.response?.data ? JSON.stringify(err.response.data) : (err.message || 'unknown error')).slice(0, 500)
      console.error(`[GraphWebhookNotificationService] processing failed for notification ${id} (attempt ${row.attempts + 1}/${MAX_ATTEMPTS}):`, message)
      await Database.from('graph_webhook_notifications').where('id', id).update({
        status: 'failed',
        last_error: message,
        updated_at: new Date(),
      })
    }
  }
}

// ───────────────────────── Retry scheduler ─────────────────────────
// Same self-contained-interval pattern as MailAccountService's subscription
// renewal scheduler and AttachmentMigrationService's health-check scheduler —
// runs regardless of how the rest of the app is wired up, as long as this
// module gets imported once at boot (see the eager import in ChatRoute.ts).
//
// Override the interval for local testing via env, e.g. in .env:
//   WEBHOOK_RETRY_INTERVAL_MS=15000   (check every 15s)
const RETRY_INTERVAL_MS = Number(process.env.WEBHOOK_RETRY_INTERVAL_MS) || 2 * 60 * 1000 // default: every 2 min

let retrySchedulerStarted = false

function startRetryScheduler() {
  if (retrySchedulerStarted) return // guard against double-start on hot reload
  retrySchedulerStarted = true

  console.log(`[GraphWebhookNotificationService][retry-scheduler] starting — checking every ${Math.round(RETRY_INTERVAL_MS / 1000)}s`)

  const tick = async () => {
    try {
      await GraphWebhookNotificationService.processPending()
    } catch (err: any) {
      console.error('[GraphWebhookNotificationService][retry-scheduler] tick failed:', err.message)
    }
  }

  // DOES run immediately at boot (unlike the attachment health-check
  // scheduler) — this is exactly the mechanism that recovers notifications
  // stranded by a crash between being recorded and processed, so it
  // shouldn't wait a full interval after every restart.
  tick()
  setInterval(tick, RETRY_INTERVAL_MS)
}

startRetryScheduler()