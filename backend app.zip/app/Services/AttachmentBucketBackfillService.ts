import Database from '@ioc:Adonis/Lucid/Database'
import axios from 'axios'
import MailAccountService from 'App/Services/MailAccountService'
import { uploadBufferToS3 } from 'App/Helper/StorageS3'

const GRAPH = 'https://graph.microsoft.com/v1.0'

// Guard key in `app_settings` (see SettingsService.ts) — flips to 'true'
// once the full backfill has completed successfully, so it never re-runs
// automatically on a later restart. The /admin/attachments/backfill-from-outlook
// route bypasses this guard for a manual re-run.
const SETTINGS_KEY = 'attachments_bucket_backfill_completed'

type TicketRow = { id: number; mail_conversation_id: string; mailbox_email: string }
type MessageRow = { id: number; ticket_id: number; graph_message_id: string; message: string | null }

type Summary = {
  ticketsTotal: number
  ticketsSkippedNoToken: number
  ticketsFailed: number
  messagesProcessed: number
  attachmentsUploaded: number
  inlineRewritten: number
  errors: number
}

/**
 * One-time, boot-triggered backfill that re-fetches every attachment/inline
 * image for every existing (non-deleted) ticket straight from Outlook via
 * Microsoft Graph and uploads it to S3 — it never looks at local disk at
 * all, unlike AttachmentMigrationService's disk-based legacy migration.
 *
 * Runs automatically once on server boot (see the eager import + runOnce()
 * call at the bottom of this file), guarded by an `app_settings` flag so a
 * later restart doesn't repeat the whole thing. To force it again later
 * (e.g. after fixing a mailbox token issue), hit
 * POST /admin/attachments/backfill-from-outlook, which calls
 * backfillAllFromOutlook() directly and does NOT check or touch the guard
 * flag's "already done" state going in — it always re-sets it to done when
 * it finishes.
 */
export default class AttachmentBucketBackfillService {
  // ───────────────────────── Boot-guarded entry point ─────────────────────────

  public static async runOnce() {
    let alreadyDone = false
    try {
      const row = await Database.from('app_settings').where('setting_key', SETTINGS_KEY).first()
      alreadyDone = row?.setting_value === 'true'
    } catch (err: any) {
      console.error('[AttachmentBucketBackfillService][runOnce] could not read app_settings flag — skipping auto-run to be safe:', err.message)
      return
    }

    if (alreadyDone) {
      console.log(`[AttachmentBucketBackfillService][runOnce] "${SETTINGS_KEY}" already true — skipping. Use POST /admin/attachments/backfill-from-outlook to re-run manually.`)
      return
    }

    console.log('[AttachmentBucketBackfillService][runOnce] not yet run — starting full backfill from Outlook...')
    try {
      const summary = await this.backfillAllFromOutlook()
      console.log('[AttachmentBucketBackfillService][runOnce] finished:', summary)
    } catch (err: any) {
      console.error('[AttachmentBucketBackfillService][runOnce] backfill threw — flag will stay unset so it retries on next restart:', err.message)
    }
  }

  // ───────────────────────── Core backfill ─────────────────────────

  public static async backfillAllFromOutlook(): Promise<Summary> {
    const summary: Summary = {
      ticketsTotal: 0,
      ticketsSkippedNoToken: 0,
      ticketsFailed: 0,
      messagesProcessed: 0,
      attachmentsUploaded: 0,
      inlineRewritten: 0,
      errors: 0,
    }

    const tickets: TicketRow[] = await Database.from('tickets')
      .whereNull('deleted_at')
      .whereNotNull('mail_conversation_id')
      .whereNotNull('mailbox_email')
      .select('id', 'mail_conversation_id', 'mailbox_email')

    summary.ticketsTotal = tickets.length
    console.log(`[AttachmentBucketBackfillService][backfill] starting — ${tickets.length} non-deleted ticket(s) with a mail_conversation_id.`)

    for (const ticket of tickets) {
      try {
        const token = await MailAccountService.getValidAccessToken(ticket.mailbox_email)
        if (!token) {
          summary.ticketsSkippedNoToken++
          console.warn(`[AttachmentBucketBackfillService][backfill] no valid access token for mailbox ${ticket.mailbox_email} — skipping ticket #${ticket.id}.`)
          continue
        }

        const messages: MessageRow[] = await Database.from('ticket_messages')
          .where('ticket_id', ticket.id)
          .whereNotNull('graph_message_id')
          .select('id', 'ticket_id', 'graph_message_id', 'message')

        for (const message of messages) {
          summary.messagesProcessed++
          await this.backfillOneMessage(token, ticket.id, message, summary)
        }
      } catch (err: any) {
        summary.ticketsFailed++
        console.error(`[AttachmentBucketBackfillService][backfill] failed for ticket #${ticket.id} (conversation ${ticket.mail_conversation_id}):`, err?.response?.data ?? err.message)
      }

      if (summary.ticketsTotal >= 25 && (summary.ticketsSkippedNoToken + summary.ticketsFailed + summary.messagesProcessed) % 25 === 0) {
        console.log('[AttachmentBucketBackfillService][backfill] progress so far:', summary)
      }
    }

    try {
      const existing = await Database.from('app_settings').where('setting_key', SETTINGS_KEY).first()
      if (existing) {
        await Database.from('app_settings').where('setting_key', SETTINGS_KEY).update({ setting_value: 'true', updated_at: new Date() })
      } else {
        await Database.table('app_settings').insert({ setting_key: SETTINGS_KEY, setting_value: 'true', updated_at: new Date() })
      }
    } catch (err: any) {
      console.error('[AttachmentBucketBackfillService][backfill] finished but FAILED to persist the "done" flag — it will re-run on next restart:', err.message)
    }

    console.log('[AttachmentBucketBackfillService][backfill] finished:', summary)
    return summary
  }

  /** Re-fetches every attachment on one Outlook message and uploads each to S3 — real attachments get a ticket_attachments row (inserted or updated), inline images get their src rewritten in-place in the stored message HTML. */
  private static async backfillOneMessage(token: string, ticketId: number, message: MessageRow, summary: Summary) {
    let data: any
    try {
      const res = await axios.get(`${GRAPH}/me/messages/${message.graph_message_id}/attachments`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      data = res.data
    } catch (err: any) {
      summary.errors++
      console.error(`[AttachmentBucketBackfillService][backfill] could not fetch attachments for message id=${message.id} (graph ${message.graph_message_id}):`, err?.response?.data ?? err.message)
      return
    }

    let html = message.message || ''
    let htmlChanged = false

    for (const att of data.value ?? []) {
      if (att['@odata.type'] !== '#microsoft.graph.fileAttachment') continue

      let s3Url: string
      try {
        const buffer = Buffer.from(att.contentBytes, 'base64')
        const originalName = att.name || att.contentId || `attachment_${Date.now()}`
        const safeName = `${Date.now()}_${originalName}`.replace(/[^a-zA-Z0-9._-]/g, '_')
        const key = `ticket-attachments/${ticketId}/${safeName}`
        s3Url = await uploadBufferToS3(key, buffer, att.contentType)
        summary.attachmentsUploaded++
      } catch (err: any) {
        summary.errors++
        console.error(`[AttachmentBucketBackfillService][backfill] upload failed for attachment "${att.name}" on message id=${message.id}:`, err.message)
        continue
      }

      if (att.isInline) {
        const before = html
        if (att.contentId) {
          const cid = att.contentId.replace(/[<>]/g, '')
          html = html.replace(new RegExp(`cid:${this.escapeRegex(cid)}`, 'gi'), s3Url)
          html = html.replace(new RegExp(`src=["']${this.escapeRegex(cid)}["']`, 'gi'), `src="${s3Url}"`)
        }
        // Legacy rows store the OLD local-disk-relative path in <img src="uploads/...">
        // (see ticket-detail.ts's client-side `src="uploads/..."` rewrite) — replace
        // any such reference whose filename matches this attachment.
        if (att.name) {
          html = html.replace(
            new RegExp(`src=["'](?:/)?uploads/[^"']*${this.escapeRegex(this.baseNameNoExt(att.name))}[^"']*["']`, 'gi'),
            `src="${s3Url}"`
          )
        }
        if (html !== before) {
          htmlChanged = true
          summary.inlineRewritten++
        }
        continue // inline images don't get their own ticket_attachments row — same rule EmailToTicketService follows
      }

      // Real (non-inline) attachment — upsert by (message_id, file_name) so re-running this is safe.
      const existingRow = await Database.from('ticket_attachments')
        .where('message_id', message.id)
        .where('file_name', att.name)
        .first()

      if (existingRow) {
        await Database.from('ticket_attachments').where('id', existingRow.id).update({
          storage_path: s3Url,
          content_type: att.contentType,
          size: att.size,
        })
      } else {
        await Database.table('ticket_attachments').insert({
          ticket_id: ticketId,
          message_id: message.id,
          file_name: att.name,
          content_type: att.contentType,
          size: att.size,
          storage_path: s3Url,
          created_at: new Date(),
        })
      }
    }

    if (htmlChanged) {
      await Database.from('ticket_messages').where('id', message.id).update({ message: html })
    }
  }

  private static escapeRegex(s: string) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  }

  private static baseNameNoExt(fileName: string) {
    return fileName.replace(/\.[^.]+$/, '')
  }
}

// ───────────────────────── Boot trigger ─────────────────────────
// Same eager-import self-start pattern as MailAccountService / AttachmentMigrationService
// (see ChatRoute.ts) — fires once at server startup, actual work gated by the
// app_settings flag above so a normal restart is a no-op after the first run.
let bootRunTriggered = false

if (!bootRunTriggered) {
  bootRunTriggered = true
  // Deliberately not awaited — this can take a while on a large ticket
  // table and must not delay server boot / port binding.
  AttachmentBucketBackfillService.runOnce().catch((err) => {
    console.error('[AttachmentBucketBackfillService] boot-time runOnce() rejected unexpectedly:', err.message)
  })
}