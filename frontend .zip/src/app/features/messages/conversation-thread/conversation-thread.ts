import { Component, Input, OnChanges, effect, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { HttpClient } from '@angular/common/http'
import { TicketService } from '../../../core/services/ticket.service'
import { Ticket, TicketMessage } from '../../../core/models/ticket.model'
import { TicketSocketService } from '../../../core/services/ticket-socket.services'
import { AuthService } from '../../../service/auth.service'
import { environment } from '../../../../environments/environment'
import { DialogService } from '../../../core/services/Dialog-services/dialog.services'

@Component({
  selector: 'app-conversation-thread',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './conversation-thread.html',
  styleUrl: './conversation-thread.css',
})
export class ConversationThread implements OnChanges {
  @Input() ticketId: number | null = null

  private ticketService = inject(TicketService)
  private ticketSocket  = inject(TicketSocketService)
  private auth          = inject(AuthService)
  private http          = inject(HttpClient)
  private dialog        = inject(DialogService)

  ticket = signal<Ticket | null>(null)
  messages = signal<TicketMessage[]>([])
  draft = ''

  // `ticketSocket.activeMessages()` is a monotonically-growing signal (it's
  // never trimmed, only reset on joinTicket). We must only ever consume the
  // NEW tail of it — re-appending the whole array on every change produces
  // duplicate message ids, which breaks @for's track and was the root cause
  // of the UI freeze.
  private consumedCount = 0

  constructor() {
    effect(() => {
      const incoming = this.ticketSocket.activeMessages()
      if (incoming.length > this.consumedCount) {
        // Only accept messages for the ticket currently shown here — see the
        // matching comment in TicketSocketService.joinTicket() for why a
        // stray cross-ticket message could otherwise still arrive.
        const newOnes = incoming.slice(this.consumedCount).filter(m => m.ticket_id === this.ticketId)
        if (newOnes.length) this.messages.set([...this.messages(), ...newOnes])
        this.consumedCount = incoming.length
      }
    })
  }

  ngOnChanges() {
    if (!this.ticketId) { this.ticket.set(null); this.messages.set([]); return }
    this.consumedCount = 0
    this.ticketSocket.joinTicket(this.ticketId)
    this.ticketService.getTicketDetail(this.ticketId).subscribe((r: any) => {
      this.ticket.set(r.ticket)
      this.messages.set(r.messages)
    })
  }

  send() {
    const text = this.draft.trim()
    if (!text || !this.ticketId) return

    const t = this.ticket()

    // Internal persistence + real-time fan-out to other agents viewing this ticket.
    this.ticketSocket.sendMessage({
      ticketId: this.ticketId,
      sender: 'agent',
      type: 'reply',
      message: text,
      agentId: this.auth.getAgentId(),
    })
    this.draft = ''

    // Actually deliver the message to the customer over WhatsApp. The socket
    // event above does NOT do this — without this call, replies never leave
    // your inbox.
    if (t?.source === 'whatsapp' && t?.customer_phone) {
      this.http.post(`${environment.apiUrl}/api/whatsapp/send`, {
        ticketId: this.ticketId,
        recipientPhone: t.customer_phone,
        messageText: text
      }, {
        headers: this.auth.getAuthHeaders()
      }).subscribe({
        next: () => {},
        error: (err) => {
          console.error('❌ WhatsApp dispatch failed:', err?.error || err)
          this.dialog.alert({
            title: 'WhatsApp delivery failed',
            message: `Your reply was saved, but WhatsApp delivery failed: ${err?.error?.error || err?.message || 'Unknown error'}`,
          })
        }
      })
    }
  }
}