import { Component } from '@angular/core';

@Component({
  selector: 'app-email-inbox',
  imports: [],
  templateUrl: './email-inbox.html',
  styleUrl: './email-inbox.css',
})
export class EmailInbox {}
