import { Component, effect, inject, signal, computed } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { HttpClient } from '@angular/common/http'
import { TicketService } from '../../../core/services/ticket.service'
import { Ticket } from '../../../core/models/ticket.model'
import { ConversationThread } from '../conversation-thread/conversation-thread'
import { TicketSocketService } from '../../../core/services/ticket-socket.services'
import { environment } from '../../../../environments/environment'
import { AuthService } from '../../../service/auth.service'
import { DialogService } from '../../../core/services/Dialog-services/dialog.services'

@Component({
  selector: 'app-whatsapp-inbox',
  standalone: true,
  imports: [CommonModule, FormsModule, ConversationThread],
  templateUrl: './whatsapp-inbox.html',
  styleUrl: './whatsapp-inbox.css',
})
export class WhatsappInbox {
  private ticketService = inject(TicketService)
  private ticketSocket  = inject(TicketSocketService)
  private http          = inject(HttpClient)
  private auth          = inject(AuthService)
  private dialog        = inject(DialogService)

  conversations = signal<Ticket[]>([])
  selectedId = signal<number | null>(null)
  searchQuery = signal<string>('')

  // New Chat Modal state
  showNewChatModal = signal<boolean>(false)
  isSubmitting = signal<boolean>(false)
  newCustomerName = signal<string>('')
  newCustomerPhone = signal<string>('')
  newInitialMessage = signal<string>('')

  // Filtered list based on search bar
  filteredConversations = computed(() => {
    const query = this.searchQuery().toLowerCase().trim()
    if (!query) return this.conversations()
    return this.conversations().filter(t =>
      t.customer_name?.toLowerCase().includes(query) ||
      t.customer_phone?.toLowerCase().includes(query) ||
      t.ticket_uid?.toLowerCase().includes(query)
    )
  })

  constructor() {
    this.fetch()
    effect(() => {
      this.ticketSocket.ticketsVersion()
      this.fetch()
    })
  }

  select(id: number) {
    this.selectedId.set(id)
  }

  openNewChatModal() {
    this.newCustomerName.set('')
    this.newCustomerPhone.set('')
    this.newInitialMessage.set('')
    this.showNewChatModal.set(true)
  }

  closeNewChatModal() {
    this.showNewChatModal.set(false)
  }

  startNewChat() {
    const name = this.newCustomerName().trim()
    const phone = this.newCustomerPhone().trim()
    const message = this.newInitialMessage().trim() || 'Hello! How can we help you today?'

    if (!name || !phone) return

    this.isSubmitting.set(true)

    const payload = {
      customer_name: name,
      customer_phone: phone,
      customerName: name,
      customerPhone: phone,
      source: 'whatsapp',
      subject: `WhatsApp Chat with ${name}`,
      message: message,
      description: message,
      priority: 'medium',
      status: 'open'
    }

    // Step 1: Create ticket in MySQL DB
    this.ticketService.createTicket(payload).subscribe({
      next: (res: any) => {
        const createdId = res?.id || res?.data?.id || res?.ticket?.id

        // Step 2: Dispatch message outward to Meta Graph API
        this.http.post(`${environment.apiUrl}/api/whatsapp/send`, {
          ticketId: createdId,
          recipientPhone: phone,
          messageText: message
        }, {
          headers: this.auth.getAuthHeaders()
        }).subscribe({
          next: (sendRes) => console.log('✅ WhatsApp message dispatched to Meta:', sendRes),
          error: (sendErr) => {
            console.error('❌ Meta dispatch failed:', sendErr?.error || sendErr)
            this.dialog.alert({
              title: 'WhatsApp send failed',
              message: `Ticket created, but the WhatsApp message failed to send: ${sendErr?.error?.error || sendErr?.message || 'Unknown error'}`,
            })
          }
        })

        this.isSubmitting.set(false)
        this.closeNewChatModal()
        this.fetch()
        if (createdId) {
          this.selectedId.set(createdId)
        }
      },
      error: (err) => {
        console.error('Failed to create WhatsApp chat:', err)
        this.isSubmitting.set(false)
      }
    })
  }

  private fetch() {
    this.ticketService.getTickets(0, 50, { source: 'whatsapp' }).subscribe((r: any) => {
      if (r?.status !== false) {
        const list = Array.isArray(r) ? r : (r?.data || [])
        this.conversations.set(list)
        if (!this.selectedId() && list.length > 0) {
          this.selectedId.set(list[0].id)
        }
      }
    })
  }
}