// create-ticket-modal.ts
import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { DomSanitizer, SafeHtml } from '@angular/platform-browser'
import { TicketService } from '../../../core/services/ticket.service'
import { AgentService } from '../../../core/services/agent.service'
import { AuthService } from '../../../service/auth.service'
import { PendingAttachment } from '../../../core/models/ticket.model'

@Component({
  selector: 'app-create-ticket-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-ticket-modal.html',
  styleUrl: './create-ticket-modal.css',
})
export class CreateTicketModal implements OnInit {
  @Output() close = new EventEmitter<void>()
  @Output() created = new EventEmitter<void>()
  private ticketService = inject(TicketService)
  private agentService = inject(AgentService)
  private auth = inject(AuthService)
  private sanitizer = inject(DomSanitizer)

  contactName = ''
  email = ''
  phone = ''
  subject = ''
  // Renamed from `description` — this is the agent's own opening message to
  // the customer (their footer/signature is appended automatically, see
  // below). Replaces the old auto-response email entirely: no automated
  // "your ticket has been created" message is sent anymore, this typed
  // message + attachments IS the first thing the customer receives.
  message = ''
  // 'new' was never a valid backend status — TicketService's VALID_STATUSES
  // is only ['open','on_hold','escalated','closed']. Default stays 'open'.
  status: 'open' | 'on_hold' | 'escalated' | 'closed' = 'open'
  priority: 'low' | 'medium' | 'high' = 'medium'
  // Manual tickets are always treated as the "email" channel — same as
  // inbound email tickets — so this is no longer agent-editable.
  channel: 'email' = 'email'
  ccInput = ''
  bccInput = ''
  showMoreOptions = false
  // Left as null (Auto-assign) by default — the backend falls back to its
  // existing support-owner auto-assign logic when this isn't set.
  assignedTo: number | null = null
  agentsList = signal<{ id: number; name: string; role: string }[]>([])
  isSaving = signal(false)
  errorMsg = signal('')

  // ── Ticket ID preview ─────────────────────────────────────────────────
  // Fetched as soon as the modal opens so the agent can see the real ID
  // *before* hitting Submit — the exact same value is sent back in the
  // create payload (ticketUid) so what's shown here is guaranteed to be
  // what actually gets saved.
  ticketUid = signal<string | null>(null)
  ticketUidLoading = signal(false)

  // ── Attachments ──────────────────────────────────────────────────────
  // Same immediate-upload-on-pick pattern as the reply composer in
  // ticket-detail.ts: a file uploads the instant it's picked, so the chip
  // can show progress/errors right away, well before Submit is hit.
  attachments = signal<PendingAttachment[]>([])
  @ViewChild('attachmentInput') attachmentInputRef?: ElementRef<HTMLInputElement>
  private nextAttachmentClientId = 0

  // ── Agent signature / footer preview ────────────────────────────────
  signatureHtml = signal<SafeHtml | null>(null)
  signatureLoading = signal(false)
  signatureNotConfigured = signal(false)
  signatureBannerDismissed = false

  ngOnInit() {
    this.ticketService.getAgents().subscribe({
      next: (r: any) => this.agentsList.set(Array.isArray(r) ? r : (r?.data ?? [])),
      error: () => this.agentsList.set([]),
    })

    this.ticketUidLoading.set(true)
    this.ticketService.getNextTicketUid().subscribe({
      next: (r) => { this.ticketUid.set(r?.ticketUid ?? null); this.ticketUidLoading.set(false) },
      error: () => { this.ticketUid.set(null); this.ticketUidLoading.set(false) },
    })

    const agentId = this.auth.getAgentId()
    this.signatureLoading.set(true)
    this.agentService.getSignature(agentId).subscribe({
      next: (res: any) => {
        const raw = res?.signatureHtml?.trim() ?? ''
        if (raw) {
          let formattedSig = raw.split('{{agent_name}}').join(this.auth.getAgentName())
          if (!/<[a-z][\s\S]*>/i.test(formattedSig)) {
            formattedSig = formattedSig.replace(/\r?\n/g, '<br/>')
          }
          this.signatureHtml.set(this.sanitizer.bypassSecurityTrustHtml(formattedSig))
          this.signatureNotConfigured.set(false)
        } else {
          this.signatureHtml.set(null)
          this.signatureNotConfigured.set(true)
        }
        this.signatureLoading.set(false)
      },
      error: () => {
        this.signatureHtml.set(null)
        this.signatureNotConfigured.set(false)
        this.signatureLoading.set(false)
      },
    })
  }

  private parseEmailList(raw: string): string[] {
    return raw.split(',').map(e => e.trim()).filter(Boolean)
  }

  // ── Attachments ──────────────────────────────────────────────────────
  triggerAttachmentInput() { this.attachmentInputRef?.nativeElement.click() }

  onAttachmentPicked(event: Event) {
    const input = event.target as HTMLInputElement
    const files = input.files ? Array.from(input.files) : []
    input.value = '' // reset so picking the same file again still fires (change)

    for (const file of files) {
      const clientId = `att-${Date.now()}-${this.nextAttachmentClientId++}`
      const pending: PendingAttachment = {
        fileName: file.name, contentType: file.type, size: file.size,
        storagePath: '', clientId, uploading: true, error: null,
      }
      this.attachments.update(list => [...list, pending])

      this.ticketService.uploadAttachment(file).subscribe({
        next: (res: any) => {
          this.attachments.update(list => list.map(a => a.clientId === clientId
            ? {
                ...a,
                uploading: false,
                storagePath: res?.storagePath ?? '',
                fileName: res?.fileName ?? a.fileName,
                contentType: res?.contentType ?? a.contentType,
                size: res?.size ?? a.size,
                error: res?.status === false ? (res?.msg || 'Upload failed') : null,
              }
            : a
          ))
        },
        error: (err: any) => {
          this.attachments.update(list => list.map(a => a.clientId === clientId
            ? { ...a, uploading: false, error: err?.error?.msg || 'Upload failed — please try again.' }
            : a
          ))
        },
      })
    }
  }

  removeAttachment(clientId: string) {
    this.attachments.update(list => list.filter(a => a.clientId !== clientId))
  }

  attachmentsUploading(): boolean {
    return this.attachments().some(a => a.uploading)
  }

  private attachmentsForSend() {
    return this.attachments()
      .filter(a => a.storagePath && !a.error)
      .map(a => ({ fileName: a.fileName, contentType: a.contentType, size: a.size, storagePath: a.storagePath }))
  }

  fileSize(bytes?: number) {
    if (!bytes) return ''
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  submit() {
    if (!this.contactName.trim() || !this.subject.trim() || !this.email.trim()) {
      this.errorMsg.set('Contact Name, Email and Subject are required.')
      return
    }
    if (this.attachmentsUploading()) {
      this.errorMsg.set('Please wait for attachments to finish uploading.')
      return
    }
    this.isSaving.set(true)
    this.errorMsg.set('')
    this.ticketService.createTicket({
      customerName: this.contactName.trim(),
      customerPhone: this.phone.trim() || undefined,
      customerEmail: this.email.trim(),
      subject: this.subject.trim(),
      source: this.channel,
      priority: this.priority,
      status: this.status,
      message: this.message.trim() || undefined,
      // Round-tripped so the ticket actually gets created with the exact ID
      // already shown to the agent above.
      ticketUid: this.ticketUid() ?? undefined,
      ccRecipients: this.parseEmailList(this.ccInput),
      bccRecipients: this.parseEmailList(this.bccInput),
      assignedTo: this.assignedTo || undefined,
      attachments: this.attachmentsForSend(),
    }).subscribe({
      next: () => { this.isSaving.set(false); this.created.emit(); this.close.emit() },
      error: () => { this.isSaving.set(false); this.errorMsg.set('Failed to create ticket. Please try again.') },
    })
  }
  cancel() { this.close.emit() }
}