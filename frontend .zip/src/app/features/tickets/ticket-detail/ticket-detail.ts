import { ChangeDetectionStrategy, Component, computed, effect, ElementRef, EventEmitter, inject, Input, OnChanges, OnDestroy, OnInit, AfterViewChecked, Output, signal, SimpleChanges, ViewChild } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { ActivatedRoute, Router } from '@angular/router'
import { TicketService } from '../../../core/services/ticket.service'
import { Ticket, TicketMessage, TicketAttachment, Agent, CcParticipant, PendingAttachment } from '../../../core/models/ticket.model'
import { TicketSocketService } from '../../../core/services/ticket-socket.services'
import { environment } from '../../../../environments/environment'
import * as XLSX from 'xlsx';
import * as mammoth from 'mammoth';
import { DomSanitizer, SafeHtml, SafeResourceUrl } from '@angular/platform-browser'
import { AgentService } from '../../../core/services/agent.service'
import { AuthService } from '../../../service/auth.service'
import { Subscription } from 'rxjs'
import { LayoutService } from '../../../core/services/layout.service'
import { HttpClient, HttpParams } from '@angular/common/http'
import { TicketDraftService } from '../../../core/services/ticket-draft.service'
import { DialogService } from '../../../core/services/Dialog-services/dialog.services'
import { TicketResyncService } from '../../../core/services/ticket-resync.service'

// Geometry for one flow arrow, used by renderFlowArrows()'s overlap-resolution
// pass — mutable so resolveFlowArrowOverlaps() can grow yShift in place.
type FlowArrowGeom = {
  link: { src: string; tgt: string; type: 'wa-email' | 'email-wa' }
  isWaToMail: boolean
  sx: number; sy: number; tx: number; ty: number
  yShift: number
}

@Component({
  selector: 'app-ticket-detail',
  imports: [CommonModule, FormsModule],
  templateUrl: './ticket-detail.html',
  styleUrl: './ticket-detail.css',
  host: {
    '(window:resize)': 'onResize()',
  },
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TicketDetailComponent implements OnChanges, OnDestroy, OnInit, AfterViewChecked {
  private layout = inject(LayoutService)
  @Input() ticketIdInput?: number
  @Input() embedded = false
  @Output() closeRequested = new EventEmitter<void>()
  private route = inject(ActivatedRoute)
  private router = inject(Router)
  private ticketService = inject(TicketService)
  private ticketSocket  = inject(TicketSocketService)
  private flowResizeObserver = new ResizeObserver(() => this.renderFlowArrows())
private flowObservedEls = new Set<Element>()

  ticket = signal<Ticket | null>(null)
  messages = signal<(TicketMessage & { isSending?: boolean; formattedHtml?: SafeHtml })[]>([])
  draft = ''
   ticketId!: number
  private agentService = inject(AgentService)
  auth = inject(AuthService)
  ticketDraftService = inject(TicketDraftService)
  private dialog = inject(DialogService)
  resyncService = inject(TicketResyncService)
  isResyncing = signal(false)

  agents = signal<Agent[]>([])
  ccParticipants = signal<CcParticipant[]>([])
  replyRecipients = signal<{ to: string[]; cc: string[]; bcc: string[] }>({ to: [], cc: [], bcc: [] })
  selectedRecipients = signal<string[]>([])
  internalNoteText = ''
  loading = signal(true)
  showCcPopover = signal(false)
  activeEyeMsgId = signal<number | null>(null)
  compactTickets = signal<Ticket[]>([])
compactLoading = signal(true)
// True while a ticket other than the one we already knew about sits at the
// top of the compact list (i.e. a new ticket just arrived) — drives the
// "NEW" badge so an agent buried in a ticket's detail view still notices.
compactHasNew = signal(false)
private lastSeenTopTicketId: number | null = null
private compactRefetchTimer: any = null

  // ── Close-ticket confirm (closure email is now a per-ticket decision) ──────
  showCloseConfirm = signal(false)
  sendClosureMessage = signal(true)
  // ───────────────────────────────────────────────────────────────────────────

  // ── Right-Side Sheet Drawer ────────────────────────────────────────────────
  drawerOpen = signal(false)
  drawerMode = signal<'reply' | 'reply_all' | 'reply_selected' | 'forward'>('reply')
  sidePanelTab = signal<'properties' | 'kb' | 'timeline' | 'followers'>('properties')
  forwardToInput = ''
  forwardToChips = signal<string[]>([])
  showCcInput = signal(false)
  showBccInput = signal(false)
  customCcChips = signal<string[]>([])
  customBccChips = signal<string[]>([])
  ccInputText = ''
  bccInputText = ''
  drawerDraft = ''
  drawerSignatureHtml = signal<SafeHtml | null>(null)
  drawerSignatureLoading = signal(false)
  signatureNotConfigured = signal(false)
  signatureBannerDismissed = false
  retryingMessageId = signal<number | null>(null)
  private activeStatusFilter = '';

  // Files the agent has attached to the current drawer reply (email) or the
  // WhatsApp composer, from the moment they're picked (upload fires
  // immediately — see onAttachmentPicked) until Send. Two separate lists
  // since the two composers are independent surfaces with their own
  // lifecycle/cancel behavior.
  drawerAttachments = signal<PendingAttachment[]>([])
  waAttachments = signal<PendingAttachment[]>([])
  @ViewChild('drawerFileInput') drawerFileInputRef?: ElementRef<HTMLInputElement>
  @ViewChild('waFileInput') waFileInputRef?: ElementRef<HTMLInputElement>

  // ── Outbound attachments (drawer + WA composers) ─────────────────────────
  private nextAttachmentClientId = 0

  triggerDrawerFileInput() { this.drawerFileInputRef?.nativeElement.click() }
  triggerWaFileInput() { this.waFileInputRef?.nativeElement.click() }

  /** Fires the instant a file is picked (see PendingAttachment doc in the
   *  model) — uploads immediately via TicketService.uploadAttachment so the
   *  chip can show progress/errors right away, well before Send is hit. */
  onAttachmentPicked(event: Event, target: 'drawer' | 'wa') {
    const input = event.target as HTMLInputElement
    const files = input.files ? Array.from(input.files) : []
    input.value = '' // reset so picking the same file again still fires (change)

    const sig = target === 'drawer' ? this.drawerAttachments : this.waAttachments

    for (const file of files) {
      const clientId = `att-${Date.now()}-${this.nextAttachmentClientId++}`
      const pending: PendingAttachment = {
        fileName: file.name, contentType: file.type, size: file.size,
        storagePath: '', clientId, uploading: true, error: null,
      }
      sig.update(list => [...list, pending])

      this.ticketService.uploadAttachment(file).subscribe({
        next: (res: any) => {
          sig.update(list => list.map(a => a.clientId === clientId
            ? {
                ...a,
                uploading: false,
                storagePath: res?.storagePath ?? '',
                fileName: res?.fileName ?? a.fileName,
                contentType: res?.contentType ?? a.contentType,
                size: res?.size ?? a.size,
                error: res?.status === false ? (res?.msg || 'Upload failed') : null,
              }
            : a
          ))
          if (target === 'drawer') {
            this.saveCurrentDraft()
          }
        },
        error: (err: any) => {
          sig.update(list => list.map(a => a.clientId === clientId
            ? { ...a, uploading: false, error: err?.error?.msg || 'Upload failed — please try again.' }
            : a
          ))
        },
      })
    }
  }

  removeAttachment(target: 'drawer' | 'wa', clientId: string) {
    const sig = target === 'drawer' ? this.drawerAttachments : this.waAttachments
    sig.update(list => list.filter(a => a.clientId !== clientId))
    if (target === 'drawer') {
      this.saveCurrentDraft()
    }
  }

  /** True while at least one attachment for this composer is still
   *  uploading — used to disable Send so we never fire a message payload
   *  referencing a storagePath that doesn't exist yet. */
  attachmentsUploading(target: 'drawer' | 'wa'): boolean {
    const sig = target === 'drawer' ? this.drawerAttachments : this.waAttachments
    return sig().some(a => a.uploading)
  }

  /** Successfully-uploaded attachments only, shaped for the addMessage
   *  payload (TicketService.addMessage's `attachments` field). */
  private attachmentsForSend(target: 'drawer' | 'wa') {
    const sig = target === 'drawer' ? this.drawerAttachments : this.waAttachments
    return sig()
      .filter(a => a.storagePath && !a.error)
      .map(a => ({ fileName: a.fileName, contentType: a.contentType, size: a.size, storagePath: a.storagePath }))
  }

  relatedMessageId: number | null = null
waDraft = ''
waQuote = signal<{ title: string; text: string } | null>(null)
@ViewChild('waInputRef') waInputRef?: ElementRef<HTMLTextAreaElement>

// ── Relay modal (hover email/whatsapp icon on a message → confirm here) ────
// This is the ONLY place a cross-channel relatedMessageId gets set, which in
// turn is the ONLY thing renderFlowArrows() ever draws a link for.
relayModalOpen = signal(false)
relayModalTargetChannel = signal<'wa' | 'mail' | null>(null)
relayModalSourceMsg = signal<TicketMessage | null>(null)
relayModalNote = ''

inlineMailReplyFor = signal<number | null>(null)
inlineMailReplyText = ''
private agentSignatureHtml: string | null = null
private agentSignatureLoaded = false

// Auto-email cards are long — collapsed by default, expand on click.
expandedEmails = signal<Set<number>>(new Set())

isEmailExpanded(id: number): boolean {
  return this.expandedEmails().has(id)
}

toggleEmailExpand(id: number) {
  const next = new Set(this.expandedEmails())
  next.has(id) ? next.delete(id) : next.add(id)
  this.expandedEmails.set(next)
  // bubble height just changed — arrow anchor points need to be recalculated
  setTimeout(() => this.renderFlowArrows(), 60)
}
  // ───────────────────────────────────────────────────────────────────────────

 private subs = new Subscription()

  constructor(
    private sanitizer: DomSanitizer,
  private http: HttpClient, ) {
      this.subs.add(
    this.route.paramMap.subscribe(pm => {
      const routeId = Number(pm.get('id'))
      const id = this.ticketIdInput ?? routeId
      if (id && id !== this.ticketId) {
        this.ticketId = id
        this.loading.set(true)
        this.loadTicket(id)
        this.ticketSocket.joinTicket(id)
      }
    })
  )
  // Read the status filter passed from the ticket list
this.activeStatusFilter = this.route.snapshot.queryParamMap.get('status') || '';
this.route.queryParamMap.subscribe(qm => {
  const newFilter = qm.get('status') || '';
  if (newFilter !== this.activeStatusFilter) {
    this.activeStatusFilter = newFilter;
    this.loadCompactList();
  }
});
  this.loadCompactList()
    const routeId = Number(this.route.snapshot.paramMap.get('id'))
    this.ticketId = this.ticketIdInput ?? routeId
  
    this.ticketSocket.joinTicket(this.ticketId)

    // Compact "All Tickets" list (left rail) never refreshed itself while an
    // agent stayed on a ticket's detail view — a new ticket landing at the
    // top was invisible until they navigated away and back. Refetch it
    // (debounced) whenever the socket says the ticket set changed.
    let skipFirstCompactEffect = true
effect(() => {
  this.messages()
  setTimeout(() => {
    this.scrollThreadToBottomIfNearBottom('wa')
    this.scrollThreadToBottomIfNearBottom('mail')
    this.renderFlowArrows()
  }, 60)
})

    // keep a handle on the effect so we can stop it
    //
    // NOTE: this used to track a `lastConsumedCount` and only look at the
    // tail-slice of `activeMessages()` whenever the array *grew*. That broke
    // two ways: (1) `message_updated` (delivery/read-receipt ticks) patches
    // an existing entry in place via `.map()` in TicketSocketService, which
    // doesn't change the array's length, so those patches were silently
    // dropped and a bubble's tick never advanced past whatever it started
    // at; (2) the counter was never reset on ticket switch, while
    // `joinTicket()` resets `activeMessages` back to `[]` per ticket — so
    // after leaving a ticket with N messages, the next ticket wouldn't be
    // "seen" as having anything new until it also passed N messages,
    // meaning even the very first optimistic-clock → real-message swap
    // could silently never happen.
    //
    // Fix: don't count anything — just merge whatever is currently in
    // `activeMessages()` into `messages()` every time the signal changes,
    // matching each entry by id (patches, e.g. delivery-status updates) or
    // by the isSending-placeholder heuristic (first arrival of a message we
    // sent). This naturally handles new arrivals AND in-place patches, and
    // needs no per-ticket reset since it re-derives from source each time.
    this.messagesEffectRef = effect(() => {
      const incoming = this.ticketSocket.activeMessages()
      if (incoming.length) {
        this.messages.update(list => {
          let next = list
          for (const n of incoming) {
            // Belt-and-suspenders: only ever render a message that actually
            // belongs to the ticket currently open in this view. Normally
            // TicketSocketService.joinTicket() leaving the previous room
            // prevents stray tickets' events from arriving here at all, but
            // this stops any that slip through (e.g. one already in flight
            // the instant before the leave) from getting merged into the
            // wrong ticket's thread.
            if (n.ticket_id !== this.ticketId) continue
            // Match by containment, not equality: the server may enrich the
            // stored text (cross-channel reference prefix, etc.) beyond what
            // the optimistic placeholder showed, so the placeholder's text is
            // always a SUBSTRING of the real one, never an exact match.
            //
            // ROOT CAUSE of "shows failed, but the mail actually sent — then
            // Retry sends it AGAIN": this used to require `isSending` to
            // still be true to match a placeholder to its real row. But the
            // backend fires the socket ack as soon as the row is inserted —
            // BEFORE the Graph send finishes — so the ack can legitimately
            // time out (dispatchAgentMessage flips isSending→false,
            // delivery_status→'failed') on a message the server went on to
            // send successfully a moment later. Once isSending was false,
            // the real confirmed row arriving afterward could no longer
            // match this placeholder at all — it fell through to "append as
            // brand new message" below, leaving the orphaned "failed"
            // placeholder on screen right next to the real, successful one
            // (2 bubbles for what was actually 1 successful send). Worse,
            // that orphaned placeholder still carries `_payload`, so
            // clicking its Retry button (retryFailedAgentMessage) replayed
            // the entire send again — a genuine second email — landing at
            // 3 bubbles total for one agent action.
            //
            // Fix: key the match on this being an unreconciled LOCAL
            // placeholder (negative client-generated id — see the
            // `id: -Date.now()` placeholders below) instead of the
            // ack-derived `isSending` flag, so a placeholder that already
            // flipped to "failed" can still be swapped for its real row
            // once the server confirms it actually went out.
            const placeholderIdx = next.findIndex(m =>
              m.id < 0 && m.sender === n.sender &&
              // Normalize nullish channel values before comparing: agent replies
              // set channel ('email'/'whatsapp'), but internal notes never do,
              // so the placeholder's channel is `undefined` while the DB row
              // comes back as `channel: null` — undefined !== null caused the
              // match to always fail, leaving a stuck "Sending..." placeholder
              // next to the real message (2 bubbles for 1 send).
              (((m as any).channel ?? null) === ((n as any).channel ?? null)) && n.message.includes(m.message)
            )
            if (placeholderIdx !== -1) {
              // [WA-TRACE F3] Optimistic clock placeholder swapped for the real row.
              console.log('[WA-TRACE F3] placeholder → real message swap, id=', n.id, 'delivery_status=', (n as any).delivery_status)
              next = [...next.slice(0, placeholderIdx), n, ...next.slice(placeholderIdx + 1)]
              continue
            }
            const existingIdx = next.findIndex(m => m.id === n.id)
            if (existingIdx !== -1) {
              // [WA-TRACE F4] In-place patch applied to an already-rendered bubble
              // — e.g. sent → delivered → read, or a retry's failed → sent.
              console.log('[WA-TRACE F4] patched existing message id=', n.id, 'delivery_status=', (n as any).delivery_status)
              next = [...next.slice(0, existingIdx), { ...next[existingIdx], ...n }, ...next.slice(existingIdx + 1)]
            } else {
              // [WA-TRACE F5] Brand new message appended (e.g. inbound customer message).
              console.log('[WA-TRACE F5] appended new message id=', n.id)
              next = [...next, n]
            }
          }
          return next
        })
      }
    })

    this.subs.add(
      this.agentService.list().subscribe({
        next: (r: any) => this.agents.set(Array.isArray(r) ? r : []),
        error: () => this.agents.set([]),
      })
    )

// add to constructor, alongside your existing effects
//
// BUG FIX: this used to call scrollThreadToBottom() unconditionally on
// every change to `messages()` — which fires on any new message arriving
// over the socket, at any time, not just right after opening a ticket.
// That meant scrolling up to read earlier messages while ANY new message
// landed (or while a resync/backfill was filling in older history) got
// yanked straight back down mid-scroll — the "quickly scrolling to the
// top keeps jumping back to the bottom" symptom. Now it only auto-scrolls
// when the agent is already at (or very near) the bottom, i.e. they
// weren't reading further up in the first place; someone who has
// scrolled away is left where they are.
effect(() => {
  this.messages()
  setTimeout(() => {
    this.renderFlowArrows()
    this.scrollThreadToBottomIfNearBottom('wa')
    this.scrollThreadToBottomIfNearBottom('mail')
  }, 60)
})
}

onResize() { this.renderFlowArrows() }

private loadCompactList() {
  const params: any = {};
  // Only apply filter if it's set and not 'all'
  if (this.activeStatusFilter && this.activeStatusFilter !== 'all') {
    params.status = this.activeStatusFilter;
  }
  
  this.ticketService.getTickets(0, 100, params).subscribe({
    next: (r: any) => {
      const rows = Array.isArray(r) ? r : []
      this.compactTickets.set(rows)
      const topId = rows[0]?.id ?? null
      if (this.lastSeenTopTicketId !== null && topId !== null && topId !== this.lastSeenTopTicketId) {
        this.compactHasNew.set(true)
      }
      this.lastSeenTopTicketId = topId
      this.compactLoading.set(false)
    },
    error: () => this.compactLoading.set(false)
  })
}

openTicketFromList(id: number) {
  this.compactHasNew.set(false)
  if (id === this.ticketId) return
  this.router.navigate(['/tickets', id])
}

  private messagesEffectRef!: ReturnType<typeof effect>

  private loadTicket(id: number) {
    this.subs.add(
      this.ticketService.getTicketDetail(id).subscribe({
        next: (r: any) => {
          this.ticket.set(r.ticket)
const filteredMessages = (r.messages ?? [])
  .map((m: any) => {
    const isAgentTemplateEmail = m.sender === 'agent' && m.channel === 'email' && !m.sender_name
    const isCreatedEmail = isAgentTemplateEmail && /Ticket Created/i.test(m.message ?? '')
    const isResolvedEmail = isAgentTemplateEmail && /TICKET RESOLVED/i.test(m.message ?? '')

    if (!isCreatedEmail && !isResolvedEmail) return m

    const uidMatch = (m.message ?? '').match(/#([A-Za-z]+-\w+)/)
    const uid = uidMatch?.[1] ?? r.ticket?.ticket_uid ?? ''
    const shortMessage = isCreatedEmail
      ? `Auto-reply sent: Ticket ${uid} created, customer notified by email.`
      : `Feedback request sent: Ticket ${uid} marked resolved, customer notified by email.`

    return { ...m, sender: 'system', channel: null, message: shortMessage }
  })
  .sort((a: any, b: any) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
          this.messages.set(filteredMessages);
          // Scroll both threads (mail + WhatsApp) to the latest message as
          // soon as a ticket is opened/clicked. Actual scrolling happens in
          // ngAfterViewChecked() once the panes exist in the DOM — see the
          // comment there for why that hook (not a timeout/rAF guess) is
          // used.
          this.pendingScrollTicketId = id
          ;[0, 60, 200, 500].forEach(delay => setTimeout(() => this.renderFlowArrows(), delay))
          // Defensive filter — the primary customer email (already shown in
          // the ticket header) should never also show up inside the CC
          // popover. Filtered here regardless of what the server returns,
          // since stale/incorrectly-upserted ticket_cc_participants rows on
          // the backend can otherwise leak the primary contact into this list.
          const primaryEmail = (r.ticket?.customer_email ?? '').trim().toLowerCase()
          this.ccParticipants.set(
            (r.ccParticipants ?? []).filter((p: CcParticipant) => p.email?.trim().toLowerCase() !== primaryEmail)
          )
          this.replyRecipients.set(r.replyRecipients ?? { to: [], cc: [], bcc: [] })
          this.loading.set(false)

          // Auto-sync conversation from Outlook in background for email tickets
          if (r.ticket?.source === 'email' && r.ticket?.mail_conversation_id) {
            this.autoSyncConversation(id)
          }

          // Opening a ticket never actually marked it read anywhere — the
          // green "unread" dot only ever cleared via the explicit toggle
          // button, or incidentally once something else (e.g. a socket
          // ticket_bump) happened to trigger a list refetch. Do it here, once
          // per load, so the dot clears as soon as the ticket is viewed. The
          // /read endpoint emits tickets_updated itself, which is what
          // refreshes both this compact list and the parent tickets list.
          if (r.ticket && !r.ticket.is_read) {
            this.ticket.update(t => t ? { ...t, is_read: 1 } : t)
            this.compactTickets.update(list => list.map(ct => ct.id === id ? { ...ct, is_read: 1 } : ct))
            this.ticketService.markRead(id).subscribe({ error: () => {} })
          }
        },
        error: () => this.loading.set(false)
      })
    )
  }

  ngOnInit() {
    // Only the full-page ticket-detail ROUTE (embedded=false) needs the app
    // sidebar hidden — it renders its own list/properties/chat 3-pane layout
    // that assumes the full window width. The quick-view flap (embedded=true)
    // is just an overlay on top of the tickets list, which should keep
    // showing its sidebar underneath. This has to live in ngOnInit rather
    // than the constructor: @Input() embedded still holds its default value
    // at construction time, so hiding it there hid the sidebar for BOTH
    // cases, including quick view.
    if (!this.embedded) this.layout.sidebarHidden.set(true)
  }

    ngOnChanges(changes: SimpleChanges) {
    if (changes['ticketIdInput'] && this.ticketIdInput && this.ticketIdInput !== this.ticketId) {
      this.ticketId = this.ticketIdInput
      this.loading.set(true)
      this.loadTicket(this.ticketId)
      this.ticketSocket.joinTicket(this.ticketId)
      this.flowResizeObserver.disconnect()
    }
  }


  changeStatus(status: string, sendClosureMessage = false) {
    this.ticketSocket.updateStatus(this.ticketId, status, sendClosureMessage)
    this.ticket.update(t => t ? { ...t, status: status as any } : t)
  }

  statusClass(status: string) {
    return {
      new: 'bg-fuchsia-50 text-fuchsia-700', open: 'bg-blue-50 text-blue-700',
      on_hold: 'bg-amber-50 text-amber-700', waiting: 'bg-amber-50 text-amber-700',
      escalated: 'bg-rose-50 text-rose-700', resolved: 'bg-emerald-50 text-emerald-700',
      closed: 'bg-emerald-50 text-emerald-700',
    }[status] ?? 'bg-slate-100 text-slate-600'
  }

  // Exact emoji + label the customer clicked in the closure email (CSAT 1-5
  // scale) — mirrors RATING_LABELS in TicketFeedbackService.ts. Never remap
  // this down to a generic "Positive/Negative" tier; show exactly what they picked.
  private static readonly RATING_META: Record<number, { emoji: string; label: string; cls: string }> = {
    1: { emoji: '😡', label: 'Very Unsatisfied', cls: 'bg-red-50 text-red-600 border-red-100' },
    2: { emoji: '🙁', label: 'Unsatisfied', cls: 'bg-orange-50 text-orange-600 border-orange-100' },
    3: { emoji: '😐', label: 'Neutral', cls: 'bg-amber-50 text-amber-600 border-amber-100' },
    4: { emoji: '🙂', label: 'Satisfied', cls: 'bg-emerald-50 text-emerald-600 border-emerald-100' },
    5: { emoji: '🤩', label: 'Very Satisfied', cls: 'bg-emerald-50 text-emerald-600 border-emerald-100' },
  }

  ratingMeta(rating?: number | null) {
    if (!rating) return null
    return TicketDetailComponent.RATING_META[rating] ?? null
  }

  initials(name?: string) {
    return name?.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase() || '?'
  }

  attachmentUrl(a: TicketAttachment) {
    // New attachments store the full S3 URL in storage_path. Old rows (saved
    // before the S3 migration) still hold a local uploads/-relative path —
    // keep serving those through the backend's static /uploads route.
    if (/^https?:\/\//i.test(a.storage_path)) return a.storage_path
    return `${environment.apiUrl}/uploads/${a.storage_path}`
  }

  fileSize(bytes?: number) {
    if (!bytes) return ''
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  identificationLabel(t: Ticket): string {
    if ((t.source !== 'email' && t.source !== 'whatsapp') || !t.sender_identification || t.sender_identification === 'unidentified') return ''
    return t.sender_identification === 'organization' ? 'Identified · Organization' : 'Identified · Employee'
  }

  isUnidentified(t: Ticket): boolean {
    return (t.source === 'email' || t.source === 'whatsapp') && t.sender_identification === 'unidentified'
  }

  selectedAttachment = signal<TicketAttachment | null>(null);
  excelData = signal<{ sheetNames: string[]; activeSheet: string; rows: any[][] } | null>(null);
  isLoadingExcel = signal<boolean>(false);
  excelError = signal<string | null>(null);
  private workbookRef: XLSX.WorkBook | null = null;

  // ── Word (.docx) preview ────────────────────────────────────────────────
  docxHtml = signal<SafeHtml | null>(null);
  isLoadingDocx = signal<boolean>(false);
  docxError = signal<string | null>(null);
  textPreview = signal<string | null>(null);
  textTruncated = signal(false);
  isLoadingText = signal(false);
  textError = signal<string | null>(null);
  private static readonly MAX_TEXT_PREVIEW_CHARS = 200_000;

  isExcel(fileName?: string): boolean {
    if (!fileName) return false;
    return /\.(xlsx|xlsb|xls|csv)$/i.test(fileName);
  }

  // Only .docx (Office Open XML) is supported — mammoth.js can't parse the
  // legacy binary .doc format, so those fall through to the generic
  // "Preview not available" / download card below.
  isDocx(fileName?: string): boolean {
    if (!fileName) return false;
    return /\.docx$/i.test(fileName);
  }

  isPdf(fileName?: string): boolean {
    if (!fileName) return false;
    return /\.pdf$/i.test(fileName);
  }

  isTextFile(fileName?: string): boolean {
    if (!fileName) return false;
    return /\.(txt|log|json|md|yml|yaml|xml|ini|conf|sql)$/i.test(fileName);
  }

  pdfSafeUrl(a: TicketAttachment): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(this.attachmentUrl(a));
  }

  // ── Video preview ───────────────────────────────────────────────────────
  isVideo(fileName?: string): boolean {
    if (!fileName) return false;
    return /\.(mp4|webm|ogg|mov|m4v)$/i.test(fileName);
  }

  videoMimeType(fileName?: string): string {
    const ext = (fileName || '').split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'webm': return 'video/webm';
      case 'ogg': return 'video/ogg';
      case 'mov': return 'video/quicktime';
      case 'm4v': return 'video/mp4';
      default: return 'video/mp4';
    }
  }

  openPreview(attachment: TicketAttachment) {
    this.selectedAttachment.set(attachment);
    this.excelData.set(null);
    this.excelError.set(null);
    this.docxHtml.set(null);
    this.docxError.set(null);
    this.textPreview.set(null);
    this.textError.set(null);
    this.textTruncated.set(false);
    if (this.isExcel(attachment.file_name)) {
      this.loadExcelPreview(this.attachmentUrl(attachment));
    } else if (this.isDocx(attachment.file_name)) {
      this.loadDocxPreview(this.attachmentUrl(attachment));
    } else if (this.isTextFile(attachment.file_name)) {
      this.loadTextPreview(this.attachmentUrl(attachment));
    }
    // Video needs no upfront loading step — the <video> tag streams the
    // attachment URL directly (see attachmentUrl()).
  }

  async loadDocxPreview(url: string) {
    this.isLoadingDocx.set(true);
    try {
      let response: Response;
      try {
        response = await fetch(url);
      } catch (fetchErr) {
        console.error('[ticket-detail] fetch() threw while loading docx preview — almost always a CORS issue on the storage bucket.', { url, fetchErr });
        throw new Error('Could not load this file for preview. The storage bucket may be missing a CORS rule for this origin — check the bucket\'s CORS configuration.');
      }
      if (!response.ok) {
        console.error('[ticket-detail] docx preview fetch returned a non-OK status', { url, status: response.status, statusText: response.statusText });
        throw new Error(`Failed to load file content (HTTP ${response.status}).`);
      }
      const buffer = await response.arrayBuffer();
      const result = await mammoth.convertToHtml({ arrayBuffer: buffer });
      this.docxHtml.set(this.sanitizer.bypassSecurityTrustHtml(result.value));
    } catch (err: any) {
      this.docxError.set(err?.message || 'Error reading Word document');
    } finally {
      this.isLoadingDocx.set(false);
    }
  }

  async loadExcelPreview(url: string) {
    this.isLoadingExcel.set(true);
    try {
      let response: Response;
      try {
        response = await fetch(url);
      } catch (fetchErr) {
        console.error('[ticket-detail] fetch() threw while loading preview file — this is almost always a CORS issue on the storage bucket, not a network outage.', { url, fetchErr });
        throw new Error('Could not load this file for preview. The storage bucket may be missing a CORS rule for this origin — check the bucket\'s CORS configuration.');
      }
      if (!response.ok) {
        console.error('[ticket-detail] preview fetch returned a non-OK status', { url, status: response.status, statusText: response.statusText });
        throw new Error(`Failed to load file content (HTTP ${response.status}).`);
      }
      const buffer = await response.arrayBuffer();
      this.workbookRef = XLSX.read(buffer, { type: 'array' });
      if (this.workbookRef.SheetNames.length > 0) {
        this.selectSheet(this.workbookRef.SheetNames[0]);
      }
    } catch (err: any) {
      this.excelError.set(err?.message || 'Error reading Excel file');
    } finally {
      this.isLoadingExcel.set(false);
    }
  }

  async loadTextPreview(url: string) {
    this.isLoadingText.set(true);
    try {
      let response: Response;
      try {
        response = await fetch(url);
      } catch (fetchErr) {
        console.error('[ticket-detail] fetch() threw while loading text preview — often a CORS issue on the storage bucket.', { url, fetchErr });
        throw new Error('Could not load this file for preview. The storage bucket may be missing a CORS rule for this origin.');
      }
      if (!response.ok) {
        throw new Error(`Failed to load file content (HTTP ${response.status}).`);
      }
      let text = await response.text();
      if (text.length > TicketDetailComponent.MAX_TEXT_PREVIEW_CHARS) {
        text = text.slice(0, TicketDetailComponent.MAX_TEXT_PREVIEW_CHARS);
        this.textTruncated.set(true);
      }
      this.textPreview.set(text);
    } catch (err: any) {
      this.textError.set(err?.message || 'Error reading file');
    } finally {
      this.isLoadingText.set(false);
    }
  }

  selectSheet(sheetName: string) {
    if (!this.workbookRef) return;
    const worksheet = this.workbookRef.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' }) as any[][];
    this.excelData.set({ sheetNames: this.workbookRef.SheetNames, activeSheet: sheetName, rows });
  }

  closePreview() {
    this.selectedAttachment.set(null);
    this.docxHtml.set(null);
    this.docxError.set(null);
    this.excelData.set(null);
    this.excelError.set(null);
    this.textPreview.set(null);
    this.textError.set(null);
    this.textTruncated.set(false);
  }

  isImage(fileName?: string): boolean {
    if (!fileName) return false;
    return /\.(jpg|jpeg|jfif|png|gif|webp|svg|bmp|tif|tiff|heic|heif)$/i.test(fileName);
  }

  getFormattedHtml(msg: TicketMessage & { formattedHtml?: SafeHtml }): SafeHtml {
    if (msg.formattedHtml) return msg.formattedHtml
    let content = msg.message || ''
    content = content.replace(/src=["'](?:\/)?uploads\//gi, `src="${environment.apiUrl}/uploads/`)
    content = this.renderMediaLinks(content)
    msg.formattedHtml = this.sanitizer.bypassSecurityTrustHtml(content)
    return msg.formattedHtml
  }

  // ── Inline video-link previews (YouTube / Vimeo / Loom / Clipchamp etc.) ──
  // Message bodies (email/WhatsApp) often contain links to hosted video
  // shares. Previously these just sat there as plain text/links the agent
  // had to click through to a new tab. getFormattedHtml() now rewrites any
  // link we can confidently recognize into a big, Outlook-style preview card
  // (real thumbnail + centered play button); clicking it opens an inline
  // player via openMediaPreview() below instead of leaving the ticket.
  // Anything we don't recognize is left as a normal link that opens in a
  // new tab — that "can't be previewed → next page" fallback is the point.
  //
  // IMPORTANT: this card's markup is built with fully INLINE styles rather
  // than CSS classes. Angular's emulated view encapsulation only scopes
  // styles to elements that go through the template compiler — elements
  // inserted via [innerHTML] never get the `_ngcontent-*` attribute, so a
  // component-stylesheet rule like `.upd-media-card { ... }` silently never
  // matches them. Inline styles sidestep that entirely and render correctly
  // no matter how this component is compiled.
  mediaPreview = signal<{ embedUrl: SafeResourceUrl; title: string; originalUrl: string; iframeOk: boolean } | null>(null)

  private extractYoutubeId(url: string): string | null {
    const m = url.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{6,})/i)
    return m ? m[1] : null
  }

  private extractVimeoId(url: string): string | null {
    const m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/i)
    return m ? m[1] : null
  }

  private extractLoomId(url: string): string | null {
    const m = url.match(/loom\.com\/(?:share|embed)\/([a-zA-Z0-9]+)/i)
    return m ? m[1] : null
  }

  // Hosts we recognize as "this link points at a video" but don't have a
  // documented, reliable embed-URL format for. We still show a big preview
  // card for these (using the email's own thumbnail image when the link
  // wraps one, e.g. Clipchamp's share-card <img>), and fall back to
  // iframing the share page itself when the agent clicks play.
  private readonly GENERIC_VIDEO_HOSTS = [
    'clipchamp.com', 'vidyard.com', 'wistia.com', 'wistia.net', 'veed.io',
    'cloudapp.net', 'screencast-o-matic.com', 'screencastomatic.com',
    'stream.microsoft.com'
  ]

  private matchGenericVideoHost(url: string): string | null {
    try {
      const host = new URL(url).hostname.toLowerCase()
      const match = this.GENERIC_VIDEO_HOSTS.find(h => host === h || host.endsWith(`.${h}`))
      return match || null
    } catch {
      return null
    }
  }

  // Outlook's "Record a clip" / Clipchamp-in-Outlook feature doesn't
  // actually host the video on clipchamp.com — it uploads it to the
  // sender's own OneDrive/SharePoint ("personal") site and inserts a share
  // link there, with "Clipchamp" left behind only as plain caption text.
  // Those links look like:
  //   https://{tenant}-my.sharepoint.com/:v:/g/personal/{user}/{id}?...
  // The `:v:` segment is OneDrive's own marker for "this share is a video"
  // (`:w:` word, `:x:` excel, `:p:` powerpoint, `:b:` pdf/binary, etc.), so
  // we key off that rather than the tenant name, which differs per company.
  private isSharePointVideoLink(url: string): boolean {
    try {
      const u = new URL(url)
      return /\.sharepoint\.com$/i.test(u.hostname) && /\/:v:\//i.test(u.pathname)
    } catch {
      return false
    }
  }

  /** Many corporate mail flows route links through a click-tracker or
   *  "safe link" wrapper (Outlook/Defender's safelinks.protection.outlook.com
   *  is the most common) before they reach the real destination. If we
   *  classify against the wrapper URL, we never recognize the real
   *  YouTube/Clipchamp/etc. link underneath — so unwrap known wrapper
   *  patterns first and classify the real target instead. */
  private unwrapTrackedUrl(url: string): string {
    try {
      const parsed = new URL(url)
      if (/\.safelinks\.protection\.outlook\.com$/i.test(parsed.hostname)) {
        const real = parsed.searchParams.get('url')
        if (real) return decodeURIComponent(real)
      }
      if (/(^|\.)google\.[a-z.]+$/i.test(parsed.hostname) && parsed.pathname === '/url') {
        const real = parsed.searchParams.get('q') || parsed.searchParams.get('url')
        if (real) return decodeURIComponent(real)
      }
      for (const key of ['url', 'u', 'target', 'redirect', 'redirect_url']) {
        const val = parsed.searchParams.get(key)
        if (val && /^https?:\/\//i.test(val)) return decodeURIComponent(val)
      }
    } catch {
      // not a parseable absolute URL — leave as-is
    }
    return url
  }

  /** Classifies a (already-unwrapped) URL for inline preview. Returns null
   *  for anything we don't recognize — those links are left alone as
   *  normal new-tab links. */
  private classifyMediaLink(url: string): { type: 'youtube' | 'vimeo' | 'loom' | 'generic'; thumb?: string; host?: string } | null {
    const yt = this.extractYoutubeId(url)
    if (yt) return { type: 'youtube', thumb: `https://img.youtube.com/vi/${yt}/hqdefault.jpg` }
    if (this.extractVimeoId(url)) return { type: 'vimeo' }
    if (this.extractLoomId(url)) return { type: 'loom' }
    if (this.isSharePointVideoLink(url)) {
      let host = 'sharepoint.com'
      try { host = new URL(url).hostname } catch { /* keep default */ }
      return { type: 'generic', host }
    }
    const host = this.matchGenericVideoHost(url)
    if (host) return { type: 'generic', host }
    return null
  }

  private mediaTypeLabel(type: string, host?: string): string {
    if (type === 'youtube') return 'YouTube'
    if (type === 'vimeo') return 'Vimeo'
    if (type === 'loom') return 'Loom'
    if (host && /\.sharepoint\.com$/i.test(host)) return 'OneDrive'
    if (host) {
      const name = host.replace(/^www\./i, '').split('.')[0]
      return name.charAt(0).toUpperCase() + name.slice(1)
    }
    return 'Video'
  }

  /** Finds bare (non-linked) URLs in text nodes and wraps them in <a> tags,
   *  so plain-text messages (e.g. WhatsApp) get the same treatment as HTML
   *  emails where links already arrive as anchors. Skips text already
   *  inside an <a>, <script>, or <style> tag. */
  private linkifyTextNodes(root: HTMLElement) {
    const urlTest = /https?:\/\/[^\s<>"']+/i
    const urlGlobal = /https?:\/\/[^\s<>"']+/gi
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => {
        let p = node.parentElement
        while (p && p !== root) {
          if (p.tagName === 'A' || p.tagName === 'SCRIPT' || p.tagName === 'STYLE') return NodeFilter.FILTER_REJECT
          p = p.parentElement
        }
        return urlTest.test(node.textContent || '') ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
      }
    })
    const textNodes: Text[] = []
    let n: Node | null
    while ((n = walker.nextNode())) textNodes.push(n as Text)

    textNodes.forEach(textNode => {
      const text = textNode.textContent || ''
      const frag = document.createDocumentFragment()
      let lastIndex = 0
      let match: RegExpExecArray | null
      urlGlobal.lastIndex = 0
      while ((match = urlGlobal.exec(text))) {
        if (match.index > lastIndex) frag.appendChild(document.createTextNode(text.slice(lastIndex, match.index)))
        const a = document.createElement('a')
        a.setAttribute('href', match[0])
        a.textContent = match[0]
        frag.appendChild(a)
        lastIndex = match.index + match[0].length
      }
      if (lastIndex < text.length) frag.appendChild(document.createTextNode(text.slice(lastIndex)))
      textNode.replaceWith(frag)
    })
  }

  /** Builds the big, Outlook-style preview card markup for a recognized
   *  video link. thumbSrc, when available, is the email's OWN thumbnail
   *  image (e.g. Clipchamp's share-card screenshot) so the card looks as
   *  authentic as what the sender's mail client renders — we only fall
   *  back to a generic gradient when no real image is available. */
  private buildMediaCard(href: string, label: string, media: { type: string; host?: string }, thumbSrc?: string): HTMLElement {
    const card = document.createElement('span')
    card.className = 'upd-media-card'
    card.setAttribute('data-preview-url', href)
    card.setAttribute('data-preview-type', media.type)
    card.setAttribute('data-preview-title', label)
    card.setAttribute('style', 'display:block;max-width:360px;margin:8px 0;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden;cursor:pointer;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.08);')
    const thumbStyle = thumbSrc
      ? `background:#0f172a url('${thumbSrc}') center/cover no-repeat;`
      : 'background:linear-gradient(135deg,#4f46e5,#7c3aed);'
    card.innerHTML = `
      <span style="display:block;position:relative;width:100%;padding-top:56.25%;${thumbStyle}">
        <span style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:52px;height:52px;border-radius:50%;background:rgba(255,255,255,0.95);display:flex;align-items:center;justify-content:center;box-shadow:0 2px 10px rgba(0,0,0,0.35);">
          <span style="width:0;height:0;border-style:solid;border-width:9px 0 9px 15px;border-color:transparent transparent transparent #4f46e5;margin-left:4px;"></span>
        </span>
      </span>
      <span style="display:block;padding:8px 12px;">
        <span style="display:block;font-size:12.5px;font-weight:600;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(label)}</span>
        <span style="display:block;font-size:11px;color:#64748b;margin-top:1px;">${this.mediaTypeLabel(media.type, media.host)} video · Click to play</span>
      </span>`
    return card
  }

  /** Walks the message HTML: linkifies bare URLs, unwraps tracked/safe
   *  links, swaps recognized video links for a big inline preview card
   *  (read back by onMessageBodyClick), and forces every remaining link to
   *  open in a new tab rather than navigating the ticket view away. */
  private renderMediaLinks(html: string): string {
    if (!html) return html
    let root: HTMLElement
    try {
      root = new DOMParser().parseFromString(html, 'text/html').body
    } catch {
      return html // malformed input — leave untouched rather than risk breaking the message
    }

    this.linkifyTextNodes(root)

    root.querySelectorAll('a[href]').forEach(anchor => {
      const rawHref = anchor.getAttribute('href') || ''
      const href = this.unwrapTrackedUrl(rawHref)
      const media = this.classifyMediaLink(href)
      if (!media) {
        anchor.setAttribute('target', '_blank')
        anchor.setAttribute('rel', 'noopener noreferrer')
        return
      }
      // Prefer the email's own thumbnail image when this link wraps one
      // (e.g. a Clipchamp/Loom share card already contains a real
      // screenshot) — it looks far more authentic than any placeholder we
      // could generate ourselves.
      const innerImg = anchor.querySelector('img')
      const thumbSrc = innerImg?.getAttribute('src') || media.thumb
      const rawLabel = (anchor.textContent || '').trim()
      const label = (!rawLabel || /^https?:\/\//i.test(rawLabel))
        ? `${this.mediaTypeLabel(media.type, media.host)} video`
        : rawLabel
      const card = this.buildMediaCard(href, label, media, thumbSrc)
      anchor.replaceWith(card)
    })

    return root.innerHTML
  }

  /** Event-delegated click handler bound to each message-body container so
   *  clicking anywhere on an injected `.upd-media-card` (built above) opens
   *  the inline player, without needing per-node Angular bindings on HTML
   *  we set via [innerHTML]. */
  onMessageBodyClick(event: MouseEvent) {
    const target = event.target as HTMLElement
    const card = target.closest('.upd-media-card') as HTMLElement | null
    if (!card) return
    event.preventDefault()
    event.stopPropagation()
    const url = card.getAttribute('data-preview-url') || ''
    const type = card.getAttribute('data-preview-type') || 'generic'
    const title = card.getAttribute('data-preview-title') || url
    this.openMediaPreview(url, type, title)
  }

  openMediaPreview(url: string, type: string, title: string) {
    let embed = url
    let iframeOk = true
    if (type === 'youtube') {
      const id = this.extractYoutubeId(url)
      embed = id ? `https://www.youtube.com/embed/${id}?autoplay=1&rel=0` : url
    } else if (type === 'vimeo') {
      const id = this.extractVimeoId(url)
      embed = id ? `https://player.vimeo.com/video/${id}?autoplay=1` : url
    } else if (type === 'loom') {
      const id = this.extractLoomId(url)
      embed = id ? `https://www.loom.com/embed/${id}` : url
    } else {
      // Generic hosts (Clipchamp and anything else we recognized but can't
      // build a known embed URL for) — try iframing the share page itself.
      // Some hosts block this via X-Frame-Options, so the modal keeps an
      // "open in new tab" fallback the agent can use if the frame stays
      // blank.
      embed = url
      iframeOk = false
    }
    this.mediaPreview.set({
      embedUrl: this.sanitizer.bypassSecurityTrustResourceUrl(embed),
      title,
      originalUrl: url,
      iframeOk
    })
  }

  closeMediaPreview() {
    this.mediaPreview.set(null)
  }

  isClosedOrResolved(): boolean {
    const s = this.ticket()?.status
    return s === 'closed' || s === 'resolved'
  }

  canRespond(): boolean {
    const t = this.ticket()
    if (!t) return false
    if (this.isClosedOrResolved()) return false
    if (this.auth.isAdmin()) return true
    return !t.assigned_to || Number(t.assigned_to) === this.auth.getAgentId()
  }

  isPickedByOther(): boolean {
    const t = this.ticket()
    return !!t?.assigned_to && Number(t.assigned_to) !== this.auth.getAgentId() && !this.auth.isAdmin()
  }

  pickingUp = signal(false)

  pickUp() {
    const t = this.ticket()
    if (!t || this.pickingUp()) return
    this.pickingUp.set(true)
    const agentId = this.auth.getAgentId()
    const agentName = this.auth.getAgentName()
    this.ticketService.assign(t.id, agentId, agentName).subscribe({
      next: (res: any) => {
        this.pickingUp.set(false)
        if (res?.status === false || res?.error) {
          this.dialog.alert(res.error || 'Failed to pick up this ticket. Please try again.')
          return
        }
        this.ticket.update(cur => cur ? {
          ...cur,
          assigned_to: agentId,
          assigned_agent_name: agentName,
          status: cur.status === 'new' ? 'open' : cur.status,
          ...(res?.ticket || {})
        } : null)
        this.ticketSocket.assignTicket(t.id, agentId, agentName)
      },
      error: (err) => {
        this.pickingUp.set(false)
        this.dialog.alert(err?.error?.message || err?.error?.error || err?.message || 'Failed to pick up this ticket. Please try again.')
      }
    })
  }

  // ─── Auto-sync with Outlook in background ────────────────────────────────────
  private isAutoSyncing = false
  private autoSyncConversation(ticketId: number) {
    if (this.isAutoSyncing) return
    this.isAutoSyncing = true
    this.ticketService.syncMail(ticketId).subscribe({
      next: (res) => {
        this.isAutoSyncing = false
        if (res?.synced && res.synced > 0) {
          // Reload ticket so newly discovered historical messages appear in chronological order
          this.loadTicket(ticketId)
        }
      },
      error: () => {
        this.isAutoSyncing = false
      }
    })
  }

  // ─── Manual Re-sync with Outlook ──────────────────────────────────────────
  resyncFromOutlook(t: any) {
    if (!t || this.isResyncing()) return
    this.isResyncing.set(true)
    const targetUid = t.ticket_uid || String(t.id)
    this.resyncService.resyncTicket(targetUid).subscribe({
      next: (res) => {
        this.isResyncing.set(false)
        this.loadTicket(t.id || this.ticketId)
        this.dialog.alert(`Re-sync complete for #${targetUid}. ${res.messagesInserted} message(s) imported from Outlook.`)
      },
      error: (err) => {
        this.isResyncing.set(false)
        const msg = err?.error?.error || err?.message || 'Re-sync failed. Please try again.'
        this.dialog.alert(`Re-sync failed for #${targetUid}: ${msg}`)
      },
    })
  }

  reassign(agentId: number) {
    const t = this.ticket()
    const agent = this.agents().find(a => a.id === Number(agentId))
    if (!t || !agent) return
    this.ticketService.assign(t.id, agent.id, agent.name).subscribe({
      next: (res: any) => {
        if (res?.status === false || res?.error) {
          this.dialog.alert(res.error || 'Failed to reassign this ticket. Please try again.')
          return
        }
        this.ticket.update(cur => cur ? {
          ...cur,
          assigned_to: agent.id,
          assigned_agent_name: agent.name,
          ...(res?.ticket || {})
        } : null)
        this.ticketSocket.assignTicket(t.id, agent.id, agent.name)
      },
      error: (err) => {
        this.dialog.alert(err?.error?.message || err?.error?.error || err?.message || 'Failed to reassign this ticket. Please try again.')
      }
    })
  }

  toggleRecipient(email: string) {
    this.selectedRecipients.update(list => list.includes(email) ? list.filter(e => e !== email) : [...list, email])
  }

  primaryCustomerEmail(): string {
    const custEmail = this.ticket()?.customer_email?.trim()
    if (custEmail) return custEmail
    const mailbox = this.ticket()?.mailbox_email?.trim()?.toLowerCase()
    const candidates = [...(this.replyRecipients().to || []), ...(this.replyRecipients().cc || [])]
    const nonMailbox = candidates.find(e => e.trim().toLowerCase() !== mailbox)
    return nonMailbox || this.replyRecipients().to[0] || ''
  }

  replyAllToRecipients(): string[] {
    const cust = this.primaryCustomerEmail()
    return cust ? [cust] : []
  }

  replyAllCcRecipients(): string[] {
    const mailbox = this.ticket()?.mailbox_email?.trim()?.toLowerCase()
    const cust = this.primaryCustomerEmail()?.toLowerCase()
    const rawList = [
      ...(this.replyRecipients().to || []),
      ...(this.replyRecipients().cc || []),
      // Persisted CC participants (ticket_cc_participants) — includes CC/BCC
      // addresses an agent added on an earlier reply in this ticket, not
      // just whatever's currently typed into the +CC/+BCC chip inputs.
      // Without this, "Reply All" forgets any CC added on a previous send
      // the moment the drawer is closed/reopened.
      ...this.ccParticipants().map(p => p.email),
      ...this.customCcChips()
    ]
    const filtered = rawList.filter(e => {
      const norm = e.trim().toLowerCase()
      return norm && norm !== mailbox && norm !== cust
    })
    return Array.from(new Set(filtered))
  }

  replyAllRecipientsCount(): number {
    return this.replyAllToRecipients().length + this.replyAllCcRecipients().length
  }

  allRecipients(): string[] {
    const mailbox = this.ticket()?.mailbox_email?.trim()?.toLowerCase()
    const cust = this.ticket()?.customer_email?.trim()
    const r = this.replyRecipients()
    const list = [
      ...(cust ? [cust] : []),
      ...(r.to || []),
      ...(r.cc || []),
      ...(r.bcc || []),
      // Same as replyAllCcRecipients() above: fold in persisted CC
      // participants AND whatever the agent has just typed into the +CC/+BCC
      // inputs, so a newly-added CC/BCC immediately shows up as a selectable
      // recipient in "Reply Selected" instead of only being sendable via the
      // separate CC/BCC chip fields.
      ...this.ccParticipants().map(p => p.email),
      ...this.customCcChips(),
      ...this.customBccChips(),
    ]
    const filtered = list.filter(e => {
      const norm = e.trim().toLowerCase()
      return norm && norm !== mailbox
    })
    return Array.from(new Set(filtered))
  }

  // ── Right-Side Sheet Actions ─────────────────────────────────────────────────
  openDrawer(mode: 'reply' | 'reply_all' | 'reply_selected' | 'forward') {
    this.drawerMode.set(mode)
    // Restore any unsent draft saved earlier for this ticket (see
    // onDrawerInput/confirmInsertLink below, which persist it as the agent
    // types). Callers that need a specific prefilled body — confirmRelay()'s
    // quote note, respondToSelected()'s "Hi {name}," greeting — call
    // setDrawerDraft() again right after this, which simply overwrites it.
    this.setDrawerDraft(this.ticketDraftService.load(this.ticketId))
    // Restore any attachments saved alongside the draft text (see
    // onAttachmentPicked/removeAttachment below, which persist them as the
    // agent adds/removes files). Rebuilt as already-uploaded PendingAttachment
    // entries — storagePath is already known so no re-upload is needed.
    this.drawerAttachments.set(
      this.ticketDraftService.loadAttachments(this.ticketId).map((a, i) => ({
        fileName: a.fileName,
        contentType: a.contentType,
        size: a.size,
        storagePath: a.storagePath,
        clientId: `att-restore-${Date.now()}-${i}`,
        uploading: false,
        error: null,
      }))
    )
    const savedCc = this.ticketDraftService.loadCc(this.ticketId)
    const savedBcc = this.ticketDraftService.loadBcc(this.ticketId)
    this.customCcChips.set(savedCc)
    this.customBccChips.set(savedBcc)
    this.showCcInput.set(savedCc.length > 0)
    this.showBccInput.set(savedBcc.length > 0)
    this.forwardToInput = ''
    this.forwardToChips.set([])
    this.drawerSignatureHtml.set(null)
    this.signatureNotConfigured.set(false)
    this.signatureBannerDismissed = false
    this.drawerOpen.set(true)
    // Always start clean — confirmRelay() (the only place a cross-channel
    // reference should be attached) sets relatedMessageId AFTER calling this,
    // so a stale value from an earlier quote/relay action never leaks into
    // an ordinary "Reply" click.
    this.relatedMessageId = null

    if (mode === 'reply_all') {
      this.selectedRecipients.set(this.allRecipients())
    } else if (mode === 'reply_selected') {
      this.selectedRecipients.set([])
    }

    // Load agent signature for Footer preview
    this.drawerSignatureLoading.set(true)
    const agentId = this.auth.getAgentId()
    this.agentService.getSignature(agentId).subscribe({
      next: (res: any) => {
        const raw = res?.signatureHtml?.trim() ?? ''
        if (raw) {
          let formattedSig = raw
            .split('{{agent_name}}').join(this.auth.getAgentName())
            .split('{{customer_name}}').join(this.ticket()?.customer_name ?? '')
            .split('{{ticket_id}}').join(this.ticket()?.ticket_uid ?? '')
          
          // If signature has no HTML tags, convert newlines to <br> so linebreaks render properly
          if (!/<[a-z][\s\S]*>/i.test(formattedSig)) {
            formattedSig = formattedSig.replace(/\r?\n/g, '<br/>')
          }

          this.drawerSignatureHtml.set(this.sanitizer.bypassSecurityTrustHtml(formattedSig))
          this.signatureNotConfigured.set(false)
        } else {
          this.drawerSignatureHtml.set(null)
          this.signatureNotConfigured.set(true)
        }
        this.drawerSignatureLoading.set(false)
      },
      error: () => {
        this.drawerSignatureHtml.set(null)
        this.signatureNotConfigured.set(false)
        this.drawerSignatureLoading.set(false)
      }
    })
  }

  closeDrawer() {
    this.drawerOpen.set(false)
    this.drawerDraft = ''
    this.drawerAttachments.set([])
    this.forwardToInput = ''
    this.forwardToChips.set([])
    this.showCcInput.set(false)
    this.showBccInput.set(false)
    this.customCcChips.set([])
    this.customBccChips.set([])
    this.ccInputText = ''
    this.bccInputText = ''
  }

  // ── Draft banner actions (shown above the thread when a saved draft exists
  // for this ticket and the compose drawer isn't already open) ──────────────
  /** Opens the reply drawer, which auto-restores the saved draft (see
   *  openDrawer() above) — so this just picks a sensible default mode. */
  continueDraft() {
    this.openDrawer('reply')
  }

  /** Discards the saved draft without opening the composer. Confirms first
   *  since this can't be undone once the text is gone. */
  async discardDraft() {
    const ok = await this.dialog.confirm({
      title: 'Discard draft',
      message: 'Discard the saved draft reply for this ticket? This can\'t be undone.',
      confirmLabel: 'Discard',
      variant: 'danger',
    })
    if (!ok) return
    this.ticketDraftService.clear(this.ticketId)
  }
  // ───────────────────────────────────────────────────────────────────────────

  addForwardChip(event?: Event) {
    if (event) event.preventDefault()
    const val = this.forwardToInput.trim()
    if (!val) return
    // Split by comma in case user pasted multiple
    const emails = val.split(',').map(e => e.trim()).filter(Boolean)
    const existing = this.forwardToChips()
    const toAdd = emails.filter(e => !existing.includes(e))
    if (toAdd.length) this.forwardToChips.update(c => [...c, ...toAdd])
    this.forwardToInput = ''
  }

  removeForwardChip(email: string) {
    this.forwardToChips.update(c => c.filter(e => e !== email))
  }

  onForwardInputKeydown(event: KeyboardEvent) {
    if (event.key === 'Enter' || event.key === ',' || event.key === ' ') {
      this.addForwardChip(event)
    }
  }

  addCcChip(event?: Event) {
    if (event) event.preventDefault()
    const val = this.ccInputText.trim()
    if (!val) return
    const emails = val.split(',').map(e => e.trim()).filter(Boolean)
    const existing = this.customCcChips()
    const toAdd = emails.filter(e => !existing.includes(e))
    if (toAdd.length) {
      this.customCcChips.update(c => [...c, ...toAdd])
      this.saveCurrentDraft()
    }
    this.ccInputText = ''
  }

  removeCcChip(email: string) {
    this.customCcChips.update(c => c.filter(e => e !== email))
    this.saveCurrentDraft()
  }

  onCcInputKeydown(event: KeyboardEvent) {
    if (event.key === 'Enter' || event.key === ',' || event.key === ' ') {
      this.addCcChip(event)
    }
  }

  addBccChip(event?: Event) {
    if (event) event.preventDefault()
    const val = this.bccInputText.trim()
    if (!val) return
    const emails = val.split(',').map(e => e.trim()).filter(Boolean)
    const existing = this.customBccChips()
    const toAdd = emails.filter(e => !existing.includes(e))
    if (toAdd.length) {
      this.customBccChips.update(c => [...c, ...toAdd])
      this.saveCurrentDraft()
    }
    this.bccInputText = ''
  }

  removeBccChip(email: string) {
    this.customBccChips.update(c => c.filter(e => e !== email))
    this.saveCurrentDraft()
  }

  onBccInputKeydown(event: KeyboardEvent) {
    if (event.key === 'Enter' || event.key === ',' || event.key === ' ') {
      this.addBccChip(event)
    }
  }

  private saveCurrentDraft() {
    this.ticketDraftService.save(
      this.ticketId,
      this.drawerDraft,
      this.attachmentsForSend('drawer'),
      this.customCcChips(),
      this.customBccChips()
    )
  }

  // drawerDraft is captured straight from the contenteditable compose div's
  // innerHTML (see onDrawerInput below). Typing a plain, unformatted reply
  // with a trailing or repeated space still leaves a literal "&nbsp;" entity
  // in that innerHTML even though the string has no real HTML tag anywhere.
  // The backend (EmailToTicketService.sendAgentReplyByEmail) decides "is
  // this HTML?" by checking for a tag, and treats a tag-less string as plain
  // text — escaping "&" to "&amp;" before wrapping it in a <p>. That turns
  // the stray "&nbsp;" into "&amp;nbsp;", which renders as the literal text
  // "&nbsp;" in the sent email. Genuinely formatted content (a link, a
  // chip, bold text, ...) always contains a real tag and is unaffected —
  // only decode when there's no tag to lose, so this never touches actual
  // HTML formatting.
  private normalizeDraftForSend(html: string): string {
    if (/<[a-z][\s\S]*>/i.test(html)) return html
    const div = document.createElement('div')
    div.innerHTML = html
    return (div.textContent ?? div.innerText ?? '').trim()
  }

  // Shared by every "send an agent message" call site (drawer reply, internal
  // note, WA composer, inline WA reply, inline mail reply). Pushes the
  // optimistic placeholder, then sends via the ack-based socket call — on
  // success the placeholder is swapped for the real message the normal way
  // (via the 'new_ticket_message' broadcast + swap heuristic further up this
  // file); on failure/timeout it flips the SAME placeholder to a `failed`
  // state instead of leaving it on "Sending..." forever. The original
  // payload is kept on the row (`_payload`) so retryFailedAgentMessage() can
  // resend it without duplicating the payload-building logic per call site.
  private dispatchAgentMessage(payload: any, pendingMessage: any) {
    pendingMessage._payload = payload
    this.messages.update(list => [...list, pendingMessage])
    if (!this.ticket()?.assigned_to) {
      const myId = this.auth.getAgentId()
      const myName = this.auth.getAgentName()
      if (myId) {
        this.ticket.update(t => t ? { ...t, assigned_to: myId, assigned_agent_name: myName } : t)
      }
    }
    this.ticketSocket.sendMessage(payload, (result) => {
      if (result.ok) return
      this.messages.update(list => list.map(m =>
        m.id === pendingMessage.id
          ? { ...m, isSending: false, delivery_status: 'failed', failure_reason: result.error }
          : m
      ))
    })
  }

  // Re-sends a failed outgoing agent message. Two cases:
  //  1. Still-in-memory placeholder from THIS session (m._payload set by
  //     dispatchAgentMessage) — replay it through the same socket path.
  //  2. Everything else — BUG FIX: this used to require m._payload and
  //     silently return (no error, no spinner, nothing) whenever it was
  //     missing. But _payload only ever exists on a placeholder held in
  //     THIS browser tab's memory from the moment it was first sent — the
  //     instant the page is reloaded, the ticket is reopened, or a
  //     different agent opens it, the failed message comes back from the
  //     server with no _payload at all. That's the normal case for a
  //     message that failed and stayed failed, which is exactly when an
  //     agent would go looking for the Retry button — so it was a no-op
  //     for the one case it actually needed to work. Now falls back to the
  //     REST retry endpoint (retryMessage(), see ticket.service.ts), which
  //     re-sends using what's already stored on the message row itself —
  //     same endpoint the system-message Retry button next to auto-ack
  //     failures already uses successfully.
  retryFailedAgentMessage(m: any) {
    if (this.retryingMessageId() === m.id) return
    this.retryingMessageId.set(m.id)
    this.messages.update(list => list.map(x =>
      x.id === m.id ? { ...x, isSending: true, delivery_status: undefined, failure_reason: undefined } : x
    ))

    if (m?._payload) {
      this.ticketSocket.sendMessage(m._payload, (result) => {
        this.retryingMessageId.set(null)
        if (result.ok) return
        this.messages.update(list => list.map(x =>
          x.id === m.id ? { ...x, isSending: false, delivery_status: 'failed', failure_reason: result.error } : x
        ))
      })
      return
    }

    this.ticketService.retryMessage(m.id).subscribe({
      next: (r: any) => {
        this.retryingMessageId.set(null)
        this.messages.update(list => list.map(x => x.id === m.id ? { ...x, isSending: false, ...r.message } : x))
      },
      error: () => {
        this.retryingMessageId.set(null)
        this.messages.update(list => list.map(x =>
          x.id === m.id ? { ...x, isSending: false, delivery_status: 'failed' } : x
        ))
      },
    })
  }

  sendFromDrawer() {
    const text = this.normalizeDraftForSend(this.drawerDraft.trim())
    const attachments = this.attachmentsForSend('drawer')
    if ((!text && !attachments.length) || !this.canRespond() || this.attachmentsUploading('drawer')) return

    const mode = this.drawerMode()

    // Flush any pending chip text before sending
    if (mode === 'forward') {
      if (this.forwardToInput.trim()) this.addForwardChip()
      if (!this.forwardToChips().length) {
        this.dialog.alert('Please enter at least one recipient email address to forward to.')
        return
      }
    }
    if (this.ccInputText.trim()) this.addCcChip()
    if (this.bccInputText.trim()) this.addBccChip()

    let toRecipients: string[] = []
    let ccRecipients: string[] = []
    let bccRecipients: string[] = []

    // Reply All / Reply Selected / Forward are only ever shown for
    // t.source === 'email' tickets (see template) — always email, unchanged.
    // Plain "Reply" is shown for BOTH email and WhatsApp tickets, so it must
    // route to whichever channel the ticket actually is; hardcoding 'email'
    // here made every agent reply on a WhatsApp-origin ticket silently try
    // (and fail) to send by email instead.
    // Route to WhatsApp only when this is a WhatsApp-origin ticket AND there
    // is no mail thread at all to reply on (same condition that gates
    // whether Reply All/Selected/Forward are shown at all, above). If a mail
    // thread exists — even on a WhatsApp-origin ticket, e.g. one auto-created
    // from an identified customer's inbound message — "Reply" here always
    // means reply-by-email; WhatsApp replies belong to the dedicated WA
    // composer / the inline "Reply via WhatsApp" icon, not this button.
    const replyChannel = mode === 'reply' && this.ticket()?.source === 'whatsapp' && !this.mailMessages().length ? 'whatsapp' : 'email'

    if (mode === 'reply') {
      const primary = this.primaryCustomerEmail()
      if (primary) toRecipients = [primary]
      ccRecipients = [...this.customCcChips()]
      bccRecipients = [...this.customBccChips()]
    } else if (mode === 'reply_all') {
      toRecipients = this.replyAllToRecipients()
      ccRecipients = this.replyAllCcRecipients()
      const mailbox = this.ticket()?.mailbox_email?.trim()?.toLowerCase()
      const cust = this.primaryCustomerEmail()?.toLowerCase()
      const rawBcc = [...(this.replyRecipients().bcc || []), ...this.customBccChips()]
      bccRecipients = Array.from(new Set(rawBcc.filter(e => {
        const norm = e.trim().toLowerCase()
        return norm && norm !== mailbox && norm !== cust
      })))
    } else if (mode === 'reply_selected') {
      toRecipients = this.selectedRecipients()
      ccRecipients = [...this.customCcChips()]
      bccRecipients = [...this.customBccChips()]
    } else if (mode === 'forward') {
      toRecipients = this.forwardToChips()
      ccRecipients = [...this.customCcChips()]
      bccRecipients = [...this.customBccChips()]
    }

    const payload: any = {
      ticketId: this.ticketId,
      sender: 'agent',
      type: 'reply',
      message: text,
      replyMode: mode,
      toRecipients,
      ccRecipients,
      bccRecipients,
      recipients: { to: toRecipients, cc: ccRecipients, bcc: bccRecipients },
      channel: replyChannel,
      relatedMessageId: this.relatedMessageId,
      agentId: this.auth.getAgentId(),
      attachments,
    }
    const pendingMessage: any = {
      id: -Date.now(), sender: 'agent', type: 'reply',
      message: text, isSending: true, sender_name: this.auth.getAgentName(),
      reply_mode: mode,
      to_recipients: toRecipients,
      cc_recipients: ccRecipients,
      bcc_recipients: bccRecipients,
      forward_to: mode === 'forward' ? toRecipients.join(', ') : null,
      channel: replyChannel,
      // Synthetic ids just so @for's track a.id has something to key on —
      // swapped for the real ticket_attachments rows once the server
      // broadcast for this message comes back.
      attachments: attachments.map((a, i) => ({ id: -(i + 1), file_name: a.fileName, content_type: a.contentType, size: a.size, storage_path: a.storagePath })),
    }
    this.dispatchAgentMessage(payload, pendingMessage)
    // Mirror any newly-added CC/BCC into ccParticipants() right away, so they
    // show up as selectable/known recipients in Reply All / Reply Selected
    // for the rest of this session even before the ticket is next reloaded
    // from the server (which is what actually persists them — see
    // TicketService.addMessage()'s upsertCcParticipants call).
    const primaryEmail = (this.ticket()?.customer_email ?? '').trim().toLowerCase()
    const newlyKnown = Array.from(new Set([...ccRecipients, ...bccRecipients].map(e => e.trim().toLowerCase()).filter(Boolean)))
      .filter(e => e !== primaryEmail)
    if (newlyKnown.length) {
      this.ccParticipants.update(list => {
        const existing = new Set(list.map(p => p.email.trim().toLowerCase()))
        const additions = newlyKnown.filter(e => !existing.has(e)).map(email => ({ email }))
        return additions.length ? [...list, ...additions] : list
      })
    }
    // Reply actually went out — the saved draft (if any) no longer applies.
    this.ticketDraftService.clear(this.ticketId)
    this.drawerAttachments.set([])
    this.closeDrawer()
    this.relatedMessageId = null
  }
  // ────────────────────────────────────────────────────────────────────────────

  // Guards against submitInternalNote() firing twice for one user action
  // (Enter key + a near-simultaneous button click, or a duplicate keydown) —
  // without this, two "Sending…" placeholders get pushed but only one note
  // actually reaches the server, so the other sits stuck on "Sending…"
  // forever (2 bubbles shown for 1 note sent).
  private isSendingInternalNote = false

  submitInternalNote() {
    if (this.isSendingInternalNote) return
    const text = this.internalNoteText.trim()
    if (!text) return
    this.isSendingInternalNote = true
    const payload = { ticketId: this.ticketId, sender: 'agent', type: 'internal_note', message: text }
    const pendingMessage: any = { id: -Date.now(), sender: 'agent', type: 'internal_note', message: text, isSending: true, sender_name: this.auth.getAgentName() }
    this.internalNoteText = ''
    this.dispatchAgentMessage(payload, pendingMessage)
    setTimeout(() => { this.isSendingInternalNote = false }, 300)
  }

closeTicket() {
  this.changeStatus('closed', this.sendClosureMessage())
}

  confirmCloseTicket() {
    this.changeStatus('closed', this.sendClosureMessage())
    this.showCloseConfirm.set(false)
  }

  cancelCloseTicket() {
    this.showCloseConfirm.set(false)
  }

  reopenTicket() { this.changeStatus('open') }

  messageAuthorName(m: TicketMessage): string {
    if (m.sender === 'system') return 'System'
    if (m.sender === 'agent') return m.sender_name || 'Agent'
    return m.sender_name || this.ticket()?.customer_name || 'Customer'
  }

  messageModeBadge(m: any): { label: string; color: string } | null {
    if (m.sender !== 'agent' || m.type === 'internal_note') return null
    const mode = m.reply_mode
    if (!mode || mode === 'reply') return null
    if (mode === 'reply_all') return { label: '↩ Reply All', color: 'bg-indigo-500/20 text-indigo-200' }
    if (mode === 'reply_selected') return { label: '↩ Reply Selected', color: 'bg-indigo-500/20 text-indigo-200' }
    if (mode === 'forward') return { label: '→ Forwarded', color: 'bg-amber-400/30 text-amber-100' }
    return null
  }

  messageForwardTo(m: any): string | null {
    return m.forward_to ?? null
  }

navigateToSettings() {
    this.router.navigate(['/settings/messaging'], { queryParams: { open: 'message_footer' } })
  }

  quickReplyTo(email: string, name?: string) {
    this.selectedRecipients.set([email])
    this.openDrawer('reply_selected')
    if (name) {
     this.setDrawerDraft(`Hi ${name},<br><br>`)
    }
  }

  isNonOriginator(m: TicketMessage): boolean {
    if (m.sender !== 'customer') return false
    const origEmail = this.ticket()?.customer_email?.toLowerCase()
    const senderEmail = m.sender_email?.toLowerCase()
    return !!(senderEmail && origEmail && senderEmail !== origEmail)
  }

  messageRecipientsText(m: TicketMessage): string | null {
    if (m.sender !== 'agent') return null
    const to = m.to_recipients || []
    const cc = m.cc_recipients || []
    const fwd = m.forward_to
    if (!to.length && !cc.length && !fwd) return null
    const parts = []
    if (to.length) parts.push(`To: ${to.join(', ')}`)
    if (cc.length) parts.push(`CC: ${cc.join(', ')}`)
    if (!to.length && !cc.length && fwd) parts.push(`To: ${fwd}`)
    return parts.join(' | ')
  }

  toggleEyePopover(msgId: number, event?: Event) {
    if (event) event.stopPropagation()
    this.activeEyeMsgId.update(curr => curr === msgId ? null : msgId)
  }

  onInternalNoteEnter(event: Event) {
    const ke = event as KeyboardEvent
    if (ke.shiftKey) return
    event.preventDefault()
    this.submitInternalNote()
  }

 @ViewChild('drawerEditable') drawerEditableRef?: ElementRef<HTMLDivElement>
private savedDrawerRange: Range | null = null

showLinkPopover = false
linkUrlDraft = ''
linkTextDraft = ''

/** Keeps drawerDraft (the actual HTML that gets sent) in sync with what's typed,
 *  and persists it as this ticket's saved draft (browser localStorage) so it
 *  survives closing the drawer, switching tickets, or reloading the page. */
onDrawerInput(event: Event) {
  this.drawerDraft = (event.target as HTMLDivElement).innerHTML
  this.saveCurrentDraft()
}

/** Sets drawerDraft AND pushes it into the live contenteditable DOM — needed
 *  anywhere drawerDraft is set programmatically (reset, prefill), since a
 *  contenteditable div isn't two-way bound the way a textarea's ngModel was.
 *
 *  The div only exists once drawerOpen() is true and Angular has rendered it
 *  — which happens *after* openDrawer() sets an initial draft (restoring a
 *  saved one). If drawerEditableRef isn't there yet, defer the DOM write to
 *  the next tick. That deferred write reads `this.drawerDraft` (not the
 *  `html` argument captured here) at fire time, so if another
 *  setDrawerDraft() call happens synchronously right after this one — e.g.
 *  quickReplyTo()'s "Hi {name}," greeting or confirmRelay()'s quote note,
 *  both called immediately after openDrawer() — the LAST call's text always
 *  wins in the DOM, regardless of the order the two deferred writes fire in. */
private setDrawerDraft(html: string) {
  this.drawerDraft = html
  const editable = this.drawerEditableRef?.nativeElement
  if (editable) {
    editable.innerHTML = html
  } else {
    setTimeout(() => {
      const el = this.drawerEditableRef?.nativeElement
      if (el) el.innerHTML = this.drawerDraft
    }, 0)
  }
}

openLinkPopover() {
  const editable = this.drawerEditableRef?.nativeElement
  editable?.focus()
  const sel = window.getSelection()
  this.savedDrawerRange = sel && sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null
  this.linkTextDraft = sel?.toString() || '' // pre-fill with any text the agent had selected
  this.linkUrlDraft = ''
  this.showLinkPopover = true
}

confirmInsertLink() {
  let url = this.linkUrlDraft.trim()
  if (!url) return
  if (!/^https?:\/\//i.test(url)) url = `https://${url}` // tolerate "www.google.com" without a protocol
  const label = this.linkTextDraft.trim() || url
  this.showLinkPopover = false

  const editable = this.drawerEditableRef?.nativeElement
  if (!editable) return
  editable.focus()
  const sel = window.getSelection()
  if (sel && this.savedDrawerRange) { sel.removeAllRanges(); sel.addRange(this.savedDrawerRange) }

document.execCommand('insertHTML', false, `<a href="${url}" target="_blank" rel="noopener noreferrer" style="color:#4f46e5 !important;text-decoration:underline !important;">${label}</a>&nbsp;`)
  this.drawerDraft = editable.innerHTML
  this.saveCurrentDraft()
}

cancelInsertLink() {
  this.showLinkPopover = false
}



  goBack() {
    if (this.embedded) { this.closeRequested.emit(); return }
    this.router.navigate(['/tickets'])
  }

  /** Deletes the ticket currently open in this view, then returns to the
   *  list (or closes the embedded panel) — mirrors ticket-list.ts's
   *  deleteTicket(), just without a row to remove from a table afterward. */
  async deleteTicketFromDetail(t: Ticket) {
    const ok = await this.dialog.confirm({
      title: 'Delete ticket',
      message: `Delete ticket ${t.ticket_uid}? This can't be undone from here.`,
      confirmLabel: 'Delete',
      variant: 'danger',
    })
    if (!ok) return
    this.ticketService.deleteTicket(t.id).subscribe(() => this.goBack())
  }

    ngOnDestroy() {
      this.layout.sidebarHidden.set(false)
    this.ticketSocket.leaveTicket?.(this.ticketId)   // add/confirm this method exists on the socket service
    this.messagesEffectRef.destroy()
    this.subs.unsubscribe()
  }



waMessages   = computed(() => this.messages().filter(m => this.messageChannel(m) === 'whatsapp'))
mailMessages = computed(() => this.messages().filter(m => this.messageChannel(m) === 'email'))





retryMessage(m: TicketMessage) {
  if (this.retryingMessageId() === m.id) return
  this.retryingMessageId.set(m.id)
  this.ticketService.retryMessage(m.id).subscribe({
    next: (r: any) => {
      this.messages.update(list => list.map(x => x.id === m.id ? { ...x, ...r.message } : x))
      this.retryingMessageId.set(null)
    },
    error: () => this.retryingMessageId.set(null),
  })
}


// ── Channel split (prefers explicit `channel`, falls back for legacy rows) ──
messageChannel(m: TicketMessage): 'whatsapp' | 'email' {
  if (m.channel) return m.channel
  if (m.sender === 'customer') return 'whatsapp'
  if (m.to_recipients?.length || m.cc_recipients?.length || m.graph_message_id) return 'email'
  return 'whatsapp'
}



// ── Arrow pairing: ONLY explicit relatedMessageId links draw an arrow.
//    A message gets related_message_id set exclusively via the relay modal
//    (openRelayModal → confirmRelay), so an arrow only ever appears when an
//    agent actually relayed one message into the other channel — never as
//    a guess based on ordering or timing. ──
flowLinks = computed<{ src: string; tgt: string; type: 'wa-email' | 'email-wa' }[]>(() => {
  const out: { src: string; tgt: string; type: 'wa-email' | 'email-wa' }[] = []
  const byId = new Map(this.messages().map(m => [m.id, m]))

  for (const m of this.messages()) {
    if (!m.related_message_id || !byId.has(m.related_message_id)) continue
    const related = byId.get(m.related_message_id)!
    const relCh = this.messageChannel(related)
    const ch = this.messageChannel(m)
    if (relCh === 'whatsapp' && ch === 'email') out.push({ src: `wa-${related.id}`, tgt: `mail-${m.id}`, type: 'wa-email' })
    if (relCh === 'email' && ch === 'whatsapp') out.push({ src: `mail-${related.id}`, tgt: `wa-${m.id}`, type: 'email-wa' })
  }
  return out
})

// ── Overlap resolution for the flow arrows ──────────────────────────────
// Two curves are sampled into short polylines and checked segment-by-segment
// for intersection. On a collision, the later curve's yShift grows (pushing
// its bezier control points further from the straight line between its
// endpoints) and every curve is re-sampled/re-checked. Bounded to a handful
// of passes — this only needs to separate a small number of on-screen links.
private resolveFlowArrowOverlaps(geoms: FlowArrowGeom[], maxPasses = 6): void {
  const step = 14 // px added to yShift per collision, away from the crossing curve

  for (let pass = 0; pass < maxPasses; pass++) {
    let sawCollision = false

    for (let i = 0; i < geoms.length; i++) {
      for (let j = i + 1; j < geoms.length; j++) {
        const a = geoms[i], b = geoms[j]
        // Links that legitimately share an endpoint already get their
        // vertical stacking offset from incomingMap/outgoingMap — that's
        // intentional adjacency, not an overlap to resolve here.
        const shareEndpoint =
          a.link.src === b.link.src || a.link.tgt === b.link.tgt ||
          a.link.src === b.link.tgt || a.link.tgt === b.link.src
        if (shareEndpoint) continue

        if (this.curvesIntersect(a, b)) {
          sawCollision = true
          // Push the curve with the smaller current magnitude out further;
          // ties go to the later link so earlier ones stay stable.
          const grow = Math.abs(a.yShift) <= Math.abs(b.yShift) ? a : b
          grow.yShift += grow.yShift < 0 ? -step : step
        }
      }
    }

    if (!sawCollision) break
  }
}

private curvesIntersect(a: FlowArrowGeom, b: FlowArrowGeom): boolean {
  const pa = this.sampleCubicBezier(a)
  const pb = this.sampleCubicBezier(b)
  for (let i = 0; i < pa.length - 1; i++) {
    for (let j = 0; j < pb.length - 1; j++) {
      if (this.segmentsIntersect(pa[i], pa[i + 1], pb[j], pb[j + 1])) return true
    }
  }
  return false
}

private sampleCubicBezier(g: FlowArrowGeom, steps = 14): { x: number; y: number }[] {
  const gap = Math.abs(g.sx - g.tx)
  const cp1x = g.sx + (g.isWaToMail ? -gap * 0.45 : gap * 0.45)
  const cp2x = g.tx + (g.isWaToMail ? gap * 0.45 : -gap * 0.45)
  const cp1y = g.sy + g.yShift
  const cp2y = g.ty + g.yShift

  const pts: { x: number; y: number }[] = []
  for (let i = 0; i <= steps; i++) {
    const t = i / steps
    const mt = 1 - t
    const x = mt * mt * mt * g.sx + 3 * mt * mt * t * cp1x + 3 * mt * t * t * cp2x + t * t * t * g.tx
    const y = mt * mt * mt * g.sy + 3 * mt * mt * t * cp1y + 3 * mt * t * t * cp2y + t * t * t * g.ty
    pts.push({ x, y })
  }
  return pts
}

private segmentsIntersect(
  p1: { x: number; y: number }, p2: { x: number; y: number },
  p3: { x: number; y: number }, p4: { x: number; y: number }
): boolean {
  const d1 = this.crossSign(p3, p4, p1)
  const d2 = this.crossSign(p3, p4, p2)
  const d3 = this.crossSign(p1, p2, p3)
  const d4 = this.crossSign(p1, p2, p4)
  return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))
}

private crossSign(a: { x: number; y: number }, b: { x: number; y: number }, c: { x: number; y: number }): number {
  return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
}

// ── Arrow renderer — ported directly from what's+gmail_support.html's
//    renderArrows(): same clipping-to-visible-scroll-area check, same
//    incoming/outgoing 18px stacking offsets, same anti-collision curvature.
//    Only the element-id prefixes and container refs changed (wa-/mail-
//    instead of wa-msg/email, real container ids instead of hardcoded ones).
renderFlowArrows() {
  const t = this.ticket()
  if (!t || t.source !== 'whatsapp') return
  const svg = document.getElementById(`flow-svg-${t.id}`) as unknown as SVGSVGElement | null
  const host = svg?.parentElement
  const mailEl = document.getElementById(`mail-thread-${t.id}`)
  const waEl = document.getElementById(`wa-thread-${t.id}`)
  if (!svg || !host || !mailEl || !waEl) return

  const hostRect = host.getBoundingClientRect()
  const mailRect = mailEl.getBoundingClientRect()
  const waRect = waEl.getBoundingClientRect()

  svg.innerHTML = `
    <defs>
      <marker id="fa-wa-mail" viewBox="0 -4 10 8" refX="9" refY="0" markerWidth="7" markerHeight="7" orient="auto">
        <path d="M0,-4L10,0L0,4Z" fill="#075e54" opacity=".85"/>
      </marker>
      <marker id="fa-mail-wa" viewBox="0 -4 10 8" refX="9" refY="0" markerWidth="7" markerHeight="7" orient="auto">
        <path d="M0,-4L10,0L0,4Z" fill="#6366f1" opacity=".85"/>
      </marker>
    </defs>`

  // Only drop links whose message elements no longer exist in the DOM.
  // Pane-boundary visibility is checked later (see "geoms" below), against
  // the arrow's actual endpoint — not the whole message bubble's box.
  const visible = this.flowLinks().filter(link =>
    !!document.getElementById(link.src) && !!document.getElementById(link.tgt)
  )

  const incomingMap: Record<string, number[]> = {}
  const outgoingMap: Record<string, number[]> = {}
  visible.forEach((link, idx) => {
    ;(outgoingMap[link.src] ??= []).push(idx)
    ;(incomingMap[link.tgt] ??= []).push(idx)
  })

// Phase 1 — compute each link's curve geometry (no DOM writes yet), so
// overlaps can be checked and resolved before anything is drawn.
const allGeoms: FlowArrowGeom[] = visible.map((link, idx) => {
const srcEl = document.getElementById(link.src)!
const tgtEl = document.getElementById(link.tgt)!

// Agent wrappers include the inline composer; measure only their bubble.
// Other message types already have their ID on the correct element.
const srcAnchor =
  srcEl.querySelector<HTMLElement>('[data-flow-anchor]') ?? srcEl

const tgtAnchor =
  tgtEl.querySelector<HTMLElement>('[data-flow-anchor]') ?? tgtEl

const sr = srcAnchor.getBoundingClientRect()
const tr = tgtAnchor.getBoundingClientRect()
  const isWaToMail = link.type === 'wa-email'

  // Pairs that chain into each other (this link's target is another link's
  // source, or vice versa) get more clearance so their curves don't run
  // through the same space.
  const chained = visible.some(l => l !== link && (l.tgt === link.src || l.src === link.tgt))
  const curveMagnitude = chained ? 44 : 28

  let sx: number, sy: number, tx: number, ty: number
  if (isWaToMail) {
    const tOffset = incomingMap[link.tgt].indexOf(idx) * 18
    sx = sr.left - hostRect.left
    sy = sr.bottom - hostRect.top - Math.min(sr.height / 2, 16)
    tx = tr.right - hostRect.left
    ty = tr.top - hostRect.top + 22 + tOffset
  } else {
    const sOffset = outgoingMap[link.src].indexOf(idx) * 18
    sx = sr.right - hostRect.left
    // Stacking multiple arrows from the same source by a fixed 18px step
    // works for tall bubbles, but a short one (e.g. one-word "Hello", only
    // ~40px tall) can't absorb more than one or two steps before the
    // anchor is pushed straight past its own bottom edge and into the
    // NEXT message's row — which is exactly what you saw: the tail
    // appearing to launch from a different message entirely. Clamp the
    // final point so it can never leave this bubble's own vertical span,
    // regardless of how many arrows stack from it.
    const sTopBound = sr.top - hostRect.top + 6
    const sBottomBound = sr.bottom - hostRect.top - 6
    const sRawY = sr.bottom - hostRect.top - Math.min(sr.height / 2, 16) + sOffset
    sy = Math.min(Math.max(sRawY, sTopBound), sBottomBound)
    tx = tr.left - hostRect.left
    ty = tr.top - hostRect.top + Math.min(tr.height / 2, 16)
  }

  return { link, isWaToMail, sx, sy, tx, ty, yShift: isWaToMail ? -curveMagnitude : curveMagnitude }
})

// Phase 1.5 — keep an arrow only while BOTH its tail (sx,sy) and its tip
// (tx,ty) sit inside their own pane's visible viewport. This checks the
// exact point the curve touches, not whether the whole message box is
// on-screen, so an arrow stays drawn until that precise spot scrolls out.
const geoms: FlowArrowGeom[] = allGeoms.filter(g => {
  const srcViewportY = g.sy + hostRect.top
  const tgtViewportY = g.ty + hostRect.top
  const srcPaneRect = g.link.src.startsWith('wa-') ? waRect : mailRect
  const tgtPaneRect = g.link.tgt.startsWith('wa-') ? waRect : mailRect
  const inSrcPane = srcViewportY >= srcPaneRect.top - 2 && srcViewportY <= srcPaneRect.bottom + 2
  const inTgtPane = tgtViewportY >= tgtPaneRect.top - 2 && tgtViewportY <= tgtPaneRect.bottom + 2
  return inSrcPane && inTgtPane
})

// Phase 2 — collision avoidance: if two curves visually cross, push the
// later one further out (bigger yShift) and recheck, so arrows route
// around each other instead of overlapping. Bounded iteration count keeps
// this cheap even with several links on screen at once.
this.resolveFlowArrowOverlaps(geoms)

// Phase 3 — draw the now non-overlapping curves.
geoms.forEach(g => {
  const gap = Math.abs(g.sx - g.tx)
  const cp1x = g.sx + (g.isWaToMail ? -gap * 0.45 : gap * 0.45)
  const cp2x = g.tx + (g.isWaToMail ? gap * 0.45 : -gap * 0.45)
  const d = `M${g.sx},${g.sy} C${cp1x},${g.sy + g.yShift} ${cp2x},${g.ty + g.yShift} ${g.tx},${g.ty}`
  const color = g.isWaToMail ? '#075e54' : '#6366f1'

  const glow = document.createElementNS('http://www.w3.org/2000/svg', 'path')
  glow.setAttribute('d', d); glow.setAttribute('fill', 'none')
  glow.setAttribute('stroke', color); glow.setAttribute('stroke-width', '7')
  glow.setAttribute('stroke-opacity', '.08'); glow.setAttribute('stroke-linecap', 'round')
  svg.appendChild(glow)

  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path')
  path.setAttribute('d', d); path.setAttribute('fill', 'none')
  path.setAttribute('stroke', color); path.setAttribute('stroke-width', '1.9')
  path.setAttribute('stroke-opacity', '.85'); path.setAttribute('stroke-linecap', 'round')
  if (!g.isWaToMail) path.setAttribute('stroke-dasharray', '5 4')
  svg.appendChild(path)

  if (g.isWaToMail) {
    path.setAttribute('marker-end', 'url(#fa-wa-mail)')
  } else {
    // stroke-dasharray has no idea where the path ends — whether the very
    // tail lands on a "dash" or a "gap" of the 5-4 pattern depends purely
    // on the curve's total length, so the arrow can visually stop a few px
    // short of (g.tx, g.ty) even though that point itself is correct. Cap
    // the last 14px with a short SOLID segment carrying the arrowhead, so
    // the tip always reaches — and visibly touches — the target bubble
    // regardless of curve length.
    const totalLen = path.getTotalLength()
    const capLen = Math.min(14, totalLen)
    const capStart = path.getPointAtLength(totalLen - capLen)
    const cap = document.createElementNS('http://www.w3.org/2000/svg', 'path')
    cap.setAttribute('d', `M${capStart.x},${capStart.y} L${g.tx},${g.ty}`)
    cap.setAttribute('fill', 'none')
    cap.setAttribute('stroke', color); cap.setAttribute('stroke-width', '1.9')
    cap.setAttribute('stroke-opacity', '.85'); cap.setAttribute('stroke-linecap', 'round')
    cap.setAttribute('marker-end', 'url(#fa-mail-wa)')
    svg.appendChild(cap)
  }
})

  // NEW: pending "about to connect" preview line, while the inline mail
  // composer is open but before anything has actually been sent.
  const pending: { src: string; tgt: string } | null = this.pendingMailLink()
  if (pending) {
    const s = document.getElementById(pending.src)
    const t = document.getElementById(pending.tgt)
    if (s && t) {
    const sr = s.getBoundingClientRect(), tr = t.getBoundingClientRect()
const sx = sr.left - hostRect.left, sy = sr.bottom - hostRect.top - Math.min(sr.height / 2, 16)
const tx = tr.right - hostRect.left, ty = tr.bottom - hostRect.top - 16
const gap = Math.abs(sx - tx)
const d = `M${sx},${sy} C${sx - gap * 0.45},${sy + 28} ${tx + gap * 0.45},${ty + 28} ${tx},${ty}`
      const p = document.createElementNS('http://www.w3.org/2000/svg', 'path')
      p.setAttribute('d', d); p.setAttribute('fill', 'none')
      p.setAttribute('stroke', '#94a3b8'); p.setAttribute('stroke-width', '1.6')
      p.setAttribute('stroke-dasharray', '3 4'); p.setAttribute('stroke-opacity', '.6')
      svg.appendChild(p)
    }
  }

  // Re-observe every element the arrows currently touch, so any late reflow
  // (async image load inside the email HTML, expand/collapse, etc.) forces
  // a redraw instead of leaving the arrow pointing at a stale position.
  const toObserve = new Set<Element>([mailEl, waEl])
  visible.forEach(link => {
    const s = document.getElementById(link.src); if (s) toObserve.add(s)
    const t = document.getElementById(link.tgt); if (t) toObserve.add(t)
  })
  this.flowObservedEls.forEach(el => { if (!toObserve.has(el)) this.flowResizeObserver.unobserve(el) })
  toObserve.forEach(el => { if (!this.flowObservedEls.has(el)) this.flowResizeObserver.observe(el) })
  this.flowObservedEls = toObserve
}

// Hover icon on any message → opens the relay modal for confirmation before
// anything actually happens on the other channel.
openRelayModal(m: TicketMessage, targetChannel: 'wa' | 'mail') {
    if (m.isSending) return 
  this.relayModalSourceMsg.set(m)
  this.relayModalTargetChannel.set(targetChannel)
  this.relayModalNote = ''
  this.relayModalOpen.set(true)
}

closeRelayModal() {
  this.relayModalOpen.set(false)
  this.relayModalSourceMsg.set(null)
  this.relayModalTargetChannel.set(null)
  this.relayModalNote = ''
}


confirmRelay() {
  const m = this.relayModalSourceMsg()
  const target = this.relayModalTargetChannel()
  if (!m || !target) return
  const note = this.relayModalNote.trim()

  // Cross-channel referencing (quoting the original message the agent is
  // relaying from) is now built server-side in TicketService.addMessage from
  // relatedMessageId — see applyCrossChannelReference in Helper. We only
  // need to carry the agent's own note/typed reply here; baking a
  // quote/"Referring to" prefix in on top of that would double it up.
  if (target === 'mail') {
    this.openDrawer('reply')
    this.relatedMessageId = m.id
    this.setDrawerDraft(note ? `${this.escapeHtml(note)}<br><br>` : '')
  } else {
    this.relatedMessageId = m.id
    if (this.messageChannel(m) === 'email') {
      // No wamid exists for a mail-sourced message, so WhatsApp can't natively
      // quote it — the server-side reference (a "Re your email: ..." line)
      // covers that; the composer just needs the agent's note.
      this.waQuote.set(null)
      this.waDraft = note
    } else {
      // Genuine WhatsApp-origin message — safe to use native quoting.
      this.waQuote.set({ title: this.messageAuthorName(m), text: this.plainPreview(m.message) })
      this.waDraft = note
    }
    setTimeout(() => this.waInputRef?.nativeElement.focus(), 50)
    this.scrollThreadToBottom('wa')
  }

  this.closeRelayModal()
}

quoteWaMessage(m: TicketMessage) {
  if (m.isSending) return
  this.relatedMessageId = m.id
  this.waQuote.set({ title: this.messageAuthorName(m), text: this.plainPreview(m.message) })
  this.waDraft = ''
  setTimeout(() => { this.waInputRef?.nativeElement.focus(); this.scrollThreadToBottom('wa') }, 50)
}
quotedFor(m: TicketMessage): { title: string; text: string } | null {
  if (!m.related_message_id) return null
  const src = this.messages().find(x => x.id === m.related_message_id)
  if (!src) return null
  if (this.messageChannel(src) !== 'whatsapp') return null   // only native-quote WA-origin sources
  return {
    title: src.sender === 'customer' ? (src.sender_name || 'Customer') : this.messageAuthorName(src),
    text: this.plainPreview(src.message, 90)
  }
}

sendWaMessage() {
  const text = this.waDraft.trim()
  const attachments = this.attachmentsForSend('wa')
  if ((!text && !attachments.length) || !this.ticketId || this.attachmentsUploading('wa')) return
  const payload: any = { ticketId: this.ticketId, sender: 'agent', type: 'reply', message: text, channel: 'whatsapp', relatedMessageId: this.relatedMessageId, attachments }
  const pending: any = {
    id: -Date.now(), sender: 'agent', type: 'reply', message: text, isSending: true, sender_name: this.auth.getAgentName(), channel: 'whatsapp',
    attachments: attachments.map((a, i) => ({ id: -(i + 1), file_name: a.fileName, content_type: a.contentType, size: a.size, storage_path: a.storagePath })),
  }
  this.dispatchAgentMessage(payload, pending)
  this.waDraft = ''; this.waQuote.set(null); this.relatedMessageId = null
  this.waAttachments.set([])
}

private escapeHtml(s: string) { const d = document.createElement('div'); d.innerText = s; return d.innerHTML }

plainPreview(html: string, maxLen = 140): string {
  const text = (html || '')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  return text.length > maxLen ? text.slice(0, maxLen) + '…' : text
}



inlineReplyFor = signal<number | null>(null)
inlineReplyText = ''

openInlineWaReply(m: TicketMessage) {
  this.inlineReplyFor.set(this.inlineReplyFor() === m.id ? null : m.id)
  this.inlineReplyText = ''
  // FIX: scrolling the WA pane changes every message bubble's on-screen
  // (viewport-relative) position, but scrolling alone never fires the
  // flowResizeObserver (element sizes don't change, only scrollTop) — so
  // any existing arrow into/out of this pane kept the stale pre-scroll
  // coordinates it was drawn with, making it appear to drift onto whatever
  // now sits at that same screen position. Re-render AFTER the scroll so
  // the arrow is computed from final, post-scroll positions — mirrors
  // openInlineMailReply(), which already does this for the mail pane.
  setTimeout(() => {
    this.scrollThreadToBottom('wa')
    this.renderFlowArrows()
  }, 60)
}

openInlineMailReply(m: TicketMessage) {
    if (m.isSending) return 
  this.inlineMailReplyFor.set(this.inlineMailReplyFor() === m.id ? null : m.id)
  this.inlineMailReplyText = ''
  if (!this.agentSignatureLoaded) this.loadAgentSignature()
 setTimeout(() => {
  this.scrollThreadToBottom('mail')
  this.renderFlowArrows()
}, 60)
}

// Adjust the endpoint/agent-id source to whatever your AuthService actually exposes —
// I only know `this.auth.getAgentName()` from the existing code, not the id getter or
// which HttpClient/service you use for plain REST calls, so wire this call in to match.
loadAgentSignature() {
  this.agentSignatureLoaded = true
  const agentId = this.auth.getAgentId?.()
  if (!agentId) return
  this.agentService.getSignature(agentId).subscribe(res => {
    this.agentSignatureHtml = res?.signatureHtml ?? null
  })
}

sendInlineMailReply(m: TicketMessage) {
  const note = this.inlineMailReplyText.trim()
  if (!note || !this.ticketId) return
  // No quote and no footer baked in here — TicketService.addMessage now builds
  // the cross-channel reference (via relatedMessageId) and
  // EmailToTicketService.sendAgentReplyByEmail appends the agent's footer,
  // both server-side, and both land in the stored + outbound message the same
  // way. Baking either one in here too would just double it up.
  const html = `<p style="margin:0;">${this.escapeHtml(note).replace(/\n/g, '<br>')}</p>`
  const payload: any = { ticketId: this.ticketId, sender: 'agent', type: 'reply', message: html, channel: 'email', relatedMessageId: m.id, agentId: this.auth.getAgentId?.() }
  const pending: any = { id: -Date.now(), sender: 'agent', type: 'reply', message: html, isSending: true, sender_name: this.auth.getAgentName(), channel: 'email', related_message_id: m.id }
  this.dispatchAgentMessage(payload, pending)
  this.inlineMailReplyText = ''
  this.inlineMailReplyFor.set(null)
  setTimeout(() => this.renderFlowArrows(), 60)
}

sendInlineWaReply(m: TicketMessage) {
  const text = this.inlineReplyText.trim()
  if (!text || !this.ticketId) return
  const payload: any = { ticketId: this.ticketId, sender: 'agent', type: 'reply', message: text, channel: 'whatsapp', relatedMessageId: m.id }
  const pending: any = { id: -Date.now(), sender: 'agent', type: 'reply', message: text, isSending: true, sender_name: this.auth.getAgentName(), channel: 'whatsapp', related_message_id: m.id }
  this.dispatchAgentMessage(payload, pending)
  this.inlineReplyText = ''
  this.inlineReplyFor.set(null)
  setTimeout(() => this.renderFlowArrows(), 60)
}

autoGrow(ev: Event) {
  const el = ev.target as HTMLTextAreaElement
  el.style.height = 'auto'
  el.style.height = Math.min(el.scrollHeight, 128) + 'px'
}

pendingMailLink = computed(() => {
  const waId = this.inlineMailReplyFor()
  return waId ? { src: `wa-${waId}`, tgt: 'mail-pending-composer' } : null
})

private scrollThreadToBottom(prefix: 'wa' | 'mail') {
  const t = this.ticket()
  if (!t) return
  const el = document.getElementById(`${prefix}-thread-${t.id}`)
  if (el) el.scrollTop = el.scrollHeight
}

// How close to the bottom (in px) still counts as "the agent is following
// the live thread" rather than "deliberately scrolled up to read history".
// Shared with keepPinnedToBottom's own near-bottom check below.
private static readonly NEAR_BOTTOM_PX = 150

/** Same as scrollThreadToBottom, but a no-op if the pane isn't already near its bottom — see the effect() above for why this exists. */
private scrollThreadToBottomIfNearBottom(prefix: 'wa' | 'mail') {
  const t = this.ticket()
  if (!t) return
  const el = document.getElementById(`${prefix}-thread-${t.id}`)
  if (!el) return
  const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < TicketDetailComponent.NEAR_BOTTOM_PX
  if (isNearBottom) el.scrollTop = el.scrollHeight
}

// ── Scroll-to-bottom on ticket open ─────────────────────────────────────────
// Previous attempts used requestAnimationFrame/setTimeout to guess when the
// thread panes existed in the DOM, which was unreliable — with OnPush +
// signals, a signal write doesn't synchronously patch the DOM, so those
// guesses could run before Angular had actually rendered past `loading()`.
// ngAfterViewChecked() is the correct hook here: Angular guarantees it only
// runs AFTER a change-detection pass has patched the view, so the very
// first time it fires with the pane in the DOM, that pane's text content is
// guaranteed to be fully laid out already.
private pendingScrollTicketId: number | null = null

ngAfterViewChecked() {
  const id = this.pendingScrollTicketId
  if (id === null) return
  const mailEl = document.getElementById(`mail-thread-${id}`)
  const waEl = document.getElementById(`wa-thread-${id}`)
  if (!mailEl && !waEl) return   // view hasn't rendered past `loading()` yet — keep waiting

  if (mailEl) { mailEl.scrollTop = mailEl.scrollHeight; this.keepPinnedToBottom(mailEl, id) }
  if (waEl) { waEl.scrollTop = waEl.scrollHeight; this.keepPinnedToBottom(waEl, id) }
  this.pendingScrollTicketId = null
}

/** Attachments/images inside the thread can still grow the pane's height
 *  after this first scroll (their intrinsic size isn't known until they
 *  finish loading), which would otherwise leave the view short of the true
 *  bottom. Re-pin scrollTop each time a media element inside the pane
 *  finishes loading, for a bounded window so it doesn't fight an agent who
 *  deliberately scrolls up afterward. */
private keepPinnedToBottom(el: HTMLElement, ticketId: number) {
  // How close to the bottom counts as "still there" — a media element
  // loading (or a DOM mutation) shouldn't yank the pane back down if the
  // agent has deliberately scrolled up to read earlier messages. Without
  // this check, rePin() fired unconditionally on every image/video load
  // and every DOM mutation for the 2s window below, which is exactly what
  // made the pane "jump to the bottom" whenever someone scrolled up
  // quickly right after opening a ticket while attachments were still
  // loading.
  const isNearBottom = () => el.scrollHeight - el.scrollTop - el.clientHeight < TicketDetailComponent.NEAR_BOTTOM_PX
  const rePin = () => {
    if (this.ticketId !== ticketId) return
    if (!isNearBottom()) return
    el.scrollTop = el.scrollHeight
  }
  const media = el.querySelectorAll('img, video')
  media.forEach(m => {
    m.addEventListener('load', rePin, { once: true })
    m.addEventListener('loadedmetadata', rePin, { once: true })
  })
  // Also catch new media nodes arriving shortly after (e.g. expanding a
  // collapsed auto-email card) for a short window post-open.
  const mo = new MutationObserver(() => {
    if (this.ticketId !== ticketId) { mo.disconnect(); return }
    rePin()
    el.querySelectorAll('img, video').forEach(m => {
      m.addEventListener('load', rePin, { once: true })
      m.addEventListener('loadedmetadata', rePin, { once: true })
    })
  })
  mo.observe(el, { childList: true, subtree: true })
  setTimeout(() => mo.disconnect(), 2000)
}

@Input() ticketSourceHint?: string

loadingIsWhatsapp = computed(() =>
  this.ticketSourceHint === 'whatsapp' ||
  this.compactTickets().find(ct => ct.id === this.ticketId)?.source === 'whatsapp'
)



}