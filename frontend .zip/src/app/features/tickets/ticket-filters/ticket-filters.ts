import { Component } from '@angular/core';

@Component({
  selector: 'app-ticket-filters',
  imports: [],
  templateUrl: './ticket-filters.html',
  styleUrl: './ticket-filters.css',
})
export class TicketFilters {}
