import { Component, effect, inject, signal, computed, OnDestroy, ElementRef, ViewChild, HostListener } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { ActivatedRoute, Router, RouterLink } from '@angular/router'
import { TicketService } from '../../../core/services/ticket.service'
import { Ticket, TicketMacro } from '../../../core/models/ticket.model'
import { TicketSocketService } from '../../../core/services/ticket-socket.services'
import { CreateTicketModal } from "../create-ticket-modal/create-ticket-modal";
import { AgentPickerComponent } from '../../settings/agent-picker/agent-picker'
import { TicketDetailComponent } from "../ticket-detail/ticket-detail";
import { AuthService } from '../../../service/auth.service'
import { LayoutService } from '../../../core/services/layout.service'
import { TicketDraftService } from '../../../core/services/ticket-draft.service'
import { DialogService } from '../../../core/services/Dialog-services/dialog.services'
import { TicketResyncService } from '../../../core/services/ticket-resync.service'

type StatusFilter = '' | 'open' | 'on_hold' | 'escalated' | 'closed' | 'reopened' | 'rated'

@Component({
  selector: 'app-ticket-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, CreateTicketModal, AgentPickerComponent, TicketDetailComponent],
  templateUrl: './ticket-list.html',
  styleUrl: './ticket-list.css',
})
export class TicketListComponent implements OnDestroy {
  private ticketService = inject(TicketService)
  private ticketSocket  = inject(TicketSocketService)
  private router        = inject(Router)
  private route         = inject(ActivatedRoute)
  auth = inject(AuthService)
  private layout        = inject(LayoutService)
  draftService = inject(TicketDraftService)
  private dialog = inject(DialogService)
  resyncService = inject(TicketResyncService)

  /** ID of the ticket currently being re-synced (null = none) */
  resyncingId = signal<number | null>(null)

  tickets = signal<Ticket[]>([])
  loading = signal(true)
  loadingMore = signal(false)
  hasMore = signal(true)
  private pageOffset = 0
  private readonly PAGE_SIZE_INITIAL = 30
  private readonly PAGE_SIZE_MORE = 20
  search = ''
// Default to the "Open" tab so it's already selected/highlighted (and its
// filtered results are what load) the moment the list mounts, instead of
// starting on the unfiltered/no-tab-highlighted "All" state.
  statusFilter: StatusFilter = 'open'
  priorityFilter = signal<string>('')
  resolvedTodayFilter = signal<boolean>(false)
  unassignedFilter = signal<boolean>(false)
  showDeleted = signal(false)
  tabCounts = signal<Record<string, number>>({})

  // ── Ratings tab: star-value dropdown ────────────────────────────────
  // Clicking the "Ratings" tab no longer immediately loads every rated
  // ticket — it opens a small dropdown to pick 1–5 stars (or "All
  // ratings") first, and only THEN fetches, filtered to that star value.
  // Multi-select: an agent can pick several star values at once (e.g. 4★
  // and 5★ together) instead of being limited to one rating per query.
  ratingFilter = signal<number[]>([])
  showRatingPicker = signal(false)
  readonly ratingOptions = [5, 4, 3, 2, 1]
  @ViewChild('ratingPickerRef') ratingPickerRef?: ElementRef<HTMLElement>

  toggleRatingPicker(ev: Event) {
    ev.stopPropagation()
    this.showRatingPicker.set(!this.showRatingPicker())
  }

  // Toggles a single star value in/out of the selection (checkbox-style,
  // like toggleAssigneeInFilter below) instead of replacing it — the
  // dropdown stays open so several values can be picked in one go.
  toggleRatingInFilter(stars: number) {
    const cur = new Set(this.ratingFilter())
    cur.has(stars) ? cur.delete(stars) : cur.add(stars)
    const next = Array.from(cur)
    this.ratingFilter.set(next)
    this.showDeleted.set(false)
    this.statusFilter = 'rated'
    this.router.navigate([], { relativeTo: this.route, queryParams: { status: 'rated' }, queryParamsHandling: 'merge' })
    this.fetch()
  }

  ratingFilterLabel() {
    const rs = this.ratingFilter()
    if (!rs.length) return ''
    if (rs.length === 1) return `${rs[0]}★`
    return `${rs.length} selected`
  }

  // ── Organization-wise / contact-wise filters ────────────────────────
  // Both support selecting several orgs/contacts at once — same
  // checkbox-dropdown pattern as the "Assigned To" filter above.
  orgOptions = signal<{ orgId: number; orgName: string }[]>([])
  contactOptions = signal<{ id: number; name: string; email?: string; phone?: string }[]>([])
  orgFilter = signal<{ orgId: number; orgName: string }[]>([])
  contactFilterSel = signal<{ id: number; name: string; email?: string; phone?: string }[]>([])
  showOrgFilter = signal(false)
  showContactFilter = signal(false)
  @ViewChild('orgFilterRef') orgFilterRef?: ElementRef<HTMLElement>
  @ViewChild('contactFilterRef') contactFilterRef?: ElementRef<HTMLElement>

  // Org dropdown: server-side search (debounced) instead of a one-time
  // fixed-size fetch. The old version only ever pulled the first 200 orgs
  // (alphabetically) and cached that on first open — any org with tickets
  // past that cutoff, or one an agent wanted to find by name, was
  // effectively invisible. Now every open (and every keystroke in the
  // search box) re-queries the backend for orgs that actually have at
  // least one ticket (open, closed, or deleted), scoped to the typed term.
  orgFilterSearch = ''
  orgOptionsLoading = signal(false)
  private orgSearchTimer: any

  toggleOrgFilterMenu(ev: Event) {
    ev.stopPropagation()
    const opening = !this.showOrgFilter()
    this.showOrgFilter.set(opening)
    if (opening) this.fetchOrgOptions()
  }

  onOrgFilterSearch(e: Event) {
    this.orgFilterSearch = (e.target as HTMLInputElement).value
    clearTimeout(this.orgSearchTimer)
    this.orgSearchTimer = setTimeout(() => this.fetchOrgOptions(), 300)
  }

  private fetchOrgOptions() {
    this.orgOptionsLoading.set(true)
    // Pulls straight from tickets.sender_org_name (see
    // TicketService.getTicketOrganizations on the backend) instead of the
    // legacy Organization table — guarantees every org that actually has a
    // ticket on file (open, closed, or deleted) shows up here, with no
    // join/sync gap. The dedicated Organizations tab is unaffected — it
    // still calls getOrganizations() against the Organization table.
    this.ticketService.getTicketOrganizations(this.orgFilterSearch).subscribe({
      next: (r: any) => {
        this.orgOptions.set(Array.isArray(r) ? r : (r?.data ?? []))
        this.orgOptionsLoading.set(false)
      },
      error: () => {
        this.orgOptions.set([])
        this.orgOptionsLoading.set(false)
      },
    })
  }

  toggleContactFilterMenu(ev: Event) {
    ev.stopPropagation()
    const opening = !this.showContactFilter()
    this.showContactFilter.set(opening)
    if (opening) this.fetchContactOptions()
  }

  // Contact dropdown: server-side search (debounced), same pattern as the
  // Organization dropdown above — re-queries on open and on every keystroke,
  // and sorts the results alphabetically by name client-side so ordering is
  // guaranteed regardless of what the backend returns.
  contactFilterSearch = ''
  contactOptionsLoading = signal(false)
  private contactSearchTimer: any

  onContactFilterSearch(e: Event) {
    this.contactFilterSearch = (e.target as HTMLInputElement).value
    clearTimeout(this.contactSearchTimer)
    this.contactSearchTimer = setTimeout(() => this.fetchContactOptions(), 300)
  }

  private fetchContactOptions() {
    this.contactOptionsLoading.set(true)
    this.ticketService.getContacts(0, 200, this.contactFilterSearch).subscribe({
      next: (r: any) => {
        const list = Array.isArray(r) ? r : (r?.data ?? [])
        list.sort((a: any, b: any) =>
          (a.name || '').localeCompare(b.name || '', undefined, { sensitivity: 'base' })
        )
        this.contactOptions.set(list)
        this.contactOptionsLoading.set(false)
      },
      error: () => {
        this.contactOptions.set([])
        this.contactOptionsLoading.set(false)
      },
    })
  }

  toggleOrgInFilter(org: { orgId: number; orgName: string }) {
    const cur = this.orgFilter()
    const exists = cur.some(o => o.orgId === org.orgId)
    this.orgFilter.set(exists ? cur.filter(o => o.orgId !== org.orgId) : [...cur, org])
    this.fetch()
  }

  toggleContactInFilter(contact: { id: number; name: string; email?: string; phone?: string }) {
    const cur = this.contactFilterSel()
    const exists = cur.some(c => c.id === contact.id)
    this.contactFilterSel.set(exists ? cur.filter(c => c.id !== contact.id) : [...cur, contact])
    this.fetch()
  }

  orgFilterLabel() {
    const os = this.orgFilter()
    if (!os.length) return 'Organization'
    if (os.length === 1) return os[0].orgName
    return `${os.length} orgs selected`
  }

  contactFilterLabel() {
    const cs = this.contactFilterSel()
    if (!cs.length) return 'Contact'
    if (cs.length === 1) return cs[0].name
    return `${cs.length} contacts selected`
  }

  // ── Sort control ─────────────────────────────────────────────────────
  // Combined "field:direction" value so a single <select> covers every
  // sortable column in both directions.
  readonly sortOptions: { value: string; label: string }[] = [
    { value: 'last_message_at:desc', label: 'Newest activity' },
    { value: 'last_message_at:asc',  label: 'Oldest activity' },
    { value: 'created_at:desc',      label: 'Newest created' },
    { value: 'created_at:asc',       label: 'Oldest created' },
    { value: 'priority:desc',        label: 'Priority: High → Low' },
    { value: 'priority:asc',         label: 'Priority: Low → High' },
    { value: 'status:asc',           label: 'Status (A → Z)' },
    { value: 'customer_name:asc',    label: 'Customer name (A → Z)' },
    { value: 'customer_name:desc',   label: 'Customer name (Z → A)' },
    { value: 'ticket_uid:asc',       label: 'Ticket ID (A → Z)' },
    { value: 'ticket_uid:desc',      label: 'Ticket ID (Z → A)' },
    { value: 'subject:asc',          label: 'Subject (A → Z)' },
    { value: 'rating:desc',          label: 'Rating: High → Low' },
    { value: 'rating:asc',           label: 'Rating: Low → High' },
  ]
  sortValue = signal<string>('last_message_at:desc')

  onSortChange(value: string) {
    this.sortValue.set(value)
    this.fetch()
  }

  private get sortByParam(): string { return this.sortValue().split(':')[0] }
  private get sortOrderParam(): 'asc' | 'desc' { return this.sortValue().split(':')[1] === 'asc' ? 'asc' : 'desc' }

  // ── Admin-only "Assigned To" multi-select filter ────────────────────
  // Only rendered in the template when auth.isAdmin() — but this state
  // just sits unused (empty array = no filter applied) for non-admins,
  // so there's no need to gate it here too.
  private static readonly ASSIGNEE_FILTER_STORAGE_KEY = 'ticketList.assignedToFilter'
  assignedToFilter = signal<number[]>(this.loadSavedAssigneeFilter())
  showAssigneeFilter = signal(false)
  // Wraps the button + dropdown in the template — used by the
  // document-click listener below to detect "clicked outside" vs.
  // "clicked inside" (which should never close the menu, including
  // clicking the same toggle button that just opened it).
  @ViewChild('assigneeFilterRef') assigneeFilterRef?: ElementRef<HTMLElement>
  // Same pattern for the bulk-action-bar "Assign To" dropdown below.
  @ViewChild('bulkAssignRef') bulkAssignRef?: ElementRef<HTMLElement>

  private loadSavedAssigneeFilter(): number[] {
    try {
      const raw = localStorage.getItem(TicketListComponent.ASSIGNEE_FILTER_STORAGE_KEY)
      if (!raw) return []
      const parsed = JSON.parse(raw)
      return Array.isArray(parsed) ? parsed.filter((v) => Number.isFinite(v)) : []
    } catch {
      return []
    }
  }

  private saveAssigneeFilter(ids: number[]) {
    try {
      localStorage.setItem(TicketListComponent.ASSIGNEE_FILTER_STORAGE_KEY, JSON.stringify(ids))
    } catch {
      // Storage full/unavailable (e.g. private browsing) — filter still
      // works for the current session, it just won't persist. Not worth
      // surfacing to the admin.
    }
  }

  toggleAssigneeFilterMenu() { this.showAssigneeFilter.set(!this.showAssigneeFilter()) }

  // Closes the "Assigned To" dropdown the moment the admin clicks anywhere
  // outside it — including after selecting several agents in a row, since
  // each checkbox toggle re-runs this without closing the menu (the click
  // target is still inside assigneeFilterRef). Same handler also closes the
  // bulk-bar "Assign To" dropdown when a click lands outside bulkAssignRef.
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as Node
    if (this.showAssigneeFilter() && this.assigneeFilterRef && !this.assigneeFilterRef.nativeElement.contains(target)) {
      this.showAssigneeFilter.set(false)
    }
    if (this.showBulkAssign() && this.bulkAssignRef && !this.bulkAssignRef.nativeElement.contains(target)) {
      this.showBulkAssign.set(false)
    }
    if (this.showRatingPicker() && this.ratingPickerRef && !this.ratingPickerRef.nativeElement.contains(target)) {
      this.showRatingPicker.set(false)
    }
    if (this.showOrgFilter() && this.orgFilterRef && !this.orgFilterRef.nativeElement.contains(target)) {
      this.showOrgFilter.set(false)
    }
    if (this.showContactFilter() && this.contactFilterRef && !this.contactFilterRef.nativeElement.contains(target)) {
      this.showContactFilter.set(false)
    }
  }

  toggleAssigneeInFilter(agentId: number) {
    const cur = new Set(this.assignedToFilter())
    cur.has(agentId) ? cur.delete(agentId) : cur.add(agentId)
    const next = Array.from(cur)
    this.assignedToFilter.set(next)
    this.saveAssigneeFilter(next)
    this.fetch()
  }

  clearAssigneeFilter(ev?: Event) {
    ev?.stopPropagation()
    this.assignedToFilter.set([])
    this.saveAssigneeFilter([])
    this.fetch()
  }

  assigneeFilterLabel() {
    const ids = this.assignedToFilter()
    if (!ids.length) return 'Assigned To'
    if (ids.length === 1) return this.agentsList().find(a => a.id === ids[0])?.name ?? '1 selected'
    return `${ids.length} selected`
  }

  quickViewTicketId = signal<number | null>(null)

quickViewTicketSource = signal<string | null>(null)

openQuickView(t: Ticket, ev: Event) {
  ev.stopPropagation()
  this.quickViewTicketId.set(t.id)
  this.quickViewTicketSource.set(t.source)
  this.markRowReadLocally(t)
  // Lock background scroll while the flap is open. Without this, the list
  // behind it (scrolled via <main>'s own overflow-y-auto, not document.body)
  // can gain/lose its scrollbar as content changes underneath — a sudden
  // ~15px reflow that reads as the whole page "shifting" the instant the
  // panel opens or closes, even though the panel itself is truly
  // fixed/overlaid.
  this.layout.scrollLocked.set(true)
}
closeQuickView() {
  this.quickViewTicketId.set(null)
  this.layout.scrollLocked.set(false)
}

// ticket-detail.ts now calls the /read endpoint itself as soon as a ticket
// loads, but that round-trips through the server before tickets_updated
// comes back and this list refetches — so the dot on THIS row lingered for
// a beat. Flip it locally too, immediately, for the row the agent just
// clicked. Harmless if the server call is a no-op (already read).
private markRowReadLocally(t: Ticket) {
  if (t.is_read) return
  this.tickets.update(list => list.map(x => x.id === t.id ? { ...x, is_read: 1 } : x))
}

  // --- Bulk select ---
  selectedIds = signal<Set<number>>(new Set())
  hasSelection = computed(() => this.selectedIds().size > 0)
  selectedList = computed(() => Array.from(this.selectedIds()))
  allVisibleSelected = computed(() => {
    const t = this.tickets()
    return t.length > 0 && t.every(x => this.selectedIds().has(x.id))
  })

  // --- Per-row popovers ---
  statusMenuOpenFor = signal<number | null>(null)

  // --- Edit modal state (unchanged behavior, statuses updated to the 4-value set) ---
  editing = signal<Ticket | null>(null)
  editForm = { customerName: '', customerPhone: '', customerEmail: '', priority: 'medium', status: 'open', source: 'manual' }
  saving = signal(false)

  // --- Merge modal state ---
  showMergeModal = signal(false)
  mergeTargetId: number | null = null

  // --- Macro picker (bulk bar) ---
  macros = signal<TicketMacro[]>([])
  showMacroMenu = signal(false)

  // Fetched once here and passed down to every <app-agent-picker> row via
  // [agents] — previously each row fetched /agents on its own.
  agentsList = signal<{ id: number; name: string; role: string }[]>([])

  // --- Bulk assign popover ---
  showBulkAssign = signal(false)

  showCreateModal = signal(false)

  readonly statuses: { value: StatusFilter; label: string; dotClass: string }[] = [
    // { value: '',           label: 'All',       dotClass: 'bg-indigo-500' },
    { value: 'open',      label: 'Open',      dotClass: 'bg-blue-500' },
    { value: 'on_hold',   label: 'On Hold',   dotClass: 'bg-amber-500' },
    { value: 'escalated', label: 'Escalated', dotClass: 'bg-rose-500' },
    { value: 'closed',    label: 'Closed',    dotClass: 'bg-emerald-500' },
    // Virtual tabs — not real statuses, filtered server-side on
    // reopen_count / rating instead of the status column (see
    // TicketService.getTickets). Excluded from assignableStatuses below.
    { value: 'reopened',  label: 'Re-opened', dotClass: 'bg-violet-500' },
    { value: 'rated',     label: 'Ratings',   dotClass: 'bg-fuchsia-500' },
  ]

  // Real, assignable statuses only. Used by the two dropdowns that actually
  // SET a ticket's status (bulk update + per-row status menu) — "All",
  // "Re-opened" and "Ratings" aren't values you can assign to a ticket, so
  // they should never appear as options there. Only the top filter-tabs bar
  // (which uses `statuses` directly) should show all of them.
  readonly assignableStatuses = this.statuses.filter(s =>
    ['open', 'on_hold', 'escalated', 'closed'].includes(s.value)
  )

readonly priorities: { value: string; label: string; dotClass: string }[] = [
  { value: 'low',    label: 'Low',    dotClass: 'bg-slate-400' },
  { value: 'medium', label: 'Medium', dotClass: 'bg-amber-500' },
  { value: 'high',   label: 'High',   dotClass: 'bg-rose-500' },
];

priorityClass(priority: string) {
  return {
    low: 'bg-slate-100 text-slate-600',
    medium: 'bg-amber-50 text-amber-700 border-amber-200',
    high: 'bg-rose-50 text-rose-700 border-rose-200',
  }[priority] ?? 'bg-slate-100 text-slate-600';
}

priorityDot(priority: string) {
  return { low: 'bg-slate-400', medium: 'bg-amber-500', high: 'bg-rose-500' }[priority] ?? 'bg-slate-400';
}

priorityMenuOpenFor = signal<number | null>(null)

togglePriorityMenu(t: Ticket, ev: Event) {
  ev.stopPropagation()
  this.priorityMenuOpenFor.set(this.priorityMenuOpenFor() === t.id ? null : t.id)
}

setTicketPriority(t: Ticket, priority: string, ev: Event) {
  ev.stopPropagation()
  this.priorityMenuOpenFor.set(null)
  this.ticketService.updateTicket({ id: t.id, priority }).subscribe(() => this.fetch())
}

private refetchTimer: any = null
private skipFirstTicketsEffect = true

constructor() {
  const initialStatus = this.route.snapshot.queryParamMap.get('status')
  if (initialStatus !== null) {
    if (initialStatus === 'all' || initialStatus === '') {
      this.statusFilter = ''
    } else if (initialStatus === 'deleted') {
      // Deep-link / page-refresh support for ?status=deleted — mirrors
      // toggleDeletedView()'s own state (showDeleted=true, statusFilter
      // cleared) instead of falling through unrecognized.
      this.statusFilter = ''
      this.showDeleted.set(true)
    } else if (this.statuses.some(s => s.value === initialStatus)) {
      this.statusFilter = initialStatus as StatusFilter
    }
  }
  const initialPriority = this.route.snapshot.queryParamMap.get('priority')
  if (initialPriority) {
    this.priorityFilter.set(initialPriority)
  }
  const initialResolvedToday = this.route.snapshot.queryParamMap.get('resolvedToday')
  if (initialResolvedToday === 'true' || initialResolvedToday === '1') {
    this.resolvedTodayFilter.set(true)
  }
  const initialUnassigned = this.route.snapshot.queryParamMap.get('unassigned')
  if (initialUnassigned === 'true' || initialUnassigned === '1') {
    this.unassignedFilter.set(true)
  }

  this.fetch()
  this.fetchMacros()
  this.fetchAgents()
  this.fetchCounts()

  this.route.queryParamMap.subscribe(params => {
    let shouldFetch = false
    const statusParam = params.get('status')
    if (statusParam !== null) {
      // FIX (root cause of the "click Deleted twice" bug): 'deleted' isn't
      // one of `this.statuses`' values, so it used to fall through to the
      // `: 'open'` default below — which then found statusFilter ('' or
      // 'open', set by toggleDeletedView()) different from the recomputed
      // 'open' target and IMMEDIATELY forced showDeleted back to false,
      // undoing the toggle the same tick it was set. Handle it explicitly
      // instead, mirroring exactly what toggleDeletedView() itself sets.
      if (statusParam === 'deleted') {
        if (!this.showDeleted()) {
          this.showDeleted.set(true)
          this.statusFilter = ''
          shouldFetch = true
        }
      } else {
        const targetFilter: StatusFilter = statusParam === 'all' || statusParam === ''
          ? ''
          : (this.statuses.some(s => s.value === statusParam) ? (statusParam as StatusFilter) : 'open')
        if (this.statusFilter !== targetFilter || this.showDeleted()) {
          this.statusFilter = targetFilter
          this.showDeleted.set(false)
          shouldFetch = true
        }
      }
    }

    const priorityParam = params.get('priority') ?? ''
    if (this.priorityFilter() !== priorityParam) {
      this.priorityFilter.set(priorityParam)
      shouldFetch = true
    }

    const resolvedTodayParam = params.get('resolvedToday') === 'true' || params.get('resolvedToday') === '1'
    if (this.resolvedTodayFilter() !== resolvedTodayParam) {
      this.resolvedTodayFilter.set(resolvedTodayParam)
      shouldFetch = true
    }

    const unassignedParam = params.get('unassigned') === 'true' || params.get('unassigned') === '1'
    if (this.unassignedFilter() !== unassignedParam) {
      this.unassignedFilter.set(unassignedParam)
      shouldFetch = true
    }

    if (shouldFetch) {
      this.fetch()
    }
  })

  // effect() always runs once immediately on creation, in addition to the
  // explicit this.fetch() above — that was firing two identical
  // GET /tickets calls on every mount. Skip that first run.
  effect(() => {
    this.ticketSocket.ticketsVersion()
    if (this.skipFirstTicketsEffect) { this.skipFirstTicketsEffect = false; return }
    clearTimeout(this.refetchTimer)
    this.refetchTimer = setTimeout(() => { this.fetch(true); this.fetchCounts() }, 250)
  })
}

  ngOnDestroy() {
    // Safety net: if this component is torn down (route navigation away)
    // while the quick-view flap is still open, make sure the scroll lock
    // from openQuickView() doesn't leak and freeze scrolling on whatever
    // page loads next.
    this.layout.scrollLocked.set(false)
  }

  onSearch(e: Event) { this.search = (e.target as HTMLInputElement).value; this.fetch() }
  setStatus(status: StatusFilter, ev?: Event) {
    // "Ratings" tab: don't jump straight to "every rated ticket" — open the
    // small star-value dropdown first (see toggleRatingPicker/toggleRatingInFilter
    // above) and let the dropdown itself trigger the actual fetch once a
    // star value (or "All ratings") is picked.
    if (status === 'rated') {
      ev?.stopPropagation()
      // FIX: this used to be `!this.showRatingPicker() || this.statusFilter
      // !== 'rated'` — since statusFilter only actually flips to 'rated'
      // once a star value is picked (see toggleRatingInFilter), a second
      // click on the tab BEFORE picking anything had showRatingPicker()
      // true and statusFilter still !== 'rated', so the OR made the whole
      // expression true again and the dropdown never closed. A plain
      // negation toggles correctly in every case.
      this.showRatingPicker.set(!this.showRatingPicker())
      return
    }
    this.showRatingPicker.set(false)
    this.ratingFilter.set([])
    this.showDeleted.set(false)
    // FIX: this used to toggle back to '' (no filter) when the already-
    // active tab was clicked again — with the "All" tab hidden/commented
    // out, that meant clicking "Open" a second time silently deselected
    // it instead of just re-confirming/refreshing it. A tab should stay
    // selected when clicked again, not clear itself.
    this.statusFilter = status
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { status: this.statusFilter || 'all' },
      queryParamsHandling: 'merge',
    })
    this.fetch()
  }

  clearPriorityFilter() {
    this.priorityFilter.set('')
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { priority: null },
      queryParamsHandling: 'merge',
    })
    this.fetch()
  }

  clearResolvedTodayFilter() {
    this.resolvedTodayFilter.set(false)
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { resolvedToday: null },
      queryParamsHandling: 'merge',
    })
    this.fetch()
  }

  clearOrgFilter(ev?: Event) { ev?.stopPropagation(); this.orgFilter.set([]); this.fetch() }
  clearContactFilter(ev?: Event) { ev?.stopPropagation(); this.contactFilterSel.set([]); this.fetch() }
  clearRatingFilter() {
    this.ratingFilter.set([])
    this.statusFilter = ''
    this.router.navigate([], { relativeTo: this.route, queryParams: { status: 'all' }, queryParamsHandling: 'merge' })
    this.fetch()
  }

  clearUnassignedFilter() {
    this.unassignedFilter.set(false)
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { unassigned: null },
      queryParamsHandling: 'merge',
    })
    this.fetch()
  }

  toggleDeletedView() {
    this.showDeleted.set(!this.showDeleted())
    if (this.showDeleted()) {
      this.statusFilter = ''
      this.router.navigate([], {
        relativeTo: this.route,
        queryParams: { status: 'deleted' },
        queryParamsHandling: 'merge',
      })
    } else {
      // FIX: turning Deleted OFF used to leave the URL's ?status=deleted
      // in place with nothing to reconcile it — harmless on its own, but
      // stale state that the query-param subscription above could
      // otherwise re-interpret. Restore a real tab (Open) in both the URL
      // and the filter so the list and the tab bar agree.
      this.statusFilter = 'open'
      this.router.navigate([], {
        relativeTo: this.route,
        queryParams: { status: 'open' },
        queryParamsHandling: 'merge',
      })
    }
    this.clearSelection()
    this.fetch()
  }

  tabKey(v: StatusFilter) { return v || 'open' }

  statusClass(status: string) {
    return {
      open: 'bg-blue-50 text-blue-700',
      on_hold: 'bg-amber-50 text-amber-700',
      escalated: 'bg-rose-50 text-rose-700',
      closed: 'bg-emerald-50 text-emerald-700',
    }[status] ?? 'bg-slate-100 text-slate-600'
  }



  statusLabel(status: string) {
    return this.statuses.find(s => s.value === status)?.label ?? status
  }

 

  initials(name?: string) {
    return name?.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase() || '?'
  }

  orgInitials(name?: string) {
    return name?.trim()?.[0]?.toUpperCase() || '?'
  }

  /** Zoho falls back to the customer's message subject; we fall back further to customer name so a card is never blank-headlined. */
cardTitle(t: Ticket) {
  return t.subject?.trim() || 'New ticket'
}

private fetch(isBackground = false) {
  this.pageOffset = 0
  this.hasMore.set(true)
  if (!isBackground) this.loading.set(true)
  this.ticketService.getTickets(0, this.PAGE_SIZE_INITIAL, {
    search: this.search,
    status: this.statusFilter,
    priority: this.priorityFilter() || undefined,
    resolvedToday: this.resolvedTodayFilter(),
    unassignedOnly: this.unassignedFilter(),
    deletedOnly: this.showDeleted(),
    assignedTo: this.assignedToFilter(),
    orgId: this.orgFilter().map(o => o.orgId),
    contactEmail: this.contactFilterSel().filter(c => c.email).map(c => c.email as string),
    contactPhone: this.contactFilterSel().filter(c => !c.email && c.phone).map(c => c.phone as string),
    rating: this.ratingFilter(),
    sortBy: this.sortByParam,
    sortOrder: this.sortOrderParam,
  }).subscribe({
    next: (r: any) => {
      const rows = r?.status !== false ? r : []
      this.tickets.set(rows)
      this.pageOffset = rows.length
      this.hasMore.set(rows.length === this.PAGE_SIZE_INITIAL)
      this.loading.set(false)
    },
    error: () => this.loading.set(false)
  })
}

  // Called when the list is scrolled near its bottom. Search/status filters
  // stay in effect — this only appends the next page of the SAME filtered
  // query, it never resets them.
  loadMore() {
    if (this.loadingMore() || !this.hasMore() || this.loading()) return
    this.loadingMore.set(true)
    this.ticketService.getTickets(this.pageOffset, this.PAGE_SIZE_MORE, {
      search: this.search,
      status: this.statusFilter,
      priority: this.priorityFilter() || undefined,
      resolvedToday: this.resolvedTodayFilter(),
      unassignedOnly: this.unassignedFilter(),
      deletedOnly: this.showDeleted(),
      assignedTo: this.assignedToFilter(),
      orgId: this.orgFilter().map(o => o.orgId),
      contactEmail: this.contactFilterSel().filter(c => c.email).map(c => c.email as string),
      contactPhone: this.contactFilterSel().filter(c => !c.email && c.phone).map(c => c.phone as string),
      rating: this.ratingFilter(),
      sortBy: this.sortByParam,
      sortOrder: this.sortOrderParam,
    }).subscribe({
      next: (r: any) => {
        const rows = r?.status !== false ? r : []
        this.tickets.update(cur => [...cur, ...rows])
        this.pageOffset += rows.length
        this.hasMore.set(rows.length === this.PAGE_SIZE_MORE)
        this.loadingMore.set(false)
      },
      error: () => this.loadingMore.set(false)
    })
  }

  onListScroll(ev: Event) {
    const el = ev.target as HTMLElement
    if (el.scrollHeight - el.scrollTop - el.clientHeight < 150) this.loadMore()
  }

  private fetchCounts() {
    this.ticketService.getStatusCounts().subscribe({
      next: (r: any) => this.tabCounts.set(r ?? {}),
      error: () => {},
    })
  }

  private fetchMacros() {
    this.ticketService.getMacros().subscribe({
      next: (r: any) => this.macros.set(Array.isArray(r) ? r : (r?.data ?? [])),
      error: () => this.macros.set([]),
    })
  }

  private fetchAgents() {
    this.ticketService.getAgents().subscribe({
      next: (r: any) => this.agentsList.set(Array.isArray(r) ? r : (r?.data ?? [])),
      error: () => this.agentsList.set([]),
    })
  }

  // ============================================================
  // Navigation ("View" — same as the old row-click / Ticket Peek)
  // ============================================================
viewTicket(t: Ticket) {
  this.markRowReadLocally(t)
  // Pass the current status filter as a query param
  this.router.navigate(['/tickets', t.id], { queryParams: { status: this.statusFilter || 'all' } })
}

  // Deleted tickets are view + restore only — clicking the row opens the
  // quick-view panel in place rather than navigating to the full ticket
  // detail route (which still exposes editing controls this list hides).
  onRowClick(t: Ticket, ev: Event) {
    if (this.showDeleted()) { this.openQuickView(t, ev); return }
    this.viewTicket(t)
  }

  // ============================================================
  // Bulk select
  // ============================================================
  toggleSelect(id: number, ev: Event) {
    ev.stopPropagation()
    const next = new Set(this.selectedIds())
    next.has(id) ? next.delete(id) : next.add(id)
    this.selectedIds.set(next)
  }

  toggleSelectAll() {
    if (this.allVisibleSelected()) { this.selectedIds.set(new Set()); return }
    this.selectedIds.set(new Set(this.tickets().map(t => t.id)))
  }

  clearSelection() { this.selectedIds.set(new Set()) }

  // ============================================================
  // Per-card status dropdown (Zoho-style)
  // ============================================================
  toggleStatusMenu(t: Ticket, ev: Event) {
    ev.stopPropagation()
    this.statusMenuOpenFor.set(this.statusMenuOpenFor() === t.id ? null : t.id)
  }

  setTicketStatus(t: Ticket, status: string, ev: Event) {
    ev.stopPropagation()
    this.statusMenuOpenFor.set(null)
    // Closing is the one status change that can also fire a closure email
    // to the customer — same as ticket-detail's Close Ticket flow — so it
    // goes through a confirm step instead of applying immediately.
    if (status === 'closed') {
      this.closeConfirmTarget.set(t)
      this.sendClosureOnClose.set(true)
      return
    }
    this.ticketService.updateStatus(t.id, status).subscribe(() => { this.fetch(); this.fetchCounts() })
  }

  // ── Close-ticket confirm (mirrors ticket-detail's close flow) ─────────
  // Target is either a single Ticket (row-level close) or a plain array of
  // ids (bulk close) — same modal, same per-ticket socket call either way.
  closeConfirmTarget = signal<Ticket | number[] | null>(null)
  sendClosureOnClose = signal(true)

  closeConfirmIds(): number[] {
    const target = this.closeConfirmTarget()
    if (!target) return []
    return Array.isArray(target) ? target : [target.id]
  }

  closeConfirmLabel(): string {
    const target = this.closeConfirmTarget()
    if (!target) return ''
    if (Array.isArray(target)) return `${target.length} ticket${target.length === 1 ? '' : 's'}`
    return `ticket ${target.ticket_uid}`
  }

  confirmCloseTicket() {
    const ids = this.closeConfirmIds()
    if (!ids.length) return
    // Socket path (not the plain REST updateStatus above) — it's the one
    // that actually knows how to send the closure email; see
    // TicketService.updateStatus on the backend. The list refreshes itself
    // via the ticketsVersion effect once the server's tickets_updated event
    // comes back, so no local patch/subscribe needed here.
    ids.forEach(id => this.ticketSocket.updateStatus(id, 'closed', this.sendClosureOnClose()))
    this.closeConfirmTarget.set(null)
    this.clearSelection()
  }

  cancelCloseTicket() {
    this.closeConfirmTarget.set(null)
  }

  // ============================================================
  // Read / unread (4th icon)
  // ============================================================
  toggleRead(t: Ticket, ev: Event) {
    ev.stopPropagation()
    const req = t.is_read ? this.ticketService.markUnread(t.id) : this.ticketService.markRead(t.id)
    req.subscribe(() => this.fetch())
  }

  // ============================================================
  // Assign (per-card, via AgentPickerComponent)
  // ============================================================
  onAssigned(t: Ticket, agent: { id: number; name: string }) {
    this.ticketService.assign(t.id, agent.id, agent.name).subscribe(() => this.fetch())
  }

  // ============================================================
  // Edit (unchanged logic — statuses/priorities updated)
  // ============================================================
  openEdit(t: Ticket, ev: Event) {
    ev.stopPropagation()
    this.editing.set(t)
    this.editForm = {
      customerName: t.customer_name ?? '',
      customerPhone: t.customer_phone ?? '',
      customerEmail: t.customer_email ?? '',
      priority: t.priority,
      status: t.status,
      source: t.source,
    }
  }

  closeEdit() { this.editing.set(null) }

  saveEdit() {
    const t = this.editing()
    if (!t) return
    this.saving.set(true)
    this.ticketService.updateTicket({ id: t.id, ...this.editForm }).subscribe({
      next: () => { this.saving.set(false); this.closeEdit(); this.fetch() },
      error: () => { this.saving.set(false) },
    })
  }

  // ============================================================
  // Delete (unchanged logic)
  // ============================================================
  async deleteTicket(t: Ticket, ev: Event) {
    ev.stopPropagation()
    const ok = await this.dialog.confirm({
      title: 'Delete ticket',
      message: `Delete ticket ${t.ticket_uid}? This can't be undone from here.`,
      confirmLabel: 'Delete',
      variant: 'danger',
    })
    if (!ok) return
    this.ticketService.deleteTicket(t.id).subscribe(() => this.fetch())
  }

  async restoreTicket(t: Ticket, ev: Event) {
    ev.stopPropagation()
    const ok = await this.dialog.confirm({
      title: 'Restore ticket',
      message: `Restore ticket ${t.ticket_uid}?`,
      confirmLabel: 'Restore',
    })
    if (!ok) return
    this.ticketService.restoreTicket(t.id).subscribe(() => this.fetch())
  }

  openCreate() { this.showCreateModal.set(true) }
  closeCreate() { this.showCreateModal.set(false) }
  onCreated() { this.showCreateModal.set(false); this.fetch() }

  // ============================================================
  // BULK ACTION BAR
  // ============================================================
  private get selectedArray() { return Array.from(this.selectedIds()) }

  bulkAssign(agent: { id: number; name: string }) {
    this.showBulkAssign.set(false)
    this.ticketService.bulkAssign(this.selectedArray, agent.id, agent.name).subscribe(() => { this.clearSelection(); this.fetch() })
  }

  bulkSetStatus(status: string) {
    // Same rule as the per-row path above: closing can fire a customer
    // email, so it goes through the confirm modal instead of applying
    // immediately — closeConfirmTarget accepts the bulk id array directly.
    if (status === 'closed') {
      this.closeConfirmTarget.set(this.selectedArray)
      this.sendClosureOnClose.set(true)
      return
    }
    this.ticketService.bulkUpdateStatus(this.selectedArray, status).subscribe(() => { this.clearSelection(); this.fetch() })
  }

  bulkClose() { this.bulkSetStatus('closed') }

  async bulkComment() {
    const note = await this.dialog.prompt({
      title: 'Add internal note',
      message: `Add an internal note to ${this.selectedArray.length} selected ticket(s).`,
      placeholder: 'Write a note…',
      confirmLabel: 'Add Note',
    })
    if (!note) return
    this.selectedArray.forEach(id => this.ticketService.addInternalNote(id, note).subscribe())
    setTimeout(() => { this.clearSelection(); this.fetch() }, 300)
  }

  async bulkDelete() {
    const ok = await this.dialog.confirm({
      title: 'Delete tickets',
      message: `Delete ${this.selectedArray.length} ticket(s)? This can't be undone.`,
      confirmLabel: 'Delete',
      variant: 'danger',
    })
    if (!ok) return
    this.ticketService.bulkDelete(this.selectedArray).subscribe(() => { this.clearSelection(); this.fetch() })
  }

  async bulkMarkSpam() {
    const ok = await this.dialog.confirm({
      title: 'Mark as spam',
      message: `Mark ${this.selectedArray.length} ticket(s) as spam?`,
      confirmLabel: 'Mark as spam',
    })
    if (!ok) return
    this.ticketService.bulkMarkSpam(this.selectedArray, true).subscribe(() => { this.clearSelection(); this.fetch() })
  }

  async openMerge() {
    if (this.selectedIds().size < 2) {
      await this.dialog.alert('Select at least 2 tickets to merge.')
      return
    }
    this.mergeTargetId = this.selectedArray[0]
    this.showMergeModal.set(true)
  }

  confirmMerge() {
    if (!this.mergeTargetId) return
    const sourceIds = this.selectedArray.filter(id => id !== this.mergeTargetId)
    this.ticketService.mergeTickets(sourceIds, this.mergeTargetId).subscribe(() => {
      this.showMergeModal.set(false)
      this.clearSelection()
      this.fetch()
    })
  }

  toggleMacroMenu() { this.showMacroMenu.set(!this.showMacroMenu()) }

  applyMacro(macro: TicketMacro) {
    this.showMacroMenu.set(false)
    this.ticketService.bulkApplyMacro(this.selectedArray, macro.id).subscribe(() => { this.clearSelection(); this.fetch() })
  }

  async bulkUpdateResolution() {
    const code = await this.dialog.prompt({
      title: 'Set resolution code',
      message: `Resolution code for ${this.selectedArray.length} selected ticket(s).`,
      placeholder: 'fixed, duplicate, not-reproducible…',
      confirmLabel: 'Apply',
    })
    if (!code) return
    this.selectedArray.forEach(id => this.ticketService.updateResolution(id, code).subscribe())
    setTimeout(() => { this.clearSelection(); this.fetch() }, 300)
  }

  showCommentFor = signal<Ticket | null>(null)
commentDraft = ''

openCommentModal(t: Ticket, ev: Event) {
  ev.stopPropagation()
  this.showCommentFor.set(t)
  this.commentDraft = ''
}
closeCommentModal() { this.showCommentFor.set(null) }

submitComment() {
  const t = this.showCommentFor()
  const text = this.commentDraft.trim()
  if (!t || !text) return
  this.ticketService.addInternalNote(t.id, text).subscribe(() => {
    this.closeCommentModal()
    this.fetch()
  })
}

// ─── Ticket Re-sync ────────────────────────────────────────────────────────────
resyncTicket(t: Ticket, event: Event) {
  event.stopPropagation()
  if (this.resyncingId() === t.id) return
  this.resyncingId.set(t.id)
  this.resyncService.resyncTicket(t.ticket_uid).subscribe({
    next: (res) => {
      this.resyncingId.set(null)
      this.fetch()
      this.dialog.alert(`Re-sync complete for #${t.ticket_uid}. ${res.messagesInserted} message(s) imported from Outlook.`)
    },
    error: (err) => {
      this.resyncingId.set(null)
      const msg = err?.error?.error || err?.message || 'Re-sync failed. Please try again.'
      this.dialog.alert(`Re-sync failed for #${t.ticket_uid}: ${msg}`)
    },
  })
}

}