import { Component, inject } from '@angular/core'
import { CommonModule } from '@angular/common'
import { AuthService } from '../../service/auth.service'
import { RouterLink } from '@angular/router'

@Component({
  selector: 'app-settings',
  standalone: true,
 imports: [CommonModule, RouterLink], 
  templateUrl: './settings.html',
  styleUrl: './settings.css',
})
export class SettingsComponent {
  auth = inject(AuthService)
} 