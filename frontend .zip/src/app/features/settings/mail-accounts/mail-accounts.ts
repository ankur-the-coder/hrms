import { Component, OnInit, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ActivatedRoute } from '@angular/router'
import { MailAccountService } from '../../../core/services/mail-account.service'
import { MailAccount } from '../../../core/models/mail-account.model'
import { DialogService } from '../../../core/services/Dialog-services/dialog.services'

@Component({
  selector: 'app-mail-accounts',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './mail-accounts.html',
  styleUrl: './mail-accounts.css',
})
export class MailAccountsComponent implements OnInit {
  accounts = signal<MailAccount[]>([])
  justConnected = signal<string | null>(null)
  connectError = signal(false)
  trace = signal<any | null>(null)
  traceLoading = signal(false)
  traceError = signal<string | null>(null)

  constructor(private mailAccountService: MailAccountService, private route: ActivatedRoute, private dialog: DialogService) {}

  ngOnInit() {
    this.justConnected.set(this.route.snapshot.queryParamMap.get('mailConnected'))
    this.connectError.set(!!this.route.snapshot.queryParamMap.get('mailConnectError'))
    this.refresh()

    const traceId = this.route.snapshot.queryParamMap.get('traceId')
    if (traceId) this.loadTrace(traceId)
  }

  loadTrace(traceId: string) {
    this.traceLoading.set(true)
    this.traceError.set(null)
    this.mailAccountService.getTrace(traceId).subscribe({
      next: (data) => {
        this.trace.set(data)
        this.traceLoading.set(false)
      },
      error: (err) => {
        this.traceError.set(err?.error?.msg || 'Could not load trace.')
        this.traceLoading.set(false)
      },
    })
  }

  copyTrace() {
    navigator.clipboard.writeText(JSON.stringify(this.trace(), null, 2))
  }

  refresh() {
    this.mailAccountService.list().subscribe((rows) => this.accounts.set(rows))
  }

  connect() {
    // Full navigation — this needs to hit accounts.microsoftonline.com,
    // it can't be an XHR/fetch.
    window.location.href = this.mailAccountService.connectUrl()
  }

  async disconnect(id: number) {
    const ok = await this.dialog.confirm({
      title: 'Disconnect mailbox',
      message: 'Disconnect this mailbox? New mail will stop creating tickets automatically.',
      confirmLabel: 'Disconnect',
      variant: 'danger',
    })
    if (!ok) return
    this.mailAccountService.disconnect(id).subscribe(() => this.refresh())
  }

  setDefault(id: number) {
    this.mailAccountService.setDefault(id).subscribe(() => this.refresh())
  }

  subscriptionStatus(account: MailAccount): string {
    if (account.webhook_failed) return 'Webhook failed — reconnect'
    if (!account.subscription_expires_at) return 'Connecting…'
    return new Date(account.subscription_expires_at) > new Date() ? 'Live' : 'Renewing…'
  }
}