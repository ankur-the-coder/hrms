import { Component, EventEmitter, Input, Output, OnInit, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { TicketService } from '../../../core/services/ticket.service'

interface Agent { id: number; name: string; role: string }

/**
 * Small popover: "Assign To" -> list of agents -> emits { id, name }.
 * I don't have your existing agent list component (if you have one, share
 * it and I'll swap this out to reuse it instead of hitting /agents again).
 */
@Component({
  selector: 'app-agent-picker',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative">
      <button (click)="open.set(!open())"
              class="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors" title="Assign">
        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>
        </svg>
      </button>
      @if (open()) {
        <div class="absolute right-0 mt-1 w-52 bg-white rounded-lg shadow-xl border border-slate-100 z-50 py-1 max-h-64 overflow-y-auto">
          <p class="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wide">Assign To</p>
          @for (a of agents(); track a.id) {
            <button (click)="pick(a)" class="w-full text-left px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2">
              <span class="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-[10px] font-semibold">
                {{ a.name.slice(0,2).toUpperCase() }}
              </span>
              {{ a.name }}
            </button>
          }
          @if (!agents().length) {
            <p class="px-3 py-2 text-sm text-slate-400">No agents found.</p>
          }
        </div>
      }
    </div>
  `,
})
export class AgentPickerComponent implements OnInit {
  private ticketService = inject(TicketService)

  @Input() currentAgentId: number | null = null
  // Pass the agents list down from the parent (fetched ONCE there) instead
  // of each row instance calling GET /agents itself. With N ticket rows on
  // screen this component used to fire N identical /agents requests on
  // every render — that's the repeated "agents" calls you saw in Network.
  // If a parent doesn't pass anything, this still self-fetches so the
  // component keeps working as a drop-in anywhere else it's used.
  private readonly defaultAgents = signal<Agent[]>([])
  @Input() agents = this.defaultAgents
  @Output() assigned = new EventEmitter<{ id: number; name: string }>()

  open = signal(false)

  ngOnInit() {
    // `this.agents !== this.defaultAgents` means a parent bound its own
    // signal via [agents] — trust it and never self-fetch, even if it's
    // still empty right now (its own request may just not have resolved
    // yet). Checking `.length` here instead was the bug: it couldn't tell
    // "no parent" apart from "parent's fetch hasn't finished", so every row
    // rendered before the parent's /agents call resolved fired its own.
    if (this.agents !== this.defaultAgents) return
    this.ticketService.getAgents().subscribe({
      next: (r: any) => this.agents.set(Array.isArray(r) ? r : (r?.data ?? [])),
      error: () => this.agents.set([]),
    })
  }

  pick(a: Agent) {
    this.open.set(false)
    this.assigned.emit({ id: a.id, name: a.name })
  }
}