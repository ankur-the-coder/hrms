import { Component, inject, signal, ViewChild } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { DomSanitizer, SafeHtml } from '@angular/platform-browser'
import { AgentService } from '../../../core/services/agent.service'
import { Agent } from '../../../core/models/ticket.model'
import { FRONTEND_DEFAULTS } from '../messaging/messaging'
import { RichTextEditorComponent, MergeTag } from '../../../core/text-editor/rich-text-editor'
import { DialogService } from '../../../core/services/Dialog-services/dialog.services'
import { TicketResyncService } from '../../../core/services/ticket-resync.service'

const AGENT_FOOTER_MERGE_TAGS: MergeTag[] = [{ label: 'Agent Name', token: '{{agent_name}}' }]

@Component({
  selector: 'app-agents',
  standalone: true,
  imports: [CommonModule, FormsModule, RichTextEditorComponent],
  templateUrl: './agents.html',
})
export class AgentsComponent {
  private agentService = inject(AgentService)
  private sanitizer = inject(DomSanitizer)
  private dialog = inject(DialogService)
  resyncService = inject(TicketResyncService)

  /** Convenience pass-through so the template can read the signal */
  get resyncEnabled() { return this.resyncService.resyncEnabled }

  agents = signal<Agent[]>([])
  showModal = signal(false)
  showSignatureModal = signal(false)
  saving = signal(false)
  errorMsg = signal('')
  loading = signal(false)

  editingId: number | null = null
  form = { name: '', username: '', password: '', role: 'agent' as 'admin' | 'agent' }

  // Admin editing agent signature
  sigAgent = signal<Agent | null>(null)
  sigHtml = ''
  sigSaving = signal(false)

  @ViewChild(RichTextEditorComponent) rteEditor?: RichTextEditorComponent
  readonly agentFooterMergeTags = AGENT_FOOTER_MERGE_TAGS
  readonly frontendDefaultFooter = FRONTEND_DEFAULTS.message_footer

  constructor() { this.fetch() }

  fetch() {
    this.loading.set(true)
    this.agentService.list().subscribe({
      next: (r: any) => { this.agents.set(Array.isArray(r) ? r : []); this.loading.set(false) },
      error: () => { this.loading.set(false) },
    })
  }

  openCreate() {
    this.editingId = null
    this.form = { name: '', username: '', password: '', role: 'agent' }
    this.errorMsg.set('')
    this.showModal.set(true)
  }

  openEdit(a: Agent) {
    this.editingId = a.id
    this.form = { name: a.name, username: a.username, password: '', role: a.role }
    this.errorMsg.set('')
    this.showModal.set(true)
  }

  closeModal() { this.showModal.set(false) }

openSignature(a: Agent) {
  this.sigAgent.set(a)
  this.agentService.getSignature(a.id).subscribe((r: any) => {
    this.sigHtml = r.signatureHtml?.trim() ? r.signatureHtml : FRONTEND_DEFAULTS.message_footer
    this.showSignatureModal.set(true)
  })
}

  closeSignatureModal() { this.showSignatureModal.set(false) }

async saveSignature() {
    const a = this.sigAgent()
    if (!a) return
    this.sigSaving.set(true)
    const finalHtml = this.rteEditor ? await this.rteEditor.finalizeForSave() : this.sigHtml
    this.sigHtml = finalHtml
    this.agentService.updateSignature(a.id, finalHtml).subscribe({
      next: () => { this.sigSaving.set(false); this.closeSignatureModal() },
      error: () => { this.sigSaving.set(false) }
    })
  }

getSafePreview(html: string): SafeHtml {
    const name = this.sigAgent()?.name || 'Agent'
    const replaced = (html || '').split('{{agent_name}}').join(name)
    return this.sanitizer.bypassSecurityTrustHtml(replaced)
  }

  save() {
    if (!this.form.name.trim() || !this.form.username.trim()) {
      this.errorMsg.set('Name and username are required.')
      return
    }
    if (!this.editingId && !this.form.password.trim()) {
      this.errorMsg.set('Password is required for a new account.')
      return
    }
    this.saving.set(true)
    const req$ = this.editingId
      ? this.agentService.update({ id: this.editingId, ...this.form, password: this.form.password || undefined })
      : this.agentService.create(this.form)

    req$.subscribe({
      next: (r: any) => {
        this.saving.set(false)
        if (r?.status === false) { this.errorMsg.set(r.msg || 'Failed to save.'); return }
        this.showModal.set(false)
        this.fetch()
      },
      error: () => { this.saving.set(false); this.errorMsg.set('Failed to save. Please try again.') },
    })
  }

  async toggleActive(a: Agent) {
    const activating = !a.is_active
    const ok = await this.dialog.confirm({
      title: activating ? 'Activate agent' : 'Deactivate agent',
      message: activating
        ? `Activate ${a.name}? They will regain access and be eligible for ticket assignment.`
        : `Deactivate ${a.name}? Their open tickets will become unassigned.`,
      confirmLabel: activating ? 'Activate' : 'Deactivate',
      variant: activating ? 'default' : 'danger',
    })
    if (!ok) return
    this.agentService.update({ id: a.id, isActive: activating }).subscribe(() => this.fetch())
  }

  /** Toggle the ticket re-sync feature for this workstation (stored in local browser). */
  toggleResync(event: Event) {
    const checked = (event.target as HTMLInputElement).checked
    this.resyncService.setResyncEnabled(checked)
  }
}