import { Component, OnInit, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { WhatsappAccountService, WhatsappAccount } from '../../../core/services/whatsapp-account.service'
import { DialogService } from '../../../core/services/Dialog-services/dialog.services'

@Component({
  selector: 'app-whatsapp-accounts',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './whatsapp-accounts.html',
})
export class WhatsappAccountsComponent implements OnInit {
  private waService = inject(WhatsappAccountService)
  private dialog = inject(DialogService)

  accounts = signal<WhatsappAccount[]>([])
  showModal = signal(false)
  saving = signal(false)
  errorMsg = signal('')

  form = {
    phoneNumberId: '',
    wabaId: '',
    displayPhoneNumber: '',
    accessToken: '',
  }

  ngOnInit() {
    this.refresh()
  }

  refresh() {
    this.waService.list().subscribe({
      next: (rows) => this.accounts.set(Array.isArray(rows) ? rows : []),
      error: () => this.accounts.set([])
    })
  }

  openConnectModal() {
    this.form = { phoneNumberId: '', wabaId: '', displayPhoneNumber: '', accessToken: '' }
    this.errorMsg.set('')
    this.showModal.set(true)
  }

  closeModal() {
    this.showModal.set(false)
  }

  saveAccount() {
    if (!this.form.phoneNumberId.trim() || !this.form.accessToken.trim()) {
      this.errorMsg.set('Phone Number ID and Meta Access Token are required.')
      return
    }

    this.saving.set(true)
    this.errorMsg.set('')

    this.waService.connect(this.form).subscribe({
      next: (res: any) => {
        this.saving.set(false)
        if (res?.status === false) {
          this.errorMsg.set(res.msg || 'Authentication failed.')
          return
        }
        this.closeModal()
        this.refresh()
      },
      error: (err: any) => {
        this.saving.set(false)
        const msg = err.error?.message || err.error?.error || 'Failed to authenticate with Meta Graph API.'
        this.errorMsg.set(msg)
      },
    })
  }

  async disconnect(id: number) {
    const ok = await this.dialog.confirm({
      title: 'Disconnect WhatsApp account',
      message: 'Disconnect this WhatsApp account? Incoming messages will no longer create tickets.',
      confirmLabel: 'Disconnect',
      variant: 'danger',
    })
    if (!ok) return
    this.waService.disconnect(id).subscribe(() => this.refresh())
  }
}