import { Component, ViewChild, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { AgentService } from '../../../core/services/agent.service'
import { AuthService } from '../../../service/auth.service'
import { EmailTemplateService, EmailTemplateKey, EmailTemplateRow } from '../../../core/services/email-template.service'
import { MergeTag, RichTextEditorComponent } from '../../../core/text-editor/rich-text-editor'
import { ActivatedRoute } from '@angular/router'


export type TemplateType = 'auto_response' | 'message_footer' | 'ticket_closure'
export const AGENT_FOOTER_MERGE_TAGS: MergeTag[] = [{ label: 'Agent Name', token: '{{agent_name}}' }]
export { FRONTEND_DEFAULTS }

const KEY_MAP: Record<TemplateType, EmailTemplateKey> = {
  auto_response: 'auto_ticket_response',
  message_footer: 'agent_footer_default',
  ticket_closure: 'ticket_closure',
}

// Frontend-owned factory defaults — "Reset to Default" reads these directly, no API call.
const FRONTEND_DEFAULTS: Record<TemplateType, string> = {
  auto_response: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin:0; padding:0; -webkit-text-size-adjust:100%; }
    @media only screen and (max-width:600px) {
      .ubis-wrapper { padding:0 !important; }
      .ubis-card { border-radius:0 !important; box-shadow:none !important; }
      .ubis-body, .ubis-footer { padding:24px 20px !important; }
      .ubis-h1 { font-size:18px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">

  <table width="100%" cellpadding="0" cellspacing="0" class="ubis-wrapper" style="width:100%;background:#f8fafc;padding:32px 16px;">
    <tr>
      <td align="center">
        <table width="100%" cellpadding="0" cellspacing="0" class="ubis-container" style="max-width:520px;margin:0 auto;width:100%;">

          <!-- Top Brand Header -->
          <tr>
            <td style="padding-bottom:20px; text-align:left;">
              <table cellpadding="0" cellspacing="0" style="display:inline-block;vertical-align:middle;">
                <tr>
                  <td style="vertical-align:middle;padding-right:8px;">
               <img src="https://ubihrmimages.s3.ap-south-1.amazonaws.com/10/division/35.jpg?r=16289015" alt="Logo" width="24" height="24" style="display:block;border-radius:6px;object-fit:cover;" />
                  </td>
                  <td style="vertical-align:middle;">
                    <span style="font-size:18px;font-weight:700;color:#0f172a;letter-spacing:-0.5px;">ubi<span style="color:#10b981;">Support</span></span>
                    <span style="font-size:12px;color:#64748b;margin-left:8px;font-weight:500;">• &nbsp;Helpdesk</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Main Premium Card --> 
          <tr>
            <td class="ubis-card" style="background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 4px 20px rgba(15,23,42,0.03);overflow:hidden;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="ubis-body" style="padding:32px 32px 24px;">

                    <table cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
                      <tr>
                        <td style="background:#e6f4ea;border-radius:20px;padding:4px 12px;vertical-align:middle;">
                          <span style="display:inline-block;width:6px;height:6px;background:#10b981;border-radius:50%;margin-right:6px;vertical-align:middle;"></span>
                          <span style="font-size:11px;font-weight:600;color:#059669;text-transform:uppercase;letter-spacing:0.5px;vertical-align:middle;">Ticket Created</span>
                        </td>
                      </tr>
                    </table>

                    <h1 class="ubis-h1" style="margin:0 0 6px;color:#0f172a;font-size:20px;font-weight:700;letter-spacing:-0.3px;">Hi {{customer_name:first}}!</h1>
                    <p class="ubis-sub" style="margin:0;color:#64748b;font-size:13px;line-height:1.5;">Thanks for reaching out! We have received your email and automatically logged it into our support system.</p>

                    <hr style="border:0;border-top:1px solid #f1f5f9;margin:24px 0;" />

                    <p style="margin:0 0 12px;font-size:11px;font-weight:700;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;">Ticket Details</p>
                    <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:10px;background:#ffffff;overflow:hidden;">
                      <tr>
                        <td style="padding:14px 16px;background:#f8fafc;">
                          <div style="font-size:11px;color:#94a3b8;margin-bottom:2px;text-transform:uppercase;letter-spacing:0.5px;">Ticket Reference Number</div>
                          <div style="font-size:16px;color:#0f172a;font-weight:700;letter-spacing:-0.3px;">#{{ticket_uid}}</div>
                        </td>
                      </tr>
                    </table>

                    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:16px;">
                      <tr>
                        <td style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:14px 16px;font-size:13px;color:#0369a1;line-height:1.5;">
                          <strong style="display:block;margin-bottom:4px;color:#0284c7;">Need to add anything else?</strong>
                          Our team is on it and will get back to you shortly. Just reply directly to this email to add updates or attachments — it will stay attached to this ticket.
                        </td>
                      </tr>
                    </table>

                  </td>
                </tr>

                <!-- Footer -->
                <tr>
                  <td class="ubis-footer" style="background:#f8fafc;padding:24px 32px;border-top:1px solid #e2e8f0;">
                    <p class="ubis-footer-title" style="font-size:13px;color:#374151;font-weight:700;margin:0 0 14px;">Need Assistance?</p>

                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">India Support</strong>
                      📞 <a href="tel:+916264345425" style="color:#0284c7;text-decoration:none;font-weight:500;">+91 6264345425</a>
                    </div>
                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">Overseas Support</strong>
                      📞 <a href="tel:+971555524131" style="color:#0284c7;text-decoration:none;font-weight:500;">+971 55-5524131</a>
                    </div>
                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">Email Us</strong>
                      ✉️ <a href="mailto:ubihrmsupport@ubitechsolutions.com" style="color:#0284c7;text-decoration:none;font-weight:500;">ubihrmsupport@ubitechsolutions.com</a>
                    </div>

                    <div class="ubis-divider" style="height:1px;background:#e2e8f0;margin:14px 0;"></div>

                    <p style="margin:0;font-size:11px;color:#94a3b8;line-height:1.5;text-align:center;">
                      Automated confirmation via <strong style="color:#64748b;font-weight:600;">ubiSupport Engine</strong><br>
                      Please retain your ticket ID when replying.
                    </p>
                    <p class="ubis-copyright" style="margin-top:10px;text-align:center;font-size:11px;color:#94a3b8;">&copy; 2026 ubiSupport. All rights reserved.</p>
                  </td>
                </tr>

              </table>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
 
</body> 
</html> ` ,
  ticket_closure: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <style>
    body { margin:0; padding:0; background:#f8fafc; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif; }
    .wrapper { padding:32px 16px; }
    .card { max-width:520px; margin:0 auto; background:#ffffff; border:1px solid #e2e8f0; border-radius:16px; overflow:hidden; box-shadow:0 4px 20px rgba(15,23,42,0.05); }
    .header { padding:28px 32px 20px; border-bottom:1px solid #f1f5f9; }
    .brand { font-size:18px; font-weight:700; color:#0f172a; }
    .brand span { color:#10b981; }
    .badge { display:inline-block; margin-top:12px; background:#fef3c7; color:#d97706; font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; padding:4px 12px; border-radius:20px; }
    .body { padding:28px 32px; }
    .greeting { font-size:16px; font-weight:600; color:#0f172a; margin:0 0 12px 0; }
    .msg { font-size:14px; color:#475569; line-height:1.7; margin:0 0 20px 0; }
    .ticket-ref { background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px 20px; text-align:center; }
    .ticket-ref p { margin:0; font-size:12px; color:#94a3b8; }
    .ticket-ref strong { font-size:16px; color:#0f172a; font-family:monospace; }
    .note { font-size:12px; color:#94a3b8; line-height:1.6; margin-top:20px; }
    .footer { background:#f8fafc; padding:16px 32px; text-align:center; font-size:11px; color:#94a3b8; border-top:1px solid #e2e8f0; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <div class="header">
        <div class="brand">ubi<span>Support</span> <span style="font-size:12px;color:#64748b;font-weight:500;">• Helpdesk</span></div>
        <div class="badge">✓ Ticket Closed</div>
      </div>
      <div class="body">
<p class="greeting">Hi {{customer_name:first}},</p>
        <p class="msg">This ticket has been closed. If your issue isn't fully resolved, just reply to reopen it.</p>
        <div class="ticket-ref">
          <p>Closed ticket reference</p>
          <strong>#{{ticket_uid}}</strong>
        </div>
        <p class="note">If your issue is not fully resolved, just reply to this email to reopen the ticket.</p>
      </div>
      <div class="footer">© ubiDesk Support Manager. All rights reserved.</div>
    </div>
  </div>
</body>
</html>`,
  message_footer: `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px;line-height:1.5;color:#334155;">
  <p style="margin:0 0 2px 0;font-weight:700;color:#0f172a;">{{agent_name}}</p>
  <p style="margin:0;color:#64748b;font-size:12px;">Customer Support | ubiDesk</p> 
</div>`      ,
}

const CUSTOMER_FIRST_NAME_TAG: MergeTag = { label: 'FirstName', token: '{{customer_name:first}}' }
const CUSTOMER_LAST_NAME_TAG: MergeTag = { label: 'LastName', token: '{{customer_name:last}}' }

const MERGE_TAGS: Record<TemplateType, MergeTag[]> = {
  auto_response: [ CUSTOMER_FIRST_NAME_TAG, CUSTOMER_LAST_NAME_TAG, { label: 'Ticket ID', token: '{{ticket_uid}}' } ],
  ticket_closure: [ CUSTOMER_FIRST_NAME_TAG, CUSTOMER_LAST_NAME_TAG, { label: 'Ticket ID', token: '{{ticket_uid}}' } ],
  message_footer: [ { label: 'Agent Name', token: '{{agent_name}}' } ],
}

export const TEMPLATE_META: Record<TemplateType, { title: string; description: string; adminOnly: boolean }> = {
  auto_response: {
    title: 'Auto-Response Template',
    description: 'Sent automatically when a customer opens a new support ticket.',
    adminOnly: true,
  },
  message_footer: {
    title: 'Message Footer Template',
    description: 'Your personal footer appended to every outbound reply you send.',
    adminOnly: false,
  },
  ticket_closure: {
    title: 'Ticket Closure Template',
    description: 'Sent to the customer when a ticket is marked as closed (agent decides per-ticket).',
    adminOnly: true,
  },
}

@Component({
  selector: 'app-messaging-settings',
  standalone: true,
  imports: [CommonModule, FormsModule, RichTextEditorComponent],
  templateUrl: './messaging.html',
})
export class MessagingSettingsComponent {
  private agentService = inject(AgentService)
  private emailTemplateService = inject(EmailTemplateService)
  auth = inject(AuthService)

  saving = signal(false)
  toast = signal<string | null>(null)

  autoRespondHtml = ''
  closureHtml = ''
  agentFooterHtml = ''

  panelOpen = signal(false)
  activeTemplate = signal<TemplateType | null>(null)

  @ViewChild(RichTextEditorComponent) rteEditor?: RichTextEditorComponent

  readonly templateMeta = TEMPLATE_META
  readonly templateTypeKeys: TemplateType[] = ['auto_response', 'message_footer', 'ticket_closure']

  constructor() {

     const route = inject(ActivatedRoute)
  const openParam = route.snapshot.queryParamMap.get('open') as TemplateType | null
  if (openParam && this.templateTypeKeys.includes(openParam)) {
    this.openPanel(openParam)
  }
    // Initial load still comes from the DB (the actual live/customized content);
    // only "Reset" is frontend-only now. Empty/never-customized rows fall back
    // to the frontend default so there's no blank editor on first use.
    this.emailTemplateService.list().subscribe((rows: EmailTemplateRow[]) => {
      for (const row of rows) {
        const value = row.html?.trim() ? row.html : FRONTEND_DEFAULTS[this.typeForKey(row.template_key)]
        if (row.template_key === 'auto_ticket_response') this.autoRespondHtml = value
        if (row.template_key === 'ticket_closure') this.closureHtml = value
        if (row.template_key === 'agent_footer_default' && !this.agentFooterHtml) this.agentFooterHtml = value
      }
    })

    const myAgentId = this.auth.getAgentId()
    if (myAgentId) {
      this.agentService.getSignature(myAgentId).subscribe((r: any) => {
        if (r.signatureHtml?.trim()) this.agentFooterHtml = r.signatureHtml
      })
    }
  }

  private typeForKey(key: EmailTemplateKey): TemplateType {
    if (key === 'auto_ticket_response') return 'auto_response'
    if (key === 'ticket_closure') return 'ticket_closure'
    return 'message_footer'
  }

  isReadOnly(type: TemplateType): boolean {
    return TEMPLATE_META[type].adminOnly && !this.auth.isAdmin()
  }

  mergeTagsFor(type: TemplateType | null): MergeTag[] {
    return type ? MERGE_TAGS[type] : []
  }

  openPanel(type: TemplateType) {
    this.activeTemplate.set(type)
    this.panelOpen.set(true)
  }

  closePanel() { this.panelOpen.set(false) }

  activeTitle(): string {
    const t = this.activeTemplate()
    return t ? TEMPLATE_META[t].title : ''
  }

  currentHtml(type: TemplateType | null): string {
    if (type === 'auto_response') return this.autoRespondHtml
    if (type === 'ticket_closure') return this.closureHtml
    if (type === 'message_footer') return this.agentFooterHtml
    return ''
  }

  onEditorChange(type: TemplateType | null, html: string) {
    if (type === 'auto_response') this.autoRespondHtml = html
    else if (type === 'ticket_closure') this.closureHtml = html
    else if (type === 'message_footer') this.agentFooterHtml = html
  }

  // ── Save: spinner while in flight, toast + auto-close on success ───────────
  savePanel() {
    const type = this.activeTemplate()
    if (!type || this.saving()) return
    this.saving.set(true)

    this.finalizeCurrentEditorHtml(type).then((finalHtml) => {
      const onDone = () => {
        this.saving.set(false)
        this.closePanel()
        this.showToast(`${TEMPLATE_META[type].title} saved`)
      }
      const onError = () => {
        this.saving.set(false)
        this.showToast('Could not save — please try again')
      }

      if (type === 'message_footer') {
        const myAgentId = this.auth.getAgentId()
        if (!myAgentId) { this.saving.set(false); return }
        this.agentService.updateSignature(myAgentId, finalHtml).subscribe({ next: onDone, error: onError })
        return
      }

      if (!this.auth.isAdmin()) { this.saving.set(false); return }
      this.emailTemplateService.update(KEY_MAP[type], finalHtml).subscribe({ next: onDone, error: onError })
    })
  }

  private async finalizeCurrentEditorHtml(type: TemplateType): Promise<string> {
    const finalHtml = this.rteEditor ? await this.rteEditor.finalizeForSave() : this.currentHtml(type)
    this.onEditorChange(type, finalHtml)
    return finalHtml
  }

  private showToast(message: string) {
    this.toast.set(message)
    setTimeout(() => this.toast.set(null), 3000)
  }

  // ── Reset: purely local, no backend round trip ──────────────────────────────
  resetPanel() {
    const type = this.activeTemplate()
    if (!type) return
    const fallback = FRONTEND_DEFAULTS[type]
    if (type === 'auto_response') this.autoRespondHtml = fallback
    if (type === 'ticket_closure') this.closureHtml = fallback
    if (type === 'message_footer') this.agentFooterHtml = fallback
  }



   AUTO_RESPONSE_DEFAULT = 
`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin:0; padding:0; -webkit-text-size-adjust:100%; }
    @media only screen and (max-width:600px) {
      .ubis-wrapper { padding:0 !important; }
      .ubis-card { border-radius:0 !important; box-shadow:none !important; }
      .ubis-body, .ubis-footer { padding:24px 20px !important; }
      .ubis-h1 { font-size:18px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">

  <table width="100%" cellpadding="0" cellspacing="0" class="ubis-wrapper" style="width:100%;background:#f8fafc;padding:32px 16px;">
    <tr>
      <td align="center">
        <table width="100%" cellpadding="0" cellspacing="0" class="ubis-container" style="max-width:520px;margin:0 auto;width:100%;">

          <!-- Top Brand Header -->
          <tr>
            <td style="padding-bottom:20px; text-align:left;">
              <table cellpadding="0" cellspacing="0" style="display:inline-block;vertical-align:middle;">
                <tr>
                  <td style="vertical-align:middle;padding-right:8px;">
                   <img src="{{logo_url}}" alt="Logo" width="24" height="24" style="display:block;border-radius:6px;object-fit:cover;" />
                  </td>
                  <td style="vertical-align:middle;">
                    <span style="font-size:18px;font-weight:700;color:#0f172a;letter-spacing:-0.5px;">ubi<span style="color:#10b981;">Support</span></span>
                    <span style="font-size:12px;color:#64748b;margin-left:8px;font-weight:500;">• &nbsp;Helpdesk</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Main Premium Card -->
          <tr>
            <td class="ubis-card" style="background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 4px 20px rgba(15,23,42,0.03);overflow:hidden;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="ubis-body" style="padding:32px 32px 24px;">

                    <table cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
                      <tr>
                        <td style="background:#e6f4ea;border-radius:20px;padding:4px 12px;vertical-align:middle;">
                          <span style="display:inline-block;width:6px;height:6px;background:#10b981;border-radius:50%;margin-right:6px;vertical-align:middle;"></span>
                          <span style="font-size:11px;font-weight:600;color:#059669;text-transform:uppercase;letter-spacing:0.5px;vertical-align:middle;">Ticket Created</span>
                        </td>
                      </tr>
                    </table>

                    <h1 class="ubis-h1" style="margin:0 0 6px;color:#0f172a;font-size:20px;font-weight:700;letter-spacing:-0.3px;">Hi {{customer_name:first}}!</h1>
                    <p class="ubis-sub" style="margin:0;color:#64748b;font-size:13px;line-height:1.5;">Thanks for reaching out! We have received your email and automatically logged it into our support system.</p>

                    <hr style="border:0;border-top:1px solid #f1f5f9;margin:24px 0;" />

                    <p style="margin:0 0 12px;font-size:11px;font-weight:700;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;">Ticket Details</p>
                    <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:10px;background:#ffffff;overflow:hidden;">
                      <tr>
                        <td style="padding:14px 16px;background:#f8fafc;">
                          <div style="font-size:11px;color:#94a3b8;margin-bottom:2px;text-transform:uppercase;letter-spacing:0.5px;">Ticket Reference Number</div>
                          <div style="font-size:16px;color:#0f172a;font-weight:700;letter-spacing:-0.3px;">#{{ticket_uid}}</div>
                        </td>
                      </tr>
                    </table>

                    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:16px;">
                      <tr>
                        <td style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:14px 16px;font-size:13px;color:#0369a1;line-height:1.5;">
                          <strong style="display:block;margin-bottom:4px;color:#0284c7;">Need to add anything else?</strong>
                          Our team is on it and will get back to you shortly. Just reply directly to this email to add updates or attachments — it will stay attached to this ticket.
                        </td>
                      </tr>
                    </table>

                  </td>
                </tr>

                <!-- Footer -->
                <tr>
                  <td class="ubis-footer" style="background:#f8fafc;padding:24px 32px;border-top:1px solid #e2e8f0;">
                    <p class="ubis-footer-title" style="font-size:13px;color:#374151;font-weight:700;margin:0 0 14px;">Need Assistance?</p>

                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">India Support</strong>
                      📞 <a href="tel:+916264345425" style="color:#0284c7;text-decoration:none;font-weight:500;">+91 6264345425</a>
                    </div>
                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">Overseas Support</strong>
                      📞 <a href="tel:+971555524131" style="color:#0284c7;text-decoration:none;font-weight:500;">+971 55-5524131</a>
                    </div>
                    <div class="ubis-contact-item" style="display:block;font-size:12.5px;color:#64748b;line-height:1.5;margin-bottom:10px;">
                      <strong style="display:block;color:#334155;margin-bottom:2px;font-size:11.5px;">Email Us</strong>
                      ✉️ <a href="mailto:ubihrmsupport@ubitechsolutions.com" style="color:#0284c7;text-decoration:none;font-weight:500;">ubihrmsupport@ubitechsolutions.com</a>
                    </div>

                    <div class="ubis-divider" style="height:1px;background:#e2e8f0;margin:14px 0;"></div>

                    <p style="margin:0;font-size:11px;color:#94a3b8;line-height:1.5;text-align:center;">
                      Automated confirmation via <strong style="color:#64748b;font-weight:600;">ubiSupport Engine</strong><br>
                      Please retain your ticket ID when replying.
                    </p>
                    <p class="ubis-copyright" style="margin-top:10px;text-align:center;font-size:11px;color:#94a3b8;">&copy; 2026 ubiSupport. All rights reserved.</p>
                  </td>
                </tr>

              </table>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
 
</body> 
</html> ` 

 TICKET_CLOSURE_DEFAULT = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <style>
    body { margin:0; padding:0; background:#f8fafc; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif; }
    .wrapper { padding:32px 16px; }
    .card { max-width:520px; margin:0 auto; background:#ffffff; border:1px solid #e2e8f0; border-radius:16px; overflow:hidden; box-shadow:0 4px 20px rgba(15,23,42,0.05); }
    .header { padding:28px 32px 20px; border-bottom:1px solid #f1f5f9; }
    .brand { font-size:18px; font-weight:700; color:#0f172a; }
    .brand span { color:#10b981; }
    .badge { display:inline-block; margin-top:12px; background:#fef3c7; color:#d97706; font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; padding:4px 12px; border-radius:20px; }
    .body { padding:28px 32px; }
    .greeting { font-size:16px; font-weight:600; color:#0f172a; margin:0 0 12px 0; }
    .msg { font-size:14px; color:#475569; line-height:1.7; margin:0 0 20px 0; }
    .ticket-ref { background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px 20px; text-align:center; }
    .ticket-ref p { margin:0; font-size:12px; color:#94a3b8; }
    .ticket-ref strong { font-size:16px; color:#0f172a; font-family:monospace; }
    .note { font-size:12px; color:#94a3b8; line-height:1.6; margin-top:20px; }
    .footer { background:#f8fafc; padding:16px 32px; text-align:center; font-size:11px; color:#94a3b8; border-top:1px solid #e2e8f0; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <div class="header">
        <div class="brand">ubi<span>Support</span> <span style="font-size:12px;color:#64748b;font-weight:500;">• Helpdesk</span></div>
        <div class="badge">✓ Ticket Closed</div>
      </div>
      <div class="body">
 <p class="greeting">Hi {{customer_name}},</p>
+        <p class="msg">This ticket has been closed. If your issue isn't fully resolved, just reply to reopen it.</p>
        <div class="ticket-ref">
          <p>Closed ticket reference</p>
          <strong>#{{ticket_uid}}</strong>
        </div>
        <p class="note">If your issue is not fully resolved, just reply to this email to reopen the ticket.</p>
      </div>
      <div class="footer">© ubiDesk Support Manager. All rights reserved.</div>
    </div>
  </div>
</body>
</html>`

 DEFAULT_AGENT_FOOTER = `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px;line-height:1.5;color:#334155;">
  <p style="margin:0 0 2px 0;font-weight:700;color:#0f172a;">{{agent_name}}</p>
  <p style="margin:0;color:#64748b;font-size:12px;">Customer Support | ubiDesk</p> 
</div>`      

 AGENT_FOOTER_DEFAULT = `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px;line-height:1.5;color:#334155;">
  <p style="margin:0 0 2px 0;font-weight:700;color:#0f172a;">{{agent_name}}</p>
  <p style="margin:0;color:#64748b;font-size:12px;">Customer Support | ubiDesk</p>
</div>`
}