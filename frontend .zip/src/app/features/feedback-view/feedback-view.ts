import { Component, computed, inject, OnInit, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { ActivatedRoute } from '@angular/router'
import { FeedbackRatingTier, PublicTicket, PublicTicketMessage } from '../../core/models/feedback.model'
import { FeedbackService } from './feedback.service'

/** One row rendered on the Remark-Timeline-style conversation strip. */
interface TimelineEntry {
  kind: 'rating' | 'customer' | 'agent' | 'system'
  badgeLabel: string
  badgeClass: string
  title: string
  meta: string
  body?: string | null
  date: Date
}

@Component({
  selector: 'app-feedback-view',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './feedback-view.html',
  styleUrl: './feedback-view.css',
})
export class FeedbackViewComponent implements OnInit {
  private route = inject(ActivatedRoute)
  private feedback = inject(FeedbackService)

  loading = signal(true)
  notFound = signal(false)
  errorMsg = signal<string | null>(null)

  mode = signal<'rating' | 'reopen' | 'view'>('view')
  tier = signal<FeedbackRatingTier | null>(null)
  ratingLabel = signal<string>('')
  ticket = signal<PublicTicket | null>(null)
  messages = signal<PublicTicketMessage[]>([])

  private token = ''

  // --- rating feedback form state ---
  likedMost = ''
  improve = ''
  explanation = ''
  submittingFeedback = signal(false)
  feedbackSubmitted = signal(false)

  // --- reopen "message us further" form state ---
  reopenMessage = ''
  submittingReopenMsg = signal(false)
  reopenMsgSent = signal(false)

  readonly TIER_META: Record<FeedbackRatingTier, { label: string; badgeClass: string; emoji: string }> = {
    positive: { label: 'Positive', badgeClass: 'badge-positive', emoji: '🎉' },
    neutral: { label: 'Neutral', badgeClass: 'badge-neutral', emoji: '🙂' },
    negative: { label: 'Negative', badgeClass: 'badge-negative', emoji: '💬' },
  }

  /** Exact emoji + label the customer clicked in the closure email (1-5 CSAT
   *  scale) — mirrors RATING_LABELS in TicketFeedbackService.ts. This is what
   *  should be shown everywhere the customer's own rating is displayed;
   *  never collapse it down to a generic "Positive/Neutral/Negative" tier. */
  readonly RATING_META: Record<number, { label: string; emoji: string; badgeClass: string }> = {
    1: { label: 'Very Unsatisfied', emoji: '😡', badgeClass: 'badge-negative' },
    2: { label: 'Unsatisfied', emoji: '🙁', badgeClass: 'badge-negative' },
    3: { label: 'Neutral', emoji: '😐', badgeClass: 'badge-neutral' },
    4: { label: 'Satisfied', emoji: '🙂', badgeClass: 'badge-positive' },
    5: { label: 'Very Satisfied', emoji: '🤩', badgeClass: 'badge-positive' },
  }

  firstName = computed(() => (this.ticket()?.customerName || 'there').split(' ')[0])

  /** The customer picked an exact emoji + label in the email (1-5 CSAT scale),
   *  not a generic tier — so this always reflects exactly what they clicked. */
  experienceMeta = computed(() => {
    const r = this.ticket()?.rating
    if (!r) return null
    return this.RATING_META[r] ?? null
  })

  /** Positive feedback (4-5) hides the priority pill entirely — a happy
   *  customer's ticket isn't something that needs a priority call-out. */
  showPriority = computed(() => {
    const r = this.ticket()?.rating
    return !(r && r >= 4)
  })

  statusMeta = computed(() => {
    const s = this.ticket()?.status ?? ''
    const map: Record<string, { label: string; dot: string }> = {
      new: { label: 'New', dot: 'bg-sky-500' },
      open: { label: 'Open', dot: 'bg-indigo-500' },
      waiting: { label: 'Waiting', dot: 'bg-amber-500' },
      on_hold: { label: 'On Hold', dot: 'bg-orange-500' },
      escalated: { label: 'Escalated', dot: 'bg-red-500' },
      resolved: { label: 'Resolved', dot: 'bg-emerald-500' },
      closed: { label: 'Closed', dot: 'bg-slate-400' },
    }
    return map[s] ?? { label: s || '—', dot: 'bg-slate-400' }
  })

  priorityMeta = computed(() => {
    const p = this.ticket()?.priority ?? ''
    const map: Record<string, { label: string; cls: string }> = {
      low: { label: 'Low', cls: 'text-emerald-600 bg-emerald-50' },
      medium: { label: 'Medium', cls: 'text-amber-600 bg-amber-50' },
      high: { label: 'High', cls: 'text-red-600 bg-red-50' },
    }
    return map[p] ?? { label: p || '—', cls: 'text-slate-600 bg-slate-50' }
  })

  /** Merges the customer's own rating/review with the message thread into one
   *  chronologically-descending timeline, styled after the Remark Timeline UI. */
  timeline = computed<TimelineEntry[]>(() => {
    const t = this.ticket()
    const entries: TimelineEntry[] = []

    if (t?.rating && t.ratingSubmittedAt) {
      const meta = this.RATING_META[t.rating]
      const parts = [t.ratingLikedMost, t.ratingImproveFeedback].filter(Boolean)
      entries.push({
        kind: 'rating',
        badgeLabel: meta.label,
        badgeClass: meta.badgeClass,
        title: `Your Experience — ${meta.label} ${meta.emoji}`,
        meta: 'Given by You',
        body: parts.length ? parts.join(' · ') : null,
        date: new Date(t.ratingSubmittedAt),
      })
    }

    for (const m of this.messages()) {
      const isAgent = m.sender === 'agent'
      const isSystem = m.sender === 'system'
      entries.push({
        kind: isAgent ? 'agent' : isSystem ? 'system' : 'customer',
        badgeLabel: isAgent ? 'Agent Reply' : isSystem ? 'System' : 'You',
        badgeClass: isAgent ? 'badge-agent' : isSystem ? 'badge-system' : 'badge-customer',
        title: m.sender_name || (isAgent ? 'Support Agent' : isSystem ? 'System' : 'You'),
        meta: isAgent ? 'Given by Support' : isSystem ? 'Automated update' : 'Given by You',
        body: this.stripHtml(m.message),
        date: new Date(m.created_at),
      })
    }

    return entries.sort((a, b) => b.date.getTime() - a.date.getTime())
  })

  ngOnInit(): void {
    const qp = this.route.snapshot.queryParamMap
    this.token = qp.get('t') || ''
    const rating = qp.get('r') ? Number(qp.get('r')) : undefined
    const reopen = qp.get('reopen') === '1' || qp.get('reopen') === 'true'

    if (!this.token) {
      this.loading.set(false)
      this.notFound.set(true)
      return
    }

    this.feedback.view(this.token, rating, reopen).subscribe({
      next: (data) => {
        this.loading.set(false)
        if (!data.found) { this.notFound.set(true); return }
        this.mode.set(data.mode ?? 'view')
        this.tier.set(data.tier ?? null)
        this.ratingLabel.set(data.ratingLabel ?? '')
        this.ticket.set(data.ticket ?? null)
        this.messages.set(data.messages ?? [])
      },
      error: () => {
        this.loading.set(false)
        this.notFound.set(true)
      },
    })
  }

  submitFeedback(): void {
    if (this.submittingFeedback()) return
    this.submittingFeedback.set(true)
    this.errorMsg.set(null)

    const payload = this.tier() === 'negative'
      ? { explanation: this.explanation.trim() }
      : { likedMost: this.likedMost.trim(), improve: this.improve.trim() }

    this.feedback.submit(this.token, payload).subscribe({
      next: (data) => {
        this.submittingFeedback.set(false)
        if (!data.found) { this.errorMsg.set("This link isn't valid anymore."); return }
        this.ticket.set(data.ticket ?? this.ticket())
        this.messages.set(data.messages ?? this.messages())
        this.feedbackSubmitted.set(true)
      },
      error: () => {
        this.submittingFeedback.set(false)
        this.errorMsg.set('Something went wrong sending your feedback — please try again.')
      },
    })
  }

  submitReopenMessage(): void {
    if (this.submittingReopenMsg() || !this.reopenMessage.trim()) return
    this.submittingReopenMsg.set(true)
    this.errorMsg.set(null)

    this.feedback.sendReopenMessage(this.token, this.reopenMessage.trim()).subscribe({
      next: (data) => {
        this.submittingReopenMsg.set(false)
        if (!data.found) { this.errorMsg.set("This link isn't valid anymore."); return }
        this.ticket.set(data.ticket ?? this.ticket())
        this.messages.set(data.messages ?? this.messages())
        this.reopenMessage = ''
        this.reopenMsgSent.set(true)
      },
      error: () => {
        this.submittingReopenMsg.set(false)
        this.errorMsg.set('Something went wrong sending your message — please try again.')
      },
    })
  }

  /** Timeline bodies past this length get truncated with a "Show more" toggle
   *  — the timeline is reference material, not the main box, so it shouldn't
   *  balloon the page (automated system emails especially). */
  private static readonly TRUNCATE_LEN = 220
  private expandedEntries = signal<Set<number>>(new Set())

  isExpanded(i: number): boolean {
    return this.expandedEntries().has(i)
  }

  toggleExpand(i: number): void {
    const next = new Set(this.expandedEntries())
    if (next.has(i)) next.delete(i)
    else next.add(i)
    this.expandedEntries.set(next)
  }

  isTruncatable(body: string | null | undefined): boolean {
    return !!body && body.length > FeedbackViewComponent.TRUNCATE_LEN
  }

  displayBody(entry: TimelineEntry, i: number): string {
    const body = entry.body ?? ''
    if (!this.isTruncatable(body) || this.isExpanded(i)) return body
    return body.slice(0, FeedbackViewComponent.TRUNCATE_LEN).trimEnd() + '…'
  }

  /** Strips a message down to plain, readable text. Ticket messages (especially
   *  the automated "Ticket Created" system one) are full HTML emails — style
   *  blocks, nested tables, etc. — so a naive tag-strip used to leave raw CSS
   *  and dozens of blank lines sitting in the timeline. This removes style/
   *  script blocks entirely, decodes entities, and collapses blank lines. */
  private stripHtml(html: string): string {
    let text = String(html ?? '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<!--[\s\S]*?-->/g, '')
      .replace(/<!DOCTYPE[^>]*>/gi, '')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|div|tr|table|h[1-6]|li)>/gi, '\n')
      .replace(/<[^>]+>/g, '')

    text = text
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&')
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'")

    const lines = text.split('\n').map((l) => l.trim())
    const collapsed: string[] = []
    for (const line of lines) {
      if (line === '' && collapsed[collapsed.length - 1] === '') continue
      collapsed.push(line)
    }
    while (collapsed.length && collapsed[0] === '') collapsed.shift()
    while (collapsed.length && collapsed[collapsed.length - 1] === '') collapsed.pop()

    return collapsed.join('\n').trim()
  }
}