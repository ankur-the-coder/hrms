import { Injectable } from '@angular/core'
import { HttpClient, HttpParams } from '@angular/common/http'
import { environment } from '../../../environments/environment'
import { FeedbackViewData } from '../../core/models/feedback.model'

/**
 * Talks to the public, token-gated /api/feedback/* endpoints. This is the
 * only unauthenticated surface in the app — reached by customers clicking a
 * rating or reopen button in the ticket-closure email — so, unlike every
 * other service here, it never attaches the agent auth headers.
 */
@Injectable({ providedIn: 'root' })
export class FeedbackService {
  private base = environment.apiUrl

  constructor(private http: HttpClient) {}

  view(token: string, rating?: number, reopen?: boolean) {
    let params = new HttpParams().set('t', token)
    if (rating) params = params.set('r', rating)
    if (reopen) params = params.set('reopen', '1')
    return this.http.get<FeedbackViewData>(`${this.base}/api/feedback/view`, { params })
  }

  submit(token: string, data: { likedMost?: string; improve?: string; explanation?: string }) {
    return this.http.post<FeedbackViewData>(`${this.base}/api/feedback/submit`, { t: token, ...data })
  }

  sendReopenMessage(token: string, message: string) {
    return this.http.post<FeedbackViewData>(`${this.base}/api/feedback/reopen-message`, { t: token, message })
  }
}