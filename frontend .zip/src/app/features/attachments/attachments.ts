import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal, computed, AfterViewInit, OnDestroy, ViewChild, ElementRef } from '@angular/core'
import { takeUntilDestroyed } from '@angular/core/rxjs-interop'
import { CommonModule } from '@angular/common'
import { RouterLink } from '@angular/router'
import { Subject } from 'rxjs'
import { debounceTime, distinctUntilChanged, map, switchMap, tap } from 'rxjs/operators'
import { TicketService } from '../../core/services/ticket.service'
import { AttachmentBrowserRow, S3BucketObjectRow, S3BucketAuditSummary } from '../../core/models/ticket.model'
import { environment } from '../../../environments/environment'
import { dateService } from '../../../helper-components/date.service'
// Same preview stack ticket-detail.ts uses for attachments inside a ticket
// thread — reused here so the standalone "Attachments" browser renders
// previews identically with the libraries already present in package.json.
import * as XLSX from 'xlsx'
import * as mammoth from 'mammoth'
import { DomSanitizer, SafeHtml, SafeResourceUrl } from '@angular/platform-browser'

type AttachmentType = '' | 'image' | 'video' | 'document' | 'other'
interface FetchParams { search: string; type: AttachmentType; offset: number; append?: boolean }

type ViewMode = 'tracked' | 'bucket'
type BucketFilter = '' | 'tracked' | 'untracked'
interface BucketFetchParams { search: string; filter: BucketFilter; offset: number; append?: boolean; refresh?: boolean }
type PreviewFile = AttachmentBrowserRow & { key?: string }


/**
 * "Attachments" — own top-level sidebar page (sits below Organizations, see
 * shell/sidebar-nav.ts), separate from any single ticket's thread. Every
 * attachment ever saved to S3 (or, for not-yet-migrated legacy rows, local
 * disk) lives in the `ticket_attachments` table regardless of which ticket
 * it came from — that table is what backs this page (see
 * AttachmentAdminController.list on the backend), NOT a raw S3 bucket
 * listing. That's deliberate: the DB row already carries the file name,
 * size, content type and the ticket/customer it belongs to, so search and
 * "which ticket is this from" come for free — a raw ListObjectsV2 call
 * against the bucket would only return keys, with none of that context.
 */
@Component({
  selector: 'app-attachments',
  imports: [CommonModule, RouterLink],
  templateUrl: './attachments.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AttachmentsComponent implements AfterViewInit, OnDestroy {
  private ticketService = inject(TicketService)
  private destroyRef = inject(DestroyRef)
  private sanitizer = inject(DomSanitizer)

  attachments = signal<AttachmentBrowserRow[]>([])
  loading = signal(false)
  search = ''
  activeType = signal<AttachmentType>('')

  // Tracked-attachments tab now scrolls infinitely instead of paging: 20
  // rows up front, then 20 more each time the sentinel at the bottom of the
  // grid comes into view (see onWindowScroll below). The S3 Bucket tab below
  // still uses `pageSize`/prev-next paging — untouched.
  readonly pageSize = 40
  readonly TRACKED_PAGE_SIZE = 20
  totalRecords = signal(0)
  loadingMore = signal(false)
  hasMore = computed(() => this.attachments().length < this.totalRecords())

  readonly typeTabs: { label: string; value: AttachmentType }[] = [
    { label: 'All', value: '' },
    { label: 'Images', value: 'image' },
    { label: 'Videos', value: 'video' },
    { label: 'Documents', value: 'document' },
    { label: 'Other', value: 'other' },
  ]

  // Selection for bulk delete.
  selectedIds = signal<Set<number>>(new Set())
  selectedCount = computed(() => this.selectedIds().size)

  // Per-row "deleting…" guard, same idea as Organizations' savingOrgIds —
  // stops a double-click firing the same delete twice while it's in flight.
  private deletingIds = new Set<number>()
  deleteError = signal<string | null>(null)

  // Same debounce/switchMap pattern as Organizations — coalesces rapid
  // typing and drops stale in-flight responses so a slow early response
  // can't land after (and overwrite) a newer one.
  private fetch$ = new Subject<FetchParams>()

  constructor() {
    this.fetch$
      .pipe(
        debounceTime(300),
        distinctUntilChanged((a, b) => a.search === b.search && a.type === b.type && a.offset === b.offset),
        tap(p => { if (p.append) this.loadingMore.set(true); else this.loading.set(true) }),
        switchMap(p => this.ticketService.getAllAttachments(p.offset, this.TRACKED_PAGE_SIZE, p.search, p.type).pipe(map(r => ({ r, append: !!p.append })))),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: ({ r, append }: any) => {
          const rows: AttachmentBrowserRow[] = r?.data ?? []
          // Append for a scroll-triggered page; replace for a fresh search/
          // type/initial load (offset 0, append undefined).
          this.attachments.update(list => append ? [...list, ...rows] : rows)
          this.totalRecords.set(Number(r?.totalRecords ?? 0))
          this.loading.set(false)
          this.loadingMore.set(false)
        },
        error: () => { this.loading.set(false); this.loadingMore.set(false) },
      })

    this.fetch$.next({ search: '', type: '', offset: 0 })

    // NOTE: infinite-scroll triggering itself lives in ngAfterViewInit
    // below (IntersectionObserver on #scrollSentinel) — see the comment
    // there for why this replaced a `window` scroll listener.

    this.bucketFetch$
      .pipe(
        debounceTime(300),
        distinctUntilChanged((a, b) => a.search === b.search && a.filter === b.filter && a.offset === b.offset && !a.refresh && !b.refresh),
        tap(p => { if (p.append) this.bucketLoadingMore.set(true); else this.bucketLoading.set(true) }),
        switchMap(p => this.ticketService.getBucketAudit(p.offset, this.pageSize, p.search, p.filter, p.refresh).pipe(map(r => ({ r, append: !!p.append })))),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: ({ r, append }: any) => {
          const rows = r?.data ?? []
          this.bucketRows.update(list => append ? [...list, ...rows] : rows)
          this.bucketTotalRecords.set(Number(r?.totalRecords ?? 0))
          this.bucketSummary.set(r?.summary ?? null)
          this.bucketLoading.set(false)
          this.bucketLoadingMore.set(false)
          this.bucketError.set(null)
        },
        error: () => { this.bucketLoading.set(false); this.bucketLoadingMore.set(false); this.bucketError.set('Failed to load S3 bucket listing — please try again.') },
      })
  }

  // ── View mode toggle ─────────────────────────────────────────────────
  viewMode = signal<ViewMode>('tracked')

  setViewMode(mode: ViewMode) {
    if (mode === this.viewMode()) return
    this.viewMode.set(mode)
    // First switch into bucket mode triggers the initial fetch — subsequent
    // switches just re-show what's already loaded (no need to re-walk S3).
    if (mode === 'bucket' && !this.bucketRows().length && !this.bucketLoading()) {
      this.bucketFetch$.next({ search: this.bucketSearch, filter: this.bucketFilter(), offset: 0 })
    }
  }

  // ── S3 bucket audit state ───────────────────────────────────────────
  // Independent of the tracked-attachments state above: this reflects the
  // raw bucket contents (GET /admin/attachments/bucket-audit), not
  // ticket_attachments rows.
  bucketRows = signal<S3BucketObjectRow[]>([])
  bucketSummary = signal<S3BucketAuditSummary | null>(null)
  bucketLoading = signal(false)
  bucketLoadingMore = signal(false)
  bucketError = signal<string | null>(null)
  bucketSearch = ''
  bucketFilter = signal<BucketFilter>('')
  bucketTotalRecords = signal(0)
  bucketHasMore = computed(() => this.bucketRows().length < this.bucketTotalRecords())
  private bucketFetch$ = new Subject<BucketFetchParams>()

  onBucketSearch(e: Event) {
    this.bucketSearch = (e.target as HTMLInputElement).value
    this.bucketRows.set([])
    this.bucketFetch$.next({ search: this.bucketSearch, filter: this.bucketFilter(), offset: 0 })
  }

  setBucketFilter(filter: BucketFilter) {
    if (filter === this.bucketFilter()) return
    this.bucketFilter.set(filter)
    this.bucketRows.set([])
    this.bucketFetch$.next({ search: this.bucketSearch, filter, offset: 0 })
  }

  refreshBucketAudit() {
    // Bypasses the backend's 5-minute cache — full S3 walk, so don't spam this.
    this.bucketRows.set([])
    this.bucketFetch$.next({ search: this.bucketSearch, filter: this.bucketFilter(), offset: 0, refresh: true })
  }

  loadMoreBucket() {
    if (this.bucketLoading() || this.bucketLoadingMore() || !this.bucketHasMore()) return
    this.bucketFetch$.next({
      search: this.bucketSearch,
      filter: this.bucketFilter(),
      offset: this.bucketRows().length,
      append: true,
    })
  }

  formatBytes(bytes?: number | null): string {
    if (!bytes || bytes <= 0) return '0 B'
    const units = ['B', 'KB', 'MB', 'GB', 'TB']
    const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)))
    const value = bytes / Math.pow(1024, i)
    return `${i === 0 ? value : value.toFixed(2)} ${units[i]}`
  }

  onSearch(e: Event) {
    this.search = (e.target as HTMLInputElement).value
    this.attachments.set([])
    this.selectedIds.set(new Set())
    this.fetch$.next({ search: this.search, type: this.activeType(), offset: 0 })
  }

  setType(type: AttachmentType) {
    if (type === this.activeType()) return
    this.activeType.set(type)
    this.attachments.set([])
    this.selectedIds.set(new Set())
    this.fetch$.next({ search: this.search, type, offset: 0 })
  }

  // Fetches the next 20 rows and appends them — triggered by the
  // IntersectionObserver in ngAfterViewInit below.
  loadMore() {
    if (this.loading() || this.loadingMore() || !this.hasMore()) return
    this.fetch$.next({ search: this.search, type: this.activeType(), offset: this.attachments().length, append: true })
  }

  // ── Infinite scroll trigger ─────────────────────────────────────────
  // Previously a `window` scroll listener — but this app's actual
  // scrolling element is app-shell's <main> (overflow-y-auto), not
  // `window`/document.body (see LayoutService's note on scrollLocked).
  // `window.scrollY` never moves, so the old "near bottom" check never
  // tripped and neither tab ever loaded a second page. An
  // IntersectionObserver instead watches a 1px sentinel at the bottom of
  // whichever tab's list is rendered — it fires correctly regardless of
  // which ancestor element is actually scrolling, since intersection is
  // computed against the viewport, not against any particular scroll
  // container.
  @ViewChild('scrollSentinel') private sentinelRef?: ElementRef<HTMLDivElement>
  private sentinelObserver?: IntersectionObserver

  ngAfterViewInit() {
    this.sentinelObserver = new IntersectionObserver(
      (entries) => {
        if (!entries.some(e => e.isIntersecting)) return
        if (this.viewMode() === 'tracked') this.loadMore()
        else this.loadMoreBucket()
      },
      { rootMargin: '400px 0px' }, // start fetching ~400px before the sentinel is actually on-screen
    )
    if (this.sentinelRef) this.sentinelObserver.observe(this.sentinelRef.nativeElement)
  }

  ngOnDestroy() {
    this.sentinelObserver?.disconnect()
  }

  // ── Selection ────────────────────────────────────────────────────────
  isSelected(id: number) { return this.selectedIds().has(id) }

  toggleSelect(id: number) {
    const next = new Set(this.selectedIds())
    if (next.has(id)) next.delete(id); else next.add(id)
    this.selectedIds.set(next)
  }

  toggleSelectAll() {
    const all = this.attachments()
    const next = new Set(this.selectedIds())
    const allSelected = all.length > 0 && all.every(a => next.has(a.id))
    if (allSelected) {
      all.forEach(a => next.delete(a.id))
    } else {
      all.forEach(a => next.add(a.id))
    }
    this.selectedIds.set(next)
  }

  allOnPageSelected(): boolean {
    const all = this.attachments()
    return all.length > 0 && all.every(a => this.selectedIds().has(a.id))
  }

  clearSelection() { this.selectedIds.set(new Set()) }

  // ── Delete ───────────────────────────────────────────────────────────
  isDeleting(id: number) { return this.deletingIds.has(id) }

  // ── Custom delete-confirm modal (replaces window.confirm) ─────────────
  confirmDialog = signal<{ title: string; message: string; confirmLabel: string; onConfirm: () => void } | null>(null)

  confirmDialogAccept() {
    const dlg = this.confirmDialog()
    if (!dlg) return
    dlg.onConfirm()
    this.confirmDialog.set(null)
  }

  confirmDialogCancel() {
    this.confirmDialog.set(null)
  }

  deleteOne(a: AttachmentBrowserRow) {
    if (this.isDeleting(a.id)) return
    this.confirmDialog.set({
      title: 'Delete attachment',
      message: `Delete "${a.file_name}"? This removes it from storage permanently.`,
      confirmLabel: 'Delete',
      onConfirm: () => this.runDelete([a.id]),
    })
  }

  deleteSelected() {
    const ids = Array.from(this.selectedIds())
    if (!ids.length) return
    this.confirmDialog.set({
      title: ids.length > 1 ? 'Delete attachments' : 'Delete attachment',
      message: `Delete ${ids.length} selected attachment${ids.length > 1 ? 's' : ''}? This removes ${ids.length > 1 ? 'them' : 'it'} from storage permanently.`,
      confirmLabel: `Delete${ids.length > 1 ? ` (${ids.length})` : ''}`,
      onConfirm: () => this.runDelete(ids),
    })
  }

  private runDelete(ids: number[]) {
    this.deleteError.set(null)
    ids.forEach(id => this.deletingIds.add(id))
    this.ticketService.deleteAttachments(ids).subscribe({
      next: (r: any) => {
        const deleted: number[] = r?.deleted ?? []
        const failed: { id: number; error: string }[] = r?.failed ?? []
        if (deleted.length) {
          this.attachments.update(list => list.filter(a => !deleted.includes(a.id)))
          this.totalRecords.update(n => Math.max(0, n - deleted.length))
          this.selectedIds.update(set => {
            const next = new Set(set)
            deleted.forEach(id => next.delete(id))
            return next
          })
        }
        if (failed.length) {
          this.deleteError.set(`Couldn't delete ${failed.length} file${failed.length > 1 ? 's' : ''} — ${failed[0].error}`)
        }
        ids.forEach(id => this.deletingIds.delete(id))
      },
      error: () => {
        this.deleteError.set('Delete failed — please try again.')
        ids.forEach(id => this.deletingIds.delete(id))
      },
    })
  }

  // ── Display helpers ─────────────────────────────────────────────────
  attachmentUrl(a: AttachmentBrowserRow) {
    if (/^https?:\/\//i.test(a.storage_path)) return a.storage_path
    return `${environment.apiUrl}/uploads/${a.storage_path}`
  }

  isImage(a: AttachmentBrowserRow): boolean {
    if (a.content_type?.startsWith('image/')) return true
    return /\.(jpg|jpeg|jfif|png|gif|webp|svg|bmp|tif|tiff|heic|heif)$/i.test(a.file_name || '')
  }

  isVideo(a: AttachmentBrowserRow): boolean {
    if (a.content_type?.startsWith('video/')) return true
    return /\.(mp4|webm|ogg|mov|m4v)$/i.test(a.file_name || '')
  }

  fileExt(fileName?: string): string {
    return (fileName || '').split('.').pop()?.toUpperCase().slice(0, 4) || 'FILE'
  }

  fileSize(bytes?: number | null) {
    if (!bytes) return ''
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  formatDate(d: string) {
    return dateService.explicitFormatDate(d)
  }

  // summary.cachedAt is a raw epoch-ms number (Date.now() from the backend
  // cache), not an ISO string like everything else here — formatDate()
  // expects the latter, so this gets its own small helper instead of
  // (mis)reusing that one.
  formatEpochMs(ms: number): string {
    return new Date(ms).toLocaleString()
  }

  // date + time this row was saved (ticket_attachments.created_at) — shown
  // on each card. Reuses the app's house date formatter and appends a
  // local time-of-day, since explicitFormatDate() only gives the date part.
  formatSavedAt(d?: string | null): string {
    if (!d) return ''
    const datePart = dateService.explicitFormatDate(d)
    const t = new Date(d)
    if (isNaN(t.getTime())) return datePart
    const timePart = t.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
    return datePart ? `${datePart} · ${timePart}` : timePart
  }

  // ══════════════════════════════════════════════════════════════════════
  // Full-view preview modal — same behavior/libraries as the in-ticket
  // attachment preview (ticket-detail.ts): image, Excel (xlsx/xls/csv via
  // the `xlsx` package), Word .docx (via `mammoth`), video, and now also
  // PDF (native browser rendering, no library needed), SQL/plain-text
  // files (fetched and shown as text, no library needed), and a clean
  // open/download fallback for compressed archives and unknown formats.
  // ══════════════════════════════════════════════════════════════════════

  selectedAttachment = signal<PreviewFile | null>(null)

  excelData = signal<{ sheetNames: string[]; activeSheet: string; rows: any[][] } | null>(null)
  isLoadingExcel = signal(false)
  excelError = signal<string | null>(null)
  private workbookRef: XLSX.WorkBook | null = null

  docxHtml = signal<SafeHtml | null>(null)
  isLoadingDocx = signal(false)
  docxError = signal<string | null>(null)

  textPreview = signal<string | null>(null)
  textTruncated = signal(false)
  isLoadingText = signal(false)
  textError = signal<string | null>(null)

  private static readonly MAX_TEXT_PREVIEW_CHARS = 200_000

  // isImage(a) / isVideo(a) already exist above (used by the grid
  // thumbnails) — the preview modal reuses those instead of redefining them.

  videoMimeType(fileName?: string): string {
    const ext = (fileName || '').split('.').pop()?.toLowerCase()
    switch (ext) {
      case 'webm': return 'video/webm'
      case 'ogg': return 'video/ogg'
      case 'mov': return 'video/quicktime'
      case 'm4v': return 'video/mp4'
      default: return 'video/mp4'
    }
  }

  isExcelFile(fileName?: string): boolean {
    if (!fileName) return false
    return /\.(xlsx|xlsb|xls|csv)$/i.test(fileName)
  }

  // Only .docx (Office Open XML) is supported — mammoth.js can't parse the
  // legacy binary .doc format; those fall through to the generic fallback.
  isDocxFile(fileName?: string): boolean {
    if (!fileName) return false
    return /\.docx$/i.test(fileName)
  }

  isPdfFile(fileName?: string): boolean {
    if (!fileName) return false
    return /\.pdf$/i.test(fileName)
  }

  isSqlFile(fileName?: string): boolean {
    if (!fileName) return false
    return /\.sql$/i.test(fileName)
  }

  // Plain-text formats other than .sql (kept separate so the preview panel
  // can still show a distinct "SQL" label/icon for .sql files). .csv is
  // deliberately excluded here — it's handled by the Excel/xlsx branch.
  isPlainTextFile(fileName?: string): boolean {
    if (!fileName) return false
    return /\.(txt|log|json|md|yml|yaml|xml|ini|conf)$/i.test(fileName)
  }

  isArchiveFile(fileName?: string): boolean {
    if (!fileName) return false
    return /\.(zip|7z|rar|tar|gz|tgz|bz2)$/i.test(fileName)
  }

  pdfSafeUrl(a: AttachmentBrowserRow): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(this.attachmentUrl(a))
  }

  openPreview(a: PreviewFile) {
    this.selectedAttachment.set(a)
    this.excelData.set(null); this.excelError.set(null)
    this.docxHtml.set(null); this.docxError.set(null)
    this.textPreview.set(null); this.textError.set(null); this.textTruncated.set(false)

    const url = this.attachmentUrl(a)
    if (this.isExcelFile(a.file_name)) {
      this.loadExcelPreview(url)
    } else if (this.isDocxFile(a.file_name)) {
      this.loadDocxPreview(url)
    } else if (this.isSqlFile(a.file_name) || this.isPlainTextFile(a.file_name)) {
      this.loadTextPreview(url)
    }
    // Image / video / PDF stream the URL directly, no upfront load needed.
    // .7z / other archives / anything unrecognized fall through to the
    // labeled download card in the template.
  }

  async loadDocxPreview(url: string) {
    this.isLoadingDocx.set(true)
    try {
      let response: Response
      try {
        response = await fetch(url)
      } catch (fetchErr) {
        console.error('[attachments] fetch() threw while loading docx preview — almost always a CORS issue on the storage bucket.', { url, fetchErr })
        throw new Error('Could not load this file for preview. The storage bucket may be missing a CORS rule for this origin.')
      }
      if (!response.ok) {
        console.error('[attachments] docx preview fetch returned a non-OK status', { url, status: response.status, statusText: response.statusText })
        throw new Error(`Failed to load file content (HTTP ${response.status}).`)
      }
      const buffer = await response.arrayBuffer()
      const result = await mammoth.convertToHtml({ arrayBuffer: buffer })
      this.docxHtml.set(this.sanitizer.bypassSecurityTrustHtml(result.value))
    } catch (err: any) {
      this.docxError.set(err?.message || 'Error reading Word document')
    } finally {
      this.isLoadingDocx.set(false)
    }
  }

  async loadExcelPreview(url: string) {
    this.isLoadingExcel.set(true)
    try {
      let response: Response
      try {
        response = await fetch(url)
      } catch (fetchErr) {
        console.error('[attachments] fetch() threw while loading preview file — almost always a CORS issue on the storage bucket.', { url, fetchErr })
        throw new Error('Could not load this file for preview. The storage bucket may be missing a CORS rule for this origin.')
      }
      if (!response.ok) {
        console.error('[attachments] preview fetch returned a non-OK status', { url, status: response.status, statusText: response.statusText })
        throw new Error(`Failed to load file content (HTTP ${response.status}).`)
      }
      const buffer = await response.arrayBuffer()
      this.workbookRef = XLSX.read(buffer, { type: 'array' })
      if (this.workbookRef.SheetNames.length > 0) {
        this.selectSheet(this.workbookRef.SheetNames[0])
      }
    } catch (err: any) {
      this.excelError.set(err?.message || 'Error reading Excel file')
    } finally {
      this.isLoadingExcel.set(false)
    }
  }

  selectSheet(sheetName: string) {
    if (!this.workbookRef) return
    const worksheet = this.workbookRef.Sheets[sheetName]
    const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' }) as any[][]
    this.excelData.set({ sheetNames: this.workbookRef.SheetNames, activeSheet: sheetName, rows })
  }

  // SQL dumps / plain-text files — no parsing library needed, just fetched
  // and shown verbatim in a monospace block. Large files are truncated so
  // one huge .sql dump can't freeze the tab; download link covers the rest.
  async loadTextPreview(url: string) {
    this.isLoadingText.set(true)
    try {
      let response: Response
      try {
        response = await fetch(url)
      } catch (fetchErr) {
        console.error('[attachments] fetch() threw while loading text preview — almost always a CORS issue on the storage bucket.', { url, fetchErr })
        throw new Error('Could not load this file for preview. The storage bucket may be missing a CORS rule for this origin.')
      }
      if (!response.ok) {
        console.error('[attachments] text preview fetch returned a non-OK status', { url, status: response.status, statusText: response.statusText })
        throw new Error(`Failed to load file content (HTTP ${response.status}).`)
      }
      let text = await response.text()
      if (text.length > AttachmentsComponent.MAX_TEXT_PREVIEW_CHARS) {
        text = text.slice(0, AttachmentsComponent.MAX_TEXT_PREVIEW_CHARS)
        this.textTruncated.set(true)
      }
      this.textPreview.set(text)
    } catch (err: any) {
      this.textError.set(err?.message || 'Error reading file')
    } finally {
      this.isLoadingText.set(false)
    }
  }

  closePreview() {
    this.selectedAttachment.set(null)
    this.docxHtml.set(null); this.docxError.set(null)
    this.excelData.set(null); this.excelError.set(null)
    this.textPreview.set(null); this.textError.set(null); this.textTruncated.set(false)
  }

  bucketPreviewRow(o: S3BucketObjectRow): PreviewFile {
    return {
      id: 0,
      ticket_id: o.ticketId,
      message_id: null,
      file_name: o.fileName,
      content_type: o.contentType ?? null,
      size: o.size,
      storage_path: o.url || o.key,
      created_at: o.lastModified,
      key: o.key,
    }
  }
}