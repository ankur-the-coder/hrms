import { Component, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { TicketService } from '../../core/services/ticket.service'

/**
 * Contacts (`ticket_contacts`) — derived ourselves from inbound tickets.
 * Organizations now live on their own page/route (see
 * features/organizations) instead of as a tab here.
 *
 * Marking a contact "High Priority" makes every open/incoming ticket from
 * them default to priority=high going forward (see
 * TicketService.resolveDefaultPriority) — it does not touch existing
 * tickets.
 */
@Component({
  selector: 'app-contacts',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './contacts.html',
})
export class Contacts {
  private ticketService = inject(TicketService)
  contacts = signal<any[]>([])
  loading = signal(false)
  search = ''

  // Per-row "saving…" guard so a double-click can't fire the toggle twice
  // for the same contact while the first request is still in flight.
  private savingContactIds = new Set<number>()

  constructor() { this.fetch() }

  onSearch(e: Event) {
    this.search = (e.target as HTMLInputElement).value
    this.fetch()
  }

  initials(name: string) {
    return name?.split(' ').map((p: string) => p[0]).slice(0, 2).join('').toUpperCase() || '?'
  }

  isSavingContact(id: number) { return this.savingContactIds.has(id) }

  toggleContactPriority(c: any) {
    if (this.isSavingContact(c.id)) return
    const next = !c.is_high_priority
    this.savingContactIds.add(c.id)
    this.ticketService.setContactPriority(c.id, next).subscribe({
      next: () => {
        this.contacts.update(list => list.map(x => x.id === c.id ? { ...x, is_high_priority: next ? 1 : 0 } : x))
        this.savingContactIds.delete(c.id)
      },
      error: () => { this.savingContactIds.delete(c.id) },
    })
  }

  private fetch() {
    this.loading.set(true)
    this.ticketService.getContacts(0, 100, this.search).subscribe({
      next: (r: any) => {
        this.contacts.set(r)
        this.loading.set(false)
      },
      error: () => { this.loading.set(false) },
    })
  }
}