import { Component, inject, signal, computed, OnInit } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { ReportService, Report360Data, ReportScheduleItem } from '../../core/services/report.service'
import { AgentService } from '../../core/services/agent.service'
import { Agent } from '../../core/models/ticket.model'
import { DialogService } from '../../core/services/Dialog-services/dialog.services'

type ReportTab = 'overview' | 'agents' | 'channels' | 'csat' | 'organizations' | 'schedules'
type DatePreset = 'today' | 'yesterday' | '7d' | '14d' | '30d' | 'this_month' | 'last_month' | 'custom'

@Component({
  selector: 'app-reports-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reports-dashboard.html',
  styleUrl: './reports-dashboard.css',
})
export class ReportsDashboard implements OnInit {
  private reportService = inject(ReportService)
  private agentService = inject(AgentService)
  private dialog = inject(DialogService)
  readonly Math = Math

  // ── Navigation & Tabs ─────────────────────────────────────────────────────
  activeTab = signal<ReportTab>('overview')

  // ── Filters & Time Window ─────────────────────────────────────────────────
  datePreset = signal<DatePreset>('7d')
  customStartDate = ''
  customEndDate = ''
  selectedSource = signal<string>('all')
  selectedPriority = signal<string>('all')
  selectedAgentId = signal<string>('all')
  selectedStatus = signal<string>('all')

  agentsList = signal<Agent[]>([])

  // ── State ─────────────────────────────────────────────────────────────────
  loading = signal<boolean>(true)
  exporting = signal<boolean>(false)
  reportData = signal<Report360Data | null>(null)

  // ── Schedules State ───────────────────────────────────────────────────────
  schedules = signal<ReportScheduleItem[]>([])
  schedulesLoading = signal<boolean>(false)
  showScheduleModal = signal<boolean>(false)
  editingScheduleId = signal<number | null>(null)
  scheduleSaving = signal<boolean>(false)
  runningScheduleId = signal<number | null>(null)

  scheduleForm = {
    name: '',
    recipients: '',
    frequency: 'weekly' as 'daily' | 'weekly' | 'weekday' | 'monthly',
    day_of_week: 1, // 1 = Monday
    time_of_day: '09:00',
    timezone: 'Asia/Kolkata',
    date_range: 'last_7_days' as 'last_7_days' | 'last_14_days' | 'last_30_days' | 'yesterday' | 'last_week' | 'last_month',
    is_active: true,
  }

  daysOfWeek = [
    { value: 1, label: 'Monday' },
    { value: 2, label: 'Tuesday' },
    { value: 3, label: 'Wednesday' },
    { value: 4, label: 'Thursday' },
    { value: 5, label: 'Friday' },
    { value: 6, label: 'Saturday' },
    { value: 0, label: 'Sunday' },
  ]

  // ── Hover interaction on trend chart ──────────────────────────────────────
  hoveredTrendIndex = signal<number | null>(null)
  hoveredTrend = computed(() => {
    const idx = this.hoveredTrendIndex()
    if (idx === null) return null
    return this.reportData()?.dailyTrends?.[idx] || null
  })

  maxHourlyCount = computed(() => {
    const hours = this.reportData()?.hourlyHeatmap || []
    return Math.max(1, ...hours.map(h => h.count))
  })

  // ── Smooth Spline Generator (Cubic Bézier Curve) ──────────────────────────
  private getSmoothPath(points: { x: number; y: number }[]): string {
    if (!points.length) return ''
    if (points.length === 1) return `M ${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)}`
    if (points.length === 2) {
      return `M ${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)} L ${points[1].x.toFixed(1)} ${points[1].y.toFixed(1)}`
    }

    let path = `M ${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)}`
    const tension = 0.22

    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[i > 0 ? i - 1 : 0]
      const p1 = points[i]
      const p2 = points[i + 1]
      const p3 = points[i + 2 < points.length ? i + 2 : points.length - 1]

      const cp1x = p1.x + (p2.x - p0.x) * tension
      const cp1y = p1.y + (p2.y - p0.y) * tension
      const cp2x = p2.x - (p3.x - p1.x) * tension
      const cp2y = p2.y - (p3.y - p1.y) * tension

      path += ` C ${cp1x.toFixed(1)} ${cp1y.toFixed(1)}, ${cp2x.toFixed(1)} ${cp2y.toFixed(1)}, ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`
    }
    return path
  }

  private getSmoothAreaPath(points: { x: number; y: number }[], baseY: number): string {
    if (points.length < 2) return ''
    const line = this.getSmoothPath(points)
    const first = points[0]
    const last = points[points.length - 1]
    return `${line} L ${last.x.toFixed(1)} ${baseY} L ${first.x.toFixed(1)} ${baseY} Z`
  }

  // ── High Quality Trend Chart Layout ───────────────────────────────────────
  chartLayout = computed(() => {
    const trends = this.reportData()?.dailyTrends || []
    const leftX = 46
    const rightX = 605
    const topY = 24
    const baseY = 215
    const chartW = rightX - leftX
    const chartH = baseY - topY

    if (!trends.length) {
      return {
        ticks: [],
        xAxisLabels: [],
        createdPath: '',
        closedPath: '',
        reopenedPath: '',
        closedArea: '',
        createdArea: '',
        pointsCreated: [] as any[],
        pointsClosed: [] as any[],
        pointsReopened: [] as any[],
        niceMax: 10,
        baseY,
        leftX,
        rightX,
      }
    }

    const rawMax = Math.max(1, ...trends.flatMap(d => [d.created, d.closed, d.reopened]))
    let niceMax = Math.ceil(rawMax * 1.1)
    if (niceMax <= 8) niceMax = 8
    else if (niceMax <= 20) niceMax = Math.ceil(niceMax / 4) * 4
    else if (niceMax <= 50) niceMax = Math.ceil(niceMax / 5) * 5
    else if (niceMax <= 100) niceMax = Math.ceil(niceMax / 10) * 10
    else niceMax = Math.ceil(niceMax / 25) * 25

    const tickCount = 4
    const ticks: { val: number; y: number }[] = []
    for (let i = 0; i <= tickCount; i++) {
      const val = Math.round((niceMax / tickCount) * i)
      const y = baseY - (val / niceMax) * chartH
      ticks.push({ val, y })
    }

    const n = trends.length
    const stepX = n > 1 ? chartW / (n - 1) : chartW

    const pointsCreated = trends.map((d, i) => ({
      x: leftX + i * stepX,
      y: baseY - (d.created / niceMax) * chartH,
      val: d.created,
      data: d,
      index: i,
    }))

    const pointsClosed = trends.map((d, i) => ({
      x: leftX + i * stepX,
      y: baseY - (d.closed / niceMax) * chartH,
      val: d.closed,
      data: d,
      index: i,
    }))

    const pointsReopened = trends.map((d, i) => ({
      x: leftX + i * stepX,
      y: baseY - (d.reopened / niceMax) * chartH,
      val: d.reopened,
      data: d,
      index: i,
    }))

    const createdPath = this.getSmoothPath(pointsCreated)
    const closedPath = this.getSmoothPath(pointsClosed)
    const reopenedPath = this.getSmoothPath(pointsReopened)

    const closedArea = this.getSmoothAreaPath(pointsClosed, baseY)
    const createdArea = this.getSmoothAreaPath(pointsCreated, baseY)

    const labelStep = Math.max(1, Math.floor(n / 6))
    const xAxisLabels = trends.map((d, i) => ({
      x: leftX + i * stepX,
      label: d.label,
      show: i === 0 || i === n - 1 || i % labelStep === 0,
    })).filter(l => l.show)

    return {
      ticks,
      xAxisLabels,
      createdPath,
      closedPath,
      reopenedPath,
      closedArea,
      createdArea,
      pointsCreated,
      pointsClosed,
      pointsReopened,
      niceMax,
      baseY,
      leftX,
      rightX,
    }
  })

  ngOnInit() {
    this.fetchAgents()
    this.refreshReport()
    this.loadSchedules()
  }

  fetchAgents() {
    this.agentService.list().subscribe({
      next: (res: any) => this.agentsList.set(Array.isArray(res) ? res : []),
      error: () => {},
    })
  }

  setPreset(preset: DatePreset) {
    this.datePreset.set(preset)
    if (preset !== 'custom') {
      this.refreshReport()
    }
  }

  getDateRangeForPreset(): { start: string; end: string } {
    const now = new Date()
    const start = new Date()

    switch (this.datePreset()) {
      case 'today':
        start.setHours(0, 0, 0, 0)
        break
      case 'yesterday':
        start.setDate(start.getDate() - 1)
        start.setHours(0, 0, 0, 0)
        now.setDate(now.getDate() - 1)
        now.setHours(23, 59, 59, 999)
        break
      case '14d':
        start.setDate(start.getDate() - 14)
        start.setHours(0, 0, 0, 0)
        break
      case '30d':
        start.setDate(start.getDate() - 30)
        start.setHours(0, 0, 0, 0)
        break
      case 'this_month':
        start.setDate(1)
        start.setHours(0, 0, 0, 0)
        break
      case 'last_month':
        start.setMonth(start.getMonth() - 1)
        start.setDate(1)
        start.setHours(0, 0, 0, 0)
        now.setDate(0)
        now.setHours(23, 59, 59, 999)
        break
      case 'custom':
        if (this.customStartDate && this.customEndDate) {
          return {
            start: new Date(this.customStartDate).toISOString(),
            end: new Date(this.customEndDate + 'T23:59:59').toISOString(),
          }
        }
        start.setDate(start.getDate() - 7)
        break
      case '7d':
      default:
        start.setDate(start.getDate() - 7)
        start.setHours(0, 0, 0, 0)
        break
    }

    return {
      start: start.toISOString(),
      end: now.toISOString(),
    }
  }

  refreshReport() {
    this.loading.set(true)
    const range = this.getDateRangeForPreset()

    this.reportService.get360Report({
      startDate: range.start,
      endDate: range.end,
      source: this.selectedSource(),
      priority: this.selectedPriority(),
      agentId: this.selectedAgentId(),
      status: this.selectedStatus(),
    }).subscribe({
      next: (res) => {
        this.loading.set(false)
        if (res?.data) {
          this.reportData.set(res.data)
        }
      },
      error: (err) => {
        this.loading.set(false)
        console.error('Failed to load 360 report:', err)
      },
    })
  }

  exportReportCsv() {
    this.exporting.set(true)
    const range = this.getDateRangeForPreset()

    this.reportService.exportCsv({
      startDate: range.start,
      endDate: range.end,
      source: this.selectedSource(),
      priority: this.selectedPriority(),
      agentId: this.selectedAgentId(),
      status: this.selectedStatus(),
    }).subscribe({
      next: (blob: any) => {
        this.exporting.set(false)
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `ubidesk-report-${new Date().toISOString().slice(0, 10)}.csv`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        window.URL.revokeObjectURL(url)
      },
      error: () => {
        this.exporting.set(false)
        this.dialog.alert('Failed to export CSV report. Please try again.')
      },
    })
  }

  // ── Schedules Management ──────────────────────────────────────────────────
  loadSchedules() {
    this.schedulesLoading.set(true)
    this.reportService.getSchedules().subscribe({
      next: (res) => {
        this.schedulesLoading.set(false)
        this.schedules.set(res.schedules || [])
      },
      error: (err) => {
        this.schedulesLoading.set(false)
        console.error('Error fetching schedules:', err)
      },
    })
  }

  openCreateSchedule() {
    this.editingScheduleId.set(null)
    this.scheduleForm = {
      name: '',
      recipients: '',
      frequency: 'weekly',
      day_of_week: 1,
      time_of_day: '09:00',
      timezone: 'Asia/Kolkata',
      date_range: 'last_7_days',
      is_active: true,
    }
    this.showScheduleModal.set(true)
  }

  openEditSchedule(item: ReportScheduleItem) {
    this.editingScheduleId.set(item.id)
    this.scheduleForm = {
      name: item.name,
      recipients: item.recipients,
      frequency: item.frequency,
      day_of_week: item.day_of_week ?? 1,
      time_of_day: (item.time_of_day || '09:00').slice(0, 5),
      timezone: item.timezone || 'Asia/Kolkata',
      date_range: (item.date_range as any) || 'last_7_days',
      is_active: Boolean(item.is_active),
    }
    this.showScheduleModal.set(true)
  }

  closeScheduleModal() {
    this.showScheduleModal.set(false)
  }

  saveSchedule() {
    if (!this.scheduleForm.name.trim() || !this.scheduleForm.recipients.trim()) {
      this.dialog.alert('Schedule name and recipient email(s) are required.')
      return
    }

    this.scheduleSaving.set(true)
    const editingId = this.editingScheduleId()

    const req$ = editingId
      ? this.reportService.updateSchedule(editingId, this.scheduleForm)
      : this.reportService.createSchedule(this.scheduleForm)

    req$.subscribe({
      next: () => {
        this.scheduleSaving.set(false)
        this.showScheduleModal.set(false)
        this.loadSchedules()
        this.dialog.alert(editingId ? 'Report schedule updated!' : 'Report schedule created successfully!')
      },
      error: (err) => {
        this.scheduleSaving.set(false)
        const msg = err?.error?.error || err?.message || 'Failed to save schedule.'
        this.dialog.alert(`Error: ${msg}`)
      },
    })
  }

  toggleScheduleActive(item: ReportScheduleItem) {
    const updatedState = !item.is_active
    this.reportService.updateSchedule(item.id, { is_active: updatedState }).subscribe({
      next: () => this.loadSchedules(),
      error: () => this.dialog.alert('Failed to update schedule status.'),
    })
  }

  async deleteSchedule(item: ReportScheduleItem) {
    const ok = await this.dialog.confirm({
      title: 'Delete Report Schedule',
      message: `Are you sure you want to delete "${item.name}"? This action cannot be undone.`,
      confirmLabel: 'Delete Schedule',
      variant: 'danger',
    })
    if (!ok) return

    this.reportService.deleteSchedule(item.id).subscribe({
      next: () => {
        this.loadSchedules()
      },
      error: () => this.dialog.alert('Failed to delete schedule.'),
    })
  }

  runScheduleNow(item: ReportScheduleItem) {
    if (this.runningScheduleId() === item.id) return
    this.runningScheduleId.set(item.id)

    this.reportService.runScheduleNow(item.id).subscribe({
      next: (res) => {
        this.runningScheduleId.set(null)
        this.loadSchedules()
        this.dialog.alert(`Report dispatched successfully! Sent to ${res.recipients.join(', ')}.`)
      },
      error: (err) => {
        this.runningScheduleId.set(null)
        const msg = err?.error?.error || err?.message || 'Failed to trigger schedule dispatch.'
        this.dialog.alert(`Delivery Error: ${msg}`)
      },
    })
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  formatDuration(seconds: number | null | undefined): string {
    if (!seconds || seconds <= 0) return '0m'
    const h = Math.floor(seconds / 3600)
    const m = Math.floor((seconds % 3600) / 60)
    if (h > 0) return `${h}h ${m}m`
    return `${m}m`
  }

  sourceColor(source: string): string {
    const colors: Record<string, string> = {
      email: 'bg-indigo-500',
      whatsapp: 'bg-emerald-500',
      phone: 'bg-amber-500',
      manual: 'bg-slate-400',
    }
    return colors[source] || 'bg-slate-400'
  }

  sourceBadgeClass(source: string): string {
    const map: Record<string, string> = {
      email: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      whatsapp: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      phone: 'bg-amber-50 text-amber-700 border-amber-200',
      manual: 'bg-slate-50 text-slate-700 border-slate-200',
    }
    return map[source] || 'bg-slate-50 text-slate-700 border-slate-200'
  }

  channelDonutGradient(): string {
    const channels = this.reportData()?.channels || []
    if (!channels.length) return 'conic-gradient(#e2e8f0 0deg 360deg)'

    const total = channels.reduce((s, c) => s + c.total, 0) || 1
    const colorMap: Record<string, string> = {
      email: '#6366f1',
      whatsapp: '#10b981',
      phone: '#f59e0b',
      manual: '#94a3b8',
    }

    let acc = 0
    const stops = channels.map((c) => {
      const start = (acc / total) * 360
      acc += c.total
      const end = (acc / total) * 360
      const col = colorMap[c.source] || '#94a3b8'
      return `${col} ${start.toFixed(2)}deg ${end.toFixed(2)}deg`
    })

    return `conic-gradient(${stops.join(', ')})`
  }

  priorityDonutGradient(): string {
    const priorities = this.reportData()?.priorities || []
    if (!priorities.length) return 'conic-gradient(#e2e8f0 0deg 360deg)'

    const total = priorities.reduce((s, p) => s + p.total, 0) || 1
    const colorMap: Record<string, string> = {
      high: '#ef4444',
      medium: '#f59e0b',
      low: '#3b82f6',
    }

    let acc = 0
    const stops = priorities.map((p) => {
      const start = (acc / total) * 360
      acc += p.total
      const end = (acc / total) * 360
      const col = colorMap[p.priority] || '#94a3b8'
      return `${col} ${start.toFixed(2)}deg ${end.toFixed(2)}deg`
    })

    return `conic-gradient(${stops.join(', ')})`
  }

  getRatingEmoji(rating: number): string {
    const emojis: Record<number, string> = {
      5: '🤩',
      4: '🙂',
      3: '😐',
      2: '🙁',
      1: '😡',
    }
    return emojis[rating] || '⭐'
  }

  getRatingLabel(rating: number): string {
    const labels: Record<number, string> = {
      5: 'Very Satisfied',
      4: 'Satisfied',
      3: 'Neutral',
      2: 'Unsatisfied',
      1: 'Very Unsatisfied',
    }
    return labels[rating] || `Rating ${rating}`
  }

  getDayLabel(dayNumber: number | undefined): string {
    const found = this.daysOfWeek.find(d => d.value === dayNumber)
    return found ? found.label : 'Monday'
  }
}