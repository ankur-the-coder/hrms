import { Component, computed, effect, inject, signal, DestroyRef } from '@angular/core'
import { CommonModule } from '@angular/common'
import { Router, RouterLink } from '@angular/router'
import { Subject, of } from 'rxjs'
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators'
import { takeUntilDestroyed } from '@angular/core/rxjs-interop'
import { TicketService } from '../core/services/ticket.service'
import { ChartsOverview, DashboardStats, PendingTicketRow, Ticket } from '../core/models/ticket.model'
import { TicketSocketService } from '../core/services/ticket-socket.services'
import { AuthService } from '../service/auth.service'
import { CreateTicketModal } from "./tickets/create-ticket-modal/create-ticket-modal";

const DAY_OPTIONS = [7, 14, 30, 45, 60] as const

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, CreateTicketModal],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class DashboardComponent {
  private ticketService = inject(TicketService)
  private ticketSocket  = inject(TicketSocketService)
  private router = inject(Router)
  private destroyRef = inject(DestroyRef)
  auth = inject(AuthService)

  // ── Header "Search tickets, users, contacts..." box ──────────────────
  // Was a bare <input> with no binding at all — typing did nothing because
  // nothing was ever wired up to it. Debounced (300ms) + switchMap (so a
  // slow early keystroke's response can't land after and overwrite a
  // newer one), same pattern as ticket-list/organizations/attachments
  // search elsewhere in this app. Matches by name, phone, email, ticket ID
  // or subject via the same /tickets?search= endpoint the Tickets page
  // uses — "users, contacts" in the placeholder are covered too, since
  // that search already matches on customer_name/email/phone.
  searchQuery = ''
  searchResults = signal<Ticket[]>([])
  searchLoading = signal(false)
  showSearchResults = signal(false)
  private search$ = new Subject<string>()

  dayOptions = DAY_OPTIONS
  days = signal<number>(7)

  stats = signal<DashboardStats>({ open: 0, closed: 0, resolvedToday: 0, unassigned: 0, highPriority: 0 })
  showCreateModal = signal(false)

  // Pending-tickets bar chart
  pendingTickets = signal<PendingTicketRow[]>([])
  pendingTotal   = signal(0)
  pendingLoading = signal(false)

  // "Show more" modal
  showPendingModal = signal(false)
  modalTickets     = signal<PendingTicketRow[]>([])
  modalLoading     = signal(false)

  // Other charts
  charts = signal<ChartsOverview | null>(null)
  chartsLoading = signal(false)

  maxPendingMinutes = computed(() => this.pendingTickets()[0]?.pending_minutes ?? 1)
  maxModalMinutes   = computed(() => this.modalTickets()[0]?.pending_minutes ?? 1)
  maxAgentCount     = computed(() => Math.max(1, ...(this.charts()?.agentWorkload.map(a => a.count) ?? [1])))

  // Time-of-day greeting — Morning until noon, Afternoon until 5pm, Evening after.
  greeting = computed(() => {
    const h = new Date().getHours()
    if (h < 12) return 'Good morning'
    if (h < 17) return 'Good afternoon'
    return 'Good evening'
  })

  trendDays = computed(() => {
    const c = this.charts()
    const n = this.days()
    const days: { date: string; label: string; created: number; closed: number }[] = []
    const today = new Date()
    for (let i = n - 1; i >= 0; i--) {
      const d = new Date(today)
      d.setDate(d.getDate() - i)
      const iso = d.toISOString().slice(0, 10)
      const label = d.toLocaleDateString('en-US', { day: '2-digit', month: 'short' })
      const created = c?.trend.created.find(p => p.day?.toString().slice(0, 10) === iso)?.count ?? 0
      const closed  = c?.trend.closed.find(p => p.day?.toString().slice(0, 10) === iso)?.count ?? 0
      days.push({ date: iso, label, created: Number(created), closed: Number(closed) })
    }
    return days
  })
  maxTrendCount = computed(() => Math.max(1, ...this.trendDays().flatMap(d => [d.created, d.closed])))

  // Sparkline points for the top stat cards — Open uses the "created"
  // series, Closed uses the "closed" series (both real daily data from the
  // trend endpoint). Resolved Today / High Priority don't have a daily
  // series backing them yet, so those cards render without one rather than
  // fabricating a line.
  private sparklinePath(values: number[]): string {
    if (values.length < 2) return ''
    const max = Math.max(1, ...values)
    const w = 100, h = 28
    const stepX = w / (values.length - 1)
    return values.map((v, i) => `${i === 0 ? 'M' : 'L'} ${(i * stepX).toFixed(1)} ${(h - (v / max) * h).toFixed(1)}`).join(' ')
  }
  openSparkline   = computed(() => this.sparklinePath(this.trendDays().map(d => d.created)))
  closedSparkline = computed(() => this.sparklinePath(this.trendDays().map(d => d.closed)))

  // Conic-gradient ring for the breakdown "donut" cards — no chart library
  // in this app, so the ring is a plain CSS conic-gradient on a circle with
  // a white circle masked out in the middle (see .donut-ring in dashboard.css).
  donutGradient(rows: { count: number }[] | undefined, colors: string[]): string {
    if (!rows?.length) return 'conic-gradient(#e2e8f0 0deg 360deg)'
    const total = rows.reduce((s, r) => s + Number(r.count), 0) || 1
    let acc = 0
    const stops = rows.map((r, i) => {
      const start = (acc / total) * 360
      acc += Number(r.count)
      const end = (acc / total) * 360
      return `${colors[i % colors.length]} ${start.toFixed(2)}deg ${end.toFixed(2)}deg`
    })
    return `conic-gradient(${stops.join(', ')})`
  }

  onSearchInput(e: Event) {
    this.searchQuery = (e.target as HTMLInputElement).value
    this.showSearchResults.set(!!this.searchQuery.trim())
    this.search$.next(this.searchQuery)
  }

  onSearchFocus() {
    if (this.searchQuery.trim()) this.showSearchResults.set(true)
  }

  // Slight delay so a click on a result (which fires blur first) still
  // registers before the dropdown disappears.
  onSearchBlur() {
    setTimeout(() => this.showSearchResults.set(false), 150)
  }

  goToSearchResult(t: Ticket) {
    this.showSearchResults.set(false)
    this.searchQuery = ''
    this.searchResults.set([])
    this.router.navigate(['/tickets', t.id])
  }

  openCreateModal()  { this.showCreateModal.set(true) }
  closeCreateModal() { this.showCreateModal.set(false) }

  openPendingModal() {
    this.showPendingModal.set(true)
    this.modalLoading.set(true)
    this.ticketService.getPendingTickets(0, 200, this.days()).subscribe({
      next: (r) => { this.modalTickets.set(r.rows as PendingTicketRow[]); this.modalLoading.set(false) },
      error: () => this.modalLoading.set(false),
    })
  }
  closePendingModal() { this.showPendingModal.set(false) }

  setDays(n: number) {
    if (n === this.days()) return
    this.days.set(n)
    this.fetchStats(); this.fetchPendingTickets(); this.fetchCharts()
  }

  private skipFirstStatsEffect   = true
  private skipFirstTicketsEffect = true

  constructor() {
    this.fetchStats()
    this.fetchPendingTickets()
    this.fetchCharts()
    this.search$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap(term => {
          if (!term.trim()) return of([])
          this.searchLoading.set(true)
          return this.ticketService.getTickets(0, 8, { search: term })
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (r: any) => {
          this.searchResults.set(Array.isArray(r) ? r : [])
          this.searchLoading.set(false)
        },
        error: () => { this.searchLoading.set(false) },
      })
    // Same double-fetch-on-mount issue as ticket-list.ts: effect() runs
    // once immediately on creation on top of the explicit calls above.
    effect(() => {
      this.ticketSocket.statsVersion()
      if (this.skipFirstStatsEffect) { this.skipFirstStatsEffect = false; return }
      this.fetchStats()
    })
    effect(() => {
      this.ticketSocket.ticketsVersion()
      if (this.skipFirstTicketsEffect) { this.skipFirstTicketsEffect = false; return }
      this.fetchPendingTickets()
      this.fetchCharts()
    })
  }

  statusClass(status: string): string {
    return {
      open: 'bg-blue-50 text-blue-700 border-blue-100',
      on_hold: 'bg-amber-50 text-amber-700 border-amber-100',
      escalated: 'bg-rose-50 text-rose-700 border-rose-100',
      closed: 'bg-slate-50 text-slate-600 border-slate-200',
    }[status] ?? 'bg-slate-50 text-slate-600 border-slate-200'
  }

  priorityDot(priority: string): string {
    return {
      low: 'bg-slate-300 shadow-[0_0_0_2px_rgba(203,213,225,0.4)]',
      medium: 'bg-amber-400 shadow-[0_0_0_2px_rgba(251,191,36,0.3)]',
      high: 'bg-rose-500 shadow-[0_0_0_2px_rgba(244,63,94,0.3)]'
    }[priority] ?? 'bg-slate-300'
  }

  distColor(key: string): string {
    return {
      open: 'bg-indigo-500', on_hold: 'bg-amber-500', escalated: 'bg-rose-500', closed: 'bg-emerald-500',
      low: 'bg-slate-400', medium: 'bg-fuchsia-500', high: 'bg-rose-500',
      whatsapp: 'bg-emerald-500', email: 'bg-blue-500', phone: 'bg-amber-500', manual: 'bg-gray-400',
    }[key] ?? 'bg-slate-400'
  }

  distStrokeColor(key: string): string {
    return {
      open: '#6366F1', on_hold: '#F59E0B', escalated: '#F43F5E', closed: '#10B981',
      low: '#94A3B8', medium: '#D946EF', high: '#F43F5E',
      whatsapp: '#10B981', email: '#3B82F6', phone: '#F59E0B', manual: '#94A3B8',
    }[key] ?? '#94A3B8'
  }

  getDonutSegments(rows: { count: number; [key: string]: any }[] | undefined, keyField: string) {
    if (!rows?.length) return []
    const total = rows.reduce((s, r) => s + Number(r.count), 0) || 1
    let accumulated = 0
    return rows.map(r => {
      const pct = (Number(r.count) / total) * 100
      const strokeDasharray = `${pct.toFixed(2)} ${(100 - pct).toFixed(2)}`
      const strokeDashoffset = -accumulated.toFixed(2)
      accumulated += pct
      return {
        key: r[keyField] || 'other',
        count: Number(r.count),
        pct: Math.round(pct),
        strokeDasharray,
        strokeDashoffset,
        colorClass: this.distColor(r[keyField]),
        strokeColor: this.distStrokeColor(r[keyField]),
      }
    })
  }

  statusSegments   = computed(() => this.getDonutSegments(this.charts()?.statusDist, 'status'))
  prioritySegments = computed(() => this.getDonutSegments(this.charts()?.priorityDist, 'priority'))
  sourceSegments   = computed(() => this.getDonutSegments(this.charts()?.sourceDist, 'source'))

  distPct(rows: { count: number }[] | undefined, count: number): number {
    if (!rows?.length) return 0
    const total = rows.reduce((s, r) => s + Number(r.count), 0) || 1
    return Math.round((count / total) * 100)
  }

  private fetchStats() { this.ticketService.getDashboardStats(this.days()).subscribe((r: any) => this.stats.set(r)) }

  private fetchPendingTickets() {
    this.pendingLoading.set(true)
    this.ticketService.getPendingTickets(0, 7, this.days()).subscribe({
      next: (r) => { this.pendingTickets.set(r.rows as PendingTicketRow[]); this.pendingTotal.set(r.total); this.pendingLoading.set(false) },
      error: () => this.pendingLoading.set(false),
    })
  }

  private fetchCharts() {
    this.chartsLoading.set(true)
    this.ticketService.getChartsOverview(this.days()).subscribe({
      next: (r: ChartsOverview) => { this.charts.set(r); this.chartsLoading.set(false) },
      error: () => this.chartsLoading.set(false),
    })
  }

  onTicketCreated() { this.fetchStats(); this.fetchPendingTickets(); this.fetchCharts() }

  formatPending(minutes: number): string {
    const m = Math.max(0, minutes)
    if (m < 60) return `${Math.max(1, Math.round(m))}m`
    const hours = m / 60
    if (hours < 24) return `${Math.round(hours)}h`
    const days = Math.floor(hours / 24)
    const remHours = Math.round(hours % 24)
    return remHours > 0 ? `${days}d ${remHours}h` : `${days}d`
  }

  formatMinutes(minutes: number | null): string {
    if (minutes === null || minutes === undefined) return '—'
    if (minutes < 60) return `${minutes}m`
    const h = Math.floor(minutes / 60)
    const m = minutes % 60
    return m > 0 ? `${h}h ${m}m` : `${h}h`
  }

  barWidth(minutes: number, max: number): number {
    const safeMinutes = Math.max(0, minutes)
    const safeMax = Math.max(0, max)
    if (!safeMax) return 4
    return Math.max(4, Math.round((safeMinutes / safeMax) * 100))
  }

  // Category pie chart — converted from the old vertical-bar layout.
  // getDonutSegments (above) looks up colors from a fixed dictionary keyed
  // on known status/priority/source values, which doesn't work here since
  // ticket categories are open-ended labels from TicketClassifier — so
  // this cycles through a dedicated palette by index instead.
  private static readonly CATEGORY_PALETTE = [
    '#6366F1', '#F59E0B', '#10B981', '#F43F5E', '#0EA5E9',
    '#D946EF', '#84CC16', '#F97316', '#14B8A6', '#8B5CF6',
  ]

  categorySegments = computed(() => {
    const rows = this.charts()?.ticketsByCategory ?? []
    if (!rows.length) return []
    const total = rows.reduce((s, r) => s + Number(r.count), 0) || 1
    let accumulated = 0
    return rows.map((r, i) => {
      const pct = (Number(r.count) / total) * 100
      const strokeDasharray = `${pct.toFixed(2)} ${(100 - pct).toFixed(2)}`
      const strokeDashoffset = -accumulated.toFixed(2)
      accumulated += pct
      return {
        category: r.category || 'Uncategorized',
        count: Number(r.count),
        pct: Math.round(pct),
        strokeDasharray,
        strokeDashoffset,
        strokeColor: DashboardComponent.CATEGORY_PALETTE[i % DashboardComponent.CATEGORY_PALETTE.length],
      }
    })
  })

  categoryTotal = computed(() => DashboardComponent.sumCounts(this.charts()?.ticketsByCategory as any))

  // Angular template expressions don't support arrow functions, so these
  // small totals (used just for the donut-ring center labels) are computed
  // here rather than inline with .reduce() in the template.
  private static sumCounts(rows: { count: number }[] | undefined): number {
    return (rows ?? []).reduce((s, r) => s + Number(r.count), 0)
  }
  statusTotal   = computed(() => DashboardComponent.sumCounts(this.charts()?.statusDist))
  priorityTotal = computed(() => DashboardComponent.sumCounts(this.charts()?.priorityDist))
  sourceTotal   = computed(() => DashboardComponent.sumCounts(this.charts()?.sourceDist))
}