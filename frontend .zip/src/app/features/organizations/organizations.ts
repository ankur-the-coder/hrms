import { Component, DestroyRef, inject, signal } from '@angular/core'
import { takeUntilDestroyed } from '@angular/core/rxjs-interop'
import { CommonModule } from '@angular/common'
import { Subject } from 'rxjs'
import { debounceTime, distinctUntilChanged, switchMap, tap } from 'rxjs/operators'
import { TicketService } from '../../core/services/ticket.service'

interface FetchParams { search: string; offset: number }

/**
 * Organizations — own top-level page/route (sidebar-nav.ts: 'Organizations'
 * item), separate from Contacts. Pulled straight from the shared legacy
 * `Organization` table (every org that's ever signed up, whether or not
 * they've ever raised a ticket) — see OrganizationService on the backend.
 *
 * Marking an org "High Priority" makes every open/incoming ticket from
 * that org default to priority=high going forward (see
 * TicketService.resolveDefaultPriority) — it does not touch existing
 * tickets.
 */
@Component({
  selector: 'app-organizations',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './organizations.html',
})
export class Organizations {
  private ticketService = inject(TicketService)
  private destroyRef = inject(DestroyRef)

  organizations = signal<any[]>([])
  loading = signal(false)
  search = ''

  readonly pageSize = 20
  page = signal(0) // 0-based
  totalRecords = signal(0)

  // Per-row "saving…" guard so a double-click can't fire the toggle twice
  // for the same org while the first request is still in flight.
  private savingOrgIds = new Set<number>()

  // Every search keystroke and page change goes through this subject
  // instead of calling fetch() directly. debounceTime coalesces rapid
  // typing so we're not hitting the DB on every keystroke, and switchMap
  // cancels any request that's been superseded — without this, a slow
  // response from an earlier keystroke could land AFTER a newer one and
  // silently overwrite the correct latest results with stale ones, which
  // is what made search feel broken.
  private fetch$ = new Subject<FetchParams>()

  constructor() {
    this.fetch$
      .pipe(
        debounceTime(300),
        distinctUntilChanged((a, b) => a.search === b.search && a.offset === b.offset),
        tap(() => this.loading.set(true)),
        switchMap(({ search, offset }) => this.ticketService.getOrganizations(offset, this.pageSize, search)),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (r: any) => {
          this.organizations.set(r?.data ?? [])
          this.totalRecords.set(Number(r?.totalRecords ?? 0))
          this.loading.set(false)
        },
        error: () => { this.loading.set(false) },
      })

    this.fetch$.next({ search: '', offset: 0 })
  }

  onSearch(e: Event) {
    this.search = (e.target as HTMLInputElement).value
    this.page.set(0) // any new search restarts from page 1
    this.fetch$.next({ search: this.search, offset: 0 })
  }

  nextPage() {
    if (this.loading() || (this.page() + 1) * this.pageSize >= this.totalRecords()) return
    const next = this.page() + 1
    this.page.set(next)
    this.fetch$.next({ search: this.search, offset: next * this.pageSize })
  }

  prevPage() {
    if (this.loading() || this.page() === 0) return
    const prev = this.page() - 1
    this.page.set(prev)
    this.fetch$.next({ search: this.search, offset: prev * this.pageSize })
  }

  get totalPages() {
    return Math.max(1, Math.ceil(this.totalRecords() / this.pageSize))
  }

  get rangeStart() {
    return this.totalRecords() === 0 ? 0 : this.page() * this.pageSize + 1
  }

  get rangeEnd() {
    return Math.min((this.page() + 1) * this.pageSize, this.totalRecords())
  }

  initials(name: string) {
    return name?.split(' ').map((p: string) => p[0]).slice(0, 2).join('').toUpperCase() || '?'
  }

  isSavingOrg(orgId: number) { return this.savingOrgIds.has(orgId) }

  toggleOrgPriority(o: any) {
    if (this.isSavingOrg(o.orgId)) return
    const next = !o.is_high_priority
    this.savingOrgIds.add(o.orgId)
    this.ticketService.setOrganizationPriority(o.orgId, o.orgName, next).subscribe({
      next: () => {
        this.organizations.update(list => list.map(x => x.orgId === o.orgId ? { ...x, is_high_priority: next ? 1 : 0 } : x))
        this.savingOrgIds.delete(o.orgId)
      },
      error: () => { this.savingOrgIds.delete(o.orgId) },
    })
  }
}