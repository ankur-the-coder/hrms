import { Component, OnInit, OnDestroy, ChangeDetectorRef, NgZone, signal, computed } from '@angular/core'
import { CommonModule } from '@angular/common'
import { HttpClient } from '@angular/common/http'
import { io, Socket } from 'socket.io-client'
import { environment } from '../../environments/environment'

interface DashboardStats {
  total: number
  waiting: number
  active: number
  closed: number
  phoneCapture: number
  avgResponseMin: number | null
  byIntent: Record<string, number>
  byAgent: { name: string; count: number; active: number }[]
  byProduct: { key: string; name: string; count: number }[]
  byHour: number[]          // index 0–23, count of sessions created that hour
  recentSessions: any[]
}

interface VisitorFunnelStats {
  total: number
  opened: number
  typed: number
  converted: number
  openedPct: number        // opened as % of visited
  typedPct: number         // typed as % of opened
  convertedPct: number     // converted as % of typed
  visitorToLeadPct: number // converted as % of total visited — the headline KPI
  byCountry: { code: string; name: string; count: number }[]
  byPage: { path: string; count: number }[]
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnInit, OnDestroy {
  private socket!: Socket
  sessions: any[] = []
  isLoading = signal(true)
  lastRefreshed = signal<Date | null>(null)
visitorTracks: any[] = [] 

  range: 'today' | 'week' | 'month' = 'week'
  ranges: { key: 'today' | 'week' | 'month'; label: string }[] = [
    { key: 'today', label: 'Today' },
    { key: 'week',  label: '7 days' },
    { key: 'month', label: '30 days' },
  ]

  intentConfig: Record<string, { label: string; color: string; bg: string }> = {
    demo:    { label: 'Demo',         color: '#3b82f6', bg: '#eff6ff' },
    sales:   { label: 'Sales',        color: '#8b5cf6', bg: '#f5f3ff' },
    meeting: { label: 'Meeting',      color: '#f59e0b', bg: '#fffbeb' },
    trial:   { label: 'Trial',        color: '#16a34a', bg: '#f0fdf4' },
    new:     { label: 'Unclassified', color: '#94a3b8', bg: '#f8fafc' },
  }

  stats = signal<DashboardStats>({
    total: 0, waiting: 0, active: 0, closed: 0,
    phoneCapture: 0, avgResponseMin: null,
    byIntent: {}, byAgent: [], byProduct: [], byHour: Array(24).fill(0),
    recentSessions: [],
  })

  visitorStats = signal<VisitorFunnelStats>({
  total: 0, opened: 0, typed: 0, converted: 0,
  openedPct: 0, typedPct: 0, convertedPct: 0, visitorToLeadPct: 0,
  byCountry: [], byPage: [],
})

maxCountryCount = computed(() => Math.max(...this.visitorStats().byCountry.map(c => c.count), 1))
maxPageCount    = computed(() => Math.max(...this.visitorStats().byPage.map(p => p.count), 1))

  resolvedPct    = computed(() => this.stats().total ? Math.round(this.stats().closed / this.stats().total * 100) : 0)
  intentEntries  = computed(() => Object.entries(this.stats().byIntent).sort((a, b) => b[1] - a[1]))
  maxIntentCount = computed(() => Math.max(...Object.values(this.stats().byIntent), 1))
  maxAgentCount  = computed(() => Math.max(...this.stats().byAgent.map(a => a.count), 1))
  maxHourCount   = computed(() => Math.max(...this.stats().byHour, 1))

  // Peak hour label
  peakHour = computed(() => {
    const h = this.stats().byHour
    const idx = h.indexOf(Math.max(...h))
    return h[idx] ? `${idx}:00–${idx + 1}:00` : null
  })

  hours = Array.from({ length: 24 }, (_, i) => i)

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private zone: NgZone,
  ) {}

ngOnInit() {
  this.loadData()
  this.loadVisitorData()   // ← NEW
  this.socket = io(environment.apiUrl, { transports: ['websocket', 'polling'] })
  this.socket.on('queue_updated', () => this.zone.run(() => this.loadData()))
  this.socket.on('session_updated', () => this.zone.run(() => this.loadData()))
}

setRange(r: 'today' | 'week' | 'month') {
  this.range = r
  this.computeStats()
  this.computeVisitorStats()   // ← NEW
}

  private loadData() {
    this.http.get<any>(`${environment.apiUrl}/chat/sessions`, {
      params: { offset: 0, limit: 9999 }
    }).subscribe({
      next: res => {
        this.zone.run(() => {
          this.sessions = (res?.data ?? []).map((s: any) => ({
            ...s,
            edited_fields: s.edited_fields ? JSON.parse(s.edited_fields) : []
          }))
          this.computeStats()
          this.isLoading.set(false)
          this.lastRefreshed.set(new Date())
          this.cdr.detectChanges()
        })
      },
      error: () => this.zone.run(() => { this.isLoading.set(false); this.cdr.detectChanges() })
    })
  }

  private computeStats() {
    const now   = Date.now()
    const cutoff = this.range === 'today' ? now - 86_400_000
                 : this.range === 'week'  ? now - 7  * 86_400_000
                 :                          now - 30 * 86_400_000

    const filtered = this.sessions.filter(s => new Date(s.created_at).getTime() > cutoff)

    // Intent
    const byIntent: Record<string, number> = {}
    filtered.forEach(s => {
      const k = s.intent || 'new'
      byIntent[k] = (byIntent[k] || 0) + 1
    })

    // Agent leaderboard
    const agentMap = new Map<string, { count: number; active: number }>()
    filtered.forEach(s => {
      const name = s.assigned_agent_name || 'Unassigned'
      const prev = agentMap.get(name) ?? { count: 0, active: 0 }
      agentMap.set(name, {
        count:  prev.count + 1,
        active: prev.active + (s.status === 'active' ? 1 : 0),
      })
    })
    const byAgent = Array.from(agentMap.entries())
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 6)

    // Product breakdown
    const productMap = new Map<string, number>()
    filtered.forEach(s => {
      const k = s.widget_key || 'Unknown'
      productMap.set(k, (productMap.get(k) ?? 0) + 1)
    })
    const byProduct = Array.from(productMap.entries())
      .map(([key, count]) => ({ key, name: key, count }))
      .sort((a, b) => b.count - a.count)

    // Peak-hour heatmap (IST = UTC+5:30)
    const byHour = Array(24).fill(0)
    filtered.forEach(s => {
      const d = new Date(s.created_at)
      const istHour = (d.getUTCHours() + 5 + Math.floor((d.getUTCMinutes() + 30) / 60)) % 24
      byHour[istHour]++
    })

    // Phone capture rate
    const phoneCapture = filtered.length
      ? Math.round(filtered.filter(s => s.visitor_phone).length / filtered.length * 100)
      : 0

    // Avg response time: created_at → last_message_at on closed sessions
    const closedWithMsg = filtered.filter(s => s.status === 'closed' && s.last_message_at && s.created_at)
    const avgResponseMin = closedWithMsg.length
      ? Math.round(
          closedWithMsg.reduce((sum, s) => {
            return sum + (new Date(s.last_message_at).getTime() - new Date(s.created_at).getTime())
          }, 0) / closedWithMsg.length / 60_000
        )
      : null

    this.stats.set({
      total: filtered.length,
      waiting: filtered.filter(s => s.status === 'waiting').length,
      active:  filtered.filter(s => s.status === 'active').length,
      closed:  filtered.filter(s => s.status === 'closed').length,
      phoneCapture,
      avgResponseMin,
      byIntent,
      byAgent,
      byProduct,
      byHour,
      recentSessions: [...filtered].sort((a, b) =>
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      ).slice(0, 10),
    })
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  heatColor(count: number): string {
    if (!count) return '#f1f5f9'
    const max  = this.maxHourCount()
    const pct  = count / max
    if (pct > 0.75) return '#15803d'
    if (pct > 0.50) return '#22c55e'
    if (pct > 0.25) return '#86efac'
    return '#bbf7d0'
  }

  formatHour(h: number): string {
    if (h === 0)  return '12a'
    if (h === 12) return '12p'
    return h < 12 ? `${h}a` : `${h - 12}p`
  }

  formatResponseTime(min: number | null): string {
    if (min === null) return '—'
    if (min < 60) return `${min}m`
    const h = Math.floor(min / 60)
    const m = min % 60
    return m ? `${h}h ${m}m` : `${h}h`
  }

  toIST(utcString: string | null): string {
    if (!utcString) return '—'
    const normalized = utcString.includes('Z') || utcString.includes('+')
      ? utcString : utcString.trim().replace(' ', 'T') + 'Z'
    return new Date(normalized).toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit', month: 'short',
      hour: '2-digit', minute: '2-digit', hour12: true,
    })
  }

  private loadVisitorData() {
  const since = new Date(Date.now() - 30 * 86_400_000).toISOString()
  this.http.get<any>(`${environment.apiUrl}/visitor/funnel-stats`, {
    params: { since }
  }).subscribe({
    next: res => {
      this.zone.run(() => {
        this.visitorTracks = res?.data ?? []
        this.computeVisitorStats()
        this.cdr.detectChanges()
      })
    },
    error: () => {}
  })
}

private computeVisitorStats() {
  const now    = Date.now()
  const cutoff = this.range === 'today' ? now - 86_400_000
               : this.range === 'week'  ? now - 7  * 86_400_000
               :                          now - 30 * 86_400_000

  const filtered = this.visitorTracks.filter(v => new Date(v.first_seen_at).getTime() > cutoff)

  const total     = filtered.length
  const opened    = filtered.filter(v => v.widget_opened).length
  const typed     = filtered.filter(v => v.form_touched).length
  const converted = filtered.filter(v => v.converted).length

  // Top countries
  const countryMap = new Map<string, { name: string; count: number }>()
  filtered.forEach(v => {
    const code = v.country_code || 'XX'
    const prev = countryMap.get(code) ?? { name: v.country || code, count: 0 }
    prev.count++
    countryMap.set(code, prev)
  })
  const byCountry = Array.from(countryMap.entries())
    .map(([code, v]) => ({ code, ...v }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6)

  // Top landing pages — grouped by path only
  const pageMap = new Map<string, number>()
  filtered.forEach(v => {
    if (!v.page_url) return
    let path = v.page_url
    try { path = new URL(v.page_url).pathname || '/' } catch { /* keep raw string */ }
    pageMap.set(path, (pageMap.get(path) ?? 0) + 1)
  })
  const byPage = Array.from(pageMap.entries())
    .map(([path, count]) => ({ path, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6)

  this.visitorStats.set({
    total, opened, typed, converted,
    openedPct:        total  ? Math.round(opened    / total  * 100) : 0,
    typedPct:         opened ? Math.round(typed     / opened * 100) : 0,
    convertedPct:     typed  ? Math.round(converted / typed  * 100) : 0,
    visitorToLeadPct: total  ? Math.round(converted / total  * 100) : 0,
    byCountry,
    byPage,
  })
}

  ngOnDestroy() {
    if (this.socket) this.socket.disconnect()
  }
}