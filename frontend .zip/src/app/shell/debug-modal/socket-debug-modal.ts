import { Component, computed, inject, signal } from '@angular/core'
import { JsonPipe } from '@angular/common'
import { TicketSocketService } from '../../core/services/ticket-socket.services'
import { DebugLogLevel } from '../../core/models/debug-log.model'


@Component({
  selector: 'app-socket-debug-modal',
  standalone: true,
  imports: [JsonPipe],
  templateUrl: './socket-debug-modal.html',
})
export class SocketDebugModalComponent {
  ticketSocket = inject(TicketSocketService)

  levelFilter = signal<DebugLogLevel | 'all'>('all')
  search = signal('')
  copied = signal(false)
  activeTab = signal<'logs' | 'environment'>('logs')

  refreshDiagnostics() { this.ticketSocket.requestDiagnostics() }

  memPct(usedMB: number, totalMB: number): number {
    return totalMB ? Math.round((usedMB / totalMB) * 100) : 0
  }

  close() { this.ticketSocket.debugPanelOpen.set(false) }

  filteredLogs = computed(() => {
    const level = this.levelFilter()
    const term = this.search().trim().toLowerCase()
    // Newest first — that's what you want to see when something just broke.
    return [...this.ticketSocket.debugLogs()]
      .reverse()
      .filter(l => level === 'all' || l.level === level)
      .filter(l => !term || l.message.toLowerCase().includes(term) || l.source.toLowerCase().includes(term))
  })

  levelBadgeClass(level: DebugLogLevel): string {
    switch (level) {
      case 'error': return 'bg-red-50 text-red-600 border-red-200'
      case 'warn':  return 'bg-amber-50 text-amber-600 border-amber-200'
      case 'info':  return 'bg-indigo-50 text-indigo-600 border-indigo-200'
      default:      return 'bg-slate-50 text-slate-500 border-slate-200'
    }
  }

  sourceBadgeClass(source: string): string {
    switch (source) {
      case 'server': return 'bg-violet-50 text-violet-600 border-violet-200'
      case 'engine': return 'bg-fuchsia-50 text-fuchsia-600 border-fuchsia-200'
      default:       return 'bg-slate-100 text-slate-500 border-slate-200'
    }
  }

  formatTime(ts: number): string {
    const d = new Date(ts)
    return d.toLocaleTimeString(undefined, { hour12: false }) + '.' + String(d.getMilliseconds()).padStart(3, '0')
  }

  clear() {
    this.ticketSocket.clearLogs()
  }

  async copyLogs() {
    const text = this.filteredLogs()
      .slice()
      .reverse()
      .map(l => `[${this.formatTime(l.ts)}] [${l.source}] [${l.level}] ${l.message}${l.data ? ' ' + JSON.stringify(l.data) : ''}`)
      .join('\n')
    try {
      await navigator.clipboard.writeText(text)
      this.copied.set(true)
      setTimeout(() => this.copied.set(false), 1500)
    } catch {
      // Clipboard API can be blocked (permissions/http); fail silently, the
      // logs are still visible on screen either way.
    }
  }
}