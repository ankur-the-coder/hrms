import { Component, computed, inject } from '@angular/core'
import { RouterLink, RouterLinkActive } from '@angular/router'
import { TicketService } from '../core/services/ticket.service'
import { toSignal, toObservable } from '@angular/core/rxjs-interop'
import { switchMap } from 'rxjs'
import { AuthService } from '../service/auth.service';
import { TicketSocketService } from '../core/services/ticket-socket.services'
import { LayoutService } from '../core/services/layout.service'

interface NavItem { label: string; icon: string; route: string }

@Component({
  selector: 'app-sidebar-nav',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './sidebar-nav.html',
  styleUrl: './sidebar-nav.css',
})
export class SidebarNavComponent {
  private ticketService = inject(TicketService)
  // Public — sidebar-nav.html reads connectionInfo() and debugPanelOpen for
  // the socket-diagnostics "i" button next to the UbiDesk brand mark.
  ticketSocket = inject(TicketSocketService)
  auth = inject(AuthService)
  layout = inject(LayoutService)

  // Collapsed = icon-only rail (matches the "«" toggle in the reference
  // design) — separate from layout.sidebarHidden, which fully removes the
  // sidebar (used elsewhere for embedded/full-bleed views). This is just a
  // width toggle the user controls themselves.
  collapsed = this.layout.sidebarCollapsed

  navItems = computed<NavItem[]>(() => {
    const isAdmin = this.auth.getRole() === 'admin'
    const items: NavItem[] = [
      { label: 'Dashboard',     icon: 'grid',     route: '/dashboard' },
      { label: 'Tickets',       icon: 'ticket',   route: '/tickets' },
      { label: 'Messages',      icon: 'chat',     route: '/messages' },
      { label: 'Contacts',      icon: 'users',    route: '/contacts' },
      { label: 'Organizations', icon: 'building', route: '/organizations' },
    ]
    if (isAdmin) {
      items.push({ label: 'Attachments', icon: 'paperclip', route: '/attachments' })
    }
    items.push(
      { label: 'Reports',       icon: 'chart',    route: '/reports' },
      { label: 'Settings',      icon: 'gear',     route: '/settings' },
    )
    return items
  })

  // Was: toSignal(this.ticketService.getDashboardStats()) — subscribed ONCE
  // on load and never again, so the badge froze until a hard refresh.
  // Now it refetches every time the socket says stats went stale, and
  // whenever a ticket is created/updated (tickets_updated too).
  private stats = toSignal(
    toObservable(this.ticketSocket.statsVersion).pipe(
      switchMap(() => this.ticketService.getDashboardStats(30))
    ),
    { initialValue: { open: 0, pending: 0, resolvedToday: 0, highPriority: 0 } }
  )
  openCount = computed(() => this.stats()?.open ?? 0)

  // Backend now scopes this count the same way the ticket list is scoped —
  // an agent sees their own open tickets + unassigned ones, an admin sees
  // every open ticket. Surfaced as a tooltip since the number alone reads
  // ambiguous ("open tickets... in what set?").
  openCountLabel = computed(() =>
    this.auth.getRole() === 'admin'
      ? 'Open tickets — all agents'
      : 'Open tickets assigned to you, plus unassigned'
  )
}