import { Component, inject, OnInit } from '@angular/core'
import { RouterOutlet } from '@angular/router'
import { SidebarNavComponent } from './sidebar-nav'
import { TicketSocketService } from '../core/services/ticket-socket.services'
import { AuthService } from '../service/auth.service'
import { LayoutService } from '../core/services/layout.service'
import { SocketDebugModalComponent } from './debug-modal/socket-debug-modal'

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, SidebarNavComponent, SocketDebugModalComponent, SocketDebugModalComponent],
  templateUrl: './app-shell.html',
  styleUrl: './app-shell.css',
})
export class AppShellComponent implements OnInit {
  private auth = inject(AuthService)
  private ticketSocket = inject(TicketSocketService)
  layout = inject(LayoutService)

  ngOnInit() {
    this.ticketSocket.connect(this.auth.getAgentId(), this.auth.getAgentName(), this.auth.getRole())
  }
}