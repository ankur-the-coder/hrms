import { ApplicationConfig } from '@angular/core'
import { provideRouter } from '@angular/router'
import { provideHttpClient, withInterceptors } from '@angular/common/http'
import { routes } from './app.routes'
import { authExpiredInterceptor } from './core/interceptors/auth-expired.interceptor'

export const appConfig: ApplicationConfig = {
  providers: [
      provideHttpClient(withInterceptors([authExpiredInterceptor])),
    provideRouter(routes),
   
  ]
}