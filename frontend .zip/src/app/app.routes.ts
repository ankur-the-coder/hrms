import { Routes } from '@angular/router'
import { authGuard } from './guards/auth.guard'
import { adminGuard } from './guards/admin.guard'
import { AppShellComponent } from './shell/app-shell'

export const routes: Routes = [
  { path: 'login', loadComponent: () => import('./login/login.component').then(m => m.LoginComponent) },
  // Standalone, unauthenticated page reached from the rating/reopen buttons
  // in the ticket-closure email — intentionally outside AppShell/authGuard.
  { path: 'feedback', loadComponent: () => import('./features/feedback-view/feedback-view').then(m => m.FeedbackViewComponent) },
  {
    path: '', component: AppShellComponent, canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', loadComponent: () => import('./features/dashboard').then(m => m.DashboardComponent) },
      { path: 'tickets',   loadComponent: () => import('./features/tickets/ticket-list/ticket-list').then(m => m.TicketListComponent) },
      { path: 'tickets/:id', loadComponent: () => import('./features/tickets/ticket-detail/ticket-detail').then(m => m.TicketDetailComponent) },
      { path: 'messages', redirectTo: 'messages/whatsapp', pathMatch: 'full' },
      { path: 'messages/whatsapp', loadComponent: () => import('./features/messages/whatsapp-inbox/whatsapp-inbox').then(m => m.WhatsappInbox) },
      { path: 'messages/email',    loadComponent: () => import('./features/messages/email-inbox/email-inbox').then(m => m.EmailInbox) },
      { path: 'contacts',  loadComponent: () => import('./features/contacts/contacts').then(m => m.Contacts) },
      // NEW: Organizations — own top-level tab/route, separate from Contacts.
      { path: 'organizations', loadComponent: () => import('./features/organizations/organizations').then(m => m.Organizations) },
      // NEW: Attachments — browse/search/delete every file saved to S3 across all tickets (admin only).
      { path: 'attachments', canActivate: [adminGuard], loadComponent: () => import('./features/attachments/attachments').then(m => m.AttachmentsComponent) },
      { path: 'reports',   loadComponent: () => import('./features/reports/reports-dashboard').then(m => m.ReportsDashboard) },
      { path: 'settings',  loadComponent: () => import('./features/settings/settings').then(m => m.SettingsComponent) },
      { path: 'settings/mail-accounts', loadComponent: () => import('./features/settings/mail-accounts/mail-accounts').then(m => m.MailAccountsComponent) },
      { path: 'settings/whatsapp-accounts', loadComponent: () => import('./features/settings/whatsapp-account/whatsapp-accounts').then(m => m.WhatsappAccountsComponent) }, // <-- ADDED HERE
      { path: 'settings/agents',    loadComponent: () => import('./features/settings/agents/agents').then(m => m.AgentsComponent) },
      { path: 'settings/messaging', loadComponent: () => import('./features/settings/messaging/messaging').then(m => m.MessagingSettingsComponent) },
    ]
  }
]