import { createApplication } from '@angular/platform-browser'
import { createCustomElement } from '@angular/elements'
import { provideHttpClient } from '@angular/common/http'

(async () => {
  const app = await createApplication({
    providers: [provideHttpClient()]
  })



})

