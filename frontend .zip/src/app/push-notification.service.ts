import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { environment } from '../environments/environment'

// Replace with your VAPID public key (generate with: npx web-push generate-vapid-keys)
const VAPID_PUBLIC_KEY = 'BCDhHCPQIdc-9zc8CleDQ4c1A8gFa4sN4bpQmPTbLtcTTbzbearT4RBV5xFB3sDtaGTRSdbIAPvuvcEG4Fx1wq8'

@Injectable({ providedIn: 'root' })
export class PushNotificationService {
  private swReg: ServiceWorkerRegistration | null = null

  constructor(private http: HttpClient) {}

  async init() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return
    try {
      this.swReg = await navigator.serviceWorker.register('/sw.js')
      console.log('SW registered')
    } catch (e) { console.warn('SW registration failed', e) }
  }

  async requestPermissionAndSubscribe() {
    const perm = await Notification.requestPermission()
    if (perm !== 'granted' || !this.swReg) return

    try {
      const existing = await this.swReg.pushManager.getSubscription()
      const sub = existing ?? await this.swReg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(VAPID_PUBLIC_KEY).buffer as ArrayBuffer
      })
      // Send subscription to your backend to store it
      this.http.post(`${environment.apiUrl}/push/subscribe`, sub.toJSON()).subscribe()
    } catch (e) { console.warn('Push subscription failed', e) }
  }

  // Called by agent-panel when a chat_request comes in as a fallback
  // (for same-browser tabs that are backgrounded, not fully closed)
  showLocalNotification(title: string, body: string) {
    if (Notification.permission === 'granted') {
      new Notification(title, { body, icon: '/favicon.ico', tag: 'chat-request' })
    }
  }

  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - base64String.length % 4) % 4)
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
    const raw = atob(base64)
    return Uint8Array.from([...raw].map(c => c.charCodeAt(0)))
  }
}