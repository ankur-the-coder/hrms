// Mirrors the `ServerDiagnostics` interface in backend_start/start/socket.ts.
// Keep these two in sync manually — there's no shared package between the
// two apps, so a backend field rename needs a matching edit here.
export interface ServerDiagnostics {
  ts: number
  runtime: {
    nodeVersion: string
    platform: string
    arch: string
    pid: number
    uptimeSeconds: number
    env: string | undefined
  }
  host: {
    hostname: string
    totalMemMB: number
    freeMemMB: number
    loadAvg: number[]
    cpuCount: number
  }
  process: {
    rssMB: number
    heapUsedMB: number
    heapTotalMB: number
    externalMB: number
    eventLoopLagMs: number | null
  }
  socket: {
    connectedClients: number
    transport_ws: number
    transport_polling: number
  }
  database: {
    connected: boolean
    latencyMs: number | null
    error: string | null
  }
  config: {
    hasDbConfig: boolean
    hasWhatsappAccount: boolean
    hasActiveMailAccount: boolean
    corsOrigin: string
  }
}