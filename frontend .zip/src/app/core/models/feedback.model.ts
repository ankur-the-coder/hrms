// Models for the standalone, unauthenticated /feedback page that customers
// land on from the rating / reopen buttons in the ticket-closure email.
// Mirrors the JSON shape returned by TicketFeedbackController's *Api actions.

export type FeedbackRatingTier = 'positive' | 'neutral' | 'negative'
export type FeedbackViewMode = 'rating' | 'reopen' | 'view'

export interface PublicTicket {
  ticketUid: string
  subject?: string | null
  status: string
  priority: string
  source: string
  customerName?: string | null
  assignedAgentName?: string | null
  createdAt: string
  updatedAt?: string | null
  reopenCount: number
  lastReopenedAt?: string | null
  rating?: number | null
  ratingSubmittedAt?: string | null
  ratingLikedMost?: string | null
  ratingImproveFeedback?: string | null
}

export interface PublicTicketMessage {
  sender: 'customer' | 'agent' | 'system'
  sender_name?: string | null
  message: string
  created_at: string
}

export interface FeedbackViewData {
  found: boolean
  mode?: FeedbackViewMode
  tier?: FeedbackRatingTier | null
  ratingLabel?: string
  ticket?: PublicTicket
  messages?: PublicTicketMessage[]
}