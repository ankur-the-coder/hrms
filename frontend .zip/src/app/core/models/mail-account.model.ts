export interface MailAccount {
  id: number
  email: string
  display_name?: string
  connected_at: string
  subscription_expires_at?: string
  webhook_failed: 0 | 1
  last_synced_at?: string
  is_default: 0 | 1
}
