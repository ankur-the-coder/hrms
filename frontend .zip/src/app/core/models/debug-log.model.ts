export type DebugLogLevel = 'debug' | 'info' | 'warn' | 'error'

// 'client' = logged in the browser (socket.io-client lifecycle events, our
// own emits). 'server' / 'engine' = pushed down from the backend's own
// debug-log ring buffer (see backend_start/start/socket.ts) so you can see
// what the server thinks is happening without needing SSH/log access.
export type DebugLogSource = 'client' | 'server' | 'engine'

export interface DebugLogEntry {
  id: string
  ts: number
  level: DebugLogLevel
  source: DebugLogSource
  message: string
  data?: any
}