// --- ENUMS & TYPES ---

export type TicketStatus = 
  | 'new' 
  | 'open' 
  | 'waiting' 
  | 'on_hold' 
  | 'escalated' 
  | 'resolved' 
  | 'closed'

export type TicketPriority = 'low' | 'medium' | 'high'
export type TicketSource = 'whatsapp' | 'email' | 'phone' | 'manual'

// --- ENTITIES ---

export interface TicketAttachment {
  id: number
  file_name: string
  content_type: string
  size: number
  storage_path: string
}

/**
 * A row from GET /admin/attachments (the "Attachments" sidebar page) — a
 * TicketAttachment plus the ticket/customer context needed to search and
 * to link back to the ticket it came from.
 */
export interface AttachmentBrowserRow {
  id: number
  ticket_id: number | null
  message_id: number | null
  file_name: string
  content_type: string | null
  size: number | null
  storage_path: string
  created_at: string
  is_broken?: 0 | 1
  ticket_uid?: string | null
  ticket_subject?: string | null
  customer_name?: string | null
  customer_email?: string | null
}

/**
 * A file the agent picked in the composer, from the moment it's uploaded
 * (via TicketService.uploadAttachment) until the message is actually sent.
 * Has no `id` yet since no ticket_attachments row exists until the parent
 * message is created — see TicketService.addMessage on the backend.
 */
export interface PendingAttachment {
  fileName: string
  contentType?: string
  size?: number
  storagePath: string
  /** Client-only key for tracking upload progress / removal before send. */
  clientId: string
  uploading?: boolean
  error?: string | null
}

/**
 * A row from GET /admin/attachments/bucket-audit — a raw S3 object, walked
 * directly from the bucket (independent of ticket_attachments), with
 * whether it's actually referenced by a ticket ("tracked") or not.
 */
export interface S3BucketObjectRow {
  key: string
  fileName: string
  size: number
  lastModified: string
  tracked: boolean
  ticketId: number | null
  url?: string
  contentType?: string
}

export interface S3BucketAuditSummary {
  totalObjects: number
  totalBucketSizeBytes: number
  trackedObjects: number
  trackedSizeBytes: number
  untrackedObjects: number
  untrackedSizeBytes: number
  cachedAt: number | null
}

export interface Ticket {
  id: number
  ticket_uid: string
  subject?: string | null
  customer_name?: string | null
  customer_phone?: string | null
  customer_email?: string | null
  source: TicketSource
  status: TicketStatus
  priority: TicketPriority

  // Status flags (optional to avoid breaking existing mocks/views)
  is_read?: 0 | 1
  is_spam?: 0 | 1

  // Resolution & Merging
  merged_into_ticket_id?: number | null
  resolution_code?: string | null
  resolution_notes?: string | null

  // Customer satisfaction rating & reopen tracking (closure-email widget)
  rating?: number | null
  rating_submitted_at?: string | null
  rating_liked_most?: string | null
  rating_improve_feedback?: string | null
  reopen_count?: number
  last_reopened_at?: string | null

  // Assignment & Reassignment
  assigned_to?: number | null
  assigned_agent_name?: string | null
  prev_assigned_to?: number | null
  prev_assigned_agent_name?: string | null
  assignmentHistory?: { agent_name: string; created_at?: string }[]

  // Email & Sender Identification
  mail_conversation_id?: string | null
  mailbox_email?: string | null
  sender_identification?: 'organization' | 'employee' | 'unidentified' | null
  sender_org_id?: number | null
  sender_employee_id?: number | null
  sender_logo_url?: string | null
  sender_org_name?: string | null

  // Metadata & Timestamps
  thread_count?: number
  comment_count?: number
  agent_last_active_at?: string | null
  last_message_at?: string | null
  due_date?: string | null
  created_at: string
  updated_at?: string | null
}

export interface TicketMessage {
  id: number
  ticket_id: number
  sender: 'customer' | 'agent' | 'system'
  type: 'reply' | 'internal_note'
  message: string
  sender_name?: string | null
  sender_email?: string | null
  agent_id?: number | null
  to_recipients?: string[]
  cc_recipients?: string[]
  bcc_recipients?: string[]
  reply_mode?: 'reply' | 'reply_all' | 'reply_selected' | 'forward'
  forward_to?: string | null
  attachments?: TicketAttachment[]
  created_at: string
  graph_message_id?: string
   channel?: 'email' | 'whatsapp'
 delivery_status?: 'sent' | 'failed' | 'read' | 'delivered'
 failure_reason?: string
 retry_count?: number
 related_message_id?: number | null
  relatedMessageId?: number | null    
  deliveryStatus?: 'sent' | 'failed'   
  failureReason?: string | null   
  isSending?:any
}

export interface TicketMacro {
  id: number
  name: string
  description?: string | null
  set_status?: TicketStatus | null
  set_priority?: TicketPriority | null
  set_assigned_to?: number | null
  canned_reply?: string | null
  is_active: 0 | 1
}

export interface DashboardStats {
  open: number
  closed: number
  resolvedToday?: number
  unassigned?: number
  highPriority: number
  comparisonText?: string
  changes?: {
    openPct: number | null
    closedPct: number | null
    resolvedTodayPct?: number | null
    unassignedPct?: number | null
    highPriorityPct: number | null
  }
}

export interface ConversationSummary {
  ticketId: number
  customerName: string
  lastMessage: string
  lastMessageAt: string
  unread?: boolean
}

export interface Agent {
  id: number
  name: string
  username: string
  plain_password?: string | null
  role: 'admin' | 'agent'
  is_active: number
}

export interface CcParticipant {
  id?: number
  ticket_id?: number
  email: string
  name?: string | null
  avatar_url?: string | null
  org_id?: number | null
  employee_id?: number | null
}



export interface PendingTicketRow {
  id: number
  ticket_uid: string
  customer_name: string | null
  status: TicketStatus
  priority: TicketPriority
  assigned_agent_name: string | null
  pending_since: string
  pending_minutes: number
}

export interface DistributionRow { status?: string; priority?: string; source?: string; count: number }
export interface TrendPoint { day: string; count: number }
export interface AgentWorkloadRow { id: number; name: string; count: number }
export interface CategoryRow { category: string; count: number; pct: number }
export interface SlaCompliance { pct: number; rated: number }

export interface ChartsOverview {
  statusDist: DistributionRow[]
  priorityDist: DistributionRow[]
  sourceDist: DistributionRow[]
  trend: { created: TrendPoint[]; closed: TrendPoint[] }
  agentWorkload: AgentWorkloadRow[]
  avgFirstResponseMinutes: number | null
  ticketsByCategory: CategoryRow[]
  slaCompliance: SlaCompliance
}

export interface PendingTicketRow {
  id: number
  ticket_uid: string
  customer_name: string | null
  status: TicketStatus
  priority: TicketPriority
  assigned_agent_name: string | null
  sender_org_name?: string | null
  sender_logo_url?: string | null
  pending_since: string
  pending_minutes: number
}