import { Component, ElementRef, EventEmitter, Input, Output, ViewChild, AfterViewInit, OnChanges, OnDestroy, SimpleChanges, inject } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { DialogService } from '../services/Dialog-services/dialog.services';

export interface MergeTagVariant { label: string; suffix: string } // suffix appended as {{token:suffix}}
export interface MergeTag { label: string; token: string; variants?: MergeTagVariant[] }

const DEFAULT_MERGE_TAGS: MergeTag[] = [
  { label: 'Agent name',    token: '{{agent_name}}' },
  { label: 'Customer name', token: '{{customer_name}}' },
  { label: 'Ticket ID',     token: '{{ticket_uid}}' },
]

/**
 * contenteditable + execCommand based WYSIWYG editor. Agents/admins never
 * see or type raw HTML — every control below manipulates the DOM directly,
 * and (html) always emits real, sanitized-on-paste markup.
 */
@Component({
  selector: 'app-rich-text-editor',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './rich-text-editor.html',
  styleUrl: './rich-text-editor.css',
})
export class RichTextEditorComponent implements AfterViewInit, OnChanges, OnDestroy {
  @Input() html = ''
  @Input() mergeTags: MergeTag[] = DEFAULT_MERGE_TAGS
  @Input() placeholder = 'Start typing…'
  @Output() htmlChange = new EventEmitter<string>()

  @ViewChild('editable') editableRef!: ElementRef<HTMLDivElement>

  private lastEmitted = ''
  activeStates: Record<string, boolean> = { bold: false, italic: false, underline: false }
  private selectionHandler = () => this.refreshActiveStates()
  private savedRange: Range | null = null
  private lastColor: string | null = null
  private dialog = inject(DialogService)

  onKeydown(event: KeyboardEvent) {
    if (event.key !== 'Backspace') return
    // After the delete completes, if the caret lands in a node with no color
    // context left but we know the user was just typing in a color, reassert it
    // so the next character typed doesn't silently fall back to black.
    setTimeout(() => {
      if (!this.lastColor) return
      const sel = window.getSelection()
      if (!sel || !sel.rangeCount) return
      const node = sel.anchorNode
      const el = node?.nodeType === Node.TEXT_NODE ? node.parentElement : (node as HTMLElement | null)
      const currentColor = el ? getComputedStyle(el).color : ''
const isDefaultBlack = currentColor === 'rgb(30, 41, 59)' || currentColor === 'rgb(0, 0, 0)' || !currentColor
      if (isDefaultBlack) {
        document.execCommand('foreColor', false, this.lastColor)
      }
    }, 0)
  }

  // Dedicated "Insert Button" modal (replaces native prompt())
  showButtonModal = false
  buttonUrlDraft = ''
  buttonTextDraft = 'Click here'

  refreshActiveStates() {
    if (!this.editableRef?.nativeElement.contains(document.getSelection()?.anchorNode ?? null)) return
    this.activeStates = {
      bold: document.queryCommandState('bold'),
      italic: document.queryCommandState('italic'),
      underline: document.queryCommandState('underline'),
    }
  }

  ngAfterViewInit() {
    document.execCommand('styleWithCSS', false, 'true' as any)
    this.editableRef.nativeElement.innerHTML = this.tokensToChips(this.html || '')
    this.lastEmitted = this.html || ''
    document.addEventListener('selectionchange', this.selectionHandler)
  }

  ngOnDestroy() {
    document.removeEventListener('selectionchange', this.selectionHandler)
  }

  ngOnChanges(changes: SimpleChanges) {
    // Only push external updates in (e.g. "Reset to default") — never fight the user's own typing.
    if (changes['html'] && this.editableRef && changes['html'].currentValue !== this.lastEmitted) {
      this.editableRef.nativeElement.innerHTML = this.tokensToChips(changes['html'].currentValue || '')
      this.lastEmitted = changes['html'].currentValue || ''
    }
  }

  private emit() {
    const html = this.chipsToTokens(this.editableRef.nativeElement.innerHTML)
    this.lastEmitted = html
    this.htmlChange.emit(html)
  }

  /** Raw `{{token}}` text (as stored/sent) → labeled, non-editable chip spans (as displayed). */
  private tokensToChips(html: string): string {
    let out = html
    for (const tag of this.mergeTags) {
      if (tag.variants?.length) {
        const base = tag.token.slice(2, -2) // strip {{ }}
        const re = new RegExp(`\\{\\{${base}(?::(\\w+))?\\}\\}`, 'g')
        out = out.replace(re, (_match, suffix) => {
          const variant = tag.variants!.find(v => v.suffix === suffix) ?? tag.variants![0]
          const rawToken = suffix ? `{{${base}:${suffix}}}` : tag.token
          return `<span contenteditable="false" data-token="${rawToken}" style="display:inline-block;background:#eef2ff;color:#4338ca;border:1px solid #c7d2fe;border-radius:6px;padding:1px 8px;font-size:12px;font-weight:600;">${tag.label} (${variant.label})</span>`
        })
        continue
      }
      const escaped = tag.token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const chip = `<span contenteditable="false" data-token="${tag.token}" style="display:inline-block;background:#eef2ff;color:#4338ca;border:1px solid #c7d2fe;border-radius:6px;padding:1px 8px;font-size:12px;font-weight:600;">${tag.label}</span>`
      out = out.replace(new RegExp(escaped, 'g'), chip)
    }
    return out
  }

  /** Chip spans (as displayed) → raw `{{token}}` text (as stored/sent). */
  private chipsToTokens(html: string): string {
    return html.replace(/<span[^>]*data-token="([^"]+)"[^>]*>.*?<\/span>(&nbsp;)?/g, '$1 ')
  }

  private focusEditor() {
    this.editableRef.nativeElement.focus()
  }

  // ── Toolbar commands ────────────────────────────────────────────────────
  exec(command: string, value?: string) {
    this.focusEditor()
    document.execCommand(command, false, value)
    this.refreshActiveStates()
    this.emit()
  }

  onColorPicked(color: string) {
    this.lastColor = color
    this.exec('foreColor', color)
  }

  setBlock(tag: string) {
    this.exec('formatBlock', tag)
  }

  insertLink() {
    const url = prompt('Link URL (include https://)')
    if (!url) return
    this.focusEditor()
    document.execCommand('createLink', false, url)
    this.emit()
  }

  insertLinkButton() {
    this.focusEditor()
    const sel = window.getSelection()
    this.savedRange = sel && sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null
    this.buttonUrlDraft = ''
    this.buttonTextDraft = 'Click here'
    this.showButtonModal = true
  }

  confirmInsertButton() {
    if (!this.buttonUrlDraft.trim()) { this.showButtonModal = false; return }
    this.focusEditor()
    const sel = window.getSelection()
    if (sel && this.savedRange) {
      sel.removeAllRanges()
      sel.addRange(this.savedRange)
    }
    const html = `<a href="${this.buttonUrlDraft.trim()}" style="display:inline-block;background:#4f46e5;color:#ffffff;font-weight:600;font-size:13px;padding:10px 20px;border-radius:8px;text-decoration:none;">${this.buttonTextDraft.trim() || 'Click here'}</a>&nbsp;`
    this.insertHtmlAtCursor(html)
    this.showButtonModal = false
  }

  cancelInsertButton() {
    this.showButtonModal = false
  }

triggerImageUpload(fileInput: HTMLInputElement) {
    const sel = window.getSelection()
    const range = sel && sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null
    // Collapse to the start: if the user had clicked/selected an existing
    // image (e.g. the current logo), this makes the new image insert right
    // before it instead of replacing it.
    if (range) range.collapse(true)
    this.savedRange = range
    fileInput.click()
  }



  onImageSelected(event: Event) {
    const input = event.target as HTMLInputElement
    const file = input.files?.[0]
    if (!file) return

    const isSvg = file.type === 'image/svg+xml' || file.name.toLowerCase().endsWith('.svg')

    if (isSvg) {
      if (file.size > 100 * 1024) {
        this.dialog.alert('SVG files must be under 100KB.')
        input.value = ''
        return
      }
      const reader = new FileReader()
reader.onload = () => {
        this.restoreSavedRange()
        // SVGs are never resized/downscaled — inserted exactly as uploaded.
       const html = `<img src="${reader.result}" alt="" draggable="true" data-svg="1" data-just-inserted="1" style="max-width:100%;display:inline-block;vertical-align:middle;" />`
        this.insertHtmlAtCursor(html)
        this.selectJustInserted()
      }
      reader.readAsDataURL(file)
      input.value = ''
      return
    }

    if (file.size > 10 * 1024 * 1024) {
      this.dialog.alert('Please use an image under 10MB.')
      input.value = ''
      return
    }

const reader = new FileReader()
    reader.onload = async () => {
      let dataUrl = reader.result as string
      if (file.size > 200 * 1024) {
        dataUrl = await this.compressImage(dataUrl, 200 * 1024)
      }
      this.restoreSavedRange()
     const html = `<img src="${dataUrl}" alt="" draggable="true" data-just-inserted="1" style="max-width:100%;display:inline-block;vertical-align:middle;cursor:pointer;" />`
      this.insertHtmlAtCursor(html)
      this.selectJustInserted()
    }
    reader.readAsDataURL(file)
    input.value = ''
  }

  /** Iteratively re-encodes a raster image at reduced JPEG quality/dimensions until under targetBytes. */
  private compressImage(dataUrl: string, targetBytes: number): Promise<string> {
    return new Promise((resolve) => {
      const img = new Image()
      img.onload = () => {
        let { width, height } = img
        let quality = 0.85
        const canvas = document.createElement('canvas')
        const ctx = canvas.getContext('2d')!
        let result = dataUrl

        for (let attempt = 0; attempt < 6; attempt++) {
          canvas.width = width
          canvas.height = height
          ctx.clearRect(0, 0, width, height)
          ctx.drawImage(img, 0, 0, width, height)
          result = canvas.toDataURL('image/jpeg', quality)
          const approxBytes = result.length * 0.75
          if (approxBytes <= targetBytes) break
          quality -= 0.15
          if (quality < 0.4) { width = Math.round(width * 0.8); height = Math.round(height * 0.8); quality = 0.7 }
        }
    resolve(result)
      }
      img.onerror = () => resolve(dataUrl) // don't block on an unreadable file
      img.src = dataUrl
    })
  }

  // ── Post-upload resize ──────────────────────────────────────────────────
  selectedImage: HTMLImageElement | null = null
  imageWidthPercent = 100

onEditorClick(event: MouseEvent) {
    const target = event.target as HTMLElement
    if (target.tagName === 'IMG') {
      this.selectImageEl(target as HTMLImageElement)
    } else {
      this.selectedImage = null
    }
  }

  private selectImageEl(imgEl: HTMLImageElement) {
    this.selectedImage = imgEl
    const container = this.editableRef.nativeElement.clientWidth || 1
    const currentWidth = imgEl.width || imgEl.getBoundingClientRect().width
    this.imageWidthPercent = Math.round(Math.min(100, (currentWidth / container) * 100))
  }

/** Auto-selects the image just inserted via upload and scales it to match the
   *  font-size of the text it landed next to (so a logo dropped before a
   *  heading sits at that heading's scale, not a flat 50%). Also makes the
   *  resize bar appear immediately, without requiring a click on the image. */
  private selectJustInserted() {
    const el = this.editableRef.nativeElement.querySelector('img[data-just-inserted="1"]') as HTMLImageElement | null
    if (!el) return
    el.removeAttribute('data-just-inserted')
    setTimeout(() => {
      this.selectedImage = el
      const finalizeSize = () => {
        const refNode = this.savedRange?.startContainer ?? el.parentNode
        const refEl = refNode?.nodeType === Node.TEXT_NODE ? (refNode as Node).parentElement : (refNode as HTMLElement | null)
        const fontSizePx = refEl ? parseFloat(getComputedStyle(refEl).fontSize) || 16 : 16
        const targetHeight = Math.round(fontSizePx * 1.6) // sits like an inline logo next to that text
        const ratio = el.naturalWidth && el.naturalHeight ? el.naturalWidth / el.naturalHeight : 1
        const targetWidth = Math.round(targetHeight * ratio)

        el.setAttribute('height', String(targetHeight))
        el.setAttribute('width', String(targetWidth))
        el.style.height = `${targetHeight}px`
        el.style.width = `${targetWidth}px`

        const container = this.editableRef.nativeElement.clientWidth || 1
        this.imageWidthPercent = Math.max(1, Math.min(100, Math.round((targetWidth / container) * 100)))
      }
      if (el.naturalWidth) finalizeSize()
      else el.addEventListener('load', finalizeSize, { once: true }) // data: URL may not have decoded yet
    }, 0)
  }
  private draggingImage: HTMLImageElement | null = null

  onEditorDragStart(event: DragEvent) {
    const target = event.target as HTMLElement
    if (target.tagName !== 'IMG') { event.preventDefault(); return }
    this.draggingImage = target as HTMLImageElement
    event.dataTransfer?.setData('text/plain', '') // Firefox requires data to be set to permit dragging
  }

  onEditorDragOver(event: DragEvent) {
    if (!this.draggingImage) return
    event.preventDefault() // required to allow a drop
  }

onEditorDrop(event: DragEvent) {
    if (!this.draggingImage) return
    event.preventDefault()
    const range = this.caretRangeFromPoint(event.clientX, event.clientY)
    if (range) {
      const img = this.draggingImage
      img.remove()
      // Manually repositioning an image is an explicit signal the user wants
      // it to sit inline with text — override whatever display it had before
      // (e.g. a legacy/default block-style logo), not just move the node.
      img.style.display = 'inline-block'
      img.style.verticalAlign = 'middle'
      range.insertNode(img)
      this.selectImageEl(img)
    }
    this.draggingImage = null
    this.emit()
  }

  private caretRangeFromPoint(x: number, y: number): Range | null {
    const doc = document as any
    if (doc.caretRangeFromPoint) return doc.caretRangeFromPoint(x, y) // Chrome/Safari
    if (doc.caretPositionFromPoint) {
      const pos = doc.caretPositionFromPoint(x, y) // Firefox
      if (!pos) return null
      const r = document.createRange()
      r.setStart(pos.offsetNode, pos.offset)
      r.collapse(true)
      return r
    }
    return null
  }

  onResizeSlider(value: string) {
    this.imageWidthPercent = Number(value)
    if (this.selectedImage) {
      const container = this.editableRef.nativeElement.clientWidth || 1
      const targetWidth = Math.round((this.imageWidthPercent / 100) * container)
      const ratio = this.selectedImage.naturalWidth ? targetWidth / this.selectedImage.naturalWidth : 1
      // Explicit pixel attributes — the part most email clients actually honor.
      this.selectedImage.setAttribute('width', String(targetWidth))
      this.selectedImage.setAttribute('height', String(Math.round((this.selectedImage.naturalHeight || 0) * ratio)))
      this.selectedImage.style.width = `${targetWidth}px`
      this.selectedImage.style.height = 'auto'
    }
  }

  removeSelectedImage() {
    if (this.selectedImage) {
      this.selectedImage.remove()
      this.selectedImage = null
      this.emit()
    }
  }

  applyResize() {
    this.selectedImage = null
    this.emit()
  }

  /**
   * Called by the parent right before saving. Re-encodes every raster image
   * (skips anything marked data-svg) at its current on-screen pixel width,
   * so a resize actually shrinks the stored bytes, not just the CSS box.
   */
async finalizeForSave(): Promise<string> {
    const clone = this.editableRef.nativeElement.cloneNode(true) as HTMLElement
    const imgs = Array.from(clone.querySelectorAll('img')) as HTMLImageElement[]
    const liveImgs = Array.from(this.editableRef.nativeElement.querySelectorAll('img')) as HTMLImageElement[]

    for (let i = 0; i < imgs.length; i++) {
      const cloneImg = imgs[i]
      const liveImg = liveImgs[i]
      if (!liveImg || cloneImg.dataset['svg'] === '1') continue
      // Pasted content (signatures, docs) often brings in remote/cid <img> src,
      // not data: URLs. Those can't be canvas-resized — skip them entirely.
      if (!cloneImg.src.startsWith('data:')) continue
      const targetWidth = liveImg.width || Math.round(liveImg.getBoundingClientRect().width) || liveImg.naturalWidth
      if (!targetWidth || targetWidth >= liveImg.naturalWidth) continue // no downscale needed
try {
        const resized = await this.downscaleToWidth(cloneImg.src, targetWidth)
        cloneImg.src = resized
        cloneImg.setAttribute('width', String(targetWidth))
        cloneImg.style.width = `${targetWidth}px` // update size only — keep whatever display/alignment it already had (e.g. inline-block logos)
      } catch {
        // Resize failed — keep the original image rather than blocking save.
      }
    }
    return this.chipsToTokens(clone.innerHTML)
  }

  private downscaleToWidth(dataUrl: string, targetWidth: number): Promise<string> {
    return new Promise((resolve, reject) => {
      const img = new Image()
      img.onload = () => {
        try {
          const ratio = targetWidth / img.width
          const canvas = document.createElement('canvas')
          canvas.width = targetWidth
          canvas.height = Math.round(img.height * ratio)
          const ctx = canvas.getContext('2d')!
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
          resolve(canvas.toDataURL('image/jpeg', 0.85))
        } catch (err) {
          reject(err) // e.g. tainted-canvas SecurityError
        }
      }
      img.onerror = () => reject(new Error('Image failed to load'))
      img.src = dataUrl
    })
  }

  // Merge-tag variant picker (e.g. Customer Name → First / Last / Full / Last, First)
  showVariantPicker = false
  variantPickerFor: MergeTag | null = null

  insertMergeTag(tag: MergeTag) {
    if (tag.variants?.length) {
      this.focusEditor()
      const sel = window.getSelection()
      this.savedRange = sel && sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null
      this.variantPickerFor = tag
      this.showVariantPicker = true
      return
    }
    this.insertChip(tag.label, tag.token)
  }

  chooseVariant(variant: MergeTagVariant) {
    const tag = this.variantPickerFor
    this.showVariantPicker = false
    if (!tag) return
    this.focusEditor()
    const sel = window.getSelection()
    if (sel && this.savedRange) { sel.removeAllRanges(); sel.addRange(this.savedRange) }
    const rawToken = tag.token.replace('}}', `:${variant.suffix}}}`)
    this.insertChip(`${tag.label} (${variant.label})`, rawToken)
  }

  cancelVariantPicker() {
    this.showVariantPicker = false
    this.variantPickerFor = null
  }

  private insertChip(label: string, token: string) {
    const chip = `<span contenteditable="false" data-token="${token}" style="display:inline-block;background:#eef2ff;color:#4338ca;border:1px solid #c7d2fe;border-radius:6px;padding:1px 8px;font-size:12px;font-weight:600;">${label}</span>&nbsp;`
    this.insertHtmlAtCursor(chip)
  }

  clearFormatting() {
    this.exec('removeFormat')
  }

private insertHtmlAtCursor(html: string) {
    let sel = window.getSelection()
    // Only refocus if there's no valid selection already inside the editor —
    // refocusing unconditionally here was clobbering a range a caller (e.g.
    // restoreSavedRange) had just carefully restored.
    const hasValidSelection = !!sel && sel.rangeCount > 0 &&
      this.editableRef.nativeElement.contains(sel.getRangeAt(0).commonAncestorContainer)
    if (!hasValidSelection) {
      this.focusEditor()
      sel = window.getSelection()
    }
    if (!sel || !sel.rangeCount) {
      this.editableRef.nativeElement.insertAdjacentHTML('beforeend', html)
      this.emit()
      return
    }
    document.execCommand('insertHTML', false, html)
    this.emit()
  }

  // ── Paste handling: keep formatting/links/images, strip scripts & tracking ──
  onPaste(event: ClipboardEvent) {
    event.preventDefault()
    const html = event.clipboardData?.getData('text/html')
    const text = event.clipboardData?.getData('text/plain') ?? ''
    const clean = html ? this.sanitizePastedHtml(html) : this.escapeHtml(text).replace(/\n/g, '<br/>')
    document.execCommand('insertHTML', false, clean)
    this.emit()
  }

  private sanitizePastedHtml(html: string): string {
    return html
      .replace(/<(script|iframe|object|embed|link|meta|style)[^>]*>[\s\S]*?<\/\1>/gi, '')
      .replace(/<(script|iframe|object|embed|link|meta)[^>]*\/?>/gi, '')
      .replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '')
      .replace(/(href|src)\s*=\s*(["'])\s*javascript:[^"']*\2/gi, '$1="#"')
  }

  private escapeHtml(s: string): string {
    const div = document.createElement('div')
    div.textContent = s
    return div.innerHTML
  }

  onInput() {
    this.emit()
  }

private restoreSavedRange() {
    if (!this.savedRange) return
    this.focusEditor() // focus BEFORE restoring — focusing after wipes the selection
    const sel = window.getSelection()
    if (sel) { sel.removeAllRanges(); sel.addRange(this.savedRange) }
  }
}