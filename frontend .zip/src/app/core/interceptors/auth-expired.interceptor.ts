import { HttpInterceptorFn } from '@angular/common/http'
import { inject } from '@angular/core'
import { catchError, throwError } from 'rxjs'
import { AuthService } from '../../service/auth.service'

export const authExpiredInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService)

  return next(req).pipe(
    catchError((err) => {
      if (err.status === 401) {
        auth.logout()   // already clears storage and navigates to /login
      }
      return throwError(() => err)
    })
  )
}