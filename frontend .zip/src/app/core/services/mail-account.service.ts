import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { environment } from '../../../environments/environment'
import { AuthService } from '../../service/auth.service'
import { MailAccount } from '../models/mail-account.model'

@Injectable({ providedIn: 'root' })
export class MailAccountService {
  private base = environment.apiUrl

  constructor(private http: HttpClient, private auth: AuthService) {}

  list() {
    return this.http.get<MailAccount[]>(`${this.base}/mail-accounts`, { headers: this.auth.getAuthHeaders() })
  }

  /** Full-page navigation (not an XHR) — this has to hit Microsoft's login page. */
  connectUrl(): string {
    return `${this.base}/mail-accounts/connect`
  }

  disconnect(id: number) {
    return this.http.post<any>(`${this.base}/mail-accounts/${id}/disconnect`, {}, { headers: this.auth.getAuthHeaders() })
  }

  setDefault(id: number) {
    return this.http.post<any>(`${this.base}/mail-accounts/${id}/set-default`, {}, { headers: this.auth.getAuthHeaders() })
  }

  /** Fetches the full step-by-step trace for one connect attempt (see traceId on the callback redirect). */
  getTrace(traceId: string) {
    return this.http.get<any>(`${this.base}/mail-accounts/debug/${traceId}`, { headers: this.auth.getAuthHeaders() })
  }
}