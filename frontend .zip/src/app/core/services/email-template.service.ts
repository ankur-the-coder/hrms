import { Injectable, inject } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { environment } from '../../../environments/environment'
import { AuthService } from '../../service/auth.service'

export type EmailTemplateKey = 'auto_ticket_response' | 'ticket_closure' | 'agent_footer_default'

export interface EmailTemplateRow {
  template_key: EmailTemplateKey
  html: string
  default_html: string
  updated_at: string
}

@Injectable({ providedIn: 'root' })
export class EmailTemplateService {
  private http = inject(HttpClient)
  private auth = inject(AuthService)
  private base = `${environment.apiUrl}`

  list() {
    return this.http.get<EmailTemplateRow[]>(`${this.base}/email-templates`, { headers: this.auth.getAuthHeaders() })
  }

  update(key: EmailTemplateKey, html: string) {
    return this.http.post<any>(`${this.base}/email-templates/${key}/update`, { html }, { headers: this.auth.getAuthHeaders() })
  }

  reset(key: EmailTemplateKey) {
    return this.http.post<any>(`${this.base}/email-templates/${key}/reset`, {}, { headers: this.auth.getAuthHeaders() })
  }
}