import { Injectable, signal } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { environment } from '../../../environments/environment'

export interface ResyncResult {
  status: true
  ticketId: number
  ticketUid: string
  totalMessages: number
  messagesInserted: number
  attachmentsUploaded: number
  attachmentsReused: number
}

@Injectable({ providedIn: 'root' })
export class TicketResyncService {
  private base = environment.apiUrl
  private readonly STORAGE_KEY = 'enable_ticket_resync'

  /**
   * Reactive signal that tracks whether the re-sync button is enabled on this workstation.
   * Stored in localStorage so it applies ONLY to the person/browser currently working on this panel.
   */
  resyncEnabled = signal<boolean>(
    localStorage.getItem(this.STORAGE_KEY) === 'true'
  )

  constructor(private http: HttpClient) {}

  /**
   * Toggle the setting for the current user/workstation in localStorage.
   */
  setResyncEnabled(enabled: boolean): void {
    this.resyncEnabled.set(enabled)
    localStorage.setItem(this.STORAGE_KEY, String(enabled))
  }

  /**
   * Trigger a full re-sync of all Outlook conversation messages for the given
   * ticket UID (e.g. "UBI-162090"). No auth header is required by the API.
   */
  resyncTicket(ticketUid: string) {
    return this.http.post<ResyncResult>(
      `${this.base}/tickets/uid/${ticketUid}/resync-mail`,
      {}
    )
  }

  /**
   * Same as above but by internal ticket ID.
   */
  resyncTicketById(ticketId: number) {
    return this.http.post<ResyncResult>(
      `${this.base}/tickets/${ticketId}/resync-mail`,
      {}
    )
  }
}
