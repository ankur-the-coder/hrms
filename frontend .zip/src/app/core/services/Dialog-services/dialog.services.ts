import { Injectable, signal } from '@angular/core'

export type DialogVariant = 'default' | 'danger'

export interface ConfirmOptions {
  title?: string
  message: string
  confirmLabel?: string
  cancelLabel?: string
  variant?: DialogVariant
}

export interface AlertOptions {
  title?: string
  message: string
  okLabel?: string
  variant?: DialogVariant
}

export interface PromptOptions {
  title?: string
  message?: string
  placeholder?: string
  defaultValue?: string
  confirmLabel?: string
  cancelLabel?: string
  variant?: DialogVariant
}

// Internal shape the modal component renders — always has both callbacks so
// the template stays a single branch; `mode` just controls whether the
// Cancel button / text input are shown.
interface DialogState {
  mode: 'confirm' | 'alert' | 'prompt'
  title: string
  message: string
  confirmLabel: string
  cancelLabel: string
  variant: DialogVariant
  inputValue: string
  inputPlaceholder: string
  resolve: (value: boolean | string | null) => void
}

/**
 * App-wide replacement for window.confirm()/window.alert(). Native browser
 * dialogs are blocking, unstyled, and (on some platforms) can be suppressed
 * entirely by the user — every confirmation/notice in ubiDesk should go
 * through this instead so it renders as the same custom modal everywhere.
 *
 * Mounted once at the root via <app-confirm-dialog> (see app.html) and
 * driven by the `request` signal below; any component can inject this
 * service and `await` confirm()/alert() exactly like the native calls they
 * replace, just async.
 */
@Injectable({ providedIn: 'root' })
export class DialogService {
  request = signal<DialogState | null>(null)

  confirm(options: ConfirmOptions | string): Promise<boolean> {
    const opts: ConfirmOptions = typeof options === 'string' ? { message: options } : options
    return new Promise<boolean>((resolve) => {
      this.request.set({
        mode: 'confirm',
        title: opts.title ?? 'Please confirm',
        message: opts.message,
        confirmLabel: opts.confirmLabel ?? 'Confirm',
        cancelLabel: opts.cancelLabel ?? 'Cancel',
        variant: opts.variant ?? 'default',
        inputValue: '',
        inputPlaceholder: '',
        resolve: (v) => resolve(v as boolean),
      })
    })
  }

  alert(options: AlertOptions | string): Promise<void> {
    const opts: AlertOptions = typeof options === 'string' ? { message: options } : options
    return new Promise<void>((resolve) => {
      this.request.set({
        mode: 'alert',
        title: opts.title ?? 'Notice',
        message: opts.message,
        confirmLabel: opts.okLabel ?? 'OK',
        cancelLabel: '',
        variant: opts.variant ?? 'default',
        inputValue: '',
        inputPlaceholder: '',
        resolve: () => resolve(),
      })
    })
  }

  // Replaces window.prompt(). Resolves with the trimmed input string, or
  // null on cancel — same null-on-cancel contract as the native call it
  // replaces, so existing `if (!x) return` call sites keep working as-is.
  prompt(options: PromptOptions | string): Promise<string | null> {
    const opts: PromptOptions = typeof options === 'string' ? { message: options } : options
    return new Promise<string | null>((resolve) => {
      this.request.set({
        mode: 'prompt',
        title: opts.title ?? 'Enter a value',
        message: opts.message ?? '',
        confirmLabel: opts.confirmLabel ?? 'OK',
        cancelLabel: opts.cancelLabel ?? 'Cancel',
        variant: opts.variant ?? 'default',
        inputValue: opts.defaultValue ?? '',
        inputPlaceholder: opts.placeholder ?? '',
        resolve: (v) => resolve(v as string | null),
      })
    })
  }

  // Called by the modal component for confirm/alert.
  respond(value: boolean) {
    const req = this.request()
    if (!req) return
    this.request.set(null)
    req.resolve(value)
  }

  // Called by the modal component for prompt — Cancel passes null, same
  // as the native window.prompt() it replaces.
  respondPrompt(value: string | null) {
    const req = this.request()
    if (!req) return
    this.request.set(null)
    req.resolve(value)
  }
}