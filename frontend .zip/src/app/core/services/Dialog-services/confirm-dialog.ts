import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { DialogService } from './dialog.services'

// Single global mount (see app.html) for every confirm()/alert()/prompt()
// in the app — replaces window.confirm/window.alert/window.prompt
// everywhere so there's exactly one modal look-and-feel instead of native
// browser dialogs sprinkled around individual features.
@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './confirm-dialog.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConfirmDialogComponent {
  dialog = inject(DialogService)

  // Local, editable mirror of the request's inputValue. The service's
  // DialogState is read-only from here, so the prompt <input> needs its
  // own signal to bind [(ngModel)] against — reset whenever a new prompt
  // request comes in.
  promptValue = signal('')

  constructor() {
    effect(() => {
      const req = this.dialog.request()
      this.promptValue.set(req?.mode === 'prompt' ? req.inputValue : '')
    })
  }

  onCancel() {
    const req = this.dialog.request()
    if (req?.mode === 'prompt') { this.dialog.respondPrompt(null); return }
    this.dialog.respond(false)
  }

  onConfirm() {
    const req = this.dialog.request()
    if (req?.mode === 'prompt') {
      const value = this.promptValue().trim()
      if (!value) return // mirrors the disabled submit button — no empty submits
      this.dialog.respondPrompt(value)
      return
    }
    this.dialog.respond(true)
  }
}