import { Injectable, signal } from '@angular/core'
import { io, Socket } from 'socket.io-client'
import { environment } from '../../../environments/environment'
import { TicketMessage } from '../models/ticket.model'
import { DebugLogEntry, DebugLogLevel, DebugLogSource } from '../models/debug-log.model'
import { ServerDiagnostics } from '../models/server-diagnostic.modal'

@Injectable({ providedIn: 'root' })
export class TicketSocketService {
  private socket!: Socket

  // Version counters — components `effect()` on these and refetch via TicketService.
  // Keeps this service dumb (no REST calls, no circular deps).
  ticketsVersion   = signal(0)
  statsVersion     = signal(0)
  activeMessages   = signal<TicketMessage[]>([])
  typingMap        = signal<Record<number, boolean>>({})

  // ===========================================================================
  // DEBUG LOG SYSTEM — backs the "i" button / debug modal in the sidebar.
  // Two feeds merge into one signal:
  //   1. Everything this browser tab does with the socket (connect, drop,
  //      reconnect attempts, transport upgrades, every emit/received event).
  //   2. Everything the SERVER pushes via 'debug_log' / 'debug_log_history',
  //      once this client subscribes — includes engine-level connection
  //      errors ("session id unknown" etc) that never reach the browser as
  //      a normal client-side event at all.
  // This is what lets you see *why* a socket got stuck instead of just
  // that it did.
  // ===========================================================================
  private static readonly MAX_LOGS = 400
  debugLogs = signal<DebugLogEntry[]>([])
  connectionInfo = signal<{ connected: boolean; transport: string | null; socketId: string | null; reconnectAttempts: number }>({
    connected: false, transport: null, socketId: null, reconnectAttempts: 0,
  })
  // Shared open/close state for the debug modal — the sidebar's "i" button
  // sets this true, the modal component (rendered once in app-shell) reads
  // it directly. Kept on the service (not local component state) so any
  // future entry point can pop the same panel open.
  debugPanelOpen = signal(false)

  // Server environment snapshot (Node/host/memory/DB/socket-transport info)
  // — backs the "Environment" tab in the debug modal. Populated once on
  // subscribe, then refreshed automatically every ~15s by the server for
  // as long as this socket stays subscribed. `null` until the first
  // snapshot arrives.
  serverDiagnostics = signal<ServerDiagnostics | null>(null)

  private logSeq = 0
  private pushLog(level: DebugLogLevel, source: DebugLogSource, message: string, data?: any) {
    const entry: DebugLogEntry = { id: `c-${Date.now()}-${this.logSeq++}`, ts: Date.now(), level, source, message, data }
    this.debugLogs.update(list => {
      const next = [...list, entry]
      return next.length > TicketSocketService.MAX_LOGS ? next.slice(next.length - TicketSocketService.MAX_LOGS) : next
    })
  }

  clearLogs() {
    this.debugLogs.set([])
  }

  connect(agentId: number, agentName: string, role: string) {
    if (this.socket?.connected) return
    // IMPORTANT: a path segment inside the connection URL (e.g. passing
    // `${origin}/api` as the url) is parsed by socket.io-client as a
    // NAMESPACE, not an HTTP path — it would NOT change which URL polling/
    // websocket requests hit. The actual HTTP endpoint is controlled by the
    // separate `path` option below, which defaults to '/socket.io/' if
    // omitted.
    //
    // In production, our reverse proxy only forwards /api/* to this
    // backend, so the client needs `/api/socket.io` explicitly. In local
    // dev there's no such proxy — Angular talks directly to the Adonis
    // server on :3000, which serves Socket.IO at its own default
    // '/socket.io' — so passing '/api/socket.io' there would 404. Only
    const token = localStorage.getItem('agent_token')
    const opts: any = {
      auth: { token, agentId, agentName, role }
    }
    if (environment.production) {
      opts.path = '/api/socket.io'
    }
    this.socket = io(environment.socketUrl, opts)

    // Was: emitted once right after io() and never again. socket.io-client
    // auto-reconnects the transport on drop, but it does NOT auto re-send
    // app-level "join_agent" — so after any reconnect the server no longer
    // has this socket in `agent_${id}`'s room until a full page refresh.
    // Emitting on 'connect' covers both the first connection and every
    // reconnect after a drop.
    this.socket.on('connect', () => {
      this.socket.emit('join_agent', { agentId, agentName, role, token, device: navigator.userAgent })
      const transport = (this.socket.io.engine as any)?.transport?.name ?? null
      this.connectionInfo.set({ connected: true, transport, socketId: this.socket.id ?? null, reconnectAttempts: 0 })
      this.pushLog('info', 'client', 'connected', { socketId: this.socket.id, transport })
      // Ask the server to start streaming its own debug log feed (and
      // periodic environment diagnostics) to us, and backfill whatever it
      // already has buffered (including anything that happened on the
      // server before this tab was even open).
      this.socket.emit('subscribe_debug_logs')

      // A reconnect gives us a brand-new server-side socket with empty
      // rooms — join_ticket'ing on the OLD connection doesn't carry over.
      // Without this, an agent viewing a ticket during a drop/reconnect
      // silently stops receiving new_ticket_message/message_updated for it
      // until they navigate away and back.
      if (this.currentTicketId !== null) {
        this.socket.emit('join_ticket', this.currentTicketId)
        this.pushLog('debug', 'client', 're-joined ticket room after reconnect', { ticketId: this.currentTicketId })
      }

      // Track live transport upgrades (polling → websocket, or a forced
      // downgrade) — a socket stuck permanently on 'polling' with frequent
      // reconnects is the signature of a production load-balancer/proxy
      // issue (missing sticky sessions or WebSocket upgrade headers).
      const engine = (this.socket.io.engine as any)
      engine?.on('upgrade', (t: any) => {
        this.connectionInfo.update(c => ({ ...c, transport: t.name }))
        this.pushLog('debug', 'client', 'transport upgraded', { transport: t.name })
      })
    })

    this.socket.on('disconnect', (reason) => {
      this.connectionInfo.update(c => ({ ...c, connected: false }))
      this.pushLog('warn', 'client', `disconnected: ${reason}`, { reason })
    })

    this.socket.on('connect_error', (err: any) => {
      this.pushLog('error', 'client', `connect_error: ${err?.message || err}`, { message: err?.message, description: (err as any)?.description })
    })

    this.socket.io.on('reconnect_attempt', (attempt: number) => {
      this.connectionInfo.update(c => ({ ...c, reconnectAttempts: attempt }))
      this.pushLog('warn', 'client', `reconnect attempt #${attempt}`)
    })
    this.socket.io.on('reconnect', (attempt: number) => {
      this.pushLog('info', 'client', `reconnected after ${attempt} attempt(s)`)
    })
    this.socket.io.on('reconnect_failed', () => {
      this.pushLog('error', 'client', 'reconnect failed — giving up')
    })
    this.socket.io.on('error', (err: any) => {
      this.pushLog('error', 'client', `manager error: ${err?.message || err}`)
    })

    // Server-pushed debug feed.
    this.socket.on('debug_log_history', (entries: DebugLogEntry[]) => {
      if (!Array.isArray(entries) || entries.length === 0) return
      this.debugLogs.update(list => {
        const known = new Set(list.map(l => l.id))
        const merged = [...list, ...entries.filter(e => !known.has(e.id))]
        merged.sort((a, b) => a.ts - b.ts)
        return merged.length > TicketSocketService.MAX_LOGS ? merged.slice(merged.length - TicketSocketService.MAX_LOGS) : merged
      })
    })
    this.socket.on('debug_log', (entry: DebugLogEntry) => {
      this.debugLogs.update(list => {
        const next = [...list, entry]
        return next.length > TicketSocketService.MAX_LOGS ? next.slice(next.length - TicketSocketService.MAX_LOGS) : next
      })
    })

    // Server environment snapshot — sent once on subscribe, then every
    // ~15s automatically, and again on-demand via requestDiagnostics().
    this.socket.on('server_diagnostics', (snapshot: ServerDiagnostics) => {
      this.serverDiagnostics.set(snapshot)
    })

    this.socket.on('tickets_updated',        () => this.ticketsVersion.update(v => v + 1))
    this.socket.on('ticket_bump',             () => this.ticketsVersion.update(v => v + 1))
    this.socket.on('dashboard_stats_stale',   () => this.statsVersion.update(v => v + 1))
    this.socket.on('new_ticket_message', (msg: TicketMessage) => {
      // [WA-TRACE F1] Confirms the browser actually received this over the
      // socket, and what delivery_status it arrived with.
      console.log('[WA-TRACE F1] new_ticket_message received:', msg.id, 'delivery_status=', (msg as any).delivery_status, msg)
      this.pushLog('debug', 'client', 'new_ticket_message received', { id: msg.id, delivery_status: (msg as any).delivery_status })
      this.activeMessages.update(list => [...list, msg])
    })
    // Delivery/read-receipt ticks (and retry sent/failed updates) patch an
    // existing bubble in place rather than appending a new one.
    this.socket.on('message_updated', (msg: TicketMessage) => {
      // [WA-TRACE F2] Confirms the browser received a delivered/read patch.
      // If you NEVER see this log when you know Meta delivered/read the
      // message, the backend never emitted it — go check the W-series logs
      // server-side instead, this is purely a receipt confirmation.
      console.log('[WA-TRACE F2] message_updated received:', msg.id, 'delivery_status=', (msg as any).delivery_status, msg)
      this.pushLog('debug', 'client', 'message_updated received', { id: msg.id, delivery_status: (msg as any).delivery_status })
      this.activeMessages.update(list => list.map(m => (m.id === msg.id ? { ...m, ...msg } : m)))
    })
    this.socket.on('ticket_typing', (data: { ticketId: number; isTyping: boolean }) => {
      this.typingMap.update(m => ({ ...m, [data.ticketId]: data.isTyping }))
    })
    this.socket.on('login_blocked', (data: any) => {
      this.pushLog('warn', 'client', 'login_blocked', data)
      /* surfaced by login component already */
    })
    this.socket.on('message_rejected', (data: any) => {
      this.pushLog('error', 'client', 'message_rejected', data)
    })
  }

  // Tracks whichever ticket room this socket is currently a member of. Every
  // call site (ticket-detail, conversation-thread, ...) used to call
  // joinTicket() on switch without ever calling leaveTicket() for the ticket
  // it was leaving — the socket stayed subscribed to every ticket room it had
  // ever visited in the session. Server-side emits are correctly scoped to
  // `ticket_${id}` rooms, so a still-joined old room kept delivering that
  // ticket's new_ticket_message events to this client long after the agent
  // navigated away, and they'd get merged into whatever ticket happened to be
  // open at the time (see the ticket_id filter in the consuming components).
  // Doing the leave here, once, means every call site gets it for free.
  private currentTicketId: number | null = null

  joinTicket(ticketId: number) {
    if (this.currentTicketId !== null && this.currentTicketId !== ticketId) {
      this.socket.emit('leave_ticket', this.currentTicketId)
    }
    this.currentTicketId = ticketId
    this.activeMessages.set([])
    this.socket.emit('join_ticket', ticketId)
    this.pushLog('debug', 'client', 'join_ticket', { ticketId })
  }

  leaveTicket(ticketId: number) {
    if (this.currentTicketId === ticketId) this.currentTicketId = null
    this.socket.emit('leave_ticket', ticketId)
  }

  // Was: fire-and-forget — emitted 'ticket_message' and just hoped the
  // server-broadcast echo ('new_ticket_message') would eventually come back
  // to swap the "Sending..." placeholder for a real message. If the socket
  // never actually delivered the emit (or the echo never made it back —
  // e.g. the production polling-retry-storm issue), there was NO error and
  // NO timeout, so the UI sat on "Sending..." forever with nothing to debug.
  //
  // Now uses a Socket.IO ack with a timeout: the server calls back with
  // {ok:true} once the message is saved+broadcast, or {ok:false, error}
  // on failure. If neither happens within 8s (dead/looping connection),
  // socket.io-client's timeout() fires the callback with an error itself.
  // Either way, the caller now gets a definite result instead of silence.
  sendMessage(
    payload: {
      ticketId: number
      sender: string
      type: string
      message: string
      replyMode?: 'reply' | 'reply_all' | 'reply_selected' | 'forward'
      agentId?: number
      recipients?: { to?: string[]; cc?: string[] }
    },
    onResult?: (result: { ok: boolean; error?: string }) => void
  ) {
    this.pushLog('debug', 'client', 'ticket_message emit', { ticketId: payload.ticketId, type: payload.type })
    this.socket.timeout(8000).emit('ticket_message', payload, (err: any, response: any) => {
      if (err) {
        // Ack timeout, or the socket dropped before one arrived.
        this.pushLog('error', 'client', 'ticket_message ack timeout', { ticketId: payload.ticketId, err: err?.message || String(err) })
        onResult?.({ ok: false, error: 'No response from server — check your connection.' })
        return
      }
      if (response?.ok === false) {
        this.pushLog('error', 'client', 'ticket_message rejected by server', { ticketId: payload.ticketId, error: response.error })
        onResult?.({ ok: false, error: response.error || 'Failed to send message' })
        return
      }
      onResult?.({ ok: true })
    })
  }

  updateStatus(ticketId: number, status: string, sendClosureMessage = false) {
    this.socket.emit('update_ticket_status', { ticketId, status, sendClosureMessage })
  }

  // Was fire-and-forget with no ack — a failed assign (e.g. the
  // requester.role crash when `requester` came back null) or one blocked
  // by the "picked up by another agent" guard failed completely silently:
  // no error shown, and the local `ticket` signal never updated even on
  // success (nothing was listening for 'ticket_assigned' either), so the
  // "Pick up" button just sat there looking like it did nothing.
  assignTicket(
    ticketId: number,
    agentId: number,
    agentName: string,
    onResult?: (result: { ok: boolean; error?: string; ticket?: any }) => void
  ) {
    this.socket.timeout(8000).emit('assign_ticket', { ticketId, agentId, agentName }, (err: any, response: any) => {
      if (err) {
        this.pushLog('error', 'client', 'assign_ticket ack timeout', { ticketId, err: err?.message || String(err) })
        onResult?.({ ok: false, error: 'Request timed out — check your connection and try again.' })
        return
      }
      onResult?.(response ?? { ok: false, error: 'No response from server' })
    })
  }

  setTyping(ticketId: number, sender: string, isTyping: boolean) {
    this.socket.emit('ticket_typing', { ticketId, sender, isTyping })
  }

  // Manual refresh for the debug modal's "Refresh" button — server also
  // pushes this automatically every ~15s while subscribed, so this is only
  // needed when you don't want to wait for the next tick.
  requestDiagnostics() {
    this.socket.emit('request_diagnostics')
  }
}