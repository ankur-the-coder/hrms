import { Injectable, signal } from '@angular/core'

@Injectable({ providedIn: 'root' })
export class LayoutService {
  sidebarHidden = signal(false)

  // <main> in app-shell (not document.body) is the element that actually
  // scrolls — app-shell's root is `h-screen` and <main> is `overflow-y-auto`
  // inside it, so document.body never has its own scrollbar to lock in the
  // first place. Anything that needs to lock background scroll while an
  // overlay is open (e.g. the tickets quick-view flap) should toggle this
  // instead of touching document.body directly.
  scrollLocked = signal(false)

  // Icon-only collapsed rail toggle for the sidebar (the "«" control) —
  // separate from sidebarHidden above, which removes the sidebar entirely.
  sidebarCollapsed = signal(false)
}