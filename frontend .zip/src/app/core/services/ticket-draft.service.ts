import { Injectable, signal } from '@angular/core'

const PREFIX = 'ticket_draft_'

export interface DraftAttachment {
  fileName: string
  contentType?: string
  size?: number
  storagePath: string
}

/**
 * Persists an agent's unsent reply text (and any already-uploaded
 * attachments) to a ticket in the browser's localStorage, so it survives
 * closing the compose drawer, switching tickets, or reloading the page.
 *
 * `draftTicketIds` is a signal (not just a plain localStorage read) so that
 * every component sharing this singleton — the ticket-list row tags and the
 * ticket-detail composer alike — reacts immediately when a draft is saved,
 * updated, or cleared. This matters in particular for the "quick view" flap
 * (app-ticket-detail embedded inside ticket-list): closing it doesn't
 * navigate/remount anything, so without a shared reactive signal the list's
 * (draft) tag wouldn't update until a manual refetch.
 */
@Injectable({ providedIn: 'root' })
export class TicketDraftService {
  draftTicketIds = signal<Set<number>>(this.readAllDraftIds())

  private key(ticketId: number) {
    return `${PREFIX}${ticketId}`
  }

  private readAllDraftIds(): Set<number> {
    const ids = new Set<number>()
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i)
        if (k && k.startsWith(PREFIX)) {
          const id = Number(k.slice(PREFIX.length))
          if (!Number.isNaN(id)) ids.add(id)
        }
      }
    } catch {
      // localStorage unavailable (SSR / private-mode edge cases) — treat as empty
    }
    return ids
  }

  hasDraft(ticketId: number): boolean {
    return this.draftTicketIds().has(ticketId)
  }

  /** Returns the saved draft HTML for a ticket, or '' if none exists. */
  load(ticketId: number): string {
    return this.loadFull(ticketId).html
  }

  /** Returns the saved draft's attachments for a ticket, or [] if none exist. */
  loadAttachments(ticketId: number): DraftAttachment[] {
    return this.loadFull(ticketId).attachments
  }

  /** Returns the saved draft's custom CC list for a ticket, or [] if none exist. */
  loadCc(ticketId: number): string[] {
    return this.loadFull(ticketId).cc
  }

  /** Returns the saved draft's custom BCC list for a ticket, or [] if none exist. */
  loadBcc(ticketId: number): string[] {
    return this.loadFull(ticketId).bcc
  }

  /**
   * Reads and parses the stored value for a ticket. Storage historically
   * held a raw HTML string (pre-attachments format); that's still read
   * fine here, just with empty attachments/cc/bcc lists, so old drafts already
   * sitting in agents' browsers don't break/disappear after this update.
   */
  private loadFull(ticketId: number): { html: string; attachments: DraftAttachment[]; cc: string[]; bcc: string[] } {
    try {
      const raw = localStorage.getItem(this.key(ticketId))
      if (!raw) return { html: '', attachments: [], cc: [], bcc: [] }

      try {
        const parsed = JSON.parse(raw)
        if (parsed && typeof parsed === 'object' && 'html' in parsed) {
          return {
            html: parsed.html ?? '',
            attachments: parsed.attachments ?? [],
            cc: Array.isArray(parsed.cc) ? parsed.cc : [],
            bcc: Array.isArray(parsed.bcc) ? parsed.bcc : [],
          }
        }
      } catch {
        // Not JSON — pre-migration draft, stored as a raw HTML string. Fall through.
      }
      return { html: raw, attachments: [], cc: [], bcc: [] }
    } catch {
      return { html: '', attachments: [], cc: [], bcc: [] }
    }
  }

  /**
   * Saves `html` (and any uploaded `attachments`, `cc`, `bcc`) as the ticket's draft.
   * An empty/whitespace-only html AND no attachments AND no cc/bcc
   * is treated as "no draft" and clears it instead.
   */
  save(ticketId: number, html: string, attachments: DraftAttachment[] = [], cc: string[] = [], bcc: string[] = []) {
    const plainText = (html || '')
      .replace(/<[^>]*>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .trim()

    if (!plainText && !attachments.length && !cc.length && !bcc.length) {
      this.clear(ticketId)
      return
    }

    try {
      localStorage.setItem(this.key(ticketId), JSON.stringify({ html, attachments, cc, bcc }))
    } catch {
      // storage full/unavailable — draft just won't persist, non-fatal
    }

    if (!this.draftTicketIds().has(ticketId)) {
      this.draftTicketIds.update(ids => new Set(ids).add(ticketId))
    }
  }

  clear(ticketId: number) {
    try {
      localStorage.removeItem(this.key(ticketId))
    } catch {
      // ignore
    }
    if (this.draftTicketIds().has(ticketId)) {
      this.draftTicketIds.update(ids => {
        const next = new Set(ids)
        next.delete(ticketId)
        return next
      })
    }
  }
}