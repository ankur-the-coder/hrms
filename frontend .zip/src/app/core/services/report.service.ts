import { Injectable, inject } from '@angular/core'
import { HttpClient, HttpParams } from '@angular/common/http'
import { environment } from '../../../environments/environment'
import { AuthService } from '../../service/auth.service'
import { Observable } from 'rxjs'

export interface ReportKpis {
  total: number
  open: number
  onHold: number
  escalated: number
  closed: number
  reopened: number
  unassigned: number
  spam: number
  resolutionRate: number
  reopenRate: number
  ratingCount: number
  avgCsat: number | null
  avgFrtSeconds: number
  medianFrtSeconds: number
  avgResolutionSeconds: number
  medianResolutionSeconds: number
}

export interface BacklogAging {
  under24h: number
  days1To3: number
  days4To7: number
  over7d: number
}

export interface AgentPerformance {
  agentId: number
  name: string
  username: string
  role: string
  assigned: number
  closed: number
  open: number
  reopened: number
  resolutionRate: number
  avgResolutionSeconds: number | null
  avgCsat: number | null
  csatReviews: number
}

export interface ChannelStat {
  source: string
  total: number
  pct: number
  closed: number
  open: number
  avgResolutionSeconds: number | null
}

export interface PriorityStat {
  priority: string
  total: number
  pct: number
  closed: number
  open: number
}

export interface DailyTrendPoint {
  date: string
  label: string
  created: number
  closed: number
  reopened: number
}

export interface HourlyHeatmapPoint {
  hour: number
  label: string
  count: number
  pct: number
}

export interface TopOrganization {
  orgName: string
  orgId: number | null
  ticketCount: number
  closedCount: number
  openCount: number
  avgRating: number | null
  isHighPriority: boolean
}

export interface QualitativeFeedback {
  id: number
  ticket_uid: string
  customer_name: string
  rating: number
  rating_liked_most: string | null
  rating_improve_feedback: string | null
  rating_submitted_at: string
}

export interface Report360Data {
  window: {
    startDate: string
    endDate: string
    daysCount: number
  }
  kpis: ReportKpis
  backlogAging: BacklogAging
  csat: {
    average: number | null
    totalRated: number
    responseRate: number
    distribution: Record<number, number>
    recentFeedback: QualitativeFeedback[]
  }
  agentLeaderboard: AgentPerformance[]
  channels: ChannelStat[]
  priorities: PriorityStat[]
  dailyTrends: DailyTrendPoint[]
  hourlyHeatmap: HourlyHeatmapPoint[]
  topOrganizations: TopOrganization[]
  resolutionCodes: { code: string; count: number }[]
}

export interface ReportScheduleItem {
  id: number
  name: string
  recipients: string
  frequency: 'daily' | 'weekly' | 'weekday' | 'monthly'
  day_of_week?: number
  time_of_day: string
  timezone: string
  date_range: string
  include_sections?: string[]
  is_active: boolean | number
  created_by?: number
  last_run_at?: string | null
  last_run_status?: 'success' | 'failed' | null
  last_error?: string | null
  created_at: string
}

@Injectable({ providedIn: 'root' })
export class ReportService {
  private http = inject(HttpClient)
  private auth = inject(AuthService)
  private base = environment.apiUrl

  get360Report(filters: {
    startDate?: string
    endDate?: string
    source?: string
    priority?: string
    agentId?: number | string
    status?: string
  }): Observable<{ status: boolean; data: Report360Data }> {
    let params = new HttpParams()
    if (filters.startDate) params = params.set('startDate', filters.startDate)
    if (filters.endDate) params = params.set('endDate', filters.endDate)
    if (filters.source && filters.source !== 'all') params = params.set('source', filters.source)
    if (filters.priority && filters.priority !== 'all') params = params.set('priority', filters.priority)
    if (filters.agentId && filters.agentId !== 'all') params = params.set('agentId', String(filters.agentId))
    if (filters.status && filters.status !== 'all') params = params.set('status', filters.status)

    return this.http.get<{ status: boolean; data: Report360Data }>(
      `${this.base}/reports/360`,
      { params, headers: this.auth.getAuthHeaders() }
    )
  }

  exportCsv(filters: any) {
    let params = new HttpParams()
    if (filters.startDate) params = params.set('startDate', filters.startDate)
    if (filters.endDate) params = params.set('endDate', filters.endDate)
    if (filters.source && filters.source !== 'all') params = params.set('source', filters.source)
    if (filters.priority && filters.priority !== 'all') params = params.set('priority', filters.priority)
    if (filters.agentId && filters.agentId !== 'all') params = params.set('agentId', String(filters.agentId))
    if (filters.status && filters.status !== 'all') params = params.set('status', filters.status)

    return this.http.get(`${this.base}/reports/export`, {
      params,
      headers: this.auth.getAuthHeaders(),
      responseType: 'blob',
    })
  }

  getSchedules(): Observable<{ status: boolean; schedules: ReportScheduleItem[]; notice?: string }> {
    return this.http.get<{ status: boolean; schedules: ReportScheduleItem[]; notice?: string }>(
      `${this.base}/reports/schedules`,
      { headers: this.auth.getAuthHeaders() }
    )
  }

  createSchedule(payload: any): Observable<{ status: boolean; schedule: ReportScheduleItem }> {
    return this.http.post<{ status: boolean; schedule: ReportScheduleItem }>(
      `${this.base}/reports/schedules`,
      payload,
      { headers: this.auth.getAuthHeaders() }
    )
  }

  updateSchedule(id: number, payload: any): Observable<{ status: boolean; schedule: ReportScheduleItem }> {
    return this.http.put<{ status: boolean; schedule: ReportScheduleItem }>(
      `${this.base}/reports/schedules/${id}`,
      payload,
      { headers: this.auth.getAuthHeaders() }
    )
  }

  deleteSchedule(id: number): Observable<{ status: boolean; message: string }> {
    return this.http.delete<{ status: boolean; message: string }>(
      `${this.base}/reports/schedules/${id}`,
      { headers: this.auth.getAuthHeaders() }
    )
  }

  runScheduleNow(id: number): Observable<{ status: boolean; message: string; recipients: string[] }> {
    return this.http.post<{ status: boolean; message: string; recipients: string[] }>(
      `${this.base}/reports/schedules/${id}/run`,
      {},
      { headers: this.auth.getAuthHeaders() }
    )
  }
}
