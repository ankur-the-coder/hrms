import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { environment } from '../../../environments/environment'
import { AuthService } from '../../service/auth.service'

@Injectable({ providedIn: 'root' })
export class AgentService {
  private base = environment.apiUrl
  constructor(private http: HttpClient, private auth: AuthService) {}

  list() { return this.http.get<any>(`${this.base}/agents`, { headers: this.auth.getAuthHeaders() }) }
  create(payload: { name: string; username: string; password: string; role: string }) {
    return this.http.post<any>(`${this.base}/agents/create`, payload, { headers: this.auth.getAuthHeaders() })
  }
  update(payload: any) { return this.http.post<any>(`${this.base}/agents/update`, payload, { headers: this.auth.getAuthHeaders() }) }
  remove(id: number) { return this.http.post<any>(`${this.base}/agents/delete`, { id }, { headers: this.auth.getAuthHeaders() }) }

  getSignature(agentId: number) {
    return this.http.get<any>(`${this.base}/agents/${agentId}/signature`, { headers: this.auth.getAuthHeaders() })
  }
  updateSignature(agentId: number, signatureHtml: string) {
    return this.http.post<any>(`${this.base}/agents/${agentId}/signature`, { signature_html: signatureHtml }, { headers: this.auth.getAuthHeaders() })
  }
}