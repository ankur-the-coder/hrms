import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs'
import { environment } from '../../../environments/environment'
import { AuthService } from '../../service/auth.service'

export interface WhatsappAccount {
  id: number
  phone_number_id: string
  waba_id: string
  display_phone_number: string
  verified_name?: string
  is_active: boolean
  connected_at: string
}

@Injectable({ providedIn: 'root' })
export class WhatsappAccountService {
  private base = environment.apiUrl

  constructor(private http: HttpClient, private auth: AuthService) {}

  list(): Observable<WhatsappAccount[]> {
    return this.http.get<WhatsappAccount[]>(`${this.base}/whatsapp/accounts`, {
      headers: this.auth.getAuthHeaders(),
    })
  }

  connect(payload: { phoneNumberId: string; wabaId: string; displayPhoneNumber: string; accessToken: string }): Observable<any> {
    return this.http.post<any>(`${this.base}/whatsapp/accounts`, payload, {
      headers: this.auth.getAuthHeaders(),
    })
  }

  disconnect(id: number): Observable<any> {
    return this.http.delete<any>(`${this.base}/whatsapp/accounts/${id}`, {
      headers: this.auth.getAuthHeaders(),
    })
  }
}