import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs'
import { environment } from '../../../environments/environment'
import { AuthService } from '../../service/auth.service'

@Injectable({ providedIn: 'root' })
export class SettingsService {
  private base = environment.apiUrl
  constructor(private http: HttpClient, private auth: AuthService) {}

  list() { return this.http.get<any>(`${this.base}/settings`, { headers: this.auth.getAuthHeaders() }) }
  get(key: string): Observable<any> {
    return new Observable((observer) => {
      this.list().subscribe({
        next: (res: any) => {
          if (Array.isArray(res)) {
            const item = res.find((s: any) => s.key === key)
            observer.next(item ? item.value : null)
          } else if (res && typeof res === 'object') {
            observer.next(res[key] !== undefined ? res[key] : null)
          } else {
            observer.next(null)
          }
          observer.complete()
        },
        error: (err: any) => observer.error(err)
      })
    })
  }
  update(key: string, value: string) {
    return this.http.post<any>(`${this.base}/settings/update`, { key, value }, { headers: this.auth.getAuthHeaders() })
  }
}