import { Injectable } from '@angular/core'
import { HttpClient, HttpParams } from '@angular/common/http'
import { environment } from '../../../environments/environment'
import { AuthService } from '../../service/auth.service'

@Injectable({ providedIn: 'root' })
export class TicketService {
  private base = environment.apiUrl

  constructor(private http: HttpClient, private auth: AuthService) {}

  createTicket(payload: any) {
    return this.http.post<any>(`${this.base}/tickets/create`, payload, { headers: this.auth.getAuthHeaders() })
  }

  /** Fetches the next ticket ID up front so the Add Ticket modal can show
   *  it to the agent before Submit — the same value is sent back as
   *  `ticketUid` in createTicket()'s payload so what's shown = what's saved. */
  getNextTicketUid() {
    return this.http.get<{ ticketUid: string }>(`${this.base}/tickets/next-uid`, { headers: this.auth.getAuthHeaders() })
  }

  getTickets(offset = 0, limit = 20, filters: {
    status?: string; priority?: string; resolvedToday?: boolean; unassignedOnly?: boolean; source?: string;
    search?: string; unreadOnly?: boolean; deletedOnly?: boolean; assignedTo?: number[];
    // Organization-wise / contact-wise filters + the star-rating filter
    // (Ratings tab dropdown) + full sort control. All four are multi-select
    // now — each takes an array and is sent comma-separated, same pattern
    // as assignedTo below.
    orgId?: number[]; contactEmail?: string[]; contactPhone?: string[]; rating?: number[];
    sortBy?: string; sortOrder?: 'asc' | 'desc';
  } = {}) {
    let params = new HttpParams().set('offset', offset).set('limit', limit)
    if (filters.status) params = params.set('status', filters.status)
    if (filters.priority) params = params.set('priority', filters.priority)
    if (filters.resolvedToday) params = params.set('resolvedToday', 'true')
    if (filters.unassignedOnly) params = params.set('unassignedOnly', 'true')
    if (filters.source) params = params.set('source', filters.source)
    if (filters.search) params = params.set('search', filters.search)
    if (filters.unreadOnly) params = params.set('unreadOnly', 'true')
    if (filters.deletedOnly) params = params.set('deletedOnly', 'true')
    // Admin-only "Assigned To" multi-select filter — comma-separated agent
    // ids, e.g. assignedTo=3,7,12. Non-admins never see this control, but
    // the backend re-checks the requester's role too rather than trusting
    // the frontend to withhold it.
    if (filters.assignedTo?.length) params = params.set('assignedTo', filters.assignedTo.join(','))
    if (filters.orgId?.length) params = params.set('orgId', filters.orgId.join(','))
    if (filters.contactEmail?.length) params = params.set('contactEmail', filters.contactEmail.join(','))
    if (filters.contactPhone?.length) params = params.set('contactPhone', filters.contactPhone.join(','))
    if (filters.rating?.length) params = params.set('rating', filters.rating.join(','))
    if (filters.sortBy) params = params.set('sortBy', filters.sortBy)
    if (filters.sortOrder) params = params.set('sortOrder', filters.sortOrder)
    return this.http.get<any>(`${this.base}/tickets`, { params, headers: this.auth.getAuthHeaders() })
  }

  getTicketDetail(id: number) {
    return this.http.get<any>(`${this.base}/tickets/${id}`, { headers: this.auth.getAuthHeaders() })
  }

  updateStatus(id: number, status: string) {
    return this.http.post<any>(`${this.base}/tickets/status`, { id, status }, { headers: this.auth.getAuthHeaders() })
  }

  assign(ticketId: number, agentId: number, agentName: string) {
    return this.http.post<any>(`${this.base}/tickets/assign`, { ticketId, agentId, agentName }, { headers: this.auth.getAuthHeaders() })
  }

  getDashboardStats(days = 7) {
    const params = new HttpParams().set('days', days)
    return this.http.get<any>(`${this.base}/tickets/dashboard/stats`, { params, headers: this.auth.getAuthHeaders() })
  }

  getStatusCounts() {
    return this.http.get<any>(`${this.base}/tickets/status-counts`, { headers: this.auth.getAuthHeaders() })
  }

  getContacts(offset = 0, limit = 50, search = '', highPriorityOnly = false) {
    let params = new HttpParams().set('offset', offset).set('limit', limit).set('search', search)
    if (highPriorityOnly) params = params.set('highPriorityOnly', 'true')
    return this.http.get<any>(`${this.base}/contacts`, { params, headers: this.auth.getAuthHeaders() })
  }

  setContactPriority(id: number, isHighPriority: boolean) {
    return this.http.post<any>(`${this.base}/contacts/priority`, { id, isHighPriority }, { headers: this.auth.getAuthHeaders() })
  }

  // ── Organizations tab ─────────────────────────────────────────────────
  // Distinct from Contacts: pulled straight from the shared legacy
  // Organization table (every org that's ever signed up), not derived from
  // support tickets.
  getOrganizations(offset = 0, limit = 50, search = '', highPriorityOnly = false, withTicketsOnly = false) {
    let params = new HttpParams().set('offset', offset).set('limit', limit).set('search', search)
    if (highPriorityOnly) params = params.set('highPriorityOnly', 'true')
    if (withTicketsOnly) params = params.set('withTicketsOnly', 'true')
    return this.http.get<any>(`${this.base}/organizations`, { params, headers: this.auth.getAuthHeaders() })
  }

  // ── Ticket-list "Organization" filter dropdown ──────────────────────
  // Distinct from getOrganizations above (which pulls from the shared
  // legacy Organization table for the dedicated Organizations tab) — this
  // reads straight off tickets.sender_org_name, so it only ever offers
  // orgs that actually have a ticket on file (open, closed, or deleted),
  // with no join/sync gap between the two tables.
  getTicketOrganizations(search = '') {
    let params = new HttpParams()
    if (search) params = params.set('search', search)
    return this.http.get<any>(`${this.base}/tickets/organizations`, { params, headers: this.auth.getAuthHeaders() })
  }

  setOrganizationPriority(orgId: number, orgName: string | null, isHighPriority: boolean) {
    return this.http.post<any>(`${this.base}/organizations/priority`, { orgId, orgName, isHighPriority }, { headers: this.auth.getAuthHeaders() })
  }

  // ── Attachments tab ───────────────────────────────────────────────────
  // Browses every ticket_attachments row (i.e. every file saved to S3)
  // across all tickets, independent of any single ticket's thread.
  getAllAttachments(offset = 0, limit = 40, search = '', type: '' | 'image' | 'video' | 'document' | 'other' = '') {
    let params = new HttpParams().set('offset', offset).set('limit', limit)
    if (search) params = params.set('search', search)
    if (type) params = params.set('type', type)
    return this.http.get<any>(`${this.base}/admin/attachments`, { params, headers: this.auth.getAuthHeaders() })
  }

  deleteAttachments(ids: number[]) {
    return this.http.post<any>(`${this.base}/admin/attachments/delete`, { ids }, { headers: this.auth.getAuthHeaders() })
  }

  // ── Bucket audit ─────────────────────────────────────────────────────
  // Independent, ground-truth view of the S3 bucket itself (every object
  // under the attachments prefix, walked directly via ListObjectsV2) —
  // separate from getAllAttachments() above, which only ever reflects
  // ticket_attachments rows. Surfaces orphaned files + true bucket size.
  getBucketAudit(offset = 0, limit = 50, search = '', filter: '' | 'tracked' | 'untracked' = '', refresh = false) {
    let params = new HttpParams().set('offset', offset).set('limit', limit)
    if (search) params = params.set('search', search)
    if (filter) params = params.set('filter', filter)
    if (refresh) params = params.set('refresh', 'true')
    return this.http.get<any>(`${this.base}/admin/attachments/bucket-audit`, { params, headers: this.auth.getAuthHeaders() })
  }

  updateTicket(payload: { id: number; customerName?: string; customerPhone?: string; customerEmail?: string; priority?: string; status?: string; source?: string }) {
    return this.http.post<any>(`${this.base}/tickets/update`, payload, { headers: this.auth.getAuthHeaders() })
  }

  deleteTicket(id: number) {
    return this.http.post<any>(`${this.base}/tickets/delete`, { id }, { headers: this.auth.getAuthHeaders() })
  }

  restoreTicket(id: number) {
    return this.http.post<any>(`${this.base}/tickets/restore`, { id }, { headers: this.auth.getAuthHeaders() })
  }

  sendReply(payload: { ticketId: number; message: string; replyMode?: string; recipients?: { to?: string[]; cc?: string[] } }) {
    return this.http.post<any>(`${this.base}/tickets/message`, {
      ...payload, sender: 'agent', type: 'reply',
    }, { headers: this.auth.getAuthHeaders() })
  }

  /** Internal note — same /tickets/message endpoint, but type: internal_note so it never goes out to the customer. */
  addInternalNote(ticketId: number, message: string) {
    return this.http.post<any>(`${this.base}/tickets/message`, {
      ticketId, message, sender: 'agent', type: 'internal_note',
    }, { headers: this.auth.getAuthHeaders() })
  }

  // ============================================================
  // NEW: read / unread
  // ============================================================
  markRead(id: number) {
    return this.http.post<any>(`${this.base}/tickets/${id}/read`, {}, { headers: this.auth.getAuthHeaders() })
  }

  markUnread(id: number) {
    return this.http.post<any>(`${this.base}/tickets/${id}/unread`, {}, { headers: this.auth.getAuthHeaders() })
  }

  // ============================================================
  // NEW: resolution
  // ============================================================
  updateResolution(id: number, resolutionCode?: string, resolutionNotes?: string) {
    return this.http.post<any>(`${this.base}/tickets/${id}/resolution`, { resolutionCode, resolutionNotes }, { headers: this.auth.getAuthHeaders() })
  }

  // ============================================================
  // NEW: merge
  // ============================================================
  mergeTickets(sourceIds: number[], targetId: number) {
    return this.http.post<any>(`${this.base}/tickets/merge`, { sourceIds, targetId }, { headers: this.auth.getAuthHeaders() })
  }

  // ============================================================
  // NEW: bulk actions
  // ============================================================
  bulkAssign(ids: number[], agentId: number, agentName: string) {
    return this.http.post<any>(`${this.base}/tickets/bulk/assign`, { ids, agentId, agentName }, { headers: this.auth.getAuthHeaders() })
  }

  bulkUpdateStatus(ids: number[], status: string) {
    return this.http.post<any>(`${this.base}/tickets/bulk/status`, { ids, status }, { headers: this.auth.getAuthHeaders() })
  }

  bulkDelete(ids: number[]) {
    return this.http.post<any>(`${this.base}/tickets/bulk/delete`, { ids }, { headers: this.auth.getAuthHeaders() })
  }

  bulkMarkSpam(ids: number[], spam = true) {
    return this.http.post<any>(`${this.base}/tickets/bulk/spam`, { ids, spam }, { headers: this.auth.getAuthHeaders() })
  }

  bulkApplyMacro(ids: number[], macroId: number) {
    return this.http.post<any>(`${this.base}/tickets/bulk/apply-macro`, { ids, macroId }, { headers: this.auth.getAuthHeaders() })
  }

  // ============================================================
  // NEW: macros
  // ============================================================
  getMacros() {
    return this.http.get<any>(`${this.base}/macros`, { headers: this.auth.getAuthHeaders() })
  }

  createMacro(payload: any) {
    return this.http.post<any>(`${this.base}/macros/create`, payload, { headers: this.auth.getAuthHeaders() })
  }

  updateMacro(id: number, payload: any) {
    return this.http.post<any>(`${this.base}/macros/${id}/update`, payload, { headers: this.auth.getAuthHeaders() })
  }

  deleteMacro(id: number) {
    return this.http.post<any>(`${this.base}/macros/${id}/delete`, {}, { headers: this.auth.getAuthHeaders() })
  }

  // ============================================================
  // NEW: agents (for the assign picker)
  // ============================================================
  getAgents() {
    return this.http.get<any>(`${this.base}/agents`, { headers: this.auth.getAuthHeaders() })
  }

  retryMessage(messageId: number) {
  return this.http.post(`${environment.apiUrl}/tickets/messages/${messageId}/retry`, {})
}

  // ============================================================
  // NEW: outbound attachments
  // ============================================================
  /**
   * Uploads a single file the agent is about to attach to a reply. Fires as
   * soon as they pick the file (see ticket-detail.ts's onAttachmentPicked)
   * so the composer can show upload progress/errors immediately — the
   * response {fileName, contentType, size, storagePath} is held client-side
   * and only sent along with the actual message payload once they hit Send.
   * No Content-Type header set here on purpose: the browser needs to add
   * its own multipart boundary, which an explicit header would stomp on.
   */
  uploadAttachment(file: File) {
    const form = new FormData()
    form.append('file', file, file.name)
    return this.http.post<{ status: boolean; fileName: string; contentType: string; size: number; storagePath: string; msg?: string }>(
      `${this.base}/tickets/attachments/upload`, form, { headers: this.auth.getAuthHeaders() }
    )
  }

getPendingTickets(offset = 0, limit = 7, days = 7) {
    const params = new HttpParams().set('offset', offset).set('limit', limit).set('days', days)
    return this.http.get<{ rows: any[]; total: number }>(`${this.base}/tickets/dashboard/pending`, { params, headers: this.auth.getAuthHeaders() })
  }

  getChartsOverview(days = 7) {
    const params = new HttpParams().set('days', days)
    return this.http.get<any>(`${this.base}/tickets/dashboard/charts`, { params, headers: this.auth.getAuthHeaders() })
  }

  syncMail(ticketId: number) {
    return this.http.post<{ status: boolean; synced: number; totalInConversation?: number; alreadyExisting?: number; error?: string }>(
      `${this.base}/tickets/${ticketId}/sync-mail`, {}, { headers: this.auth.getAuthHeaders() }
    )
  }
}