import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { Router } from '@angular/router'
import { environment } from '../../environments/environment'

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly TOKEN_KEY    = 'agent_token'
  private readonly NAME_KEY     = 'agent_name'
  private readonly ROLE_KEY     = 'agent_role'
  private readonly SAVED_AT_KEY = 'agent_saved_at'
  private readonly ID_KEY       = 'agent_id'         
  private _pendingForceLogin = false
setForceLogin(v: boolean)   { this._pendingForceLogin = v }
consumeForceLogin(): boolean { const v = this._pendingForceLogin; this._pendingForceLogin = false; return v }

  constructor(private http: HttpClient, private router: Router) {}

login(username: string, password: string, force = false) {
     return this.http.post<any>(`${environment.apiUrl}/agent/login`, { username, password, force })
   }

  isLoggedIn(): boolean {
    const token = localStorage.getItem(this.TOKEN_KEY)
    if (!token) return false
    const savedAt = Number(localStorage.getItem(this.SAVED_AT_KEY) ?? '0')
    if (Date.now() - savedAt > 2 * 24 * 60 * 60 * 1000) {
      this.logout()
      return false
    }
    return true
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY)
  }

  getAgentName(): string {
    return localStorage.getItem(this.NAME_KEY) ?? ''
  }

  getRole(): string {
    return localStorage.getItem(this.ROLE_KEY) ?? 'user'
  }

  isAdmin(): boolean {
    return this.getRole() === 'admin'
  }

  getAuthHeaders() {
    return { Authorization: `Bearer ${this.getToken()}` }
  }

  getAgentId(): number {
    return Number(localStorage.getItem(this.ID_KEY) ?? 0)   // ← now reads a key that's actually written
  }

  // ← ADD agentId parameter
  saveSession(token: string, name: string, role: string = 'user', agentId: number = 0) {
    localStorage.setItem(this.TOKEN_KEY,    token)
    localStorage.setItem(this.NAME_KEY,     name)
    localStorage.setItem(this.ROLE_KEY,     role)
    localStorage.setItem(this.SAVED_AT_KEY, Date.now().toString())
    localStorage.setItem(this.ID_KEY,       String(agentId))   
  }

  logoutWithReason(reason: string) {
  sessionStorage.setItem('logout_reason', reason)   
  this.logout()
}

  clearSession() {
    this.logout()
  }

  logout() {
    localStorage.removeItem(this.TOKEN_KEY)
    localStorage.removeItem(this.NAME_KEY)
    localStorage.removeItem(this.ROLE_KEY)
    localStorage.removeItem(this.SAVED_AT_KEY)
    localStorage.removeItem(this.ID_KEY)   
    this.router.navigate(['/login'])
  }

  /** User-initiated logout (e.g. sidebar button) — notifies the backend
   *  (clears auth_token/socket presence server-side) then clears the local
   *  session either way, so a network hiccup never traps the user logged in. */
  logoutFromServer() {
    this.http.post(`${environment.apiUrl}/agent/logout`, {}, { headers: this.getAuthHeaders() }).subscribe({
      next: () => this.logout(),
      error: () => this.logout(),
    })
  }
}