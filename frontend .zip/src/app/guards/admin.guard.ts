import { inject } from '@angular/core'
import { CanActivateFn, Router } from '@angular/router'
import { AuthService } from '../service/auth.service'

export const adminGuard: CanActivateFn = () => {
  const auth   = inject(AuthService)
  const router = inject(Router)
  if (auth.isLoggedIn() && auth.getRole() === 'admin') return true
  router.navigate(['/dashboard'])
  return false
}
