self.addEventListener('push', event => {
  const data = event.data?.json() ?? {}
  self.registration.showNotification(data.title ?? 'New Chat Request', {
    body:  data.body  ?? 'A visitor is waiting for an agent.',
    icon:  '/favicon.ico',
    badge: '/favicon.ico',
    tag:   'chat-request',          // collapses duplicates
    renotify: true,
    data: { url: data.url ?? '/' }
  })
})

self.addEventListener('notificationclick', event => {
  event.notification.close()
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      const existing = list.find(c => c.url.includes(event.notification.data.url) && 'focus' in c)
      if (existing) return existing.focus()
      return clients.openWindow(event.notification.data.url)
    })
  )
})