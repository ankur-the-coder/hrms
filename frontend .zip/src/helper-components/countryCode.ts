export const countryCodes = 
[
    {Id:"1",flag:"at",code:"43",name:"Austria (+43)", phoneNumberLength: 10},
    {Id:"2",flag:"af",code:"93",name:"Afghanistan (+93)", phoneNumberLength: 9},
    {Id:"3",flag:"ag",code:"1",name:"Antigua and Barbuda (+1)", phoneNumberLength: 10},
    {Id:"4",flag:"al",code:"355",name:"Albania (+355)", phoneNumberLength: 9},
    {Id:"5",flag:"as",code:"1",name:"American Samoa (+1)", phoneNumberLength: 10},
    {Id:"6",flag:"ad",code:"376",name:"Andorra (+376)", phoneNumberLength: 6},
    {Id:"7",flag:"ao",code:"244",name:"Angola (+244)", phoneNumberLength: 9},
    {Id:"8",flag:"am",code:"374",name:"Armenia (+374)", phoneNumberLength: 8},
    {Id:"9",flag:"aw",code:"297",name:"Aruba (+297)", phoneNumberLength: 7},
    {Id:"10",flag:"au",code:"61",name:"Australia (+61)", phoneNumberLength: 9},
    {Id:"11",flag:"ai",code:"264",name:"Anguilla (+264)", phoneNumberLength: 7},
    {Id:"12",flag:"az",code:"994",name:"Azerbaijan (+994)", phoneNumberLength: 9},
    {Id:"13",flag:"be",code:"32",name:"Belgium (+32)", phoneNumberLength: 9},
    {Id:"14",flag:"bd",code:"880",name:"Bangladesh (+880)", phoneNumberLength: 10},
    {Id:"15",flag:"bb",code:"246",name:"Barbados (+246)", phoneNumberLength: 7},
    {Id:"16",flag:"bj",code:"229",name:"Benin (+229)", phoneNumberLength: 8},
    {Id:"17",flag:"bm",code:"441",name:"Bermuda (+441)", phoneNumberLength: 7},
    {Id:"18",flag:"bf",code:"226",name:"Burkina Faso (+226)", phoneNumberLength: 8},
    {Id:"19",flag:"bg",code:"359",name:"Bulgaria (+359)", phoneNumberLength: 9},
    {Id:"20",flag:"bt",code:"975",name:"Bhutan (+975)", phoneNumberLength: 8},
    {Id:"21",flag:"bi",code:"257",name:"Burundi (+257)", phoneNumberLength: 8},
    {Id:"22",flag:"ba",code:"387",name:"Bosnia and Herzegovina (+387)", phoneNumberLength: 8},
    {Id:"23",flag:"bo",code:"591",name:"Bolivia (+591)", phoneNumberLength: 8},
    {Id:"24",flag:"br",code:"55",name:"Brazil (+55)", phoneNumberLength: 10},
    {Id:"25",flag:"bh",code:"973",name:"Bahrain (+973)", phoneNumberLength: 8},
    {Id:"26",flag:"bn",code:"673",name:"Brunei (+673)", phoneNumberLength: 7},
    {Id:"27",flag:"bs",code:"242",name:"Bahamas (+242)", phoneNumberLength: 7},
    {Id:"28",flag:"vg",code:"284",name:"British Virgin Islands (+284)", phoneNumberLength: 7},
    {Id:"29",flag:"by",code:"375",name:"Belarus (+375)", phoneNumberLength: 9},
    {Id:"30",flag:"bz",code:"501",name:"Belize (+501)", phoneNumberLength: 7},
    {Id:"31",flag:"cu",code:"53",name:"Cuba (+53)", phoneNumberLength: 8},
    {Id:"32",flag:"cm",code:"237",name:"Cameroon (+237)", phoneNumberLength: 8},
    {Id:"33",flag:"ky",code:"345",name:"Cayman Islands (+345)", phoneNumberLength: 7},
    {Id:"34",flag:"ca",code:"1",name:"Canada (+1)", phoneNumberLength: 10},
    {Id:"35",flag:"ch",code:"41",name:"Switzerland (+41)", phoneNumberLength: 9},
    {Id:"36",flag:"ci",code:"225",name:"Cote dIvoire (+225)", phoneNumberLength: 8},
    {Id:"37",flag:"lk",code:"94",name:"Sri Lanka (+94)", phoneNumberLength: 10},
    {Id:"38",flag:"co",code:"57",name:"Colombia (+57)", phoneNumberLength: 10},
    {Id:"39",flag:"cc",code:"891",name:"Cocos Islands (+891)", phoneNumberLength: 9},
    {Id:"40",flag:"km",code:"269",name:"Comoros (+269)", phoneNumberLength: 7},
    {Id:"41",flag:"ck",code:"682",name:"Cook Islands (+682)", phoneNumberLength: 5},
    {Id:"42",flag:"cr",code:"506",name:"Costa Rica (+506)", phoneNumberLength: 8},
    {Id:"43",flag:"cv",code:"238",name:"Cape Verde (+238)", phoneNumberLength: 7},
    {Id:"44",flag:"cy",code:"357",name:"Cyprus (+357)", phoneNumberLength: 8},
    {Id:"45",flag:"cz",code:"420",name:"Czech Republic (+420)", phoneNumberLength: 9},
    {Id:"46",flag:"de",code:"49",name:"Germany (+49)", phoneNumberLength: 10},
    {Id:"47",flag:"dj",code:"253",name:"Djibouti (+253)", phoneNumberLength: 8},
    {Id:"48",flag:"dk",code:"45",name:"Denmark (+45)", phoneNumberLength: 8},
    {Id:"49",flag:"do",code:"1",name:"Dominican Republic (+1)", phoneNumberLength: 10},
    {Id:"50",flag:"dz",code:"213",name:"Algeria (+213)", phoneNumberLength: 9},
    {Id:"51",flag:"es",code:"34",name:"Spain (+34)", phoneNumberLength: 9},
    {Id:"52",flag:"ke",code:"254",name:"Kenya (+254)", phoneNumberLength: 9},
    {Id:"53",flag:"tz",code:"255",name:"Tanzania (+255)", phoneNumberLength: 9},
    {Id:"54",flag:"ug",code:"256",name:"Uganda (+256)", phoneNumberLength: 9},
    {Id:"55",flag:"ec",code:"593",name:"Ecuador (+593)", phoneNumberLength: 9},
    {Id:"56",flag:"er",code:"291",name:"Eritrea (+291)", phoneNumberLength: 7},
    {Id:"57",flag:"sv",code:"503",name:"El Salvador (+503)", phoneNumberLength: 8},
    {Id:"58",flag:"eg",code:"20",name:"Egypt (+20)", phoneNumberLength: 10},
    {Id:"59",flag:"et",code:"251",name:"Ethiopia (+251)", phoneNumberLength: 9},
    {Id:"60",flag:"ee",code:"372",name:"Estonia (+372)", phoneNumberLength: 7},
    {Id:"61",flag:"fr",code:"33",name:"France (+33)", phoneNumberLength: 9},
    {Id:"62",flag:"fk",code:"500",name:"Falkland Islands (+500)", phoneNumberLength: 5},
    {Id:"63",flag:"fo",code:"298",name:"Faroe Islands (+298)", phoneNumberLength: 6},
    {Id:"64",flag:"gf",code:"594",name:"French Guiana (+594)", phoneNumberLength: 9},
    {Id:"65",flag:"fj",code:"679",name:"Fiji (+679)", phoneNumberLength: 7},
    {Id:"66",flag:"li",code:"423",name:"Liechtenstein (+423)", phoneNumberLength: 7},
    {Id:"67",flag:"pf",code:"689",name:"French Polynesia (+689)", phoneNumberLength: 6},
    {Id:"68",flag:"fm",code:"691",name:"Micronesia (+691)", phoneNumberLength: 7},
    {Id:"69",flag:"ga",code:"241",name:"Gabon (+241)", phoneNumberLength: 7},
    {Id:"70",flag:"gs",code:"970",name:"Gaza Strip (+970)", phoneNumberLength: 8},
    {Id:"71",flag:"gb",code:"44",name:"United Kingdom (+44)", phoneNumberLength: 10},
    {Id:"72",flag:"gg",code:"44",name:"Guernsey (+44)", phoneNumberLength: 10},
    {Id:"73",flag:"je",code:"44",name:"Jersey (+44)", phoneNumberLength: 10},
    {Id:"74",flag:"im",code:"44",name:"Isle of Man (+44)", phoneNumberLength: 10},
    {Id:"75",flag:"gi",code:"350",name:"Gibraltar (+350)", phoneNumberLength: 8},
    {Id:"76",flag:"gt",code:"502",name:"Guatemala (+502)", phoneNumberLength: 8},
    {Id:"77",flag:"ge",code:"995",name:"Georgia (+995)", phoneNumberLength: 9},
    {Id:"78",flag:"gh",code:"233",name:"Ghana (+233)", phoneNumberLength: 9},
    {Id:"79",flag:"gw",code:"245",name:"Guinea-Bissau (+245)", phoneNumberLength: 7},
    {Id:"80",flag:"gq",code:"240",name:"Equatorial Guinea (+240)", phoneNumberLength: 9},
    {Id:"81",flag:"gr",code:"30",name:"Greece (+30)", phoneNumberLength: 10},
    {Id:"82",flag:"gl",code:"299",name:"Greenland (+299)", phoneNumberLength: 6},
    {Id:"83",flag:"gp",code:"590",name:"Guadeloupe (+590)", phoneNumberLength: 9},
    {Id:"84",flag:"gu",code:"1",name:"Guam (+1)", phoneNumberLength: 10},
    {Id:"85",flag:"gy",code:"592",name:"Guyana (+592)", phoneNumberLength: 7},
    {Id:"86",flag:"hu",code:"36",name:"Hungary (+36)", phoneNumberLength: 9},
    {Id:"87",flag:"hn",code:"504",name:"Honduras (+504)", phoneNumberLength: 8},
    {Id:"88",flag:"sh",code:"290",name:"Saint Helena (+290)", phoneNumberLength: 4},
    {Id:"89",flag:"hk",code:"852",name:"Hong Kong (+852)", phoneNumberLength: 8},
    {Id:"90",flag:"hr",code:"385",name:"Croatia (+385)", phoneNumberLength: 9},
    {Id:"91",flag:"it",code:"39",name:"Italy (+39)", phoneNumberLength: 10},
    {Id:"92",flag:"il",code:"972",name:"Israel (+972)", phoneNumberLength: 9},
    {Id:"93",flag:"in",code:"91",name:"India (+91)", phoneNumberLength: 10},
    {Id:"94",flag:"ir",code:"98",name:"Iran (+98)", phoneNumberLength: 10},
    {Id:"95",flag:"ie",code:"353",name:"Ireland (+353)", phoneNumberLength: 9},
    {Id:"96",flag:"iq",code:"964",name:"Iraq (+964)", phoneNumberLength: 10},
    {Id:"97",flag:"is",code:"354",name:"Iceland (+354)", phoneNumberLength: 7},
    {Id:"98",flag:"jp",code:"81",name:"Japan (+81)", phoneNumberLength: 10},
    {Id:"99",flag:"jm",code:"876",name:"Jamaica (+876)", phoneNumberLength: 7},
    {Id:"100",flag:"jo",code:"962",name:"Jordan (+962)", phoneNumberLength: 9},
    {Id:"101",flag:"kh",code:"855",name:"Cambodia (+855)", phoneNumberLength: 9},
    {Id:"102",flag:"kz",code:"7",name:"Kazakhstan (+7)", phoneNumberLength: 10},
    {Id:"103",flag:"kg",code:"996",name:"Kyrgyzstan (+996)", phoneNumberLength: 9},
    {Id:"104",flag:"ki",code:"686",name:"Kiribati (+686)", phoneNumberLength: 5},
    {Id:"105",flag:"kn",code:"869",name:"Saint Kitts and Nevis (+869)", phoneNumberLength: 7},
    {Id:"106",flag:"kv",code:"383",name:"Kosovo (+383)", phoneNumberLength: 8},
    {Id:"107",flag:"kw",code:"965",name:"Kuwait (+965)", phoneNumberLength: 8},
    {Id:"108",flag:"lu",code:"352",name:"Luxembourg (+352)", phoneNumberLength: 9},
    {Id:"109",flag:"la",code:"856",name:"Laos (+856)", phoneNumberLength: 8},
    {Id:"110",flag:"ly",code:"218",name:"Libya (+218)", phoneNumberLength: 9},
    {Id:"111",flag:"lr",code:"231",name:"Liberia (+231)", phoneNumberLength: 7},
    {Id:"112",flag:"ls",code:"266",name:"Lesotho (+266)", phoneNumberLength: 8},
    {Id:"113",flag:"lt",code:"370",name:"Lithuania (+370)", phoneNumberLength: 8},
    {Id:"114",flag:"lv",code:"371",name:"Latvia (+371)", phoneNumberLength: 8},
    {Id:"115",flag:"mt",code:"356",name:"Malta (+356)", phoneNumberLength: 8},
    {Id:"116",flag:"ma",code:"212",name:"Morocco (+212)", phoneNumberLength: 9},
    {Id:"117",flag:"mo",code:"853",name:"Macau (+853)", phoneNumberLength: 8},
    {Id:"118",flag:"my",code:"60",name:"Malaysia (+60)", phoneNumberLength: 9},
    {Id:"119",flag:"mq",code:"596",name:"Martinique (+596)", phoneNumberLength: 9},
    {Id:"120",flag:"yt",code:"262",name:"Mayotte (+262)", phoneNumberLength: 9},
    {Id:"121",flag:"mc",code:"377",name:"Monaco (+377)", phoneNumberLength: 8},
    {Id:"122",flag:"md",code:"373",name:"Moldova (+373)", phoneNumberLength: 8},
    {Id:"123",flag:"mx",code:"52",name:"Mexico (+52)", phoneNumberLength: 10},
    {Id:"124",flag:"mh",code:"692",name:"Marshall Islands (+692)", phoneNumberLength: 7},
    {Id:"125",flag:"mk",code:"389",name:"Macedonia (+389)", phoneNumberLength: 8},
    {Id:"126",flag:"me",code:"382",name:"Montenegro (+382)", phoneNumberLength: 8},
    {Id:"127",flag:"mn",code:"976",name:"Mongolia (+976)", phoneNumberLength: 8},
    {Id:"128",flag:"ms",code:"664",name:"Montserrat (+664)", phoneNumberLength: 7},
    {Id:"129",flag:"mz",code:"258",name:"Mozambique (+258)", phoneNumberLength: 9},
    {Id:"130",flag:"mu",code:"230",name:"Mauritius (+230)", phoneNumberLength: 7},
    {Id:"131",flag:"mv",code:"960",name:"Maldives (+960)", phoneNumberLength: 7},
    {Id:"132",flag:"mw",code:"265",name:"Malawi (+265)", phoneNumberLength: 7},
    {Id:"133",flag:"mm",code:"95",name:"Myanmar (+95)", phoneNumberLength: 8},
    {Id:"134",flag:"no",code:"47",name:"Norway (+47)", phoneNumberLength: 8},
    {Id:"135",flag:"nl",code:"599",name:"Netherlands Antilles (+599)", phoneNumberLength: 7},
    {Id:"136",flag:"na",code:"264",name:"Namibia (+264)", phoneNumberLength: 9},
    {Id:"137",flag:"nr",code:"674",name:"Nauru (+674)", phoneNumberLength: 7},
    {Id:"138",flag:"nc",code:"687",name:"New Caledonia (+687)", phoneNumberLength: 6},
    {Id:"139",flag:"np",code:"977",name:"Nepal (+977)", phoneNumberLength: 10},
    {Id:"140",flag:"ni",code:"505",name:"Nicaragua (+505)", phoneNumberLength: 8},
    {Id:"141",flag:"nu",code:"683",name:"Niue (+683)", phoneNumberLength: 4},
    {Id:"142",flag:"nl",code:"31",name:"Netherlands (+31)", phoneNumberLength: 9},
    {Id:"143",flag:"mp",code:"1",name:"Northern Mariana Islands (+1)", phoneNumberLength: 10},
    {Id:"144",flag:"kp",code:"850",name:"North Korea (+850)", phoneNumberLength: 8},
    {Id:"145",flag:"nf",code:"672",name:"Norfolk Island (+672)", phoneNumberLength: 5},
    {Id:"146",flag:"nz",code:"64",name:"New Zealand (+64)", phoneNumberLength: 9},
    {Id:"147",flag:"om",code:"968",name:"Oman (+968)", phoneNumberLength: 8},
    {Id:"148",flag:"pt",code:"351",name:"Portugal (+351)", phoneNumberLength: 9},
    {Id:"149",flag:"pa",code:"507",name:"Panama (+507)", phoneNumberLength: 8},
    {Id:"150",flag:"pw",code:"680",name:"Palau (+680)", phoneNumberLength: 7},
    {Id:"151",flag:"pe",code:"51",name:"Peru (+51)", phoneNumberLength: 9},
    {Id:"152",flag:"pn",code:"64",name:"Pitcairn Islands (+64)", phoneNumberLength: 5},
    {Id:"153",flag:"pk",code:"92",name:"Pakistan (+92)", phoneNumberLength: 10},
    {Id:"154",flag:"pl",code:"48",name:"Poland (+48)", phoneNumberLength: 9},
    {Id:"155",flag:"pg",code:"675",name:"Papua New Guinea (+675)", phoneNumberLength: 7},
    {Id:"156",flag:"pr",code:"1",name:"Puerto Rico (+1)", phoneNumberLength: 10},
    {Id:"157",flag:"py",code:"595",name:"Paraguay (+595)", phoneNumberLength: 9},
    {Id:"158",flag:"qa",code:"974",name:"Qatar (+974)", phoneNumberLength: 8},
    {Id:"159",flag:"ru",code:"7",name:"Russia (+7)", phoneNumberLength: 10},
    {Id:"160",flag:"ar",code:"54",name:"Argentina (+54)", phoneNumberLength: 10},
    {Id:"161",flag:"bw",code:"267",name:"Botswana (+267)", phoneNumberLength: 7},
    {Id:"162",flag:"tw",code:"886",name:"Taiwan (+886)", phoneNumberLength: 9},
    {Id:"163",flag:"cf",code:"236",name:"Central African Republic (+236)", phoneNumberLength: 8},
    {Id:"164",flag:"cd",code:"243",name:"Republic of the Congo (+243)", phoneNumberLength: 9},
    {Id:"165",flag:"cl",code:"56",name:"Chile (+56)", phoneNumberLength: 9},
    {Id:"166",flag:"re",code:"262",name:"Reunion (+262)", phoneNumberLength: 9},
    {Id:"167",flag:"gn",code:"224",name:"Guinea (+224)", phoneNumberLength: 8},
    {Id:"168",flag:"ht",code:"509",name:"Haiti (+509)", phoneNumberLength: 8},
    {Id:"169",flag:"Id",code:"62",name:"Indonesia (+62)", phoneNumberLength: 10},
    {Id:"170",flag:"mr",code:"222",name:"Mauritania (+222)", phoneNumberLength: 8},
    {Id:"171",flag:"lb",code:"961",name:"Lebanon (+961)", phoneNumberLength: 8},
    {Id:"172",flag:"mg",code:"261",name:"Madagascar (+261)", phoneNumberLength: 9},
    {Id:"173",flag:"ml",code:"223",name:"Mali (+223)", phoneNumberLength: 8},
    {Id:"174",flag:"ne",code:"227",name:"Niger (+227)", phoneNumberLength: 8},
    {Id:"175",flag:"ro",code:"40",name:"Romania (+40)", phoneNumberLength: 9},
    {Id:"176",flag:"kr",code:"82",name:"South Korea (+82)", phoneNumberLength: 10},
    {Id:"177",flag:"uy",code:"598",name:"Uruguay (+598)", phoneNumberLength: 8},
    {Id:"178",flag:"ph",code:"63",name:"Philippines (+63)", phoneNumberLength: 10},
    {Id:"179",flag:"za",code:"27",name:"South Africa (+27)", phoneNumberLength: 9},
    {Id:"180",flag:"sm",code:"378",name:"San Marino (+378)", phoneNumberLength: 10},
    {Id:"181",flag:"tg",code:"228",name:"Togo (+228)", phoneNumberLength: 8},
    {Id:"182",flag:"rw",code:"250",name:"Rwanda (+250)", phoneNumberLength: 9},
    {Id:"183",flag:"se",code:"46",name:"Sweden (+46)", phoneNumberLength: 9},
    {Id:"184",flag:"sa",code:"966",name:"Saudi Arabia (+966)", phoneNumberLength: 9},
    {Id:"185",flag:"sz",code:"268",name:"Swaziland (+268)", phoneNumberLength: 8},
    {Id:"186",flag:"fi",code:"358",name:"Finland (+358)", phoneNumberLength: 10},
    {Id:"187",flag:"sg",code:"65",name:"Singapore (+65)", phoneNumberLength: 8},
    {Id:"188",flag:"sk",code:"421",name:"Slovakia (+421)", phoneNumberLength: 9},
    {Id:"189",flag:"sb",code:"677",name:"Solomon Islands (+677)", phoneNumberLength: 7},
    {Id:"190",flag:"si",code:"386",name:"Slovenia (+386)", phoneNumberLength: 8},
    {Id:"191",flag:"mf",code:"1",name:"Saint Martin (+1)", phoneNumberLength: 10},
    {Id:"192",flag:"sr",code:"597",name:"Suriname (+597)", phoneNumberLength: 7},
    {Id:"193",flag:"sn",code:"221",name:"Senegal (+221)", phoneNumberLength: 9},
    {Id:"194",flag:"so",code:"252",name:"Somalia (+252)", phoneNumberLength: 8},
    {Id:"195",flag:"pm",code:"508",name:"Saint Pierre and Miquelon (+508)", phoneNumberLength: 6},
    {Id:"196",flag:"rs",code:"381",name:"Serbia (+381)", phoneNumberLength: 9},
    {Id:"197",flag:"st",code:"239",name:"Sao Tome and Principe (+239)", phoneNumberLength: 7},
    {Id:"198",flag:"sd",code:"249",name:"Sudan (+249)", phoneNumberLength: 9},
    {Id:"199",flag:"sv",code:"47",name:"Svalbard (+47)", phoneNumberLength: 8},
    {Id:"200",flag:"sc",code:"248",name:"Seychelles (+248)", phoneNumberLength: 7},
    {Id:"201",flag:"sy",code:"963",name:"Syria (+963)", phoneNumberLength: 9},
    {Id:"202",flag:"tj",code:"992",name:"Tajikistan (+992)", phoneNumberLength: 9},
    {Id:"203",flag:"td",code:"235",name:"Chad (+235)", phoneNumberLength: 8},
    {Id:"204",flag:"th",code:"66",name:"Thailand (+66)", phoneNumberLength: 9},
    {Id:"205",flag:"cn",code:"86",name:"China (+86)", phoneNumberLength: 11},
    {Id:"206",flag:"tl",code:"670",name:"Timor-Leste (+670)", phoneNumberLength: 7},
    {Id:"207",flag:"tm",code:"993",name:"Turkmenistan (+993)", phoneNumberLength: 8},
    {Id:"208",flag:"tn",code:"216",name:"Tunisia (+216)", phoneNumberLength: 8},
    {Id:"209",flag:"to",code:"676",name:"Tonga (+676)", phoneNumberLength: 5},
    {Id:"210",flag:"tr",code:"90",name:"Turkey (+90)", phoneNumberLength: 10},
    {Id:"211",flag:"tt",code:"868",name:"Trinidad and Tobago (+868)", phoneNumberLength: 7},
    {Id:"212",flag:"tc",code:"1",name:"Turks and Caicos Islands (+1)", phoneNumberLength: 10},
    {Id:"213",flag:"tv",code:"688",name:"Tuvalu (+688)", phoneNumberLength: 5},
    {Id:"214",flag:"ua",code:"380",name:"Ukraine (+380)", phoneNumberLength: 9},
    {Id:"215",flag:"ae",code:"971",name:"United Arab Emirates (+971)", phoneNumberLength: 9},
    {Id:"216",flag:"us",code:"1",name:"United States of America (+1)", phoneNumberLength: 10},
    {Id:"217",flag:"uz",code:"998",name:"Uzbekistan (+998)", phoneNumberLength: 9},
    {Id:"218",flag:"hs",code:"379",name:"Holy See (+379)", phoneNumberLength: 10},
    {Id:"219",flag:"vi",code:"1",name:"U.S. Virgin Islands (+1)", phoneNumberLength: 10},
    {Id:"220",flag:"vn",code:"84",name:"Vietnam (+84)", phoneNumberLength: 9},
    {Id:"221",flag:"vu",code:"678",name:"Vanuatu (+678)", phoneNumberLength: 7},
    {Id:"222",flag:"wf",code:"681",name:"Wallis and Futuna (+681)", phoneNumberLength: 6},
    {Id:"223",flag:"gm",code:"220",name:"Gambia (+220)", phoneNumberLength: 7},
    {Id:"224",flag:"sl",code:"232",name:"Sierra Leone (+232)", phoneNumberLength: 8},
    {Id:"225",flag:"ng",code:"234",name:"Nigeria (+234)", phoneNumberLength: 10},
    {Id:"226",flag:"dm",code:"767",name:"Dominica (+767)", phoneNumberLength: 7},
    {Id:"227",flag:"wb",code:"970",name:"West Bank (+970)", phoneNumberLength: 8},
    {Id:"228",flag:"gd",code:"473",name:"Grenada (+473)", phoneNumberLength: 7},
    {Id:"229",flag:"lc",code:"758",name:"Saint Lucia (+758)", phoneNumberLength: 7},
    {Id:"230",flag:"ws",code:"685",name:"Samoa (+685)", phoneNumberLength: 7},
    {Id:"231",flag:"eh",code:"212",name:"Western Sahara (+212)", phoneNumberLength: 9},
    {Id:"232",flag:"vc",code:"784",name:"Saint Vincent and the Grenadines (+784)", phoneNumberLength: 7},
    {Id:"233",flag:"cx",code:"61",name:"Christmas Island (+61)", phoneNumberLength: 9},
    {Id:"234",flag:"ye",code:"967",name:"Yemen (+967)", phoneNumberLength: 9},
    {Id:"235",flag:"ve",code:"58",name:"Venezuela (+58)", phoneNumberLength: 10},
    {Id:"236",flag:"zm",code:"260",name:"Zambia (+260)", phoneNumberLength: 9},
    {Id:"237",flag:"zr",code:"243",name:"Zaire (+243)", phoneNumberLength: 9},
    {Id:"238",flag:"zw",code:"263",name:"Zimbabwe (+263)", phoneNumberLength: 9},
    // {Id:"239",flag:null,code:"1809",name:"Dominican Republic (+1809)", phoneNumberLength: 10},
    // {Id:"240",flag:null,code:"1829",name:"Dominican Republic (+1829)", phoneNumberLength: 10},
    // {Id:"241",flag:null,code:"1849",name:"Dominican Republic (+1849)", phoneNumberLength: 10},
    {Id:"242",flag:"us",code:"1",name:"USA (+1)", phoneNumberLength: 10},
    {Id:"243",flag:"la",code:"856",name:"Lao People's Democratic Republic (+856)", phoneNumberLength: 8},
    {Id:"244",flag:"mk",code:"389",name:"North Macedonia (+389)", phoneNumberLength: 8},
    {Id:"245",flag:"ps",code:"970",name:"State of Palestine (+970)", phoneNumberLength: 8},
    {Id:"246",flag:"sy",code:"963",name:"Syrian Arab Republic (+963)", phoneNumberLength: 9},
    {Id:"247",flag:"tz",code:"255",name:"United Republic of Tanzania (+255)", phoneNumberLength: 9},
    {Id:"248",flag:"aq",code:"672",name:"Antarctica (+672)", phoneNumberLength: 6},
    {Id:"249",flag:"bq",code:"599",name:"Bonaire, Sint Eustatius and Saba (+599)", phoneNumberLength: 7},
    {Id:"250",flag:"bv",code:"47",name:"Bouvet Island (+47)", phoneNumberLength: 8},
    {Id:"251",flag:"io",code:"246",name:"British Indian Ocean Territory (+246)", phoneNumberLength: 7},
    {Id:"252",flag:"vg",code:"1",name:"British Virgin Islands (+1)", phoneNumberLength: 10},
    {Id:"253",flag:"cc",code:"61",name:"Cocos (Keeling) Islands (+61)", phoneNumberLength: 9},
    {Id:"254",flag:"cw",code:"599",name:"Curaçao (+599)", phoneNumberLength: 7},
    {Id:"255",flag:"fk",code:"500",name:"Falkland Islands (Malvinas) (+500)", phoneNumberLength: 5},
    {Id:"256",flag:"tf",code:"262",name:"French Southern Territories (+262)", phoneNumberLength: 9},
    {Id:"257",flag:"hm",code:"672",name:"Heard Island and McDonald Islands (+672)", phoneNumberLength: 6},
    {Id:"258",flag:"ci",code:"225",name:"Côte d'Ivoire (+225)", phoneNumberLength: 8},
    {Id:"259",flag:"yt",code:"262",name:"Mayotte (+262)", phoneNumberLength: 9},
    {Id:"260",flag:"re",code:"262",name:"Réunion (+262)", phoneNumberLength: 9},
    {Id:"261",flag:"bl",code:"590",name:"Saint Barthélemy (+590)", phoneNumberLength: 9},
    {Id:"262",flag:"sx",code:"1",name:"Sint Maarten (+1)", phoneNumberLength: 10},
    {Id:"263",flag:"gs",code:"500",name:"South Georgia and the South Sandwich Islands (+500)", phoneNumberLength: 5},
    {Id:"264",flag:"sj",code:"47",name:"Svalbard and Jan Mayen (+47)", phoneNumberLength: 8},
    {Id:"265",flag:"tk",code:"690",name:"Tokelau (+690)", phoneNumberLength: 5},
    {Id:"266",flag:"um",code:"1",name:"United States Minor Outlying Islands (+1)", phoneNumberLength: 10},
    {Id:"267",flag:"vi",code:"1",name:"United States Virgin Islands (+1)", phoneNumberLength: 10}
]









/**
 * Get country ID by country name (supports partial matches)
 * @param countryName - The name of the country (can be partial like "ind" for "India")
 * @returns The country Id or null if not found
 */
export function getCountryIdByName(countryName: string): string | null {
  if (!countryName) return null;
  
  const normalizedInput = countryName.trim().toLowerCase();
  
  // First, try to find exact match or starts with match
  let country = countryCodes.find(country => {
    const nameOnly = country.name.split('(')[0].trim().toLowerCase();
    return nameOnly === normalizedInput || nameOnly.startsWith(normalizedInput);
  });
  
  // If no exact/starts-with match, try includes
  if (!country) {
    country = countryCodes.find(country => {
      const nameOnly = country.name.split('(')[0].trim().toLowerCase();
      return nameOnly.includes(normalizedInput);
    });
  }
  
  return country ? country.Id : null;
}

/**
 * Get country object by country name (supports partial matches)
 * @param countryName - The name of the country (can be partial like "ind" for "India")
 * @returns The complete country object or null if not found
 */
export function getCountryByName(countryName: string) {
  if (!countryName) return null;
  
  const normalizedInput = countryName.trim().toLowerCase();
  
  // First, try to find exact match or starts with match
  let country = countryCodes.find(country => {
    const nameOnly = country.name.split('(')[0].trim().toLowerCase();
    return nameOnly === normalizedInput || nameOnly.startsWith(normalizedInput);
  });
  
  // If no exact/starts-with match, try includes
  if (!country) {
    country = countryCodes.find(country => {
      const nameOnly = country.name.split('(')[0].trim().toLowerCase();
      return nameOnly.includes(normalizedInput);
    });
  }
  
  return country || null;
}