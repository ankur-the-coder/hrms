import { NgClass } from '@angular/common';
import { Component, ElementRef, EventEmitter, forwardRef, HostListener, Input, OnDestroy, Optional, Output, SimpleChanges, ViewChild } from '@angular/core';
import { AbstractControl, ControlValueAccessor, FormControl, ControlContainer, NG_VALIDATORS, NG_VALUE_ACCESSOR, ValidationErrors, Validator, Validators, ValidatorFn, FormsModule } from '@angular/forms';


import { debounceTime } from 'rxjs/operators';
import { countryCodes } from '../countryCode';
import { ValidationHelperComponent as V, ValidationHelperComponent  } from '../validaton-helper/validaton-helper.component';
import { dateService } from '../date.service';



export interface ValidationConfig {
  type: 'name' | 'phone' | 'email' | 'postalCode' | 'aadhar' | 'number' | 'text'
  | 'naturalNumber' | 'wholeNumber' | 'integer' | 'rational' | 'gpa' | 'tenure' | 'document';
  min?: number;
  max?: number;
  countryIdGetter?: () => string; // For postal code
  wordRange?: { min: number; max: number };
  required?: boolean;
  capitalize?:boolean;
}
@Component({
  selector: 'app-text-input',
  imports: [NgClass,FormsModule,],
  templateUrl: './text-input.component.html',
  styleUrls: ['./text-input.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TextInputComponent),
      multi: true,
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => TextInputComponent),
      multi: true,
    },
  ]
})
export class TextInputComponent implements ControlValueAccessor, Validator {
  @Input() label: string = '';
  @Input() placeholder: string = '';
  @Input() addClass: string = '';
  @Input() readOnly: boolean = false;
  @Input() type: 'basic' | 'date-viewer' = 'basic';
  @Input() disabled = false;
  @Input() infoMsg: boolean = false;
  @Input() required: boolean = false;
  @Input() copy: boolean = true;
  @Input() paste: boolean = true;
  @Input() maxLength: number | null = 200;
  @Input() addValidation = true
  @Input() formControl?: FormControl;//CHANGE
  @Input() formControlName!: string; //CHANGE
  formatDate = dateService.formatDate;
  @Input() value: string = '';
  touched = false;
  @Input() enableTouchValidations: boolean = false;
  @Input() truncate: boolean = false;
  hasMaxLengthError = false;
  @Input() trimOnBlur: boolean = false;
  @Input() showErrorBorder: boolean = true;
  @Input() allowNoWhiteSpace: boolean = false;
  @Input() validationConfig?: ValidationConfig;
  private appliedValidators: ValidatorFn[] = [];
  @ViewChild('monthsInput') monthsInput!: ElementRef<HTMLInputElement>;
@ViewChild('daysInput') daysInput!: ElementRef<HTMLInputElement>;
@ViewChild('phoneDropdownRef') phoneDropdownRef!: ElementRef;
openUpwards = false;


// Phone-mode state
phoneCountryId: string = '';
phoneCountryCode: string = '';
phoneCountryPhoneLength: number = 10;
phoneCountryOptions: { label: string; value: string; code: string; flag: string }[] = [];
showCountryDropdown: boolean = false;
countrySearchQuery: string = '';
filteredCountryOptions: { label: string; value: string; code: string; flag: string }[] = [];
// ADD after: showValidationErrors = false;
private pendingPhoneValue: { countryId?: string; phoneNumber?: string } | null = null;
private isEmittingPhone = false;

tenureMonths: string = '';
tenureDays: string = '';
private validationDebounceTimeout: any;
showValidationErrors = false;

  id: string = '';
  constructor(@Optional() private controlContainer: ControlContainer,) {
    this.id = 'text_input' + this.generateRandomString(5)
  }

  @HostListener('document:click', ['$event'])
onDocumentClick(event: MouseEvent) {
  if (this.showCountryDropdown && this.phoneDropdownRef && 
      !this.phoneDropdownRef.nativeElement.contains(event.target)) {
    this.showCountryDropdown = false;
  }
}

  // Dynamically get the FormControl
  get control(): FormControl | null {   //change  
    return (
      this.formControl ||
      (this.formControlName
        ? (this.controlContainer?.control?.get(
          this.formControlName
        ) as FormControl)
        : null)
    );
  }

ngOnInit() {
  if (this.validationConfig && this.control) {
    this.applyValidationConfig();
  }

  // Phone mode init
  if (this.validationConfig?.type === 'phone') {
    this.phoneCountryOptions = (countryCodes as any[]).map(c => ({
      label: c.name,
      value: c.Id,
      code: c.code,
      flag: c.flag,
    }));
    this.filteredCountryOptions = [...this.phoneCountryOptions];

        if (this.pendingPhoneValue) {
      if (this.pendingPhoneValue.countryId) {
        this.setCountryById(this.pendingPhoneValue.countryId);
      }
      this.value = this.pendingPhoneValue.phoneNumber || '';
      this.pendingPhoneValue = null;
    } else {
      this.initGeoLocation();
    }


  }
}

ngOnChanges(changes: SimpleChanges) {
  if (changes['validationConfig'] && !changes['validationConfig'].firstChange) {
    this.applyValidationConfig();
  }
  // If parent patches countryId externally
  if (changes['countryId'] && changes['countryId'].currentValue) {
    this.setCountryById(changes['countryId'].currentValue);
  }
}

  // ngOnInit() {
  //   if (this.enableTouchValidations && this.control) {
  //     this.control.markAsTouched();
  //   }
  // }


 onChange = (value: any) => { };
  onTouched = () => { };

  // Called by Angular to write a value to the component
writeValue(value: any) {
  // ✅ FIXED: only enter phone block when type is explicitly 'phone'
  if (this.validationConfig?.type === 'phone') {
    if (value && typeof value === 'object') {
      const phoneObj = value as { countryId?: string; phoneNumber?: string };
      if (this.phoneCountryOptions.length === 0) {
        this.pendingPhoneValue = phoneObj;
        this.value = phoneObj.phoneNumber || '';
        return;
      }
      if (phoneObj.countryId) {
        this.value = phoneObj.phoneNumber || '';
        this.setCountryById(phoneObj.countryId);
        setTimeout(() => {
          if (this.control) {
            this.control.updateValueAndValidity({ emitEvent: false });
          }
        }, 0);
      }
    } else {
      this.value = '';
    }
    return;
  }

  // ✅ When no validationConfig, behave exactly like old component
  if (!this.validationConfig) {
    this.value = value ?? '';
    return;
  }

  if (value !== undefined && value !== null && typeof value === 'string') {
    let cleanedValue = value;

    if (this.validationConfig.type === 'tenure') {
      this.parseTenureFromDays(value);
      this.value = value;
      return;
    }

    if (this.validationConfig.type === 'email' ||
        this.validationConfig.type === 'postalCode' ||
        this.validationConfig.type === 'gpa') {
      cleanedValue = value.replace(/\s/g, '');
    } else if (this.allowNoWhiteSpace) {
      cleanedValue = value.replace(/\s/g, '');
    } else {
      cleanedValue = value.trimStart();
    }

    this.value = cleanedValue;
  } else {
    this.value = value || '';
  }
}

  // Called by Angular to register a change function
  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  // Called by Angular to register a touch function
  registerOnTouched(fn: any) {
    this.onTouched = fn;
  }

  // Mark the component as touched
  markAsTouched() {
    if (!this.touched) {
      this.onTouched();
      this.touched = true;
    }
  }

  // Enable or disable the component
  setDisabledState(isDisabled: boolean) {
    this.disabled = isDisabled;
  }


onInput(event: Event) {
  const input = event.target as HTMLInputElement;
  let inputValue = input.value;

  // ✅ No validationConfig = behave exactly like old component
  if (!this.validationConfig) {
    this.value = inputValue;
    this.onChange(this.value);
    if (this.control) {
      this.control.markAsTouched();
      this.control.setValue(this.value);
    }
    this.markAsTouched?.();
    return;
  }
  const cursorPosition = input.selectionStart || 0;

  // Get effective maxLength from validationConfig or @Input
  const effectiveMaxLength = this.validationConfig?.max ?? this.maxLength;

  // Prevent typing beyond maxLength
  if (effectiveMaxLength && inputValue.length > effectiveMaxLength) {
    inputValue = inputValue.substring(0, effectiveMaxLength);
  }
  

  // Phone: only allow digits, enforce country length
  if (this.validationConfig?.type === 'phone') {
    inputValue = inputValue.replace(/\D/g, '');
    if (this.phoneCountryPhoneLength && inputValue.length > this.phoneCountryPhoneLength) {
      inputValue = inputValue.substring(0, this.phoneCountryPhoneLength);
    }
    this.value = inputValue;
    input.value = inputValue;
    this.emitPhoneValue();
    // debounce touch
    if (this.validationDebounceTimeout) clearTimeout(this.validationDebounceTimeout);
    this.validationDebounceTimeout = setTimeout(() => {
      if (this.control && !this.control.touched) {
        this.control.markAsTouched();
        this.showValidationErrors = true;
      }
    }, 1000);
    return; // exit early, skip rest of onInput
  }

// For email, postalCode, and gpa types, remove all spaces
if (this.validationConfig?.type === 'email' || 
    this.validationConfig?.type === 'postalCode' || 
    this.validationConfig?.type === 'gpa' ||
    this.validationConfig?.type === 'tenure' ||
    this.validationConfig?.type === 'document') {
  inputValue = inputValue.replace(/\s/g, '');
}

if (this.validationConfig?.type === 'tenure') {
  inputValue = inputValue.replace(/\D/g, ''); // Remove all non-digits
}

// For gpa type, only allow numbers and single dot
if (this.validationConfig?.type === 'gpa') {
  // Remove all characters except digits and dots
  inputValue = inputValue.replace(/[^\d.]/g, '');
  
  // Allow only one dot
  const parts = inputValue.split('.');
  if (parts.length > 2) {
    inputValue = parts[0] + '.' + parts.slice(1).join('');
  }
}
  // If allowNoWhiteSpace is true, remove all spaces
// If allowNoWhiteSpace is true, remove all spaces
  else if (this.allowNoWhiteSpace) {
    inputValue = inputValue.replace(/\s/g, '');
 } else {
    const cursorAtStart = (event.target as HTMLInputElement).selectionStart ?? 0;
    // Only trim leading space if cursor is at the very beginning
    if (inputValue.startsWith(' ') && cursorAtStart <= 1) {
      inputValue = inputValue.trimStart();
    }
    
    // Replace multiple consecutive spaces
    inputValue = inputValue.replace(/\s{2,}/g, ' ');
  }
if (this.validationConfig?.type === 'document') {
  inputValue = inputValue.toUpperCase();
}
// Auto-capitalize for name type: capitalize first letter after start or space
  if (this.validationConfig?.type === 'name') {
    inputValue = inputValue.replace(/(^|\s)(\S)/g, (match, space, char) => {
      return space + char.toUpperCase();
    });
  }

  // Only reassign input.value if it actually changed — prevents cursor jump
  if (input.value !== inputValue) {
    const cursorPos = input.selectionStart ?? inputValue.length;
    input.value = inputValue;
    // Restore cursor after forced value update
    const newCursor = Math.min(cursorPos, inputValue.length);
    input.setSelectionRange(newCursor, newCursor);
  }

  this.value = inputValue;
  this.onChange(this.value);


  // if (this.control) {
  //   // Don't mark as touched on input - only on blur
  //   this.control.setValue(this.value, { emitEvent: true });
  // }
if (this.validationDebounceTimeout) {
  clearTimeout(this.validationDebounceTimeout);
}

// Set new timeout to mark as touched after 2 seconds
this.validationDebounceTimeout = setTimeout(() => {
  if (this.control && !this.control.touched) {
    this.control.markAsTouched();
    this.showValidationErrors = true;
  }
  
  // Show max length error immediately if max is reached
  const effectiveMaxLength = this.validationConfig?.max ?? this.maxLength;
  if (effectiveMaxLength && this.value.length >= effectiveMaxLength) {
    this.control?.markAsTouched();
    this.showValidationErrors = true;
  }
}, 1000);

}



  // onBlur() {  //CHANGE
  //   this.onTouched();
  //   if (this.control) {
  //     this.control.markAsTouched();
  //   }
  // }

onBlur(event?: Event) {
  this.onTouched();
  if (!this.control) return;

  // ✅ No validationConfig = behave exactly like old component
  if (!this.validationConfig) {
    if (this.trimOnBlur && typeof this.control.value === 'string') {
      const trimmed = this.control.value.trim();
      if (trimmed !== this.control.value) {
        this.control.setValue(trimmed);
        this.value = trimmed;
      }
    }
    this.control.markAsTouched();
    return;
  }

  if (!this.control) return;

  let processedValue = this.control.value;

// For phone type, just mark touched and return — value is managed separately
  if (this.validationConfig?.type === 'phone') {
    this.control.markAsTouched();
    this.showValidationErrors = true;
    return;
  }

  if (typeof processedValue !== 'string' && this.validationConfig?.type) {
    this.control.markAsTouched();
    return;
  }

  // Handle allowNoWhiteSpace
  if (this.allowNoWhiteSpace) {
    processedValue = processedValue.replace(/\s/g, '');
  } 
else if (this.validationConfig?.type === 'email' || 
         this.validationConfig?.type === 'postalCode' || 
         this.validationConfig?.type === 'gpa'  ||
         this.validationConfig?.type === 'tenure' ||
         this.validationConfig?.type === 'document') {
  processedValue = processedValue.replace(/\s/g, '');
} else if (this.validationConfig?.type === 'name'){
 processedValue = processedValue.replace(/\s+/g, ' ');
}
  // For other types, trim and normalize spaces
  else {
    // Always trim on blur (removes leading/trailing spaces)
    processedValue = processedValue.trim();
    
    // Normalize multiple spaces to single space
    // processedValue = processedValue.replace(/\s+/g, ' ');
  }

  // Auto-capitalize for name type fields BEFORE setting value
  if (this.validationConfig?.type === 'name' && processedValue) {
    processedValue = processedValue.trim()
  }

  // Only update if value actually changed
  if (processedValue !== this.control.value) {
    // Update internal value first
    this.value = processedValue;
    
    // Update form control (this will trigger writeValue through the form)
    this.control.setValue(processedValue);
  }

  // Mark as touched
  this.control.markAsTouched();
}




private applyValidationConfig() {
  if (!this.validationConfig || !this.control) return;

  this.appliedValidators = this.buildValidators(this.validationConfig);
  this.control.setValidators(this.appliedValidators);

  // ✅ Pass { emitEvent: true } and ensure parent is notified
  this.control.updateValueAndValidity({ emitEvent: true, onlySelf: false });
}


private buildValidators(config: ValidationConfig): ValidatorFn[] {
  const validators: ValidatorFn[] = [];

  // Required validator
  if (config.required) {
    validators.push(Validators.required);
  }

  switch (config.type) {
    case 'name':
      validators.push(
        V.nameWithHyphen(),
        V.noMultipleWhiteSpaces(),
      );
      // Use new validators that exclude titles from character count
      validators.push(V.trimmedMinLengthExcludingTitles(config.min ?? 2));
      validators.push(V.trimmedMaxLength(config.max ?? 50));
      break;

case 'phone':
  validators.push(this.phoneValidatorForCountry());
  break;

    case 'email':
      validators.push(V.email());
      // Default: max=50
      validators.push(Validators.maxLength(config.max ?? 50));
      break;

    case 'postalCode':
      const countryGetter = config.countryIdGetter;
      if (countryGetter) {
        validators.push(V.postalCode(countryGetter));
      }
      if (config.max) {
        validators.push(Validators.maxLength(config.max));
      }
      break;

    case 'aadhar':
      validators.push(V.aadhar());
      break;

    case 'number':
      validators.push(V.onlyNumbers());
      if (config.min !== undefined) validators.push(Validators.min(config.min));
      if (config.max !== undefined) validators.push(Validators.max(config.max));
      break;

    case 'text':
      // Default: min=5, max=200
      validators.push(V.trimmedMinLength(config.min ?? 5));
      validators.push(V.trimmedMaxLength(config.max ?? 200));

      if (config.wordRange) {
        validators.push(V.wordRange(config.wordRange.min, config.wordRange.max));
      }
      break;

    case 'naturalNumber':
      validators.push(V.naturalNumber());
      validators.push(Validators.minLength(config.min ?? 0));
      validators.push(Validators.maxLength(config.max ?? 5));
      break;

    case 'wholeNumber':
      validators.push(V.wholeNumber());
      validators.push(Validators.minLength(config.min ?? 0));
      validators.push(Validators.maxLength(config.max ?? 5));
      break;

    case 'integer':
      validators.push(V.integer());
      validators.push(Validators.minLength(config.min ?? 0));
      validators.push(Validators.maxLength(config.max ?? 5));
      break;

    case 'rational':
      validators.push(V.rational(2)); // 2 decimal places
      validators.push(Validators.minLength(config.min ?? 3));
      validators.push(Validators.maxLength(config.max ?? 5));
      break;

    case 'gpa':
  validators.push(V.gpaOrPercentage());
  break;
  case 'tenure':
  validators.push(V.tenure(config.min ?? 1, config.max ?? 730));
  break;
  
  case 'document':
  // You might want to add specific validators for document type
  // For now, just add maxLength if specified
  if (config.max) {
    validators.push(Validators.maxLength(config.max));
  }
  }
  return validators;
}

validate(control: AbstractControl): ValidationErrors | null {
  if (this.validationConfig?.type !== 'phone' || !control.value) return null;

  const phoneNumber = (control.value.phoneNumber || '').replace(/\D/g, '');
  const selectedCountry = countryCodes.find(c => c.Id.toString() === this.phoneCountryCode?.toString());
  const countryCode = selectedCountry?.code;
  const isIndia = countryCode === '+91';

  if (!phoneNumber) return { required: true };

  const len = phoneNumber.length;

  // Dynamic length-aware blocked pattern checks
  const isRepeating = /^(\d)\1+$/.test(phoneNumber);
  const ascSeq = '01234567890123456789'.substring(0, len);
  const descSeq = '98765432109876543210'.substring(0, len);
  const isSequential = phoneNumber === ascSeq || phoneNumber === descSeq;
  const isNearlyRepeating = /^(\d)\1{6,}\d$/.test(phoneNumber) && !isRepeating;

  if (isIndia) {
    if (phoneNumber.length !== 10) {
      return { invalidPhone: { message: 'Mobile number must be exactly 10 digits' } };
    }
    if (!/^[6-9]/.test(phoneNumber)) {
      return { invalidPhone: { message: 'Mobile number should start with digits 6-9' } };
    }
    if (isRepeating || isSequential || isNearlyRepeating) {
      return { invalidPhone: { message: 'Invalid phone number' } };
    }
    const dummyPrefixes = ['555', '123', '000', '111'];
    if (dummyPrefixes.some(prefix => phoneNumber.startsWith(prefix))) {
      return { invalidPhone: { message: 'Invalid phone number' } };
    }
  } else {
    const expectedLength = (selectedCountry as any)?.length;

    if (expectedLength && phoneNumber.length !== expectedLength) {
      return { invalidPhone: { message: `Phone number must be ${expectedLength} digits` } };
    }
    if (!expectedLength && (phoneNumber.length < 5 || phoneNumber.length > 15)) {
      return { invalidPhone: { message: 'Phone number must be between 5 and 15 digits' } };
    }
    if (isRepeating || isSequential || isNearlyRepeating) {
      return { invalidPhone: { message: 'Invalid phone number' } };
    }
  }

  return null;
}

  // NEW: Get dynamic error messages
  getErrorMessages(): string[] {
  if (!this.control || !this.control.errors || !this.validationConfig) {
    return [];
  }

  const errors = this.control.errors;
  const messages: string[] = [];
  const config = this.validationConfig;

  // Generate dynamic messages based on config
  if (errors['required']) {
    messages.push(this.getRequiredMessage());
  }
  
  // Only show minlength error after blur (when user has left the field)
if (errors['minlength']) {
  messages.push(this.getMinLengthMessage(config.min!));
}

if (errors['minLengthExcludingTitles']) {
  const requiredLength = errors['minLengthExcludingTitles'].requiredLength;
  messages.push(`${this.label || 'This field'} must be at least ${requiredLength} characters`);
}
  
  if (errors['maxlength']) {
    messages.push(this.getMaxLengthMessage(config.max!));
  }
  
  // ... rest of your error messages remain the same
  if (errors['onlyAlphabets']) {
    messages.push(`${this.label} must contain only letters`);
  }
  if (errors['disallowTitles']) {
    messages.push('Titles (Mr, Mrs, Dr) are not allowed');
  }
  if (errors['email']) {
    messages.push('Please enter a valid email address');
  }
  if (errors['postalCode']) {
    messages.push(this.getPostalCodeErrorMessage());
  }
  if (errors['invalidCharacters']) {
    messages.push(`${this.label} can only contain letters, spaces, dots, and hyphens`);
  }
  if (errors['consecutiveSpecialChars']) {
    messages.push(`${this.label} cannot contain consecutive special characters`);
  }
  if (errors['invalidStartOrEnd']) {
    messages.push(`${this.label} cannot start or end with special characters`);
  }
  if (errors['naturalNumber']) {
    messages.push(`${this.label} must be a positive whole number (1, 2, 3, ...)`);
  }
  if (errors['wholeNumber']) {
    messages.push(`${this.label} must be a non-negative whole number (0, 1, 2, ...)`);
  }
  if (errors['integer']) {
    messages.push(`${this.label} must be a whole number (positive or negative)`);
  }
  if (errors['rational']) {
    messages.push(`${this.label} must be a number with up to 2 decimal places`);
  }
  if (errors['invalidFormat']) {
  messages.push(`${this.label} must be a valid number with up to 2 decimal places`);
}
if (errors['negative']) {
  messages.push(`${this.label} cannot be negative`);
}
if (errors['tooHigh']) {
  messages.push(`${this.label} cannot exceed 100`);
}
if (errors['invalidRange']) {
  messages.push(`${this.label} must be between 0 and 100`);
}
if (errors['tenureFormat']) {
  messages.push(`${this.label} must be a valid number of days`);
}
if (errors['tenureMin']) {
  const minDays = errors['tenureMin'].min;
  const minMonths = Math.floor(minDays / 30);
  const minRemainingDays = minDays % 30;
  let message = `${this.label} must be at least `;
  if (minMonths > 0) {
    message += `${minMonths} month${minMonths !== 1 ? 's' : ''}`;
  }
  if (minRemainingDays > 0) {
    message += minMonths > 0 ? ` and ${minRemainingDays} day${minRemainingDays !== 1 ? 's' : ''}` : `${minRemainingDays} day${minRemainingDays !== 1 ? 's' : ''}`;
  }
  messages.push(message);
}
if (errors['tenureMax']) {
  const maxDays = errors['tenureMax'].max;
  const maxMonths = Math.floor(maxDays / 30);
  const maxRemainingDays = maxDays % 30;
  let message = `${this.label} cannot exceed `;
  if (maxMonths > 0) {
    message += `${maxMonths} month${maxMonths !== 1 ? 's' : ''}`;
  }
  if (maxRemainingDays > 0) {
    message += maxMonths > 0 ? ` and ${maxRemainingDays} day${maxRemainingDays !== 1 ? 's' : ''}` : `${maxRemainingDays} day${maxRemainingDays !== 1 ? 's' : ''}`;
  }
  messages.push(message);
}

if (errors['invalidPhone']) {
  messages.push(errors['invalidPhone'].message || `${this.label} is invalid`);
}

  return messages.slice(0, 1);
}

  private getRequiredMessage(): string {
    const fieldName = this.label || 'This field';
    return `${fieldName} is required`;
  }

  // UPDATE these methods to handle undefined:

  private getMinLengthMessage(min: number): string {
    const fieldName = this.label || 'This field';
    const minValue = min ?? this.getDefaultMin(); // Use default if undefined
    return `${fieldName} must be at least ${minValue} characters`;
  }

  private getMaxLengthMessage(max: number): string {
    const fieldName = this.label || 'This field';
    const maxValue = max ?? this.getDefaultMax(); // Use default if undefined
    return `${fieldName} must be under ${maxValue} characters`;
  }

  // ADD helper methods to get defaults based on validation type:
  private getDefaultMin(): number {
    switch (this.validationConfig?.type) {
      case 'text': return 5;
      case 'name': return 2;
      case 'phone': return 5;
      case 'naturalNumber':
      case 'wholeNumber':
      case 'integer': return 0;
      case 'rational': return 3;
      default: return 0;
    }
  }

  private getDefaultMax(): number {
    switch (this.validationConfig?.type) {
      case 'text': return 200;
      case 'name': return 50;
      case 'phone': return 15;
      case 'email': return 50;
      case 'naturalNumber':
      case 'wholeNumber':
      case 'integer':
      case 'rational': return 5;
      default: return 200;
    }
  }

  private capitalizeWords(text: string): string {
  return text
    .split(' ')
    .map(word => {
      if (!word) return word;
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    })
    .join(' ');
}

// Remove the disallowTitles validator and add this new one:
static trimmedMinLengthExcludingTitles(minLength: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null; // Let 'required' validator handle empty values
    }
    
    let value = control.value.toString().trim();
    
    // Remove common titles from the beginning
    const titleRegex = /^(mr\.?|mrs\.?|ms\.?|dr\.?|er\.?)\s+/i;
    const valueWithoutTitle = value.replace(titleRegex, '').trim();
    
    // Check if there's anything left after removing title
    if (!valueWithoutTitle) {
      return { 
        minLengthExcludingTitles: { 
          requiredLength: minLength, 
          actualLength: 0 
        } 
      };
    }
    
    // Check length of value without title
    if (valueWithoutTitle.length < minLength) {
      return { 
        minLengthExcludingTitles: { 
          requiredLength: minLength, 
          actualLength: valueWithoutTitle.length 
        } 
      };
    }
    
    return null;
  };
}

private getPostalCodeErrorMessage(): string {
  // Get country ID from the validationConfig's countryIdGetter
  const countryId = this.validationConfig?.countryIdGetter?.();
  
  if (countryId) {
    // Find the country by ID
    const country = countryCodes.find((c: { Id: string; }) => c.Id === countryId);
    
    if (country) {
      // Extract just the country name without the phone code
      // "Austria (+43)" -> "Austria"
      const countryName = country.name.split('(')[0].trim();
      return `Please enter a valid postal code for ${countryName}`;
    }
  }
  
  // Fallback message if country not found or not selected
  return 'Please enter a valid postal code for selected country';
}

onTenureMonthsInput(event: Event) {
  const input = event.target as HTMLInputElement;
  let inputValue = input.value;

  // Only allow digits
  inputValue = inputValue.replace(/\D/g, '');

  // Limit to 2 digits
  if (inputValue.length > 2) {
    inputValue = inputValue.substring(0, 2);
  }

  // Validate max 24 months (or adjust as needed)
  if (inputValue.length > 0) {
    const months = parseInt(inputValue, 10);
    if (months > 24) {
      inputValue = '24';
    }
  }

  this.tenureMonths = inputValue;
  input.value = inputValue;

  // Auto-focus to days input when 2 digits entered
  if (inputValue.length === 2 && this.daysInput) {
    setTimeout(() => {
      this.daysInput.nativeElement.focus();
    }, 0);
  }

  this.updateTenureValue();
}

onTenureDaysInput(event: Event) {
  const input = event.target as HTMLInputElement;
  let inputValue = input.value;

  // Only allow digits
  inputValue = inputValue.replace(/\D/g, '');

  // Limit to 2 digits
  if (inputValue.length > 2) {
    inputValue = inputValue.substring(0, 2);
  }

  // Validate max 30 days
  if (inputValue.length > 0) {
    const days = parseInt(inputValue, 10);
    if (days > 30) {
      inputValue = '30';
    }
  }

  this.tenureDays = inputValue;
  input.value = inputValue;

  this.updateTenureValue();
}

onTenureBlur() {
  this.onTouched();
  
  // Ensure values are updated
  this.updateTenureValue();
  
  if (this.control) {
    this.control.markAsTouched();
    // Force validation check
    this.control.updateValueAndValidity();
  }
}

private updateTenureValue() {
  const months = parseInt(this.tenureMonths || '0', 10);
  const days = parseInt(this.tenureDays || '0', 10);
  
  // Format as "XMY D" (e.g., "20M10D")
  let newValue = '';
  if (months > 0) {
    newValue += `${months}M`;
  }
  if (days > 0) {
    newValue += `${days}D`;
  }
  
  // If both are empty, set to empty string
  if (!newValue) {
    newValue = '';
  }
  
  // Only update if value changed
  if (this.value !== newValue) {
    this.value = newValue;
    this.onChange(this.value);
    
    if (this.control) {
      this.control.setValue(this.value, { emitEvent: false });
      this.control.updateValueAndValidity({ emitEvent: false });
    }
  }
}

private parseTenureFromDays(value: string) {
  if (!value) {
    this.tenureMonths = '';
    this.tenureDays = '';
    return;
  }
  
  // Parse format like "20M10D"
  const monthsMatch = value.match(/(\d+)M/);
  const daysMatch = value.match(/(\d+)D/);
  
  this.tenureMonths = monthsMatch ? monthsMatch[1] : '';
  this.tenureDays = daysMatch ? daysMatch[1] : '';
}

// ---- PHONE MODE METHODS ----

private initGeoLocation() {
  const cached = localStorage.getItem('geojs_country');
  if (cached) {
    const { countryId } = JSON.parse(cached);
    this.setCountryById(countryId);
    return;
  }

  fetch('https://get.geojs.io/v1/ip/geo.json')
    .then(r => r.json())
    .then(data => {
      if (data?.country_code) {
        const alpha2 = data.country_code.toUpperCase();
        // countryCodes uses flag field as alpha2 lowercase
        const found = (countryCodes as any[]).find(c => c.flag.toUpperCase() === alpha2);
        if (found) {
          localStorage.setItem('geojs_country', JSON.stringify({ countryId: found.Id }));
          this.setCountryById(found.Id);
        }
      }
    })
    .catch(() => {
      // fallback: set India as default
      const india = (countryCodes as any[]).find(c => c.flag === 'in');
      if (india) this.setCountryById(india.Id);
    });
}

setCountryById(id: string) {
  const country = (countryCodes as any[]).find(c => c.Id === id);
  if (!country) return;
  this.phoneCountryId = country.Id;
  this.phoneCountryCode = country.code;
  this.phoneCountryPhoneLength = country.phoneNumberLength ?? 10;

  if (this.control && this.validationConfig?.type === 'phone') {
    this.applyValidationConfig();
   this.control.updateValueAndValidity({ onlySelf: false, emitEvent: true });
  }

  if (this.phoneCountryOptions.length > 0) {
    this.emitPhoneValue();
  }
}

onCountrySelect(option: { value: string; code: string; flag: string; label: string }) {
  this.setCountryById(option.value);
  this.showCountryDropdown = false;
  this.countrySearchQuery = '';
  this.filteredCountryOptions = [...this.phoneCountryOptions];
}

onCountrySearch(event: Event) {
  const q = (event.target as HTMLInputElement).value.toLowerCase();
  this.countrySearchQuery = q;
  this.filteredCountryOptions = q
    ? this.phoneCountryOptions.filter(o => o.label.toLowerCase().includes(q) || o.code.includes(q))
    : [...this.phoneCountryOptions];
}

toggleCountryDropdown() {
  this.showCountryDropdown = !this.showCountryDropdown;

  if (this.showCountryDropdown) {
    // Wait a tick for the UI to be ready or just calculate based on the trigger
    const rect = this.phoneDropdownRef.nativeElement.getBoundingClientRect();
    const spaceBelow = window.innerHeight - rect.bottom;
    const dropdownHeight = 300; // This should be roughly your max-h-56 (224px) + search bar

    // If space below is less than dropdown height, open upwards
    this.openUpwards = spaceBelow < dropdownHeight;
  }
}

closeDropdown() {
  this.showCountryDropdown = false;
}

private emitPhoneValue() {
  if (this.isEmittingPhone) return; 
  this.isEmittingPhone = true;

  const phoneValue = {
    countryId: this.phoneCountryId,
    countryCode: this.phoneCountryCode,
    phoneNumber: this.value,
  };
  this.onChange(phoneValue);
  if (this.control) {
    this.control.setValue(phoneValue, { emitEvent: false });
      this.control.updateValueAndValidity({ onlySelf: false, emitEvent: true });
  }

  this.isEmittingPhone = false; // ✅ THIS LINE WAS MISSING
}

getFlagUrl(flag: string): string {
  return `../assets/country-flags/${flag.toLowerCase()}.svg`;
}

getSelectedCountryFlag(): string {
  const c = (countryCodes as any[]).find(c => c.Id === this.phoneCountryId);
  return c ? c.flag : '';
}

getSelectedCountryCode(): string {
  return this.phoneCountryCode ? `+${this.phoneCountryCode}` : '';
}


private phoneValidatorForCountry(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const raw = control.value;
    const phoneNumber = (typeof raw === 'object' && raw !== null)
      ? (raw.phoneNumber || '').toString().trim()
      : (raw || '').toString().trim();

    if (!phoneNumber) return null;

    if (!/^\d+$/.test(phoneNumber)) {
      return { invalidPhone: { message: 'Phone number must contain only digits' } };
    }

    const expectedLength = this.phoneCountryPhoneLength;

    if (expectedLength && expectedLength > 0) {
      if (phoneNumber.length !== expectedLength) {
        return { invalidPhone: { message: `Phone number must be exactly ${expectedLength} digits` } };
      }
    } else {
      if (phoneNumber.length < 5 || phoneNumber.length > 15) {
        return { invalidPhone: { message: 'Phone number must be between 5 and 15 digits' } };
      }
    }

    // ---- DYNAMIC LENGTH-AWARE BLOCKED PATTERNS ----
    const len = phoneNumber.length;

    // Repeating digits: e.g. "000000000", "111111111" for any length
    const isRepeating = /^(\d)\1+$/.test(phoneNumber);

    // Sequential ascending: 1234567890... trimmed to actual length
    const ascSeq = '01234567890123456789'.substring(0, len);
    const descSeq = '98765432109876543210'.substring(0, len);
    const isSequential = phoneNumber === ascSeq || phoneNumber === descSeq;

    // Nearly repeating: all same digit except last (e.g. 99999998, 11111112)
    const isNearlyRepeating = /^(\d)\1{6,}\d$/.test(phoneNumber) && !isRepeating;

    if (isRepeating || isSequential || isNearlyRepeating) {
      return { invalidPhone: { message: 'Invalid phone number' } };
    }

    // ---- INDIA-SPECIFIC VALIDATIONS ----
    const countryFlag = this.getSelectedCountryFlag().toLowerCase();
    if (countryFlag === 'in') {
      if (!/^[6-9]/.test(phoneNumber)) {
        return { invalidPhone: { message: 'Indian mobile number must start with 6-9' } };
      }
      const dummyPrefixes = ['555', '123', '000', '111'];
      if (dummyPrefixes.some(p => phoneNumber.startsWith(p))) {
        return { invalidPhone: { message: 'Invalid phone number' } };
      }
    }

    return null;
  };
}


  generateRandomString = (length: number) => {
  let result = '';
  const characters =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charactersLength);
    result += characters.charAt(randomIndex);
  }

  return result;
};


getDropdownPosition() {
  if (!this.phoneDropdownRef) return {};
  const rect = this.phoneDropdownRef.nativeElement.getBoundingClientRect();
  return {
    position: 'fixed',
    top: `${rect.bottom + 4}px`,
    left: `${rect.left}px`,
    width: '288px',
    zIndex: 99999
  };
}




ngOnDestroy() {
  if (this.validationDebounceTimeout) {
    clearTimeout(this.validationDebounceTimeout);
  }
}
}


