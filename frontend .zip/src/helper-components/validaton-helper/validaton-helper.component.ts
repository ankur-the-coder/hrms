import { CommonModule } from '@angular/common';
import { Component, Input, Optional, SkipSelf } from '@angular/core';
import { AbstractControl, ControlContainer, ValidationErrors, ValidatorFn } from '@angular/forms';
import { countryCodes } from '../countryCode';


@Component({
  selector: 'app-validation-helper',
  standalone: true,
  imports: [CommonModule,],
  templateUrl: './validaton-helper.component.html',
  styleUrl: './validaton-helper.component.css'
})
export class ValidationHelperComponent {
  @Input() controlName?: string;
  @Input() customMessages: { [key: string]: string } = {};
  @Input() showSingleMessage: boolean = false;

  constructor(@Optional() @SkipSelf() private controlContainer: ControlContainer) {}

  get control(): AbstractControl | null {
    if (!this.controlName || !this.controlContainer) return null;
    return this.controlContainer.control?.get(this.controlName) || null;
  }

  get errors(): string[] {
    const ctrl = this.control;
  
    if (!ctrl || !ctrl.errors || !ctrl.touched) return [];
  
    const errorKeys = Object.keys(ctrl.errors);
    const mappedErrors = errorKeys.map(key => this.customMessages[key] || key);
  
    return this.showSingleMessage ? [mappedErrors[0]] : mappedErrors;
  }
  

  // Static validators (unchanged)
  static onlyNumbers(): ValidatorFn {
    return control => /^[0-9]*$/.test(control.value) ? null : { onlyNumbers: true };
  }

  static onlyAlphabets(): ValidatorFn {
    return control => /^[a-zA-Z\s.]*$/.test(control.value) ? null : { onlyAlphabets: true };
  }

  static noMultipleWhiteSpaces(): ValidatorFn {
    return control => /\s{3,}/.test(control.value) ? { maxWhiteSpace: true } : null;
  }

  static noSpecialCharacters(): ValidatorFn {
    return control => /^[a-zA-Z0-9\s\.\-]*$/.test(control.value) ? null : { noSpecialCharacters: true };
  }

  static disallowTitles(): ValidatorFn {
    return control => /^(mr|mrs|dr|er)\.?\s/i.test(control.value) ? { disallowTitles: true } : null;
  }

  static wordRange(min: number, max: number): ValidatorFn {
    return control => {
      const wordCount = (control.value || '').trim().split(/\s+/).length;
      return wordCount >= min && wordCount <= max ? null : { wordRange: true };
    };
  }

  static aadhar(): ValidatorFn {
    return control => /^\d{12}$/.test(control.value) ? null : { aadhar: true };
  }

  static validPhoneNumber(): ValidatorFn {
    return control =>
      /^\+?[0-9\s\-()]{7,20}$/.test(control.value) ? null : { validPhoneNumber: true };
  }

  // UPDATE the nameWithHyphen validator:
static nameWithHyphen(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null;
    }
    
    const value = control.value.toString();
    
    // Allow: letters, spaces, hyphens, and dots
    const validPattern = /^[a-zA-Z\s.\-]+$/;
    
    if (!validPattern.test(value)) {
      return { invalidCharacters: true };
    }
    
    // UPDATED: Prevent consecutive same special characters
    // Allow "Dr. John" but prevent "Dr..John" or "John--Smith" or "John  Doe"
    if (/\.{2,}/.test(value) || /\-{2,}/.test(value) || /\s{2,}/.test(value)) {
      return { consecutiveSpecialChars: true };
    }
    
    // Prevent starting with hyphen or dot
    if (/^[\-.]/.test(value)) {
      return { invalidStartOrEnd: true };
    }
    
    // Prevent ending with hyphen (allow ending with dot for titles like "Dr.")
    if (/\-$/.test(value)) {
      return { invalidStartOrEnd: true };
    }
    
    return null;
  };
}


  // Inside ValidationHelperComponent or in a shared validators file
static gpaOrPercentage(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value === null || value === '' || value === undefined) {
      return null; // Let 'required' handle emptiness if needed
    }

    // Check if it's a valid number
    if (isNaN(value) || !/^\d{1,3}(\.\d{1,2})?$/.test(value)) {
      return { invalidFormat: true };
    }

    const num = parseFloat(value);

    if (num < 0) {
      return { negative: true };
    }

    if (num > 100) {
      return { tooHigh: true };
    }

    // If between 10 and 100, treat as percentage → max 100
    if (num > 10 && num <= 100) {
      return null; // Valid percentage
    }

    // If ≤ 10, treat as GPA → must be ≤ 10
    if (num <= 10) {
      return null; // Valid GPA
    }

    // Shouldn't reach here, but just in case
    return { invalidRange: true };
  };
}

// Add these static methods to your ValidationHelperComponent class

static trimmedMinLength(minLength: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null; // Let 'required' validator handle empty values
    }
    const trimmedValue = control.value.toString().trim();
    return trimmedValue.length < minLength 
      ? { minlength: { requiredLength: minLength, actualLength: trimmedValue.length } }
      : null;
  };
}

static trimmedMaxLength(maxLength: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null;
    }
    const trimmedValue = control.value.toString().trim();
    return trimmedValue.length > maxLength 
      ? { maxlength: { requiredLength: maxLength, actualLength: trimmedValue.length } }
      : null;
  };
}


static email(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null; // Let 'required' handle empty values
    }

    const value = control.value.toString().trim();

    // Basic format check: must contain @ and domain
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      return { email: true };
    }

    // Split email into local and domain parts
    const parts = value.split('@');
    if (parts.length !== 2) {
      return { email: true };
    }

    const [localPart, domain] = parts;

    // Local part validations
    if (localPart.length === 0 || localPart.length > 64) {
      return { email: true };
    }

    // Local part cannot start or end with a dot
    if (localPart.startsWith('.') || localPart.endsWith('.')) {
      return { email: true };
    }

    // Local part cannot have consecutive dots
    if (/\.\./.test(localPart)) {
      return { email: true };
    }

    // Local part can only contain alphanumeric, dots, hyphens, underscores, plus signs
    if (!/^[a-zA-Z0-9._+\-]+$/.test(localPart)) {
      return { email: true };
    }

    // Domain validations
    if (domain.length === 0 || domain.length > 255) {
      return { email: true };
    }

    // Domain cannot start or end with a dot or hyphen
    if (domain.startsWith('.') || domain.endsWith('.') || 
        domain.startsWith('-') || domain.endsWith('-')) {
      return { email: true };
    }

    // Domain must have at least one dot
    if (!domain.includes('.')) {
      return { email: true };
    }

    // Domain parts validation
    const domainParts = domain.split('.');
    
    // Each domain part must be valid
    for (const part of domainParts) {
      if (part.length === 0 || part.length > 63) {
        return { email: true };
      }
      
      // Each part can only contain alphanumeric and hyphens
      if (!/^[a-zA-Z0-9\-]+$/.test(part)) {
        return { email: true };
      }
      
      // Parts cannot start or end with hyphen
      if (part.startsWith('-') || part.endsWith('-')) {
        return { email: true };
      }
    }

    // TLD (last part) must be at least 2 characters and only letters
    const tld = domainParts[domainParts.length - 1];
    if (tld.length < 2 || !/^[a-zA-Z]+$/.test(tld)) {
      return { email: true };
    }

    // Check for common disposable/invalid domains (optional)
    const invalidDomains = ['test.com', 'example.com', 'localhost'];
    if (invalidDomains.includes(domain.toLowerCase())) {
      return { email: true };
    }

    return null;
  };
}


static postalCode(getCountryId: () => string): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null; // Let 'required' handle empty values
    }

    const value = control.value.toString().trim();
    const countryId = getCountryId(); // Get the current country ID dynamically

    // If country not selected yet, use general validator
    if (!countryId) {
      return /^[A-Za-z0-9\s\-]{3,10}$/.test(value) ? null : { postalCode: true };
    }

    // Find country by ID
    const country = countryCodes.find(c => c.Id === countryId);
    if (!country) {
      // If country not found, use general validator
      return /^[A-Za-z0-9\s\-]{3,10}$/.test(value) ? null : { postalCode: true };
    }

    // Get country code in uppercase
    const countryCode = country.flag.toUpperCase();

    // Country-specific validators (same as before)
    const validators: { [key: string]: RegExp } = {
      'US': /^\d{5}(-\d{4})?$/,
      'GB': /^[A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2}$/i,
      'CA': /^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/i,
      'AU': /^\d{4}$/,
      'DE': /^\d{5}$/,
      'FR': /^\d{5}$/,
      'IT': /^\d{5}$/,
      'ES': /^\d{5}$/,
      'NL': /^\d{4}\s?[A-Z]{2}$/i,
      'BE': /^\d{4}$/,
      'CH': /^\d{4}$/,
      'AT': /^\d{4}$/,
      'SE': /^\d{3}\s?\d{2}$/,
      'NO': /^\d{4}$/,
      'DK': /^\d{4}$/,
      'FI': /^\d{5}$/,
      'PL': /^\d{2}-\d{3}$/,
      'CZ': /^\d{3}\s?\d{2}$/,
      'PT': /^\d{4}-\d{3}$/,
      'GR': /^\d{3}\s?\d{2}$/,
      'HU': /^\d{4}$/,
      'RO': /^\d{6}$/,
      'IE': /^[A-Z]\d{2}\s?[A-Z0-9]{4}$/i,
      'NZ': /^\d{4}$/,
      'SG': /^\d{6}$/,
      'MY': /^\d{5}$/,
      'TH': /^\d{5}$/,
      'PH': /^\d{4}$/,
      'ID': /^\d{5}$/,
      'VN': /^\d{6}$/,
      'IN': /^\d{6}$/,
      'PK': /^\d{5}$/,
      'BD': /^\d{4}$/,
      'LK': /^\d{5}$/,
      'JP': /^\d{3}-?\d{4}$/,
      'KR': /^\d{5}$/,
      'CN': /^\d{6}$/,
      'TW': /^\d{3}(-?\d{2,3})?$/,
      'BR': /^\d{5}-?\d{3}$/,
      'MX': /^\d{5}$/,
      'AR': /^[A-Z]?\d{4}$/i,
      'CL': /^\d{7}$/,
      'CO': /^\d{6}$/,
      'PE': /^\d{5}$/,
      'ZA': /^\d{4}$/,
      'EG': /^\d{5}$/,
      'NG': /^\d{6}$/,
      'KE': /^\d{5}$/,
      'IL': /^\d{7}$/,
      'SA': /^\d{5}(-\d{4})?$/,
      'AE': /^\d{5}$/,
      'TR': /^\d{5}$/,
      'RU': /^\d{6}$/,
      'UA': /^\d{5}$/,
      'BY': /^\d{6}$/,
      'KZ': /^\d{6}$/,
    };

    // Check if specific validator exists for this country
    if (validators[countryCode]) {
      return validators[countryCode].test(value) ? null : { postalCode: true };
    }

    // General validator for other countries
    return /^[A-Za-z0-9\s\-]{3,10}$/.test(value) ? null : { postalCode: true };
  };
}

// ADD these 4 new static validators:

static naturalNumber(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value && control.value !== 0) {
      return null;
    }
    
    const value = control.value.toString();
    
    // Natural numbers: 1, 2, 3, ... (positive integers, no zero)
    if (!/^[1-9]\d*$/.test(value)) {
      return { naturalNumber: true };
    }
    
    return null;
  };
}

static wholeNumber(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value && control.value !== 0) {
      return null;
    }
    
    const value = control.value.toString();
    
    // Whole numbers: 0, 1, 2, 3, ... (non-negative integers)
    if (!/^(0|[1-9]\d*)$/.test(value)) {
      return { wholeNumber: true };
    }
    
    return null;
  };
}

static integer(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value && control.value !== 0) {
      return null;
    }
    
    const value = control.value.toString();
    
    // Integers: ..., -2, -1, 0, 1, 2, ... (positive or negative whole numbers)
    if (!/^-?(0|[1-9]\d*)$/.test(value)) {
      return { integer: true };
    }
    
    return null;
  };
}

static rational(maxDecimals: number = 2): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value && control.value !== 0) {
      return null;
    }
    
    const value = control.value.toString();
    
    // Rational numbers with up to maxDecimals decimal places
    const pattern = new RegExp(`^-?(0|[1-9]\\d*)(\\.\\d{1,${maxDecimals}})?$`);
    
    if (!pattern.test(value)) {
      return { rational: true };
    }
    
    return null;
  };
}

// Remove the disallowTitles validator and add this new one:
static trimmedMinLengthExcludingTitles(minLength: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null; // Let 'required' validator handle empty values
    }
    
    let value = control.value.toString().trim();
    
    // Remove common titles from the beginning
    const titleRegex = /^(mr\.?|mrs\.?|ms\.?|dr\.?|er\.?)\s+/i;
    const valueWithoutTitle = value.replace(titleRegex, '').trim();
    
    // Check if there's anything left after removing title
    if (!valueWithoutTitle) {
      return { 
        minLengthExcludingTitles: { 
          requiredLength: minLength, 
          actualLength: 0 
        } 
      };
    }
    
    // Check length of value without title
    if (valueWithoutTitle.length < minLength) {
      return { 
        minLengthExcludingTitles: { 
          requiredLength: minLength, 
          actualLength: valueWithoutTitle.length 
        } 
      };
    }
    
    return null;
  };
}

static tenure(minDays: number = 1, maxDays: number = 730): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value) {
      return null;
    }
    
    const value = control.value.toString();
    
    // Parse format like "20M10D"
    const monthsMatch = value.match(/(\d+)M/);
    const daysMatch = value.match(/(\d+)D/);
    
    if (!monthsMatch && !daysMatch) {
      return { tenureFormat: true };
    }
    
    const months = monthsMatch ? parseInt(monthsMatch[1], 10) : 0;
    const days = daysMatch ? parseInt(daysMatch[1], 10) : 0;
    const totalDays = (months * 30) + days;
    
    if (totalDays === 0) {
      return { tenureFormat: true };
    }
    
    if (totalDays < minDays) {
      return { tenureMin: { min: minDays, actual: totalDays } };
    }
    
    if (totalDays > maxDays) {
      return { tenureMax: { max: maxDays, actual: totalDays } };
    }
    
    return null;
  };
}

}
