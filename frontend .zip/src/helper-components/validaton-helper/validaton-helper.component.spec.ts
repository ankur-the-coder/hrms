import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidatonHelperComponent } from './validaton-helper.component';

describe('ValidatonHelperComponent', () => {
  let component: ValidatonHelperComponent;
  let fixture: ComponentFixture<ValidatonHelperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ValidatonHelperComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ValidatonHelperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
