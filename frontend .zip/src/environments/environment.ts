export const environment = {
  production: false,
  apiUrl: 'http://127.0.0.1:3000',
  socketUrl: 'http://127.0.0.1:3000',
  brand: {
    namePart1: 'Ubi',
    namePart2: 'Desk',
    accentColor: '#2563eb', 
  }
}