export const environment = {
  production: true,
  apiUrl: 'https://ubidesk.ubitechsolutions.com/api',
  socketUrl: 'https://ubidesk.ubitechsolutions.com',
  brand: {
    namePart1: 'Ubi',
    namePart2: 'Desk',
    accentColor: '#2563eb',
  }
}