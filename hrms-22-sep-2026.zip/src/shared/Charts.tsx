import { useState, useRef, useEffect, useCallback, useMemo, lazy, Suspense } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown, Download, Box, Square, Eye, X, Check, Minimize2 } from 'lucide-react';
import { useFlip, Popover, ChartSkeleton } from './primitives';
import { HONEST_PALETTE } from '../theme/themes';
import { fontFaceCss } from '../theme/fonts';
import { radialOffset, distinctLineColor } from './chartGeometry';
import type { ThreeChartHandle } from './three/ThreeSankey3D';
import { RADIAL_PRESET_OPTIONS, radialLegendFor, type RadialPresetKey } from './three/radialPresets';

/** Three.js-powered chart renderers — lazily loaded so pages that never use
 * these kinds don't pay for the three.js bundle. */
const ThreeSankey3D = lazy(() => import('./three/ThreeSankey3D'));
const ThreeStreamgraph = lazy(() => import('./three/ThreeStreamgraph'));
/* Radial Bar — now ONE chart (Radial Bar (Classic) merged into it, since
   both were replaced by the same supplied reference chart) rendered
   natively with Three.js so it uses this app's OWN heading, 2D/3D toggle,
   kind dropdown, zoom-lock and export menu instead of any of its own —
   see ThreeReferenceRadialBar.tsx. Its three "version" presets (Olympic
   medals / Slide template / Updating points) are ported verbatim from the
   supplied HTML and switched via the "Version" dropdown below. */
const ThreeReferenceRadialBar = lazy(() => import('./three/ThreeReferenceRadialBar'));
/* Radial Bars Circular — the Three.js port of 3dRadialBarChart.html is the
   renderer again (3D oblique view + top-down 2D view), per product request. */
const ThreeRadialBarsCircular = lazy(() => import('./three/ThreeRadialBarsCircular'));
import { STREAM_COUNTRIES, STREAM_EDITIONS } from './three/streamModel';

/* ============================================================
   Shared Charts v5
   - Single or multi-series (categories + series ⇒ stacked/grouped)
   - Kinds: bar · line · area · pie · donut · radar · polar
     (+ funnel · pyramid opt-in), 3D for bar/area/pie/donut/funnel/pyramid
   - Continuous, ease-in-out 2D⇄3D morph (no geometry jumps at any size)
   - Intelligent x-axis labels: measure → horizontal / rotated / strided,
     never overlapping; fullscreen & exports always show complete text
   - Leader arrows anchored ON the rim with an outline — never hidden
   - Exports: PNG (white bg, theme fonts, nothing trimmed) / PDF / Print /
     true-vector SVG (fonts @imported) / Excel / CSV / JSON
   - Neumorphic family (donut · pie · bars · columns · line · area) painted
     on canvas from ONE painter so the live chart and every export match
   - Palette deliberately free of purple / violet / indigo
   ============================================================ */

export interface ChartDatum { label: string; value: number; color?: string; /** Prior-period comparison value (Radial Bars Circular markers / deltas). */ prior?: number }
export interface StackedSeries { name: string; color?: string; values: number[] }
export type ChartKind = 'bar' | 'line' | 'area' | 'pie' | 'donut' | 'radar' | 'polar' | 'radialbar' | 'radialbarclassic' | 'radialbars' | 'dual' | 'funnel' | 'pyramid' | 'calendarpie' | 'sankey' | 'sankey3d' | 'toroid' | 'gantt' | 'scatter' | 'stream';
/** Calendar-pie: one mini pie per day (ISO date → per-series values). */
export interface CalendarDay { date: string; values: number[] }
/** Sankey flow: source → target with a weight. */
export interface SankeyLink { source: string; target: string; value: number }
/** Gantt task: milestone / phase duration and progress. */
export interface GanttTask { id: string | number; name: string; start: string | number; end: string | number; progress?: number; color?: string; category?: string; assignee?: string; dependsOn?: (string | number)[]; milestone?: boolean; baselineStart?: string | number; baselineEnd?: string | number; slackDays?: number }
/** Scatter point: 2D numeric correlation coordinate. */
export interface ScatterPoint { x: number; y: number; label?: string; size?: number; color?: string; category?: string }
/** Streamgraph event flag (Highcharts-style plot-line label marking a special event on the timeline). */
export interface StreamEvent { at: number; label: string; detail?: string }

/** Brand palette — no purple, violet or indigo anywhere. */
export const PALETTE = ['#0d7a54', '#c9932b', '#0ea5e9', '#e11d63', '#f97316', '#14b8a6', '#1e5aa8', '#84cc16', '#f43f5e', '#a16207', '#06b6d4', '#64748b'];
/** Glossy Sankey-3D family for the Toroid Donut (REFERENCE_PALETTE minus violet, per palette rule). */
export const TOROID_GLOSS = ['#7dd4f8', '#f07ed0', '#4dba80', '#fcc84a', '#f7984a', '#5cd9d5', '#6b9ff5', '#a8db5a', '#f87171', '#fb923c', '#34d399', '#f472b6', '#38bdf8', '#b8e065'];
/** Palette for the active theme — the Honest Paper theme brings Pie.’s slice colours with it. */
export function activePalette(): string[] {
  try { return document.documentElement.getAttribute('data-theme') === 'honest' ? HONEST_PALETTE : PALETTE; } catch { return PALETTE; }
}

const TILT = 0.32; // slight left-leaning perspective — aesthetic, not a full tilt
const K = Math.sin(TILT);
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const SIN45 = Math.SQRT1_2;

/* ---------- colour utils ---------- */
function parseColor(c: string): [number, number, number, number] | null {
  const s = (c || '').trim();
  let m = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(s);
  if (m) return [parseInt(m[1] + m[1], 16), parseInt(m[2] + m[2], 16), parseInt(m[3] + m[3], 16), 1];
  m = /^#([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(s);
  if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, m[2] ? parseInt(m[2], 16) / 255 : 1]; }
  m = /^rgba?\(([^)]+)\)$/i.exec(s);
  if (m) {
    const parts = m[1].split(/[\s,/]+/).filter(Boolean).map(parseFloat);
    if (parts.length >= 3) return [parts[0], parts[1], parts[2], parts.length > 3 ? parts[3] : 1];
  }
  return null;
}
const shadeCache = new Map<string, string>();
const shade = (col: string, f: number) => {
  const key = col + '|' + f.toFixed(3);
  const hit = shadeCache.get(key);
  if (hit) return hit;
  const p = parseColor(col) || [136, 136, 136, 1];
  const c = (v: number) => Math.min(255, Math.max(0, Math.round(v * f)));
  const out = `rgb(${c(p[0])},${c(p[1])},${c(p[2])})`;
  if (shadeCache.size > 4000) shadeCache.clear();
  shadeCache.set(key, out);
  return out;
};
const rgba = (col: string, a: number) => {
  const p = parseColor(col);
  return p ? `rgba(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])},${a})` : col;
};
const withAlpha = (hex: string, a: string) => (/^#[0-9a-f]{6}$/i.test(hex) ? hex + a : rgba(hex, parseInt(a, 16) / 255));
const luma = (col: string) => { const p = parseColor(col); return p ? (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) / 255 : 0.5; };

/* ---------- theme (colours + fonts read from the live token set) ---------- */
export interface Theme { ink: string; axis: string; grid: string; surface?: string; fontBody?: string; fontDisplay?: string; dark?: boolean }
const DEF_BODY = '"Outfit", ui-sans-serif, system-ui, sans-serif';
const DEF_DISPLAY = '"Fraunces", Georgia, serif';
function cssVar(name: string, fallback: string): string {
  try { return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback; } catch { return fallback; }
}
export function themeColors(forExport = false): Theme {
  const fontBody = cssVar('--t-font-body', DEF_BODY);
  const fontDisplay = cssVar('--t-font-display', DEF_DISPLAY);
  if (forExport) return { ink: '#1c2620', axis: '#39443d', grid: 'rgba(60,70,64,0.18)', surface: '#eef0ec', fontBody, fontDisplay, dark: false };
  const ink = cssVar('--t-ink', '#101914');
  const surface = cssVar('--t-surface', '#e4e7e0');
  return { ink, axis: ink, grid: 'rgba(128,128,128,0.18)', surface, fontBody, fontDisplay, dark: luma(ink) > 0.5 };
}
const font = (t: Theme | undefined, weight: number, size: number, display = false) =>
  `${weight} ${size}px ${display ? t?.fontDisplay || DEF_DISPLAY : t?.fontBody || DEF_BODY}`;
/** Families to @import inside exported SVGs so text renders with the app's fonts. */
function fontFamilies(t: Theme): string[] {
  const out = new Set<string>();
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem('aviary-prefs-v2') : null;
    if (raw) {
      const p = JSON.parse(raw);
      if (p.fontBody) out.add(p.fontBody.trim());
      if (p.fontDisplay) out.add(p.fontDisplay.trim());
    }
  } catch { /* ignore */ }
  [t.fontBody || DEF_BODY, t.fontDisplay || DEF_DISPLAY].forEach((stack) => {
    stack.split(',').forEach((part) => {
      const first = part.trim().replace(/^["']|["']$/g, '');
      if (first && !/^(serif|sans-serif|system-ui|ui-sans-serif|ui-serif|monospace|Georgia|Arial|Helvetica)$/i.test(first)) out.add(first);
    });
  });
  return [...out];
}
const fontsReady = async () => { try { await (document as unknown as { fonts?: { ready: Promise<unknown> } }).fonts?.ready; } catch { /* noop */ } };

/* ---------- text helpers ---------- */
const approxW = (s: string, fs = 10.5) => s.length * fs * 0.58;
/** Smart label fitting — ellipsis, prefers word boundaries. Deterministic (no ctx). */
export function fitText(s: string, maxW: number, fs = 10.5): string {
  const cw = fs * 0.58;
  const maxC = Math.max(2, Math.floor(maxW / cw));
  if (s.length <= maxC) return s;
  let cut = s.slice(0, maxC - 1);
  const sp = cut.lastIndexOf(' ');
  if (sp > maxC * 0.5) cut = cut.slice(0, sp);
  return cut.trimEnd() + '…';
}
export const fmtNum = (n: number) =>
  Math.abs(n) >= 1e6 ? `${(n / 1e6).toFixed(1).replace(/\.0$/, '')}M`
    : Math.abs(n) >= 1e3 ? `${(n / 1e3).toFixed(1).replace(/\.0$/, '')}k`
    : String(Math.round(n));
type Ctx = CanvasRenderingContext2D;
const measureW = (ctx: Ctx, s: string) => {
  try { const w = ctx.measureText(s).width; return w > 0 && isFinite(w) ? w : approxW(s); } catch { return approxW(s); }
};
/** Measured ellipsis using the context's current font. */
function fitCtx(ctx: Ctx, s: string, maxW: number): string {
  if (maxW === Infinity || measureW(ctx, s) <= maxW) return s;
  let lo = 0, hi = s.length;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (measureW(ctx, s.slice(0, mid) + '…') <= maxW) lo = mid; else hi = mid - 1; }
  let cut = s.slice(0, Math.max(1, lo));
  const sp = cut.lastIndexOf(' ');
  if (sp > cut.length * 0.5) cut = cut.slice(0, sp);
  return cut.trimEnd() + '…';
}

/* ================= CDN loaders ================= */
const scriptCache = new Map<string, Promise<void>>();
function loadScript(src: string): Promise<void> {
  if (!scriptCache.has(src)) {
    scriptCache.set(src, new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = () => resolve();
      s.onerror = () => { scriptCache.delete(src); reject(new Error('Failed to load ' + src)); };
      document.head.appendChild(s);
    }));
  }
  return scriptCache.get(src)!;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
export async function loadPdfMake(): Promise<any> {
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.12/pdfmake.min.js');
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.12/vfs_fonts.js');
  return (window as any).pdfMake;
}
export async function loadExcelJS(): Promise<any> {
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js');
  return (window as any).ExcelJS;
}
/* eslint-enable @typescript-eslint/no-explicit-any */

export function downloadBlob(name: string, blob: Blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

export function jpegToPdf(jpegBytes: Uint8Array, wPx: number, hPx: number): Blob {
  const wPt = (wPx * 0.75) / 3, hPt = (hPx * 0.75) / 3;
  const enc = new TextEncoder();
  const chunks: (Uint8Array | string)[] = [];
  const offsets: number[] = [];
  let len = 0;
  const push = (s: Uint8Array | string) => { chunks.push(s); len += typeof s === 'string' ? enc.encode(s).length : s.length; };
  const obj = (body: string) => { offsets.push(len); push(body); };
  push('%PDF-1.4\n');
  obj('1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n');
  obj('2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n');
  obj(`3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${wPt.toFixed(1)} ${hPt.toFixed(1)}]/Resources<</XObject<</Im0 4 0 R>>>>/Contents 5 0 R>>endobj\n`);
  offsets.push(len);
  push(`4 0 obj<</Type/XObject/Subtype/Image/Width ${wPx}/Height ${hPx}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ${jpegBytes.length}>>stream\n`);
  push(jpegBytes);
  push('\nendstream endobj\n');
  const content = `q ${wPt.toFixed(1)} 0 0 ${hPt.toFixed(1)} 0 0 cm /Im0 Do Q`;
  obj(`5 0 obj<</Length ${content.length}>>stream\n${content}\nendstream endobj\n`);
  const xrefAt = len;
  push(`xref\n0 6\n0000000000 65535 f \n${offsets.map((o) => String(o).padStart(10, '0') + ' 00000 n \n').join('')}`);
  push(`trailer<</Size 6/Root 1 0 R>>\nstartxref\n${xrefAt}\n%%EOF`);
  return new Blob(chunks.map((c) => (typeof c === 'string' ? enc.encode(c) : c)) as BlobPart[], { type: 'application/pdf' });
}

export function printCanvas(title: string, cv: HTMLCanvasElement) {
  const url = cv.toDataURL('image/png');
  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'position:fixed;right:200vw;bottom:200vh;width:980px;height:720px;border:0;';
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow!.document;
  doc.open();
  doc.write(`<html><head><title>${title}</title><style>@page{margin:12mm;}body{margin:0;display:grid;place-items:center;background:#fff;}img{max-width:100%;}</style></head><body><img src="${url}"/></body></html>`);
  doc.close();
  const cleanup = () => { try { iframe.remove(); } catch { /* noop */ } };
  iframe.contentWindow!.onafterprint = cleanup;
  const img = doc.querySelector('img')!;
  const go = () => setTimeout(() => {
    try { iframe.contentWindow!.focus(); iframe.contentWindow!.print(); } catch { cleanup(); }
    setTimeout(cleanup, 60000);
  }, 150);
  if ((img as HTMLImageElement).complete) go(); else img.addEventListener('load', go);
}

/** Rasterize an SVG string to a canvas (white background). */
export function svgToCanvas(svg: string, w: number, h: number, scale = 3): Promise<HTMLCanvasElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
    img.onload = () => {
      const cv = document.createElement('canvas');
      cv.width = w * scale; cv.height = h * scale;
      const ctx = cv.getContext('2d')!;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.drawImage(img, 0, 0, cv.width, cv.height);
      URL.revokeObjectURL(url);
      resolve(cv);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('SVG rasterize failed')); };
    img.src = url;
  });
}

/* ============================================================
   Canvas → SVG recorder. Implements the 2D-context subset used
   by the painters (paths, text, gradients, soft shadows, alpha,
   transforms) emitting true vector SVG — so EVERY chart, including
   the neumorphic family, exports as vector with fonts intact.
   ============================================================ */
// FILE-SIZE FIX: every SVG export's path coordinates flow through this
// rounder. 2-decimal precision (hundredths of a px) is invisible at any
// normal viewing size but meaningfully lengthens every single coordinate
// string — a real cost for facet-heavy charts (the toroid in particular,
// with hundreds to low-thousands of small quads). 1-decimal precision
// (tenths of a px) is still far finer than anything visible on screen or
// in print, and shortens the average coordinate string noticeably.
const r2 = (n: number) => Math.round(n * 10) / 10;
function splitColor(c: string): { color: string; opacity: number } {
  const p = parseColor(c);
  if (!p) return { color: c || '#000', opacity: 1 };
  return { color: `rgb(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])})`, opacity: p[3] };
}
class SvgCtx {
  els: string[] = [];
  defs: string[] = [];
  /** embedded @font-face rules (base64 woff2) — fonts travel with the file, no CDN */
  fontCss = '';
  fillStyle: string | { __grad: string } = '#000';
  strokeStyle: string | { __grad: string } = '#000';
  lineWidth = 1;
  lineJoin = 'miter';
  lineCap = 'butt';
  font = '10px sans-serif';
  textAlign: 'left' | 'center' | 'right' | 'start' | 'end' = 'left';
  globalAlpha = 1;
  shadowBlur = 0; shadowOffsetX = 0; shadowOffsetY = 0; shadowColor = 'rgba(0,0,0,0)';
  private d = '';
  private tx = 0; private ty = 0; private rot = 0;
  private stack: { tx: number; ty: number; rot: number; alpha: number; sb: number; sx: number; sy: number; sc: string }[] = [];
  private gradN = 0;
  private filters = new Map<string, string>();
  private meas: CanvasRenderingContext2D;
  constructor(public W: number, public H: number) {
    this.meas = document.createElement('canvas').getContext('2d')!;
  }
  /* transforms / state */
  setTransform() { /* dpr no-op */ }
  clearRect() { /* no-op */ }
  save() { this.stack.push({ tx: this.tx, ty: this.ty, rot: this.rot, alpha: this.globalAlpha, sb: this.shadowBlur, sx: this.shadowOffsetX, sy: this.shadowOffsetY, sc: this.shadowColor }); }
  restore() {
    const s = this.stack.pop();
    if (s) { this.tx = s.tx; this.ty = s.ty; this.rot = s.rot; this.globalAlpha = s.alpha; this.shadowBlur = s.sb; this.shadowOffsetX = s.sx; this.shadowOffsetY = s.sy; this.shadowColor = s.sc; }
  }
  translate(x: number, y: number) { this.tx += x; this.ty += y; }
  rotate(a: number) { this.rot += a; }
  scale() { /* entrance scale is 1 at export */ }
  clip() { /* reveal clips are full-frame at export */ }
  setLineDash() { /* dashes only decorate live hover guides */ }
  rect(x: number, y: number, w: number, h: number) { this.d += `M ${this.px(x, y)} h ${r2(w)} v ${r2(h)} h ${r2(-w)} Z `; }
  /* path building */
  private px(x: number, y: number) { return `${r2(x + this.tx)} ${r2(y + this.ty)}`; }
  beginPath() { this.d = ''; }
  moveTo(x: number, y: number) { this.d += `M ${this.px(x, y)} `; }
  lineTo(x: number, y: number) { this.d += `L ${this.px(x, y)} `; }
  closePath() { this.d += 'Z '; }
  bezierCurveTo(c1x: number, c1y: number, c2x: number, c2y: number, x: number, y: number) {
    this.d += `C ${this.px(c1x, c1y)} ${this.px(c2x, c2y)} ${this.px(x, y)} `;
  }
  quadraticCurveTo(cx: number, cy: number, x: number, y: number) {
    this.d += `Q ${this.px(cx, cy)} ${this.px(x, y)} `;
  }
  arc(x: number, y: number, r: number, a0: number, a1: number, ccw = false) {
    this.ellipse(x, y, r, r, 0, a0, a1, ccw);
  }
  ellipse(x: number, y: number, rx: number, ry: number, _rot: number, a0: number, a1: number, ccw = false) {
    rx = Math.max(0.01, rx); ry = Math.max(0.01, ry);
    let d = a1 - a0;
    if (ccw && d > 0) d -= Math.PI * 2;
    if (!ccw && d < 0) d += Math.PI * 2;
    const full = Math.abs(d) >= Math.PI * 2 - 1e-4;
    const seg = full ? (d > 0 ? Math.PI : -Math.PI) : d;
    const steps = full ? 2 : 1;
    const sx = x + Math.cos(a0) * rx, sy = y + Math.sin(a0) * ry;
    if (this.d === '' || this.d.endsWith('Z ')) this.d += `M ${this.px(sx, sy)} `;
    else this.d += `L ${this.px(sx, sy)} `;
    let cur = a0;
    for (let i = 0; i < steps; i++) {
      const next = full ? cur + seg : a0 + d;
      const ex = x + Math.cos(next) * rx, ey = y + Math.sin(next) * ry;
      const large = Math.abs(next - cur) > Math.PI ? 1 : 0;
      const sweep = next > cur ? 1 : 0;
      this.d += `A ${r2(rx)} ${r2(ry)} 0 ${large} ${sweep} ${this.px(ex, ey)} `;
      cur = next;
    }
  }
  roundRect(x: number, y: number, w: number, h: number, r: number | number[]) {
    const lim = Math.min(w, h) / 2;
    const rr = (Array.isArray(r) ? r : [r, r, r, r]).map((v) => Math.min(lim, Math.max(0, v)));
    const [tl, tr, br, bl] = [rr[0] ?? 0, rr[1] ?? rr[0] ?? 0, rr[2] ?? rr[0] ?? 0, rr[3] ?? rr[1] ?? rr[0] ?? 0];
    this.d += `M ${this.px(x + tl, y)} H ${r2(x + w - tr + this.tx)} `;
    if (tr) this.d += `A ${r2(tr)} ${r2(tr)} 0 0 1 ${this.px(x + w, y + tr)} `;
    this.d += `V ${r2(y + h - br + this.ty)} `;
    if (br) this.d += `A ${r2(br)} ${r2(br)} 0 0 1 ${this.px(x + w - br, y + h)} `;
    this.d += `H ${r2(x + bl + this.tx)} `;
    if (bl) this.d += `A ${r2(bl)} ${r2(bl)} 0 0 1 ${this.px(x, y + h - bl)} `;
    this.d += `V ${r2(y + tl + this.ty)} `;
    if (tl) this.d += `A ${r2(tl)} ${r2(tl)} 0 0 1 ${this.px(x + tl, y)} `;
    this.d += 'Z ';
  }
  /* paint */
  private resolve(style: string | { __grad: string }): string {
    return typeof style === 'string' ? style : `url(#${style.__grad})`;
  }
  private fx(): string {
    let attr = this.globalAlpha < 1 ? ` opacity="${r2(this.globalAlpha)}"` : '';
    if (this.shadowBlur > 0 || this.shadowOffsetX || this.shadowOffsetY) {
      const { color, opacity } = splitColor(this.shadowColor);
      if (opacity > 0) {
        const key = `${r2(this.shadowOffsetX)}|${r2(this.shadowOffsetY)}|${r2(this.shadowBlur)}|${color}|${r2(opacity)}`;
        let id = this.filters.get(key);
        if (!id) {
          id = `sh${this.filters.size + 1}`;
          this.filters.set(key, id);
          // classic blur → offset → flood → composite → merge chain: renders in every
          // SVG engine (browsers, Inkscape, librsvg, Illustrator), unlike feDropShadow
          this.defs.push(`<filter id="${id}" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur in="SourceAlpha" stdDeviation="${r2(this.shadowBlur / 2)}"/><feOffset dx="${r2(this.shadowOffsetX)}" dy="${r2(this.shadowOffsetY)}" result="ob"/><feFlood flood-color="${color}" flood-opacity="${r2(opacity)}"/><feComposite in2="ob" operator="in" result="sh"/><feMerge><feMergeNode in="sh"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`);
        }
        attr += ` filter="url(#${id})"`;
      }
    }
    return attr;
  }
  fill() { if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`); }
  stroke() {
    if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="none" stroke="${this.resolve(this.strokeStyle)}" stroke-width="${r2(this.lineWidth)}" stroke-linejoin="${this.lineJoin === 'round' ? 'round' : 'miter'}" stroke-linecap="${this.lineCap === 'round' ? 'round' : 'butt'}"${this.fx()}/>`);
  }
  fillRect(x: number, y: number, w: number, h: number) {
    this.els.push(`<rect x="${r2(x + this.tx)}" y="${r2(y + this.ty)}" width="${r2(w)}" height="${r2(h)}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`);
  }
  fillText(text: string, x: number, y: number) {
    const fm = /(\d+(?:\.\d+)?)px\s+(.+)$/.exec(this.font);
    const size = fm ? +fm[1] : 10;
    const fam = fm ? fm[2] : 'sans-serif';
    const wm = /^(\d{3}|bold)\s/.exec(this.font);
    const weight = wm ? (wm[1] === 'bold' ? '700' : wm[1]) : '400';
    const anchor = this.textAlign === 'center' ? 'middle' : this.textAlign === 'right' || this.textAlign === 'end' ? 'end' : 'start';
    const esc = text.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const gx = r2(x + this.tx), gy = r2(y + this.ty);
    const tf = this.rot !== 0 ? ` transform="rotate(${r2((this.rot * 180) / Math.PI)} ${gx} ${gy})"` : '';
    this.els.push(`<text x="${gx}" y="${gy}" font-family="${fam.replace(/"/g, "'")}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}" fill="${this.resolve(this.fillStyle)}"${tf}${this.fx()}>${esc}</text>`);
  }
  measureText(t: string) { this.meas.font = this.font; return this.meas.measureText(t); }
  createLinearGradient(x0: number, y0: number, x1: number, y1: number) {
    const id = `g${++this.gradN}`;
    const stops: string[] = [];
    this.defs.push('');
    const idx = this.defs.length - 1;
    const self = this;
    const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
    return {
      __grad: id,
      addColorStop(off: number, col: string) {
        const sc = splitColor(col);
        stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
        self.defs[idx] = `<linearGradient id="${id}" x1="${r2(ax)}" y1="${r2(ay)}" x2="${r2(bx)}" y2="${r2(by)}" gradientUnits="userSpaceOnUse">${stops.join('')}</linearGradient>`;
      },
    };
  }
  /** SVG <radialGradient> support — required for dual-axis 3D line markers
   * and the toroid's centre orb. Canvas semantics: offset 0 lives on the
   * START circle (x0,y0,r0) and offset 1 on the END circle (x1,y1,r1). In
   * SVG that maps to fx/fy/fr = start (focal) circle and cx/cy/r = end
   * circle — the old attribute mapping had the two circles swapped, which
   * inverted every radial gradient in SVG exports. */
  createRadialGradient(x0: number, y0: number, r0: number, x1: number, y1: number, r1: number) {
    const id = `g${++this.gradN}`;
    const stops: string[] = [];
    this.defs.push('');
    const idx = this.defs.length - 1;
    const self = this;
    const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
    return {
      __grad: id,
      addColorStop(off: number, col: string) {
        const sc = splitColor(col);
        stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
        self.defs[idx] = `<radialGradient id="${id}" cx="${r2(bx)}" cy="${r2(by)}" r="${r2(Math.max(0.01, r1))}" fx="${r2(ax)}" fy="${r2(ay)}" fr="${r2(Math.max(0, r0))}" gradientUnits="userSpaceOnUse">${stops.join('')}</radialGradient>`;
      },
    };
  }
  toString(): string {
    const fams = fontFamilies(themeColors(true));
    const googleImport = fams.length
      ? `@import url('https://fonts.googleapis.com/css2?family=${fams.map((f) => encodeURIComponent(f).replace(/%20/g, '+')).join('&family=')}:wght@400;600;700&display=swap');\n`
      : '';
    const style = `<style><![CDATA[\n${googleImport}${this.fontCss}]]></style>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${this.W}" height="${this.H}" viewBox="0 0 ${this.W} ${this.H}"><defs>${style}${this.defs.join('')}</defs><rect width="${this.W}" height="${this.H}" fill="#ffffff"/>${this.els.join('')}</svg>`;
  }
}

/* ================= Mini dropdown (shows current selection) ================= */
export function MiniDrop({ label, items, onPick, icon, activeKey }: {
  label: string; items: { key: string; label: string; disabled?: boolean }[];
  onPick: (k: string) => void; icon?: React.ReactNode; activeKey?: string;
}) {
  const [open, setOpen] = useState(false);
  const anchorRef = useRef<HTMLDivElement>(null);
  const popRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number; minWidth: number } | null>(null);

  /* Measure the anchor on open and on scroll/resize so the portal menu
     tracks the button. Uses rAF-throttled viewport listeners. */
  useEffect(() => {
    if (!open) return;
    let raf = 0;
    const update = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const r = anchorRef.current?.getBoundingClientRect();
        if (!r) return;
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        const estH = Math.min(window.innerHeight * 0.6, items.length * 36 + 12);
        const below = vh - r.bottom - 8;
        const above = r.top - 8;
        // Flip upward when there is no room below but room above.
        const openUp = below < Math.min(estH, 180) && above > below;
        const menuH = openUp ? Math.min(estH, above) : Math.min(estH, Math.max(below, 120));
        const left = Math.min(Math.max(8, r.left), vw - 196);
        const top = openUp ? Math.max(8, r.top - 6 - menuH) : Math.min(r.bottom + 6, vh - 8 - 40);
        setPos({ left, top, minWidth: Math.max(180, r.width) });
      });
    };
    update();
    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true);
    return () => {
      window.removeEventListener('resize', update);
      window.removeEventListener('scroll', update, true);
      cancelAnimationFrame(raf);
    };
  }, [open, items.length]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (anchorRef.current?.contains(t)) return;
      if (popRef.current?.contains(t)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('mousedown', onDown);
    window.addEventListener('keydown', onKey, true);
    return () => {
      window.removeEventListener('mousedown', onDown);
      window.removeEventListener('keydown', onKey, true);
    };
  }, [open]);

  return (
    <div ref={anchorRef} className="relative">
      <button onClick={() => setOpen(!open)}
        className="tk-btn-ghost flex items-center gap-1.5 rounded-xl px-3 py-1.5 font-body text-[12px] font-bold">
        {icon} {label} <ChevronDown size={12} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {/* Portalled out of the chart card: the menu renders above ALL charts (and
          above the fullscreen overlays) instead of being clipped/covered by
          neighboring chart cards. `position: fixed` keeps it out of every
          scroll container so opening it can never introduce a page scrollbar.
          Target is the native-fullscreen element when one is active — a body
          portal would be invisible under native fullscreen. */}
      {open && createPortal(
        <div ref={popRef}
          style={{
            position: 'fixed',
            left: pos?.left ?? -9999,
            top: pos?.top ?? -9999,
            minWidth: pos?.minWidth ?? 180,
            maxWidth: 'calc(100vw - 16px)',
            backgroundColor: 'var(--t-surface)',
            zIndex: 9999,
            visibility: pos ? 'visible' : 'hidden',
          }}
          className="tk-pop max-h-[60vh] overflow-y-auto rounded-xl p-1 shadow-2xl border border-ink/15">
          {items.map((it) => (
            <button key={it.key} disabled={it.disabled}
              onClick={() => { setOpen(false); onPick(it.key); }}
              className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-left font-body text-[12.5px] font-semibold transition hover:bg-primary/10 disabled:opacity-35 ${activeKey === it.key ? 'text-primary font-bold bg-primary/5' : 'text-ink/80'}`}>
              {it.label}
              {activeKey === it.key && <Check size={13} className="shrink-0 text-primary" />}
            </button>
          ))}
        </div>,
        (typeof document !== 'undefined' && (document.fullscreenElement ?? document.body)) || document.body
      )}
    </div>
  );
}

function useThemeTick() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const handler = () => { setTick((t) => t + 1); timer = setTimeout(() => setTick((t) => t + 1), 720); };
    window.addEventListener('aviary:prefs', handler);
    return () => { window.removeEventListener('aviary:prefs', handler); clearTimeout(timer); };
  }, []);
  return tick;
}

/* ============================================================
   Intelligent x-axis labels
   measure → horizontal if they fit; otherwise rotate (-45° / -90°)
   and stride so labels never collide. Compact mode keeps things
   readable with measured ellipsis; full mode (fullscreen / export)
   never truncates and grows the bottom padding instead.
   ============================================================ */
interface XPlan { rot: number; stride: number; padB: number; maxW: number; fs: number; /** how far a rotated first label reaches left of its anchor */ overhang: number }
function planX(labels: string[], step: number, full: boolean, fs = 10.5): XPlan {
  const longest = labels.reduce((m, l) => Math.max(m, approxW(l, fs)), 0);
  const base = 34;
  if (!labels.length || longest <= step - 6) return { rot: 0, stride: 1, padB: base, maxW: Math.max(20, step - 4), fs, overhang: 0 };
  if (full) {
    const rot = longest * SIN45 + fs <= 130 ? -Math.PI / 4 : -Math.PI / 2;
    const foot = (fs * 1.4) / Math.abs(Math.sin(rot));
    const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
    const padB = Math.min(170, (rot === -Math.PI / 2 ? longest : longest * SIN45) + 22);
    return { rot, stride, padB, maxW: Infinity, fs, overhang: longest * Math.abs(Math.cos(rot)) + 4 };
  }
  if (step >= 56) return { rot: 0, stride: 1, padB: base, maxW: step - 4, fs, overhang: 0 };
  const rot = -Math.PI / 4;
  const foot = (fs * 1.4) / SIN45;
  const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
  const maxW = 78;
  const padB = Math.min(70, Math.min(longest, maxW) * SIN45 + 22);
  return { rot, stride, padB, maxW, fs, overhang: Math.min(longest, maxW) * SIN45 + 4 };
}
/** Plan labels for a plot of width `W - l - r`, growing the left pad when a rotated first label would spill off-canvas. */
function planXFit(labels: string[], W: number, l: number, r: number, full: boolean, fs: number, slots: number, endpoints = false) {
  const stepOf = (left: number) => { const cw = Math.max(10, W - left - r); return endpoints ? (slots > 1 ? cw / (slots - 1) : cw) : cw / Math.max(1, slots); };
  let plan = planX(labels, stepOf(l), full, fs);
  if (plan.overhang > l) { l = plan.overhang; plan = planX(labels, stepOf(l), full, fs); }
  return { plan, l, step: stepOf(l) };
}
function drawXLabels(ctx: Ctx, labels: string[], plan: XPlan, xOf: (i: number) => number, yAxis: number, t: Theme, W: number, weight = 600, color?: string) {
  ctx.font = font(t, weight, plan.fs);
  ctx.fillStyle = color || t.axis;
  const n = labels.length;
  for (let i = 0; i < n; i++) {
    const x = xOf(i);
    const isLast = i === n - 1;
    const shown = i % plan.stride === 0 || (isLast && plan.stride > 1 && (n - 1) % plan.stride >= Math.ceil(plan.stride * 0.6));
    if (!shown) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x, yAxis); ctx.lineTo(x, yAxis + 3); ctx.stroke();
      continue;
    }
    const text = plan.maxW === Infinity ? labels[i] : fitCtx(ctx, labels[i], plan.maxW);
    if (plan.rot === 0) {
      const w = measureW(ctx, text);
      const cx = Math.max(w / 2 + 2, Math.min(W - w / 2 - 2, x));
      ctx.textAlign = 'center';
      ctx.fillText(text, cx, yAxis + 16);
    } else {
      ctx.save(); ctx.translate(x, yAxis + 8); ctx.rotate(plan.rot); ctx.textAlign = 'right';
      ctx.fillText(text, 0, plan.fs * 0.35); ctx.restore();
    }
  }
  ctx.textAlign = 'left';
}

/* ================= geometry helpers ================= */
const ZX = 15, ZY = 10, DZ = 7, DZY = 4.5; // 3D line/area: per-series depth step + (thin) slab thickness
interface XY { pad: { l: number; r: number; t: number; b: number }; cw: number; ch: number; step: number; plan: XPlan; ox: number; oy: number }
function xyLayout(kind: 'bar' | 'line' | 'area', W: number, H: number, m: number, labels: string[], nD: number, max: number, hasY: boolean, full: boolean): XY {
  const isBar = kind === 'bar';
  const ox = isBar ? 13 * m : ZX * m * Math.max(0, nD - 1) + DZ * m;
  const oy = isBar ? 9 * m : ZY * m * Math.max(0, nD - 1) + DZY * m;
  const l0 = 12 + approxW(fmtNum(max), 10.5) + 12 + (hasY ? 14 : 0);
  const r = 16 + (isBar ? 20 * m : ox);
  const tp = 18 + (isBar ? 12 * m : oy);
  const { plan, l, step } = planXFit(labels, W, l0, r, full, 10.5, labels.length);
  return { pad: { l, r, t: tp, b: plan.padB }, cw: W - l - r, ch: H - tp - plan.padB, step, plan, ox, oy };
}

/** Depth rank per series: 0 = front (smallest total) … n-1 = back (largest). */
export function seriesDepth(series: StackedSeries[]): number[] {
  const order = series.map((s, i) => ({ i, sum: s.values.reduce((a, b) => a + b, 0) })).sort((a, b) => a.sum - b.sum);
  const depth = new Array(series.length).fill(0);
  order.forEach((o, rank) => { depth[o.i] = rank; });
  return depth;
}

const leaderLabel = (d: ChartDatum, total: number) => `${d.label} · ${Math.round((d.value / total) * 100)}%`;
function circGeom(W: number, H: number, m: number, data: ChartDatum[], full = false) {
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const longest = Math.max(0, ...data.map((x) => approxW(leaderLabel(x, total))));
  const labelSpace = full ? longest + 40 : Math.min(Math.max(60, longest) + 34, W * 0.32);
  const squash = lerp(1, K, m);
  // The diameter is FIXED across the 2D⇄3D morph: the disc is sized once for
  // the flat view (the binding constraint) and only tilts/extrudes afterwards.
  let R = Math.min(W / 2 - labelSpace, (H - 44) / 2);
  R = Math.max(full ? 60 : 40, R);
  // Keep the extruded disc's depth strictly proportional to its radius so the
  // 3D pie/donut/polar always read with a proper thickness in fullscreen,
  // regardless of how much vertical space the container offers.
  // Slimmer than the legacy 0.42 ratio: the old slab looked chunky in
  // fullscreen, so the extrusion now tops out at ~30 % of the radius with a
  // capped pixel ceiling.
  const depth = Math.min(58, Math.max(12, R * 0.3)) * m;
  const cy = (H - depth) / 2 + 4;
  return { cx: W / 2, cy, R, rInRatio: 0.55, depth, squash, total };
}

/* ================= true-3D projection core (rotatable 3D scenes) =================
   A tiny software 3D pipeline shared by the rotatable 3D charts (currently
   Sankey 3D). World space is pixels in X/Y with a Z depth in pixels; the
   camera orbits around the scene centre by yaw (horizontal) and pitch
   (vertical tilt). Projection is a gentle perspective divide, so near edges
   grow and far edges shrink exactly like a modelled object in a viewport.
   Dragging the canvas orbits the camera; the angles ease back toward rest on
   release so the scene always settles into a readable default view. */
export interface Orbit3D { yaw: number; pitch: number }
export const ORBIT_REST: Orbit3D = { yaw: -0.30, pitch: 0.30 };
export interface Proj3D {
  px: (x: number, y: number, z: number) => number;
  py: (x: number, y: number, z: number) => number;
  sc: (x: number, y: number, z: number) => number;
  yaw: number; pitch: number; cx: number; cy: number;
}
export function makeProj(W: number, H: number, o: Orbit3D, dist?: number): Proj3D {
  // Focal length scales with canvas size so perspective strength is identical
  // in cards, fullscreen and exports.
  const D = dist ?? Math.max(W, H) * 2.2;
  const cx = W / 2, cy = H / 2;
  const cyaw = Math.cos(o.yaw), syaw = Math.sin(o.yaw);
  const cpit = Math.cos(o.pitch), spit = Math.sin(o.pitch);
  const rot = (x: number, y: number, z: number): [number, number, number] => {
    const dx = x - cx, dy = y - cy;
    // yaw around the vertical axis, then pitch around the horizontal axis
    const x1 = dx * cyaw - z * syaw;
    const z1 = dx * syaw + z * cyaw;
    const y2 = dy * cpit - z1 * spit;
    const z2 = dy * spit + z1 * cpit;
    return [x1, y2, z2];
  };
  const sc = (x: number, y: number, z: number) => D / (D + rot(x, y, z)[2]);
  return {
    px: (x, y, z) => cx + rot(x, y, z)[0] * sc(x, y, z),
    py: (x, y, z) => cy + rot(x, y, z)[1] * sc(x, y, z),
    sc, yaw: o.yaw, pitch: o.pitch, cx, cy,
  };
}

/* ---- sankey layout: longest-path column assignment, proportional node heights, flows stacked in node order ---- */
interface SkNode { name: string; col: number; value: number; x: number; y: number; h: number; color: string }
interface SkFlow { si: number; ti: number; value: number; sy0: number; sy1: number; ty0: number; ty1: number }
export function sankeyLayout(links: SankeyLink[], W: number, H: number, labelSpace: number) {
  const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
  const idx = new Map(names.map((n, i) => [n, i]));
  const outs = names.map(() => [] as number[]), ins = names.map(() => [] as number[]);
  links.forEach((l, li) => { outs[idx.get(l.source)!].push(li); ins[idx.get(l.target)!].push(li); });
  // column = longest path from a source (cycle-guarded)
  const col = new Array(names.length).fill(0);
  const visit = (i: number, depth: number, seen: Set<number>) => {
    if (seen.has(i) || depth > 32) return;
    col[i] = Math.max(col[i], depth);
    seen.add(i);
    outs[i].forEach((li) => visit(idx.get(links[li].target)!, depth + 1, seen));
    seen.delete(i);
  };
  names.forEach((_, i) => { if (!ins[i].length) visit(i, 0, new Set()); });
  const cols = Math.max(...col) + 1;
  if (cols < 2) return null;
  const value = names.map((_, i) => Math.max(outs[i].reduce((s2, li) => s2 + links[li].value, 0), ins[i].reduce((s2, li) => s2 + links[li].value, 0)));
  const padT = 14, padB = 14, padL = 8, padR = labelSpace;
  const nodeW = 12, gap = 10;
  const plotW = W - padL - padR - nodeW, plotH = H - padT - padB;
  const colX = Array.from({ length: cols }, (_, c) => padL + (plotW * c) / (cols - 1));
  const perCol = Array.from({ length: cols }, () => [] as number[]);
  names.forEach((_, i) => perCol[col[i]].push(i));
  // scale so the tallest column fits
  const colTotal = perCol.map((ids) => ids.reduce((s2, i) => s2 + value[i], 0) + gap * Math.max(0, ids.length - 1));
  const scale = (plotH) / Math.max(...colTotal, 1);
  const pal = activePalette();
  const nodes: SkNode[] = names.map((n, i) => ({ name: n, col: col[i], value: value[i], x: colX[col[i]], y: 0, h: value[i] * scale, color: pal[i % pal.length] }));
  perCol.forEach((ids) => {
    ids.sort((a, b) => value[b] - value[a]);
    const total = ids.reduce((s2, i) => s2 + nodes[i].h, 0) + gap * Math.max(0, ids.length - 1);
    let y = padT + (plotH - total) / 2;
    ids.forEach((i) => { nodes[i].y = y; y += nodes[i].h + gap; });
  });
  // flows: stack outgoing on the source (ordered by target y) and incoming on the target (ordered by source y)
  const flows: SkFlow[] = links.map((l) => ({ si: idx.get(l.source)!, ti: idx.get(l.target)!, value: l.value, sy0: 0, sy1: 0, ty0: 0, ty1: 0 }));
  nodes.forEach((n, i) => {
    let y = n.y;
    outs[i].map((li) => flows[li]).sort((a, b) => nodes[a.ti].y - nodes[b.ti].y).forEach((f) => { f.sy0 = y; y += f.value * scale; f.sy1 = y; });
    y = n.y;
    ins[i].map((li) => flows[li]).sort((a, b) => nodes[a.si].y - nodes[b.si].y).forEach((f) => { f.ty0 = y; y += f.value * scale; f.ty1 = y; });
  });
  return { nodes, flows, nodeW, cols, colX };
}

/** 3D layout: same flow math as 2D, but shifted right to reserve the
   left outside-label gutter and vertically centred in the taller 3D plot. */
export function sankeyLayout3D(links: SankeyLink[], W: number, H: number, labelSpace: number, padL3D: number) {
  const lay = sankeyLayout(links, W - padL3D, H, labelSpace);
  if (!lay) return null;
  const dx = padL3D;
  lay.nodes.forEach((n) => { n.x += dx; });
  lay.colX = lay.colX.map((x) => x + dx);
  return lay;
}

function sankeyRibbon(ctx: Ctx, f: SkFlow, nodes: SkNode[], nodeW: number, emphasis = 0) {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x, mid = (x0 + x1) / 2;
  const spread = 5 * emphasis;
  ctx.beginPath(); ctx.moveTo(x0, f.sy0);
  ctx.bezierCurveTo(mid, f.sy0 - spread, mid, f.ty0 - spread, x1, f.ty0);
  ctx.lineTo(x1, f.ty1);
  ctx.bezierCurveTo(mid, f.ty1 + spread, mid, f.sy1 + spread, x0, f.sy1);
  ctx.closePath();
}

/* ---- sankey ribbon sampler: bezier ribbons as polylines so perspective
   projection can be applied per-vertex (true 3D), shared by painter + hit ---- */
interface SlabPt { x: number; y: number }
// Shared glass-slab camera: the painter and the hit tester MUST use the same
// projection or hover will drift from the rotated artwork.
export function sankeyCam(W: number, H: number, o: Orbit3D) {
  // Oblique-cabinet projection tuned to the reference render: depth recedes
  // up-and-right at a fixed shallow angle, and yaw only *scales* that
  // direction (never a rotation matrix), so x-order can never flip and no
  // mirror/break can occur at any orbit, size or morph step.
  const yaw = Math.max(-1.1, Math.min(1.1, o.yaw));
  const tilt = Math.max(0, Math.min(1, (o.pitch + 0.15) / 1.25));
  const dir = yaw >= 0 ? 1 : -1;
  const k = 0.34 + 0.30 * Math.min(1, Math.abs(yaw) / 0.6); // 0.34..0.64
  const dx = dir * k, dy = -(0.30 + 0.34 * tilt);
  const px = (x: number, y: number, z: number): number => x + z * dx;
  const py = (x: number, y: number, z: number): number => {
    const s = 1 / (1 + Math.max(0, z) * 0.0009);
    return H / 2 + (y - H / 2) * (0.985 - tilt * 0.06) * s + z * -dy * -1 * s;
  };
  return { px, py };
}
const SK_SEG = 22;
function sankeySlab(f: SkFlow, nodes: SkNode[], nodeW: number, spread: number): { top: SlabPt[]; bot: SlabPt[] } {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x;
  const c1 = x0 + (x1 - x0) * 0.5, c2 = x1 - (x1 - x0) * 0.5;
  const tA0 = f.sy0 - spread, tA1 = f.sy1 + spread, tB0 = f.ty0 - spread, tB1 = f.ty1 + spread;
  const top: SlabPt[] = [], bot: SlabPt[] = [];
  for (let s = 0; s <= SK_SEG; s++) {
    const tt = s / SK_SEG, u = 1 - tt;
    const bx = u * u * u * x0 + 3 * u * u * tt * c1 + 3 * u * tt * tt * c2 + tt * tt * tt * x1;
    const by0 = u * u * u * tA0 + 3 * u * u * tt * tA0 + 3 * u * tt * tt * tB0 + tt * tt * tt * tB0;
    const by1 = u * u * u * tA1 + 3 * u * u * tt * tA1 + 3 * u * tt * tt * tB1 + tt * tt * tt * tB1;
    top.push({ x: bx, y: by0 }); bot.push({ x: bx, y: by1 });
  }
  return { top, bot };
}

/* ---- radial bar geometry ---- */
/* ---- radial pipe renderer: solves the flat-tube problem ----
   A flat 3D ring reads as a ribbon because its top face is a single fill.
   A pipe reads as a pipe because light wraps around its circular cross
   section. pipeShade() reproduces that wrap analytically: given the
   fractional position v across the tube (0 = inner wall, 1 = outer wall),
   it returns the light factor of a cylinder lit from the top-left —
   bright crest, saturated flank, dark contact edge — so N stacked strokes
   fuse into one round tube. Ends are NOT round dots: they are flat radial
   cuts (butt caps) whose top edge follows the same perspective squash as
   the ring, exactly like a sawn pipe end. */
const pipeShade = (v: number) => 0.62 + 0.78 * Math.sin(Math.PI * Math.min(1, Math.max(0, v)));

/* ---- sankey-3D glass-tube renderer (matches the reference render) ----
   Reference anatomy, observed pixel-by-pixel:
   - Nodes are OPAQUE vertical glass bars with a rounded top / elliptical cap,
     a bright vertical sheen band on the face, and the "Name · value" label
     printed ON the bar face (dark ink on light bars, white on dark bars).
   - Ribbons are TRANSLUCENT glass tubes: bright highlight along the TOP edge,
     saturated color through the middle, deep saturated color along the
     BOTTOM edge, with a soft blurred shadow cast beneath each tube onto the
     glossy off-white floor. Tube color = horizontal source→target blend.
   - Thin downstream ribbons (Offered→Hired/Declined) curve gracefully and
     the tiny end nodes sit as small glass blocks the tubes plug into.
   The helpers below reproduce exactly that construction. */
const SK3_TUBE_SEG = 40;
/** Sample a ribbon's S-curve edges into a polyline tube.
   Reference curvature: the bend concentrates ~55% across (smoothstep ease),
   NOT a symmetric cubic — that is what makes tubes swoop and settle like
   the reference instead of bowing evenly. Bevel bulbs at the mouths are
   intentional (the reference tubes bulge slightly as they leave the bars). */
function sk3Smooth(u: number): number {
  const t = Math.max(0, Math.min(1, u));
  return t * t * t * (t * (t * 6 - 15) + 10);
}
function sk3Tube(f: SkFlow, nodes: SkNode[], nodeW: number): { top: SlabPt[]; bot: SlabPt[] } {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x;
  const top: SlabPt[] = [], bot: SlabPt[] = [];
  for (let s = 0; s <= SK3_TUBE_SEG; s++) {
    const u = s / SK3_TUBE_SEG;
    const e = sk3Smooth(u);
    const bx = x0 + (x1 - x0) * u;
    const by0 = f.sy0 + (f.ty0 - f.sy0) * e;
    const by1 = f.sy1 + (f.ty1 - f.sy1) * e;
    // bevel bulb: tube mouths bulge ~12% near the bars, like the reference
    const bulb = 1 + 0.12 * (Math.exp(-Math.pow(u / 0.10, 2)) + Math.exp(-Math.pow((1 - u) / 0.10, 2)));
    const mid = (by0 + by1) / 2, half = ((by1 - by0) / 2) * bulb;
    top.push({ x: bx, y: mid - half }); bot.push({ x: bx, y: mid + half });
  }
  return { top, bot };
}
/** Fill the tube silhouette between two sampled edges. */
function sk3FillTube(ctx: Ctx, T: SlabPt[], B: SlabPt[]) {
  ctx.beginPath();
  T.forEach((q, k) => { k === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y); });
  for (let k = B.length - 1; k >= 0; k--) ctx.lineTo(B[k].x, B[k].y);
  ctx.closePath(); ctx.fill();
}
/** Stroke one sampled edge. */
function sk3StrokeEdge(ctx: Ctx, E: SlabPt[]) {
  ctx.beginPath();
  E.forEach((q, k) => { k === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y); });
  ctx.stroke();
}
/** Vertical glass gradient for a tube: bright crown → mid color → deep base. */
function sk3TubeGrad(ctx: Ctx, yTop: number, yBot: number, c0: string, c1: string, a: number) {
  const g = ctx.createLinearGradient(0, yTop, 0, Math.max(yTop + 1, yBot));
  g.addColorStop(0, rgba(shade(c0, 1.45), a));
  g.addColorStop(0.28, rgba(shade(c0, 1.12), a));
  g.addColorStop(0.55, rgba(c1, a));
  g.addColorStop(1, rgba(shade(c1, 0.62), Math.min(1, a + 0.1)));
  return g;
}
function radialGeom(W: number, H: number, data: ChartDatum[], full: boolean, m = 0) {
  const n = Math.max(1, data.length);
  // Adaptive label column: only reserve side space when there is genuinely
  // room (large canvas or fullscreen). On small tiles / narrow exports every
  // pixel goes to the rings and labels render inside the tubes instead.
  const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
  const roomy = full || W >= 560;
  const labelSpace = roomy ? longest + 26 : 0;
  const squash = 1 - 0.44 * m;
  // Vertical budget accounts for the 3D squash: an untilted disc needs its
  // full radius, a squashed one needs far less height.
  const vBudget = full ? (H - 32) / 2 : (H - 24) / 2;
  const R = Math.max(26, Math.min((W - labelSpace) / 2 - 10, vBudget / Math.max(0.5, squash) - 4));
  const cx = labelSpace + (W - labelSpace) / 2, cy = H / 2;
  // Tube thickness adapts to ring count so N rings always fit: thin tubes for
  // many rings (min 3px), chunky tubes for few (max 22px). The inner hole
  // keeps a floor of 14px so the last (innermost) bar never splits/collapses.
  const avail = Math.max(30, R - 16);
  const thick = Math.max(3, Math.min(22, avail / Math.max(1, n * 1.22)));
  const gap = Math.max(1.5, Math.min(4, thick * 0.28));
  const radiusOf = (i: number) => R - thick / 2 - i * (thick + gap);
  // Clamp helper: keeps the innermost tube's inner edge >= minHole so the
  // last bar can never invert / split into a broken ring.
  const minHole = 13;
  const ringR = (i: number) => Math.max(thick / 2 + minHole, radiusOf(i));
  return { cx, cy, R, thick, gap, radiusOf, ringR, labelSpace, n, roomy };
}

/* ---- radial classic geometry: fixed-diameter rings that can never overlap ----
   Pitch is SOLVED from the ring count (n·thick + (n−1)·gap ≤ R − minHole),
   so adjacent tubes always clear each other. Shared verbatim by the painter
   and the hit tester. */
interface RadialClassicGeom { cx: number; cy: number; R: number; thick: number; gap: number; ringR: (i: number) => number; n: number; roomy: boolean }
function radialClassicGeom(W: number, H: number, data: ChartDatum[], full: boolean): RadialClassicGeom {
  const n = Math.max(1, data.length);
  const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
  const roomy = full || W >= 560;
  const gutter = roomy ? Math.min(longest + 30, W * 0.34) : 0;
  const R = Math.max(40, Math.min((W - gutter) / 2 - 14, H / 2 - 14));
  const cx = gutter + (W - gutter) / 2, cy = H / 2;
  const minHole = 16;
  const avail = Math.max(24, R - minHole);
  const GAP_RATIO = 0.38;
  let thick = Math.min(26, avail / (n + (n - 1) * GAP_RATIO));
  thick = Math.max(4, thick);
  let gap = Math.max(2, thick * GAP_RATIO);
  const total = n * thick + (n - 1) * gap;
  if (total > avail) { const k = avail / total; thick *= k; gap *= k; }
  const ringR = (i: number) => R - thick / 2 - i * (thick + gap);
  return { cx, cy, R, thick, gap, ringR, n, roomy };
}

const funnelLabel = (x: ChartDatum, total: number) => `${x.label} · ${x.value} (${Math.round((x.value / total) * 100)}%)`;
function funnelGeom(W: number, H: number, m: number, data: ChartDatum[], full: boolean, pyramid = false) {
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const longest = Math.max(0, ...data.map((x) => approxW(funnelLabel(x, total))));
  const labelSpace = full ? longest + 40 : Math.min(160, W * 0.3);
  const padT = 16, padB = 16;
  // the visual envelope is identical in 2D and 3D — the 3D body shrinks to
  // make room for its elliptical caps instead of growing past it
  const env = Math.min(H - padT - padB, W * 0.62);
  const sq = 0.16 * m;
  const ch = env / (1 + 1.2 * sq);
  // the 3D pyramid's side face extends 20 % of the base width to the right;
  // reserve that room so the leader lane always clears it
  const side = pyramid ? 0.2 * 0.96 * m : 0;
  const plotW = Math.min((W - labelSpace - 60) / (1 + side / 2), ch * 1.15);
  const capTop = (plotW / 2) * sq;
  const topY = padT + (H - padT - padB - env) / 2 + capTop;
  const cx = (W - labelSpace) / 2 + 10 - (plotW * side) / 4;
  // x where every leader turns towards its label: just right of the widest point
  const laneX = cx + (plotW / 2) * 0.96 + plotW * side + 14;
  return { total, labelSpace, ch, plotW, sq, topY, cx, capTop, laneX };
}

/* ================= leader labels — curved arrows attached ON the rim ================= */
function drawLeaders(ctx: Ctx, cx: number, cy: number, R: number, squash: number, data: ChartDatum[], colors: string[], total: number, t: Theme, W: number, H: number, equalAngles = false, full = false) {
  ctx.font = font(t, 600, full ? 13 : 12);
  const n = data.length;
  let a = -Math.PI / 2;
  interface E { i: number; mid: number; right: boolean; y: number }
  const entries: E[] = data.map((d, i) => {
    let mid: number;
    if (equalAngles) mid = -Math.PI / 2 + ((i + 0.5) * Math.PI * 2) / n;
    else { const a2 = a + (d.value / total) * Math.PI * 2; mid = (a + a2) / 2; a = a2; }
    return { i, mid, right: Math.cos(mid) >= 0, y: cy + Math.sin(mid) * (R + 20) * squash };
  });
  const place = (list: E[]) => {
    list.sort((p, q) => p.y - q.y);
    let prev = -Infinity;
    list.forEach((e) => { e.y = Math.max(e.y, prev + 18); prev = e.y; });
    list.forEach((e) => { e.y = Math.max(12, Math.min(H - 8, e.y)); });
  };
  place(entries.filter((e) => e.right));
  place(entries.filter((e) => !e.right));

  entries.forEach((e) => {
    const d = data[e.i];
    const ax = cx + Math.cos(e.mid) * R;
    const ay = cy + Math.sin(e.mid) * R * squash;
    const qx = cx + Math.cos(e.mid) * (R + 18);
    const qy = cy + Math.sin(e.mid) * (R + 18) * squash;
    const ex = cx + (e.right ? R + 26 : -(R + 26));
    const tx = cx + (e.right ? R + 34 : -(R + 34));
    const c1x = (ex + qx) / 2, c1y = e.y;
    const c2x = qx, c2y = qy;
    // end tangent (anchor − c2) → arrow direction
    const dx = ax - c2x, dy = ay - c2y;
    const dl = Math.hypot(dx, dy) || 1;
    const ux = dx / dl, uy = dy / dl;
    const px2 = -uy, py2 = ux;
    // the curve stops where the arrowhead begins so nothing overdraws the head
    const bx = ax - ux * 8, by = ay - uy * 8;
    ctx.strokeStyle = colors[e.i];
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(tx, e.y);
    ctx.lineTo(ex, e.y);
    ctx.bezierCurveTo(c1x, c1y, c2x, c2y, bx, by);
    ctx.stroke();
    // arrowhead: tip sits ON the rim, outlined so it reads cleanly against any background
    ctx.fillStyle = colors[e.i];
    ctx.beginPath();
    ctx.moveTo(ax + ux * 0.5, ay + uy * 0.5);
    ctx.lineTo(bx - ux * 1.2 + px2 * 4.2, by - uy * 1.2 + py2 * 4.2);
    ctx.lineTo(bx - ux * 1.2 - px2 * 4.2, by - uy * 1.2 - py2 * 4.2);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.lineJoin = 'round';
    ctx.stroke();
    ctx.lineJoin = 'miter';
    // label — larger font (12px / 13px), clear legible text
    const avail = e.right ? W - tx - 8 : tx - 8;
    ctx.fillStyle = t.ink;
    ctx.textAlign = e.right ? 'left' : 'right';
    const text = leaderLabel(d, total);
    ctx.fillText(full ? text : fitCtx(ctx, text, avail), tx + (e.right ? 4 : -4), e.y + 4);
  });
  ctx.textAlign = 'left';
}

/* ================= axes ================= */
function drawAxes(ctx: Ctx, W: number, H: number, pad: { l: number; r: number; t: number; b: number }, max: number, t: Theme, ox = 0, oy = 0) {
  const ch = H - pad.t - pad.b;
  ctx.font = font(t, 600, 10.5);
  for (let g = 0; g <= 4; g++) {
    const y = pad.t + ch - (ch * g) / 4;
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    ctx.beginPath();
    if (ox) { ctx.moveTo(pad.l, y); ctx.lineTo(pad.l + ox, y - oy); ctx.lineTo(W - pad.r + ox, y - oy); }
    else { ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); }
    ctx.stroke();
    ctx.fillStyle = t.axis; ctx.textAlign = 'right';
    ctx.fillText(fmtNum((max * g) / 4), pad.l - 7, y + 3.5);
  }
  ctx.strokeStyle = t.axis; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(pad.l, pad.t - 4); ctx.lineTo(pad.l, pad.t + ch); ctx.lineTo(W - pad.r, pad.t + ch); ctx.stroke();
  ctx.lineWidth = 1;
  ctx.textAlign = 'left';
}

/* ================= streamgraph model + geometry (Highcharts-style) =================
   Layers stack with an inside-out order (largest centred) over a smoothed
   silhouette baseline, drawn with freehand-smooth Catmull-Rom boundaries.
   Shared verbatim by the painter and the hit tester so hover always matches. */
export interface StreamLayer { name: string; color: string; values: number[] }
export interface StreamGeom {
  list: StreamLayer[]; labels: string[]; xs: number[];
  /** bound[k][j]: px y of the k-th stack boundary (0 = bottom) at column j */
  bound: number[][]; order: number[]; posOf: number[];
  padT: number; padB: number; plotW: number; plotH: number; midY: number;
  plan: XPlan;
  /** per-column totals (raw, unsmoothed) — for markers + hit % */
  totals: number[];
}
/** Canonical 10-year salary-story demo (Highcharts-style streamgraph):
 * TEN yearly salary layers (₹L p.a. salary mass per cohort) telling the
 * company's decade: joiners, exits, rejoiners, a layoff year (2021), a bonus
 * year (2023) and contract hiring (2025). Cohorts:
 *  Founders         — here all 10 years, steady compounding rises;
 *  Eng Early        — 2016 crew, fast early raises, some leave in 2021;
 *  Eng Growth       — joins 2018 hiring wave, fastest raises of anyone;
 *  Sales Core       — joins 2017, dips in the layoff, rebounds on bonus;
 *  Support          — joins 2017, flat middle years, exits partly in 2024;
 *  Marketing        — joins 2019, cut HARD in the 2021 layoff, regrows;
 *  People Ops       — joins 2018, slow-and-steady, never leaves;
 *  Finance          — joins 2018, steady, small bonus-year bump;
 *  Boomerangs       — leave in 2020–21, REJOIN in 2022 (zero middle years);
 *  Contract Flex    — contract hiring: bursts in 2020 and 2025, zero between.
 * Used as the honest built-in demo whenever no series data is supplied. */
export const STREAM_SALARY_10Y = {
  labels: ['2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
  layers: [
    { name: 'Founders', color: '#0d7a54', values: [46, 52, 60, 68, 76, 72, 80, 96, 102, 110] },
    { name: 'Eng Early', color: '#1e5aa8', values: [74, 104, 138, 172, 198, 158, 178, 226, 240, 258] },
    { name: 'Eng Growth', color: '#0ea5e9', values: [0, 0, 52, 92, 128, 112, 152, 214, 246, 288] },
    { name: 'Sales Core', color: '#c9932b', values: [0, 58, 82, 108, 122, 92, 116, 156, 168, 186] },
    { name: 'Support', color: '#14b8a6', values: [0, 34, 48, 62, 74, 58, 68, 82, 70, 76] },
    { name: 'Marketing', color: '#e11d63', values: [0, 0, 0, 56, 62, 28, 48, 84, 92, 104] },
    { name: 'People Ops', color: '#84cc16', values: [0, 0, 30, 38, 46, 42, 50, 62, 68, 74] },
    { name: 'Finance', color: '#64748b', values: [0, 0, 26, 32, 38, 34, 40, 50, 56, 60] },
    { name: 'Boomerangs', color: '#f97316', values: [26, 34, 30, 26, 12, 0, 22, 42, 48, 54] },
    { name: 'Contract Flex', color: '#a16207', values: [0, 0, 0, 0, 44, 18, 0, 0, 26, 58] },
  ],
  events: [
    { at: 1, label: 'Sales + Support join', detail: 'GTM founded' },
    { at: 2, label: 'Hiring wave', detail: '60+ joiners' },
    { at: 5, label: 'Layoff period', detail: '-18% salary base' },
    { at: 6, label: 'Boomerangs return', detail: 'Rejoiners + growth' },
    { at: 7, label: 'Bonus year', detail: '+24% payouts' },
    { at: 9, label: 'Contract hiring', detail: 'Flex workforce' },
  ] as StreamEvent[],
};
export function streamGeom(
  multi: boolean, cats: string[], series: StackedSeries[], sColors: string[],
  data: ChartDatum[], colors: string[], pal: string[],
  W: number, H: number, full: boolean,
): StreamGeom | null {
  let list: StreamLayer[] = [];
  let labels: string[] = [];
  if (multi && series.length && cats.length >= 2) {
    labels = cats;
    list = series.map((s, i) => ({
      name: s.name, color: s.color || sColors[i] || pal[i % pal.length],
      values: cats.map((_, j) => s.values[j] || 0),
    }));
  } else {
    // Honest built-in demo: the 10-year salary story (not a meander hack).
    // Layer colours resolve through the live palette when the demo's own
    // colours are absent so theme switching still works.
    labels = STREAM_SALARY_10Y.labels.slice();
    list = STREAM_SALARY_10Y.layers.map((l, i) => ({
      name: l.name, color: l.color || colors[i] || pal[i % pal.length], values: l.values.slice(),
    }));
    void data;
  }
  const n = labels.length;
  const padT = 46, padL = 14, padR = 14;
  const plotW = W - padL - padR;
  const xs = labels.map((_, j) => padL + (plotW * j) / Math.max(1, n - 1));
  const stepS = n > 1 ? plotW / (n - 1) : plotW;
  const plan = planX(labels, stepS, full);
  const padB = plan.padB;
  const plotH = Math.max(40, H - padT - padB);
  const midY = padT + plotH / 2;
  const totals = list.map((l) => l.values.reduce((a, b) => a + b, 0));
  // Onset order (Highcharts streamgraph): layers ordered by the column
  // where they FIRST become non-zero (ties → larger total first), then
  // inside-out around the centre. New joiners / rejoiners therefore enter
  // at the river's edge instead of tearing through the middle.
  const onset = list.map((l) => {
    const j = l.values.findIndex((v) => (v || 0) > 0);
    return j < 0 ? n : j;
  });
  const desc = list.map((_, i) => i).sort((a, b) => (onset[a] - onset[b]) || (totals[b] - totals[a]));
  const order: number[] = [];
  desc.forEach((si, k) => { if (k % 2 === 0) order.push(si); else order.unshift(si); });
  const S = labels.map((_, j) => list.reduce((a, l) => a + (l.values[j] || 0), 0));
  const maxS = Math.max(...S, 1);
  // ThemeRiver-style symmetric baseline: the smoothed silhouette centres on
  // midY (zero pinch at all-zero columns), so layers breathe like the
  // reference instead of shearing diagonally.
  const sm = S.map((s, j) => {
    if (s <= 0) return 0;
    let a = 0, c = 0;
    for (let k = -2; k <= 2; k++) { const jj = j + k; if (jj >= 0 && jj < n && S[jj] > 0) { a += S[jj]; c++; } }
    const avg = c ? a / c : s;
    return avg * 0.55 + s * 0.45;
  });
  const scaleY = plotH / (maxS * 1.06);
  const Y = (v: number) => midY - v * scaleY;
  const bound: number[][] = [];
  const acc = sm.map((s) => -s / 2);
  bound.push(acc.map(Y));
  order.forEach((si) => {
    for (let j = 0; j < n; j++) acc[j] += list[si].values[j] || 0;
    bound.push(acc.map(Y));
  });
  // Organic flow (reference look): smooth every stacked boundary so BOTH
  // edges of each band breathe smoothly even when raw column totals jump.
  // True-zero columns are re-pinched afterwards (gap years shut the river).
  for (let pass = 0; pass < 2; pass++) {
    bound.forEach((b) => {
      const c = b.slice();
      for (let j = 1; j < n - 1; j++) b[j] = (c[j - 1] + c[j] * 2 + c[j + 1]) / 4;
    });
  }
  for (let j = 0; j < n; j++) {
    if (S[j] <= 0) bound.forEach((b) => { b[j] = midY; });
  }
  // Rounded silhouette noses: taper the outer two columns toward midY.
  if (n > 3) {
    bound.forEach((b) => {
      b[0] = midY + (b[0] - midY) * 0.10;
      b[1] = midY + (b[1] - midY) * 0.45;
      b[n - 1] = midY + (b[n - 1] - midY) * 0.10;
      b[n - 2] = midY + (b[n - 2] - midY) * 0.45;
    });
  }
  const posOf = new Array(list.length).fill(0);
  order.forEach((si, k) => { posOf[si] = k; });
  return { list, labels, xs, bound, order, posOf, padT, padB, plotW, plotH, midY, plan, totals: S.slice() };
}

/* ================= hover model ================= */
interface Hover { idx: number | null; seg: { c: number; s: number } | null; amt: number }
const NO_HOVER: Hover = { idx: null, seg: null, amt: 0 };

export interface DrawCtx {
  W: number; H: number; t: Theme; p: number; m: number; hov: Hover;
  data: ChartDatum[]; colors: string[];
  multi: boolean; cats: string[]; series: StackedSeries[]; sColors: string[];
  yLabel?: string;
  /** fullscreen / export — labels are never truncated */
  full?: boolean;
  /** opaque background (exports) — otherwise the frame is cleared to transparent */
  bg?: string;
  /** calendar-pie input (series names come from `series`) */
  days?: CalendarDay[];
  /** sankey input */
  links?: SankeyLink[];
  /** gantt input */
  tasks?: GanttTask[];
  /** scatter input */
  scatter?: ScatterPoint[];
  /** camera orbit for rotatable true-3D scenes (Sankey 3D) */
  orbit?: Orbit3D;
  /** streamgraph event flags (Highcharts-style special-event labels) */
  streamEvents?: StreamEvent[];
}

/* ================= unified painter (m = 3D morph 0..1) ================= */
export function paintChart(ctx: Ctx, kind: ChartKind, d: DrawCtx) {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  if (d.bg) { ctx.fillStyle = d.bg; ctx.fillRect(0, 0, W, H); } else ctx.clearRect(0, 0, W, H);
  // OPTIMIZATION + STALE-TILE FIX: `radialbar` renders through its own
  // dedicated Three.js overlay (ThreeReferenceRadialBar) — this 2D canvas
  // is hidden (opacity 0) whenever it's active. With no explicit guard
  // here, kind==='radialbar' used to fall through EVERY unmatched `if`
  // block all the way to the generic pie/donut painter at the bottom of
  // this function, which then wastefully redrew a whole pie chart from
  // the radial-bar dataset on every hidden frame for nothing. Bailing out
  // immediately (after the clear above, so the hidden canvas is at least
  // blank rather than a stale pie) removes that wasted CPU/GPU work.
  if (kind === 'radialbar') return;
  if (!data.length && !(multi && cats.length) && kind !== 'calendarpie' && kind !== 'sankey' && kind !== 'gantt' && kind !== 'scatter' && kind !== 'stream') return;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;

  /* ============ BAR ============ */
  if (kind === 'bar') {
    const labels = multi ? cats : data.map((x) => x.label);
    const max = multi
      ? Math.max(...cats.map((_, c) => series.reduce((s, sr) => s + (sr.values[c] || 0), 0)), 1)
      : Math.max(...data.map((x) => x.value), 1);
    const L = xyLayout('bar', W, H, m, labels, 1, max, !!d.yLabel, full);
    const { pad, ch, step, ox, oy } = L;
    drawAxes(ctx, W, H, pad, max, t, ox, oy);
    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2 + ox / 2, pad.t + ch, t, W);

    labels.forEach((_, ci) => {
      const bw = Math.min(44, step * 0.52);
      const x = pad.l + step * ci + (step - bw) / 2;
      const segs = multi
        ? series.map((sr, si) => ({ v: sr.values[ci] || 0, col: sColors[si], on: !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === si) }))
        : [{ v: data[ci].value, col: colors[ci], on: hov.idx === ci }];
      let acc = 0;
      segs.forEach((sg, si) => {
        if (sg.v <= 0) return;
        const h = (sg.v / max) * ch * p;
        const yTop = pad.t + ch - ((acc / max) * ch * p) - h;
        const col = sg.on ? shade(sg.col, 1 + 0.16 * hov.amt) : sg.col;
        if (m > 0.02) {
          ctx.fillStyle = shade(sg.col, 0.7 * (sg.on ? 1 + 0.1 * hov.amt : 1));
          ctx.beginPath(); ctx.moveTo(x + bw, yTop); ctx.lineTo(x + bw + ox, yTop - oy);
          ctx.lineTo(x + bw + ox, yTop - oy + h); ctx.lineTo(x + bw, yTop + h); ctx.closePath(); ctx.fill();
          const isTop = si === segs.length - 1 || segs.slice(si + 1).every((z) => z.v <= 0);
          if (isTop) {
            ctx.fillStyle = shade(sg.col, 1.22);
            ctx.beginPath(); ctx.moveTo(x, yTop); ctx.lineTo(x + ox, yTop - oy);
            ctx.lineTo(x + bw + ox, yTop - oy); ctx.lineTo(x + bw, yTop); ctx.closePath(); ctx.fill();
          }
          ctx.fillStyle = col;
          ctx.fillRect(x, yTop, bw, h);
        } else {
          ctx.fillStyle = col;
          ctx.beginPath(); ctx.roundRect(x, yTop, bw, Math.max(1, h - (multi ? 1 : 0)), multi ? 2 : [6, 6, 0, 0]); ctx.fill();
        }
        acc += sg.v;
      });
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ LINE & AREA (2D + true 3D) ============ */
  if (kind === 'line' || kind === 'area') {
    const list: { name: string; color: string; values: number[] }[] = multi
      ? series.map((s, i) => ({ name: s.name, color: sColors[i], values: s.values }))
      : [{ name: '', color: colors[0], values: data.map((x) => x.value) }];
    const nD = list.length;
    // smaller series sit in FRONT, larger ones recede — nothing gets hidden
    const depth = multi ? seriesDepth(series) : [0];
    const zx = ZX * m, zy = ZY * m, dz = DZ * m, dzy = DZY * m;
    const labels = multi ? cats : data.map((x) => x.label);
    const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
    const L = xyLayout(kind, W, H, m, labels, nD, max, !!d.yLabel, full);
    const { pad, ch, step, ox, oy } = L;
    drawAxes(ctx, W, H, pad, max, t, ox, oy);
    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);

    const isArea = kind === 'area';
    const order = list.map((_, i) => i).sort((a, b) => depth[b] - depth[a]); // back → front
    for (const si of order) {
      const sr = list[si];
      const offX = zx * depth[si], offY = zy * depth[si];
      const baseY = pad.t + ch - offY;
      const pts = sr.values.map((v, i) => ({
        x: pad.l + step * i + step / 2 + offX,
        y: pad.t + ch - (v / max) * ch * p - offY,
      }));
      if (!pts.length) continue;

      // Smooth freehand curve through the points (Catmull-Rom → Bézier), the
      // SAME path builder used in 2D and 3D so the morph never kinks.
      const curve = (offX = 0, offY = 0) => {
        ctx.moveTo(pts[0].x + offX, pts[0].y + offY);
        if (pts.length === 2) { ctx.lineTo(pts[1].x + offX, pts[1].y + offY); return; }
        for (let i = 0; i < pts.length - 1; i++) {
          const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
          ctx.bezierCurveTo(
            p1.x + offX + (p2.x - p0.x) / 6, p1.y + offY + (p2.y - p0.y) / 6,
            p2.x + offX - (p3.x - p1.x) / 6, p2.y + offY - (p3.y - p1.y) / 6, p2.x + offX, p2.y + offY);
        }
      };
      // Reversed curve back along the same points — closes area bands and
      // ribbon walls without seams.
      const curveBack = (offX = 0, offY = 0) => {
        if (pts.length === 2) { ctx.lineTo(pts[0].x + offX, pts[0].y + offY); return; }
        for (let i = pts.length - 1; i > 0; i--) {
          const p0 = pts[Math.min(pts.length - 1, i + 1)], p1 = pts[i], p2 = pts[i - 1], p3 = pts[Math.max(0, i - 2)];
          ctx.bezierCurveTo(
            p1.x + offX + (p2.x - p0.x) / 6, p1.y + offY + (p2.y - p0.y) / 6,
            p2.x + offX - (p3.x - p1.x) / 6, p2.y + offY - (p3.y - p1.y) / 6, p2.x + offX, p2.y + offY);
        }
      };
      if (m > 0.02) {
        // TRUE 3D for BOTH line and area: the series floats as a smooth
        // ribbon above a soft floor shadow; the area adds a translucent
        // curtain down to the floor so depth reads at a glance.
        const lift = 10 * m + depth[si] * 3 * m;
        // floor shadow — same freehand silhouette, blurred onto the floor
        ctx.save();
        setShadow(ctx, 0, 6 * m + 3, 10, rgba(t.ink, 0.20 * m));
        ctx.fillStyle = rgba(t.ink, 0.10 * m);
        ctx.beginPath();
        curve(dz, lift - dzy + 6 * m);
        if (isArea) { ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy + 6 * m); ctx.lineTo(pts[0].x + dz, baseY - dzy + 6 * m); }
        ctx.closePath(); ctx.fill();
        ctx.restore();
        // back wall: the freehand curve swept through the depth vector —
        // front curve out, back curve reversed: a seamless smooth band
        ctx.fillStyle = shade(sr.color, isArea ? 0.62 : 0.78);
        ctx.beginPath();
        curve(0, 0);
        ctx.lineTo(pts[pts.length - 1].x + dz, pts[pts.length - 1].y - dzy);
        curveBack(dz, -dzy);
        ctx.closePath(); ctx.fill();
        if (isArea) {
          // back curtain (floor to curve, at depth) then front curtain
          ctx.fillStyle = shade(sr.color, 0.55);
          ctx.beginPath();
          curve(dz, -dzy);
          ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy);
          ctx.lineTo(pts[0].x + dz, baseY - dzy);
          ctx.closePath(); ctx.fill();
          const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ch);
          grad.addColorStop(0, withAlpha(sr.color, multi ? '66' : '7a'));
          grad.addColorStop(1, withAlpha(sr.color, '14'));
          ctx.fillStyle = grad;
          ctx.beginPath();
          curve(0, 0);
          ctx.lineTo(pts[pts.length - 1].x, baseY); ctx.lineTo(pts[0].x, baseY);
          ctx.closePath(); ctx.fill();
        } else {
          // line 3D: translucent floor curtain in the brand color
          ctx.fillStyle = withAlpha(sr.color, '26');
          ctx.beginPath();
          curve(dz, -dzy);
          ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy);
          ctx.lineTo(pts[0].x + dz, baseY - dzy);
          ctx.closePath(); ctx.fill();
        }
        // glowing freehand crest on top
        ctx.save();
        setShadow(ctx, 0, 0, 6 * m, rgba(sr.color, 0.55 * m));
        ctx.strokeStyle = shade(sr.color, 1.18); ctx.lineWidth = isArea ? 2.2 : 2.8; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        ctx.beginPath(); curve(0, 0); ctx.stroke();
        ctx.restore();
        // end cap seals the ribbon at the last point
        ctx.fillStyle = shade(sr.color, 0.6);
        ctx.beginPath();
        ctx.moveTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
        ctx.lineTo(pts[pts.length - 1].x + dz, pts[pts.length - 1].y - dzy);
        ctx.lineTo(pts[pts.length - 1].x + dz, (isArea ? baseY : pts[pts.length - 1].y + 2) - dzy);
        ctx.lineTo(pts[pts.length - 1].x, isArea ? baseY : pts[pts.length - 1].y + 2);
        ctx.closePath(); ctx.fill();
        // markers float on the crest
        const dense = step < 14;
        pts.forEach((pt, i) => {
          const on = multi ? (hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === si) : hov.idx === i;
          if (dense && !on) return;
          ctx.save();
          setShadow(ctx, 0, 2, 4, rgba(t.ink, 0.3 * m));
          ctx.fillStyle = on ? shade(sr.color, 1 + 0.2 * hov.amt) : shade(sr.color, 1.1);
          ctx.beginPath(); ctx.arc(pt.x, pt.y, (step < 26 ? 3 : 4) + (on ? 2.5 * hov.amt : 0), 0, Math.PI * 2); ctx.fill();
          ctx.restore();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
        });
      } else {
        if (isArea) {
          ctx.beginPath(); curve();
          ctx.lineTo(pts[pts.length - 1].x, baseY); ctx.lineTo(pts[0].x, baseY); ctx.closePath();
          const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ch);
          grad.addColorStop(0, withAlpha(sr.color, multi ? '3d' : '59'));
          grad.addColorStop(1, withAlpha(sr.color, '08'));
          ctx.fillStyle = grad; ctx.fill();
          ctx.strokeStyle = sr.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
          ctx.beginPath(); curve(); ctx.stroke();
        } else {
          ctx.strokeStyle = sr.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
          ctx.beginPath(); curve(); ctx.stroke();
        }
        // markers thin out automatically when points get dense
        const dense = step < 14;
        pts.forEach((pt, i) => {
          const on = multi ? (hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === si) : hov.idx === i;
          if (dense && !on) return;
          ctx.fillStyle = on ? shade(sr.color, 1 + 0.2 * hov.amt) : sr.color;
          ctx.beginPath(); ctx.arc(pt.x, pt.y, (step < 26 ? 3 : 4) + (on ? 2.5 * hov.amt : 0), 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
        });
      }
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ RADAR (2D + TRUE 3D: distance-from-centre at every morph step) ============
     A radar chart ALWAYS encodes value as distance from the centre — in 2D
     and in 3D. The 3D here is the SAME flat polygon, continuously tilted
     (squash), extruded (slab walls under the filled polygon) and shaded,
     so the 2D→3D morph never changes what the values mean. */
  if (kind === 'radar') {
    /* ============ RADAR — sticks + thread, no fill volume ============
       The chart shows ONLY vertical sticks (one per axis, height =
       value) and the thread polygon connecting the stick tips. There is
       deliberately NO filled area and NO extruded slab — in 2D or 3D.
       2D→3D is a pure camera tilt: the SAME vertex math (angle i, radius
       v/max·R) is projected through an oblique view whose pitch grows
       with m, plus stick verticals so height reads in 3D. Vertices
       never move off their data radius at any morph step. */
    const labels = multi ? cats : data.map((x) => x.label);
    const longest = Math.max(0, ...labels.map((l) => approxW(l)));
    const margin = full ? Math.min(W * 0.4, longest + 24) : 44;
    const cx = W / 2, cy = H / 2 + 6;
    const squash = 1 - 0.52 * m;
    const Rflat = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30) / Math.max(0.45, squash)));
    const depth = Math.min(46, Math.max(12, Rflat * 0.24)) * m;
    const R = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30 - depth) / Math.max(0.45, squash)));
    const n = Math.max(1, labels.length);
    const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
    const ang = (i: number) => -Math.PI / 2 + (i * Math.PI * 2) / n;
    // ONE projection for every element at every morph step: disc point +
    // vertical stick height h (in px). 2D: h collapses (sticks are dots);
    // 3D: h lifts tips toward the viewer-tilted plane. The disc itself is
    // identical in 2D and 3D, so 2D→3D never re-plots the data.
    const P = (a: number, r: number, h = 0) => ({
      x: cx + Math.cos(a) * r,
      y: cy + Math.sin(a) * r * squash - h,
    });

    // ---- floor shadow of the web (3D only) ----
    if (m > 0.02) {
      ctx.save();
      setShadow(ctx, 0, 9 * m + 2, 18, rgba(t.ink, 0.20 * m));
      ctx.fillStyle = rgba(t.ink, 0.08 * m);
      ctx.beginPath();
      for (let i = 0; i <= n; i++) {
        const q = P(ang(i % n), R);
        i === 0 ? ctx.moveTo(q.x, q.y + depth * 0.4) : ctx.lineTo(q.x, q.y + depth * 0.4);
      }
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    // ---- web rings (tilted ellipses in 3D) ----
    for (let ring = 1; ring <= 3; ring++) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i <= n; i++) {
        const q = P(ang(i % n), (R * ring) / 3);
        i === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y);
      }
      ctx.stroke();
    }
    ctx.font = font(t, 600, 10.5);
    labels.forEach((l, i) => {
      const aa = ang(i);
      const q = P(aa, R);
      ctx.strokeStyle = t.grid;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(q.x, q.y); ctx.stroke();
      ctx.fillStyle = t.axis;
      ctx.textAlign = Math.abs(Math.cos(aa)) < 0.3 ? 'center' : Math.cos(aa) > 0 ? 'left' : 'right';
      const lx = cx + Math.cos(aa) * (R + 12);
      const avail = Math.abs(Math.cos(aa)) < 0.3 ? W - 8 : Math.cos(aa) > 0 ? W - lx - 4 : lx - 4;
      ctx.fillText(full ? l : fitCtx(ctx, l, Math.max(30, avail)), lx, cy + Math.sin(aa) * (R + 12) * squash + 3);
    });
    const polys = multi
      ? series.map((s, i) => ({ color: sColors[i], values: s.values }))
      : [{ color: colors[0], values: data.map((x) => x.value) }];
    // Stick height: value-proportional lift in 3D only (0 in 2D), so the
    // tips rise off the disc while the disc footprint stays data-true.
    const stickH = (pi: number, i: number) => {
      const v = (polys[pi].values[i % n] || 0) / max;
      return v * depth * p;
    };
    const vert = (pi: number, i: number) => {
      const v = (polys[pi].values[i % n] || 0) / max;
      return P(ang(i % n), v * R * p, stickH(pi, i));
    };
    const foot = (pi: number, i: number) => {
      const v = (polys[pi].values[i % n] || 0) / max;
      return P(ang(i % n), v * R * p, 0);
    };
    const traceThread = (pi: number) => {
      for (let i = 0; i <= n; i++) {
        const q = vert(pi, i);
        i === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y);
      }
      ctx.closePath();
    };
    // ---- sticks: shaded verticals from disc foot to tip (3D), dots (2D) ----
    polys.forEach((poly, pi) => {
      const onS = multi && hov.seg?.s === pi;
      const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= sDim;
      for (let i = 0; i < n; i++) {
        const f = foot(pi, i), v = vert(pi, i);
        if (m > 0.02 && v.y < f.y - 0.5) {
          // stick: dark foot → bright tip, width tapers with light
          const sg = ctx.createLinearGradient(0, f.y, 0, v.y);
          sg.addColorStop(0, shade(poly.color, 0.55));
          sg.addColorStop(1, onS ? shade(poly.color, 1.2 + 0.1 * hov.amt) : shade(poly.color, 1.05));
          ctx.strokeStyle = sg;
          ctx.lineWidth = 3;
          ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(v.x, v.y); ctx.stroke();
          ctx.lineCap = 'butt';
          // foot dot on the disc
          ctx.fillStyle = shade(poly.color, 0.8);
          ctx.beginPath(); ctx.arc(f.x, f.y, 2.2, 0, Math.PI * 2); ctx.fill();
        }
      }
      ctx.restore();
      void pi;
    });
    // ---- thread: the connecting polygon through the stick tips ----
    polys.forEach((poly, pi) => {
      const onS = multi && hov.seg?.s === pi;
      const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= sDim;
      ctx.beginPath();
      traceThread(pi);
      ctx.strokeStyle = onS ? shade(poly.color, 1.15) : poly.color;
      ctx.lineWidth = (onS ? 2.6 : 2) + m * 0.6;
      ctx.lineJoin = 'round';
      if (m > 0.02) {
        ctx.save();
        ctx.shadowColor = rgba(poly.color, 0.45 * m);
        ctx.shadowBlur = 6;
        ctx.stroke();
        ctx.restore();
      } else {
        ctx.stroke();
      }
      ctx.restore();
    });
    // ---- tip knots: glossy spheres on every stick tip ----
    polys.forEach((poly, pi) => {
      const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= sDim;
      for (let i = 0; i < n; i++) {
        const q = vert(pi, i);
        const on = !multi && hov.idx === i;
        const rr = 3.4 + m * 1.2 + (on ? 2 * hov.amt : 0);
        const kg = ctx.createRadialGradient(q.x - rr * 0.3, q.y - rr * 0.35, rr * 0.1, q.x, q.y, rr);
        kg.addColorStop(0, '#ffffff');
        kg.addColorStop(0.4, shade(poly.color, 1.2));
        kg.addColorStop(1, shade(poly.color, 0.7));
        ctx.fillStyle = kg;
        ctx.beginPath(); ctx.arc(q.x, q.y, rr, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
      }
      ctx.restore();
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ POLAR (2D ⇄ 3D) ============ */
  if (kind === 'polar') {
    const g = circGeom(W, H, m, data, full);
    const cx = g.cx, cy = g.cy, R = g.R;
    const squash = 1 - 0.44 * m;
    const depth = 16 * m;
    const max = Math.max(...data.map((x) => x.value), 1);

    if (m > 0.05) {
      ctx.save();
      setShadow(ctx, 0, 8, 20, rgba(t.ink, 0.22 * m));
      ctx.fillStyle = t.surface || '#e4e7e0';
      ctx.beginPath();
      ctx.ellipse(cx, cy + depth, R, R * squash, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    for (let ring = 1; ring <= 3; ring++) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(cx, cy, R * (ring / 3), R * (ring / 3) * squash, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    const n = Math.max(1, data.length);
    const pieces = data.map((x, i) => {
      const a0 = -Math.PI / 2 + (i * Math.PI * 2) / n;
      const a1 = a0 + (Math.PI * 2) / n;
      const offset = radialOffset((a0 + a1) / 2, hov.idx === i ? 14 * hov.amt : 0, squash);
      return { i, a0, a1, r: Math.max(2, (x.value / max) * R * p), dx: offset.x, dy: offset.y };
    });
    // Closed opaque prisms. All faces move together in the chart plane, never upward in Z.
    const faces: { y: number; draw: () => void }[] = [];
    pieces.forEach(({ i, a0, a1, r, dx, dy }) => {
      if (m <= 0.005) return;
      const x = (a: number) => cx + dx + Math.cos(a) * r;
      const y = (a: number) => cy + dy + Math.sin(a) * r * squash;
      [a0, a1].forEach(edge => faces.push({
        y: cy + dy + Math.sin(edge) * r * squash / 2,
        draw: () => {
          ctx.fillStyle = shade(colors[i], 0.72);
          ctx.beginPath(); ctx.moveTo(cx + dx, cy + dy); ctx.lineTo(x(edge), y(edge));
          ctx.lineTo(x(edge), y(edge) + depth); ctx.lineTo(cx + dx, cy + dy + depth);
          ctx.closePath(); ctx.fill();
        },
      }));
      const count = Math.max(3, Math.ceil((a1 - a0) * r / 6));
      for (let step = 0; step < count; step++) {
        const b0 = a0 + (a1 - a0) * step / count;
        const b1 = a0 + (a1 - a0) * (step + 1) / count;
        const mid = (b0 + b1) / 2;
        if (Math.sin(mid) <= 0) continue;
        faces.push({ y: y(mid), draw: () => {
          ctx.fillStyle = shade(colors[i], 0.64 + 0.16 * Math.cos(mid));
          ctx.beginPath(); ctx.moveTo(x(b0), y(b0)); ctx.lineTo(x(b1), y(b1));
          ctx.lineTo(x(b1), y(b1) + depth); ctx.lineTo(x(b0), y(b0) + depth);
          ctx.closePath(); ctx.fill();
        } });
      }
    });
    faces.sort((a, b) => a.y - b.y).forEach(face => face.draw());
    pieces.forEach(({ i, a0, a1, r, dx, dy }) => {
      ctx.fillStyle = hov.idx === i ? shade(colors[i], 1 + 0.1 * hov.amt) : colors[i];
      ctx.beginPath(); ctx.moveTo(cx + dx, cy + dy);
      ctx.ellipse(cx + dx, cy + dy, r, r * squash, 0, a0, a1);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 0.7; ctx.stroke();
    });
    if (p > 0.95) drawLeaders(ctx, cx, cy, R, squash, data, colors, total, t, W, H, true, full);
    return;
  }

  /* ============ CALENDAR PIE — one mini pie per day (echarts calendar-pie) ============ */
  if (kind === 'calendarpie') {
    const days = d.days || [];
    const names = series.map((x) => x.name);
    if (!days.length || !names.length) return;
    const dates = days.map((x) => new Date(x.date + 'T00:00:00'));
    const first = new Date(Math.min(...dates.map((x) => x.getTime())));
    const monthStart = new Date(first.getFullYear(), first.getMonth(), 1);
    const monthEnd = new Date(first.getFullYear(), first.getMonth() + 1, 0);
    const byDay = new Map(days.map((x) => [x.date, x.values]));
    const padL = 12, padR = 12, padT = 34, padB = 10;
    const cols = 7;
    const leadBlank = (monthStart.getDay() + 6) % 7; // Monday-first grid, like the reference
    const rows = Math.ceil((leadBlank + monthEnd.getDate()) / cols);
    const cell = Math.min((W - padL - padR) / cols, (H - padT - padB) / rows);
    const gx = padL + ((W - padL - padR) - cell * cols) / 2, gy = padT + ((H - padT - padB) - cell * rows) / 2;
    const r = cell * 0.36;
    ctx.font = font(t, 700, Math.min(11, Math.max(8.5, cell * 0.16)));
    ctx.fillStyle = t.ink; ctx.textAlign = 'left';
    ctx.fillText(monthStart.toLocaleDateString('en', { month: 'long', year: 'numeric' }), padL, 18);
    ctx.font = font(t, 700, Math.min(10, Math.max(8, cell * 0.14))); ctx.fillStyle = t.axis; ctx.textAlign = 'center';
    ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].forEach((wd, i) => ctx.fillText(wd, gx + cell * i + cell / 2, gy - 6));
    // grid cells
    for (let dnum = 1; dnum <= monthEnd.getDate(); dnum++) {
      const idx = leadBlank + dnum - 1, c = idx % cols, rw = Math.floor(idx / cols);
      const x0 = gx + c * cell, y0 = gy + rw * cell;
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.rect(x0 + 0.5, y0 + 0.5, cell - 1, cell - 1); ctx.stroke();
      const iso = `${monthStart.getFullYear()}-${String(monthStart.getMonth() + 1).padStart(2, '0')}-${String(dnum).padStart(2, '0')}`;
      const vals = byDay.get(iso);
      ctx.font = font(t, 700, Math.min(10, Math.max(7.5, cell * 0.14))); ctx.fillStyle = vals ? t.ink : t.axis; ctx.textAlign = 'left';
      ctx.fillText(String(dnum), x0 + 4, y0 + Math.min(12, cell * 0.18));
      if (!vals) continue;
      const tot = vals.reduce((a2, b) => a2 + b, 0) || 1;
      const cx0 = x0 + cell / 2, cy0 = y0 + cell / 2 + cell * 0.05;
      const on = hov.seg && hov.seg.c === dnum;
      let a = -Math.PI / 2;
      vals.forEach((v, si) => {
        if (v <= 0) return;
        const a1 = a + (v / tot) * Math.PI * 2 * p;
        const hi = on && hov.seg!.s === si;
        const rr = r * (hi ? 1 + 0.1 * hov.amt : 1);
        ctx.fillStyle = hi ? shade(sColors[si], 1.12) : sColors[si];
        ctx.beginPath(); ctx.moveTo(cx0, cy0); ctx.arc(cx0, cy0, rr, a, a1); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = d.bg || t.surface || '#fff'; ctx.lineWidth = 1.2; ctx.stroke();
        // value labels inside slices when there is room
        if (cell >= 64 && v / tot >= 0.12 && p > 0.95) {
          const mid = (a + a1) / 2;
          ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
          ctx.font = font(t, 700, Math.max(7.5, Math.min(10, r * 0.28)));
          ctx.fillText(fmtNum(v), cx0 + Math.cos(mid) * rr * 0.62, cy0 + Math.sin(mid) * rr * 0.62 + 3);
        }
        a = a1;
      });
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ SANKEY — agon 2D + TRUE rotatable 3D ============ */
  /* ============ SANKEY (Classic · canvas, no Three.js) — ported from
     the agon-agent-cleaned reference build: isometric-offset 2D/3D, node
     hover only (matches the reference exactly) ============ */
  if (kind === 'sankey') {
    const links = (d.links || []).filter((l) => l.value > 0 && l.source !== l.target);
    if (!links.length) return;
    const lay = sankeyLayout(links, W, H, full ? 200 : Math.min(150, W * 0.22));
    if (!lay) return;
    const { nodes, flows, nodeW, cols } = lay;
    const maxCol = Math.max(1, cols - 1);
    const ox = 7 * m, oy = 5 * m; // 3D isometric extrusion offset

    // Hover animation model (mirrors the 3D scene's isolate behaviour):
    //  - hovering a NODE spotlights it + every ribbon touching it;
    //  - hovering a FLOW spotlights that ribbon + its source/target nodes;
    //  - everything else dims. `hov.amt` (eased 0→1 in the Chart shell)
    //    drives the emphasis so the highlight blooms instead of popping.
    const hovFlowIdx = hov.seg && hov.seg.s === -2 ? hov.seg.c : -1;
    const hovNodeIdx = hov.idx;
    const hovActive = hovNodeIdx !== null || hovFlowIdx >= 0;
    const flowEmph = (fi: number, f: SkFlow) => {
      if (!hovActive) return 0;
      if (hovFlowIdx >= 0) return fi === hovFlowIdx ? hov.amt : 0;
      return (hovNodeIdx === f.si || hovNodeIdx === f.ti) ? hov.amt : 0;
    };
    const nodeEmph = (ni: number) => {
      if (!hovActive) return 0;
      if (hovFlowIdx >= 0) {
        const f = flows[hovFlowIdx];
        return f && (ni === f.si || ni === f.ti) ? hov.amt : 0;
      }
      return ni === hovNodeIdx ? hov.amt : 0;
    };
    const glow = (col: string, e: number) => e > 0.01 && hovActive ? shade(col, 1 + 0.28 * e) : col;

    // Sequential left-to-right sweep:
    // 1. Draw nodes per column
    // 2. Flow ribbons sweep outward from left to right along their path vectors
    flows.forEach((f, fi) => {
      const src = nodes[f.si], tgt = nodes[f.ti];
      const emph = flowEmph(fi, f); // 0 … 1 eased emphasis
      const isDimmed = hovActive && emph < 0.01;
      const x0 = src.x + nodeW, x1 = tgt.x;
      const c1 = x0 + (x1 - x0) * 0.5, c2 = x1 - (x1 - x0) * 0.5;
      const yA0 = f.sy0, yA1 = f.sy1, yB0 = f.ty0, yB1 = f.ty1;

      // Sequential progress: left ribbons begin early, right ribbons follow
      const pStart = 0.12 + (src.col / maxCol) * 0.45;
      const pEnd = Math.min(1, pStart + 0.38);
      const fp = clamp01((p - pStart) / (pEnd - pStart));
      if (fp <= 0.001) return;

      // hover bloom: the emphasised ribbon brightens, thickens and lifts
      const lift = emph * 3;
      const alpha = hovActive
        ? (emph > 0.01 ? 0.45 + 0.45 * emph : 0.45 * (1 - 0.78 * hov.amt))
        : 0.45;
      const grad = ctx.createLinearGradient(x0, 0, x1, 0);
      grad.addColorStop(0, rgba(glow(src.color, emph), alpha));
      grad.addColorStop(1, rgba(glow(tgt.color, emph), alpha));

      ctx.save();
      // Sweep outward along path vectors
      if (fp < 0.999) {
        const sweepX = x0 + (x1 - x0) * fp;
        ctx.beginPath();
        ctx.rect(0, 0, sweepX, H);
        ctx.clip();
      }

      // 3D Depth Shadow ribbon underneath in 3D mode
      if (m > 0.05) {
        ctx.fillStyle = rgba(t.ink, (0.08 + 0.14 * emph) * m * (isDimmed ? (1 - 0.7 * hov.amt) : 1));
        ctx.beginPath();
        ctx.moveTo(x0, yA0 + oy - lift * 0.4);
        ctx.bezierCurveTo(c1, yA0 + oy - lift * 0.4, c2, yB0 + oy - lift * 0.4, x1, yB0 + oy - lift * 0.4);
        ctx.lineTo(x1, yB1 + oy - lift * 0.4);
        ctx.bezierCurveTo(c2, yB1 + oy - lift * 0.4, c1, yA1 + oy - lift * 0.4, x0, yA1 + oy - lift * 0.4);
        ctx.closePath();
        ctx.fill();
      }

      // Main flow ribbon
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(x0, yA0 - lift);
      ctx.bezierCurveTo(c1, yA0 - lift, c2, yB0 - lift, x1, yB0 - lift);
      ctx.lineTo(x1, yB1 + lift * 0.6);
      ctx.bezierCurveTo(c2, yB1 + lift * 0.6, c1, yA1 + lift * 0.6, x0, yA1 + lift * 0.6);
      ctx.closePath();
      ctx.fill();

      // Top edge highlight in 3D mode or on hover
      if (emph > 0.01 || m > 0.1) {
        ctx.strokeStyle = emph > 0.01 ? rgba('#ffffff', 0.35 + 0.65 * emph) : 'rgba(255,255,255,0.35)';
        ctx.lineWidth = emph > 0.01 ? 0.8 + 1.2 * emph : 0.8;
        ctx.beginPath();
        ctx.moveTo(x0, yA0 - lift);
        ctx.bezierCurveTo(c1, yA0 - lift, c2, yB0 - lift, x1, yB0 - lift);
        ctx.stroke();
      }

      ctx.restore();
    });

    // Draw nodes sequentially from left to right with 3D cuboid depth
    nodes.forEach((n, i) => {
      const colP = n.col / maxCol;
      const np = clamp01((p - colP * 0.22) / 0.32);
      if (np <= 0.001) return;
      const emph = nodeEmph(i); // 0 … 1 eased emphasis
      const isDimmed = hovActive && emph < 0.01;
      const col = glow(n.color, emph);
      const nh = Math.max(2, n.h * np);
      const ny = n.y + (n.h - nh) / 2;
      // hovered node widens slightly; dimmed nodes fade
      const xW = nodeW + emph * 4;
      const xOff = emph * 2;
      if (isDimmed) ctx.globalAlpha = 1 - 0.62 * hov.amt;

      const nx = n.x - xOff;

      // 3D Cuboid extrusion in 3D mode
      if (m > 0.05) {
        // Top cap
        ctx.fillStyle = shade(col, 1.28);
        ctx.beginPath();
        ctx.moveTo(nx, ny);
        ctx.lineTo(nx + ox, ny - oy);
        ctx.lineTo(nx + xW + ox, ny - oy);
        ctx.lineTo(nx + xW, ny);
        ctx.closePath();
        ctx.fill();

        // Right side shadow face
        ctx.fillStyle = shade(col, 0.72);
        ctx.beginPath();
        ctx.moveTo(nx + xW, ny);
        ctx.lineTo(nx + xW + ox, ny - oy);
        ctx.lineTo(nx + xW + ox, ny + nh - oy);
        ctx.lineTo(nx + xW, ny + nh);
        ctx.closePath();
        ctx.fill();
      }

      // Front node face
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.roundRect(nx, ny, xW, nh, m > 0.05 ? 0 : 3);
      ctx.fill();

      // Hover glow border — eased width/alpha via emph
      if (emph > 0.01) {
        ctx.strokeStyle = rgba('#ffffff', 0.45 + 0.55 * emph);
        ctx.lineWidth = 1 + 1.4 * emph;
        ctx.stroke();
      }
      if (isDimmed) ctx.globalAlpha = 1;

      // Labels appear as node materializes
      if (np > 0.65) {
        const lx = n.x + nodeW + 8 + (m > 0.05 ? ox : 0);
        ctx.textAlign = 'left';
        const avail = n.col < lay.cols - 1 ? (lay.colX[n.col + 1] ?? W) - lx - 10 : W - lx - 6;
        const one = `${n.name} · ${fmtNum(n.value)}`;
        ctx.font = font(t, 600 + Math.round(emph * 100), 11);
        const labelCol = emph > 0.01 ? t.ink : shade(t.ink, 0.9);
        if (full || measureW(ctx, one) <= avail) {
          ctx.fillStyle = labelCol;
          ctx.fillText(one, lx, n.y + n.h / 2 + 3.5);
        } else {
          ctx.fillStyle = labelCol;
          ctx.fillText(fitCtx(ctx, n.name, Math.max(30, avail)), lx, n.y + n.h / 2 - 2);
          ctx.font = font(t, 600, 9.5);
          ctx.fillStyle = t.axis;
          ctx.fillText(fmtNum(n.value), lx, n.y + n.h / 2 + 9);
        }
      }
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ RADIAL BARS CIRCULAR (MUI RadialBarChart · canvas) ============
     Faithful to https://mui.com/x/react-charts/radial-bars/ + reference shot:
     - rotationAxis: band scale — one angular lane per category, starting at
       12 o'clock, clockwise, categoryGapRatio 0.3 between lanes.
     - radiusAxis: linear scale — bars grow ALONG THE RADIUS from a shared
       inner baseline (layout='vertical'), with tick rings + value labels.
     - ChartsRadialGrid: faint concentric rings + radial spokes, drawn UNDER
       the bars; outer rotation-axis ring carries the category labels
       (rotated tangent, exactly like MUI) — NO leader arrows.
     - Multi-series: bars subdivide each lane (barGapRatio 0.1); single
       series: one flat bar per lane (each lane keeps its family colour).
     - Hover: the bar brightens + lifts with a drop shadow (MUI highlight);
       the axis tooltip text mirrors on the card as usual.
     2D⇄3D morph: the SAME polar layout on a tilted disc — vertical glass
     walls + lit top caps rise with m, grid/labels stay glued to the disc. */
  if (kind === 'radialbars') {
    /* ============ RADIAL BARS CIRCULAR — PREMIUM 2D ============
       The 2D version of the 3D radial bar chart (replaces the Three.js
       port): the SAME reference language rendered on canvas — arc-wedge
       bars on a (optionally tilted) disc, dashed scale rings with value
       labels, a red dashed AVERAGE ring + tag, prior-period red arc
       markers on every wedge, up/down delta arrows around the perimeter,
       tangent category labels and a glossy centre hub. Colours use the
       premium glossy family (TOROID_GLOSS) with crown→core→deep shading —
       the same material language as the rest of the chart family. The
       geometry contract shared with the hit test (labBand / plotMax / rIn
       / lane / catGap / radOf / squash) is unchanged, and the 2D⇄3D morph
       still extrudes the wedges into lit caps on deep walls. */
    const n = Math.max(1, multi ? cats.length || data.length : data.length);
    const squash = 1 - 0.5 * m; // 1 → 0.5: tilted-disc language, eased with m
    const FS = full ? 12 : W >= 760 ? 11 : 10;
    // Rotation-axis labels ring the OUTSIDE: reserve a label band by
    // measuring the longest category on the live/scratch context.
    ctx.font = font(t, 600, FS);
    const nameList: string[] = multi ? cats : data.map((x) => x.label);
    const longest = Math.max(0, ...nameList.map((l) => measureW(ctx, l)));
    const labBand = Math.min(W * 0.24, Math.max(34, longest * 0.62 + 26));
    const plotMax = Math.max(60, Math.min((W - labBand * 2) / 2 - 6, (H - 56) / 2 / Math.max(0.5, squash) - 6));
    const cx = W / 2, cy = H / 2 + 2;
    const rIn = Math.max(22, plotMax * 0.34); // radiusAxis baseline (shared inner ring)
    const A0 = -Math.PI / 2; // 12 o'clock
    const lane = (Math.PI * 2) / n;
    const catGap = lane * 0.30; // categoryGapRatio 0.3
    const nS = multi ? Math.max(1, series.length) : 1;
    const barGap = nS > 1 ? (lane - catGap) * 0.10 : 0; // barGapRatio 0.1
    const barW = nS > 1 ? (lane - catGap - barGap * (nS - 1)) / nS : lane - catGap;
    const sMax = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
    const radOf = (v: number) => rIn + ((Math.max(0, v) / sMax) * (plotMax - rIn)) * p;
    const ell = (r: number, a: number, y0 = cy): [number, number] =>
      [cx + Math.cos(a) * r, y0 + Math.sin(a) * r * squash];
    const wallHOf = (rO: number) => (m > 0.05 ? Math.min(44, Math.max(12, (rO - rIn) * 0.5)) * m : 0);
    const hasPrior = !multi && data.some((x) => x.prior != null && Number.isFinite(x.prior));
    const avgVal = multi ? 0 : data.reduce((s, x) => s + x.value, 0) / Math.max(1, data.length);

    // ---- dashed scale rings + faint spokes + value labels (reference grid) ----
    {
      const NT = 5;
      ctx.save();
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      for (let gi = 1; gi <= NT; gi++) {
        const gr = rIn + ((plotMax - rIn) * gi) / NT;
        ctx.beginPath();
        ctx.ellipse(cx, cy, gr, Math.max(1, gr * squash), 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.setLineDash([]);
      const nSp = Math.min(n, 48);
      ctx.globalAlpha *= 0.4;
      for (let si2 = 0; si2 < nSp; si2++) {
        const aa = A0 + (si2 * Math.PI * 2) / nSp;
        const [x0, y0] = ell(rIn, aa), [x1, y1] = ell(plotMax, aa);
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      }
      ctx.restore();
      // radiusAxis tick labels (value scale, parked near 12 o'clock)
      ctx.font = font(t, 700, full ? 10 : 9);
      ctx.fillStyle = t.axis;
      ctx.textAlign = 'left';
      for (let gi = 1; gi <= NT; gi++) {
        const gr = rIn + ((plotMax - rIn) * gi) / NT;
        const [tx, ty] = ell(gr, A0 - 0.045);
        ctx.fillText(fmtNum(Math.round((sMax * gi) / NT)), tx + 4, ty + 3);
      }
      ctx.textAlign = 'left';
    }

    // ---- soft floor wash under the disc (3D only) ----
    if (m > 0.05) {
      ctx.save();
      ctx.fillStyle = rgba(t.ink, 0.08 * m);
      ctx.beginPath();
      ctx.ellipse(cx, cy + 4 + 9 * m, plotMax, plotMax * squash, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // ---- jobs: one bar per (lane × series), painted back-to-front ----
    interface RBCJob { i: number; si: number; aS: number; aE: number; rO: number; col: string; on: boolean; mid: number }
    const jobs: RBCJob[] = [];
    const orderRB = Array.from({ length: n }, (_, i) => i).sort((a, b) => {
      const ma = A0 + a * lane + lane / 2, mb = A0 + b * lane + lane / 2;
      return Math.sin(ma) - Math.sin(mb); // far (top) first
    });
    orderRB.forEach((i) => {
      const laneStart = A0 + i * lane + catGap / 2;
      if (!multi) {
        const rO = radOf(data[i] ? data[i].value : 0);
        jobs.push({ i, si: 0, aS: laneStart, aE: laneStart + barW, rO, col: colors[i], on: hov.idx === i, mid: laneStart + barW / 2 });
      } else {
        series.forEach((sr, si2) => {
          const v = sr.values[i] || 0;
          const aS = laneStart + si2 * (barW + barGap);
          jobs.push({
            i, si: si2, aS, aE: aS + barW, rO: v > 0 || p >= 0.99 ? radOf(v) : rIn + 0.5,
            col: sColors[si2], on: !!(hov.seg && hov.seg.c === i && hov.seg.s === si2), mid: aS + barW / 2,
          });
        });
      }
    });

    jobs.forEach((j) => {
      const col = j.on ? shade(j.col, 1 + 0.18 * hov.amt) : j.col;
      // hover swell: the wedge grows a few px OUTWARD in place (never lifts)
      const rO = j.rO + (j.on ? 3 * hov.amt : 0);
      if (rO - rIn < 0.75) return;
      const datum = !multi ? data[j.i] : undefined;
      const priorR = datum && datum.prior != null && Number.isFinite(datum.prior)
        ? Math.min(plotMax, radOf(datum.prior as number)) : NaN;
      if (m <= 0.05) {
        // 2D premium wedge: crown→core→deep gloss across the disc, white
        // rim sheen, hairline partings, soft drop shadow on hover.
        ctx.save();
        if (j.on && hov.amt > 0.01) setShadow(ctx, 0, 3 * hov.amt, 12 * hov.amt, rgba(t.ink, 0.34 * hov.amt));
        const gW = ctx.createLinearGradient(0, cy - rO * squash, 0, cy + rO * squash);
        gW.addColorStop(0, shade(col, 1.34));
        gW.addColorStop(0.34, shade(col, 1.08));
        gW.addColorStop(0.66, col);
        gW.addColorStop(1, shade(col, 0.70));
        ctx.fillStyle = gW;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rO, rO * squash, 0, j.aS, j.aE);
        ctx.ellipse(cx, cy, rIn, rIn * squash, 0, j.aE, j.aS, true);
        ctx.closePath(); ctx.fill();
        noShadow(ctx);
        // crisp white crown along the outer rim (gloss sheen)
        ctx.strokeStyle = rgba('#ffffff', 0.65);
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rO - 0.8, (rO - 0.8) * squash, 0, j.aS + 0.012, Math.max(j.aS + 0.02, j.aE - 0.012));
        ctx.stroke();
        // hairline partings between neighbouring wedges
        ctx.strokeStyle = rgba('#ffffff', 0.5);
        ctx.lineWidth = 1;
        ([j.aS, j.aE] as const).forEach((aa) => {
          const [ix, iy] = ell(rIn, aa), [ox, oy] = ell(rO, aa);
          ctx.beginPath(); ctx.moveTo(ix, iy); ctx.lineTo(ox, oy); ctx.stroke();
        });
        // prior-period marker: red arc across the wedge at the prior radius
        if (Number.isFinite(priorR) && p > 0.6) {
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 2.4;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.ellipse(cx, cy, priorR, priorR * squash, 0, j.aS + 0.03, Math.max(j.aS + 0.04, j.aE - 0.03));
          ctx.stroke();
          ctx.lineCap = 'butt';
        }
        ctx.restore();
      } else {
        // 3D: the same wedge extruded — deep vertical walls + glossy lit cap.
        const wallH = wallHOf(rO);
        const yTop = cy - wallH;
        ctx.save();
        if (j.on && hov.amt > 0.01) setShadow(ctx, 0, 4 * hov.amt, 12 * hov.amt, rgba(t.ink, 0.28 * hov.amt));
        // outer + inner walls
        ctx.fillStyle = shade(col, 0.52);
        ctx.beginPath();
        ctx.ellipse(cx, cy, rO, rO * squash, 0, j.aS, j.aE);
        ctx.ellipse(cx, yTop, rO, rO * squash, 0, j.aE, j.aS, true);
        ctx.closePath(); ctx.fill();
        noShadow(ctx);
        ctx.fillStyle = shade(col, 0.42);
        ctx.beginPath();
        ctx.ellipse(cx, cy, rIn, rIn * squash, 0, j.aE, j.aS, true);
        ctx.ellipse(cx, yTop, rIn, rIn * squash, 0, j.aS, j.aE);
        ctx.closePath(); ctx.fill();
        // radial side edges (start/end caps of the wall)
        ([j.aS, j.aE] as const).forEach((aa) => {
          const [ox, oy] = ell(rO, aa), [ix, iy] = ell(rIn, aa);
          ctx.fillStyle = shade(col, 0.46);
          ctx.beginPath();
          ctx.moveTo(ix, iy); ctx.lineTo(ox, oy);
          ctx.lineTo(ox, oy - wallH); ctx.lineTo(ix, iy - wallH);
          ctx.closePath(); ctx.fill();
        });
        // top cap: bright crown → saturated core (premium gloss ramp)
        const capG = ctx.createLinearGradient(0, yTop - rO * squash, 0, yTop + rO * squash);
        capG.addColorStop(0, shade(col, 1.38));
        capG.addColorStop(0.4, shade(col, 1.10));
        capG.addColorStop(0.75, shade(col, 0.96));
        capG.addColorStop(1, shade(col, 0.80));
        ctx.fillStyle = capG;
        ctx.beginPath();
        ctx.ellipse(cx, yTop, rO, rO * squash, 0, j.aS, j.aE);
        ctx.ellipse(cx, yTop, rIn, rIn * squash, 0, j.aE, j.aS, true);
        ctx.closePath(); ctx.fill();
        // crest specular along the outer rim
        ctx.strokeStyle = rgba('#ffffff', 0.6 * m);
        ctx.lineWidth = Math.max(1, (rO - rIn) * 0.08);
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.ellipse(cx, yTop, rO - (rO - rIn) * 0.12, (rO - (rO - rIn) * 0.12) * squash, 0, j.aS + 0.03, Math.max(j.aS + 0.04, j.aE - 0.03));
        ctx.stroke();
        ctx.lineCap = 'butt';
        // prior-period marker rides the lit cap
        if (Number.isFinite(priorR) && p > 0.6) {
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 2.4;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.ellipse(cx, yTop, priorR, priorR * squash, 0, j.aS + 0.03, Math.max(j.aS + 0.04, j.aE - 0.03));
          ctx.stroke();
          ctx.lineCap = 'butt';
        }
        ctx.restore();
      }
    });

    // ---- perimeter delta arrows (reference increase/decrease cones) ----
    if (hasPrior && p > 0.85) {
      data.forEach((x, i) => {
        if (x.prior == null || !Number.isFinite(x.prior)) return;
        const up = x.value >= (x.prior as number);
        const mid = A0 + i * lane + lane / 2;
        const [axx, ayy] = ell(plotMax + 7, mid);
        const s = 4.6;
        ctx.save();
        ctx.fillStyle = up ? '#16a34a' : '#ef4444';
        ctx.strokeStyle = 'rgba(255,255,255,0.9)';
        ctx.lineWidth = 1;
        ctx.lineJoin = 'round';
        ctx.beginPath();
        if (up) { ctx.moveTo(axx, ayy - s); ctx.lineTo(axx + s * 0.86, ayy + s * 0.6); ctx.lineTo(axx - s * 0.86, ayy + s * 0.6); }
        else { ctx.moveTo(axx, ayy + s); ctx.lineTo(axx + s * 0.86, ayy - s * 0.6); ctx.lineTo(axx - s * 0.86, ayy - s * 0.6); }
        ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.restore();
      });
    }

    // ---- average ring (red dashed) + tag (reference average language) ----
    if (!multi && data.length && p > 0.7) {
      const avgR = radOf(avgVal);
      ctx.save();
      ctx.strokeStyle = 'rgba(239,68,68,0.85)';
      ctx.lineWidth = 1.6;
      ctx.setLineDash([5, 4]);
      ctx.beginPath();
      ctx.ellipse(cx, cy, avgR, Math.max(1, avgR * squash), 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      // tag pill parked ON the ring at the reference's angle
      const aTag = -Math.PI * 0.72;
      const [tgx, tgy] = ell(avgR, aTag, cy - (m > 0.05 ? wallHOf(avgR) : 0));
      const tagTxt = `Average ${fmtNum(Math.round(avgVal * 10) / 10)}`;
      ctx.font = font(t, 700, 9.5);
      const tw = measureW(ctx, tagTxt);
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.strokeStyle = '#fecaca';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(tgx - tw / 2 - 5, tgy - 8, tw + 10, 15, 4); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#ef4444';
      ctx.textAlign = 'center';
      ctx.fillText(tagTxt, tgx, tgy + 3.5);
      ctx.textAlign = 'left';
      ctx.restore();
    }

    // ---- centre hub (glossy origin marker + average readout) ----
    {
      const hr = Math.max(11, Math.min(24, rIn * 0.5));
      const hg = ctx.createLinearGradient(0, cy - hr, 0, cy + hr);
      hg.addColorStop(0, '#ffffff');
      hg.addColorStop(0.55, t.surface || '#e8e8e8');
      hg.addColorStop(1, shade(t.surface || '#e8e8e8', 0.85));
      ctx.fillStyle = hg;
      ctx.beginPath(); ctx.ellipse(cx, cy, hr, Math.max(1, hr * squash), 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = rgba(t.ink, 0.14);
      ctx.lineWidth = 1;
      ctx.stroke();
      if (!multi && p > 0.9) {
        ctx.fillStyle = t.ink;
        ctx.font = font(t, 700, Math.max(8, Math.min(11, hr * 0.62)));
        ctx.textAlign = 'center';
        ctx.fillText(fmtNum(Math.round(avgVal)), cx, cy + 3.5);
        ctx.textAlign = 'left';
      }
    }

    // ---- rotationAxis: outer ring + tangent CATEGORY labels outside ----
    // Labels sit OUTSIDE the data radius (and beyond the delta-arrow band
    // when priors are present); long sets stride exactly like a band axis —
    // never overlapping, never leaders.
    {
      ctx.save();
      ctx.strokeStyle = rgba(t.ink, 0.30);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(cx, cy, plotMax + 3, (plotMax + 3) * squash, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      const names: string[] = multi ? cats : data.map((x) => x.label);
      const stride = Math.max(1, Math.ceil(n / Math.max(4, Math.floor(plotMax / 26))));
      ctx.font = font(t, 600, FS);
      ctx.fillStyle = t.axis;
      ctx.textAlign = 'center';
      const lOut = hasPrior ? 9 : 0; // delta arrows own the first band outside the rim
      for (let i = 0; i < n; i++) {
        if (i % stride !== 0) continue;
        const mid = A0 + i * lane + lane / 2;
        const lr = plotMax + 8 + lOut + FS * 0.9;
        const lx = cx + Math.cos(mid) * lr;
        const ly = cy + Math.sin(mid) * lr * squash;
        // tangent rotation: readable on both halves (flip past the bottom)
        let rot = mid + Math.PI / 2;
        const deg = ((rot * 180) / Math.PI % 360 + 360) % 360;
        const flip = deg > 90 && deg < 270;
        if (flip) rot += Math.PI;
        ctx.save();
        ctx.translate(lx, ly);
        ctx.rotate(rot);
        const label = names[i] ?? '';
        const maxL = Math.min(labBand + 30, Math.max(40, (Math.PI * 2 * lr) / n - 8));
        ctx.fillText(fitCtx(ctx, label, maxL), 0, FS * 0.32);
        ctx.restore();
      }
      ctx.textAlign = 'left';
    }
    return;
  }

  /* ============ RADIAL BAR (Classic · canvas) — rebuilt Option B ============
     Beautiful in 2D AND 3D: concentric round-cap tubes on soft full-circle
     tracks, glassy cylindrical wrap in 3D, sweep-end dots, and proper
     outside labels with pie/donut-style curved leaders + arrowheads.
     NOTE: `radialbar` (Three.js) no longer falls through to this painter —
     it is always covered by its WebGL overlay. This block serves
     `radialbarclassic` only (see the guard). */
  /* ============ RADIAL BAR (Classic · canvas) — Highcharts 2D + TRUE 3D ============
     2D (Highcharts language): concentric round-cap progress rings on soft
     full-circle tracks, % rim ticks, center total, outside curved leaders.
     3D (ported from RadialBarText3D.html): the SAME rings on a tilted disc
     (squash eases 1 → 0.5 with m) rendered as sphere-shaded pipes — radial
     light→base→dark shading, contact shadows, z-sorted back-to-front
     painter order, sphere end caps, tangent-rotated in-tube labels.
     Geometry contract (shared with radialClassicGeom + hit test):
     - pitch is SOLVED so tubes can never overlap (see radialClassicGeom);
     - bars START at 12 o'clock and sweep CLOCKWISE up to 0.985 of a turn;
     - the disc DIAMETER is fixed across the morph (R never changes with m);
     - ellipse squash applies to Y only: (cos a · r, sin a · r · squash). */
  if (kind === 'radialbarclassic') {
    const rg = radialClassicGeom(W, H, data, full);
    const squash = 1 - 0.5 * m; // 1 → 0.5: the reference tilt, eased smoothly
    const R = rg.R; // FIXED diameter — identical in 2D and 3D
    const cx = rg.cx, cy = rg.cy;
    const tubeHalf = rg.thick / 2;
    const pipeLift = m; // 0 = flat ring, 1 = full pipe shading
    const ringR = (i: number) => rg.ringR(i) + (hov.idx === i ? hov.amt * 2.5 : 0);
    const max = Math.max(...data.map((x) => x.value), 1);
    const sweepOf = (x: ChartDatum) => Math.min(Math.PI * 2 * 0.985, (x.value / max) * Math.PI * 2 * 0.985 * p);
    const A0 = -Math.PI / 2; // 12 o'clock
    const ell = (r: number, a: number, y = cy): [number, number] =>
      [cx + Math.cos(a) * r, y + Math.sin(a) * r * squash];

    // ---- polar grid: concentric rings + spokes with % rim ticks ----
    {
      const G = Math.max(3, Math.min(6, data.length + 1));
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = 1;
      for (let gi = 1; gi <= G; gi++) {
        const gr = Math.max(4, (R * gi) / G);
        ctx.beginPath();
        ctx.ellipse(cx, cy, gr, gr * squash, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.font = font(t, 600, full ? 10 : 9);
      ctx.fillStyle = t.axis;
      ctx.textAlign = 'center';
      for (let pct = 10; pct <= 100; pct += 10) {
        const aa = A0 + (pct / 100) * Math.PI * 2 * 0.985;
        const [sx0, sy0] = ell(Math.max(4, R / G), aa);
        const [sx1, sy1] = ell(R, aa);
        ctx.strokeStyle = rgba(t.grid, 0.7);
        ctx.beginPath(); ctx.moveTo(sx0, sy0); ctx.lineTo(sx1, sy1); ctx.stroke();
        const [lx, ly] = ell(R + tubeHalf + 9, aa);
        ctx.fillText(`${pct}%`, Math.max(14, Math.min(W - 14, lx)), Math.max(10, Math.min(H - 4, ly + 3)));
      }
      ctx.textAlign = 'left';
    }

    // ---- glossy centre hub + total ----
    {
      const hr = Math.max(7, Math.min(22, tubeHalf * 1.2));
      ctx.fillStyle = rgba(t.ink, 0.10);
      ctx.beginPath(); ctx.ellipse(cx, cy + 3, hr + 3, (hr + 3) * squash, 0, 0, Math.PI * 2); ctx.fill();
      const hg = ctx.createLinearGradient(0, cy - hr, 0, cy + hr);
      hg.addColorStop(0, '#ffffff');
      hg.addColorStop(0.55, rgba(t.surface || '#e8e8e8', 1));
      hg.addColorStop(1, shade(t.surface || '#e8e8e8', 0.82));
      ctx.fillStyle = hg;
      ctx.beginPath(); ctx.ellipse(cx, cy, hr, hr * squash, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = rgba(t.ink, 0.14);
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.font = font(t, 700, full ? 12 : 10.5);
      ctx.fillStyle = t.ink;
      ctx.textAlign = 'center';
      ctx.fillText(fmtNum(total), cx, cy + (full ? 4 : 3.5));
      ctx.textAlign = 'left';
    }

    // ---- background tracks (full-circle grooves) ----
    noShadow(ctx);
    data.forEach((_, i) => {
      const rr = ringR(i);
      ctx.save();
      ctx.strokeStyle = rgba(t.surface || '#e4e7e0', full ? 0.9 : 1);
      ctx.lineWidth = rg.thick;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.ellipse(cx, cy, rr, rr * squash, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    });

    // ---- contact shadows (grow with the tilt, like the reference) ----
    data.forEach((x, i) => {
      const sweep = sweepOf(x);
      if (sweep <= 0.01) return;
      const rr = ringR(i);
      ctx.save();
      ctx.strokeStyle = rgba(t.ink, 0.08 + 0.06 * m);
      ctx.lineWidth = rg.thick;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.ellipse(cx, cy + 2 + 10 * m, rr, rr * squash, 0, A0, A0 + sweep);
      ctx.stroke();
      ctx.restore();
    });

    // ---- pipes: z-sorted back-to-front (reference spheresToDraw order) ----
    // Sampled beads per ring, sorted by screen Y (far beads under near
    // beads), each bead a sphere-shaded circle: white-hot crown → light →
    // base → dark limb. Bead count eases with m (flat ring needs none, the
    // tilt reveals the pipe), and alpha cross-fades flat↔pipe so the morph
    // is perfectly smooth at every step.
    interface Bead { x: number; y: number; r: number; col: string; light: string; dark: string; on: boolean }
    const beads: Bead[] = [];
    const labeled: { i: number; x: ChartDatum; baseR: number; col: string; on: boolean; sweep: number; end: number }[] = [];
    data.forEach((x, i) => {
      const on = hov.idx === i;
      const col = colors[i];
      const sweep = sweepOf(x);
      const end = A0 + sweep;
      const baseR = ringR(i);
      labeled.push({ i, x, baseR, col, on, sweep, end });
      if (sweep <= 0.01) return;
      // 2D flat ring (fades out as the pipe fades in)
      if (pipeLift < 0.98) {
        ctx.save();
        ctx.globalAlpha *= 1 - pipeLift;
        ctx.lineCap = 'round';
        const grad = ctx.createLinearGradient(0, cy - baseR * squash, 0, cy + baseR * squash);
        grad.addColorStop(0, shade(col, 1.14));
        grad.addColorStop(0.5, on ? shade(col, 1 + 0.14 * hov.amt) : col);
        grad.addColorStop(1, shade(col, 0.88));
        ctx.strokeStyle = grad;
        ctx.lineWidth = rg.thick;
        ctx.beginPath();
        ctx.ellipse(cx, cy, baseR, baseR * squash, 0, A0, end);
        ctx.stroke();
        ctx.strokeStyle = rgba('#ffffff', 0.35 * (1 - pipeLift));
        ctx.lineWidth = Math.max(1, rg.thick * 0.22);
        ctx.beginPath();
        ctx.ellipse(cx, cy - rg.thick * 0.12, baseR, baseR * squash, 0, A0 + 0.04, Math.max(A0 + 0.05, end - 0.04));
        ctx.stroke();
        ctx.restore();
      }
      // 3D pipe beads (fade in with the tilt)
      if (pipeLift > 0.02) {
        const arcLen = Math.max(8, sweep * baseR);
        const nBeads = Math.max(24, Math.min(420, Math.round(arcLen / Math.max(1.5, rg.thick * 0.22))));
        for (let bi = 0; bi <= nBeads; bi++) {
          const a = A0 + (sweep * bi) / nBeads;
          const [bx, by] = ell(baseR, a);
          beads.push({ x: bx, y: by, r: tubeHalf, col, light: shade(col, 1.45), dark: shade(col, 0.45), on });
        }
      }
    });
    if (beads.length) {
      beads.sort((a, b) => a.y - b.y); // far (top) first — reference z-sort
      ctx.save();
      ctx.globalAlpha *= pipeLift;
      beads.forEach((bd) => {
        const g = ctx.createRadialGradient(bd.x, bd.y - bd.r * 0.6, bd.r * 0.05, bd.x, bd.y, bd.r);
        g.addColorStop(0, '#ffffff');
        g.addColorStop(0.3, bd.light);
        g.addColorStop(0.7, bd.on ? shade(bd.col, 1 + 0.15 * hov.amt) : bd.col);
        g.addColorStop(1, bd.dark);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(bd.x, bd.y, bd.r, 0, Math.PI * 2); ctx.fill();
      });
      ctx.restore();
    }

    // ---- sweep-end caps + in-tube rotated labels (reference textAngle style) ----
    labeled.forEach(({ i, x, baseR, col, on, sweep, end }) => {
      if (sweep <= 0.01) return;
      // Perspective-true pipe end: the tube terminates in a sphere-shaded
      // cap bead — a sphere silhouettes as a PERFECT circle at any tilt, so
      // the end always follows the perspective rules for the angle it sits
      // at. (The old flat colour disc + white speck sat on the spherical
      // end like a sticker — the stray "ball" past halfway and the "circle
      // with a white dot" at the pipe end.) In flat 2D the ring stroke's
      // round lineCap already IS the perfect end, so nothing is overlaid.
      if (pipeLift > 0.02) {
        const [dx, dy0] = ell(baseR, end);
        ctx.save();
        ctx.globalAlpha *= Math.min(1, pipeLift * 1.2);
        const cg = ctx.createRadialGradient(dx, dy0 - tubeHalf * 0.6, tubeHalf * 0.05, dx, dy0, tubeHalf);
        cg.addColorStop(0, '#ffffff');
        cg.addColorStop(0.3, shade(col, 1.45));
        cg.addColorStop(0.7, on ? shade(col, 1 + 0.15 * hov.amt) : col);
        cg.addColorStop(1, shade(col, 0.45));
        ctx.fillStyle = cg;
        ctx.beginPath(); ctx.arc(dx, dy0, tubeHalf, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
      // rotated in-tube label at the arc midpoint (Highcharts-style inside,
      // reference-style tangent rotation), only when the arc is long enough
      const arcLen = sweep * baseR;
      if (arcLen > 70 && p > 0.9 && pipeLift > 0.02) {
        const la = A0 + sweep * 0.5;
        const [lx, ly] = ell(baseR, la);
        const tangent = Math.atan2(Math.cos(la) * squash, -Math.sin(la));
        let rot = tangent + Math.PI / 2;
        if (rot > Math.PI / 2 || rot < -Math.PI / 2) rot += Math.PI;
        ctx.save();
        ctx.translate(lx, ly);
        ctx.rotate(rot - Math.PI / 2 + Math.PI / 2);
        ctx.rotate(0);
        ctx.font = font(t, 700, Math.min(12, Math.max(9, rg.thick * 0.62)));
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 4; ctx.shadowOffsetX = 1; ctx.shadowOffsetY = 1;
        ctx.fillText(fitCtx(ctx, `${x.label} ${Math.round((x.value / max) * 100)}%`, Math.min(arcLen * 0.8, 170)), 0, -tubeHalf - 8);
        ctx.restore();
        void i;
        ctx.restore();
        ctx.textBaseline = 'alphabetic';
      }
    });

    // ---- outside curved leaders (2D-forward; fade as pipes take over) ----
    if (pipeLift < 0.85) {
      ctx.save();
      ctx.globalAlpha *= 1 - pipeLift;
      const FS = full ? 12 : W >= 760 ? 11.5 : 10;
      ctx.font = font(t, 600, FS);
      const PITCH = FS + 8;
      interface RBCand { e: (typeof labeled)[number]; text: string; ax: number; ay: number; right: boolean; y: number }
      const wantLabel = (e: { on: boolean }) => (rg.roomy ? (e.on || full || rg.thick >= 5) : e.on);
      const cands: RBCand[] = labeled.filter(wantLabel).map((e) => {
        const anchorA = e.sweep > 0.03 ? e.end : A0;
        const [aX, aY] = ell(e.baseR, anchorA);
        return { e, text: `${e.x.label} · ${fmtNum(e.x.value)}`, ax: aX, ay: aY, right: aX >= cx, y: aY };
      });
      const place = (list: RBCand[]) => {
        list.sort((p2, q) => p2.y - q.y);
        let prev = -Infinity;
        list.forEach((c) => { c.y = Math.max(c.y, prev + PITCH); prev = c.y; });
        list.forEach((c) => { c.y = Math.max(12, Math.min(H - 8, c.y)); });
      };
      place(cands.filter((c) => c.right));
      place(cands.filter((c) => !c.right));
      cands.forEach((c) => {
        const tx = c.right ? Math.min(W - 8, c.ax + 30) : Math.max(8, c.ax - 30);
        const ex = c.right ? tx - 8 : tx + 8;
        const mx2 = (ex + c.ax) / 2;
        ctx.strokeStyle = c.e.col;
        ctx.lineWidth = c.e.on ? 2 : 1.4;
        ctx.beginPath();
        ctx.moveTo(tx, c.y);
        ctx.lineTo(ex, c.y);
        ctx.bezierCurveTo(mx2, c.y, c.ax, c.ay, c.ax, c.ay);
        ctx.stroke();
        const dx = c.ax - mx2, dy = c.ay - c.y;
        const dl = Math.hypot(dx, dy) || 1;
        const ux = dx / dl, uy = dy / dl;
        const px2 = -uy, py2 = ux;
        const bx = c.ax - ux * 6, by = c.ay - uy * 6;
        ctx.fillStyle = c.e.col;
        ctx.beginPath();
        ctx.moveTo(c.ax + ux * 0.5, c.ay + uy * 0.5);
        ctx.lineTo(bx - ux * 1.2 + px2 * 4, by - uy * 1.2 + py2 * 4);
        ctx.lineTo(bx - ux * 1.2 - px2 * 4, by - uy * 1.2 - py2 * 4);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.lineJoin = 'round';
        ctx.stroke();
        ctx.lineJoin = 'miter';
        const avail = c.right ? W - tx - 8 : tx - 8;
        ctx.fillStyle = t.ink;
        ctx.textAlign = c.right ? 'left' : 'right';
        ctx.fillText(full ? c.text : fitCtx(ctx, c.text, Math.max(30, avail)), tx + (c.right ? 4 : -4), c.y + FS * 0.35);
      });
      ctx.restore();
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ DUAL AXES — columns (left) + lines (right) (2D ⇄ 3D) ============ */
  if (kind === 'dual') {
    const labels = multi ? cats : data.map((x) => x.label);
    const colVals = multi ? cats.map((_, c) => series[0]?.values[c] || 0) : data.map((x) => x.value);
    const barColors = multi ? [sColors[0]] : colors;
    const lines: { name: string; color: string; values: number[] }[] = multi
      ? series.slice(1).map((s, i) => ({ name: s.name, color: distinctLineColor(barColors, sColors[i + 1], activePalette()), values: s.values }))
      : [{
        name: 'Cumulative %',
        // Premium slate ink for the Pareto cumulative line — never a bar color.
        color: distinctLineColor(barColors, '#0f172a', activePalette()),
        values: (() => {
          let acc = 0;
          return data.map((x) => { acc += x.value; return Math.round((acc / total) * 100); });
        })(),
      }];

    const ox = 20 * m, oy = 15 * m; // 3D isometric offset
    const maxL = Math.max(...colVals, 1);
    const maxR = Math.max(...lines.flatMap((l) => l.values), 1);
    const L = xyLayout('bar', W, H, 0, labels, 1, maxL, !!d.yLabel, full);
    const pad = { ...L.pad, r: 12 + approxW(fmtNum(maxR), 10.5) + 14 + ox, t: L.pad.t + oy };
    const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
    const step = cw / Math.max(1, labels.length);

    // 3D Isometric floor grid
    if (m > 0.05) {
      ctx.strokeStyle = rgba(t.grid, 0.4);
      ctx.lineWidth = 1;
      for (let g = 0; g <= 4; g++) {
        const y = pad.t + ch - (ch * g) / 4;
        ctx.beginPath();
        ctx.moveTo(pad.l, y);
        ctx.lineTo(pad.l + ox, y - oy);
        ctx.lineTo(W - pad.r + ox, y - oy);
        ctx.stroke();
      }
    }

    drawAxes(ctx, W, H, pad, maxL, t, m > 0.05 ? ox : 0, m > 0.05 ? oy : 0);

    // Right Y-axis
    ctx.font = font(t, 600, 10.5); ctx.fillStyle = t.axis; ctx.textAlign = 'left';
    for (let g = 0; g <= 4; g++) {
      const y = pad.t + ch - (ch * g) / 4;
      ctx.fillText(fmtNum((maxR * g) / 4) + (multi ? '' : '%'), W - pad.r + (m > 0.05 ? ox : 0) + 7, (m > 0.05 ? y - oy : y) + 3.5);
    }
    ctx.strokeStyle = t.axis; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t - 4 - (m > 0.05 ? oy : 0)); ctx.lineTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t + ch - (m > 0.05 ? oy : 0)); ctx.stroke(); ctx.lineWidth = 1;

    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, planX(labels, step, full), (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);

    // 3D Columns
    labels.forEach((_, ci) => {
      const bw = Math.min(36, step * 0.5);
      const x = pad.l + step * ci + (step - bw) / 2;
      const h = (colVals[ci] / maxL) * ch * p;
      const yTop = pad.t + ch - h;
      const yBase = pad.t + ch;
      const on = multi ? !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === 0) : hov.idx === ci;
      const col = multi ? sColors[0] : colors[ci];
      const cFill = on ? shade(col, 1 + 0.16 * hov.amt) : col;

      if (m > 0.05 && h > 1) {
        // 3D Top face
        ctx.fillStyle = shade(cFill, 1.25);
        ctx.beginPath();
        ctx.moveTo(x, yTop);
        ctx.lineTo(x + ox, yTop - oy);
        ctx.lineTo(x + bw + ox, yTop - oy);
        ctx.lineTo(x + bw, yTop);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 1; ctx.stroke();

        // 3D Right face
        ctx.fillStyle = shade(cFill, 0.68);
        ctx.beginPath();
        ctx.moveTo(x + bw, yTop);
        ctx.lineTo(x + bw + ox, yTop - oy);
        ctx.lineTo(x + bw + ox, yBase - oy);
        ctx.lineTo(x + bw, yBase);
        ctx.closePath();
        ctx.fill();
      }

      // Front face
      ctx.fillStyle = cFill;
      ctx.beginPath(); ctx.roundRect(x, yTop, bw, Math.max(1, h), m > 0.05 ? 0 : [5, 5, 0, 0]); ctx.fill();
    });

    // Lines on the right axis
    lines.forEach((ln, li) => {
      const pts = ln.values.map((v, i) => ({
        x: pad.l + step * i + step / 2 + (m > 0.05 ? ox * 0.5 : 0),
        y: pad.t + ch - (v / maxR) * ch * p - (m > 0.05 ? oy * 0.5 : 0),
      }));
      if (!pts.length) return;

      // Freehand (Catmull-Rom → bezier) path shared by line AND shadow —
      // the shadow is the same curve translated down, so they always match.
      const traceFreehand = (dy: number) => {
        ctx.beginPath();
        pts.forEach((pt, i) => {
          if (i === 0) { ctx.moveTo(pt.x, pt.y + dy); return; }
          const p0 = pts[Math.max(0, i - 2)], p1 = pts[i - 1], p2 = pt, p3 = pts[Math.min(pts.length - 1, i + 1)];
          ctx.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + dy + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y + dy - (p3.y - p1.y) / 6, p2.x, p2.y + dy);
        });
      };
      // 3D Shadow ribbon (same freehand curve, offset down-right)
      if (m > 0.05) {
        ctx.strokeStyle = rgba(t.ink, 0.15);
        ctx.lineWidth = 3;
        traceFreehand(oy * 0.5);
        ctx.stroke();
      }

      ctx.strokeStyle = ln.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
      traceFreehand(0);
      ctx.stroke();

      const dense = step < 14;
      pts.forEach((pt, i) => {
        const on = multi ? !!(hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === li + 1) : hov.idx === i;
        if (dense && !on) return;
        const rad = (step < 26 ? 3.5 : 4.5) + (on ? 2 * hov.amt : 0);
        if (m > 0.05) {
          const g = ctx.createRadialGradient(pt.x - 1.5, pt.y - 1.5, 1, pt.x, pt.y, rad);
          g.addColorStop(0, shade(ln.color, 1.35));
          g.addColorStop(1, shade(ln.color, 0.75));
          ctx.fillStyle = g;
        } else {
          ctx.fillStyle = on ? shade(ln.color, 1.2) : ln.color;
        }
        ctx.beginPath(); ctx.arc(pt.x, pt.y, rad, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
      });
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ GANTT CHART (2D + glass-block 3D) — rebuilt Option B ============
     Modern Gantt language inspired by the best web Gantts (rounded bars,
     progress sheen, milestones, baseline ghosts, dependency elbows,
     critical-path glow, today line, overdue hatch, weekend shading, swim
     lanes with avatar chips). 3D = the SAME layout with extruded glass
     blocks, continuous 2D⇄3D morph. */
  if (kind === 'gantt') {
    type GT = GanttTask & { _s: number; _e: number; _bS?: number; _bE?: number };
    const toMs = (v: string | number): number => (typeof v === 'number' ? v : new Date(v).getTime());
    const isDate = !!(d.tasks && d.tasks.length && typeof d.tasks[0].start === 'string');
    const rawTasks: GT[] = d.tasks && d.tasks.length ? d.tasks.map((tk) => ({
      ...tk,
      _s: toMs(tk.start), _e: Math.max(toMs(tk.start) + 1, toMs(tk.end)),
      _bS: tk.baselineStart !== undefined ? toMs(tk.baselineStart) : undefined,
      _bE: tk.baselineEnd !== undefined ? toMs(tk.baselineEnd) : undefined,
    })) : (
      data.map((x, i) => ({
        id: i, name: x.label, start: i * 3, end: i * 3 + Math.max(3, Math.round(x.value / 8)),
        progress: 35 + ((i * 17) % 60), color: colors[i], category: 'Milestone',
        _s: i * 3, _e: i * 3 + Math.max(3, Math.round(x.value / 8)),
      }))
    );
    const byId = new Map<string | number, number>();
    rawTasks.forEach((tk, i) => byId.set(tk.id, i));
    const padL = Math.max(150, Math.min(250, W * 0.27));
    const padR = 30 + 14 * m, padT = 52 + 10 * m, padB = 30;
    const chartW = W - padL - padR;
    const chartH = H - padT - padB;
    const rowH = Math.min(46, Math.max(28, chartH / Math.max(1, rawTasks.length)));
    const plotBot = padT + rowH * rawTasks.length;

    const starts = rawTasks.map((tk) => tk._s);
    const ends = rawTasks.map((tk) => tk._e);
    const minTime = Math.min(...starts);
    const maxTime = Math.max(...ends, minTime + 1);
    const timeSpan = maxTime - minTime || 1;
    // ONE oblique 3D projection for the whole Gantt scene: every 2D point
    // (x, y) at extrusion height z maps to (x + z·cosA, y − z·sinA) with a
    // fixed cabinet angle A=38°. Tracks sit at z=0, bar tops at z=barH·0.9,
    // elbows at z=barH·0.45 — so bars, caps, shadows and dependency links
    // share one consistent depth instead of ad-hoc per-element offsets.
    const G_ANG = (38 * Math.PI) / 180;
    const gOx = Math.cos(G_ANG) * 13 * m, gOy = Math.sin(G_ANG) * 13 * m;
    const X = (ms: number) => padL + ((ms - minTime) / timeSpan) * chartW;
    const ZP = (x: number, y: number, z: number): [number, number] =>
      [x + (z / 13) * gOx, y - (z / 13) * gOy];

    // ---- swim-lane grouping (by category) ----
    const lanes: { name: string; rows: number[] }[] = [];
    const laneOf = new Array(rawTasks.length).fill(0);
    rawTasks.forEach((tk, i) => {
      const nm = tk.category || 'Plan';
      let li = lanes.findIndex((l) => l.name === nm);
      if (li < 0) { lanes.push({ name: nm, rows: [] }); li = lanes.length - 1; }
      lanes[li].rows.push(i);
      laneOf[i] = li;
    });
    const laneColors = lanes.map((_, li) => colors[li % colors.length]);

    // ---- plot bay ----
    ctx.fillStyle = rgba(t.ink, m > 0.02 ? 0.05 : 0.035);
    ctx.beginPath(); ctx.roundRect(padL - 8, padT - 34, chartW + 16, plotBot - padT + 40, 10); ctx.fill();

    // ---- weekend shading (date mode) ----
    if (isDate) {
      const t0 = new Date(minTime); t0.setHours(0, 0, 0, 0);
      for (let dd = new Date(t0); dd.getTime() <= maxTime; dd = new Date(dd.getTime() + 864e5)) {
        const dow = dd.getDay();
        if (dow === 0 || dow === 6) {
          const x0 = X(dd.getTime()), x1 = X(dd.getTime() + 864e5);
          ctx.fillStyle = rgba(t.ink, 0.045);
          ctx.fillRect(x0, padT - 4, Math.max(1, x1 - x0), plotBot - padT + 8);
        }
      }
    }

    // ---- time axis: day gridlines + adaptive header (month/day or Day N) ----
    const cols = 5;
    ctx.font = font(t, 600, 10);
    ctx.textAlign = 'center';
    for (let c = 0; c <= cols; c++) {
      const gx = padL + (chartW * c) / cols;
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(gx, padT - 4);
      ctx.lineTo(gx, plotBot);
      if (m > 0.02) { ctx.moveTo(gx, plotBot); ctx.lineTo(gx + gOx, plotBot - gOy); }
      ctx.stroke();
      ctx.setLineDash([]);
      const tVal = minTime + (timeSpan * c) / cols;
      const tLabel = isDate
        ? new Date(tVal).toLocaleDateString('en', { month: 'short', day: 'numeric' })
        : `Day ${Math.round(tVal)}`;
      ctx.fillStyle = t.axis;
      ctx.fillText(tLabel, gx + (m > 0.02 ? gOx / 2 : 0), padT - 22);
    }
    if (isDate) {
      // month band above the day labels
      ctx.font = font(t, 700, 9);
      ctx.fillStyle = rgba(t.axis, 0.85);
      let lastM = '';
      for (let c = 0; c <= cols; c++) {
        const tVal = minTime + (timeSpan * c) / cols;
        const mm = new Date(tVal).toLocaleDateString('en', { month: 'long', year: 'numeric' });
        if (mm !== lastM) {
          const gx = padL + (chartW * c) / cols;
          ctx.fillText(mm.toUpperCase(), Math.min(gx + 34, padL + chartW - 40), padT - 34 - 10);
          lastM = mm;
        }
      }
    }
    // ---- today marker ----
    const nowMs = Date.now();
    if (isDate && nowMs >= minTime && nowMs <= maxTime) {
      const tx = X(nowMs);
      ctx.save();
      ctx.strokeStyle = '#e11d63'; ctx.lineWidth = 1.6; ctx.setLineDash([5, 3]);
      ctx.beginPath(); ctx.moveTo(tx, padT - 8); ctx.lineTo(tx, plotBot + 2); ctx.stroke();
      ctx.setLineDash([]);
      ctx.font = font(t, 700, 9); ctx.textAlign = 'center';
      const tw = measureW(ctx, 'TODAY') + 12;
      ctx.fillStyle = '#e11d63';
      ctx.beginPath(); ctx.roundRect(tx - tw / 2, padT - 26, tw, 14, 7); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.fillText('TODAY', tx, padT - 15.5);
      ctx.restore();
    }
    ctx.textAlign = 'left';
    if (m > 0.02) {
      ctx.fillStyle = rgba(t.ink, 0.045 * m);
      ctx.beginPath();
      ctx.moveTo(padL, plotBot);
      ctx.lineTo(padL + gOx, plotBot - gOy);
      ctx.lineTo(padL + chartW + gOx, plotBot - gOy);
      ctx.lineTo(padL + chartW, plotBot);
      ctx.closePath(); ctx.fill();
    }

    // ---- critical path: longest dependency chain (finish-to-start) ----
    const crit = new Set<number>();
    {
      const memo = new Map<number, number>();
      const depth = (i: number, seen: Set<number>): number => {
        if (memo.has(i)) return memo.get(i)!;
        if (seen.has(i)) return 0;
        seen.add(i);
        const tk = rawTasks[i];
        let best = 1;
        (tk.dependsOn || []).forEach((dep) => {
          const j = byId.get(dep);
          if (j !== undefined) best = Math.max(best, 1 + depth(j, seen));
        });
        seen.delete(i);
        memo.set(i, best);
        return best;
      };
      let longest = 0;
      rawTasks.forEach((tk, i) => { if ((tk.dependsOn || []).length) longest = Math.max(longest, depth(i, new Set())); });
      if (longest >= 2) {
        // mark tasks lying on SOME longest chain (greedy from the deepest)
        let end = -1, bd = -1;
        rawTasks.forEach((_, i) => { const dd = depth(i, new Set()); if (dd > bd) { bd = dd; end = i; } });
        let cur = end;
        const guard = new Set<number>();
        while (cur >= 0 && !guard.has(cur)) {
          guard.add(cur);
          crit.add(cur);
          const tk = rawTasks[cur];
          let nxt = -1, nd = -1;
          (tk.dependsOn || []).forEach((dep) => {
            const j = byId.get(dep);
            if (j !== undefined) { const dd = depth(j, new Set()); if (dd > nd) { nd = dd; nxt = j; } }
          });
          cur = nxt;
        }
      }
    }
    rawTasks.forEach((task, i) => {
      const sx = X(task._s);
      const ex = X(task._e);
      const barW = Math.max(8, ex - sx);
      const ry = padT + i * rowH;
      const barH = Math.max(15, rowH - 13);
      const by = ry + (rowH - barH) / 2;
      const on = hov.idx === i;
      const col = task.color || colors[i % colors.length] || '#0d7a54';
      const prg = Math.min(100, Math.max(0, task.progress ?? 100)) / 100;
      // WEDGE FIX: a progress width shorter than the bar's own height made
      // the 3D lozenge's hull centreline endpoints (fAx/fBx below) cross
      // over each other — the round-cap stroke degenerates into a pointed
      // sliver poking out past the bar for any low-progress task. Flooring
      // at barH (not a flat 4px) keeps the pill at least as wide as it is
      // tall, so the hull can never invert into a wedge, while barely
      // changing anything for any normal (wider) progress value.
      const pw = Math.max(Math.min(barW, barH), barW * prg * p);
      const pCol = on ? shade(col, 1 + 0.15 * hov.amt) : col;
      const isCrit = crit.has(i);
      const overdue = isDate && prg < 1 && task._e < nowMs;
      const laneCol = laneColors[laneOf[i] % laneColors.length];

      // swim-lane band: soft tint per category + hairline separators
      ctx.fillStyle = rgba(laneCol, i % 2 === 1 ? 0.07 : 0.045);
      ctx.fillRect(padL - 8, ry, chartW + 16, rowH);
      ctx.strokeStyle = rgba(t.ink, 0.06);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(padL - 8, ry + rowH); ctx.lineTo(padL + chartW + 8, ry + rowH); ctx.stroke();
      // lane label on its first row
      if (lanes[laneOf[i]].rows[0] === i && lanes.length > 1) {
        ctx.font = font(t, 700, 8.5);
        ctx.fillStyle = rgba(laneCol, 0.95);
        ctx.textAlign = 'left';
        ctx.fillText(lanes[laneOf[i]].name.toUpperCase(), padL + chartW - Math.min(150, measureW(ctx, lanes[laneOf[i]].name.toUpperCase()) + 4), ry + 11);
      }
      // duration pill at the bar's right end (date-aware: "12d" / "3w")
      {
        const durMs = task._e - task._s;
        const durDays = isDate ? Math.max(1, Math.round(durMs / 864e5)) : Math.max(1, Math.round(durMs));
        const durTxt = isDate ? (durDays >= 14 ? `${Math.round(durDays / 7)}w` : `${durDays}d`) : `${durDays}d`;
        const slackTxt = task.slackDays !== undefined && task.slackDays !== null
          ? ` · slack ${task.slackDays}d`
          : '';
        ctx.font = font(t, 600, 8.5);
        const pill = `${durTxt}${slackTxt}`;
        const pwPill = measureW(ctx, pill) + 12;
        const pillX = Math.min(sx + barW + 6, padL + chartW - pwPill);
        if (sx + barW + 6 < padL + chartW - 10 && barH >= 14) {
          ctx.fillStyle = rgba(t.ink, 0.07);
          ctx.beginPath(); ctx.roundRect(pillX, by + barH / 2 - 8, pwPill, 15, 7); ctx.fill();
          ctx.fillStyle = t.axis;
          ctx.textAlign = 'left';
          ctx.fillText(pill, pillX + 6, by + barH / 2 + 3);
        }
      }
      // dependency count badge at the bar's left edge ("⑂2")
      if ((task.dependsOn || []).length) {
        ctx.font = font(t, 700, 8.5);
        const depTxt = `\u2442${(task.dependsOn || []).length}`;
        const dw = measureW(ctx, depTxt) + 10;
        if (sx - dw - 16 > padL) {
          ctx.fillStyle = rgba(t.ink, 0.08);
          ctx.beginPath(); ctx.roundRect(sx - dw - 4, by + barH / 2 - 8, dw, 15, 7); ctx.fill();
          ctx.fillStyle = t.axis;
          ctx.textAlign = 'left';
          ctx.fillText(depTxt, sx - dw + 1, by + barH / 2 + 3);
        }
      }
      if (on) {
        ctx.fillStyle = rgba(t.ink, 0.05);
        ctx.beginPath(); ctx.roundRect(8, ry + 1, W - 16, rowH - 2, 6); ctx.fill();
      }

      // critical-path glow behind the bar
      if (isCrit) {
        ctx.save();
        setShadow(ctx, 0, 0, 10, rgba('#e11d63', 0.5));
        ctx.fillStyle = rgba('#e11d63', 0.10);
        ctx.beginPath(); ctx.roundRect(sx - 3, by - 3, barW + 6, barH + 6, (barH + 6) / 2); ctx.fill();
        ctx.restore();
      }

      // name + date range + avatar chip in the label gutter
      ctx.font = font(t, 600, 11);
      ctx.fillStyle = on ? t.ink : shade(t.ink, 0.85);
      ctx.textAlign = 'left';
      ctx.fillText(fitCtx(ctx, task.name, padL - 66), 16, by + barH * 0.42);
      ctx.font = font(t, 500, 9);
      ctx.fillStyle = t.axis;
      const rangeTxt = isDate
        ? `${new Date(task._s).toLocaleDateString('en', { month: 'short', day: 'numeric' })} → ${new Date(task._e).toLocaleDateString('en', { month: 'short', day: 'numeric' })}`
        : `Day ${Math.round(task._s)} → ${Math.round(task._e)}`;
      ctx.fillText(fitCtx(ctx, rangeTxt, padL - 66), 16, by + barH * 0.42 + 12);
      if (task.assignee) {
        const init = task.assignee.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();
        const ax = padL - 30, ay = by + barH / 2;
        ctx.fillStyle = shade(col, 0.85);
        ctx.beginPath(); ctx.arc(ax, ay, 9, 0, Math.PI * 2); ctx.fill();
        ctx.font = font(t, 700, 8);
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
        ctx.fillText(init, ax, ay + 2.8);
        ctx.textAlign = 'left';
      }

      // baseline ghost (thin grey bar under the plan)
      if (task._bS !== undefined && task._bE !== undefined) {
        const bsx = X(task._bS), bex = X(task._bE);
        ctx.fillStyle = rgba(t.ink, 0.22);
        ctx.beginPath(); ctx.roundRect(bsx, by + barH + 1.5, Math.max(4, bex - bsx), 3, 1.5); ctx.fill();
      }

      // milestone diamond (zero-duration or flagged) — in 3D a true
      // diamond PRISM: back face + two visible side faces via ZP, glass front.
      if (task.milestone || task._e - task._s <= 1) {
        const dx = sx + (task.milestone ? barW / 2 : 0), dyy = by + barH / 2, rr = barH * 0.52;
        const zDia = Math.min(13, Math.max(7, barH * 0.6));
        const dT = ZP(dx, dyy - rr, zDia), dR = ZP(dx + rr, dyy, zDia),
          dB = ZP(dx, dyy + rr, zDia), dL = ZP(dx - rr, dyy, zDia);
        ctx.save();
        if (m > 0.02) { setShadow(ctx, 2 * m, 3 * m, 6, rgba(t.ink, 0.25 * m)); }
        if (m > 0.02) {
          // side faces (right flank darker than top flank)
          ctx.fillStyle = shade(pCol, 0.55);
          ctx.beginPath();
          ctx.moveTo(dx + rr, dyy); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dB[0], dB[1]); ctx.lineTo(dx, dyy + rr);
          ctx.closePath(); ctx.fill();
          ctx.fillStyle = shade(pCol, 0.8);
          ctx.beginPath();
          ctx.moveTo(dx, dyy - rr); ctx.lineTo(dT[0], dT[1]); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dx + rr, dyy);
          ctx.closePath(); ctx.fill();
        }
        const mg = ctx.createLinearGradient(0, dyy - rr, 0, dyy + rr);
        mg.addColorStop(0, shade(pCol, 1.3)); mg.addColorStop(1, shade(pCol, 0.75));
        ctx.fillStyle = mg;
        ctx.beginPath();
        if (m > 0.02) {
          ctx.moveTo(dT[0], dT[1]); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dB[0], dB[1]); ctx.lineTo(dL[0], dL[1]);
        } else {
          ctx.moveTo(dx, dyy - rr); ctx.lineTo(dx + rr, dyy); ctx.lineTo(dx, dyy + rr); ctx.lineTo(dx - rr, dyy);
        }
        ctx.closePath(); ctx.fill();
        ctx.restore();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
      } else if (m > 0.02) {
        // contact shadow for the whole group
        ctx.save();
        setShadow(ctx, 0, 3 * m + 1, 7, rgba(t.ink, 0.22 * m));
        ctx.fillStyle = rgba(t.ink, 0.10 * m);
        ctx.beginPath(); ctx.roundRect(sx + gOx * 0.4, by + gOy * 0.4 + 2 * m, barW, barH, barH / 2); ctx.fill();
        ctx.restore();
        // recessed track groove (dark inset rail)
        ctx.fillStyle = rgba(t.ink, 0.10 + 0.04 * m);
        ctx.beginPath(); ctx.roundRect(sx, by, barW, barH, barH / 2); ctx.fill();
        ctx.strokeStyle = rgba('#ffffff', 0.35);
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(sx + 0.5, by + barH - 1.5, barW - 1, 1.2, 1); ctx.stroke();
        // Progress lozenge: a ROUNDED extrusion built as the exact silhouette
        // HULL of the front and back pills — one thick round-join stroke of
        // the two centrelines' hull (a stadium is the Minkowski sum of its
        // centreline and a disc, so stroking the hull quad with barH
        // reproduces the union exactly). The old stack of offset roundRect
        // slices let the dark far pill's round caps peek out around BOTH
        // ends of the front pill — the little wedge slivers that stuck out
        // of the bars in 3D.
        const zBar = Math.min(13, Math.max(7, barH * 0.72));
        const [oxB, oyB] = ZP(0, 0, zBar);
        const rC = barH / 2;
        const fAx = sx + rC, fAy = by + rC;              // front centreline left
        const fBx = sx + pw - rC, fBy = by + rC;         // front centreline right
        const bAx = fAx + oxB, bAy = fAy + oyB;          // back centreline left
        const bBx = fBx + oxB, bBy = fBy + oyB;          // back centreline right
        ctx.save();
        ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        // 1) full extrusion body — dark side wall (exact hull silhouette)
        ctx.strokeStyle = shade(pCol, 0.52);
        ctx.lineWidth = barH;
        ctx.beginPath();
        ctx.moveTo(fAx, fAy); ctx.lineTo(fBx, fBy); ctx.lineTo(bBx, bBy); ctx.lineTo(bAx, bAy);
        ctx.closePath(); ctx.stroke();
        // 2) the roof (top face): a FILLED quad from the front centreline to
        // the back centreline, PLUS its own round end caps at the back
        // vertices. Drawing this as a bare stroke used to leave the dark
        // side-wall's round caps at bAx/bBx showing raw past the quad's
        // straight edges — a mismatched-colour sliver poking out beyond the
        // rounded end of the bar (the wedge from the screenshot). Filling
        // the whole quad AND re-painting full circles over both back
        // vertices with the same mid-tone recolours those caps so nothing
        // but the intended lit roof is ever visible past the front face.
        ctx.strokeStyle = shade(pCol, 0.85);
        ctx.fillStyle = shade(pCol, 0.85);
        ctx.beginPath();
        ctx.moveTo(fAx, fAy); ctx.lineTo(fBx, fBy); ctx.lineTo(bBx, bBy); ctx.lineTo(bAx, bAy);
        ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.arc(bAx, bAy, rC, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(bBx, bBy, rC, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.moveTo(bAx, bAy); ctx.lineTo(bBx, bBy); ctx.stroke();
        ctx.restore();
        // top sheen slice: one bright rounded cap just under the glass front
        {
          const [ox3, oy3] = ZP(0, 0, zBar * 0.12);
          ctx.fillStyle = shade(pCol, 1.18);
          ctx.beginPath(); ctx.roundRect(sx + ox3, by + oy3, pw, Math.max(2, barH * 0.42), barH * 0.21); ctx.fill();
        }
        const gg = ctx.createLinearGradient(0, by, 0, by + barH);
        gg.addColorStop(0, shade(pCol, 1.22));
        gg.addColorStop(0.45, pCol);
        gg.addColorStop(1, shade(pCol, 0.74));
        ctx.fillStyle = gg;
        ctx.beginPath(); ctx.roundRect(sx, by, pw, barH, barH / 2); ctx.fill();
        // specular gloss band across the upper third
        ctx.fillStyle = 'rgba(255,255,255,0.30)';
        ctx.beginPath(); ctx.roundRect(sx + 3, by + 2.5, Math.max(1, pw - 6), Math.max(1, barH * 0.3), barH * 0.15); ctx.fill();
        ctx.strokeStyle = rgba('#ffffff', 0.55);
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(sx + 0.5, by + 0.5, pw - 1, barH - 1, barH / 2 - 0.5); ctx.stroke();
        // progress pip at the leading edge of the lozenge
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(sx + pw - 1, by + barH / 2, Math.max(1.6, barH * 0.14), 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = pCol;
        ctx.beginPath(); ctx.arc(sx + pw - 1, by + barH / 2, Math.max(1, barH * 0.09), 0, Math.PI * 2); ctx.fill();
        // overdue: diagonal hatch over the unworked remainder
        if (overdue) {
          ctx.save();
          ctx.beginPath(); ctx.roundRect(sx + pw, by, Math.max(0, barW - pw), barH, 4); ctx.clip();
          ctx.strokeStyle = rgba('#e11d63', 0.5);
          ctx.lineWidth = 1.4;
          for (let hx = sx + pw - barH; hx < sx + barW + barH; hx += 6) {
            ctx.beginPath(); ctx.moveTo(hx, by + barH); ctx.lineTo(hx + barH, by); ctx.stroke();
          }
          ctx.restore();
        }
        // status dot: green = done, amber = in flight, grey = not started,
        // red ring when overdue
        const stCol = overdue ? '#e11d63' : prg >= 1 ? '#16a34a' : prg > 0 ? '#d97706' : '#9ca3af';
        ctx.fillStyle = stCol;
        ctx.beginPath(); ctx.arc(sx - 9, by + barH / 2, 3.2, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
        // dependency links from EXPLICIT dependsOn (finish-to-start elbows)
        // — lifted onto the bar-face plane (z = zBar·0.5) so arrowheads plug
        // into the 3D faces instead of floating behind them.
        (task.dependsOn || []).forEach((dep) => {
          const j = byId.get(dep);
          if (j === undefined || j === i) return;
          const fromX = X(rawTasks[j]._e);
          const py = padT + j * rowH + rowH / 2;
          const cy2 = by + barH / 2;
          const hot = crit.has(i) && crit.has(j);
          const midX = Math.max(fromX + 6, sx - 14);
          const zEl = Math.min(13, Math.max(7, barH * 0.72)) * 0.5;
          const e0 = ZP(fromX, py, zEl), e1 = ZP(midX, py, zEl),
            e2 = ZP(midX, cy2, zEl), e3 = ZP(sx - 2, cy2, zEl);
          ctx.save();
          ctx.strokeStyle = hot ? '#e11d63' : rgba(t.ink, 0.35);
          ctx.lineWidth = hot ? 1.8 : 1.2;
          if (!hot) ctx.setLineDash([3, 2.5]);
          ctx.beginPath();
          ctx.moveTo(e0[0], e0[1]);
          ctx.lineTo(e1[0], e1[1]);
          ctx.lineTo(e2[0], e2[1]);
          ctx.lineTo(e3[0], e3[1]);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.fillStyle = hot ? '#e11d63' : rgba(t.ink, 0.5);
          ctx.beginPath();
          ctx.moveTo(e3[0], e3[1]);
          ctx.lineTo(e3[0] - 5, e3[1] - 3);
          ctx.lineTo(e3[0] - 5, e3[1] + 3);
          ctx.closePath(); ctx.fill();
          ctx.restore();
        });
      } else {
        // Fix #7: fully rounded pill edges in 2D to match the flattened
        // projection of the 3D design (which uses barH/2 everywhere).
        const pillR = barH / 2;
        ctx.fillStyle = rgba(col, 0.2);
        ctx.beginPath(); ctx.roundRect(sx, by, barW, barH, pillR); ctx.fill();
        // (The green/amber "effort vs elapsed" mini-track that used to sit
        // under each 2D pill was removed per product request — the status
        // dot before the bar already carries schedule health.)
        ctx.fillStyle = on ? shade(col, 1.15) : col;
        ctx.beginPath(); ctx.roundRect(sx, by, pw, barH, Math.min(pillR, pw / 2)); ctx.fill();
        ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
        ctx.beginPath(); ctx.roundRect(sx, by, Math.max(1, pw), barH / 2, [Math.min(pillR, pw / 2), Math.min(pillR, pw / 2), 0, 0]); ctx.fill();
        // owner avatar overlapping the bar's leading edge (2D + 3D alike)
        if (task.assignee && barW > 30) {
          const init2 = task.assignee.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();
          const ox = sx + 9, oy = by + barH / 2;
          ctx.fillStyle = '#ffffff';
          ctx.beginPath(); ctx.arc(ox, oy, 7.5, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = shade(col, 0.7);
          ctx.beginPath(); ctx.arc(ox, oy, 6.2, 0, Math.PI * 2); ctx.fill();
          ctx.font = font(t, 700, 7);
          ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
          ctx.fillText(init2, ox, oy + 2.4);
          ctx.textAlign = 'left';
        }
        // start/end date caps under long bars
        if (isDate && barW > 120) {
          ctx.font = font(t, 600, 8);
          ctx.fillStyle = t.axis;
          ctx.textAlign = 'left';
          const sCap = new Date(task._s).toLocaleDateString('en', { month: 'short', day: 'numeric' });
          const eCap = new Date(task._e).toLocaleDateString('en', { month: 'short', day: 'numeric' });
          ctx.fillText(sCap, sx + 2, by + barH + 10);
          ctx.textAlign = 'right';
          ctx.fillText(eCap, sx + barW - 2, by + barH + 10);
          ctx.textAlign = 'left';
        }
        if (overdue) {
          ctx.save();
          ctx.beginPath(); ctx.roundRect(sx + pw, by, Math.max(0, barW - pw), barH, 4); ctx.clip();
          ctx.strokeStyle = rgba('#e11d63', 0.5);
          ctx.lineWidth = 1.4;
          for (let hx = sx + pw - barH; hx < sx + barW + barH; hx += 6) {
            ctx.beginPath(); ctx.moveTo(hx, by + barH); ctx.lineTo(hx + barH, by); ctx.stroke();
          }
          ctx.restore();
        }
        // status dot + dependency links in 2D as well (same language)
        const stCol2 = overdue ? '#e11d63' : prg >= 1 ? '#16a34a' : prg > 0 ? '#d97706' : '#9ca3af';
        ctx.fillStyle = stCol2;
        ctx.beginPath(); ctx.arc(sx - 9, by + barH / 2, 3.2, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
        (task.dependsOn || []).forEach((dep) => {
          const j = byId.get(dep);
          if (j === undefined || j === i) return;
          const fromX = X(rawTasks[j]._e);
          const py = padT + j * rowH + rowH / 2;
          const cy2 = by + barH / 2;
          const hot = crit.has(i) && crit.has(j);
          const midX = Math.max(fromX + 6, sx - 14);
          ctx.save();
          ctx.strokeStyle = hot ? '#e11d63' : rgba(t.ink, 0.35);
          ctx.lineWidth = hot ? 1.8 : 1.2;
          if (!hot) ctx.setLineDash([3, 2.5]);
          ctx.beginPath();
          ctx.moveTo(fromX, py);
          ctx.lineTo(midX, py);
          ctx.lineTo(midX, cy2);
          ctx.lineTo(sx - 2, cy2);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.fillStyle = hot ? '#e11d63' : rgba(t.ink, 0.5);
          ctx.beginPath();
          ctx.moveTo(sx - 2, cy2);
          ctx.lineTo(sx - 7, cy2 - 3);
          ctx.lineTo(sx - 7, cy2 + 3);
          ctx.closePath(); ctx.fill();
          ctx.restore();
        });
      }

      if (barW > 35 && !(task.milestone || task._e - task._s <= 1)) {
        ctx.fillStyle = '#ffffff'; ctx.font = font(t, 700, 9.5); ctx.textAlign = 'center';
        ctx.fillText(`${Math.round(prg * 100)}%`, sx + pw / 2, by + barH * 0.7);
      }
      if (isCrit) {
        ctx.font = font(t, 700, 8);
        ctx.fillStyle = '#e11d63'; ctx.textAlign = 'left';
        ctx.fillText('CRITICAL', sx + barW + 6, by + barH * 0.68);
      }
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ SCATTER PLOT (2D + 3D room: floor, stems, shaded spheres) ============ */
  if (kind === 'scatter') {
    const rawScatter: ScatterPoint[] = d.scatter && d.scatter.length ? d.scatter : (
      data.map((x, i) => ({
        x: 20 + i * 8 + ((i * 13) % 19),
        y: x.value,
        label: x.label,
        size: 7 + ((i * 3) % 5),
        color: colors[i % colors.length],
      }))
    );

    const padL = 52, padR = 24, padT = 34, padB = 40;
    const plotW = W - padL - padR, plotH = H - padT - padB;
    const xs = rawScatter.map((pt) => pt.x);
    const ys = rawScatter.map((pt) => pt.y);
    const minX = Math.min(...xs, 0), maxX = Math.max(...xs, minX + 1);
    const minY = Math.min(...ys, 0), maxY = Math.max(...ys, minY + 1);

    const sOx = 16 * m, sOy = 12 * m;
    drawAxes(ctx, W, H, { l: padL, r: padR, t: padT, b: padB }, maxY, t, sOx, sOy);

    const xSteps = 5;
    ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center';
    for (let s = 0; s <= xSteps; s++) {
      const val = minX + ((maxX - minX) * s) / xSteps;
      const gx = padL + (plotW * s) / xSteps;
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      if (m > 0.02) { ctx.moveTo(gx, padT + plotH); ctx.lineTo(gx + sOx, padT + plotH - sOy); ctx.lineTo(gx + sOx, padT - sOy); }
      else { ctx.moveTo(gx, padT); ctx.lineTo(gx, padT + plotH); }
      ctx.stroke();
      ctx.fillStyle = t.axis; ctx.fillText(fmtNum(val), gx + (m > 0.02 ? sOx / 2 : 0), padT + plotH + 18);
    }
    ctx.textAlign = 'left';
    // 3D floor wash so the room reads
    if (m > 0.02) {
      ctx.fillStyle = rgba(t.ink, 0.05 * m);
      ctx.beginPath();
      ctx.moveTo(padL, padT + plotH); ctx.lineTo(padL + sOx, padT + plotH - sOy);
      ctx.lineTo(padL + plotW + sOx, padT + plotH - sOy); ctx.lineTo(padL + plotW, padT + plotH);
      ctx.closePath(); ctx.fill();
    }

    // Linear regression trendline
    if (rawScatter.length >= 2) {
      const n = rawScatter.length;
      const sumX = xs.reduce((a, b) => a + b, 0), sumY = ys.reduce((a, b) => a + b, 0);
      const sumXY = rawScatter.reduce((a, pt) => a + pt.x * pt.y, 0);
      const sumX2 = xs.reduce((a, b) => a + b * b, 0);
      const slope = (n * sumXY - sumX * sumY) / Math.max(1e-6, n * sumX2 - sumX * sumX);
      const intercept = (sumY - slope * sumX) / n;
      const px0 = padL, py0 = padT + plotH - ((intercept + slope * minX - minY) / (maxY - minY)) * plotH;
      const px1 = padL + plotW, py1 = padT + plotH - ((intercept + slope * maxX - minY) / (maxY - minY)) * plotH;
      ctx.strokeStyle = rgba(t.axis, 0.4); ctx.lineWidth = 1.5; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(px0, py0); ctx.lineTo(px1, py1); ctx.stroke();
      ctx.setLineDash([]);
    }

    // Painter's order in 3D: far (small y-value → back) first so near spheres overlap correctly
    const sOrder = rawScatter.map((_, i) => i).sort((a, b) => (m > 0.02 ? rawScatter[a].y - rawScatter[b].y : a - b));
    sOrder.forEach((i) => {
      const pt = rawScatter[i];
      const lift = m > 0.02 ? (pt.size || 7) * 0.9 * m : 0;
      const px = padL + ((pt.x - minX) / (maxX - minX)) * plotW + (m > 0.02 ? sOx * 0.5 : 0);
      const py = padT + plotH - ((pt.y - minY) / (maxY - minY)) * plotH - (m > 0.02 ? sOy * 0.5 : 0) - lift;
      const baseR = pt.size || 7;
      const rad = Math.max(1.5, baseR * Math.max(0.05, p));
      const on = hov.idx === i;
      const col = pt.color || colors[i % colors.length] || '#0d7a54';

      if (m > 0.02) {
        // drop stem from sphere to floor + contact ellipse: classic 3D scatter depth cue
        const fx = px, fy = padT + plotH - sOy * 0.35;
        ctx.strokeStyle = rgba(col, 0.45);
        ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(px, py + rad * 0.8); ctx.lineTo(fx, fy); ctx.stroke();
        ctx.fillStyle = rgba(t.ink, 0.16 * m);
        ctx.beginPath(); ctx.ellipse(fx, fy, rad * 0.85, rad * 0.32, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = rgba(col, 0.30);
        ctx.beginPath(); ctx.ellipse(fx, fy, rad * 0.55, rad * 0.2, 0, 0, Math.PI * 2); ctx.fill();
      }

      if (on) {
        ctx.strokeStyle = rgba(col, 0.5); ctx.lineWidth = 1; ctx.setLineDash([2, 2]);
        ctx.beginPath(); ctx.moveTo(padL, py); ctx.lineTo(padL + plotW, py); ctx.moveTo(px, padT); ctx.lineTo(px, padT + plotH); ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = rgba(col, 0.2); ctx.beginPath(); ctx.arc(px, py, rad + 6 + 3 * m, 0, Math.PI * 2); ctx.fill();
      }

      // shaded sphere: stronger light model in 3D + crisp specular dot
      const rr = on ? rad + 2 * hov.amt : rad;
      const r0 = Math.max(0.1, rr * 0.12);
      const g = ctx.createRadialGradient(px - rr * 0.35, py - rr * 0.4, r0, px, py, rr);
      g.addColorStop(0, shade(col, m > 0.02 ? 1.55 : 1.35));
      g.addColorStop(0.55, shade(col, on ? 1 + 0.12 * hov.amt : 1));
      g.addColorStop(1, shade(col, m > 0.02 ? 0.55 : 0.85));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, rr, 0, Math.PI * 2); ctx.fill();
      if (m > 0.02) {
        ctx.fillStyle = rgba('#ffffff', 0.85);
        ctx.beginPath(); ctx.arc(px - rr * 0.34, py - rr * 0.4, Math.max(0.8, rr * 0.16), 0, Math.PI * 2); ctx.fill();
      }
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1; ctx.stroke();
      // Labels: hovered point always; otherwise a decluttered subset —
      // greedy min-distance pass in 3D so dense clouds stay readable.
      (pt as ScatterPoint & { _lx?: number; _ly?: number })._lx = px;
      (pt as ScatterPoint & { _lx?: number; _ly?: number })._ly = py - rr - 6;
    });
    // second pass: collision-free labels (3D dense-data fix)
    const labelPts = sOrder
      .map((i) => ({ i, pt: rawScatter[i] }))
      .filter(({ pt, i }) => hov.idx === i || (m > 0.02 && pt.label && pt.label.trim().length > 0));
    const placed: { x: number; y: number; w: number }[] = [];
    ctx.font = font(t, 700, 9.5); ctx.textAlign = 'center';
    // hovered first so it always wins collisions
    labelPts.sort((a, b) => (hov.idx === b.i ? 1 : 0) - (hov.idx === a.i ? 1 : 0));
    labelPts.forEach(({ i, pt }) => {
      const on = hov.idx === i;
      const px = (pt as ScatterPoint & { _lx?: number })._lx ?? 0;
      const py = (pt as ScatterPoint & { _ly?: number })._ly ?? 0;
      const shown = fitCtx(ctx, pt.label || `(${fmtNum(pt.x)}, ${fmtNum(pt.y)})`, 90);
      const w = measureW(ctx, shown) + 8;
      if (!on) {
        for (const q of placed) {
          if (Math.abs(q.x - px) < (q.w + w) / 2 && Math.abs(q.y - py) < 13) return;
        }
        if (m <= 0.02) return; // 2D keeps hover-only labels (unchanged behaviour)
      }
      placed.push({ x: px, y: py, w });
      ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.82);
      const tw = measureW(ctx, shown);
      ctx.beginPath(); ctx.roundRect(px - tw / 2 - 4, py - 10, tw + 8, 14, 7); ctx.fill();
      ctx.fillStyle = on ? t.ink : t.axis;
      ctx.fillText(shown, px, py + 1);
    });
    return;
  }

    /* ============ STREAMGRAPH (Highcharts-style · TRUE 2D + TRUE 3D, canvas) ============
     Ground-up rebuild, no Three.js. 2D = the Highcharts streamgraph look:
     symmetric organic river, onset-ordered layers, flat solid fills, crisp
     hairline partings, hover crosshair + markers, in-stream labels, event
     flags. 3D = the SAME river as stacked glossy slabs (per-layer walls,
     rims, end caps, floor shadows) with a continuous 2D⇄3D morph. */
  if (kind === 'stream') {
    const gm = streamGeom(multi, cats, series, sColors, data, colors, activePalette(), W, H, full);
    if (!gm) return;
    const { list, labels, xs, bound, order, padT, plotH } = gm;
    const n = labels.length;
    const traceBound = (b: number[], dx = 0, dy = 0, upto = n) => {
      const lim = Math.max(2, Math.min(n, upto));
      ctx.moveTo(xs[0] + dx, b[0] + dy);
      if (lim === 2) { ctx.lineTo(xs[1] + dx, b[1] + dy); return; }
      for (let j = 0; j < lim - 1; j++) {
        const p0y = b[Math.max(0, j - 1)], p1y = b[j], p2y = b[j + 1], p3y = b[Math.min(n - 1, j + 2)];
        const p0x = xs[Math.max(0, j - 1)], p2x = xs[j + 1];
        const p1x = xs[j], p3x = xs[Math.min(n - 1, j + 2)];
        ctx.bezierCurveTo(
          p1x + dx + (p2x - p0x) / 6, p1y + dy + (p2y - p0y) / 6,
          xs[j + 1] + dx - (p3x - p1x) / 6, p2y + dy - (p3y - p1y) / 6,
          xs[j + 1] + dx, p2y + dy);
      }
    };
    const traceBoundBack = (b: number[], dx = 0, dy = 0, upto = n) => {
      const lim = Math.max(2, Math.min(n, upto));
      for (let j = lim - 1; j > 0; j--) {
        const p0y = b[Math.min(n - 1, j + 1)], p1y = b[j], p2y = b[j - 1], p3y = b[Math.max(0, j - 2)];
        const p0x = xs[Math.min(n - 1, j + 1)], p2x = xs[j - 1];
        const p1x = xs[j], p3x = xs[Math.max(0, j - 2)];
        ctx.bezierCurveTo(
          p1x + dx + (p2x - p0x) / 6, p1y + dy + (p2y - p0y) / 6,
          xs[j - 1] + dx - (p3x - p1x) / 6, p2y + dy - (p3y - p1y) / 6,
          xs[j - 1] + dx, p2y + dy);
      }
    };
    // column gridlines + rotated year axis (Highcharts has a bare plot area;
    // ours keeps the family's faint grid + the shared x-label planner).
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    xs.forEach((x) => {
      ctx.beginPath(); ctx.moveTo(x, padT - 4); ctx.lineTo(x, padT + plotH + 4); ctx.stroke();
    });
    drawXLabels(ctx, labels, gm.plan, (j) => xs[j], padT + plotH, t, W);
    const activeS = hov.seg ? hov.seg.s : (hov.idx !== null ? hov.idx : null);
    const activeC = hov.seg ? hov.seg.c : null;
    const sFocused = activeS !== null;
    const dzS = 9 * m, dyS = 7 * m;
    const upto = Math.max(2, Math.ceil(n * easeOut(p)));
    const B = bound;
    const flat = m < 0.02;
    // ---- 3D floor shadow of the whole silhouette ----
    if (!flat) {
      ctx.save();
      setShadow(ctx, 0, 7 * m + 2, 14, rgba(t.ink, 0.18 * m));
      ctx.fillStyle = rgba(t.ink, 0.10 * m);
      ctx.beginPath();
      traceBound(B[0], dzS * 0.7, -dyS * 0.7 + 10 * m, upto);
      traceBoundBack(B[B.length - 1], dzS * 0.7, -dyS * 0.7 + 10 * m, upto);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    // ---- 3D slab walls, back layer first ----
    if (!flat) {
      for (let k = order.length - 1; k >= 0; k--) {
        const si = order[k];
        const b1 = B[k + 1], b0w = B[k];
        const on = activeS === si;
        const aMul = sFocused && !on ? 1 - 0.55 * hov.amt : 1;
        ctx.save();
        ctx.globalAlpha *= aMul;
        // recessed groove along the band's lower edge (paper-cut separation)
        ctx.strokeStyle = rgba(t.ink, 0.32 * m);
        ctx.lineWidth = 5; ctx.lineCap = 'round';
        ctx.beginPath();
        traceBound(b0w, dzS * 0.55, -dyS * 0.55 + 3.5, upto);
        ctx.stroke();
        ctx.lineCap = 'butt';
        // riser wall along the band's top edge (paper side, darker)
        ctx.fillStyle = shade(list[si].color, 0.50);
        ctx.beginPath();
        traceBound(b1, dzS, -dyS, upto);
        traceBoundBack(b1, 0, 0, upto);
        ctx.closePath(); ctx.fill();
        // front wall swept toward the viewer (the visible stacked strip)
        ctx.fillStyle = shade(list[si].color, 0.44);
        ctx.beginPath();
        traceBound(b0w, 0, 0, upto);
        traceBoundBack(b0w, dzS, -dyS + 4, upto);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = rgba(shade(list[si].color, 0.32), 0.9);
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        traceBound(b0w, dzS, -dyS + 4, upto);
        ctx.stroke();
        // bright rim where the riser meets the top skin
        ctx.strokeStyle = rgba('#ffffff', 0.55 * m);
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        traceBound(b1, dzS, -dyS, upto);
        ctx.stroke();
        // second inner rim: the card's cut edge catching the light
        ctx.strokeStyle = rgba('#ffffff', 0.28 * m);
        ctx.lineWidth = 1;
        ctx.beginPath();
        traceBound(b1, dzS * 0.45, -dyS * 0.45 + 1.5, upto);
        ctx.stroke();
        // end cap at the final column + toe shadow
        const ex = xs[Math.min(n - 1, upto - 1)];
        const yT = b1[Math.min(n - 1, upto - 1)], yB = b0w[Math.min(n - 1, upto - 1)];
        ctx.fillStyle = shade(list[si].color, 0.5);
        ctx.beginPath();
        ctx.moveTo(ex, yT); ctx.lineTo(ex + dzS, yT - dyS);
        ctx.lineTo(ex + dzS, yB - dyS); ctx.lineTo(ex, yB);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = rgba(t.ink, 0.12 * m);
        ctx.beginPath();
        ctx.moveTo(ex, yB); ctx.lineTo(ex + dzS, yB - dyS);
        ctx.lineTo(ex + dzS + 3, yB - dyS + 3); ctx.lineTo(ex + 3, yB + 3);
        ctx.closePath(); ctx.fill();
        ctx.restore();
      }
    }
    // ---- faces: bottom layer first so upper layers overlap naturally ----
    const labelJobs: { si: number; dim: number; cx: number; x: number; w: number }[] = [];
    order.forEach((si) => {
      const k = order.indexOf(si);
      const b0 = B[k], b1 = B[k + 1];
      const on = activeS === si;
      const dim = sFocused && !on ? 1 - 0.62 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= dim;
      if (flat) {
        // Highcharts streamgraph: flat solid colour, gentle brighten on hover
        ctx.fillStyle = shade(list[si].color, on ? 1 + 0.14 * hov.amt : 1);
        ctx.globalAlpha *= 0.92;
      } else {
        // paper-cut 3D (reference look): each band is a thin card with a
        // bright LIT top skin, a saturated core and a deep paper edge; the
        // ramp is LOCAL to this band so every layer reads separately.
        const jm = Math.floor(n / 2);
        const gTop = b1[jm], gBot = Math.max(gTop + 2, b0[jm]);
        const grad = ctx.createLinearGradient(0, gTop, 0, gBot);
        const lift = on ? 0.10 * hov.amt : 0;
        grad.addColorStop(0, shade(list[si].color, 1.34 + lift));
        grad.addColorStop(0.28, shade(list[si].color, 1.10 + lift));
        grad.addColorStop(0.62, shade(list[si].color, 0.92));
        grad.addColorStop(1, shade(list[si].color, 0.62));
        ctx.fillStyle = grad;
      }
      ctx.beginPath();
      traceBound(b1, 0, 0, upto);
      traceBoundBack(b0, 0, 0, upto);
      ctx.closePath(); ctx.fill();
      ctx.restore();
      // crisp parting line between bands (+ white halo on the hovered layer)
      ctx.save();
      ctx.globalAlpha *= dim;
      ctx.strokeStyle = flat ? rgba('#ffffff', 0.85) : rgba('#ffffff', 0.7);
      ctx.lineWidth = flat ? 1.5 : 1;
      ctx.beginPath();
      traceBound(b1, 0, 0, upto);
      ctx.stroke();
      if (on) {
        ctx.strokeStyle = rgba('#ffffff', 0.95);
        ctx.lineWidth = flat ? 2.5 : 2;
        ctx.beginPath();
        traceBound(b1, 0, 0, upto);
        ctx.stroke();
      }
      ctx.restore();
      // in-stream label candidate at the layer's widest column
      let wj = 0, ww = -1;
      for (let j = 0; j < n; j++) { const w = b0[j] - b1[j]; if (w > ww) { ww = w; wj = j; } }
      labelJobs.push({ si, dim, cx: (b0[wj] + b1[wj]) / 2, x: xs[wj], w: ww });
    });
    // ---- Highcharts crosshair: vertical line + per-layer markers + total ----
    if (activeC !== null && activeC >= 0 && activeC < n && p > 0.9) {
      const j = activeC;
      const fx = xs[j];
      const yTop = Math.min(...B.map((b) => b[j]));
      const yBot = Math.max(...B.map((b) => b[j]));
      ctx.save();
      ctx.strokeStyle = rgba(t.ink, 0.45);
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(fx, yTop - 8); ctx.lineTo(fx, padT + plotH + 2); ctx.stroke();
      ctx.setLineDash([]);
      // markers on every visible layer boundary at this column
      order.forEach((si) => {
        const k = order.indexOf(si);
        if (k < 0) return;
        const yT = B[k + 1][j], yB = B[k][j];
        if (yB - yT < 3) return;
        const mid = (yT + yB) / 2;
        ctx.fillStyle = list[si].color;
        ctx.beginPath(); ctx.arc(fx, mid, si === activeS ? 4.2 : 3, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
      });
      // total chip above the river
      const tot = gm.totals[j] || 0;
      const tTxt = `${labels[j]} · ${fmtNum(tot)}`;
      ctx.font = font(t, 700, 10.5);
      const tw = measureW(ctx, tTxt);
      const chx = Math.max(tw / 2 + 8, Math.min(W - tw / 2 - 8, fx));
      const chy = Math.max(16, yTop - 14);
      ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
      ctx.strokeStyle = rgba(t.ink, 0.22); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(chx - tw / 2 - 7, chy - 11, tw + 14, 18, 9); ctx.fill(); ctx.stroke();
      ctx.fillStyle = t.ink; ctx.textAlign = 'center';
      ctx.fillText(tTxt, chx, chy + 2);
      ctx.restore();
    }
    // ---- in-stream labels: widest bands win, never overlap ----
    // Reference look: white pills with ink text floating ON the band.
    labelJobs.sort((a, b) => b.w - a.w);
    const taken: { x0: number; x1: number; y0: number; y1: number }[] = [];
    labelJobs.forEach(({ si, dim, cx, x, w }) => {
      if (w < 22 || p <= 0.9) return;
      const flat = m < 0.02;
      const fs = w > 44 ? (full ? 12 : 11.5) : 10;
      ctx.font = font(t, 700, fs);
      const nm = fitCtx(ctx, list[si].name, Math.max(44, plotH / 6));
      const tw = measureW(ctx, nm);
      const pwP = tw + 16, phP = fs + 8;
      const box = { x0: x - pwP / 2, x1: x + pwP / 2, y0: cx - phP / 2, y1: cx + phP / 2 };
      if (box.x0 < 6 || box.x1 > W - 6) return;
      for (const q of taken) {
        if (box.x0 < q.x1 && box.x1 > q.x0 && box.y0 < q.y1 && box.y1 > q.y0) return;
      }
      taken.push(box);
      ctx.save();
      ctx.globalAlpha *= dim;
      ctx.font = font(t, 700, fs);
      ctx.textAlign = 'center';
      if (flat) {
        // 2D: white pill + ink text (reference look)
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.20)'; ctx.shadowBlur = 4; ctx.shadowOffsetY = 1;
        ctx.fillStyle = 'rgba(255,255,255,0.95)';
        ctx.beginPath(); ctx.roundRect(box.x0, box.y0, pwP, phP, phP / 2); ctx.fill();
        ctx.restore();
        ctx.fillStyle = shade(list[si].color, 0.55);
        ctx.fillText(nm, x, cx + fs * 0.35);
      } else {
        // 3D: ink-on-frost pill so it reads over the glossy skin
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.30)'; ctx.shadowBlur = 5; ctx.shadowOffsetY = 2;
        ctx.fillStyle = 'rgba(255,255,255,0.92)';
        ctx.beginPath(); ctx.roundRect(box.x0, box.y0, pwP, phP, phP / 2); ctx.fill();
        ctx.restore();
        ctx.fillStyle = shade(list[si].color, 0.45);
        ctx.fillText(nm, x, cx + fs * 0.35);
      }
      ctx.restore();
    });
    // ---- event flags: default to the salary-story events when the dataset
    // carries none (built-in demo), staggered bubble lanes above the river ----
    const evts = ((d.streamEvents && d.streamEvents.length ? d.streamEvents : STREAM_SALARY_10Y.events).filter((e) => e.at >= 0 && e.at < n));
    const riverTopAt = (j: number) => Math.min(...B.map((b) => b[Math.max(0, Math.min(n - 1, j))]));
    const riverBotAt = (j: number) => Math.max(...B.map((b) => b[Math.max(0, Math.min(n - 1, j))]));
    const placedEv: { x0: number; x1: number; lane: number }[] = [];
    evts.forEach((e) => {
      const jj0 = Math.round(e.at);
      const fx = xs[jj0];
      ctx.save();
      // anchor dot sits ON the river's top surface (never floating above it)
      const surfY = riverTopAt(jj0);
      const botY = riverBotAt(jj0);
      const anchorY = Math.max(padT + 2, Math.min(padT + plotH - 2, surfY));
      void botY;
      ctx.strokeStyle = rgba(t.ink, 0.4); ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(fx, anchorY); ctx.lineTo(fx, padT - 6); ctx.stroke();
      ctx.setLineDash([]);
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.25)'; ctx.shadowBlur = 3;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(fx, anchorY, 4, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      ctx.fillStyle = t.ink;
      ctx.beginPath(); ctx.arc(fx, anchorY, 2.4, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(fx, anchorY, 1, 0, Math.PI * 2); ctx.fill();
      ctx.font = font(t, 600, 10);
      const words = e.label.split(' ');
      const lines: string[] = [];
      let cur = '';
      words.forEach((w) => {
        const trial = cur ? cur + ' ' + w : w;
        if (measureW(ctx, trial) > 132 && cur) { lines.push(cur); cur = w; } else cur = trial;
      });
      if (cur) lines.push(cur);
      const bh = lines.length * 13 + 12;
      const bw = Math.min(150, Math.max(...lines.map((l) => measureW(ctx, l))) + 18);
      let bx = fx - bw / 2;
      bx = Math.max(4, Math.min(W - bw - 4, bx));
      let lane = 0;
      for (;;) {
        const y0 = padT - 10 - bh - lane * (bh + 8);
        const clash = placedEv.some((q) => bx < q.x1 && bx + bw > q.x0 && Math.abs(y0 - (padT - 10 - bh - q.lane * (bh + 8))) < bh + 6);
        if (!clash || lane > 2) break;
        lane++;
      }
      placedEv.push({ x0: bx, x1: bx + bw, lane });
      const byTop = Math.max(4, padT - 10 - bh - lane * (bh + 8));
      ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
      ctx.strokeStyle = rgba(t.ink, 0.25); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(bx, byTop, bw, bh, 7); ctx.fill(); ctx.stroke();
      const tailX = Math.max(bx + 10, Math.min(bx + bw - 10, fx));
      ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
      ctx.beginPath();
      ctx.moveTo(tailX - 5, byTop + bh - 0.5);
      ctx.lineTo(tailX + 5, byTop + bh - 0.5);
      ctx.lineTo(tailX, byTop + bh + 6);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = t.ink; ctx.textAlign = 'left';
      lines.forEach((l, li) => ctx.fillText(l, bx + 9, byTop + 14 + li * 13));
      ctx.restore();
      if (activeS !== null && p > 0.9) {
        const si = activeS;
        const k = order.indexOf(si);
        if (k >= 0) {
          const jj = Math.round(e.at);
          const yT = B[k + 1][jj], yB = B[k][jj];
          if (yB - yT > 8) {
            const vy = (yT + yB) / 2;
            const label = fmtNum(list[si].values[jj] || 0);
            ctx.save();
            ctx.font = font(t, 700, 10);
            const tw = measureW(ctx, label);
            const cxp = Math.max(tw / 2 + 8, Math.min(W - tw / 2 - 8, fx));
            ctx.fillStyle = rgba(list[si].color, 0.95);
            ctx.beginPath(); ctx.roundRect(cxp - tw / 2 - 6, vy - 10, tw + 12, 17, 8); ctx.fill();
            ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
            ctx.fillText(label, cxp, vy + 2.5);
            ctx.restore();
          }
        }
      }
    });
    ctx.textAlign = 'left';
    return;
  }

/* ============ FUNNEL / PYRAMID (2D + 3D) ============ */
  if (kind === 'funnel' || kind === 'pyramid') {
    const g = funnelGeom(W, H, m, data, full, kind === 'pyramid');
    const { ch, plotW, sq, topY, cx, laneX } = g;
    const heights = data.map((x) => (x.value / total) * ch * p);
    const sumH = heights.reduce((a, b) => a + b, 0);
    const widthAt = (rel: number) => kind === 'funnel'
      ? plotW * (0.96 - 0.66 * (rel / ch))
      : plotW * (0.96 * (rel / ch)); // pyramid: true point at the top
    ctx.font = font(t, 600, 10.5);
    // label rows: pushed apart so thin segments never overlap, then pulled
    // back inside the plot from the bottom
    const rows: number[] = [];
    { let yy = topY + (ch - sumH); heights.forEach((h) => { rows.push(yy + h / 2); yy += h; }); }
    const PITCH = 14;
    for (let i = 1; i < rows.length; i++) rows[i] = Math.max(rows[i], rows[i - 1] + PITCH);
    const floor = Math.min(H - 8, topY + ch + 18);
    for (let i = rows.length - 1; i >= 0; i--) rows[i] = Math.min(rows[i], i === rows.length - 1 ? floor : rows[i + 1] - PITCH);
    let y = topY + (ch - sumH);
    data.forEach((x, i) => {
      const h = heights[i];
      const rel0 = y - topY;
      const w0 = widthAt(rel0), w1 = widthAt(rel0 + h);
      const on = hov.idx === i;
      const col = on ? shade(colors[i], 1 + 0.12 * hov.amt) : colors[i];
      if (kind === 'funnel' && m > 0.02) {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.ellipse(cx, y + h, Math.max(0.1, w1 / 2), Math.max(0.1, (w1 / 2) * sq), 0, Math.PI, 0, true);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.ellipse(cx, y, Math.max(0.1, w0 / 2), Math.max(0.1, (w0 / 2) * sq), 0, 0, Math.PI, false);
        ctx.closePath(); ctx.fill();
        if (i === 0) {
          ctx.fillStyle = shade(colors[i], 1.22);
          ctx.beginPath(); ctx.ellipse(cx, y, Math.max(0.1, w0 / 2), Math.max(0.1, (w0 / 2) * sq), 0, 0, Math.PI * 2); ctx.fill();
        }
      } else if (kind === 'pyramid' && m > 0.005) {
        // side face grows with the morph — no jump at the 2D/3D boundary
        const dxr = (w: number) => w * 0.2 * m, dyr = (w: number) => w * 0.075 * m;
        ctx.fillStyle = shade(colors[i], 0.72);
        ctx.beginPath();
        ctx.moveTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w0 / 2 + dxr(w0), y - dyr(w0));
        ctx.lineTo(cx + w1 / 2 + dxr(w1), y + h - dyr(w1));
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        if (m < 0.98) { ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke(); }
      } else {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        if (m < 0.98) { ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke(); }
      }
      // leader — attached at the segment's true mid-width edge, head fully outside
      const midY = y + h / 2;
      const rowY = rows[i];
      const wMid = widthAt(rel0 + h / 2);
      // anchor on the shape's true silhouette: the front edge in 2D, the side face's
      // outer edge in 3D (blended through the morph). The head is entirely outside it.
      const edgeX = cx + wMid / 2 + (kind === 'pyramid' ? wMid * 0.2 * m : 0);
      const edgeY = midY - (kind === 'pyramid' ? wMid * 0.075 * m : 0);
      // every leader turns in one shared vertical lane just right of the widest
      // part of the shape (incl. the 3D side face), then runs to its label row
      const textX = laneX + 16;
      // arrowhead scales with the segment but never below a legible 2.2px half-height
      const ah = Math.min(3.8, Math.max(2.2, h / 2 - 0.5)), al = Math.max(4.5, ah * 2);
      ctx.strokeStyle = colors[i];
      ctx.lineWidth = 1.3;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(edgeX + al, edgeY);
      if (Math.abs(rowY - edgeY) > 0.5) { ctx.lineTo(Math.max(edgeX + al + 4, laneX - 6), edgeY); ctx.lineTo(laneX, rowY); }
      ctx.lineTo(textX - 6, rowY);
      ctx.stroke();
      ctx.lineJoin = 'miter';
      ctx.fillStyle = colors[i];
      ctx.beginPath();
      ctx.moveTo(edgeX + 0.5, edgeY);
      ctx.lineTo(edgeX + al + 0.5, edgeY - ah);
      ctx.lineTo(edgeX + al + 0.5, edgeY + ah);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 0.8; ctx.stroke();
      ctx.fillStyle = t.ink;
      ctx.textAlign = 'left';
      const text = funnelLabel(x, total);
      ctx.fillText(full ? text : fitCtx(ctx, text, W - textX - 4), textX, rowY + 3.5);
      y += h;
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ TOROID DONUT (ported from chart.html drawTorus/renderDonut) ============
     TRUE toroidal torus on canvas: quads sorted back-to-front by depth, tube
     cross-section lit by a fixed light dir (ambient + diffuse + pow6 spec),
     hovered segment inflates (r×1.32, R+9) with brighter response, divider
     lines, glowing centre orb, radial leader labels + centre total — same
     structure, hover animation and tilt (0.52) as the reference.
     Colors: glossy Sankey-3D family (TOROID_GLOSS), tilt eases 0→0.52 with m
     so 2D⇄3D is a smooth morph, never a jump. */
  if (kind === 'toroid') {
    /* ---- intelligent ambient: why light mode looked "dull" ----
       The torus is lit by ambient + diffuse + spec. The old model used a
       fixed low ambient (0.28) tuned for dark tiles, where deep shading
       reads as richness. On a bright tile the same deep falloff turns every
       tube's underside near-black — high-contrast mud, read as "dull".
       Fix: sense the tile mood (theme dark/light + card luminance) and
       re-balance the whole rig — bright tiles get a lifted, hue-holding
       ambient + gentler diffuse falloff + reined-in spec, dark tiles keep
       the dramatic rig. Same model, same code path, always well-dressed. */
    const PI2 = Math.PI * 2;
    const moodLight = !t.dark;
    const amb = moodLight ? 0.62 : 0.28;      // base fill
    const dif = moodLight ? 0.42 : 0.72;      // diffuse strength (soft falloff on light)
    const spec = moodLight ? 0.34 : 0.60;     // spec stays a kiss, not a blowout
    const liftFloor = moodLight ? 0.30 : 0.0; // undersides keep hue, never near-black
    const tilt = 0.52 * m;
    // fixed diameter across the morph: sized once, only tilts afterwards
    const g0 = circGeom(W, H, 0, data, full);
    const cx = g0.cx, cy = g0.cy;
    const R = Math.max(40, g0.R * 0.78);
    const r = Math.max(14, R * 0.34);
    // perf: adaptive resolution — quad counts follow ON-SCREEN tube pixels,
    // not the container width. Small tiles stop paying for invisible slices;
    // fullscreen still renders buttery. (See cache bubble below for the
    // static-frame reuse that makes hover-only repaints cheap.)
    const tubePx = r * 2;
    const fine = tubePx * (full ? 2.2 : 1.35);
    const isSvg = typeof (ctx as unknown as { els?: unknown }).els !== 'undefined';
    // EXPORT SMOOTHNESS: exports render once, so they get the smoothest
    // possible surface — a far denser facet mesh than any live frame needs
    // (PNG/PDF compose at 3x; SVG emits fine vector facets).
    const exportHiRes = !isSvg && !!d.bg;
    // True-SVG path: rather than a bespoke geometry, SVG export reuses the
    // EXACT same `paintTube` quad-strip painter as the live canvas (see
    // below) — every quad connects TWO adjacent ring-angle cross-sections
    // (a "top" ring and a "bottom" ring of tube-profile points), so the
    // surface is always continuous. GEOMETRY-CORRECTNESS FIX: an earlier
    // version drew ONE STANDALONE cross-section "bead" per ring sample
    // instead of a connecting quad. At ring angles where the torus's
    // tilt-squash projection happens to compress that lone bead's own two
    // basis directions onto nearly the same screen axis (a real projection
    // degeneracy of this tilt model, not a texture problem), an isolated
    // bead collapses to a thin sliver — the "small grey dash lines" seen
    // in the export. A connecting QUAD never has this failure mode: even
    // if one of its two edges is momentarily thin, the strip still has
    // real area contributed by the neighbouring, non-degenerate edge, so
    // the surface stays solid everywhere. FILE-SIZE FIX: resolution is
    // capped low enough for SVG (unlike the live canvas, which can afford
    // very fine steps) that the exported quad count stays in the low
    // hundreds — each quad is one small flat-filled path with no
    // separate stroke — keeping the file in the tens of KB while still
    // reading as a smooth, continuously round tube.
    // SVG-ONLY SMOOTHNESS BUMP: the PNG/PDF exports (and the live canvas)
    // were already smooth — only the SVG's quad-strip mesh still read a
    // touch faceted. The tube's ROUND cross-section (tubeSteps, below) is
    // what most affects perceived smoothness, so it gets the bigger bump;
    // ringSteps is nudged up too. Quad count stays ring×tube ≈ ≤960, which
    // keeps the file comfortably under 100 KB.
    const ringSteps = isSvg ? Math.max(60, Math.min(80, data.length * 6))
      : Math.max(72, Math.min(exportHiRes ? 480 : (full || W >= 560 ? 300 : 176), Math.round(fine * (exportHiRes ? 2.4 : (full || W >= 560 ? 1.7 : 1.0)))));
    // Export bodies render at the LIVE transform scale (composeExport = 3x),
    // so exports always resolve MORE tube bands than the screen — smoother
    // surface at export size, same silhouette (bands are pure shading).
    const liveScaleNow = (() => {
      try { return Math.max(1, (ctx as CanvasRenderingContext2D).getTransform?.().a || 1); }
      catch { return 1; }
    })();
    const exportBoost = !isSvg && d.bg && liveScaleNow > 1.5 ? 2.2 : 1;
    const tubeSteps = isSvg ? 12
      : Math.max(10, Math.min(exportHiRes ? 64 : (full || W >= 560 ? 48 : 24), Math.round((tubePx / (moodLight ? 3.4 : 2.8)) * exportBoost)));
    const rot = -Math.PI / 2; // start at 12 o'clock like the family
    // perf: module-level texture cache — the torus body is invariant in
    // (W,H,p,m,theme,data) space, so hover-only frames repaint from cache
    // and pay JUST the hovered slice. Key rounds floats to kill jitter.
    const torKey = [
      kind, Math.round(W), Math.round(H), Math.round(p * 1000), Math.round(m * 500),
      t.dark ? 'd' : 'l', full ? 'f' : 'c', isSvg ? 's' : 'r', data.map((x) => x.value).join(','), colors.join(','),
    ].join('|');
    type TorCache = {
      body: HTMLCanvasElement | null; bodyScale: number; staticQuads: { a0: number; a1: number; depth: number }[];
      ringSteps: number; tubeSteps: number; cx: number; cy: number; R: number; r: number;
      tilt: number; rot: number; moodLight: boolean; amb: number; dif: number; spec: number; liftFloor: number;
      /** perf: tube cross-section sin/cos table, built ONCE per cache key —
       * `paintTube` used to rebuild this from scratch on every single call,
       * including every animation frame of a hover pop (the main
       * contributor to the hover feeling sluggish, alongside the frame's
       * genuine facet-fill cost). Reusing it cuts real per-frame CPU work. */
      phiCos: number[]; phiSin: number[];
    };
    const tc = (paintChart as unknown as { _tor?: { key: string; c: TorCache } })._tor;
    let cache: TorCache;
    if (tc && tc.key === torKey) {
      cache = tc.c;
    } else {
      // Static quad projection (centreline + depth + per-facet lighting is
      // all camera-invariant here — only the hover slice repaints live).
      interface TSegT { aStart: number; aEnd: number; color: string; i: number }
      const segsT: TSegT[] = [];
      {
        let acc = 0;
        data.forEach((x, i) => {
          const frac = (x.value / total) * PI2 * p;
          segsT.push({ aStart: acc, aEnd: acc + frac, color: colors[i], i });
          acc += frac;
        });
      }
      interface TQ { a0: number; a1: number; depth: number; seg: TSegT }
      const quadsT: TQ[] = [];
      const cosT = Math.cos(tilt);
      for (let si = 0; si < ringSteps; si++) {
        const a0 = (PI2 * si) / ringSteps;
        const a1 = (PI2 * (si + 1)) / ringSteps;
        const aMid = (a0 + a1) / 2;
        let seg = segsT[segsT.length - 1];
        for (let q = 0; q < segsT.length; q++) {
          if (aMid * p >= segsT[q].aStart && aMid * p < segsT[q].aEnd) { seg = segsT[q]; break; }
        }
        const ca = aMid + rot;
        quadsT.push({ a0, a1, depth: R * Math.sin(ca) * cosT, seg });
      }
      quadsT.sort((a, b) => a.depth - b.depth);
      const phiCosInit: number[] = [], phiSinInit: number[] = [];
      for (let k = 0; k < tubeSteps; k++) { const phi = (PI2 * k) / tubeSteps; phiCosInit.push(Math.cos(phi)); phiSinInit.push(Math.sin(phi)); }
      cache = {
        body: null,
        bodyScale: 1,
        staticQuads: quadsT.map((q) => ({ a0: q.a0, a1: q.a1, depth: q.depth })),
        ringSteps, tubeSteps, cx, cy, R, r, tilt, rot, moodLight, amb, dif, spec, liftFloor,
        phiCos: phiCosInit, phiSin: phiSinInit,
      };
      // cache full slices too (typed via closure, stored on the cache obj)
      (cache as TorCache & { segs?: { aStart: number; aEnd: number; color: string; i: number }[] }).segs = segsT.map((s) => ({ ...s }));
      (paintChart as unknown as { _tor?: { key: string; c: TorCache } })._tor = { key: torKey, c: cache };
    }
    const cachedSegs = (cache as TorCache & { segs?: { aStart: number; aEnd: number; color: string; i: number }[] }).segs || [];
    const segOf = (q: { a0: number; a1: number }) => {
      const aMid = (q.a0 + q.a1) / 2;
      let seg = cachedSegs[cachedSegs.length - 1];
      for (let qi = 0; qi < cachedSegs.length; qi++) {
        if (aMid * p >= cachedSegs[qi].aStart && aMid * p < cachedSegs[qi].aEnd) { seg = cachedSegs[qi]; break; }
      }
      return seg;
    };
    const LD = { x: 0.4, y: -0.6 };
    const cosTilt = Math.cos(tilt), sinTilt = Math.sin(tilt);
    const rgbCache = new Map<string, [number, number, number]>();
    const rgbOf = (c: string): [number, number, number] => {
      let hit = rgbCache.get(c);
      if (!hit) { const pc = parseColor(c) || [128, 128, 128, 1]; hit = [pc[0], pc[1], pc[2]]; rgbCache.set(c, hit); }
      return hit;
    };
    // perf: pre-computed shade ramps — hovering never re-parses/shades per
    // facet; the eased amt lerps between the two endpoints instead.
    const hovA = hov.amt;
    const paintTube = (
      c2d: Ctx, rEff: number, rEff2: number, isHover: boolean, amt: number,
      hovSeg: number | null, alphaMul: number,
    ) => {
      const { phiCos, phiSin } = cache;
      for (const q of cache.staticQuads) {
        const { a0, a1 } = q;
        if (a0 * p > PI2) continue; // entrance reveal: skip unrevealed quads only
        const seg = segOf(q);
        const hov2 = isHover && seg.i === hovSeg;
        const rE = hov2 ? rEff : cache.r;
        const rE2 = hov2 ? rEff2 : cache.R;
        // seam fix (Fix #4): each quad overlaps the next by half a slice so
        // adjacent facets share an edge — no hairline of tile background can
        // ever show through at segment joints (the "small white lines").
        const a1o = a1 + (PI2 / cache.ringSteps) * 0.5;
        const top: { x: number; y: number }[] = [], bot: { x: number; y: number }[] = [];
        ([a0, a1o] as const).forEach((ta) => {
          const cosA = Math.cos(ta + cache.rot), sinA = Math.sin(ta + cache.rot);
          const arr = ta === a0 ? top : bot;
          for (let k = 0; k < cache.tubeSteps; k++) {
            const rad = rE2 + rE * phiCos[k];
            arr.push({ x: cache.cx + rad * cosA, y: cache.cy + rad * sinA * cosTilt + rE * phiSin[k] * sinTilt });
          }
        });
        const ca = (a0 + a1) / 2 + cache.rot;
        const [r1, g1, b1] = rgbOf(seg.color);
        const ambient = (hov2 ? cache.amb + 0.12 : cache.amb) * alphaMul;
        for (let k = 0; k < cache.tubeSteps; k++) {
          const k2 = (k + 1) % cache.tubeSteps;
          const phiMid = (PI2 * (k + 0.5)) / cache.tubeSteps;
          const ld = Math.max(0, Math.cos(phiMid) * Math.cos(ca) * LD.x + (Math.cos(phiMid) * Math.sin(ca) * cosTilt + Math.sin(phiMid) * sinTilt) * LD.y);
          let ll = ambient + cache.dif * ld;
          if (cache.liftFloor) ll = Math.max(ll, cache.liftFloor + cache.dif * ld * 0.4);
          let ls = Math.pow(ld, 6) * cache.spec;
          if (hov2) { ll *= 1 + 0.2 * amt; ls *= 1 + 0.35 * amt; }
          c2d.fillStyle = `rgb(${Math.min(255, Math.round(r1 * ll + ls * 255))},${Math.min(255, Math.round(g1 * ll + ls * 255))},${Math.min(255, Math.round(b1 * ll + ls * 255))})`;
          c2d.beginPath();
          c2d.moveTo(top[k].x, top[k].y);
          c2d.lineTo(top[k2].x, top[k2].y);
          c2d.lineTo(bot[k2].x, bot[k2].y);
          c2d.lineTo(bot[k].x, bot[k].y);
          c2d.closePath();
          c2d.fill();
        }
      }
    };
    // Hover expansion happens IN PLACE on the torus axis: the tube swells
    // symmetrically around its own centreline (radius r only) — the ring
    // radius R NEVER moves and there is NO vertical lift, so the piece grows
    // exactly where it sits instead of floating off-axis like a pulled-out
    // slice.
    const hovR = r * (1 + 0.32 * hovA);
    const canCache = !isSvg && typeof document !== 'undefined' && typeof (ctx as CanvasRenderingContext2D).drawImage === 'function';
    const hoverOn = hov.idx !== null && hovA > 0.01;
    // Static body: render ONCE per (geometry+theme+data+scale) into an
    // offscreen bitmap; every non-hover frame (and same-size exports)
    // reuses it. Scale is part of validity: a live-DPR body must never
    // serve a 3x export (or vice versa). Pulled out into its own function
    // (perf fix below) so the fast hover-redraw path can also guarantee a
    // fresh bitmap exists to blit from, without duplicating this logic.
    const ensureBody = () => {
      const liveScale = (() => {
        try {
          const t2 = (ctx as CanvasRenderingContext2D).getTransform();
          return Math.max(1, t2.a || 1);
        } catch { return (typeof window !== 'undefined' && window.devicePixelRatio) || 1; }
      })();
      if (!cache.body || cache.bodyScale !== liveScale) {
        const off = document.createElement('canvas');
        // Crisp-PNG fix: key the bitmap scale to the LIVE transform (DPR ×
        // export scale), not window DPR. composeExport renders at scale=3,
        // so export bodies need 3x pixels or the torus downsamples blurry.
        off.width = Math.max(1, Math.round(W * liveScale));
        off.height = Math.max(1, Math.round(H * liveScale));
        const octx = off.getContext('2d')!;
        octx.setTransform(liveScale, 0, 0, liveScale, 0, 0);
        paintTube(octx as unknown as Ctx, r, R, false, 0, null, 1);
        cache.body = off;
        cache.bodyScale = liveScale;
      }
      return cache.body;
    };
    if (isSvg) {
      // TRUE-VECTOR SMOOTH torus: earlier revisions built the tube from a
      // facet MESH (small flat quads) — a fixed facet budget is either
      // visibly polygonal (few facets → small file) or huge (many facets
      // → smooth but hundreds of KB), because a flat-shaded mesh can only
      // ever be as smooth as its facet count. This instead draws each
      // data segment's tube as ONE elliptical <path> arc (the ring's own
      // circle, tilted — a perfect ellipse, needing no sampling at all)
      // stroked with `stroke-linecap="round"` at the tube's true
      // diameter, shaded with a genuine SVG <radialGradient> centred on
      // the ring's own centre (inner tube edge → outer tube edge) that
      // fakes the tube's round cross-section exactly the way this
      // codebase already fakes cylindrical shading elsewhere (Gantt
      // lozenges, the Radial Bar arc-tubes) — a dark undercoat stroke
      // plus a gradient-shaded main stroke. SVG gradients render at
      // INFINITE resolution (真the renderer's own anti-aliasing, not a
      // facet count) — perfectly smooth at ANY zoom, and the whole torus
      // costs only ~3 elements + 1 gradient per data segment, keeping the
      // file at a few KB instead of hundreds. Colour, radius and tilt all
      // come from the SAME `R`/`r`/`cosTilt`/`rot` values the live canvas
      // uses, so the shape and proportions match exactly — only the
      // shading METHOD (gradient vs. per-facet flat colour) differs.
      // Built purely through the standard Canvas 2D API (createRadialGradient
      // / ellipse / stroke) — all already correctly implemented by the SVG
      // recorder (SvgCtx), so this emits real <radialGradient>/<path A...>
      // markup without reaching into any recorder internals.
      const segs = cachedSegs.length ? cachedSegs : (() => {
        let acc = 0;
        return data.map((x, i) => {
          const frac = (x.value / total) * PI2 * p;
          const s = { aStart: acc, aEnd: acc + frac, color: colors[i], i };
          acc += frac;
          return s;
        });
      })();
      const ry = Math.max(0.5, R * cosTilt);
      const order = segs.map((s) => ({ s, depth: R * Math.sin((s.aStart + s.aEnd) / 2 + rot) * cosTilt }))
        .sort((a, b) => a.depth - b.depth);
      order.forEach(({ s }) => {
        const a0 = s.aStart + rot, a1 = Math.min(s.aEnd, s.aStart + PI2) + rot;
        if (a1 - a0 < 0.0005) return;
        const grad = ctx.createRadialGradient(cx, cy, Math.max(0.01, R - r), cx, cy, R + r);
        grad.addColorStop(0, shade(s.color, moodLight ? 0.72 : 0.5));
        grad.addColorStop(0.5, shade(s.color, moodLight ? 1.12 : 1.05));
        grad.addColorStop(1, shade(s.color, moodLight ? 0.82 : 0.62));
        // undercoat: full tube diameter, dark — reads as the tube's own
        // contact shadow / occluded underside, giving it real depth.
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.strokeStyle = shade(s.color, moodLight ? 0.5 : 0.32);
        ctx.lineWidth = r * 2.08;
        ctx.beginPath(); ctx.ellipse(cx, cy, R, ry, 0, a0, a1, false); ctx.stroke();
        // main lit body — the radial gradient fakes the round cross-
        // section as a smooth curve, not a single flat facet colour.
        ctx.strokeStyle = grad;
        ctx.lineWidth = r * 1.86;
        ctx.beginPath(); ctx.ellipse(cx, cy, R, ry, 0, a0, a1, false); ctx.stroke();
        // thin gloss highlight down the tube's own centreline.
        ctx.strokeStyle = shade(s.color, moodLight ? 1.28 : 1.4);
        ctx.lineWidth = r * 0.5;
        ctx.globalAlpha = 0.55;
        ctx.beginPath(); ctx.ellipse(cx, cy, R, ry, 0, a0, a1, false); ctx.stroke();
        ctx.globalAlpha = 1;
      });
    } else if (!canCache) {
      // Fallback direct path (no offscreen bitmap available).
      paintTube(ctx, hovR, R, true, hovA, hoverOn && hov.idx !== null ? hov.idx : null, 1);
    } else if (hoverOn && hov.idx !== null) {
      // IN-PLACE hover, depth-correct: repaint the WHOLE torus live with
      // the hovered slice's tube inflated. Every quad still participates
      // in the SAME back-to-front depth sort as the resting body, so the
      // torus's own front wall keeps correctly occluding the swelling
      // piece — it expands symmetrically around its own centreline,
      // staying inside the ring's silhouette, instead of visually
      // "popping out" over the top of the torus.
      // REGRESSION FIX: an earlier "speed" optimization blitted the
      // cached RESTING bitmap and then drew ONLY the hovered segment's
      // own swollen facets on top, unconditionally — since that overlay
      // never re-ran the depth sort against the rest of the (now-static)
      // torus, the swollen piece always painted OVER everything else
      // regardless of whether it should have been occluded, which is
      // exactly what read as "the slice pulls outside the donut, toward
      // the top" instead of swelling in place. Every quad must go through
      // one shared depth-sorted pass for the occlusion to be correct, so
      // this reverts to a full, live repaint of the whole torus per
      // frame — the trig-table memoization above still makes each of
      // those frames measurably cheaper than before that same "fix".
      paintTube(ctx, hovR, R, true, hovA, hov.idx, 1);
    } else {
      (ctx as CanvasRenderingContext2D).drawImage(ensureBody(), 0, 0, W, H);
    }
    // divider ticks between segments
    if (p > 0.85) {
      ctx.save();
      ctx.globalAlpha = moodLight ? 0.28 : 0.45;
      // seam fix (Fix #4): ticks are drawn from the NEIGHBOURING slice
      // colours (darkened), never ink/white — joints read as shading, not
      // as the white seam lines from the report.
      segs: {
        const list = cachedSegs;
        ctx.lineWidth = 1.2;
        list.forEach((sg) => {
          const a = sg.aStart + rot;
          ctx.strokeStyle = shade(sg.color, moodLight ? 0.62 : 0.55);
          ctx.beginPath();
          ctx.moveTo(cx + (R - r * 0.15) * Math.cos(a), cy + (R - r * 0.15) * Math.sin(a) * cosTilt);
          ctx.lineTo(cx + (R + r * 0.15) * Math.cos(a), cy + (R + r * 0.15) * Math.sin(a) * cosTilt);
          ctx.stroke();
        });
      }
      ctx.restore();
    }
    // glowing centre orb + total
    if (p > 0.5) {
      const orbR = r * 0.72;
      const og = ctx.createRadialGradient(cx, cy, 0, cx, cy, orbR);
      if (t.dark) {
        og.addColorStop(0, 'rgba(120,160,255,1)');
        og.addColorStop(0.4, 'rgba(80,100,220,0.9)');
        og.addColorStop(0.85, 'rgba(40,60,180,0.5)');
        og.addColorStop(1, 'rgba(20,30,120,0)');
      } else {
        og.addColorStop(0, 'rgba(255,255,255,1)');
        og.addColorStop(0.45, 'rgba(210,228,255,0.95)');
        og.addColorStop(0.85, 'rgba(170,200,250,0.55)');
        og.addColorStop(1, 'rgba(150,180,240,0)');
      }
      ctx.beginPath(); ctx.arc(cx, cy, orbR, 0, PI2); ctx.fillStyle = og; ctx.fill();
    }
    if (p > 0.95) drawLeaders(ctx, cx, cy, R + r * 0.9, cosTilt, data, colors, total, t, W, H, false, full);
    if (p > 0.85) {
      ctx.fillStyle = t.ink;
      ctx.font = font(t, 700, 16, true);
      ctx.textAlign = 'center';
      ctx.fillText(String(total), cx, cy + 5);
      ctx.textAlign = 'left';
    }
    return;
  }

  /* ============ PIE / DONUT (2D ⇄ 3D morph) ============ */
  const g = circGeom(W, H, m, data, full);
  const { cx, cy, R: R0, depth, squash } = g;
  const rIn = kind === 'donut' ? R0 * g.rInRatio : 0;

  interface Seg { a0: number; a1: number; i: number }
  let a = -Math.PI / 2;
  const segs: Seg[] = data.map((x, i) => {
    const a1 = a + (x.value / total) * Math.PI * 2 * p;
    const s = { a0: a, a1, i };
    a = a1;
    return s;
  });
  // hover: the slice pops radially outward along its true angle vector from the center
  const hovAmt = (s: Seg) => (hov.idx === s.i ? hov.amt : 0);
  const pullOf = (s: Seg) => 14 * hovAmt(s);                 // radial pop along the bisector angle
  const px = (ang: number, r: number) => cx + Math.cos(ang) * r;
  const py = (ang: number, r: number) => cy + Math.sin(ang) * r * squash;
  const OVER = 0.012;
  // per-slice translation (dx, dy) in screen space: pure radial along angle vector
  const offsetOf = (s: Seg): [number, number] => {
    const a = hovAmt(s);
    if (!a) return [0, 0];
    const mid = (s.a0 + s.a1) / 2, pull = pullOf(s);
    const offset = radialOffset(mid, pull, squash);
    return [offset.x, offset.y];
  };

  // soft ground shadow (live only) — replaces the CSS drop-shadow filter that
  // made large-canvas morphs stutter; fades out as the chart extrudes
  if (!d.bg && m < 0.999 && p > 0.05) {
    ctx.save();
    setShadow(ctx, 0, 7, 16, rgba(t.ink, 0.2 * (1 - m)));
    ctx.fillStyle = t.surface || '#e4e7e0';
    ctx.beginPath(); ctx.ellipse(cx, cy + depth, R0 + 1, (R0 + 1) * squash, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  /** Draw one slice's 3D body (outer rim, inner rim, cut faces) depth-sorted. */
  // exports (vector recorder) get ONE arc-bounded band per slice with a gradient
  // instead of dozens of shaded strips — same look, a fraction of the file size
  const vector = !!d.bg;
  const drawBody = (s: Seg, dx: number, dy: number) => {
    const faces: { y: number; draw: () => void }[] = [];
    const Rx = R0;
    const col = hov.idx === s.i ? shade(colors[s.i], 1 + 0.08 * hov.amt) : colors[s.i];
    if (vector) {
      const vis0 = Math.max(s.a0, 0), vis1 = Math.min(s.a1, Math.PI); // front half only
      if (vis1 > vis0 + 1e-4) {
        faces.push({
          y: py((vis0 + vis1) / 2, Rx),
          draw: () => {
            const g = ctx.createLinearGradient(px(vis0, Rx) + dx, 0, px(vis1, Rx) + dx, 0);
            g.addColorStop(0, shade(col, 0.62 + 0.2 * Math.cos(vis0)));
            g.addColorStop(1, shade(col, 0.62 + 0.2 * Math.cos(vis1)));
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, vis0, vis1, false);
            ctx.ellipse(cx + dx, cy + dy + depth, Rx, Rx * squash, 0, vis1, vis0, true);
            ctx.closePath(); ctx.fill();
          },
        });
      }
      if (rIn > 0) {
        const b0 = Math.max(s.a0, Math.PI), b1 = Math.min(s.a1, Math.PI * 2); // inner wall visible at the back
        const c0 = Math.max(s.a0, -Math.PI), c1 = Math.min(s.a1, 0);
        [[b0, b1], [c0, c1]].forEach(([q0, q1]) => {
          if (q1 <= q0 + 1e-4) return;
          faces.push({
            y: py((q0 + q1) / 2, rIn) - 900,
            draw: () => {
              ctx.fillStyle = shade(colors[s.i], 0.52);
              ctx.beginPath();
              ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, q0, q1, false);
              ctx.ellipse(cx + dx, cy + dy + depth, rIn, rIn * squash, 0, q1, q0, true);
              ctx.closePath(); ctx.fill();
            },
          });
        });
      }
      ([s.a0, s.a1] as const).forEach((edge) => {
        faces.push({
          y: py(edge, (Rx + rIn) / 2) - 0.25,
          draw: () => {
            ctx.fillStyle = shade(colors[s.i], 0.72);
            ctx.beginPath();
            if (rIn > 0) {
              ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy); ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy); ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
            } else {
              ctx.moveTo(cx + dx, cy + dy); ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy); ctx.lineTo(cx + dx, cy + depth + dy);
            }
            ctx.closePath(); ctx.fill();
          },
        });
      });
      return faces;
    }
    const steps = Math.max(3, Math.min(72, Math.ceil(((s.a1 - s.a0) * Rx) / 7)));
    for (let k = 0; k < steps; k++) {
      const b0 = s.a0 + ((s.a1 - s.a0) * k) / steps - OVER;
      const b1 = s.a0 + ((s.a1 - s.a0) * (k + 1)) / steps + OVER;
      const midS = (b0 + b1) / 2;
      if (Math.sin(midS) <= 0) continue;
      faces.push({
        y: py(midS, Rx),
        draw: () => {
          ctx.fillStyle = shade(col, 0.62 + 0.2 * Math.cos(midS));
          ctx.beginPath();
          ctx.moveTo(px(b0, Rx) + dx, py(b0, Rx) + dy);
          ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + dy);
          ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + depth + dy);
          ctx.lineTo(px(b0, Rx) + dx, py(b0, Rx) + depth + dy);
          ctx.closePath(); ctx.fill();
        },
      });
    }
    if (rIn > 0) {
      const inner = Math.max(3, Math.min(48, Math.ceil(((s.a1 - s.a0) * rIn) / 7)));
      for (let k = 0; k < inner; k++) {
        const b0 = s.a0 + ((s.a1 - s.a0) * k) / inner - OVER;
        const b1 = s.a0 + ((s.a1 - s.a0) * (k + 1)) / inner + OVER;
        const midS = (b0 + b1) / 2;
        const back = Math.sin(midS) < 0;
        faces.push({
          y: back ? py(midS, rIn) - 900 : py(midS, rIn) - 0.5,
          draw: () => {
            ctx.fillStyle = shade(colors[s.i], back ? 0.52 : 0.44);
            ctx.beginPath();
            ctx.moveTo(px(b0, rIn) + dx, py(b0, rIn) + dy);
            ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + dy);
            ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + depth + dy);
            ctx.lineTo(px(b0, rIn) + dx, py(b0, rIn) + depth + dy);
            ctx.closePath(); ctx.fill();
          },
        });
      }
    }
    ([s.a0, s.a1] as const).forEach((edge) => {
      faces.push({
        y: py(edge, (Rx + rIn) / 2) - 0.25,
        draw: () => {
          ctx.fillStyle = shade(colors[s.i], 0.88);
          ctx.beginPath();
          if (rIn > 0) {
            ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
            ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
          } else {
            ctx.moveTo(cx + dx, cy + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
            ctx.lineTo(cx + dx, cy + depth + dy);
          }
          ctx.closePath(); ctx.fill();
        },
      });
    });
    return faces;
  };
  /** Draw one slice's top face — polar 3D style: radial pop + brightness boost
   *  on the hovered slice, soft glossy bevel that matches the polar chart. */
  const drawTop = (s: Seg, dx: number, dy: number) => {
    const Rx = R0;
    const on = hov.idx === s.i;
    const pull = on ? 14 * hov.amt : 0;
    const o = OVER * clamp01(m * 8);
    // Soft drop shadow under the hovered slice — matches polar's hover lift feel
    if (on && pull > 0.5) {
      ctx.save();
      ctx.fillStyle = rgba(t.ink, 0.18 * hov.amt);
      ctx.beginPath();
      ctx.ellipse(cx + dx, cy + dy + 4, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
      if (rIn > 0) ctx.ellipse(cx + dx, cy + dy + 4, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
      else ctx.lineTo(cx + dx, cy + dy + 4);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    // Solid fill always — hover only lifts brightness uniformly. The old
    // radial-gradient wash faded the slice edge toward white, which read as a
    // hollow / washed-out ring on hover (notably on light slices like pink).
    ctx.fillStyle = on && hov.amt > 0.01 ? shade(colors[s.i], 1 + 0.14 * hov.amt) : colors[s.i];
    ctx.beginPath();
    ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
    if (rIn > 0) ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
    else ctx.lineTo(cx + dx, cy + dy);
    ctx.closePath(); ctx.fill();

    // NOTE: no specular wash is painted on the top face. The old white
    // overlay did two bad things in 3D: its auto-closed arc chord read as a
    // small white scratch on every slice, and the white fill made light
    // slices (e.g. pink) look non-solid. Slices stay 100 % solid color now.

    if (m < 0.02) {
      // Separator hint (2D only): stroke the rim arcs ONLY — never the full
      // slice path, whose radial cut edges used to flash as a fan of white
      // lines during the 2D⇄3D morph. 3D slices get no stroke at all, so the
      // top face stays perfectly clean and solid.
      ctx.strokeStyle = `rgba(255,255,255,${(0.55 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
      ctx.stroke();
      if (rIn > 0) {
        ctx.beginPath();
        ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, s.a0 - o, s.a1 + o, false);
        ctx.stroke();
      }
    }
  };

  // Hover is a planar translation, not elevation. Keep every body opaque and
  // depth-sort all slices together rather than painting the active slice on top.
  if (m > 0.005) {
    const faces = segs.flatMap((s) => {
      const [dx, dy] = offsetOf(s);
      return drawBody(s, dx, dy).map(face => ({ ...face, y: face.y + dy }));
    });
    faces.sort((a, b) => a.y - b.y).forEach(face => face.draw());
  }
  segs.forEach((s) => {
    const [dx, dy] = offsetOf(s);
    drawTop(s, dx, dy);
  });

  if (p > 0.95) drawLeaders(ctx, cx, cy, R0, squash, data, colors, total, t, W, H, false, full);
  if (kind === 'donut' && m < 0.5) {
    ctx.save();
    ctx.globalAlpha = clamp01(1 - m * 2);
    ctx.fillStyle = t.ink;
    ctx.font = font(t, 700, 16, true);
    ctx.textAlign = 'center';
    ctx.fillText(String(total), cx, cy + 5);
    ctx.restore();
    ctx.textAlign = 'left';
  }
}

/* ================= export composition ================= */
interface LegendItem { label: string; color: string }
function legendLayout(meas: (s: string) => number, items: LegendItem[], W: number) {
  const padX = 14, gap = 18, dot = 13, rowH = 17;
  const rows: { x: number; y: number; it: LegendItem }[] = [];
  let x = padX, row = 0;
  items.forEach((it) => {
    const w = dot + meas(it.label);
    if (x + w > W - padX && x > padX) { x = padX; row++; }
    rows.push({ x, y: row * rowH, it });
    x += w + gap;
  });
  return { rows, height: items.length ? (row + 1) * rowH + 12 : 6 };
}
function scratchCtx(): Ctx { return document.createElement('canvas').getContext('2d')!; }

function drawComposition(ctx: Ctx, title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme, lay: ReturnType<typeof legendLayout>, headH: number) {
  if (title) {
    ctx.fillStyle = '#1c2620';
    let fs = 15;
    ctx.font = font(t, 700, fs, true);
    while (fs > 11 && measureW(ctx, title) > chartW - 24) { fs -= 1; ctx.font = font(t, 700, fs, true); }
    ctx.textAlign = 'left';
    ctx.fillText(fitCtx(ctx, title, chartW - 24), 12, 22);
  }
  ctx.save(); ctx.translate(0, headH);
  paintFn(ctx);
  ctx.restore();
  ctx.font = font(t, 600, 10.5);
  lay.rows.forEach(({ x, y, it }) => {
    const yy = headH + chartH + 14 + y;
    ctx.fillStyle = it.color;
    ctx.beginPath(); ctx.arc(x, yy - 3, 4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#39443d'; ctx.textAlign = 'left';
    ctx.fillText(it.label, x + 9, yy);
  });
}

/** PNG/PDF/Print bitmap — white background, theme fonts, full legend (wrapped, never truncated). */
export function composeExport(title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme = themeColors(true)): HTMLCanvasElement {
  const scale = 3;
  const sc = scratchCtx(); sc.font = font(t, 600, 10.5);
  const lay = legendLayout((s) => measureW(sc, s), legend, chartW);
  const headH = title ? 34 : 10;
  const W = chartW, H = headH + chartH + lay.height;
  const cv = document.createElement('canvas');
  cv.width = W * scale; cv.height = H * scale;
  const ctx = cv.getContext('2d')!;
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);
  drawComposition(ctx, title, chartW, chartH, legend, paintFn, t, lay, headH);
  return cv;
}

export function composeSvg(title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme = themeColors(true), fontCss = ''): string {
  const sc = scratchCtx(); sc.font = font(t, 600, 10.5);
  const lay = legendLayout((s) => measureW(sc, s), legend, chartW);
  const headH = title ? 34 : 10;
  const rec = new SvgCtx(chartW, headH + chartH + lay.height);
  rec.fontCss = fontCss;
  drawComposition(rec as unknown as Ctx, title, chartW, chartH, legend, paintFn, t, lay, headH);
  return rec.toString();
}

/** Export canvas size — wide enough that every label is complete. */
export function exportDims(kind: ChartKind, W: number, H: number, data: ChartDatum[], multi: boolean, cats: string[], m = 0): { W: number; H: number } {
  let Wx = Math.max(W, 720), Hx = Math.max(H, 360);
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  if (kind === 'pie' || kind === 'donut' || kind === 'toroid' || kind === 'polar') {
    const longest = Math.max(0, ...data.map((x) => approxW(leaderLabel(x, total))));
    Wx = Math.max(Wx, 2 * (longest + 40) + 280);
    // height follows the disc the width allows (a squashed 3D disc needs less)
    const Rw = Wx / 2 - (longest + 40);
    const need = m > 0.5 ? 2 * Rw * K + 46 + 70 : 2 * Rw + 56;
    Hx = Math.max(m > 0.5 ? 250 : 300, Math.round(need), Math.min(720, data.length * 14 + 120));
  } else if (kind === 'funnel' || kind === 'pyramid') {
    const longest = Math.max(0, ...data.map((x) => approxW(funnelLabel(x, total))));
    Wx = Math.max(Wx, longest + 40 + 440);
    Hx = Math.max(Hx, 380);
  } else if (kind === 'radar') {
    const labels = multi ? cats : data.map((x) => x.label);
    Wx = Math.max(Wx, 2 * Math.max(0, ...labels.map((l) => approxW(l))) + 380);
    Hx = Math.max(Hx, 400);
  } else if (kind === 'radialbar' || kind === 'radialbarclassic' || kind === 'radialbars') {
    // Mirror radialGeom's roomy/compact split: small-tile exports stay compact
    // (in-tube labels, no side gutter) while fullscreen exports reserve the
    // real measured label column. Either way the rings get a square-ish plot.
    const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
    const roomy = W >= 560;
    Wx = Math.max(Wx, roomy ? longest + 26 + 460 : 420);
    const side = Math.min(760, Math.max(roomy ? 430 : 360, data.length * 30 + 140));
    Hx = Math.max(Hx, side);
    Wx = Math.max(Wx, Hx + (roomy ? longest + 40 : 30));
  } else if (kind === 'stream') {
    Wx = Math.max(Wx, 860);
    Hx = Math.max(Hx, 420);
  } else {
    const labels = multi ? cats : data.map((x) => x.label);
    Wx = Math.max(Wx, 90 + labels.length * 16);
  }
  return { W: Math.round(Wx), H: Math.round(Hx) };
}

/* ================= main Chart ================= */
const BASE_KINDS: { key: ChartKind; label: string; has3d: boolean }[] = [
  { key: 'bar', label: 'Bar', has3d: true },
  { key: 'line', label: 'Line', has3d: true },
  { key: 'area', label: 'Area', has3d: true },
  { key: 'pie', label: 'Pie', has3d: true },
  { key: 'donut', label: 'Donut', has3d: true },
  { key: 'toroid', label: 'Toroid Donut', has3d: true },
  { key: 'radar', label: 'Radar', has3d: true },
  { key: 'polar', label: 'Polar', has3d: true },
  // "Radial Bar (Classic)" is merged into this single "Radial Bar" kind —
  // both used to render the same supplied reference chart. Its 2D/3D is
  // driven by this app's own toggle (has3d: true), not an internal one.
  { key: 'radialbar', label: 'Radial Bar', has3d: true },
  { key: 'radialbars', label: 'Radial Bars Circular', has3d: true },
  { key: 'dual', label: 'Dual Axes', has3d: true },
];
const EXTRA_KINDS: { key: ChartKind; label: string; has3d: boolean }[] = [
  { key: 'funnel', label: 'Funnel', has3d: true },
  { key: 'pyramid', label: 'Pyramid', has3d: true },
  { key: 'calendarpie', label: 'Calendar pie', has3d: false },
  { key: 'sankey', label: 'Sankey (Classic)', has3d: true },
  { key: 'sankey3d', label: 'Sankey (3D · Three.js)', has3d: true },
  { key: 'gantt', label: 'Gantt', has3d: true },
  { key: 'scatter', label: 'Scatter', has3d: true },
  { key: 'stream', label: 'Streamgraph', has3d: true },
];
const skeletonKind = (k: ChartKind): 'circle' | 'bars' | 'columns' | 'line' =>
  k === 'pie' || k === 'donut' || k === 'toroid' || k === 'polar' || k === 'radar' || k === 'radialbar' || k === 'radialbarclassic' || k === 'radialbars' || k === 'calendarpie' ? 'circle' : k === 'line' || k === 'area' || k === 'sankey' || k === 'sankey3d' || k === 'scatter' || k === 'stream' ? 'line' : k === 'funnel' || k === 'pyramid' || k === 'gantt' ? 'bars' : 'columns';

export interface ChartProps {
  data?: ChartDatum[];
  categories?: string[];
  series?: StackedSeries[];
  title?: string;
  defaultKind?: ChartKind;
  defaultDim?: '2d' | '3d';
  height?: number;
  loading?: boolean;
  extraKinds?: ('funnel' | 'pyramid' | 'gantt' | 'scatter' | 'stream')[];
  yLabel?: string;
  insight?: string[];
  isFullscreen?: boolean;
  /** calendar-pie: per-day values, one entry per `series` */
  days?: CalendarDay[];
  /** sankey: weighted flows */
  links?: SankeyLink[];
  /** gantt tasks */
  tasks?: GanttTask[];
  /** scatter points */
  scatter?: ScatterPoint[];
  /** streamgraph event flags */
  streamEvents?: StreamEvent[];
}

export default function Chart({
  data, categories, series, title, defaultKind = 'bar', defaultDim = '2d',
  height = 300, loading = false, extraKinds = [], yLabel, insight, isFullscreen = false, days, links, tasks, scatter, streamEvents,
}: ChartProps) {
  const multi = !!(series && series.length && ((categories && categories.length) || defaultKind === 'calendarpie'));
  const themeTick = useThemeTick();
  const pal = useMemo(() => activePalette(), [themeTick]); // eslint-disable-line react-hooks/exhaustive-deps
  const sColors = useMemo(() => (series || []).map((s, i) => s.color || pal[i % pal.length]), [series, pal]);

  // Aggregate fallback data if user switches away from special chart types
  const singleData: ChartDatum[] = useMemo(() => {
    if (multi) return series!.map((s, i) => ({ label: s.name, value: s.values.reduce((a, b) => a + b, 0), color: sColors[i] }));
    if (data && data.length) return data;
    if (links && links.length) {
      const m = new Map<string, number>();
      links.forEach((l) => m.set(l.source, (m.get(l.source) || 0) + l.value));
      return [...m.entries()].map(([label, value], i) => ({ label, value, color: pal[i % pal.length] }));
    }
    if (days && days.length && series && series.length) {
      return series.map((s, i) => ({
        label: s.name,
        value: days.reduce((sum, d) => sum + (d.values[i] || 0), 0),
        color: s.color || pal[i % pal.length],
      }));
    }
    if (tasks && tasks.length) {
      return tasks.map((tk, i) => ({ label: tk.name, value: tk.progress ?? 100, color: tk.color || pal[i % pal.length] }));
    }
    if (scatter && scatter.length) {
      return scatter.slice(0, 16).map((pt, i) => ({ label: pt.label || `Point ${i + 1}`, value: pt.y, color: pt.color || pal[i % pal.length] }));
    }
    return [];
  }, [multi, series, data, sColors, links, days, tasks, scatter, pal]);


  // Context-aware KINDS dropdown list: genuine options only where suitable data exists
  const KINDS = useMemo(() => {
    const list: { key: ChartKind; label: string; has3d: boolean }[] = [];
    const baseKeys: ChartKind[] = ['bar', 'line', 'area', 'pie', 'donut', 'toroid'];
    baseKeys.forEach((k) => {
      const item = BASE_KINDS.find((b) => b.key === k);
      if (item) list.push(item);
    });

    if (singleData.length >= 3) {
      const rad = BASE_KINDS.find((b) => b.key === 'radar');
      const pol = BASE_KINDS.find((b) => b.key === 'polar');
      if (rad) list.push(rad);
      if (pol) list.push(pol);
    }
    if (singleData.length >= 2) {
      const rb = BASE_KINDS.find((b) => b.key === 'radialbar');
      if (rb) list.push(rb);
      const rbc = BASE_KINDS.find((k) => k.key === 'radialbarclassic');
      if (rbc && !list.some((x) => x.key === 'radialbarclassic')) list.push(rbc);
      const rbs = BASE_KINDS.find((k) => k.key === 'radialbars');
      if (rbs && !list.some((x) => x.key === 'radialbars')) list.push(rbs);
    }

    // Dual axes: visible only where genuine multi-series or >=2 data items exist
    const hasDualData = (series && series.length >= 2 && categories && categories.length > 0) || (singleData.length >= 2);
    if (hasDualData) {
      const dual = BASE_KINDS.find((b) => b.key === 'dual');
      if (dual && !list.some((x) => x.key === 'dual')) list.push(dual);
    }

    // Calendar pie: visible only where genuine daily data exists
    if (days && days.length > 0) {
      const cp = EXTRA_KINDS.find((k) => k.key === 'calendarpie');
      if (cp && !list.some((x) => x.key === 'calendarpie')) list.unshift(cp);
    }

    // Sankey: visible only where genuine link flow data exists — two
    // independent selectable kinds: the classic canvas chart (no Three.js)
    // and the Three.js-powered 3D-pro chart, both fed by the same `links`.
    if (links && links.length > 0) {
      const sk = EXTRA_KINDS.find((k) => k.key === 'sankey');
      if (sk && !list.some((x) => x.key === 'sankey')) list.unshift(sk);
      const sk3 = EXTRA_KINDS.find((k) => k.key === 'sankey3d');
      if (sk3 && !list.some((x) => x.key === 'sankey3d')) list.unshift(sk3);
    }

    // Gantt: visible only where genuine task timeline data exists
    if (tasks && tasks.length > 0) {
      const gt = EXTRA_KINDS.find((k) => k.key === 'gantt');
      if (gt && !list.some((x) => x.key === 'gantt')) list.unshift(gt);
    }

    // Scatter: visible only where genuine coordinate scatter data exists
    if (scatter && scatter.length > 0) {
      const sc = EXTRA_KINDS.find((k) => k.key === 'scatter');
      if (sc && !list.some((x) => x.key === 'scatter')) list.unshift(sc);
    }

    // Streamgraph: needs >=2 series over >=3 time columns (or >=3 items fallback)
    if ((series && series.length >= 2 && categories && categories.length >= 3) || singleData.length >= 3) {
      const st = EXTRA_KINDS.find((k) => k.key === 'stream');
      if (st && !list.some((x) => x.key === 'stream')) list.push(st);
    }

    extraKinds.forEach((ek) => {
      const found = EXTRA_KINDS.find((k) => k.key === ek);
      if (found && !list.some((x) => x.key === ek)) list.push(found);
    });

    if (!list.some((x) => x.key === defaultKind)) {
      const fb = [...BASE_KINDS, ...EXTRA_KINDS].find((k) => k.key === defaultKind);
      if (fb) list.unshift(fb);
    }
    return list;
  }, [singleData.length, series, categories, days, links, tasks, scatter, extraKinds, defaultKind]);
  const [kind, setKind] = useState<ChartKind>(defaultKind);
  const [dim, setDim] = useState<'2d' | '3d'>(defaultDim);
  const meta = KINDS.find((k) => k.key === kind) || BASE_KINDS[0];
  const isSpecialFlow = kind === 'sankey' || kind === 'sankey3d' || kind === 'calendarpie';
  const effDim = meta.has3d ? dim : '2d';
  const colors = useMemo(() => singleData.map((x, i) => x.color || (kind === 'toroid' || kind === 'radialbars' ? TOROID_GLOSS[i % TOROID_GLOSS.length] : pal[i % pal.length])), [singleData, pal, kind]);

  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const [hoverSeg, setHoverSeg] = useState<{ c: number; s: number } | null>(null);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);
  const [full, setFull] = useState(false);
  /** Brief explicit "building" indicator for the Toroid Donut's first
   * paint (see the entrance-animation effect below) — separate from
   * `loading` (data fetch) and from the sweep-in reveal itself. */
  const [booting, setBooting] = useState(false);
  const bootTimerRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const progRef = useRef(0);
  const dimRef = useRef(defaultDim === '3d' && meta.has3d ? 1 : 0);
  const rafRef = useRef(0);
  const dimRafRef = useRef(0);
  const hovRef = useRef<Hover>({ ...NO_HOVER });
  const hovRafRef = useRef(0);
  // True-3D camera orbit (Sankey 3D): drag to rotate like a modelled object.
  // Angles ease back to rest on release so the scene always settles readable.
  const orbitRef = useRef<Orbit3D>({ ...ORBIT_REST });
  const orbitTarget = useRef<Orbit3D>({ ...ORBIT_REST });
  const orbitRafRef = useRef(0);
  const dragRef = useRef<{ x: number; y: number; yaw: number; pitch: number; moved: boolean } | null>(null);
  const aspectRef = useRef(height / 560);
  // theme tokens are read once per theme change, never per animation frame
  const themeRef = useRef<Theme>(themeColors());
  useEffect(() => { themeRef.current = themeColors(); }, [themeTick]);

  // Three.js chart handles (Sankey 3D · Radial bar 2D/3D · Streamgraph 3D · Radial Bars Circular)
  const threeSankeyRef = useRef<ThreeChartHandle>(null);
  const threeRadialRef = useRef<ThreeChartHandle>(null);
  const threeStreamRef = useRef<ThreeChartHandle>(null);
  const threeRBCRef = useRef<ThreeChartHandle>(null);
  // Which of the reference Radial Bar's three built-in presets is showing —
  // switched via the "Version" dropdown next to the Kind dropdown, below.
  const [radialPreset, setRadialPreset] = useState<RadialPresetKey>('olympic');
  const exportTheme = useMemo(() => ({
    ink: themeRef.current.ink, fontBody: themeRef.current.fontBody || DEF_BODY, fontDisplay: themeRef.current.fontDisplay || DEF_DISPLAY,
  }), [themeTick]); // eslint-disable-line react-hooks/exhaustive-deps
  // `radialbar` and `sankey3d` are ALWAYS Three.js (both their 2D and 3D
  // views live inside the same WebGL scene so dimensions never jump on
  // toggle) — `sankey` stays pure canvas, no Three.js.
  const isThreeRadial = kind === 'radialbar';
  const isThreeSankeyPro = kind === 'sankey3d';
  // Streamgraph (Fix #6): the WebGL river from Streamgraph3DTest.html serves
  // BOTH 2D and 3D views (camera preset morph + ribbon Z-spread 1→0), so the
  // canvas painter underneath is kept only as the no-WebGL/export fallback.
  // Radial Bars Circular: full port of 3dRadialBarChart.html — always
  // Three.js in both dims (2D = the reference's top-down twin view).
  const isThreeStream = kind === 'stream';
  const isThreeRBC = kind === 'radialbars';
  const canvasHidden = isThreeRadial || isThreeSankeyPro || isThreeStream || isThreeRBC;

  const dataSig = useMemo(() => JSON.stringify({
    d: singleData.map((x) => [x.label, x.value]),
    s: (series || []).map((s) => s.values), c: categories, k: days, l: links, t: tasks, sc: scatter, ev: streamEvents,
  }), [singleData, series, categories, days, links, tasks, scatter, streamEvents]);

  const buildCtx = useCallback((W: number, H: number, p: number, m: number, hov: Hover, forExport = false): DrawCtx => ({
    W, H, t: forExport ? themeColors(true) : themeRef.current, p, m, hov,
    data: singleData, colors, multi,
    cats: categories || [], series: series || [], sColors, yLabel,
    full: isFullscreen || forExport,
    bg: forExport ? '#ffffff' : undefined,
    days, links, tasks, scatter,
    orbit: kind === 'sankey' ? { ...orbitRef.current } : undefined,
    streamEvents,
  }), [singleData, colors, multi, categories, series, sColors, yLabel, isFullscreen, days, links, tasks, scatter, kind, effDim, streamEvents]);

  const paint = useCallback((ctx: Ctx, W: number, H: number, p: number, m: number, hov: Hover, forExport = false) => {
    paintChart(ctx, kind, buildCtx(W, H, p, m, hov, forExport));
  }, [buildCtx, kind]);

  const render = useCallback(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth, H = cv.clientHeight;
    if (W <= 0 || H <= 0) { requestAnimationFrame(() => render()); return; }
    aspectRef.current = H / W;
    const bw = Math.round(W * dpr), bh = Math.round(H * dpr);
    if (cv.width !== bw || cv.height !== bh) { cv.width = bw; cv.height = bh; }
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    paint(ctx, W, H, easeOut(progRef.current), dimRef.current, hovRef.current);
  }, [paint]);

  /* entrance animation — data/kind change only (NOT dim) */
  useEffect(() => {
    if (loading) return;
    cancelAnimationFrame(rafRef.current);
    progRef.current = 0;
    dimRef.current = effDim === '3d' ? 1 : 0;
    let t0 = performance.now();
    const tick = (now: number) => {
      progRef.current = Math.min(1, (now - t0) / 750);
      render();
      if (progRef.current < 1) rafRef.current = requestAnimationFrame(tick);
    };
    // LOADING-ANIMATION FIX: the torus's facet mesh (perf: module-level
    // texture cache above) has to build once per (geometry+theme+data+
    // scale) key before the first pixel appears — a genuine brief compute
    // window on mount/kind-switch. This used to show the spinner overlay
    // WHILE ALSO already running the sweep-reveal tick loop underneath it
    // simultaneously — by the time the spinner disappeared the chart had
    // already silently swept in partway, so it never read as a real
    // "loading, then reveal" sequence. The spinner now genuinely GATES the
    // sweep: paint the blank (p=0) frame immediately, hold there for the
    // spinner's duration, THEN start the 750ms sweep-in clock — a clean,
    // two-phase loading experience matching the other 3D-labelled charts.
    if (kind === 'toroid') {
      setBooting(true);
      render(); // establish the blank p=0 frame under the spinner
      const bt = setTimeout(() => {
        setBooting(false);
        t0 = performance.now();
        rafRef.current = requestAnimationFrame(tick);
      }, 420);
      bootTimerRef.current = bt;
    } else {
      rafRef.current = requestAnimationFrame(tick);
    }
    return () => { cancelAnimationFrame(rafRef.current); clearTimeout(bootTimerRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, dataSig, loading]);

  /* STALE-TILE FIX: while a Three.js-hosted kind (radialbar / sankey3d /
     stream / radialbars) is active, this 2D canvas sits at opacity:0 and
     the entrance-animation effect above may have last painted it for a
     DIFFERENT (now-stale) kind, or not at all. When leaving one of those
     kinds — i.e. `canvasHidden` flips from true to false and the canvas
     is about to fade back to opacity:1 — force a few fresh animation
     frames once the browser has committed the new layout, so the first
     visible frame is guaranteed to be a real, current paint of whatever
     kind is now selected rather than a leftover/blank one.
     BUG FIX: an earlier version of this effect (a) depended on `render`
     itself, which is a NEW function reference on almost every relevant
     state change, so it re-ran far more often than just the true→false
     transition it was meant to catch, and (b) forced a full DOM remount
     of the <canvas> (via a `key` bump) to "guarantee" a clean paint. That
     remount could commit AFTER the entrance-animation effect's own
     750ms repaint loop (below) had already finished — swapping in a
     brand-new BLANK canvas with nothing left to ever repaint it, which is
     exactly the "switching away from Radial Bar leaves the tile blank"
     bug. Rendering is idempotent and always reads the canvas's LIVE size
     on every call, so no remount is needed — this now only depends on the
     primitive `canvasHidden`/`loading` booleans (never re-firing on
     unrelated renders) and reads the latest `render` via a ref instead of
     a dependency, so it fires exactly once per real transition. */
  const renderRef = useRef(render);
  renderRef.current = render;
  const prevHiddenRef = useRef(canvasHidden);
  useEffect(() => {
    const wasHidden = prevHiddenRef.current;
    prevHiddenRef.current = canvasHidden;
    if (loading || canvasHidden || !wasHidden) return;
    let raf = requestAnimationFrame(() => {
      renderRef.current();
      raf = requestAnimationFrame(() => {
        renderRef.current();
        raf = requestAnimationFrame(() => renderRef.current());
      });
    });
    return () => cancelAnimationFrame(raf);
  }, [canvasHidden, loading]);

  /* 2D ⇄ 3D morph — ease-in-out, duration scales gently with canvas size */
  useEffect(() => {
    if (loading) return;
    const target = effDim === '3d' ? 1 : 0;
    if (Math.abs(dimRef.current - target) < 0.001) return;
    cancelAnimationFrame(dimRafRef.current);
    const from = dimRef.current;
    const t0 = performance.now();
    const W = canvasRef.current?.clientWidth || 600;
    const DUR = 480 + Math.min(240, Math.max(0, W - 600) * 0.4);
    const tick = (now: number) => {
      const t = Math.min(1, (now - t0) / DUR);
      dimRef.current = from + (target - from) * easeInOut(t);
      render();
      if (t < 1) dimRafRef.current = requestAnimationFrame(tick);
    };
    dimRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(dimRafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effDim, loading]);

  /* smooth hover animation */
  useEffect(() => {
    const target = hoverIdx !== null || hoverSeg !== null;
    const h = hovRef.current;
    if (target && (hoverIdx !== h.idx || JSON.stringify(hoverSeg) !== JSON.stringify(h.seg))) {
      h.idx = hoverIdx; h.seg = hoverSeg;
      if (target) h.amt = Math.min(h.amt, 0.35);
    }
    cancelAnimationFrame(hovRafRef.current);
    // Toroid hover used to feel sluggish: its frame is the heaviest in the
    // family, so the generic ease rate under-delivered. Eased further still
    // (now ~3x the generic rate) so the pop settles in noticeably fewer
    // frames — paired with the trig-table memoization in paintTube above,
    // which removes real per-frame CPU work from every one of those frames.
    const hovRate = kind === 'toroid' ? 0.62 : 0.22;
    const tick = () => {
      const goal = target ? 1 : 0;
      const diff = goal - h.amt;
      if (Math.abs(diff) < 0.02) {
        h.amt = goal;
        if (!target) { h.idx = null; h.seg = null; }
        if (progRef.current >= 1) render();
        return;
      }
      h.amt += diff * hovRate;
      if (progRef.current >= 1) render();
      hovRafRef.current = requestAnimationFrame(tick);
    };
    hovRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(hovRafRef.current);
  }, [hoverIdx, hoverSeg, render]);

  useEffect(() => { if (progRef.current >= 1) render(); }, [themeTick, render]);
  useEffect(() => {
    const cv = canvasRef.current;
    const on = () => render();
    window.addEventListener('resize', on);
    let ro: ResizeObserver | null = null;
    if (cv && typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => render());
      ro.observe(cv);
    }
    return () => { window.removeEventListener('resize', on); ro?.disconnect(); };
  }, [render, loading]);

  /* hit testing — shares the exact layout helpers used by the painter */
  /* orbit easing: angles glide toward the target every frame while settling */
  useEffect(() => {
    if (kind !== 'sankey' || effDim !== '3d') return;
    cancelAnimationFrame(orbitRafRef.current);
    const tick = () => {
      const o = orbitRef.current, tg = orbitTarget.current;
      const dy = tg.yaw - o.yaw, dp = tg.pitch - o.pitch;
      if (Math.abs(dy) < 0.0004 && Math.abs(dp) < 0.0004) return;
      o.yaw += dy * 0.12; o.pitch += dp * 0.12;
      if (progRef.current >= 1) render();
      orbitRafRef.current = requestAnimationFrame(tick);
    };
    orbitRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(orbitRafRef.current);
  }, [kind, effDim, render]);

  /* Drag-orbit is no longer used by any canvas chart kind: the classic
     Sankey is now a fixed isometric painter (ported from the agon
     reference) and the Three.js Sankey rotates via its own OrbitControls
     inside <ThreeSankey3D/>. Kept as no-op stubs so the mouse handlers
     wired on the canvas element stay harmless. */
  const orbitDown = (_e: React.MouseEvent) => {};
  const orbitMove = (_e: React.MouseEvent) => {};
  const orbitUp = () => {};

  const hit = (e: React.MouseEvent) => {
    const cv = canvasRef.current;
    if (!cv || (!singleData.length && !isSpecialFlow && !tasks?.length && !scatter?.length)) return;
    const r = cv.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    const W = r.width, H = r.height;
    const m = dimRef.current;
    const total = singleData.reduce((s, x) => s + x.value, 0) || 1;
    let idx: number | null = null;
    let seg: { c: number; s: number } | null = null;
    let text = '';

    if (kind === 'sankey') {
      // Classic (canvas, no Three.js) hit test — node hover PLUS flow-ribbon
      // hover. The ribbon probe samples the rendered bezier edges (the same
      // curves the painter fills) so the highlight lands exactly on the art.
      const lay = sankeyLayout((links || []).filter((l) => l.value > 0 && l.source !== l.target), W, H, isFullscreen ? 200 : Math.min(150, W * 0.22));
      if (lay) {
        lay.nodes.forEach((n, i) => { if (mx >= n.x - 4 && mx <= n.x + lay.nodeW + 4 && my >= n.y && my <= n.y + n.h) idx = i; });
        if (idx !== null) {
          const n = lay.nodes[idx];
          text = `${n.name}: ${fmtNum(n.value)}`;
        } else {
          // flow pass: point-in-ribbon against the painter's bezier ribbons
          const cleanLinks = (links || []).filter((l) => l.value > 0 && l.source !== l.target);
          for (let fi = 0; fi < lay.flows.length; fi++) {
            const f = lay.flows[fi];
            const src = lay.nodes[f.si], tgt = lay.nodes[f.ti];
            const x0 = src.x + lay.nodeW, x1 = tgt.x, mid = (x0 + x1) / 2;
            if (mx < x0 - 2 || mx > x1 + 2) continue;
            // invert the x-bezier to find t (monotonic in x): bisection
            let lo = 0, hi = 1;
            for (let it = 0; it < 24; it++) {
              const tt = (lo + hi) / 2, u = 1 - tt;
              const bx = u * u * u * x0 + 3 * u * u * tt * mid + 3 * u * tt * tt * mid + tt * tt * tt * x1;
              if (bx < mx) lo = tt; else hi = tt;
            }
            const tt = (lo + hi) / 2, u = 1 - tt;
            const edge = (from: number, to: number) =>
              u * u * u * from + 3 * u * u * tt * from + 3 * u * tt * tt * to + tt * tt * tt * to;
            const topY = edge(f.sy0, f.ty0), botY = edge(f.sy1, f.ty1);
            if (my >= topY - 2 && my <= botY + 2) {
              seg = { c: fi, s: -2 }; // s === -2 marks "classic sankey flow"
              const L = cleanLinks[fi];
              text = L ? `${L.source} → ${L.target}: ${fmtNum(L.value)}` : '';
              break;
            }
          }
        }
      }
      setHoverIdx(idx); setHoverSeg(seg); setTip(idx !== null || seg ? { x: mx, y: my, text } : null);
      return;
    }
    if (kind === 'calendarpie') {
      const ds = days || [];
      if (ds.length && series?.length) {
        const first = new Date(Math.min(...ds.map((x) => new Date(x.date + 'T00:00:00').getTime())));
        const ms = new Date(first.getFullYear(), first.getMonth(), 1), me = new Date(first.getFullYear(), first.getMonth() + 1, 0);
        const padL = 12, padR = 12, padT = 34, padB = 10, cols = 7;
        const lead = (ms.getDay() + 6) % 7, rows = Math.ceil((lead + me.getDate()) / cols);
        const cell = Math.min((W - padL - padR) / cols, (H - padT - padB) / rows);
        const gx = padL + ((W - padL - padR) - cell * cols) / 2, gy = padT + ((H - padT - padB) - cell * rows) / 2;
        const c = Math.floor((mx - gx) / cell), rw = Math.floor((my - gy) / cell);
        const dnum = rw * cols + c - lead + 1;
        if (c >= 0 && c < cols && rw >= 0 && dnum >= 1 && dnum <= me.getDate()) {
          const iso = `${ms.getFullYear()}-${String(ms.getMonth() + 1).padStart(2, '0')}-${String(dnum).padStart(2, '0')}`;
          const vals = ds.find((x) => x.date === iso)?.values;
          if (vals) {
            const cx0 = gx + c * cell + cell / 2, cy0 = gy + rw * cell + cell / 2 + cell * 0.05;
            const rad = Math.hypot(mx - cx0, my - cy0);
            if (rad <= cell * 0.36 + 4) {
              const tot = vals.reduce((a2, b) => a2 + b, 0) || 1;
              let ang = Math.atan2(my - cy0, mx - cx0) + Math.PI / 2; ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
              let acc = 0;
              for (let si = 0; si < vals.length; si++) { acc += (vals[si] / tot) * Math.PI * 2; if (ang <= acc) { seg = { c: dnum, s: si }; break; } }
              if (seg) text = `${new Date(iso + 'T00:00:00').toLocaleDateString('en', { day: 'numeric', month: 'short' })} · ${series![seg.s].name}: ${vals[seg.s]}`;
            }
          }
        }
      }
      setHoverIdx(null); setHoverSeg(seg); setTip(seg ? { x: mx, y: my, text } : null);
      return;
    }

    if (kind === 'toroid') {
      // Toroid hover: mirror the PAINTER's torus (NOT the pie disc).
      // circGeom + tube: R = g.R*0.78, r = R*0.34, tilted by 0.52·m.
      // STRICT band test: hover fires ONLY when the cursor sits on the
      // tube itself (R±r in unsquashed space, +2px AA tolerance). Blank
      // centre, label gutters and corners must never trigger a segment.
      const tg = circGeom(W, H, 0, singleData, isFullscreen);
      const tR = Math.max(40, tg.R * 0.78);
      const tr = Math.max(14, tR * 0.34);
      const tTilt = 0.52 * m;
      const tCos = Math.cos(tTilt), tSin = Math.sin(tTilt);
      const cur = hovRef.current;
      // sticky: while a piece is eased open, test its CURRENT inflated tube
      // (r×(1+0.32·amt)) so the cursor doesn't fall off the swelling piece —
      // but never wider than that, or blank space starts hovering.
      const curR = tr * (1 + 0.32 * (cur.idx !== null ? cur.amt : 0));
      const probeTor = (dy: number, band: number): number | null => {
        const ex = mx - tg.cx, ey = (my - dy - tg.cy) / tCos;
        const rad = Math.hypot(ex, ey);
        if (Math.abs(rad - tR) > band) return null; // off-tube ⇒ no hover
        let ang = Math.atan2(ey, ex) + Math.PI / 2;
        ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        let acc = 0;
        for (let i = 0; i < singleData.length; i++) {
          acc += (singleData[i].value / total) * Math.PI * 2;
          if (ang <= acc) return i;
        }
        return null;
      };
      idx = probeTor(0, curR + 2);
      if (idx === null && tTilt > 0.02) {
        // 3D crown band: the tube's lit front wall (up to r·sinTilt above
        // the centreline) belongs to the same piece — same strict band.
        for (const f of [0.5, 1]) { idx = probeTor(tr * tSin * f, curR + 2); if (idx !== null) break; }
      }
      if (idx !== null) {
        text = `${singleData[idx].label}: ${singleData[idx].value}`;
        let a0 = -Math.PI / 2;
        for (let j = 0; j < idx; j++) a0 += (singleData[j].value / total) * Math.PI * 2;
        const a1 = a0 + (singleData[idx].value / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2;
        const outR = tR + tr + 24;
        const tx = Math.max(16, Math.min(W - 140, tg.cx + Math.cos(mid) * outR));
        const ty = Math.max(16, Math.min(H - 40, tg.cy + Math.sin(mid) * outR * tCos));
        setHoverIdx(idx); setHoverSeg(null); setTip({ x: tx, y: ty, text });
        return;
      }
      // MISS ⇒ blank space. The toroid must NEVER fall through to the generic
      // xy hit test below (it treated the card like a column chart, so hover
      // fired "all over the place" — centre hole, gutters, corners). Off the
      // tube means no segment, no tooltip, full stop.
      setHoverIdx(null); setHoverSeg(null); setTip(null);
      return;
    }

    if (kind === 'pie' || kind === 'donut' || kind === 'polar') {
      const g = circGeom(W, H, m, singleData, isFullscreen);
      if (kind === 'polar') { g.squash = 1 - 0.44 * m; g.depth = 16 * m; }
      const rIn = kind === 'donut' ? g.R * g.rInRatio : 0;
      const sliceAt = (ang: number) => {
        if (kind === 'polar') return Math.min(singleData.length - 1, Math.floor(ang / (Math.PI * 2) * singleData.length));
        let acc = 0;
        for (let i = 0; i < singleData.length; i++) {
          acc += (singleData[i].value / total) * Math.PI * 2;
          if (ang <= acc) return i;
        }
        return null;
      };
      const probe = (dy: number, frontOnly: boolean): number | null => {
        const ex = mx - g.cx, ey = (my - dy - g.cy) / g.squash;
        const rad = Math.hypot(ex, ey);
        if (rad > g.R + 12 || rad < Math.max(0, rIn - 8)) return null;
        let ang = Math.atan2(ey, ex) + Math.PI / 2;
        ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        if (frontOnly && !(ang > Math.PI / 2 && ang < (3 * Math.PI) / 2)) return null;
        if (kind === 'polar') {
          const max = Math.max(...singleData.map((x) => x.value), 1);
          const i = Math.min(singleData.length - 1, Math.floor((ang / (Math.PI * 2)) * singleData.length));
          return (singleData[i].value / max) * g.R >= rad - 8 ? i : null;
        }
        return sliceAt(ang);
      };
      // sticky hover: while a slice is pulled out, test it first at its displaced
      // position so the cursor doesn't "fall off" the moving geometry
      const cur = hovRef.current;
      if (cur.idx !== null && cur.amt > 0.01) {
        let a0 = -Math.PI / 2;
        for (let i = 0; i < cur.idx; i++) a0 += (kind === 'polar' ? 1 / singleData.length : singleData[i].value / total) * Math.PI * 2;
        const a1 = a0 + (kind === 'polar' ? 1 / singleData.length : singleData[cur.idx].value / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2, pull = 14 * cur.amt;
        const { x: dx, y: dy } = radialOffset(mid, pull, g.squash);
        const activeR = kind === 'polar' ? g.R * singleData[cur.idx].value / Math.max(...singleData.map(x => x.value), 1) : g.R;
        const ex = mx - dx - g.cx;
        for (const band of [0, g.depth * 0.5, g.depth]) {
          const ey = (my - dy - band - g.cy) / g.squash;
          const rad = Math.hypot(ex, ey);
          if (rad > activeR + 10 || rad < Math.max(0, rIn - 8)) continue;
          let ang = Math.atan2(ey, ex) + Math.PI / 2;
          ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
          if (band > 0 && !(ang > Math.PI / 2 && ang < (3 * Math.PI) / 2)) continue;
          if (sliceAt(ang) === cur.idx) { idx = cur.idx; break; }
        }
      }
      if (idx === null) idx = probe(0, false);
      // extruded view: the side band (rim → rim + depth) belongs to the front slices too
      if (idx === null && g.depth > 0.5) {
        for (const f of [0.5, 1]) { idx = probe(g.depth * f, true); if (idx !== null) break; }
      }
      if (idx !== null) {
        text = `${singleData[idx].label}: ${singleData[idx].value}`;
        let a0 = -Math.PI / 2;
        for (let j = 0; j < idx; j++) a0 += (singleData[j].value / total) * Math.PI * 2;
        const a1 = a0 + (singleData[idx].value / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2;
        const outR = g.R + 24;
        const tx = Math.max(16, Math.min(W - 140, g.cx + Math.cos(mid) * outR));
        const ty = Math.max(16, Math.min(H - 40, g.cy + Math.sin(mid) * outR * g.squash));
        setHoverIdx(idx); setHoverSeg(null); setTip({ x: tx, y: ty, text });
        return;
      }
    } else if (kind === 'radialbars') {
      // Radial Bars Circular (MUI): mirror the PAINTER's polar frame
      // verbatim — label band reserve, plotMax, rIn, A0, lane/gaps — and
      // invert the pointer in UNSQUASHED ellipse space. The painter draws
      // y = cy + r·sin·squash, so dividing by squash recovers r exactly in
      // BOTH 2D and 3D (no separate 2D/3D hit paths to drift apart).
      const FS = isFullscreen ? 12 : W >= 760 ? 11 : 10;
      const squash = 1 - 0.5 * m;
      const hitNames: string[] = multi ? (categories || []) : singleData.map((x) => x.label);
      const nRB = Math.max(1, multi ? (categories || []).length || singleData.length : singleData.length);
      const labBand = Math.min(W * 0.24, Math.max(34, Math.max(0, ...hitNames.map((l) => approxW(l))) * 0.62 + 26));
      const plotR = Math.max(60, Math.min((W - labBand * 2) / 2 - 6, (H - 56) / 2 / Math.max(0.5, squash) - 6));
      const cxRB = W / 2, cyRB = H / 2 + 2;
      const rIn = Math.max(22, plotR * 0.34);
      const maxRB = multi ? Math.max(...series!.flatMap((s) => s.values), 1) : Math.max(...singleData.map((x) => x.value), 1);
      const laneRB = (Math.PI * 2) / nRB;
      const catGapRB = laneRB * 0.30;
      const nSRB = multi ? Math.max(1, series!.length) : 1;
      const barGapRB = nSRB > 1 ? (laneRB - catGapRB) * 0.10 : 0;
      const barWRB = nSRB > 1 ? (laneRB - catGapRB - barGapRB * (nSRB - 1)) / nSRB : laneRB - catGapRB;
      const radOfRB = (v: number) => rIn + (Math.max(0, v) / maxRB) * (plotR - rIn);
      // 3D wall: bars rise wallH above the disc — fold back down first
      const wallBack = (rO: number) => (m > 0.05 ? Math.min(44, Math.max(12, (rO - rIn) * 0.5)) * m : 0);
      const eyRB = (my - cyRB) / squash;
      const radRB = Math.hypot(mx - cxRB, eyRB);
      let angRB = Math.atan2(eyRB, mx - cxRB);
      angRB = ((angRB % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
      const reachRB = ((angRB - (3 * Math.PI) / 2 + Math.PI * 2) % (Math.PI * 2));
      const liRB = Math.floor(reachRB / laneRB);
      if (liRB >= 0 && liRB < nRB && radRB >= rIn - 4) {
        const inLane = reachRB - liRB * laneRB - catGapRB / 2;
        if (inLane >= -0.02 && inLane <= laneRB - catGapRB + 0.02) {
          if (!multi) {
            const rO = radOfRB(singleData[liRB].value);
            // accept body band AND the raised cap above it (3D)
            const eyCap = (my - cyRB + wallBack(rO)) / squash;
            const radCap = Math.hypot(mx - cxRB, eyCap);
            if (radRB <= rO + 6 || radCap <= rO + 6) {
              idx = liRB;
              const dd = singleData[liRB];
              text = dd.prior != null
                ? `${dd.label}: ${dd.value} · prior ${dd.prior} (${dd.value >= dd.prior ? '▲ +' : '▼ '}${Math.round((dd.value - dd.prior) * 10) / 10})`
                : `${dd.label}: ${dd.value}`;
            }
          } else {
            for (let si = 0; si < nSRB; si++) {
              const bS = si * (barWRB + barGapRB), bE = bS + barWRB;
              const rO = radOfRB(series![si].values[liRB] || 0);
              const eyCap = (my - cyRB + wallBack(rO)) / squash;
              const radCap = Math.hypot(mx - cxRB, eyCap);
              if (inLane >= bS - 0.02 && inLane <= bE + 0.02 && (radRB <= rO + 6 || radCap <= rO + 6)) {
                seg = { c: liRB, s: si };
                text = `${categories![liRB]} · ${series![si].name}: ${series![si].values[liRB] || 0}`;
                break;
              }
            }
          }
        }
      }
      void FS;
    } else if (kind === 'radialbarclassic') {
      // Hover labels were dead because this test inverted the WRONG geometry:
      // it used radialGeom's fitted frame (Rfit/kFit scaling, 0.44 squash,
      // depth-shifted centre) while the painter draws radialClassicGeom
      // (fixed diameter, 0.5 squash, no depth shift) — the bands never lined
      // up with the painted rings. The test now mirrors the painter's
      // contract VERBATIM: same helper, same ring radii (incl. the +2.5·amt
      // hover swell), same squash, same clockwise-from-12-o'clock sweep.
      const rg = radialClassicGeom(W, H, singleData, isFullscreen);
      const squash = 1 - 0.5 * m;
      const maxVal = Math.max(...singleData.map((x) => x.value), 1);
      const cur = hovRef.current;
      const ex = mx - rg.cx, ey = (my - rg.cy) / squash;
      const rad = Math.hypot(ex, ey);
      let ang = Math.atan2(ey, ex);
      ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
      const A0 = (3 * Math.PI) / 2; // 12 o'clock in [0, 2π)
      for (let i = 0; i < singleData.length; i++) {
        const rr = rg.ringR(i) + (cur.idx === i ? cur.amt * 2.5 : 0);
        if (Math.abs(rad - rr) > rg.thick / 2 + 2) continue;
        const sweep = Math.min(Math.PI * 2 * 0.985, (singleData[i].value / maxVal) * Math.PI * 2 * 0.985);
        // clockwise-from-top reach, with a small angular tolerance
        const reach = ((ang - A0 + Math.PI * 2) % (Math.PI * 2));
        if (reach <= sweep + 0.06) { idx = i; break; }
      }
      if (idx !== null) text = `${singleData[idx].label}: ${singleData[idx].value}`;
    } else if (kind === 'dual') {
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const colVals = multi ? categories!.map((_, c) => series![0]?.values[c] || 0) : singleData.map((x) => x.value);
      const maxL = Math.max(...colVals, 1);
      const L = xyLayout('bar', W, H, 0, labels, 1, maxL, !!yLabel, isFullscreen);
      const lineVals = multi ? series!.slice(1).map((s) => s.values) : [];
      const maxR = Math.max(...lineVals.flat(), 1);
      const pad = { ...L.pad, r: 12 + approxW(fmtNum(maxR), 10.5) + 14 };
      const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
      const step = cw / Math.max(1, labels.length);
      const ci = Math.floor((mx - pad.l) / step);
      if (ci >= 0 && ci < labels.length && mx >= pad.l) {
        if (multi) {
          let best = 16, bs: number | null = null;
          lineVals.forEach((vals, li) => { const yy = pad.t + ch - ((vals[ci] || 0) / maxR) * ch; if (Math.abs(my - yy) < best) { best = Math.abs(my - yy); bs = li + 1; } });
          const colTop = pad.t + ch - (colVals[ci] / maxL) * ch;
          if (bs === null && my >= colTop - 4) bs = 0;
          if (bs !== null) { seg = { c: ci, s: bs }; text = `${labels[ci]} · ${series![bs].name}: ${series![bs].values[ci] || 0}`; }
        } else {
          idx = ci; text = `${singleData[ci].label}: ${singleData[ci].value}`;
        }
      }
    } else if (kind === 'funnel' || kind === 'pyramid') {
      const g = funnelGeom(W, H, m, singleData, isFullscreen, kind === 'pyramid');
      const heights = singleData.map((x) => (x.value / total) * g.ch);
      let y = g.topY;
      for (let i = 0; i < singleData.length; i++) {
        if (my >= y && my <= y + heights[i] && Math.abs(mx - g.cx) <= g.plotW / 2 + 24) { idx = i; break; }
        y += heights[i];
      }
      if (idx !== null) text = `${singleData[idx].label}: ${singleData[idx].value}`;
    } else if (kind === 'stream') {
      const gm = streamGeom(multi, categories || [], series || [], sColors, singleData, colors, pal, W, H, isFullscreen);
      if (gm) {
        const { list, labels, xs, bound, order } = gm;
        const n = labels.length;
        // nearest column, then the layer whose band contains the cursor
        let j = 0, best = Infinity;
        xs.forEach((x, k) => { const dd = Math.abs(mx - x); if (dd < best) { best = dd; j = k; } });
        let si: number | null = null;
        for (let k = order.length - 1; k >= 0; k--) {
          if (my >= bound[k + 1][j] - 2 && my <= bound[k][j] + 2) { si = order[k]; break; }
        }
        if (si === null) {
          // snap to nearest boundary when between hairline layers
          let bd = Infinity;
          bound.forEach((b) => { const dd = Math.abs(my - b[j]); if (dd < bd) { bd = dd; } });
          if (bd < 10) {
            for (let k = order.length - 1; k >= 0; k--) {
              if (my >= bound[k + 1][j] - 10 && my <= bound[k][j] + 10) { si = order[k]; break; }
            }
          }
        }
        if (si !== null) {
          seg = { c: j, s: si };
          const tot = list.reduce((a, l) => a + (l.values[j] || 0), 0) || 1;
          text = `${labels[j]} · ${list[si].name}: ${fmtNum(list[si].values[j] || 0)} (${Math.round(((list[si].values[j] || 0) / tot) * 100)}%)`;
        }
      }
    } else if (kind === 'gantt') {
      const rawTasks: GanttTask[] = tasks && tasks.length ? tasks : singleData.map((x, i) => ({
        id: i, name: x.label, start: i * 3, end: i * 3 + Math.max(3, Math.round(x.value / 8)), progress: 50,
      }));
      const padL = Math.max(140, Math.min(240, W * 0.26));
      const padR = 28 + 14 * m, padT = 40 + 10 * m, padB = 30;
      const chartW = W - padL - padR, chartH = H - padT - padB;
      const rowH = Math.min(42, Math.max(26, chartH / Math.max(1, rawTasks.length)));
      const ri = Math.floor((my - padT) / rowH);
      if (ri >= 0 && ri < rawTasks.length) {
        const tk = rawTasks[ri];
        idx = ri;
        const prg = tk.progress ?? 100;
        text = `${tk.name}: ${prg}%${tk.assignee ? ` · ${tk.assignee}` : ''}`;
      }
    } else if (kind === 'scatter') {
      const rawScatter: ScatterPoint[] = scatter && scatter.length ? scatter : singleData.map((x, i) => ({
        x: 20 + i * 8 + ((i * 13) % 19), y: x.value, label: x.label, size: 7 + ((i * 3) % 5),
      }));
      const padL = 52, padR = 24, padT = 34, padB = 40;
      const plotW = W - padL - padR, plotH = H - padT - padB;
      const xs = rawScatter.map((pt) => pt.x), ys = rawScatter.map((pt) => pt.y);
      const minX = Math.min(...xs, 0), maxX = Math.max(...xs, minX + 1);
      const minY = Math.min(...ys, 0), maxY = Math.max(...ys, minY + 1);
      const sOx = 16 * m, sOy = 12 * m;
      let best = 16;
      rawScatter.forEach((pt, i) => {
        const lift = m > 0.02 ? (pt.size || 7) * 0.9 * m : 0;
        const px = padL + ((pt.x - minX) / (maxX - minX)) * plotW + (m > 0.02 ? sOx * 0.5 : 0);
        const py = padT + plotH - ((pt.y - minY) / (maxY - minY)) * plotH - (m > 0.02 ? sOy * 0.5 : 0) - lift;
        const dd = Math.hypot(mx - px, my - py);
        if (dd < best + (pt.size || 7) * 0.5) { best = dd; idx = i; }
      });
      if (idx !== null) {
        const pt = rawScatter[idx];
        text = `${pt.label || `Point ${idx + 1}`}: (${fmtNum(pt.x)}, ${fmtNum(pt.y)})`;
      }
    } else if (kind === 'radar') {
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const longest = Math.max(0, ...labels.map((l) => approxW(l)));
      const margin = isFullscreen ? Math.min(W * 0.4, longest + 24) : 44;
      const squash = 1 - 0.52 * m;
      const Rflat = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30) / Math.max(0.45, squash)));
      const depth = Math.min(46, Math.max(12, Rflat * 0.24)) * m;
      const cy = H / 2 + 6, R = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30 - depth) / Math.max(0.45, squash)));
      const max = multi ? Math.max(...series!.flatMap((s) => s.values), 1) : Math.max(...singleData.map((x) => x.value), 1);
      // Tips ride `depth` above the disc in 3D (sticks + thread, no slab) —
      // hover the tip knot, with a tolerance band covering the stick body.
      let best = 14;
      labels.forEach((_, i) => {
        const aa = -Math.PI / 2 + (i * Math.PI * 2) / labels.length;
        const v = multi ? Math.max(...series!.map((s) => s.values[i] || 0)) : singleData[i].value;
        const vr = (v / max) * R;
        const vx = W / 2 + Math.cos(aa) * vr, vy = cy + Math.sin(aa) * vr * squash - (v / max) * depth;
        const dy = my < vy ? vy - my : my > vy + depth ? my - vy - depth : 0;
        const dd = Math.hypot(mx - vx, dy);
        if (dd < best) { best = dd; idx = i; }
      });
      if (idx !== null) text = multi
        ? `${categories![idx]} · ${series!.map((s) => `${s.name}: ${s.values[idx!] || 0}`).join(' · ')}`
        : `${singleData[idx].label}: ${singleData[idx].value}`;
    } else {
      const isBar = kind === 'bar';
      const nD = multi ? series!.length : 1;
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const max = isBar
        ? (multi ? Math.max(...categories!.map((_, c) => series!.reduce((s, sr) => s + (sr.values[c] || 0), 0)), 1) : Math.max(...singleData.map((x) => x.value), 1))
        : (multi ? Math.max(...series!.flatMap((s) => s.values), 1) : Math.max(...singleData.map((x) => x.value), 1));
      const L = xyLayout(kind as 'bar' | 'line' | 'area', W, H, m, labels, nD, max, !!yLabel, isFullscreen);
      const { pad, ch, step } = L;
      const ci = Math.floor((mx - pad.l) / step);
      if (ci >= 0 && ci < labels.length && mx >= pad.l) {
        if (multi && isBar) {
          const totals = categories!.map((_, c) => series!.reduce((s, sr) => s + (sr.values[c] || 0), 0));
          const yVal = ((pad.t + ch - my) / ch) * max;
          let acc = 0, si: number | null = null;
          for (let s = 0; s < series!.length; s++) {
            acc += series![s].values[ci] || 0;
            if (yVal <= acc) { si = s; break; }
          }
          if (si !== null && yVal <= totals[ci]) {
            seg = { c: ci, s: si };
            text = `${categories![ci]} · ${series![si].name}: ${series![si].values[ci] || 0} (total ${totals[ci]})`;
          }
        } else if (multi) {
          const depth = seriesDepth(series!);
          let best = 20, bs: number | null = null;
          series!.forEach((s, si) => {
            const yy = pad.t + ch - ((s.values[ci] || 0) / max) * ch - ZY * m * depth[si];
            const dd = Math.abs(my - yy);
            if (dd < best) { best = dd; bs = si; }
          });
          if (bs !== null) {
            seg = { c: ci, s: bs };
            text = `${categories![ci]} · ${series![bs].name}: ${series![bs].values[ci] || 0}`;
          }
        } else {
          idx = ci;
          text = `${singleData[ci].label}: ${singleData[ci].value}`;
        }
      }
    }

    setHoverIdx(idx);
    setHoverSeg(seg);
    setTip(idx !== null || seg !== null ? { x: mx, y: my, text } : null);
  };

  const legend = kind === 'stream'
    // ONE labelled row under the card — the ONLY place nation colour
    // labels appear. The scene itself never renders its own legend/shelf,
    // so there is no double set of colour labels anywhere for this chart.
    ? STREAM_COUNTRIES.map((c) => ({ label: c.name, color: c.color }))
    : (kind === 'radialbars' && !multi)
      // Semantic legend mirroring 3dRadialBarChart.html's legend card — the
      // bars are ONE blue material, so per-category swatches would lie.
      ? [
        { label: 'Current (bar)', color: '#2563eb' },
        { label: 'Prior (marker)', color: '#ef4444' },
        { label: '▲ Increased', color: '#2563eb' },
        { label: '▼ Fell', color: '#ef4444' },
        { label: 'Average (dashed)', color: '#f87171' },
      ]
      : kind === 'radialbar'
        // Single source of truth for this chart's labels — the SAME
        // preset legend the Three.js scene and its exports use, so it is
        // never shown twice or disagrees with the on-canvas colours.
        ? radialLegendFor(radialPreset)
        : (kind === 'sankey' || kind === 'sankey3d')
        ? (() => { const names = [...new Set((links || []).flatMap((l) => [l.source, l.target]))]; return names.map((n, i) => ({ label: n, color: pal[i % pal.length] })); })()
        : multi
          ? series!.map((s, i) => ({ label: s.name, color: kind === 'dual' && i > 0 ? distinctLineColor([sColors[0]], sColors[i], pal) : sColors[i] }))
          : singleData.map((x, i) => ({ label: x.label, color: colors[i] }));

  /* exports */
  const doExport = async (fmt: string) => {
    const cv = canvasRef.current;
    if (!cv) return;
    const base = (title || 'chart').toLowerCase().replace(/\s+/g, '-');
    const m = effDim === '3d' ? 1 : 0;
    const legendItems = legend;

    if ((fmt === 'png' || fmt === 'svg' || fmt === 'pdf' || fmt === 'print') && (isThreeRadial || isThreeSankeyPro || isThreeStream || isThreeRBC)) {
      const api = isThreeRadial ? threeRadialRef.current : isThreeStream ? threeStreamRef.current : isThreeRBC ? threeRBCRef.current : threeSankeyRef.current;
      if (!api) return;
      if (fmt === 'svg') {
        const svg = await api.exportSVG(title || 'Chart');
        downloadBlob(`${base}.svg`, new Blob([svg], { type: 'image/svg+xml' }));
        return;
      }
      const blob = await api.exportPNG(title || 'Chart');
      if (fmt === 'png') { downloadBlob(`${base}.png`, blob); return; }
      const dataUrl: string = await new Promise((resolve) => { const r = new FileReader(); r.onload = () => resolve(r.result as string); r.readAsDataURL(blob); });
      const img = await new Promise<HTMLImageElement>((resolve) => { const im = new Image(); im.onload = () => resolve(im); im.src = dataUrl; });
      const out = document.createElement('canvas'); out.width = img.width; out.height = img.height;
      out.getContext('2d')!.drawImage(img, 0, 0);
      if (fmt === 'pdf') {
        const jpegUrl = out.toDataURL('image/jpeg', 0.94);
        const bytes = Uint8Array.from(atob(jpegUrl.split(',')[1]), (c) => c.charCodeAt(0));
        downloadBlob(`${base}.pdf`, jpegToPdf(bytes, out.width, out.height));
      } else if (fmt === 'print') {
        printCanvas(title || 'Chart', out);
      }
      return;
    }

    if (fmt === 'csv' && (kind === 'sankey' || kind === 'sankey3d')) {
      downloadBlob(`${base}.csv`, new Blob(['source,target,value\n' + (links || []).map((l) => `"${l.source}","${l.target}",${l.value}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'csv' && kind === 'calendarpie') {
      downloadBlob(`${base}.csv`, new Blob(['date,' + series!.map((x) => `"${x.name}"`).join(',') + '\n' + (days || []).map((x) => `${x.date},${x.values.join(',')}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if ((fmt === 'csv' || fmt === 'json' || fmt === 'excel') && kind === 'stream') {
      // Streamgraph's data is ALWAYS the supplied reference's own Olympic
      // medal dataset (verbatim, regardless of `categories`/`series` props)
      // — every export format reflects exactly what the chart shows.
      const periods = STREAM_EDITIONS.map((e) => `${e.yr} ${e.name}`);
      if (fmt === 'csv') {
        const csv = 'edition,' + STREAM_COUNTRIES.map((c) => `"${c.name}"`).join(',') + '\n' +
          periods.map((p, i) => `"${p}",` + STREAM_COUNTRIES.map((c) => c.vals[i] || 0).join(',')).join('\n');
        downloadBlob(`${base}.csv`, new Blob([csv], { type: 'text/csv' }));
        return;
      }
      if (fmt === 'json') {
        downloadBlob(`${base}.json`, new Blob([JSON.stringify({ editions: STREAM_EDITIONS, countries: STREAM_COUNTRIES }, null, 2)], { type: 'application/json' }));
        return;
      }
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Chart Data');
      ws.mergeCells(1, 1, 1, STREAM_COUNTRIES.length + 1);
      const titleCell = ws.getCell(1, 1);
      titleCell.value = (title || 'Chart').toUpperCase();
      titleCell.font = { bold: true, size: 13, color: { argb: 'FF0D7A54' } };
      const head0 = ws.addRow(['Edition', ...STREAM_COUNTRIES.map((c) => c.name)]);
      head0.eachCell((cell: { font: unknown; fill: unknown }) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
      });
      periods.forEach((p, i) => ws.addRow([p, ...STREAM_COUNTRIES.map((c) => c.vals[i] || 0)]));
      ws.getColumn(1).width = 24;
      const buf0 = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf0], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }
    if (fmt === 'json' && isSpecialFlow) {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify((kind === 'sankey' || kind === 'sankey3d') ? { links } : { series: series!.map((x) => x.name), days }, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel' && isSpecialFlow) {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Chart Data');
      const head = ws.addRow((kind === 'sankey' || kind === 'sankey3d') ? ['Source', 'Target', 'Value'] : ['Date', ...series!.map((x) => x.name)]);
      head.eachCell((cell: { font: unknown; fill: unknown }) => { cell.font = { bold: true, color: { argb: 'FFFFFFFF' } }; cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } }; });
      if (kind === 'sankey' || kind === 'sankey3d') (links || []).forEach((l) => ws.addRow([l.source, l.target, l.value])); else (days || []).forEach((x) => ws.addRow([x.date, ...x.values]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }

    if (fmt === 'csv') {
      const csv = multi
        ? 'category,' + series!.map((s) => `"${s.name}"`).join(',') + '\n' +
          categories!.map((c, i) => `"${c}",` + series!.map((s) => s.values[i] || 0).join(',')).join('\n')
        : 'label,value\n' + singleData.map((x) => `"${x.label}",${x.value}`).join('\n');
      downloadBlob(`${base}.csv`, new Blob([csv], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'json') {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify(multi ? { categories, series } : singleData, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel') {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Chart Data');
      ws.mergeCells(1, 1, 1, multi ? series!.length + 1 : 2);
      const titleCell = ws.getCell(1, 1);
      titleCell.value = (title || 'Chart').toUpperCase();
      titleCell.font = { bold: true, size: 13, color: { argb: 'FF0D7A54' } };
      const head = ws.addRow(multi ? ['Category', ...series!.map((s) => s.name)] : ['Label', 'Value']);
      head.eachCell((cell: { font: unknown; fill: unknown }) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
      });
      if (multi) categories!.forEach((c, i) => ws.addRow([c, ...series!.map((s) => s.values[i] || 0)]));
      else singleData.forEach((x) => ws.addRow([x.label, x.value]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }

    await fontsReady();
    const tEx = themeColors(true);
    if (fmt === 'svg') {
      // SVG mirrors the chart EXACTLY as shown: same canvas size, same layout mode
      // (compact/fullscreen label fitting), same fonts — embedded so it renders
      // identically anywhere, at any zoom, without depending on installed fonts.
      // Toroid included: its painter has a dedicated TRUE-vector branch (a
      // faceted torus mesh emitted as flat-shaded polygons through this SVG
      // recorder — pure <path> nodes, no <image>, identical lighting to the
      // live canvas), so the generic recorder path IS the true-SVG path.
      //
      // SMALL-TILE FIX: the toroid's quad/facet COUNT is already fixed
      // (data.length-based, independent of canvas size — see `ringSteps`/
      // `tubeSteps` in the toroid painter), but exporting used the LIVE
      // on-screen tile's own client size — a small, non-fullscreen card
      // could be as little as ~140px across. At that size the torus's own
      // radius shrinks to just a few dozen px, so the SAME facet count
      // spans far fewer degrees each — every facet edge becomes a
      // visually larger fraction of the whole shape once someone actually
      // VIEWS the exported file at a normal size, reading as "not smooth"
      // even though the vector data itself never lost precision. PNG/PDF
      // exports never had this problem because they already render at a
      // canonical `exportDims()` size regardless of the live tile — the
      // toroid's SVG export now does the same, so its absolute size (and
      // therefore facet density) is always consistent.
      const useCanonicalDims = kind === 'toroid';
      const { W: Ws, H: Hs } = useCanonicalDims
        ? exportDims(kind, cv.clientWidth, cv.clientHeight, singleData, multi, categories || [], m)
        : { W: cv.clientWidth, H: cv.clientHeight };
      // FILE-SIZE FIX: embedded @font-face base64 (not the geometry) is the
      // dominant cost of the toroid's SVG — the generic path always
      // requests BOTH weights (600 AND 700) for BOTH the body AND display
      // font families (up to 4 separate ~20–40 KB embedded files), but the
      // toroid painter only ever actually sets body-600 (leader labels)
      // and display-700 (centre total). Requesting exactly those two
      // (font,weight) pairs — not the generic 2×2 — roughly halves the
      // embedded payload with zero loss: every glyph the file actually
      // uses is still embedded, nothing else is.
      const fontCss = kind === 'toroid'
        ? (await Promise.all([
          fontFaceCss([tEx.fontBody || DEF_BODY], ['600']),
          (tEx.fontDisplay || DEF_DISPLAY) === (tEx.fontBody || DEF_BODY) ? Promise.resolve('') : fontFaceCss([tEx.fontDisplay || DEF_DISPLAY], ['700']),
        ])).join('')
        : await fontFaceCss(fontFamilies(tEx), ['600', '700']);
      const svgPainter = (ctx: Ctx) => paintChart(ctx, kind, { ...buildCtx(Ws, Hs, 1, m, NO_HOVER, true), full: useCanonicalDims ? true : isFullscreen });
      downloadBlob(`${base}.svg`, new Blob([composeSvg(title || '', Ws, Hs, legendItems, svgPainter, tEx, fontCss)], { type: 'image/svg+xml' }));
      return;
    }
    const { W: Wx, H: Hx } = exportDims(kind, cv.clientWidth, cv.clientHeight, singleData, multi, categories || [], m);
    const painter = (ctx: Ctx) => paint(ctx, Wx, Hx, 1, m, NO_HOVER, true);
    const out = composeExport(title || '', Wx, Hx, legendItems, painter, tEx);
    if (fmt === 'png') out.toBlob((b) => b && downloadBlob(`${base}.png`, b), 'image/png');
    else if (fmt === 'pdf') {
      const dataUrl = out.toDataURL('image/jpeg', 0.94);
      const bytes = Uint8Array.from(atob(dataUrl.split(',')[1]), (c) => c.charCodeAt(0));
      downloadBlob(`${base}.pdf`, jpegToPdf(bytes, out.width, out.height));
    } else if (fmt === 'print') printCanvas(title || 'Chart', out);
  };


  const containerRef = useRef<HTMLDivElement>(null);
  const [isFs, setIsFs] = useState(false);

  useEffect(() => {
    const onFs = () => {
      const active = !!document.fullscreenElement && document.fullscreenElement === containerRef.current;
      setIsFs(active);
    };
    document.addEventListener('fullscreenchange', onFs);
    document.addEventListener('webkitfullscreenchange', onFs);
    return () => {
      document.removeEventListener('fullscreenchange', onFs);
      document.removeEventListener('webkitfullscreenchange', onFs);
    };
  }, []);

  /* Lock the page scroll while the CSS-fallback overlay is open so the page
     behind the fullscreen dialog never shifts or gains scrollbars. */
  useEffect(() => {
    if (!full) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, [full]);

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      try {
        if (containerRef.current?.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        } else if ((containerRef.current as unknown as { webkitRequestFullscreen?: () => Promise<void> })?.webkitRequestFullscreen) {
          await (containerRef.current as unknown as { webkitRequestFullscreen: () => Promise<void> }).webkitRequestFullscreen();
        }
        setIsFs(true);
      } catch {
        setFull(true);
      }
    } else {
      try {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as unknown as { webkitExitFullscreen?: () => Promise<void> })?.webkitExitFullscreen) {
          await (document as unknown as { webkitExitFullscreen: () => Promise<void> }).webkitExitFullscreen();
        }
      } catch { /* noop */ }
      setIsFs(false);
      setFull(false);
    }
  };

  const body = (
    <div ref={containerRef} className={`tk-card ${isFs ? '!fixed !inset-0 !z-[100] !w-screen !h-screen !max-w-[100vw] !m-0 !rounded-none !p-6 sm:!p-10 flex flex-col overflow-y-auto overflow-x-hidden bg-(--t-surface)' : 'p-4'}`}>
      {/* The toolbar no longer carries a z-index: the MiniDrop menus are
          portalled out of the card, so no stacking-context arms race is
          needed (or wanted) between sibling chart cards. */}
      <div className="relative mb-3 flex flex-wrap items-center gap-2">
        {title && <p className={`mr-auto font-display font-semibold text-ink ${isFs ? 'text-xl' : 'text-[15px]'}`}>{title}</p>}
        {meta.has3d && (
          <div className="tk-inset flex gap-0.5 p-1">
            {(['2d', '3d'] as const).map((dd) => (
              <button key={dd} onClick={() => setDim(dd)} disabled={loading || (dd === '3d' && !meta.has3d)}
                className={`flex items-center gap-1 rounded-lg px-2.5 py-1 font-body text-[11px] font-bold uppercase transition disabled:opacity-30 ${effDim === dd ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}>
                {dd === '2d' ? <Square size={11} /> : <Box size={11} />} {dd}
              </button>
            ))}
          </div>
        )}
        <MiniDrop label={meta.label} activeKey={kind}
          items={KINDS.map((k) => ({ key: k.key, label: k.label }))}
          onPick={(k) => { setKind(k as ChartKind); setHoverIdx(null); setHoverSeg(null); setTip(null); }} />
        {isThreeRadial && (
          <MiniDrop label="Version" activeKey={radialPreset}
            items={RADIAL_PRESET_OPTIONS.map((o) => ({ key: o.key, label: o.label }))}
            onPick={(k) => { setRadialPreset(k as RadialPresetKey); setHoverIdx(null); }} />
        )}
        <MiniDrop label="Export" icon={<Download size={12} />}
          items={[
            { key: 'png', label: 'PNG image' },
            { key: 'svg', label: 'SVG vector' },
            { key: 'pdf', label: 'PDF document' },
            { key: 'excel', label: 'Excel workbook' },
            { key: 'print', label: 'Print…' },
            { key: 'csv', label: 'CSV data' },
            { key: 'json', label: 'JSON data' },
          ]}
          onPick={doExport} />
        {!isFullscreen && (
          <button onClick={toggleFullscreen} data-tip={isFs ? "Exit fullscreen" : "View fullscreen"} className="tk-btn-ghost rounded-xl p-2">
            {isFs ? <Minimize2 size={15} /> : <Eye size={14} />}
          </button>
        )}
      </div>

      <div className="relative flex-1 w-full min-h-0" style={{ height: isFs ? 'calc(100vh - 160px)' : isThreeStream ? Math.max(height, 560) : (isThreeRadial || kind === 'radialbars') ? Math.max(height, 460) : height }}>
        {loading ? (
          <ChartSkeleton kind={skeletonKind(kind)} height={isFs ? 500 : height} legend={false} />
        ) : (
          <>
            <canvas ref={canvasRef}
              style={{
                width: '100%', height: '100%',
                cursor: undefined,
                opacity: canvasHidden ? 0 : 1, transition: 'opacity 320ms ease',
                pointerEvents: canvasHidden ? 'none' : 'auto',
              }}
              onMouseMove={(e) => { orbitMove(e); if (!dragRef.current?.moved) hit(e); }}
              onMouseDown={orbitDown} onMouseUp={orbitUp}
              onMouseLeave={() => { orbitUp(); setHoverIdx(null); setHoverSeg(null); setTip(null); }} />
            {kind === 'toroid' && booting && (
              <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center gap-2.5 bg-(--t-surface) font-body text-[12.5px] font-semibold text-muted">
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent opacity-70" />
                Loading chart…
              </div>
            )}
            {!canvasHidden && tip && (
              <div className="tk-pop pointer-events-none absolute z-10 px-2.5 py-1 font-body text-[11px] font-bold text-ink"
                style={{ left: Math.min(tip.x + 12, (canvasRef.current?.clientWidth || 300) - 170), top: Math.max(0, tip.y - 34) }}>
                {tip.text}
              </div>
            )}
            {isThreeSankeyPro && (
              <div className="absolute inset-0" style={{ opacity: 1, transition: 'opacity 320ms ease' }}>
                <Suspense fallback={null}>
                  <ThreeSankey3D ref={threeSankeyRef} links={links || []} palette={pal} theme={exportTheme}
                    dim={effDim} dark={themeRef.current.dark} hoverIndex={hoverIdx}
                    onHover={(text) => {
                      // Hovering inside the 3D scene mirrors back to the card
                      // legend; the 3D tooltip itself is owned by the scene.
                      if (!text) { setHoverIdx(null); return; }
                      const names = [...new Set((links || []).flatMap((l) => [l.source, l.target]))];
                      const ni = names.findIndex((n) => text.startsWith(n));
                      setHoverIdx(ni >= 0 ? ni : null);
                    }} />
                </Suspense>
              </div>
            )}
            {isThreeRadial && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <ThreeReferenceRadialBar ref={threeRadialRef} presetKey={radialPreset} dim={effDim} theme={exportTheme}
                    dark={themeRef.current.dark} hoverIndex={hoverIdx}
                    onHover={(idx) => setHoverIdx(idx)} />
                </Suspense>
              </div>
            )}
            {isThreeStream && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <ThreeStreamgraph ref={threeStreamRef} categories={multi ? categories : undefined}
                    series={multi ? series : undefined} palette={TOROID_GLOSS} dim={effDim} theme={exportTheme}
                    dark={themeRef.current.dark} hoverIndex={hoverSeg ? hoverSeg.s : null}
                    onHover={(_idx, text) => {
                      // Mirror the WebGL hover back to the card legend; the
                      // 3D tooltip itself is owned by the scene.
                      if (_idx === null || _idx === undefined) { setHoverSeg(null); return; }
                      setHoverSeg({ c: -1, s: _idx });
                      void text;
                    }} />
                </Suspense>
              </div>
            )}
            {isThreeRBC && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <ThreeRadialBarsCircular ref={threeRBCRef} data={singleData}
                    categories={multi ? categories : undefined} series={multi ? series : undefined}
                    palette={pal} dim={effDim} theme={exportTheme}
                    dark={themeRef.current.dark} hoverIndex={hoverIdx}
                    onHover={(idx) => setHoverIdx(idx)} />
                </Suspense>
              </div>
            )}
          </>
        )}
      </div>

      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <span key={i} className="tk-skeleton h-2.5" style={{ width: 48 + (i % 3) * 18 }} />)
          : legend.map((l, i) => (
            <button key={l.label + i}
              onMouseEnter={() => ((kind === 'sankey' || kind === 'sankey3d') ? setHoverIdx(i) : (multi || kind === 'stream') ? setHoverSeg({ c: -1, s: i }) : setHoverIdx(i))}
              onMouseLeave={() => { setHoverIdx(null); setHoverSeg(null); }}
              className={`flex items-center gap-1.5 font-body text-[11px] font-semibold transition ${(multi ? hoverSeg?.s === i : hoverIdx === i) ? 'text-ink' : 'text-muted'}`}>
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: l.color }} /> {l.label}
            </button>
          ))}
      </div>

      {insight && insight.length > 0 && (
        <div className="tk-inset mt-3 space-y-1 rounded-xl px-3.5 py-2.5">
          {insight.map((line, i) => <p key={i} className="font-body text-[11.5px] text-ink/70">• {line}</p>)}
        </div>
      )}
    </div>
  );

  return (
    <>
      {body}
      {/* CSS-fallback fullscreen (used when native requestFullscreen fails or is
          unavailable, e.g. inside an iframe without allow="fullscreen"). The
          overlay locks the page scroll (body overflow hidden) so the page
          behind never scrolls, and clips horizontally so an opening dropdown
          can never summon an x-axis scrollbar. */}
      {full && createPortal(
        <div className="fixed inset-0 z-[100] flex flex-col bg-(--t-surface) p-6 sm:p-10 backdrop-blur-md overflow-y-auto overflow-x-hidden max-w-[100vw]"
          onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) setFull(false); }}>
          <div className="mb-3 flex justify-between items-center">
            {title && <h2 className="font-display text-xl font-bold text-ink">{title}</h2>}
            <button onClick={() => setFull(false)} className="tk-btn-ghost rounded-full p-2.5 ml-auto"><X size={18} /></button>
          </div>
          <div className="flex-1 w-full min-w-0 max-w-full">
            <Chart data={data} categories={categories} series={series} title={title}
              defaultKind={kind} defaultDim={effDim} height={window.innerHeight - 180} extraKinds={extraKinds}
              yLabel={yLabel} insight={insight} days={days} links={links} tasks={tasks} scatter={scatter} streamEvents={streamEvents} isFullscreen />
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

/* ================= StackedColumns (compat wrapper) ================= */
export function StackedColumns({ title, categories, series, height = 300, yLabel = 'Employees', insight }: {
  title: string; categories: string[]; series: StackedSeries[]; height?: number; yLabel?: string; insight?: string[];
}) {
  return <Chart title={title} categories={categories} series={series} defaultKind="bar" height={height} yLabel={yLabel} insight={insight} />;
}

/* ============================================================
   Neumorphic chart family v3 — reference soft-UI depth
   (extruded puck · inset groove ring · carved wedges with divider
   grooves · raised centre button · on-slice % labels). ONE canvas
   painter drives the live chart AND every export, so nothing is
   ever missing or truncated and fonts are preserved.
   ============================================================ */
export type NeuKind = 'donut' | 'pie' | 'bars' | 'columns' | 'line' | 'area';
const NEU_KINDS: { key: NeuKind; label: string }[] = [
  { key: 'donut', label: 'Donut' },
  { key: 'pie', label: 'Pie' },
  { key: 'bars', label: 'Bars' },
  { key: 'columns', label: 'Columns' },
  { key: 'line', label: 'Line' },
  { key: 'area', label: 'Area' },
];

interface NeuTones { surface: string; hi: string; lo: string; shadowDark: string; shadowLight: string; groove: string; grooveHi: string; muted: string; grid: string }
function neuTones(t: Theme): NeuTones {
  const dark = !!t.dark;
  const surface = t.surface || '#e4e7e0';
  return {
    surface,
    hi: shade(surface, dark ? 1.1 : 1.045),
    lo: shade(surface, dark ? 0.88 : 0.962),
    shadowDark: dark ? 'rgba(0,0,0,0.55)' : rgba(t.ink, 0.24),
    shadowLight: dark ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.92)',
    groove: dark ? 'rgba(0,0,0,0.5)' : rgba(t.ink, 0.14),
    grooveHi: dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.85)',
    muted: rgba(t.ink, 0.55),
    grid: rgba(t.ink, 0.16),
  };
}
function setShadow(ctx: Ctx, x: number, y: number, blur: number, color: string) {
  ctx.shadowOffsetX = x; ctx.shadowOffsetY = y; ctx.shadowBlur = blur; ctx.shadowColor = color;
}
function noShadow(ctx: Ctx) { ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; ctx.shadowColor = 'rgba(0,0,0,0)'; }
function circle(ctx: Ctx, cx: number, cy: number, r: number) { ctx.beginPath(); ctx.arc(cx, cy, Math.max(0.1, r), 0, Math.PI * 2); ctx.closePath(); }
/** Extruded soft disc: dark shadow bottom-right, light shadow top-left, gentle sheen. */
function raisedDisc(ctx: Ctx, cx: number, cy: number, r: number, n: NeuTones, spread = 1) {
  ctx.save();
  setShadow(ctx, 7 * spread, 7 * spread, 16 * spread, n.shadowDark); ctx.fillStyle = n.surface; circle(ctx, cx, cy, r); ctx.fill();
  setShadow(ctx, -6 * spread, -6 * spread, 14 * spread, n.shadowLight); circle(ctx, cx, cy, r); ctx.fill();
  noShadow(ctx);
  const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
  g.addColorStop(0, n.hi); g.addColorStop(1, n.lo);
  ctx.fillStyle = g; circle(ctx, cx, cy, r); ctx.fill();
  ctx.restore();
}
/** Inset groove ring (trench) — dark inner edge top-left, light edge bottom-right. */
function grooveRing(ctx: Ctx, cx: number, cy: number, r: number, n: NeuTones, w = 2.6) {
  ctx.lineWidth = w; ctx.strokeStyle = n.groove; circle(ctx, cx - 0.7, cy - 0.7, r); ctx.stroke();
  ctx.lineWidth = w * 0.6; ctx.strokeStyle = n.grooveHi; circle(ctx, cx + 0.9, cy + 0.9, r); ctx.stroke();
  ctx.lineWidth = w * 0.45; ctx.strokeStyle = n.surface; circle(ctx, cx, cy, r); ctx.stroke();
  ctx.lineWidth = 1;
}
/** Inset track (rounded rect trench) for bars / columns / plot panels. */
function insetTrack(ctx: Ctx, x: number, y: number, w: number, h: number, n: NeuTones, r?: number) {
  const rr = Math.min(r ?? h / 2, w / 2, h / 2);
  ctx.fillStyle = n.lo; ctx.beginPath(); ctx.roundRect(x, y, w, h, rr); ctx.fill();
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, n.groove); g.addColorStop(1, n.grooveHi);
  ctx.strokeStyle = g; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.roundRect(x + 0.6, y + 0.6, w - 1.2, h - 1.2, Math.max(0, rr - 0.6)); ctx.stroke();
  ctx.lineWidth = 1;
}
function wedgePath(ctx: Ctx, cx: number, cy: number, R: number, rIn: number, a0: number, a1: number) {
  ctx.beginPath();
  if (rIn > 0) { ctx.arc(cx, cy, R, a0, a1); ctx.arc(cx, cy, rIn, a1, a0, true); ctx.closePath(); }
  else { ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, a0, a1); ctx.closePath(); }
}

export interface NeuDraw { data: ChartDatum[]; colors: string[]; t: Theme; p: number; hover: number | null; amt: number; centerLabel: string; full: boolean }

/* ---- circular: puck + groove ring + carved wedges + raised centre ---- */
export function paintNeuCircular(ctx: Ctx, isDonut: boolean, cx: number, cy: number, R: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const { data, colors, p, hover, amt } = d;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const rIn = isDonut ? R * 0.56 : 0;
  const scale = 0.94 + 0.06 * clamp01(p * 1.4);

  ctx.save();
  if (scale < 0.999) { ctx.translate(cx, cy); ctx.scale(scale, scale); ctx.translate(-cx, -cy); }
  raisedDisc(ctx, cx, cy, R + 18, n);
  grooveRing(ctx, cx, cy, R + 9, n);

  let a = -Math.PI / 2;
  const mids: number[] = [];
  data.forEach((x, i) => {
    const frac = x.value / total;
    const a1 = a + frac * Math.PI * 2 * p;
    const mid = (a + a1) / 2;
    mids.push(mid);
    const on = hover === i;
    const off = on ? 6 * amt : 0;
    const col = colors[i];
    ctx.save();
    ctx.globalAlpha = hover !== null && !on ? 1 - 0.42 * amt : 1;
    ctx.translate(Math.cos(mid) * off, Math.sin(mid) * off);
    wedgePath(ctx, cx, cy, R, rIn, a, a1);
    const g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
    g.addColorStop(0, shade(col, 1.14)); g.addColorStop(1, shade(col, 0.86));
    setShadow(ctx, 2, 3, on ? 10 : 6, on ? rgba(col, 0.55) : 'rgba(0,0,0,0.28)');
    ctx.fillStyle = g; ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = n.surface; ctx.lineWidth = 3; ctx.lineJoin = 'round'; ctx.stroke(); // divider grooves
    ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 1; ctx.stroke();          // bevel
    ctx.lineJoin = 'miter';
    ctx.restore();
    a = a1;
  });

  // on-slice % labels (fade in as the sweep completes)
  if (p > 0.85) {
    ctx.save();
    ctx.globalAlpha = clamp01((p - 0.85) / 0.15);
    ctx.font = font(d.t, 700, R >= 110 ? 12 : R >= 80 ? 10.5 : 9.5);
    ctx.textAlign = 'center';
    setShadow(ctx, 0, 1, 2, 'rgba(0,0,0,0.45)');
    data.forEach((x, i) => {
      const frac = x.value / total;
      if (frac < 0.06) return;
      const on = hover === i;
      const off = on ? 6 * amt : 0;
      const lr = (rIn > 0 ? (R + rIn) / 2 : R * 0.62) + off;
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`${Math.round(frac * 100)}%`, cx + Math.cos(mids[i]) * lr, cy + Math.sin(mids[i]) * lr + 3.5);
    });
    ctx.restore();
  }

  // raised centre button (donut) — total or hovered slice
  if (isDonut) {
    const cr = rIn - 7;
    raisedDisc(ctx, cx, cy, cr, n, 0.7);
    ctx.strokeStyle = rgba(d.t.ink, 0.08); ctx.lineWidth = 1; circle(ctx, cx, cy, cr - 3); ctx.stroke();
    const value = hover !== null ? data[hover].value : total;
    const label = hover !== null ? data[hover].label : d.centerLabel;
    const vs = Math.max(13, Math.min(28, cr * 0.5));
    ctx.textAlign = 'center';
    ctx.fillStyle = d.t.ink; ctx.font = font(d.t, 700, vs, true);
    ctx.fillText(fitCtx(ctx, String(value), cr * 1.7), cx, cy + vs * 0.18);
    ctx.fillStyle = n.muted; ctx.font = font(d.t, 700, Math.max(7.5, Math.min(10, cr * 0.18)));
    ctx.fillText(fitCtx(ctx, label.toUpperCase(), cr * 1.7), cx, cy + vs * 0.18 + Math.max(10, cr * 0.24));
  }
  ctx.restore();
  ctx.textAlign = 'left';
}

/* ---- horizontal soft bars (export painter; live uses DOM) ---- */
function paintNeuBars(ctx: Ctx, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const max = Math.max(...d.data.map((x) => x.value), 1);
  const N = d.data.length;
  const rowH = Math.min(48, (H - 12) / Math.max(1, N));
  d.data.forEach((x, i) => {
    const y = 8 + i * rowH;
    const col = d.colors[i];
    ctx.font = font(d.t, 600, 11.5); ctx.fillStyle = rgba(d.t.ink, 0.78); ctx.textAlign = 'left';
    ctx.fillText(x.label, 14, y + 12);
    ctx.font = font(d.t, 700, 11.5); ctx.fillStyle = d.t.ink; ctx.textAlign = 'right';
    ctx.fillText(String(x.value), W - 14, y + 12);
    const tx = 14, ty = y + 19, tw = W - 28, th = 14;
    insetTrack(ctx, tx, ty, tw, th, n);
    const bw = Math.max(th, tw * (x.value / max) * d.p);
    const g = ctx.createLinearGradient(tx, ty, tx + bw, ty + th);
    g.addColorStop(0, col); g.addColorStop(1, shade(col, 0.82));
    setShadow(ctx, 1, 1, 3, 'rgba(0,0,0,0.25)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(tx, ty, bw, th, 7); ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(tx + 1, ty + 1, bw - 2, th - 2, 6); ctx.stroke();
  });
  ctx.textAlign = 'left';
}

/* ---- vertical soft columns (export painter; live uses DOM) ---- */
function paintNeuColumns(ctx: Ctx, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const max = Math.max(...d.data.map((x) => x.value), 1);
  const N = d.data.length;
  const padT = 28, padR = 14;
  const { plan, l: padL, step } = planXFit(d.data.map((x) => x.label), W, 14, padR, d.full, 9.5, N);
  const ch = Math.max(30, H - padT - plan.padB - 6);
  const colW = Math.min(44, step * 0.62);
  d.data.forEach((x, i) => {
    const cx = padL + step * i + step / 2;
    const col = d.colors[i];
    insetTrack(ctx, cx - colW / 2, padT, colW, ch, n, 12);
    const h = Math.max(6, ch * (x.value / max) * d.p);
    const g = ctx.createLinearGradient(cx - colW / 2, padT + ch - h, cx + colW / 2, padT + ch);
    g.addColorStop(0, col); g.addColorStop(1, shade(col, 0.82));
    setShadow(ctx, 0, -1, 3, 'rgba(0,0,0,0.18)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(cx - colW / 2, padT + ch - h, colW, h, 12); ctx.fill();
    noShadow(ctx);
    ctx.font = font(d.t, 700, 10.5); ctx.fillStyle = rgba(d.t.ink, 0.72); ctx.textAlign = 'center';
    ctx.fillText(String(x.value), cx, padT - 9);
  });
  drawXLabels(ctx, d.data.map((x) => x.label), plan, (i) => padL + step * i + step / 2, padT + ch, d.t, W, 700, n.muted);
}

/* ---- soft line / area: inset panel, dotted grid, adaptive labels & markers ---- */
interface NeuLineLayout { padL: number; padT: number; cw: number; ch: number; step: number; plan: XPlan; xOf: (i: number) => number; yOf: (v: number) => number; max: number }
function neuLineLayout(W: number, H: number, data: ChartDatum[], full: boolean): NeuLineLayout {
  const max = Math.max(...data.map((x) => x.value), 1);
  const fs = 10;
  const padR = 18, padT = 24;
  const N = data.length;
  const { plan, l: padL, step } = planXFit(data.map((x) => x.label), W, 14 + approxW(fmtNum(max), 9.5) + 12, padR, full, fs, N, true);
  const cw = Math.max(10, W - padL - padR);
  const ch = Math.max(20, H - padT - plan.padB - 6);
  return {
    padL, padT, cw, ch, step, plan, max,
    xOf: (i) => padL + (N > 1 ? step * i : cw / 2),
    yOf: (v) => padT + ch * (1 - v / max),
  };
}
export function paintNeuLine(ctx: Ctx, isArea: boolean, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const { data, colors, p, hover } = d;
  if (!data.length) return;
  const L = neuLineLayout(W, H, data, d.full);
  const { padL, padT, cw, ch, step, plan, xOf, yOf, max } = L;
  const col = colors[0];
  const N = data.length;

  // inset plot panel
  const px0 = padL - 10, py0 = padT - 12, pw = cw + 22, ph = ch + 24;
  insetTrack(ctx, px0, py0, pw, ph, n, 16);
  // dotted grid — aligns to points when few, otherwise a 6-column lattice
  const gcols = N <= 12 ? N : 6;
  ctx.fillStyle = n.grid;
  for (let gx = 0; gx < gcols; gx++) for (let gy = 0; gy <= 3; gy++) {
    const x = N <= 12 ? xOf(gx) : padL + (gx * cw) / 5;
    circle(ctx, x, padT + (gy * ch) / 3, 1.4); ctx.fill();
  }
  // y ticks
  ctx.font = font(d.t, 600, 9.5); ctx.fillStyle = n.muted; ctx.textAlign = 'right';
  for (let g = 0; g <= 3; g++) ctx.fillText(fmtNum((max * g) / 3), padL - 14, padT + ch - (ch * g) / 3 + 3.5);

  const pts = data.map((x, i) => ({ x: xOf(i), y: yOf(x.value) }));
  // reveal left → right while the entrance animation runs (live only)
  const revealing = p < 1 && typeof ctx.clip === 'function';
  if (revealing) { ctx.save(); ctx.beginPath(); ctx.rect(0, 0, padL + cw * p + 10, H); ctx.clip(); }
  const curve = () => {
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
      ctx.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y - (p3.y - p1.y) / 6, p2.x, p2.y);
    }
  };
  if (isArea && N > 1) {
    ctx.beginPath(); curve();
    ctx.lineTo(pts[pts.length - 1].x, padT + ch); ctx.lineTo(pts[0].x, padT + ch); ctx.closePath();
    const g = ctx.createLinearGradient(0, padT, 0, padT + ch);
    g.addColorStop(0, rgba(col, 0.36)); g.addColorStop(1, rgba(col, 0.03));
    ctx.fillStyle = g; ctx.fill();
  }
  if (N > 1) {
    setShadow(ctx, 2, 3, 3, rgba(d.t.ink, 0.28));
    ctx.strokeStyle = col; ctx.lineWidth = N > 40 ? 2.2 : 3.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); curve(); ctx.stroke();
    noShadow(ctx);
    ctx.lineCap = 'butt'; ctx.lineJoin = 'miter';
  }
  // markers thin out automatically; the hovered point is always shown
  const showAll = step >= 12;
  pts.forEach((pt, i) => {
    const on = hover === i;
    if (!showAll && !on) return;
    setShadow(ctx, 1.5, 1.5, 2, rgba(d.t.ink, 0.25));
    ctx.fillStyle = n.surface; circle(ctx, pt.x, pt.y, on ? 7 : step < 26 ? 4.2 : 5.5); ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = col; ctx.lineWidth = 2.5; ctx.stroke();
  });
  if (revealing) ctx.restore();

  drawXLabels(ctx, data.map((x) => x.label), plan, xOf, padT + ch + 10, d.t, W, 700, n.muted);
}

/* ---- export composition for the neumorphic family ---- */
export function neuExportDims(kind: NeuKind, data: ChartDatum[]): { W: number; H: number } {
  const N = data.length;
  if (kind === 'donut' || kind === 'pie') {
    const total = data.reduce((s, x) => s + x.value, 0) || 1;
    const legW = data.reduce((m, x) => Math.max(m, approxW(x.label, 11.5) + approxW(`  ${x.value} · ${Math.round((x.value / total) * 100)}%`, 11.5)), 0) + 44;
    const cols = Math.max(1, Math.ceil(N / 16));
    return { W: Math.round(Math.max(600, 24 + 340 + 28 + legW * cols + 20)), H: Math.max(400, 60 + Math.min(N, 16) * 20 + 40) };
  }
  if (kind === 'bars') return { W: 640, H: 40 + N * 48 + 16 };
  if (kind === 'columns') return { W: Math.max(640, N * 42 + 60), H: 400 };
  return { W: Math.max(720, N * 24 + 120), H: 400 };
}
export function paintNeuExport(ctx: Ctx, W: number, H: number, kind: NeuKind, d: NeuDraw, title: string) {
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H);
  const top = title ? 40 : 14;
  if (title) { ctx.fillStyle = '#1c2620'; ctx.font = font(d.t, 700, 15, true); ctx.textAlign = 'left'; ctx.fillText(fitCtx(ctx, title, W - 32), 16, 26); }
  if (kind === 'donut' || kind === 'pie') {
    const total = d.data.reduce((s, x) => s + x.value, 0) || 1;
    const S = Math.min(H - top - 16, 340);
    const R = S / 2 - 22;
    const cx = 24 + S / 2, cy = top + (H - top) / 2;
    paintNeuCircular(ctx, kind === 'donut', cx, cy, R, d);
    // legend — right-aligned value column guarantees zero text overlap in SVG vector exports
    const maxLblW = d.data.reduce((m, x) => Math.max(m, approxW(x.label, 11.5)), 0);
    const legW = Math.max(220, maxLblW + 90);
    const x0 = 24 + S + 28;
    d.data.forEach((x, i) => {
      const colI = Math.floor(i / 16), row = i % 16;
      const lx = x0 + colI * legW, ly = top + 26 + row * 22;
      ctx.fillStyle = d.colors[i]; circle(ctx, lx + 4, ly - 4, 4.5); ctx.fill();
      ctx.font = font(d.t, 600, 11.5); ctx.fillStyle = '#1c2620'; ctx.textAlign = 'left';
      ctx.fillText(x.label, lx + 15, ly);
      ctx.fillStyle = '#6b746e'; ctx.textAlign = 'right';
      ctx.fillText(`${x.value} · ${Math.round((x.value / total) * 100)}%`, lx + legW - 10, ly);
      ctx.textAlign = 'left';
    });
  } else {
    ctx.save(); ctx.translate(0, top);
    const h = H - top;
    if (kind === 'bars') paintNeuBars(ctx, W, h, d);
    else if (kind === 'columns') paintNeuColumns(ctx, W, h, d);
    else paintNeuLine(ctx, kind === 'area', W, h, d);
    ctx.restore();
  }
  ctx.textAlign = 'left';
}

/* ---- live canvas for the neumorphic kinds (circular + line/area) ---- */
function NeuCanvas({ kind, data, colors, size, height, centerLabel, hover, onHover, full }: {
  kind: NeuKind; data: ChartDatum[]; colors: string[]; size: number; height: number; centerLabel: string;
  hover: number | null; onHover: (i: number | null) => void; full: boolean;
}) {
  const circular = kind === 'donut' || kind === 'pie';
  const S = size + 36;
  const ref = useRef<HTMLCanvasElement>(null);
  const progRef = useRef(0);
  const amtRef = useRef(0);
  const hovRef = useRef<number | null>(null);
  const rafRef = useRef(0);
  const hovRafRef = useRef(0);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);
  const themeTick = useThemeTick();
  const themeRef = useRef<Theme>(themeColors());
  useEffect(() => { themeRef.current = themeColors(); }, [themeTick]);
  const dataSig = useMemo(() => JSON.stringify(data.map((x) => [x.label, x.value])), [data]);

  const draw = useCallback(() => {
    const cv = ref.current;
    if (!cv) return;
    const W = circular ? S : cv.clientWidth, H = circular ? S : height;
    if (W <= 0 || H <= 0) { requestAnimationFrame(() => draw()); return; }
    const dpr = window.devicePixelRatio || 1;
    const bw = Math.round(W * dpr), bh = Math.round(H * dpr);
    if (cv.width !== bw || cv.height !== bh) { cv.width = bw; cv.height = bh; }
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const d: NeuDraw = { data, colors, t: themeRef.current, p: easeOut(progRef.current), hover: hovRef.current, amt: amtRef.current, centerLabel, full };
    if (circular) paintNeuCircular(ctx, kind === 'donut', W / 2, H / 2, size / 2 - 4, d);
    else paintNeuLine(ctx, kind === 'area', W, H, d);
  }, [circular, S, height, data, colors, centerLabel, full, kind, size]);

  /* entrance sweep / draw-in */
  useEffect(() => {
    cancelAnimationFrame(rafRef.current);
    progRef.current = 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      progRef.current = Math.min(1, (now - t0) / 900);
      draw();
      if (progRef.current < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, dataSig]);

  /* hover amount animation */
  useEffect(() => {
    const goal = hover !== null ? 1 : 0;
    if (hover !== null) {
      // moving straight from one slice to another re-plays part of the pop
      if (hovRef.current !== null && hovRef.current !== hover) amtRef.current = Math.min(amtRef.current, 0.35);
      hovRef.current = hover;
    }
    cancelAnimationFrame(hovRafRef.current);
    const tick = () => {
      const diff = goal - amtRef.current;
      if (Math.abs(diff) < 0.02) {
        amtRef.current = goal;
        if (goal === 0) hovRef.current = null;
        if (progRef.current >= 1) draw();
        return;
      }
      amtRef.current += diff * 0.22;
      if (progRef.current >= 1) draw();
      hovRafRef.current = requestAnimationFrame(tick);
    };
    hovRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(hovRafRef.current);
  }, [hover, draw]);

  useEffect(() => { if (progRef.current >= 1) draw(); }, [themeTick, draw]);
  useEffect(() => {
    const cv = ref.current;
    let ro: ResizeObserver | null = null;
    if (cv && typeof ResizeObserver !== 'undefined') { ro = new ResizeObserver(() => draw()); ro.observe(cv); }
    window.addEventListener('resize', draw);
    return () => { ro?.disconnect(); window.removeEventListener('resize', draw); };
  }, [draw]);

  const hit = (e: React.MouseEvent) => {
    const cv = ref.current;
    if (!cv || !data.length) return;
    const r = cv.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    let idx: number | null = null;
    if (circular) {
      const R = size / 2 - 4, rIn = kind === 'donut' ? R * 0.56 : 0;
      const ex = mx - S / 2, ey = my - S / 2;
      const rad = Math.hypot(ex, ey);
      if (rad <= R + 8 && rad >= Math.max(0, rIn - 6)) {
        const total = data.reduce((s, x) => s + x.value, 0) || 1;
        let ang = Math.atan2(ey, ex) + Math.PI / 2;
        ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        let acc = 0;
        for (let i = 0; i < data.length; i++) { acc += (data[i].value / total) * Math.PI * 2; if (ang <= acc) { idx = i; break; } }
      }
      onHover(idx);
      setTip(null);
    } else {
      const L = neuLineLayout(r.width, height, data, full);
      let best = Math.max(10, L.step / 2), bi: number | null = null;
      data.forEach((_, i) => { const dd = Math.abs(mx - L.xOf(i)); if (dd < best) { best = dd; bi = i; } });
      idx = bi;
      onHover(idx);
      if (idx !== null) {
        const px = L.xOf(idx), py = L.yOf(data[idx].value);
        setTip({ x: Math.max(4, Math.min(r.width - 150, px - 50)), y: Math.max(0, py - 40), text: `${data[idx].label}: ${data[idx].value}` });
      } else setTip(null);
    }
  };

  return (
    <div className="relative shrink-0" style={circular ? { width: S, height: S } : { width: '100%', height }}>
      <canvas ref={ref} style={{ width: '100%', height: '100%', display: 'block', cursor: 'pointer' }}
        onMouseMove={hit} onMouseLeave={() => { onHover(null); setTip(null); }} />
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 px-2.5 py-1 font-body text-[11px] font-bold text-ink" style={{ left: tip.x, top: tip.y }}>
          {tip.text}
        </div>
      )}
    </div>
  );
}

export function NeuChart({ data, title, defaultKind = 'donut', size = 158, centerLabel = 'total', legendSide = false, loading = false, isFullscreen = false }: {
  data: ChartDatum[]; title?: string; defaultKind?: NeuKind; size?: number; centerLabel?: string; legendSide?: boolean; loading?: boolean; isFullscreen?: boolean;
}) {
  const [kind, setKind] = useState<NeuKind>(defaultKind);
  const [hover, setHover] = useState<number | null>(null);
  const [full, setFull] = useState(false);
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const max = Math.max(...data.map((d) => d.value), 1);
  const themeTick = useThemeTick();
  const pal = useMemo(() => activePalette(), [themeTick]); // eslint-disable-line react-hooks/exhaustive-deps
  const colors = useMemo(() => data.map((d, i) => d.color || pal[i % pal.length]), [data, pal]);
  const dataSig = useMemo(() => JSON.stringify(data.map((x) => [x.label, x.value])), [data]);
  const circular = kind === 'donut' || kind === 'pie';

  const doExport = async (fmt: string) => {
    const base = (title || 'chart').toLowerCase().replace(/\s+/g, '-');
    if (fmt === 'csv') {
      downloadBlob(`${base}.csv`, new Blob(['label,value\n' + data.map((d) => `"${d.label}",${d.value}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'json') {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel') {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Data');
      const head = ws.addRow(['Label', 'Value']);
      head.eachCell((cell: { font: unknown; fill: unknown }) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
      });
      data.forEach((d) => ws.addRow([d.label, d.value]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }
    await fontsReady();
    const t = themeColors(true);
    const { W, H } = neuExportDims(kind, data);
    const d: NeuDraw = { data, colors, t, p: 1, hover: null, amt: 0, centerLabel, full: true };
    if (fmt === 'svg') {
      const rec = new SvgCtx(W, H);
      rec.fontCss = await fontFaceCss(fontFamilies(t), ['600', '700']);
      paintNeuExport(rec as unknown as Ctx, W, H, kind, d, title || 'Chart');
      downloadBlob(`${base}.svg`, new Blob([rec.toString()], { type: 'image/svg+xml' }));
      return;
    }
    const scale = 3;
    const cv = document.createElement('canvas');
    cv.width = W * scale; cv.height = H * scale;
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    paintNeuExport(ctx, W, H, kind, d, title || 'Chart');
    if (fmt === 'png') cv.toBlob((b) => b && downloadBlob(`${base}.png`, b), 'image/png');
    else if (fmt === 'pdf') {
      const dataUrl = cv.toDataURL('image/jpeg', 0.94);
      const bytes = Uint8Array.from(atob(dataUrl.split(',')[1]), (c) => c.charCodeAt(0));
      downloadBlob(`${base}.pdf`, jpegToPdf(bytes, cv.width, cv.height));
    } else if (fmt === 'print') printCanvas(title || 'Chart', cv);
  };

  /* ---- horizontal soft bars (DOM, CSS-grown on entrance) ---- */
  const bars = (
    <div key={`bars-${dataSig}`} className="w-full space-y-3">
      {data.map((d, i) => (
        <div key={d.label} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
          <div className="mb-1 flex justify-between font-body text-[11.5px]">
            <span className={`font-semibold ${hover === i ? 'text-ink' : 'text-ink/75'}`}>{d.label}</span>
            <span className="font-bold tabular-nums text-ink">{d.value}</span>
          </div>
          <div className="tk-inset h-4 overflow-hidden rounded-full">
            <div className="tk-grow-w h-full rounded-full transition-[filter] duration-300"
              style={{
                width: `${(d.value / max) * 100}%`, animationDelay: `${i * 70}ms`,
                background: `linear-gradient(145deg, ${shade(colors[i], 1.08)}, ${shade(colors[i], 0.8)})`,
                boxShadow: '1px 1px 3px rgba(0,0,0,0.25), inset 0 1px 1px rgba(255,255,255,0.4)',
                filter: hover === i ? 'brightness(1.12)' : hover !== null ? 'saturate(0.6) opacity(0.7)' : undefined,
              }} />
          </div>
        </div>
      ))}
    </div>
  );

  /* ---- vertical soft columns (DOM, CSS-grown on entrance, adaptive labels) ---- */
  const columns = (() => {
    const N = Math.max(1, data.length);
    const rotate = N > 6;
    return (
      <div key={`cols-${dataSig}`} className="w-full">
        <div className="flex w-full items-end justify-around gap-1.5" style={{ height: size + 24 }}>
          {data.map((d, i) => (
            <div key={d.label} className="flex min-w-0 flex-1 flex-col items-center gap-1.5"
              onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              <span className="font-body text-[10.5px] font-bold tabular-nums text-ink/70">{d.value}</span>
              <div className="tk-inset flex w-full max-w-[44px] items-end overflow-hidden rounded-xl" style={{ height: size - 10 }}>
                <div className="tk-grow-h w-full rounded-xl transition-[filter] duration-300"
                  style={{
                    height: `${(d.value / max) * 100}%`, animationDelay: `${i * 70}ms`,
                    background: `linear-gradient(145deg, ${shade(colors[i], 1.08)}, ${shade(colors[i], 0.8)})`,
                    boxShadow: 'inset 0 2px 2px rgba(255,255,255,0.35), 0 -1px 3px rgba(0,0,0,0.15)',
                    filter: hover === i ? 'brightness(1.12)' : hover !== null ? 'saturate(0.6) opacity(0.7)' : undefined,
                  }} />
              </div>
            </div>
          ))}
        </div>
        <div className="mt-1.5 flex w-full justify-around gap-1.5" style={{ height: rotate ? 52 : 16 }}>
          {data.map((d, i) => (
            <div key={d.label} className="flex min-w-0 flex-1 justify-center">
              <span data-tip={d.label} title={d.label}
                className={`font-body text-[9.5px] font-bold uppercase tracking-wide ${hover === i ? 'text-ink' : 'text-muted'} ${rotate ? 'origin-top-right whitespace-nowrap' : 'w-full truncate text-center'}`}
                style={rotate ? { maxWidth: 64, overflow: 'hidden', textOverflow: 'ellipsis', transform: 'translateX(-50%) rotate(-45deg)' } : undefined}>
                {rotate ? d.label : fitText(d.label, 52, 9.5)}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  })();

  const containerRef = useRef<HTMLDivElement>(null);
  const [isFs, setIsFs] = useState(false);

  useEffect(() => {
    const onFs = () => {
      const active = !!document.fullscreenElement && document.fullscreenElement === containerRef.current;
      setIsFs(active);
    };
    document.addEventListener('fullscreenchange', onFs);
    document.addEventListener('webkitfullscreenchange', onFs);
    return () => {
      document.removeEventListener('fullscreenchange', onFs);
      document.removeEventListener('webkitfullscreenchange', onFs);
    };
  }, []);

  /* Lock the page scroll while the CSS-fallback overlay is open. */
  useEffect(() => {
    if (!full) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, [full]);

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      try {
        if (containerRef.current?.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        } else if ((containerRef.current as unknown as { webkitRequestFullscreen?: () => Promise<void> })?.webkitRequestFullscreen) {
          await (containerRef.current as unknown as { webkitRequestFullscreen: () => Promise<void> }).webkitRequestFullscreen();
        }
        setIsFs(true);
      } catch {
        setFull(true);
      }
    } else {
      try {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as unknown as { webkitExitFullscreen?: () => Promise<void> })?.webkitExitFullscreen) {
          await (document as unknown as { webkitExitFullscreen: () => Promise<void> }).webkitExitFullscreen();
        }
      } catch { /* noop */ }
      setIsFs(false);
      setFull(false);
    }
  };

  const legendEl = (
    <div className={legendSide && circular ? 'min-w-0 flex-1 space-y-2' : 'mt-3 flex flex-wrap justify-center gap-x-4 gap-y-1.5'}>
      {data.map((d, i) => {
        const pct = Math.round((d.value / total) * 100);
        const on = hover === i;
        return (
          <button key={d.label} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}
            className={`flex items-center gap-2 font-body text-[11.5px] font-semibold transition ${on ? 'text-ink' : 'text-ink/75'} ${legendSide && circular ? 'w-full pr-1' : ''}`}>
            <span className="flex min-w-0 flex-1 items-center gap-2">
              <span className="h-2.5 w-2.5 shrink-0 rounded-full transition-shadow"
                style={{ background: colors[i], boxShadow: on ? `0 0 0 3px ${rgba(colors[i], 0.22)}` : '0.5px 0.5px 1.5px rgba(0,0,0,0.3)' }} />
              <span className="truncate">{d.label}</span>
              <span className="shrink-0 text-muted text-[10.5px]">({pct}%)</span>
            </span>
            {legendSide && circular && (
              <span className="ml-2 shrink-0 tabular-nums font-bold text-ink/80 text-[11px] px-2 py-0.5 rounded-md bg-black/5 dark:bg-white/10">{d.value}</span>
            )}
          </button>
        );
      })}
    </div>
  );

  const canvasEl = (
    <NeuCanvas kind={kind} data={data} colors={colors} size={isFs ? Math.min(380, window.innerHeight - 240) : size} height={isFs ? Math.min(420, window.innerHeight - 200) : size + 40} centerLabel={centerLabel}
      hover={hover} onHover={setHover} full={isFullscreen || isFs} />
  );

  const body = (
    <div ref={containerRef} className={`tk-card ${isFs ? '!fixed !inset-0 !z-[100] !w-screen !h-screen !m-0 !rounded-none !p-6 sm:!p-10 flex flex-col justify-between overflow-y-auto overflow-x-hidden bg-(--t-surface)' : 'p-4'}`}>
      {/* No toolbar z-index: MiniDrop menus are portalled to document.body. */}
      <div className="relative mb-3 flex flex-wrap items-center gap-2">
        {title && <p className={`mr-auto font-display font-semibold text-ink ${isFs ? 'text-xl' : 'text-[14px]'}`}>{title}</p>}
        <MiniDrop label={NEU_KINDS.find((k) => k.key === kind)!.label} activeKey={kind}
          items={NEU_KINDS.map((k) => ({ key: k.key, label: k.label }))}
          onPick={(k) => { setKind(k as NeuKind); setHover(null); }} />
        <MiniDrop label="Export" icon={<Download size={12} />}
          items={[
            { key: 'png', label: 'PNG image' },
            { key: 'svg', label: 'SVG vector' },
            { key: 'pdf', label: 'PDF document' },
            { key: 'excel', label: 'Excel workbook' },
            { key: 'print', label: 'Print…' },
            { key: 'csv', label: 'CSV data' },
            { key: 'json', label: 'JSON data' },
          ]}
          onPick={doExport} />
        {!isFullscreen && (
          <button onClick={toggleFullscreen} data-tip={isFs ? "Exit fullscreen" : "View fullscreen"} className="tk-btn-ghost rounded-xl p-2">
            {isFs ? <Minimize2 size={15} /> : <Eye size={14} />}
          </button>
        )}
      </div>

      {loading ? (
        <ChartSkeleton kind={circular ? 'circle' : kind === 'bars' ? 'bars' : kind === 'columns' ? 'columns' : 'line'} height={size + 40} legend={legendSide && circular} />
      ) : data.length === 0 ? (
        <div className="flex items-center justify-center font-body text-[12.5px] text-muted" style={{ minHeight: size + 40 }}>No data to chart.</div>
      ) : circular ? (
        legendSide
          ? <div className={`flex items-center gap-6 ${isFs ? 'max-w-4xl mx-auto w-full my-auto' : ''}`}>{canvasEl}{legendEl}</div>
          : <div className={`flex flex-col items-center ${isFs ? 'my-auto' : ''}`}>{canvasEl}{legendEl}</div>
      ) : kind === 'bars' ? bars
        : kind === 'columns' ? columns
        : canvasEl}
    </div>
  );

  return (
    <>
      {body}
      {full && createPortal(
        <div className="fixed inset-0 z-[100] flex flex-col bg-(--t-surface) p-6 sm:p-10 backdrop-blur-md overflow-y-auto overflow-x-hidden max-w-[100vw]"
          onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) setFull(false); }}>
          <div className="mb-3 flex justify-between items-center">
            {title && <h2 className="font-display text-xl font-bold text-ink">{title}</h2>}
            <button onClick={() => setFull(false)} className="tk-btn-ghost rounded-full p-2.5 ml-auto"><X size={18} /></button>
          </div>
          <div className="flex-1 w-full min-w-0 max-w-full flex items-center justify-center">
            <NeuChart data={data} title={title} defaultKind={kind}
              size={Math.max(240, Math.min(380, window.innerHeight - 300))} centerLabel={centerLabel} legendSide isFullscreen />
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

/* compat wrappers */
export function NeuDonut(props: { data: ChartDatum[]; title?: string; size?: number; centerLabel?: string; legendSide?: boolean; loading?: boolean }) {
  return <NeuChart {...props} defaultKind="donut" />;
}
export function NeuBars({ data, title, loading }: { data: ChartDatum[]; title?: string; loading?: boolean }) {
  return <NeuChart data={data} title={title} defaultKind="bars" loading={loading} />;
}


