(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/react/cjs/react.production.js
  var require_react_production = __commonJS({
    "node_modules/react/cjs/react.production.js"(exports) {
      "use strict";
      var REACT_ELEMENT_TYPE = /* @__PURE__ */ Symbol.for("react.transitional.element");
      var REACT_PORTAL_TYPE = /* @__PURE__ */ Symbol.for("react.portal");
      var REACT_FRAGMENT_TYPE = /* @__PURE__ */ Symbol.for("react.fragment");
      var REACT_STRICT_MODE_TYPE = /* @__PURE__ */ Symbol.for("react.strict_mode");
      var REACT_PROFILER_TYPE = /* @__PURE__ */ Symbol.for("react.profiler");
      var REACT_CONSUMER_TYPE = /* @__PURE__ */ Symbol.for("react.consumer");
      var REACT_CONTEXT_TYPE = /* @__PURE__ */ Symbol.for("react.context");
      var REACT_FORWARD_REF_TYPE = /* @__PURE__ */ Symbol.for("react.forward_ref");
      var REACT_SUSPENSE_TYPE = /* @__PURE__ */ Symbol.for("react.suspense");
      var REACT_MEMO_TYPE = /* @__PURE__ */ Symbol.for("react.memo");
      var REACT_LAZY_TYPE = /* @__PURE__ */ Symbol.for("react.lazy");
      var REACT_ACTIVITY_TYPE = /* @__PURE__ */ Symbol.for("react.activity");
      var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
      function getIteratorFn(maybeIterable) {
        if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
        maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
        return "function" === typeof maybeIterable ? maybeIterable : null;
      }
      var ReactNoopUpdateQueue = {
        isMounted: function() {
          return false;
        },
        enqueueForceUpdate: function() {
        },
        enqueueReplaceState: function() {
        },
        enqueueSetState: function() {
        }
      };
      var assign = Object.assign;
      var emptyObject = {};
      function Component(props, context, updater) {
        this.props = props;
        this.context = context;
        this.refs = emptyObject;
        this.updater = updater || ReactNoopUpdateQueue;
      }
      Component.prototype.isReactComponent = {};
      Component.prototype.setState = function(partialState, callback) {
        if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState)
          throw Error(
            "takes an object of state variables to update or a function which returns an object of state variables."
          );
        this.updater.enqueueSetState(this, partialState, callback, "setState");
      };
      Component.prototype.forceUpdate = function(callback) {
        this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
      };
      function ComponentDummy() {
      }
      ComponentDummy.prototype = Component.prototype;
      function PureComponent(props, context, updater) {
        this.props = props;
        this.context = context;
        this.refs = emptyObject;
        this.updater = updater || ReactNoopUpdateQueue;
      }
      var pureComponentPrototype = PureComponent.prototype = new ComponentDummy();
      pureComponentPrototype.constructor = PureComponent;
      assign(pureComponentPrototype, Component.prototype);
      pureComponentPrototype.isPureReactComponent = true;
      var isArrayImpl = Array.isArray;
      function noop() {
      }
      var ReactSharedInternals = { H: null, A: null, T: null, S: null };
      var hasOwnProperty = Object.prototype.hasOwnProperty;
      function ReactElement(type, key, props) {
        var refProp = props.ref;
        return {
          $$typeof: REACT_ELEMENT_TYPE,
          type,
          key,
          ref: void 0 !== refProp ? refProp : null,
          props
        };
      }
      function cloneAndReplaceKey(oldElement, newKey) {
        return ReactElement(oldElement.type, newKey, oldElement.props);
      }
      function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
      }
      function escape(key) {
        var escaperLookup = { "=": "=0", ":": "=2" };
        return "$" + key.replace(/[=:]/g, function(match) {
          return escaperLookup[match];
        });
      }
      var userProvidedKeyEscapeRegex = /\/+/g;
      function getElementKey(element, index) {
        return "object" === typeof element && null !== element && null != element.key ? escape("" + element.key) : index.toString(36);
      }
      function resolveThenable(thenable) {
        switch (thenable.status) {
          case "fulfilled":
            return thenable.value;
          case "rejected":
            throw thenable.reason;
          default:
            switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(
              function(fulfilledValue) {
                "pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
              },
              function(error) {
                "pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
              }
            )), thenable.status) {
              case "fulfilled":
                return thenable.value;
              case "rejected":
                throw thenable.reason;
            }
        }
        throw thenable;
      }
      function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
        var type = typeof children;
        if ("undefined" === type || "boolean" === type) children = null;
        var invokeCallback = false;
        if (null === children) invokeCallback = true;
        else
          switch (type) {
            case "bigint":
            case "string":
            case "number":
              invokeCallback = true;
              break;
            case "object":
              switch (children.$$typeof) {
                case REACT_ELEMENT_TYPE:
                case REACT_PORTAL_TYPE:
                  invokeCallback = true;
                  break;
                case REACT_LAZY_TYPE:
                  return invokeCallback = children._init, mapIntoArray(
                    invokeCallback(children._payload),
                    array,
                    escapedPrefix,
                    nameSoFar,
                    callback
                  );
              }
          }
        if (invokeCallback)
          return callback = callback(children), invokeCallback = "" === nameSoFar ? "." + getElementKey(children, 0) : nameSoFar, isArrayImpl(callback) ? (escapedPrefix = "", null != invokeCallback && (escapedPrefix = invokeCallback.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function(c) {
            return c;
          })) : null != callback && (isValidElement(callback) && (callback = cloneAndReplaceKey(
            callback,
            escapedPrefix + (null == callback.key || children && children.key === callback.key ? "" : ("" + callback.key).replace(
              userProvidedKeyEscapeRegex,
              "$&/"
            ) + "/") + invokeCallback
          )), array.push(callback)), 1;
        invokeCallback = 0;
        var nextNamePrefix = "" === nameSoFar ? "." : nameSoFar + ":";
        if (isArrayImpl(children))
          for (var i = 0; i < children.length; i++)
            nameSoFar = children[i], type = nextNamePrefix + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(
              nameSoFar,
              array,
              escapedPrefix,
              type,
              callback
            );
        else if (i = getIteratorFn(children), "function" === typeof i)
          for (children = i.call(children), i = 0; !(nameSoFar = children.next()).done; )
            nameSoFar = nameSoFar.value, type = nextNamePrefix + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(
              nameSoFar,
              array,
              escapedPrefix,
              type,
              callback
            );
        else if ("object" === type) {
          if ("function" === typeof children.then)
            return mapIntoArray(
              resolveThenable(children),
              array,
              escapedPrefix,
              nameSoFar,
              callback
            );
          array = String(children);
          throw Error(
            "Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead."
          );
        }
        return invokeCallback;
      }
      function mapChildren(children, func, context) {
        if (null == children) return children;
        var result = [], count = 0;
        mapIntoArray(children, result, "", "", function(child) {
          return func.call(context, child, count++);
        });
        return result;
      }
      function lazyInitializer(payload) {
        if (-1 === payload._status) {
          var ctor = payload._result;
          ctor = ctor();
          ctor.then(
            function(moduleObject) {
              if (0 === payload._status || -1 === payload._status)
                payload._status = 1, payload._result = moduleObject;
            },
            function(error) {
              if (0 === payload._status || -1 === payload._status)
                payload._status = 2, payload._result = error;
            }
          );
          -1 === payload._status && (payload._status = 0, payload._result = ctor);
        }
        if (1 === payload._status) return payload._result.default;
        throw payload._result;
      }
      var reportGlobalError = "function" === typeof reportError ? reportError : function(error) {
        if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
          var event = new window.ErrorEvent("error", {
            bubbles: true,
            cancelable: true,
            message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
            error
          });
          if (!window.dispatchEvent(event)) return;
        } else if ("object" === typeof process && "function" === typeof process.emit) {
          process.emit("uncaughtException", error);
          return;
        }
        console.error(error);
      };
      var Children = {
        map: mapChildren,
        forEach: function(children, forEachFunc, forEachContext) {
          mapChildren(
            children,
            function() {
              forEachFunc.apply(this, arguments);
            },
            forEachContext
          );
        },
        count: function(children) {
          var n = 0;
          mapChildren(children, function() {
            n++;
          });
          return n;
        },
        toArray: function(children) {
          return mapChildren(children, function(child) {
            return child;
          }) || [];
        },
        only: function(children) {
          if (!isValidElement(children))
            throw Error(
              "React.Children.only expected to receive a single React element child."
            );
          return children;
        }
      };
      exports.Activity = REACT_ACTIVITY_TYPE;
      exports.Children = Children;
      exports.Component = Component;
      exports.Fragment = REACT_FRAGMENT_TYPE;
      exports.Profiler = REACT_PROFILER_TYPE;
      exports.PureComponent = PureComponent;
      exports.StrictMode = REACT_STRICT_MODE_TYPE;
      exports.Suspense = REACT_SUSPENSE_TYPE;
      exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
      exports.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function(size) {
          return ReactSharedInternals.H.useMemoCache(size);
        }
      };
      exports.cache = function(fn) {
        return function() {
          return fn.apply(null, arguments);
        };
      };
      exports.cacheSignal = function() {
        return null;
      };
      exports.cloneElement = function(element, config, children) {
        if (null === element || void 0 === element)
          throw Error(
            "The argument must be a React element, but you passed " + element + "."
          );
        var props = assign({}, element.props), key = element.key;
        if (null != config)
          for (propName in void 0 !== config.key && (key = "" + config.key), config)
            !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
        var propName = arguments.length - 2;
        if (1 === propName) props.children = children;
        else if (1 < propName) {
          for (var childArray = Array(propName), i = 0; i < propName; i++)
            childArray[i] = arguments[i + 2];
          props.children = childArray;
        }
        return ReactElement(element.type, key, props);
      };
      exports.createContext = function(defaultValue) {
        defaultValue = {
          $$typeof: REACT_CONTEXT_TYPE,
          _currentValue: defaultValue,
          _currentValue2: defaultValue,
          _threadCount: 0,
          Provider: null,
          Consumer: null
        };
        defaultValue.Provider = defaultValue;
        defaultValue.Consumer = {
          $$typeof: REACT_CONSUMER_TYPE,
          _context: defaultValue
        };
        return defaultValue;
      };
      exports.createElement = function(type, config, children) {
        var propName, props = {}, key = null;
        if (null != config)
          for (propName in void 0 !== config.key && (key = "" + config.key), config)
            hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (props[propName] = config[propName]);
        var childrenLength = arguments.length - 2;
        if (1 === childrenLength) props.children = children;
        else if (1 < childrenLength) {
          for (var childArray = Array(childrenLength), i = 0; i < childrenLength; i++)
            childArray[i] = arguments[i + 2];
          props.children = childArray;
        }
        if (type && type.defaultProps)
          for (propName in childrenLength = type.defaultProps, childrenLength)
            void 0 === props[propName] && (props[propName] = childrenLength[propName]);
        return ReactElement(type, key, props);
      };
      exports.createRef = function() {
        return { current: null };
      };
      exports.forwardRef = function(render) {
        return { $$typeof: REACT_FORWARD_REF_TYPE, render };
      };
      exports.isValidElement = isValidElement;
      exports.lazy = function(ctor) {
        return {
          $$typeof: REACT_LAZY_TYPE,
          _payload: { _status: -1, _result: ctor },
          _init: lazyInitializer
        };
      };
      exports.memo = function(type, compare) {
        return {
          $$typeof: REACT_MEMO_TYPE,
          type,
          compare: void 0 === compare ? null : compare
        };
      };
      exports.startTransition = function(scope) {
        var prevTransition = ReactSharedInternals.T, currentTransition = {};
        ReactSharedInternals.T = currentTransition;
        try {
          var returnValue = scope(), onStartTransitionFinish = ReactSharedInternals.S;
          null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
          "object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && returnValue.then(noop, reportGlobalError);
        } catch (error) {
          reportGlobalError(error);
        } finally {
          null !== prevTransition && null !== currentTransition.types && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
        }
      };
      exports.unstable_useCacheRefresh = function() {
        return ReactSharedInternals.H.useCacheRefresh();
      };
      exports.use = function(usable) {
        return ReactSharedInternals.H.use(usable);
      };
      exports.useActionState = function(action, initialState, permalink) {
        return ReactSharedInternals.H.useActionState(action, initialState, permalink);
      };
      exports.useCallback = function(callback, deps) {
        return ReactSharedInternals.H.useCallback(callback, deps);
      };
      exports.useContext = function(Context) {
        return ReactSharedInternals.H.useContext(Context);
      };
      exports.useDebugValue = function() {
      };
      exports.useDeferredValue = function(value, initialValue) {
        return ReactSharedInternals.H.useDeferredValue(value, initialValue);
      };
      exports.useEffect = function(create, deps) {
        return ReactSharedInternals.H.useEffect(create, deps);
      };
      exports.useEffectEvent = function(callback) {
        return ReactSharedInternals.H.useEffectEvent(callback);
      };
      exports.useId = function() {
        return ReactSharedInternals.H.useId();
      };
      exports.useImperativeHandle = function(ref, create, deps) {
        return ReactSharedInternals.H.useImperativeHandle(ref, create, deps);
      };
      exports.useInsertionEffect = function(create, deps) {
        return ReactSharedInternals.H.useInsertionEffect(create, deps);
      };
      exports.useLayoutEffect = function(create, deps) {
        return ReactSharedInternals.H.useLayoutEffect(create, deps);
      };
      exports.useMemo = function(create, deps) {
        return ReactSharedInternals.H.useMemo(create, deps);
      };
      exports.useOptimistic = function(passthrough, reducer) {
        return ReactSharedInternals.H.useOptimistic(passthrough, reducer);
      };
      exports.useReducer = function(reducer, initialArg, init) {
        return ReactSharedInternals.H.useReducer(reducer, initialArg, init);
      };
      exports.useRef = function(initialValue) {
        return ReactSharedInternals.H.useRef(initialValue);
      };
      exports.useState = function(initialState) {
        return ReactSharedInternals.H.useState(initialState);
      };
      exports.useSyncExternalStore = function(subscribe, getSnapshot, getServerSnapshot) {
        return ReactSharedInternals.H.useSyncExternalStore(
          subscribe,
          getSnapshot,
          getServerSnapshot
        );
      };
      exports.useTransition = function() {
        return ReactSharedInternals.H.useTransition();
      };
      exports.version = "19.2.8";
    }
  });

  // node_modules/react/index.js
  var require_react = __commonJS({
    "node_modules/react/index.js"(exports, module) {
      "use strict";
      if (true) {
        module.exports = require_react_production();
      } else {
        module.exports = null;
      }
    }
  });

  // node_modules/react-dom/cjs/react-dom.production.js
  var require_react_dom_production = __commonJS({
    "node_modules/react-dom/cjs/react-dom.production.js"(exports) {
      "use strict";
      var React2 = require_react();
      function formatProdErrorMessage(code) {
        var url = "https://react.dev/errors/" + code;
        if (1 < arguments.length) {
          url += "?args[]=" + encodeURIComponent(arguments[1]);
          for (var i = 2; i < arguments.length; i++)
            url += "&args[]=" + encodeURIComponent(arguments[i]);
        }
        return "Minified React error #" + code + "; visit " + url + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
      }
      function noop() {
      }
      var Internals = {
        d: {
          f: noop,
          r: function() {
            throw Error(formatProdErrorMessage(522));
          },
          D: noop,
          C: noop,
          L: noop,
          m: noop,
          X: noop,
          S: noop,
          M: noop
        },
        p: 0,
        findDOMNode: null
      };
      var REACT_PORTAL_TYPE = /* @__PURE__ */ Symbol.for("react.portal");
      function createPortal$1(children, containerInfo, implementation) {
        var key = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
        return {
          $$typeof: REACT_PORTAL_TYPE,
          key: null == key ? null : "" + key,
          children,
          containerInfo,
          implementation
        };
      }
      var ReactSharedInternals = React2.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
      function getCrossOriginStringAs(as, input) {
        if ("font" === as) return "";
        if ("string" === typeof input)
          return "use-credentials" === input ? input : "";
      }
      exports.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = Internals;
      exports.createPortal = function(children, container) {
        var key = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
        if (!container || 1 !== container.nodeType && 9 !== container.nodeType && 11 !== container.nodeType)
          throw Error(formatProdErrorMessage(299));
        return createPortal$1(children, container, null, key);
      };
      exports.flushSync = function(fn) {
        var previousTransition = ReactSharedInternals.T, previousUpdatePriority = Internals.p;
        try {
          if (ReactSharedInternals.T = null, Internals.p = 2, fn) return fn();
        } finally {
          ReactSharedInternals.T = previousTransition, Internals.p = previousUpdatePriority, Internals.d.f();
        }
      };
      exports.preconnect = function(href, options) {
        "string" === typeof href && (options ? (options = options.crossOrigin, options = "string" === typeof options ? "use-credentials" === options ? options : "" : void 0) : options = null, Internals.d.C(href, options));
      };
      exports.prefetchDNS = function(href) {
        "string" === typeof href && Internals.d.D(href);
      };
      exports.preinit = function(href, options) {
        if ("string" === typeof href && options && "string" === typeof options.as) {
          var as = options.as, crossOrigin = getCrossOriginStringAs(as, options.crossOrigin), integrity = "string" === typeof options.integrity ? options.integrity : void 0, fetchPriority = "string" === typeof options.fetchPriority ? options.fetchPriority : void 0;
          "style" === as ? Internals.d.S(
            href,
            "string" === typeof options.precedence ? options.precedence : void 0,
            {
              crossOrigin,
              integrity,
              fetchPriority
            }
          ) : "script" === as && Internals.d.X(href, {
            crossOrigin,
            integrity,
            fetchPriority,
            nonce: "string" === typeof options.nonce ? options.nonce : void 0
          });
        }
      };
      exports.preinitModule = function(href, options) {
        if ("string" === typeof href)
          if ("object" === typeof options && null !== options) {
            if (null == options.as || "script" === options.as) {
              var crossOrigin = getCrossOriginStringAs(
                options.as,
                options.crossOrigin
              );
              Internals.d.M(href, {
                crossOrigin,
                integrity: "string" === typeof options.integrity ? options.integrity : void 0,
                nonce: "string" === typeof options.nonce ? options.nonce : void 0
              });
            }
          } else null == options && Internals.d.M(href);
      };
      exports.preload = function(href, options) {
        if ("string" === typeof href && "object" === typeof options && null !== options && "string" === typeof options.as) {
          var as = options.as, crossOrigin = getCrossOriginStringAs(as, options.crossOrigin);
          Internals.d.L(href, as, {
            crossOrigin,
            integrity: "string" === typeof options.integrity ? options.integrity : void 0,
            nonce: "string" === typeof options.nonce ? options.nonce : void 0,
            type: "string" === typeof options.type ? options.type : void 0,
            fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0,
            referrerPolicy: "string" === typeof options.referrerPolicy ? options.referrerPolicy : void 0,
            imageSrcSet: "string" === typeof options.imageSrcSet ? options.imageSrcSet : void 0,
            imageSizes: "string" === typeof options.imageSizes ? options.imageSizes : void 0,
            media: "string" === typeof options.media ? options.media : void 0
          });
        }
      };
      exports.preloadModule = function(href, options) {
        if ("string" === typeof href)
          if (options) {
            var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
            Internals.d.m(href, {
              as: "string" === typeof options.as && "script" !== options.as ? options.as : void 0,
              crossOrigin,
              integrity: "string" === typeof options.integrity ? options.integrity : void 0
            });
          } else Internals.d.m(href);
      };
      exports.requestFormReset = function(form) {
        Internals.d.r(form);
      };
      exports.unstable_batchedUpdates = function(fn, a) {
        return fn(a);
      };
      exports.useFormState = function(action, initialState, permalink) {
        return ReactSharedInternals.H.useFormState(action, initialState, permalink);
      };
      exports.useFormStatus = function() {
        return ReactSharedInternals.H.useHostTransitionStatus();
      };
      exports.version = "19.2.8";
    }
  });

  // node_modules/react-dom/index.js
  var require_react_dom = __commonJS({
    "node_modules/react-dom/index.js"(exports, module) {
      "use strict";
      function checkDCE() {
        if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
          return;
        }
        if (false) {
          throw new Error("^_^");
        }
        try {
          __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
        } catch (err) {
          console.error(err);
        }
      }
      if (true) {
        checkDCE();
        module.exports = require_react_dom_production();
      } else {
        module.exports = null;
      }
    }
  });

  // src/shared/Charts.tsx
  var import_react2 = __toESM(require_react(), 1);
  var import_react_dom2 = __toESM(require_react_dom(), 1);

  // src/shared/primitives.tsx
  var import_react = __toESM(require_react(), 1);
  var import_react_dom = __toESM(require_react_dom(), 1);

  // test:fonts
  var FONT_LIBRARY = [];

  // src/theme/themes.ts
  var HONEST_PALETTE = ["#e4572e", "#f3a712", "#2e933c", "#669bbc", "#29335c", "#17bebb", "#f7b2ad", "#ffc857", "#a8c686", "#1e5aa8"];
  var GOOGLE_FONTS = FONT_LIBRARY.map(({ name, cat }) => ({ name, cat }));

  // src/shared/chartGeometry.ts
  function radialOffset(angle, distance, verticalScale = 1) {
    return { x: Math.cos(angle) * distance, y: Math.sin(angle) * distance * verticalScale };
  }
  var PREMIUM_LINE_PALETTE = [
    "#0f172a",
    // slate ink
    "#1e293b",
    // deeper slate
    "#334155",
    // slate
    "#475569",
    // blue slate
    "#0e7490",
    // deep teal
    "#155e75",
    // dark cyan
    "#7c2d12",
    // burnt sienna
    "#9a3412",
    // warm copper
    "#1e3a8a",
    // deep indigo
    "#312e81",
    // royal indigo
    "#4c1d95",
    // deep purple
    "#5b21b6",
    // regal purple
    "#831843",
    // mulberry
    "#9d174d",
    // deep magenta
    "#365314",
    // forest
    "#14532d",
    // pine
    "#3f3f46",
    // graphite
    "#1c1917",
    // onyx
    "#7f1d1d",
    // oxblood
    "#854d0e"
    // antique gold
  ];
  function distinctLineColor(barColors, preferred, palette) {
    const normalize = (color) => color.trim().toLowerCase();
    const browserColor = (color) => {
      if (typeof document === "undefined") return color;
      const ctx = document.createElement("canvas").getContext("2d");
      if (!ctx) return color;
      ctx.fillStyle = color;
      return String(ctx.fillStyle);
    };
    const channels = (color) => {
      color = browserColor(color);
      const hex = normalize(color).replace("#", "");
      if (/^[0-9a-f]{3}$/.test(hex)) return hex.split("").map((c) => parseInt(c + c, 16));
      if (/^[0-9a-f]{6}$/.test(hex)) return [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
      const rgb = color.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/);
      return rgb ? rgb.slice(1, 4).map(Number) : null;
    };
    const distance = (a, b) => {
      const aa = channels(a), bb = channels(b);
      if (!aa || !bb) return normalize(a) === normalize(b) ? 0 : 100;
      return Math.sqrt(aa.reduce((sum, value, i) => sum + (value - bb[i]) ** 2, 0));
    };
    const score = (color) => Math.min(...barColors.map((bar) => distance(color, bar)), Infinity);
    if (score(preferred) > 100) return preferred;
    const candidates = [...PREMIUM_LINE_PALETTE, ...palette];
    if (candidates.every((color) => score(color) === 0)) {
      for (let i = 0; i <= barColors.length; i++) candidates.push("#" + (i * 104729 % 16777215).toString(16).padStart(6, "0"));
    }
    return candidates.reduce((best, candidate) => score(candidate) > score(best) ? candidate : best, preferred);
  }

  // src/shared/Charts.tsx
  var PALETTE = ["#0d7a54", "#c9932b", "#0ea5e9", "#e11d63", "#f97316", "#14b8a6", "#1e5aa8", "#84cc16", "#f43f5e", "#a16207", "#06b6d4", "#64748b"];
  function activePalette() {
    try {
      return document.documentElement.getAttribute("data-theme") === "honest" ? HONEST_PALETTE : PALETTE;
    } catch {
      return PALETTE;
    }
  }
  var TILT = 0.32;
  var K = Math.sin(TILT);
  var lerp = (a, b, t) => a + (b - a) * t;
  var clamp01 = (v) => Math.max(0, Math.min(1, v));
  var SIN45 = Math.SQRT1_2;
  function parseColor(c) {
    const s = (c || "").trim();
    let m = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(s);
    if (m) return [parseInt(m[1] + m[1], 16), parseInt(m[2] + m[2], 16), parseInt(m[3] + m[3], 16), 1];
    m = /^#([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(s);
    if (m) {
      const n = parseInt(m[1], 16);
      return [n >> 16 & 255, n >> 8 & 255, n & 255, m[2] ? parseInt(m[2], 16) / 255 : 1];
    }
    m = /^rgba?\(([^)]+)\)$/i.exec(s);
    if (m) {
      const parts = m[1].split(/[\s,/]+/).filter(Boolean).map(parseFloat);
      if (parts.length >= 3) return [parts[0], parts[1], parts[2], parts.length > 3 ? parts[3] : 1];
    }
    return null;
  }
  var shadeCache = /* @__PURE__ */ new Map();
  var shade = (col, f) => {
    const key = col + "|" + f.toFixed(3);
    const hit = shadeCache.get(key);
    if (hit) return hit;
    const p = parseColor(col) || [136, 136, 136, 1];
    const c = (v) => Math.min(255, Math.max(0, Math.round(v * f)));
    const out = `rgb(${c(p[0])},${c(p[1])},${c(p[2])})`;
    if (shadeCache.size > 4e3) shadeCache.clear();
    shadeCache.set(key, out);
    return out;
  };
  var rgba = (col, a) => {
    const p = parseColor(col);
    return p ? `rgba(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])},${a})` : col;
  };
  var withAlpha = (hex, a) => /^#[0-9a-f]{6}$/i.test(hex) ? hex + a : rgba(hex, parseInt(a, 16) / 255);
  var luma = (col) => {
    const p = parseColor(col);
    return p ? (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) / 255 : 0.5;
  };
  var DEF_BODY = '"Outfit", ui-sans-serif, system-ui, sans-serif';
  var DEF_DISPLAY = '"Fraunces", Georgia, serif';
  function cssVar(name, fallback) {
    try {
      return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
    } catch {
      return fallback;
    }
  }
  function themeColors(forExport = false) {
    const fontBody = cssVar("--t-font-body", DEF_BODY);
    const fontDisplay = cssVar("--t-font-display", DEF_DISPLAY);
    if (forExport) return { ink: "#1c2620", axis: "#39443d", grid: "rgba(60,70,64,0.18)", surface: "#eef0ec", fontBody, fontDisplay, dark: false };
    const ink = cssVar("--t-ink", "#101914");
    const surface = cssVar("--t-surface", "#e4e7e0");
    return { ink, axis: ink, grid: "rgba(128,128,128,0.18)", surface, fontBody, fontDisplay, dark: luma(ink) > 0.5 };
  }
  var font = (t, weight, size, display = false) => `${weight} ${size}px ${display ? t?.fontDisplay || DEF_DISPLAY : t?.fontBody || DEF_BODY}`;
  function fontFamilies(t) {
    const out = /* @__PURE__ */ new Set();
    try {
      const raw = typeof localStorage !== "undefined" ? localStorage.getItem("aviary-prefs-v2") : null;
      if (raw) {
        const p = JSON.parse(raw);
        if (p.fontBody) out.add(p.fontBody.trim());
        if (p.fontDisplay) out.add(p.fontDisplay.trim());
      }
    } catch {
    }
    [t.fontBody || DEF_BODY, t.fontDisplay || DEF_DISPLAY].forEach((stack) => {
      stack.split(",").forEach((part) => {
        const first = part.trim().replace(/^["']|["']$/g, "");
        if (first && !/^(serif|sans-serif|system-ui|ui-sans-serif|ui-serif|monospace|Georgia|Arial|Helvetica)$/i.test(first)) out.add(first);
      });
    });
    return [...out];
  }
  var approxW = (s, fs = 10.5) => s.length * fs * 0.58;
  var fmtNum = (n) => Math.abs(n) >= 1e6 ? `${(n / 1e6).toFixed(1).replace(/\.0$/, "")}M` : Math.abs(n) >= 1e3 ? `${(n / 1e3).toFixed(1).replace(/\.0$/, "")}k` : String(Math.round(n));
  var measureW = (ctx, s) => {
    try {
      const w = ctx.measureText(s).width;
      return w > 0 && isFinite(w) ? w : approxW(s);
    } catch {
      return approxW(s);
    }
  };
  function fitCtx(ctx, s, maxW) {
    if (maxW === Infinity || measureW(ctx, s) <= maxW) return s;
    let lo = 0, hi = s.length;
    while (lo < hi) {
      const mid = lo + hi + 1 >> 1;
      if (measureW(ctx, s.slice(0, mid) + "\u2026") <= maxW) lo = mid;
      else hi = mid - 1;
    }
    let cut = s.slice(0, Math.max(1, lo));
    const sp = cut.lastIndexOf(" ");
    if (sp > cut.length * 0.5) cut = cut.slice(0, sp);
    return cut.trimEnd() + "\u2026";
  }
  var r2 = (n) => Math.round(n * 100) / 100;
  function splitColor(c) {
    const p = parseColor(c);
    if (!p) return { color: c || "#000", opacity: 1 };
    return { color: `rgb(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])})`, opacity: p[3] };
  }
  var SvgCtx = class {
    constructor(W, H) {
      this.W = W;
      this.H = H;
      this.meas = document.createElement("canvas").getContext("2d");
    }
    W;
    H;
    els = [];
    defs = [];
    /** embedded @font-face rules (base64 woff2) — fonts travel with the file, no CDN */
    fontCss = "";
    fillStyle = "#000";
    strokeStyle = "#000";
    lineWidth = 1;
    lineJoin = "miter";
    lineCap = "butt";
    font = "10px sans-serif";
    textAlign = "left";
    globalAlpha = 1;
    shadowBlur = 0;
    shadowOffsetX = 0;
    shadowOffsetY = 0;
    shadowColor = "rgba(0,0,0,0)";
    d = "";
    tx = 0;
    ty = 0;
    rot = 0;
    stack = [];
    gradN = 0;
    filters = /* @__PURE__ */ new Map();
    meas;
    /* transforms / state */
    setTransform() {
    }
    clearRect() {
    }
    save() {
      this.stack.push({ tx: this.tx, ty: this.ty, rot: this.rot, alpha: this.globalAlpha, sb: this.shadowBlur, sx: this.shadowOffsetX, sy: this.shadowOffsetY, sc: this.shadowColor });
    }
    restore() {
      const s = this.stack.pop();
      if (s) {
        this.tx = s.tx;
        this.ty = s.ty;
        this.rot = s.rot;
        this.globalAlpha = s.alpha;
        this.shadowBlur = s.sb;
        this.shadowOffsetX = s.sx;
        this.shadowOffsetY = s.sy;
        this.shadowColor = s.sc;
      }
    }
    translate(x, y) {
      this.tx += x;
      this.ty += y;
    }
    rotate(a) {
      this.rot += a;
    }
    scale() {
    }
    clip() {
    }
    setLineDash() {
    }
    rect(x, y, w, h) {
      this.d += `M ${this.px(x, y)} h ${r2(w)} v ${r2(h)} h ${r2(-w)} Z `;
    }
    /* path building */
    px(x, y) {
      return `${r2(x + this.tx)} ${r2(y + this.ty)}`;
    }
    beginPath() {
      this.d = "";
    }
    moveTo(x, y) {
      this.d += `M ${this.px(x, y)} `;
    }
    lineTo(x, y) {
      this.d += `L ${this.px(x, y)} `;
    }
    closePath() {
      this.d += "Z ";
    }
    bezierCurveTo(c1x, c1y, c2x, c2y, x, y) {
      this.d += `C ${this.px(c1x, c1y)} ${this.px(c2x, c2y)} ${this.px(x, y)} `;
    }
    quadraticCurveTo(cx, cy, x, y) {
      this.d += `Q ${this.px(cx, cy)} ${this.px(x, y)} `;
    }
    arc(x, y, r, a0, a1, ccw = false) {
      this.ellipse(x, y, r, r, 0, a0, a1, ccw);
    }
    ellipse(x, y, rx, ry, _rot, a0, a1, ccw = false) {
      rx = Math.max(0.01, rx);
      ry = Math.max(0.01, ry);
      let d = a1 - a0;
      if (ccw && d > 0) d -= Math.PI * 2;
      if (!ccw && d < 0) d += Math.PI * 2;
      const full = Math.abs(d) >= Math.PI * 2 - 1e-4;
      const seg = full ? d > 0 ? Math.PI : -Math.PI : d;
      const steps = full ? 2 : 1;
      const sx = x + Math.cos(a0) * rx, sy = y + Math.sin(a0) * ry;
      if (this.d === "" || this.d.endsWith("Z ")) this.d += `M ${this.px(sx, sy)} `;
      else this.d += `L ${this.px(sx, sy)} `;
      let cur = a0;
      for (let i = 0; i < steps; i++) {
        const next = full ? cur + seg : a0 + d;
        const ex = x + Math.cos(next) * rx, ey = y + Math.sin(next) * ry;
        const large = Math.abs(next - cur) > Math.PI ? 1 : 0;
        const sweep = next > cur ? 1 : 0;
        this.d += `A ${r2(rx)} ${r2(ry)} 0 ${large} ${sweep} ${this.px(ex, ey)} `;
        cur = next;
      }
    }
    roundRect(x, y, w, h, r) {
      const lim = Math.min(w, h) / 2;
      const rr = (Array.isArray(r) ? r : [r, r, r, r]).map((v) => Math.min(lim, Math.max(0, v)));
      const [tl, tr, br, bl] = [rr[0] ?? 0, rr[1] ?? rr[0] ?? 0, rr[2] ?? rr[0] ?? 0, rr[3] ?? rr[1] ?? rr[0] ?? 0];
      this.d += `M ${this.px(x + tl, y)} H ${r2(x + w - tr + this.tx)} `;
      if (tr) this.d += `A ${r2(tr)} ${r2(tr)} 0 0 1 ${this.px(x + w, y + tr)} `;
      this.d += `V ${r2(y + h - br + this.ty)} `;
      if (br) this.d += `A ${r2(br)} ${r2(br)} 0 0 1 ${this.px(x + w - br, y + h)} `;
      this.d += `H ${r2(x + bl + this.tx)} `;
      if (bl) this.d += `A ${r2(bl)} ${r2(bl)} 0 0 1 ${this.px(x, y + h - bl)} `;
      this.d += `V ${r2(y + tl + this.ty)} `;
      if (tl) this.d += `A ${r2(tl)} ${r2(tl)} 0 0 1 ${this.px(x + tl, y)} `;
      this.d += "Z ";
    }
    /* paint */
    resolve(style) {
      return typeof style === "string" ? style : `url(#${style.__grad})`;
    }
    fx() {
      let attr = this.globalAlpha < 1 ? ` opacity="${r2(this.globalAlpha)}"` : "";
      if (this.shadowBlur > 0 || this.shadowOffsetX || this.shadowOffsetY) {
        const { color, opacity } = splitColor(this.shadowColor);
        if (opacity > 0) {
          const key = `${r2(this.shadowOffsetX)}|${r2(this.shadowOffsetY)}|${r2(this.shadowBlur)}|${color}|${r2(opacity)}`;
          let id = this.filters.get(key);
          if (!id) {
            id = `sh${this.filters.size + 1}`;
            this.filters.set(key, id);
            this.defs.push(`<filter id="${id}" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur in="SourceAlpha" stdDeviation="${r2(this.shadowBlur / 2)}"/><feOffset dx="${r2(this.shadowOffsetX)}" dy="${r2(this.shadowOffsetY)}" result="ob"/><feFlood flood-color="${color}" flood-opacity="${r2(opacity)}"/><feComposite in2="ob" operator="in" result="sh"/><feMerge><feMergeNode in="sh"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`);
          }
          attr += ` filter="url(#${id})"`;
        }
      }
      return attr;
    }
    fill() {
      if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`);
    }
    stroke() {
      if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="none" stroke="${this.resolve(this.strokeStyle)}" stroke-width="${r2(this.lineWidth)}" stroke-linejoin="${this.lineJoin === "round" ? "round" : "miter"}" stroke-linecap="${this.lineCap === "round" ? "round" : "butt"}"${this.fx()}/>`);
    }
    fillRect(x, y, w, h) {
      this.els.push(`<rect x="${r2(x + this.tx)}" y="${r2(y + this.ty)}" width="${r2(w)}" height="${r2(h)}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`);
    }
    fillText(text, x, y) {
      const fm = /(\d+(?:\.\d+)?)px\s+(.+)$/.exec(this.font);
      const size = fm ? +fm[1] : 10;
      const fam = fm ? fm[2] : "sans-serif";
      const wm = /^(\d{3}|bold)\s/.exec(this.font);
      const weight = wm ? wm[1] === "bold" ? "700" : wm[1] : "400";
      const anchor = this.textAlign === "center" ? "middle" : this.textAlign === "right" || this.textAlign === "end" ? "end" : "start";
      const esc = text.replace(/&/g, "&amp;").replace(/</g, "&lt;");
      const gx = r2(x + this.tx), gy = r2(y + this.ty);
      const tf = this.rot !== 0 ? ` transform="rotate(${r2(this.rot * 180 / Math.PI)} ${gx} ${gy})"` : "";
      this.els.push(`<text x="${gx}" y="${gy}" font-family="${fam.replace(/"/g, "'")}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}" fill="${this.resolve(this.fillStyle)}"${tf}${this.fx()}>${esc}</text>`);
    }
    measureText(t) {
      this.meas.font = this.font;
      return this.meas.measureText(t);
    }
    createLinearGradient(x0, y0, x1, y1) {
      const id = `g${++this.gradN}`;
      const stops = [];
      this.defs.push("");
      const idx = this.defs.length - 1;
      const self = this;
      const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
      return {
        __grad: id,
        addColorStop(off, col) {
          const sc = splitColor(col);
          stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
          self.defs[idx] = `<linearGradient id="${id}" x1="${r2(ax)}" y1="${r2(ay)}" x2="${r2(bx)}" y2="${r2(by)}" gradientUnits="userSpaceOnUse">${stops.join("")}</linearGradient>`;
        }
      };
    }
    /** SVG <radialGradient> support — required for dual-axis 3D line markers. */
    createRadialGradient(x0, y0, r0, x1, y1, r1) {
      const id = `g${++this.gradN}`;
      const stops = [];
      this.defs.push("");
      const idx = this.defs.length - 1;
      const self = this;
      const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
      return {
        __grad: id,
        addColorStop(off, col) {
          const sc = splitColor(col);
          stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
          self.defs[idx] = `<radialGradient id="${id}" cx="${r2(ax)}" cy="${r2(ay)}" r="${r2(Math.max(0.01, r0))}" fx="${r2(bx)}" fy="${r2(by)}" fr="${r2(Math.max(0.01, r1))}" gradientUnits="userSpaceOnUse">${stops.join("")}</radialGradient>`;
        }
      };
    }
    toString() {
      const fams = fontFamilies(themeColors(true));
      const googleImport = fams.length ? `@import url('https://fonts.googleapis.com/css2?family=${fams.map((f) => encodeURIComponent(f).replace(/%20/g, "+")).join("&family=")}:wght@400;600;700&display=swap');
` : "";
      const style = `<style><![CDATA[
${googleImport}${this.fontCss}]]></style>`;
      return `<svg xmlns="http://www.w3.org/2000/svg" width="${this.W}" height="${this.H}" viewBox="0 0 ${this.W} ${this.H}"><defs>${style}${this.defs.join("")}</defs><rect width="${this.W}" height="${this.H}" fill="#ffffff"/>${this.els.join("")}</svg>`;
    }
  };
  function planX(labels, step, full, fs = 10.5) {
    const longest = labels.reduce((m, l) => Math.max(m, approxW(l, fs)), 0);
    const base = 34;
    if (!labels.length || longest <= step - 6) return { rot: 0, stride: 1, padB: base, maxW: Math.max(20, step - 4), fs, overhang: 0 };
    if (full) {
      const rot2 = longest * SIN45 + fs <= 130 ? -Math.PI / 4 : -Math.PI / 2;
      const foot2 = fs * 1.4 / Math.abs(Math.sin(rot2));
      const stride2 = Math.max(1, Math.ceil(foot2 / Math.max(1, step)));
      const padB2 = Math.min(170, (rot2 === -Math.PI / 2 ? longest : longest * SIN45) + 22);
      return { rot: rot2, stride: stride2, padB: padB2, maxW: Infinity, fs, overhang: longest * Math.abs(Math.cos(rot2)) + 4 };
    }
    if (step >= 56) return { rot: 0, stride: 1, padB: base, maxW: step - 4, fs, overhang: 0 };
    const rot = -Math.PI / 4;
    const foot = fs * 1.4 / SIN45;
    const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
    const maxW = 78;
    const padB = Math.min(70, Math.min(longest, maxW) * SIN45 + 22);
    return { rot, stride, padB, maxW, fs, overhang: Math.min(longest, maxW) * SIN45 + 4 };
  }
  function planXFit(labels, W, l, r, full, fs, slots, endpoints = false) {
    const stepOf = (left) => {
      const cw = Math.max(10, W - left - r);
      return endpoints ? slots > 1 ? cw / (slots - 1) : cw : cw / Math.max(1, slots);
    };
    let plan = planX(labels, stepOf(l), full, fs);
    if (plan.overhang > l) {
      l = plan.overhang;
      plan = planX(labels, stepOf(l), full, fs);
    }
    return { plan, l, step: stepOf(l) };
  }
  function drawXLabels(ctx, labels, plan, xOf, yAxis, t, W, weight = 600, color) {
    ctx.font = font(t, weight, plan.fs);
    ctx.fillStyle = color || t.axis;
    const n = labels.length;
    for (let i = 0; i < n; i++) {
      const x = xOf(i);
      const isLast = i === n - 1;
      const shown = i % plan.stride === 0 || isLast && plan.stride > 1 && (n - 1) % plan.stride >= Math.ceil(plan.stride * 0.6);
      if (!shown) {
        ctx.strokeStyle = t.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x, yAxis);
        ctx.lineTo(x, yAxis + 3);
        ctx.stroke();
        continue;
      }
      const text = plan.maxW === Infinity ? labels[i] : fitCtx(ctx, labels[i], plan.maxW);
      if (plan.rot === 0) {
        const w = measureW(ctx, text);
        const cx = Math.max(w / 2 + 2, Math.min(W - w / 2 - 2, x));
        ctx.textAlign = "center";
        ctx.fillText(text, cx, yAxis + 16);
      } else {
        ctx.save();
        ctx.translate(x, yAxis + 8);
        ctx.rotate(plan.rot);
        ctx.textAlign = "right";
        ctx.fillText(text, 0, plan.fs * 0.35);
        ctx.restore();
      }
    }
    ctx.textAlign = "left";
  }
  var ZX = 15;
  var ZY = 10;
  var DZ = 7;
  var DZY = 4.5;
  function xyLayout(kind, W, H, m, labels, nD, max, hasY, full) {
    const isBar = kind === "bar";
    const ox = isBar ? 13 * m : ZX * m * Math.max(0, nD - 1) + DZ * m;
    const oy = isBar ? 9 * m : ZY * m * Math.max(0, nD - 1) + DZY * m;
    const l0 = 12 + approxW(fmtNum(max), 10.5) + 12 + (hasY ? 14 : 0);
    const r = 16 + (isBar ? 20 * m : ox);
    const tp = 18 + (isBar ? 12 * m : oy);
    const { plan, l, step } = planXFit(labels, W, l0, r, full, 10.5, labels.length);
    return { pad: { l, r, t: tp, b: plan.padB }, cw: W - l - r, ch: H - tp - plan.padB, step, plan, ox, oy };
  }
  function seriesDepth(series) {
    const order = series.map((s, i) => ({ i, sum: s.values.reduce((a, b) => a + b, 0) })).sort((a, b) => a.sum - b.sum);
    const depth = new Array(series.length).fill(0);
    order.forEach((o, rank) => {
      depth[o.i] = rank;
    });
    return depth;
  }
  var leaderLabel = (d, total) => `${d.label} \xB7 ${Math.round(d.value / total * 100)}%`;
  function circGeom(W, H, m, data, full = false) {
    const total = data.reduce((s, x) => s + x.value, 0) || 1;
    const longest = Math.max(0, ...data.map((x) => approxW(leaderLabel(x, total))));
    const labelSpace = full ? longest + 40 : Math.min(Math.max(60, longest) + 34, W * 0.32);
    const squash = lerp(1, K, m);
    let R = Math.min(W / 2 - labelSpace, (H - 44) / 2);
    R = Math.max(full ? 60 : 40, R);
    const depth = Math.max(18, R * 0.42) * m;
    const cy = (H - depth) / 2 + 4;
    return { cx: W / 2, cy, R, rInRatio: 0.55, depth, squash, total };
  }
  function sankeyLayout(links, W, H, labelSpace, morph = 0) {
    const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
    const idx = new Map(names.map((n, i) => [n, i]));
    const outs = names.map(() => []), ins = names.map(() => []);
    links.forEach((l, li) => {
      outs[idx.get(l.source)].push(li);
      ins[idx.get(l.target)].push(li);
    });
    const col = new Array(names.length).fill(0);
    const visit = (i, depth, seen) => {
      if (seen.has(i) || depth > 32) return;
      col[i] = Math.max(col[i], depth);
      seen.add(i);
      outs[i].forEach((li) => visit(idx.get(links[li].target), depth + 1, seen));
      seen.delete(i);
    };
    names.forEach((_, i) => {
      if (!ins[i].length) visit(i, 0, /* @__PURE__ */ new Set());
    });
    const cols = Math.max(...col) + 1;
    if (cols < 2) return null;
    const value = names.map((_, i) => Math.max(outs[i].reduce((s2, li) => s2 + links[li].value, 0), ins[i].reduce((s2, li) => s2 + links[li].value, 0)));
    const padT = 14, padB = 14, padL = 8, padR = labelSpace;
    const nodeW = 12, gap = 10;
    const plotW = W - padL - padR - nodeW, plotH = H - padT - padB;
    const colX = Array.from({ length: cols }, (_, c) => padL + plotW * c / (cols - 1));
    const perCol = Array.from({ length: cols }, () => []);
    names.forEach((_, i) => perCol[col[i]].push(i));
    const scale = Math.max(0, Math.min(...perCol.filter((ids) => ids.length).map(
      (ids) => (plotH - gap * Math.max(0, ids.length - 1)) / Math.max(1, ids.reduce((sum, i) => sum + value[i], 0))
    )));
    const pal = activePalette();
    const nodes = names.map((n, i) => ({ name: n, col: col[i], value: value[i], x: colX[col[i]], y: 0, h: value[i] * scale, color: pal[i % pal.length] }));
    perCol.forEach((ids) => {
      ids.sort((a, b) => value[b] - value[a]);
      const total = ids.reduce((s2, i) => s2 + nodes[i].h, 0) + gap * Math.max(0, ids.length - 1);
      let y = padT + (plotH - total) / 2;
      ids.forEach((i) => {
        nodes[i].y = y;
        y += nodes[i].h + gap;
      });
    });
    const flows = links.map((l) => ({ si: idx.get(l.source), ti: idx.get(l.target), value: l.value, sy0: 0, sy1: 0, ty0: 0, ty1: 0 }));
    nodes.forEach((n, i) => {
      let y = n.y;
      outs[i].map((li) => flows[li]).sort((a, b) => nodes[a.ti].y - nodes[b.ti].y).forEach((f) => {
        f.sy0 = y;
        y += f.value * scale;
        f.sy1 = y;
      });
      y = n.y;
      ins[i].map((li) => flows[li]).sort((a, b) => nodes[a.si].y - nodes[b.si].y).forEach((f) => {
        f.ty0 = y;
        y += f.value * scale;
        f.ty1 = y;
      });
    });
    const projectY = (y, x) => H / 2 + (y - H / 2) * (1 - 0.08 * morph) - (x / W - 0.5) * 16 * morph;
    flows.forEach((f) => {
      f.sy0 = projectY(f.sy0, nodes[f.si].x);
      f.sy1 = projectY(f.sy1, nodes[f.si].x);
      f.ty0 = projectY(f.ty0, nodes[f.ti].x);
      f.ty1 = projectY(f.ty1, nodes[f.ti].x);
    });
    nodes.forEach((n) => {
      n.y = projectY(n.y, n.x);
      n.h *= 1 - 0.06 * morph;
    });
    return { nodes, flows, nodeW, cols, colX };
  }
  function sankeyRibbon(ctx, f, nodes, nodeW, emphasis = 0) {
    const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x, mid = (x0 + x1) / 2;
    const spread = 5 * emphasis;
    ctx.beginPath();
    ctx.moveTo(x0, f.sy0);
    ctx.bezierCurveTo(mid, f.sy0 - spread, mid, f.ty0 - spread, x1, f.ty0);
    ctx.lineTo(x1, f.ty1);
    ctx.bezierCurveTo(mid, f.ty1 + spread, mid, f.sy1 + spread, x0, f.sy1);
    ctx.closePath();
  }
  function radialGeom(W, H, data, full) {
    const n = Math.max(1, data.length);
    const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
    const labelSpace = full ? longest + 26 : Math.min(W * 0.3, Math.max(48, longest) + 22);
    const R = Math.max(30, Math.min((W - labelSpace) / 2 - 12, H / 2 - 16));
    const cx = labelSpace + (W - labelSpace) / 2, cy = H / 2;
    const gap = 3;
    const thick = Math.max(4, Math.min(22, (R * 0.72 - gap * (n - 1)) / n));
    const radiusOf = (i) => R - thick / 2 - i * (thick + gap);
    return { cx, cy, R, thick, gap, radiusOf, labelSpace, n };
  }
  var funnelLabel = (x, total) => `${x.label} \xB7 ${x.value} (${Math.round(x.value / total * 100)}%)`;
  function funnelGeom(W, H, m, data, full, pyramid = false) {
    const total = data.reduce((s, x) => s + x.value, 0) || 1;
    const longest = Math.max(0, ...data.map((x) => approxW(funnelLabel(x, total))));
    const labelSpace = full ? longest + 40 : Math.min(160, W * 0.3);
    const padT = 16, padB = 16;
    const env = Math.min(H - padT - padB, W * 0.62);
    const sq = 0.16 * m;
    const ch = env / (1 + 1.2 * sq);
    const side = pyramid ? 0.2 * 0.96 * m : 0;
    const plotW = Math.min((W - labelSpace - 60) / (1 + side / 2), ch * 1.15);
    const capTop = plotW / 2 * sq;
    const topY = padT + (H - padT - padB - env) / 2 + capTop;
    const cx = (W - labelSpace) / 2 + 10 - plotW * side / 4;
    const laneX = cx + plotW / 2 * 0.96 + plotW * side + 14;
    return { total, labelSpace, ch, plotW, sq, topY, cx, capTop, laneX };
  }
  function drawLeaders(ctx, cx, cy, R, squash, data, colors, total, t, W, H, equalAngles = false, full = false) {
    ctx.font = font(t, 600, full ? 13 : 12);
    const n = data.length;
    let a = -Math.PI / 2;
    const entries = data.map((d, i) => {
      let mid;
      if (equalAngles) mid = -Math.PI / 2 + (i + 0.5) * Math.PI * 2 / n;
      else {
        const a2 = a + d.value / total * Math.PI * 2;
        mid = (a + a2) / 2;
        a = a2;
      }
      return { i, mid, right: Math.cos(mid) >= 0, y: cy + Math.sin(mid) * (R + 20) * squash };
    });
    const place = (list) => {
      list.sort((p, q) => p.y - q.y);
      let prev = -Infinity;
      list.forEach((e) => {
        e.y = Math.max(e.y, prev + 18);
        prev = e.y;
      });
      list.forEach((e) => {
        e.y = Math.max(12, Math.min(H - 8, e.y));
      });
    };
    place(entries.filter((e) => e.right));
    place(entries.filter((e) => !e.right));
    entries.forEach((e) => {
      const d = data[e.i];
      const ax = cx + Math.cos(e.mid) * R;
      const ay = cy + Math.sin(e.mid) * R * squash;
      const qx = cx + Math.cos(e.mid) * (R + 18);
      const qy = cy + Math.sin(e.mid) * (R + 18) * squash;
      const ex = cx + (e.right ? R + 26 : -(R + 26));
      const tx = cx + (e.right ? R + 34 : -(R + 34));
      const c1x = (ex + qx) / 2, c1y = e.y;
      const c2x = qx, c2y = qy;
      const dx = ax - c2x, dy = ay - c2y;
      const dl = Math.hypot(dx, dy) || 1;
      const ux = dx / dl, uy = dy / dl;
      const px2 = -uy, py2 = ux;
      const bx = ax - ux * 8, by = ay - uy * 8;
      ctx.strokeStyle = colors[e.i];
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(tx, e.y);
      ctx.lineTo(ex, e.y);
      ctx.bezierCurveTo(c1x, c1y, c2x, c2y, bx, by);
      ctx.stroke();
      ctx.fillStyle = colors[e.i];
      ctx.beginPath();
      ctx.moveTo(ax + ux * 0.5, ay + uy * 0.5);
      ctx.lineTo(bx - ux * 1.2 + px2 * 4.2, by - uy * 1.2 + py2 * 4.2);
      ctx.lineTo(bx - ux * 1.2 - px2 * 4.2, by - uy * 1.2 - py2 * 4.2);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 1;
      ctx.lineJoin = "round";
      ctx.stroke();
      ctx.lineJoin = "miter";
      const avail = e.right ? W - tx - 8 : tx - 8;
      ctx.fillStyle = t.ink;
      ctx.textAlign = e.right ? "left" : "right";
      const text = leaderLabel(d, total);
      ctx.fillText(full ? text : fitCtx(ctx, text, avail), tx + (e.right ? 4 : -4), e.y + 4);
    });
    ctx.textAlign = "left";
  }
  function drawAxes(ctx, W, H, pad, max, t, ox = 0, oy = 0) {
    const ch = H - pad.t - pad.b;
    ctx.font = font(t, 600, 10.5);
    for (let g = 0; g <= 4; g++) {
      const y = pad.t + ch - ch * g / 4;
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = 1;
      ctx.beginPath();
      if (ox) {
        ctx.moveTo(pad.l, y);
        ctx.lineTo(pad.l + ox, y - oy);
        ctx.lineTo(W - pad.r + ox, y - oy);
      } else {
        ctx.moveTo(pad.l, y);
        ctx.lineTo(W - pad.r, y);
      }
      ctx.stroke();
      ctx.fillStyle = t.axis;
      ctx.textAlign = "right";
      ctx.fillText(fmtNum(max * g / 4), pad.l - 7, y + 3.5);
    }
    ctx.strokeStyle = t.axis;
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(pad.l, pad.t - 4);
    ctx.lineTo(pad.l, pad.t + ch);
    ctx.lineTo(W - pad.r, pad.t + ch);
    ctx.stroke();
    ctx.lineWidth = 1;
    ctx.textAlign = "left";
  }
  function paintChart(ctx, kind, d) {
    const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
    const full = !!d.full;
    if (d.bg) {
      ctx.fillStyle = d.bg;
      ctx.fillRect(0, 0, W, H);
    } else ctx.clearRect(0, 0, W, H);
    if (!data.length && !(multi && cats.length) && kind !== "calendarpie" && kind !== "sankey" && kind !== "gantt" && kind !== "scatter") return;
    const total = data.reduce((s, x) => s + x.value, 0) || 1;
    if (kind === "bar") {
      const labels = multi ? cats : data.map((x) => x.label);
      const max = multi ? Math.max(...cats.map((_, c) => series.reduce((s, sr) => s + (sr.values[c] || 0), 0)), 1) : Math.max(...data.map((x) => x.value), 1);
      const L = xyLayout("bar", W, H, m, labels, 1, max, !!d.yLabel, full);
      const { pad, ch, step, ox, oy } = L;
      drawAxes(ctx, W, H, pad, max, t, ox, oy);
      if (d.yLabel) {
        ctx.save();
        ctx.translate(11, pad.t + ch / 2);
        ctx.rotate(-Math.PI / 2);
        ctx.font = font(t, 600, 10.5);
        ctx.textAlign = "center";
        ctx.fillStyle = t.axis;
        ctx.fillText(d.yLabel, 0, 0);
        ctx.restore();
      }
      drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2 + ox / 2, pad.t + ch, t, W);
      labels.forEach((_, ci) => {
        const bw = Math.min(44, step * 0.52);
        const x = pad.l + step * ci + (step - bw) / 2;
        const segs2 = multi ? series.map((sr, si) => ({ v: sr.values[ci] || 0, col: sColors[si], on: !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === si) })) : [{ v: data[ci].value, col: colors[ci], on: hov.idx === ci }];
        let acc = 0;
        segs2.forEach((sg, si) => {
          if (sg.v <= 0) return;
          const h = sg.v / max * ch * p;
          const yTop = pad.t + ch - acc / max * ch * p - h;
          const col = sg.on ? shade(sg.col, 1 + 0.16 * hov.amt) : sg.col;
          if (m > 0.02) {
            ctx.fillStyle = shade(sg.col, 0.7 * (sg.on ? 1 + 0.1 * hov.amt : 1));
            ctx.beginPath();
            ctx.moveTo(x + bw, yTop);
            ctx.lineTo(x + bw + ox, yTop - oy);
            ctx.lineTo(x + bw + ox, yTop - oy + h);
            ctx.lineTo(x + bw, yTop + h);
            ctx.closePath();
            ctx.fill();
            const isTop = si === segs2.length - 1 || segs2.slice(si + 1).every((z) => z.v <= 0);
            if (isTop) {
              ctx.fillStyle = shade(sg.col, 1.22);
              ctx.beginPath();
              ctx.moveTo(x, yTop);
              ctx.lineTo(x + ox, yTop - oy);
              ctx.lineTo(x + bw + ox, yTop - oy);
              ctx.lineTo(x + bw, yTop);
              ctx.closePath();
              ctx.fill();
            }
            ctx.fillStyle = col;
            ctx.fillRect(x, yTop, bw, h);
          } else {
            ctx.fillStyle = col;
            ctx.beginPath();
            ctx.roundRect(x, yTop, bw, Math.max(1, h - (multi ? 1 : 0)), multi ? 2 : [6, 6, 0, 0]);
            ctx.fill();
          }
          acc += sg.v;
        });
      });
      ctx.textAlign = "left";
      return;
    }
    if (kind === "line" || kind === "area") {
      const list = multi ? series.map((s, i) => ({ name: s.name, color: sColors[i], values: s.values })) : [{ name: "", color: colors[0], values: data.map((x) => x.value) }];
      const nD = list.length;
      const depth2 = multi ? seriesDepth(series) : [0];
      const zx = ZX * m, zy = ZY * m, dz = DZ * m, dzy = DZY * m;
      const labels = multi ? cats : data.map((x) => x.label);
      const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
      const L = xyLayout(kind, W, H, m, labels, nD, max, !!d.yLabel, full);
      const { pad, ch, step, ox, oy } = L;
      drawAxes(ctx, W, H, pad, max, t, ox, oy);
      if (d.yLabel) {
        ctx.save();
        ctx.translate(11, pad.t + ch / 2);
        ctx.rotate(-Math.PI / 2);
        ctx.font = font(t, 600, 10.5);
        ctx.textAlign = "center";
        ctx.fillStyle = t.axis;
        ctx.fillText(d.yLabel, 0, 0);
        ctx.restore();
      }
      drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);
      const isArea = kind === "area";
      const order = list.map((_, i) => i).sort((a2, b) => depth2[b] - depth2[a2]);
      for (const si of order) {
        const sr = list[si];
        const offX = zx * depth2[si], offY = zy * depth2[si];
        const baseY = pad.t + ch - offY;
        const pts = sr.values.map((v, i) => ({
          x: pad.l + step * i + step / 2 + offX,
          y: pad.t + ch - v / max * ch * p - offY
        }));
        if (!pts.length) continue;
        if (isArea && m > 0.02) {
          const back = pts.map((pt) => ({ x: pt.x + dz, y: pt.y - dzy }));
          ctx.fillStyle = shade(sr.color, 0.72);
          ctx.beginPath();
          ctx.moveTo(back[0].x, baseY - dzy);
          back.forEach((pt) => ctx.lineTo(pt.x, pt.y));
          ctx.lineTo(back[back.length - 1].x, baseY - dzy);
          ctx.closePath();
          ctx.fill();
          for (let i = 0; i < pts.length - 1; i++) {
            ctx.fillStyle = shade(sr.color, 0.95);
            ctx.beginPath();
            ctx.moveTo(pts[i].x, pts[i].y);
            ctx.lineTo(pts[i + 1].x, pts[i + 1].y);
            ctx.lineTo(back[i + 1].x, back[i + 1].y);
            ctx.lineTo(back[i].x, back[i].y);
            ctx.closePath();
            ctx.fill();
          }
          ctx.fillStyle = shade(sr.color, 0.6);
          ctx.beginPath();
          ctx.moveTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
          ctx.lineTo(back[back.length - 1].x, back[back.length - 1].y);
          ctx.lineTo(back[back.length - 1].x, baseY - dzy);
          ctx.lineTo(pts[pts.length - 1].x, baseY);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = withAlpha(sr.color, "e6");
          ctx.beginPath();
          ctx.moveTo(pts[0].x, baseY);
          pts.forEach((pt) => ctx.lineTo(pt.x, pt.y));
          ctx.lineTo(pts[pts.length - 1].x, baseY);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = shade(sr.color, 1.15);
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          pts.forEach((pt, i) => i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y));
          ctx.stroke();
        } else {
          const curve = () => {
            ctx.moveTo(pts[0].x, pts[0].y);
            for (let i = 0; i < pts.length - 1; i++) {
              const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
              ctx.bezierCurveTo(
                p1.x + (p2.x - p0.x) / 6,
                p1.y + (p2.y - p0.y) / 6,
                p2.x - (p3.x - p1.x) / 6,
                p2.y - (p3.y - p1.y) / 6,
                p2.x,
                p2.y
              );
            }
          };
          if (isArea) {
            ctx.beginPath();
            curve();
            ctx.lineTo(pts[pts.length - 1].x, baseY);
            ctx.lineTo(pts[0].x, baseY);
            ctx.closePath();
            const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ch);
            grad.addColorStop(0, withAlpha(sr.color, multi ? "3d" : "59"));
            grad.addColorStop(1, withAlpha(sr.color, "08"));
            ctx.fillStyle = grad;
            ctx.fill();
            ctx.strokeStyle = sr.color;
            ctx.lineWidth = 2.5;
            ctx.lineJoin = "round";
            ctx.beginPath();
            curve();
            ctx.stroke();
          } else {
            ctx.strokeStyle = sr.color;
            ctx.lineWidth = 2.5;
            ctx.lineJoin = "round";
            ctx.beginPath();
            pts.forEach((pt, i) => i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y));
            ctx.stroke();
          }
          const dense = step < 14;
          pts.forEach((pt, i) => {
            const on = multi ? hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === si : hov.idx === i;
            if (dense && !on) return;
            ctx.fillStyle = on ? shade(sr.color, 1 + 0.2 * hov.amt) : sr.color;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, (step < 26 ? 3 : 4) + (on ? 2.5 * hov.amt : 0), 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#fff";
            ctx.lineWidth = 1.5;
            ctx.stroke();
          });
        }
      }
      ctx.textAlign = "left";
      return;
    }
    if (kind === "radar") {
      const labels = multi ? cats : data.map((x) => x.label);
      const longest = Math.max(0, ...labels.map((l) => approxW(l)));
      const margin = full ? Math.min(W * 0.4, longest + 24) : 44;
      const cx2 = W / 2, cy2 = H / 2 + 6, R = Math.max(30, Math.min(W / 2 - margin, H / 2 - 30));
      const n = Math.max(1, labels.length);
      const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
      const ang = (i) => -Math.PI / 2 + i * Math.PI * 2 / n;
      for (let ring = 1; ring <= 3; ring++) {
        ctx.strokeStyle = t.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let i = 0; i <= n; i++) {
          const aa = ang(i % n);
          i === 0 ? ctx.moveTo(cx2 + Math.cos(aa) * R * (ring / 3), cy2 + Math.sin(aa) * R * (ring / 3)) : ctx.lineTo(cx2 + Math.cos(aa) * R * (ring / 3), cy2 + Math.sin(aa) * R * (ring / 3));
        }
        ctx.stroke();
      }
      ctx.font = font(t, 600, 10.5);
      labels.forEach((l, i) => {
        const aa = ang(i);
        ctx.strokeStyle = t.grid;
        ctx.beginPath();
        ctx.moveTo(cx2, cy2);
        ctx.lineTo(cx2 + Math.cos(aa) * R, cy2 + Math.sin(aa) * R);
        ctx.stroke();
        ctx.fillStyle = t.axis;
        ctx.textAlign = Math.abs(Math.cos(aa)) < 0.3 ? "center" : Math.cos(aa) > 0 ? "left" : "right";
        const lx = cx2 + Math.cos(aa) * (R + 12);
        const avail = Math.abs(Math.cos(aa)) < 0.3 ? W - 8 : Math.cos(aa) > 0 ? W - lx - 4 : lx - 4;
        ctx.fillText(full ? l : fitCtx(ctx, l, Math.max(30, avail)), lx, cy2 + Math.sin(aa) * (R + 12) + 3);
      });
      const polys = multi ? series.map((s, i) => ({ color: sColors[i], values: s.values })) : [{ color: colors[0], values: data.map((x) => x.value) }];
      polys.forEach((poly) => {
        ctx.beginPath();
        for (let i = 0; i <= n; i++) {
          const aa = ang(i % n), v = (poly.values[i % n] || 0) / max * R * p;
          i === 0 ? ctx.moveTo(cx2 + Math.cos(aa) * v, cy2 + Math.sin(aa) * v) : ctx.lineTo(cx2 + Math.cos(aa) * v, cy2 + Math.sin(aa) * v);
        }
        ctx.closePath();
        ctx.fillStyle = withAlpha(poly.color, multi ? "2e" : "40");
        ctx.fill();
        ctx.strokeStyle = poly.color;
        ctx.lineWidth = 2;
        ctx.stroke();
      });
      if (!multi) {
        data.forEach((x, i) => {
          const aa = ang(i), v = x.value / max * R * p;
          const on = hov.idx === i;
          ctx.fillStyle = on ? shade(colors[0], 1 + 0.25 * hov.amt) : colors[0];
          ctx.beginPath();
          ctx.arc(cx2 + Math.cos(aa) * v, cy2 + Math.sin(aa) * v, 4 + (on ? 2 * hov.amt : 0), 0, Math.PI * 2);
          ctx.fill();
        });
      }
      ctx.textAlign = "left";
      return;
    }
    if (kind === "polar") {
      const g2 = circGeom(W, H, m, data, full);
      const cx2 = g2.cx, cy2 = g2.cy, R = g2.R;
      const squash2 = 1 - 0.44 * m;
      const depth2 = 16 * m;
      const max = Math.max(...data.map((x) => x.value), 1);
      if (m > 0.05) {
        ctx.save();
        setShadow(ctx, 0, 8, 20, rgba(t.ink, 0.22 * m));
        ctx.fillStyle = t.surface || "#e4e7e0";
        ctx.beginPath();
        ctx.ellipse(cx2, cy2 + depth2, R, R * squash2, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      for (let ring = 1; ring <= 3; ring++) {
        ctx.strokeStyle = t.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.ellipse(cx2, cy2, R * (ring / 3), R * (ring / 3) * squash2, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      const n = Math.max(1, data.length);
      const pieces = data.map((x, i) => {
        const a0 = -Math.PI / 2 + i * Math.PI * 2 / n;
        const a1 = a0 + Math.PI * 2 / n;
        const offset = radialOffset((a0 + a1) / 2, hov.idx === i ? 14 * hov.amt : 0, squash2);
        return { i, a0, a1, r: Math.max(2, x.value / max * R * p), dx: offset.x, dy: offset.y };
      });
      const faces = [];
      pieces.forEach(({ i, a0, a1, r, dx, dy }) => {
        if (m <= 5e-3) return;
        const x = (a2) => cx2 + dx + Math.cos(a2) * r;
        const y = (a2) => cy2 + dy + Math.sin(a2) * r * squash2;
        [a0, a1].forEach((edge) => faces.push({
          y: cy2 + dy + Math.sin(edge) * r * squash2 / 2,
          draw: () => {
            ctx.fillStyle = shade(colors[i], 0.72);
            ctx.beginPath();
            ctx.moveTo(cx2 + dx, cy2 + dy);
            ctx.lineTo(x(edge), y(edge));
            ctx.lineTo(x(edge), y(edge) + depth2);
            ctx.lineTo(cx2 + dx, cy2 + dy + depth2);
            ctx.closePath();
            ctx.fill();
          }
        }));
        const count = Math.max(3, Math.ceil((a1 - a0) * r / 6));
        for (let step = 0; step < count; step++) {
          const b0 = a0 + (a1 - a0) * step / count;
          const b1 = a0 + (a1 - a0) * (step + 1) / count;
          const mid = (b0 + b1) / 2;
          if (Math.sin(mid) <= 0) continue;
          faces.push({ y: y(mid), draw: () => {
            ctx.fillStyle = shade(colors[i], 0.64 + 0.16 * Math.cos(mid));
            ctx.beginPath();
            ctx.moveTo(x(b0), y(b0));
            ctx.lineTo(x(b1), y(b1));
            ctx.lineTo(x(b1), y(b1) + depth2);
            ctx.lineTo(x(b0), y(b0) + depth2);
            ctx.closePath();
            ctx.fill();
          } });
        }
      });
      faces.sort((a2, b) => a2.y - b.y).forEach((face) => face.draw());
      pieces.forEach(({ i, a0, a1, r, dx, dy }) => {
        ctx.fillStyle = hov.idx === i ? shade(colors[i], 1 + 0.1 * hov.amt) : colors[i];
        ctx.beginPath();
        ctx.moveTo(cx2 + dx, cy2 + dy);
        ctx.ellipse(cx2 + dx, cy2 + dy, r, r * squash2, 0, a0, a1);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.55)";
        ctx.lineWidth = 0.7;
        ctx.stroke();
      });
      if (p > 0.95) drawLeaders(ctx, cx2, cy2, R, squash2, data, colors, total, t, W, H, true, full);
      return;
    }
    if (kind === "calendarpie") {
      const days = d.days || [];
      const names = series.map((x) => x.name);
      if (!days.length || !names.length) return;
      const dates = days.map((x) => /* @__PURE__ */ new Date(x.date + "T00:00:00"));
      const first = new Date(Math.min(...dates.map((x) => x.getTime())));
      const monthStart = new Date(first.getFullYear(), first.getMonth(), 1);
      const monthEnd = new Date(first.getFullYear(), first.getMonth() + 1, 0);
      const byDay = new Map(days.map((x) => [x.date, x.values]));
      const padL = 12, padR = 12, padT = 34, padB = 10;
      const cols = 7;
      const leadBlank = (monthStart.getDay() + 6) % 7;
      const rows = Math.ceil((leadBlank + monthEnd.getDate()) / cols);
      const cell = Math.min((W - padL - padR) / cols, (H - padT - padB) / rows);
      const gx = padL + (W - padL - padR - cell * cols) / 2, gy = padT + (H - padT - padB - cell * rows) / 2;
      const r = cell * 0.36;
      ctx.font = font(t, 700, Math.min(11, Math.max(8.5, cell * 0.16)));
      ctx.fillStyle = t.ink;
      ctx.textAlign = "left";
      ctx.fillText(monthStart.toLocaleDateString("en", { month: "long", year: "numeric" }), padL, 18);
      ctx.font = font(t, 700, Math.min(10, Math.max(8, cell * 0.14)));
      ctx.fillStyle = t.axis;
      ctx.textAlign = "center";
      ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].forEach((wd, i) => ctx.fillText(wd, gx + cell * i + cell / 2, gy - 6));
      for (let dnum = 1; dnum <= monthEnd.getDate(); dnum++) {
        const idx = leadBlank + dnum - 1, c = idx % cols, rw = Math.floor(idx / cols);
        const x0 = gx + c * cell, y0 = gy + rw * cell;
        ctx.strokeStyle = t.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.rect(x0 + 0.5, y0 + 0.5, cell - 1, cell - 1);
        ctx.stroke();
        const iso = `${monthStart.getFullYear()}-${String(monthStart.getMonth() + 1).padStart(2, "0")}-${String(dnum).padStart(2, "0")}`;
        const vals = byDay.get(iso);
        ctx.font = font(t, 700, Math.min(10, Math.max(7.5, cell * 0.14)));
        ctx.fillStyle = vals ? t.ink : t.axis;
        ctx.textAlign = "left";
        ctx.fillText(String(dnum), x0 + 4, y0 + Math.min(12, cell * 0.18));
        if (!vals) continue;
        const tot = vals.reduce((a22, b) => a22 + b, 0) || 1;
        const cx0 = x0 + cell / 2, cy0 = y0 + cell / 2 + cell * 0.05;
        const on = hov.seg && hov.seg.c === dnum;
        let a2 = -Math.PI / 2;
        vals.forEach((v, si) => {
          if (v <= 0) return;
          const a1 = a2 + v / tot * Math.PI * 2 * p;
          const hi = on && hov.seg.s === si;
          const rr = r * (hi ? 1 + 0.1 * hov.amt : 1);
          ctx.fillStyle = hi ? shade(sColors[si], 1.12) : sColors[si];
          ctx.beginPath();
          ctx.moveTo(cx0, cy0);
          ctx.arc(cx0, cy0, rr, a2, a1);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = d.bg || t.surface || "#fff";
          ctx.lineWidth = 1.2;
          ctx.stroke();
          if (cell >= 64 && v / tot >= 0.12 && p > 0.95) {
            const mid = (a2 + a1) / 2;
            ctx.fillStyle = "#fff";
            ctx.textAlign = "center";
            ctx.font = font(t, 700, Math.max(7.5, Math.min(10, r * 0.28)));
            ctx.fillText(fmtNum(v), cx0 + Math.cos(mid) * rr * 0.62, cy0 + Math.sin(mid) * rr * 0.62 + 3);
          }
          a2 = a1;
        });
      }
      ctx.textAlign = "left";
      return;
    }
    if (kind === "sankey") {
      const links = (d.links || []).filter((l) => l.value > 0 && l.source !== l.target);
      if (!links.length) return;
      const lay = sankeyLayout(links, W, H, full ? 200 : Math.min(150, W * 0.22), m);
      if (!lay) return;
      const { nodes, flows, nodeW, cols } = lay;
      const maxCol = Math.max(1, cols - 1);
      const activeFlow = hov.seg?.c === -2 ? hov.seg.s : null;
      const focused = hov.idx !== null || activeFlow !== null;
      const isActive = (f, i) => activeFlow === i || hov.idx === f.si || hov.idx === f.ti;
      if (m > 5e-3) flows.forEach((f, i) => {
        const fp = clamp01((p - 0.15 - nodes[f.si].col / maxCol * 0.45) / 0.38);
        if (fp <= 1e-3) return;
        const on = isActive(f, i);
        ctx.save();
        ctx.globalAlpha = fp * 0.32 * (focused && !on ? 1 - 0.68 * hov.amt : 1);
        ctx.fillStyle = shade(nodes[f.si].color, 0.65);
        ctx.save();
        ctx.translate(1.5 * m, 1.5 * m);
        sankeyRibbon(ctx, f, nodes, nodeW, on ? hov.amt : 0);
        ctx.fill();
        ctx.restore();
        ctx.restore();
      });
      flows.forEach((f, i) => {
        const src = nodes[f.si], tgt = nodes[f.ti];
        const on = isActive(f, i);
        const x0 = src.x + nodeW, x1 = tgt.x;
        const pStart = 0.15 + src.col / maxCol * 0.45;
        const pEnd = Math.min(1, pStart + 0.38);
        const fp = clamp01((p - pStart) / (pEnd - pStart));
        if (fp <= 1e-3) return;
        const grad = ctx.createLinearGradient(x0, 0, x1, 0);
        const alpha = lerp(0.58, 0.78, m) * (focused ? on ? 1 + 0.03 * hov.amt : 1 - 0.72 * hov.amt : 1);
        grad.addColorStop(0, rgba(src.color, Math.min(0.82, alpha)));
        grad.addColorStop(1, rgba(tgt.color, Math.min(0.82, alpha)));
        ctx.fillStyle = grad;
        ctx.save();
        if (fp < 0.999) {
          const sweepX = x0 + (x1 - x0) * fp;
          ctx.beginPath();
          ctx.rect(0, 0, sweepX, H);
          ctx.clip();
        }
        sankeyRibbon(ctx, f, nodes, nodeW, on ? hov.amt : 0);
        ctx.fill();
        if (m > 0.05 || on) {
          ctx.strokeStyle = rgba("#ffffff", 0.24 * m + (on ? 0.45 * hov.amt : 0));
          ctx.lineWidth = on ? 1 + hov.amt : 0.7;
          ctx.stroke();
        }
        ctx.restore();
      });
      nodes.forEach((n, i) => {
        const colP = n.col / maxCol;
        const np = clamp01((p - colP * 0.25) / 0.32);
        if (np <= 1e-3) return;
        const on = hov.idx === i || activeFlow !== null && (flows[activeFlow]?.si === i || flows[activeFlow]?.ti === i);
        const expansion = on ? 2 * hov.amt : 0;
        const nh = Math.max(2, n.h * np);
        const ny = n.y + (n.h - nh) / 2;
        if (m > 5e-3) {
          const x = n.x + nodeW + expansion, dx = 3 * m, dy = 2 * m;
          ctx.fillStyle = rgba(shade(n.color, 0.55), 0.55);
          ctx.beginPath();
          ctx.moveTo(x, ny);
          ctx.lineTo(x + dx, ny + dy);
          ctx.lineTo(x + dx, ny + nh + dy);
          ctx.lineTo(x, ny + nh);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = rgba(shade(n.color, 0.72), 0.55);
          ctx.beginPath();
          ctx.moveTo(n.x - expansion, ny + nh);
          ctx.lineTo(x, ny + nh);
          ctx.lineTo(x + dx, ny + nh + dy);
          ctx.lineTo(n.x - expansion + dx, ny + nh + dy);
          ctx.closePath();
          ctx.fill();
        }
        ctx.fillStyle = on ? shade(n.color, 1 + 0.15 * hov.amt) : n.color;
        ctx.beginPath();
        ctx.roundRect(n.x - expansion, ny, nodeW + expansion * 2, nh, 2);
        ctx.fill();
        if (np > 0.65) {
          const lx = n.x + nodeW + 8;
          ctx.textAlign = "left";
          const avail = n.col < lay.cols - 1 ? (lay.colX[n.col + 1] ?? W) - lx - 10 : W - lx - 6;
          const one = `${n.name} \xB7 ${fmtNum(n.value)}`;
          ctx.font = font(t, 600, 11);
          if (full || measureW(ctx, one) <= avail) {
            ctx.fillStyle = t.ink;
            ctx.fillText(one, lx, n.y + n.h / 2 + 3.5);
          } else {
            ctx.fillStyle = t.ink;
            ctx.fillText(fitCtx(ctx, n.name, Math.max(30, avail)), lx, n.y + n.h / 2 - 2);
            ctx.font = font(t, 600, 9.5);
            ctx.fillStyle = t.axis;
            ctx.fillText(fmtNum(n.value), lx, n.y + n.h / 2 + 9);
          }
        }
      });
      ctx.textAlign = "left";
      return;
    }
    if (kind === "radialbar") {
      const rg = radialGeom(W, H, data, full);
      const max = Math.max(...data.map((x) => x.value), 1);
      const squash2 = 1 - 0.44 * m;
      const depth2 = 18 * m;
      const cx2 = rg.cx;
      const cy2 = rg.cy - depth2 * 0.25;
      ctx.font = font(t, 600, Math.min(11, Math.max(9, rg.thick * 0.8)));
      const ring = (r, start, end, y, inset = 0) => {
        const outer = r + rg.thick / 2 - inset, inner = Math.max(0.1, r - rg.thick / 2 + inset);
        ctx.beginPath();
        ctx.ellipse(cx2, y, outer, outer * squash2, 0, start, end);
        ctx.ellipse(cx2, y, inner, inner * squash2, 0, end, start, true);
        ctx.closePath();
      };
      if (!full) {
        ctx.strokeStyle = t.grid;
        ctx.lineWidth = 1;
        for (let g2 = 1; g2 <= 4; g2++) {
          ctx.beginPath();
          ctx.ellipse(cx2, cy2, rg.R * g2 / 4, rg.R * squash2 * g2 / 4, 0, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.fillStyle = t.axis;
        ctx.font = font(t, 600, 9);
        ctx.textAlign = "left";
        for (let g2 = 1; g2 <= 4; g2++) {
          ctx.fillText(fmtNum(max * g2 / 4), cx2 + rg.R * g2 / 4 + 4, cy2 + 3);
        }
      }
      noShadow(ctx);
      data.forEach((_, i) => {
        const r = rg.radiusOf(i);
        if (r <= rg.thick / 2) return;
        ctx.fillStyle = rgba(t.surface || "#e4e7e0", full ? 0.6 : 0.85);
        ring(r, 0, Math.PI * 2, cy2);
        ctx.fill();
      });
      if (m > 5e-3) data.forEach((x, i) => {
        const r = rg.radiusOf(i);
        if (r <= rg.thick / 2) return;
        const sweep = Math.min(Math.PI * 2 * 0.985, x.value / max * Math.PI * 2 * 0.985 * p);
        if (sweep <= 5e-3) return;
        const layers = Math.max(4, Math.min(10, Math.round(depth2)));
        for (let z = layers; z >= 1; z--) {
          const layer = z / layers;
          ctx.fillStyle = rgba(shade(colors[i], 0.45 + 0.25 * layer), 0.5);
          ring(r, -Math.PI / 2, -Math.PI / 2 + sweep, cy2 + z / layers * depth2);
          ctx.fill();
        }
      });
      data.forEach((x, i) => {
        const r = rg.radiusOf(i);
        if (r <= rg.thick / 2) return;
        const on = hov.idx === i;
        const col = colors[i];
        const sweep = Math.min(Math.PI * 2 * 0.985, x.value / max * Math.PI * 2 * 0.985 * p);
        if (sweep <= 5e-3) return;
        const end = -Math.PI / 2 + sweep;
        const pull = on ? hov.amt : 0;
        const baseR = r + pull * 3;
        ctx.fillStyle = on ? shade(col, 1 + 0.18 * hov.amt) : col;
        ring(baseR, -Math.PI / 2, end, cy2);
        ctx.fill();
        if (m > 0.05) {
          ctx.fillStyle = rgba("#ffffff", 0.32 * m);
          ring(baseR, -Math.PI / 2, end, cy2, rg.thick * 0.32);
          ctx.fill();
        }
        const tipX = cx2 + Math.cos(end) * baseR;
        const tipY = cy2 + Math.sin(end) * baseR * squash2;
        ctx.beginPath();
        ctx.arc(tipX, tipY, rg.thick * 0.52, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = rgba("#ffffff", 0.7);
        ctx.lineWidth = 1.2;
        ctx.stroke();
        if (full) {
          ctx.font = font(t, 700, Math.min(10, rg.thick * 0.7));
          ctx.fillStyle = "#fff";
          ctx.textAlign = "center";
          const labelAngle = -Math.PI / 2 + sweep * 0.5;
          ctx.fillText(fmtNum(x.value), cx2 + Math.cos(labelAngle) * baseR, cy2 + Math.sin(labelAngle) * baseR * squash2 + 3);
        }
        if (rg.thick >= 8 || full) {
          const text = `${x.label} \xB7 ${fmtNum(x.value)}`;
          const avail = full ? Infinity : cx2 - 14;
          const shown = fitCtx(ctx, text, avail);
          const tw = measureW(ctx, shown);
          const tx = cx2 - 14, ty = cy2 - baseR * squash2 + 4;
          ctx.fillStyle = rgba(d.bg || t.surface || "#ffffff", 0.92);
          ctx.beginPath();
          ctx.roundRect(tx - tw - 6, ty - 10, tw + 12, 14, 7);
          ctx.fill();
          ctx.fillStyle = on ? t.ink : t.axis;
          ctx.textAlign = "right";
          ctx.fillText(shown, tx, ty);
          ctx.strokeStyle = col;
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(tx + 3, cy2 - baseR * squash2);
          ctx.lineTo(cx2 - 1, cy2 - baseR * squash2);
          ctx.stroke();
        }
      });
      ctx.textAlign = "left";
      return;
    }
    if (kind === "dual") {
      const labels = multi ? cats : data.map((x) => x.label);
      const colVals = multi ? cats.map((_, c) => series[0]?.values[c] || 0) : data.map((x) => x.value);
      const barColors = multi ? [sColors[0]] : colors;
      const lines = multi ? series.slice(1).map((s, i) => ({ name: s.name, color: distinctLineColor(barColors, sColors[i + 1], activePalette()), values: s.values })) : [{
        name: "Cumulative %",
        // Premium slate ink for the Pareto cumulative line — never a bar color.
        color: distinctLineColor(barColors, "#0f172a", activePalette()),
        values: (() => {
          let acc = 0;
          return data.map((x) => {
            acc += x.value;
            return Math.round(acc / total * 100);
          });
        })()
      }];
      const ox = 20 * m, oy = 15 * m;
      const maxL = Math.max(...colVals, 1);
      const maxR = Math.max(...lines.flatMap((l) => l.values), 1);
      const L = xyLayout("bar", W, H, 0, labels, 1, maxL, !!d.yLabel, full);
      const pad = { ...L.pad, r: 12 + approxW(fmtNum(maxR), 10.5) + 14 + ox, t: L.pad.t + oy };
      const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
      const step = cw / Math.max(1, labels.length);
      if (m > 0.05) {
        ctx.strokeStyle = rgba(t.grid, 0.4);
        ctx.lineWidth = 1;
        for (let g2 = 0; g2 <= 4; g2++) {
          const y = pad.t + ch - ch * g2 / 4;
          ctx.beginPath();
          ctx.moveTo(pad.l, y);
          ctx.lineTo(pad.l + ox, y - oy);
          ctx.lineTo(W - pad.r + ox, y - oy);
          ctx.stroke();
        }
      }
      drawAxes(ctx, W, H, pad, maxL, t, m > 0.05 ? ox : 0, m > 0.05 ? oy : 0);
      ctx.font = font(t, 600, 10.5);
      ctx.fillStyle = t.axis;
      ctx.textAlign = "left";
      for (let g2 = 0; g2 <= 4; g2++) {
        const y = pad.t + ch - ch * g2 / 4;
        ctx.fillText(fmtNum(maxR * g2 / 4) + (multi ? "" : "%"), W - pad.r + (m > 0.05 ? ox : 0) + 7, (m > 0.05 ? y - oy : y) + 3.5);
      }
      ctx.strokeStyle = t.axis;
      ctx.lineWidth = 1.3;
      ctx.beginPath();
      ctx.moveTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t - 4 - (m > 0.05 ? oy : 0));
      ctx.lineTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t + ch - (m > 0.05 ? oy : 0));
      ctx.stroke();
      ctx.lineWidth = 1;
      if (d.yLabel) {
        ctx.save();
        ctx.translate(11, pad.t + ch / 2);
        ctx.rotate(-Math.PI / 2);
        ctx.textAlign = "center";
        ctx.fillStyle = t.axis;
        ctx.fillText(d.yLabel, 0, 0);
        ctx.restore();
      }
      drawXLabels(ctx, labels, planX(labels, step, full), (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);
      labels.forEach((_, ci) => {
        const bw = Math.min(36, step * 0.5);
        const x = pad.l + step * ci + (step - bw) / 2;
        const h = colVals[ci] / maxL * ch * p;
        const yTop = pad.t + ch - h;
        const yBase = pad.t + ch;
        const on = multi ? !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === 0) : hov.idx === ci;
        const col = multi ? sColors[0] : colors[ci];
        const cFill = on ? shade(col, 1 + 0.16 * hov.amt) : col;
        if (m > 0.05 && h > 1) {
          ctx.fillStyle = shade(cFill, 1.25);
          ctx.beginPath();
          ctx.moveTo(x, yTop);
          ctx.lineTo(x + ox, yTop - oy);
          ctx.lineTo(x + bw + ox, yTop - oy);
          ctx.lineTo(x + bw, yTop);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = "rgba(255,255,255,0.4)";
          ctx.lineWidth = 1;
          ctx.stroke();
          ctx.fillStyle = shade(cFill, 0.68);
          ctx.beginPath();
          ctx.moveTo(x + bw, yTop);
          ctx.lineTo(x + bw + ox, yTop - oy);
          ctx.lineTo(x + bw + ox, yBase - oy);
          ctx.lineTo(x + bw, yBase);
          ctx.closePath();
          ctx.fill();
        }
        ctx.fillStyle = cFill;
        ctx.beginPath();
        ctx.roundRect(x, yTop, bw, Math.max(1, h), m > 0.05 ? 0 : [5, 5, 0, 0]);
        ctx.fill();
      });
      lines.forEach((ln, li) => {
        const pts = ln.values.map((v, i) => ({
          x: pad.l + step * i + step / 2 + (m > 0.05 ? ox * 0.5 : 0),
          y: pad.t + ch - v / maxR * ch * p - (m > 0.05 ? oy * 0.5 : 0)
        }));
        if (!pts.length) return;
        if (m > 0.05) {
          ctx.strokeStyle = rgba(t.ink, 0.15);
          ctx.lineWidth = 3;
          ctx.beginPath();
          pts.forEach((pt, i) => {
            if (i === 0) ctx.moveTo(pt.x, pt.y + oy * 0.5);
            else ctx.lineTo(pt.x, pt.y + oy * 0.5);
          });
          ctx.stroke();
        }
        ctx.strokeStyle = ln.color;
        ctx.lineWidth = 2.5;
        ctx.lineJoin = "round";
        ctx.beginPath();
        pts.forEach((pt, i) => {
          if (i === 0) {
            ctx.moveTo(pt.x, pt.y);
            return;
          }
          const p0 = pts[Math.max(0, i - 2)], p1 = pts[i - 1], p2 = pt, p3 = pts[Math.min(pts.length - 1, i + 1)];
          ctx.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y - (p3.y - p1.y) / 6, p2.x, p2.y);
        });
        ctx.stroke();
        const dense = step < 14;
        pts.forEach((pt, i) => {
          const on = multi ? !!(hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === li + 1) : hov.idx === i;
          if (dense && !on) return;
          const rad = (step < 26 ? 3.5 : 4.5) + (on ? 2 * hov.amt : 0);
          if (m > 0.05) {
            const g2 = ctx.createRadialGradient(pt.x - 1.5, pt.y - 1.5, 1, pt.x, pt.y, rad);
            g2.addColorStop(0, shade(ln.color, 1.35));
            g2.addColorStop(1, shade(ln.color, 0.75));
            ctx.fillStyle = g2;
          } else {
            ctx.fillStyle = on ? shade(ln.color, 1.2) : ln.color;
          }
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, rad, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = "#fff";
          ctx.lineWidth = 1.5;
          ctx.stroke();
        });
      });
      ctx.textAlign = "left";
      return;
    }
    if (kind === "gantt") {
      const rawTasks = d.tasks && d.tasks.length ? d.tasks : data.map((x, i) => ({
        id: i,
        name: x.label,
        start: i * 3,
        end: i * 3 + Math.max(3, Math.round(x.value / 8)),
        progress: 35 + i * 17 % 60,
        color: colors[i],
        category: "Milestone"
      }));
      const padL = Math.max(140, Math.min(240, W * 0.26));
      const padR = 28, padT = 40, padB = 30;
      const chartW = W - padL - padR;
      const chartH = H - padT - padB;
      const rowH = Math.min(42, Math.max(26, chartH / Math.max(1, rawTasks.length)));
      const starts = rawTasks.map((tk) => typeof tk.start === "number" ? tk.start : new Date(tk.start).getTime());
      const ends = rawTasks.map((tk) => typeof tk.end === "number" ? tk.end : new Date(tk.end).getTime());
      const minTime = Math.min(...starts);
      const maxTime = Math.max(...ends, minTime + 1);
      const timeSpan = maxTime - minTime || 1;
      const cols = 5;
      ctx.font = font(t, 600, 10);
      ctx.textAlign = "center";
      for (let c = 0; c <= cols; c++) {
        const gx = padL + chartW * c / cols;
        ctx.strokeStyle = t.grid;
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(gx, padT - 4);
        ctx.lineTo(gx, padT + rowH * rawTasks.length);
        ctx.stroke();
        ctx.setLineDash([]);
        const tVal = minTime + timeSpan * c / cols;
        const tLabel = typeof rawTasks[0].start === "string" ? new Date(tVal).toLocaleDateString("en", { month: "short", day: "numeric" }) : `Day ${Math.round(tVal)}`;
        ctx.fillStyle = t.axis;
        ctx.fillText(tLabel, gx, padT - 12);
      }
      ctx.textAlign = "left";
      rawTasks.forEach((task, i) => {
        const tStart = typeof task.start === "number" ? task.start : new Date(task.start).getTime();
        const tEnd = typeof task.end === "number" ? task.end : new Date(task.end).getTime();
        const sx = padL + (tStart - minTime) / timeSpan * chartW;
        const ex = padL + (tEnd - minTime) / timeSpan * chartW;
        const barW = Math.max(8, ex - sx);
        const ry = padT + i * rowH;
        const barH = Math.max(14, rowH - 12);
        const by = ry + (rowH - barH) / 2;
        const on = hov.idx === i;
        const col = task.color || colors[i % colors.length] || "#0d7a54";
        if (on) {
          ctx.fillStyle = rgba(t.ink, 0.05);
          ctx.beginPath();
          ctx.roundRect(8, ry + 1, W - 16, rowH - 2, 6);
          ctx.fill();
        }
        ctx.font = font(t, 600, 11);
        ctx.fillStyle = on ? t.ink : shade(t.ink, 0.85);
        ctx.textAlign = "left";
        ctx.fillText(fitCtx(ctx, task.name, padL - 24), 16, by + barH * 0.65);
        ctx.fillStyle = rgba(col, 0.2);
        ctx.beginPath();
        ctx.roundRect(sx, by, barW, barH, 6);
        ctx.fill();
        const prg = Math.min(100, Math.max(0, task.progress ?? 100)) / 100;
        const pw = Math.max(4, barW * prg * p);
        ctx.fillStyle = on ? shade(col, 1.15) : col;
        ctx.beginPath();
        ctx.roundRect(sx, by, pw, barH, 6);
        ctx.fill();
        ctx.fillStyle = "rgba(255, 255, 255, 0.25)";
        ctx.beginPath();
        ctx.roundRect(sx, by, pw, barH / 2, [6, 6, 0, 0]);
        ctx.fill();
        if (barW > 35) {
          ctx.fillStyle = "#ffffff";
          ctx.font = font(t, 700, 9.5);
          ctx.textAlign = "center";
          ctx.fillText(`${Math.round(prg * 100)}%`, sx + pw / 2, by + barH * 0.7);
        }
      });
      ctx.textAlign = "left";
      return;
    }
    if (kind === "scatter") {
      const rawScatter = d.scatter && d.scatter.length ? d.scatter : data.map((x, i) => ({
        x: 20 + i * 8 + i * 13 % 19,
        y: x.value,
        label: x.label,
        size: 7 + i * 3 % 5,
        color: colors[i % colors.length]
      }));
      const padL = 52, padR = 24, padT = 34, padB = 40;
      const plotW = W - padL - padR, plotH = H - padT - padB;
      const xs = rawScatter.map((pt) => pt.x);
      const ys = rawScatter.map((pt) => pt.y);
      const minX = Math.min(...xs, 0), maxX = Math.max(...xs, minX + 1);
      const minY = Math.min(...ys, 0), maxY = Math.max(...ys, minY + 1);
      drawAxes(ctx, W, H, { l: padL, r: padR, t: padT, b: padB }, maxY, t);
      const xSteps = 5;
      ctx.font = font(t, 600, 10.5);
      ctx.textAlign = "center";
      for (let s = 0; s <= xSteps; s++) {
        const val = minX + (maxX - minX) * s / xSteps;
        const gx = padL + plotW * s / xSteps;
        ctx.strokeStyle = t.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(gx, padT);
        ctx.lineTo(gx, padT + plotH);
        ctx.stroke();
        ctx.fillStyle = t.axis;
        ctx.fillText(fmtNum(val), gx, padT + plotH + 18);
      }
      ctx.textAlign = "left";
      if (rawScatter.length >= 2) {
        const n = rawScatter.length;
        const sumX = xs.reduce((a2, b) => a2 + b, 0), sumY = ys.reduce((a2, b) => a2 + b, 0);
        const sumXY = rawScatter.reduce((a2, pt) => a2 + pt.x * pt.y, 0);
        const sumX2 = xs.reduce((a2, b) => a2 + b * b, 0);
        const slope = (n * sumXY - sumX * sumY) / Math.max(1e-6, n * sumX2 - sumX * sumX);
        const intercept = (sumY - slope * sumX) / n;
        const px0 = padL, py0 = padT + plotH - (intercept + slope * minX - minY) / (maxY - minY) * plotH;
        const px1 = padL + plotW, py1 = padT + plotH - (intercept + slope * maxX - minY) / (maxY - minY) * plotH;
        ctx.strokeStyle = rgba(t.axis, 0.4);
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(px0, py0);
        ctx.lineTo(px1, py1);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      rawScatter.forEach((pt, i) => {
        const px2 = padL + (pt.x - minX) / (maxX - minX) * plotW;
        const py2 = padT + plotH - (pt.y - minY) / (maxY - minY) * plotH;
        const baseR = pt.size || 7;
        const rad = Math.max(1.5, baseR * Math.max(0.05, p));
        const on = hov.idx === i;
        const col = pt.color || colors[i % colors.length] || "#0d7a54";
        if (on) {
          ctx.strokeStyle = rgba(col, 0.5);
          ctx.lineWidth = 1;
          ctx.setLineDash([2, 2]);
          ctx.beginPath();
          ctx.moveTo(padL, py2);
          ctx.lineTo(padL + plotW, py2);
          ctx.moveTo(px2, padT);
          ctx.lineTo(px2, padT + plotH);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.fillStyle = rgba(col, 0.2);
          ctx.beginPath();
          ctx.arc(px2, py2, rad + 6, 0, Math.PI * 2);
          ctx.fill();
        }
        const r0 = Math.max(0.1, rad * 0.15);
        const g2 = ctx.createRadialGradient(px2 - rad * 0.3, py2 - rad * 0.3, r0, px2, py2, rad);
        g2.addColorStop(0, shade(col, 1.35));
        g2.addColorStop(1, shade(col, 0.85));
        ctx.fillStyle = g2;
        ctx.beginPath();
        ctx.arc(px2, py2, on ? rad + 2 : rad, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.7)";
        ctx.lineWidth = 1;
        ctx.stroke();
      });
      return;
    }
    if (kind === "funnel" || kind === "pyramid") {
      const g2 = funnelGeom(W, H, m, data, full, kind === "pyramid");
      const { ch, plotW, sq, topY, cx: cx2, laneX } = g2;
      const heights = data.map((x) => x.value / total * ch * p);
      const sumH = heights.reduce((a2, b) => a2 + b, 0);
      const widthAt = (rel) => kind === "funnel" ? plotW * (0.96 - 0.66 * (rel / ch)) : plotW * (0.96 * (rel / ch));
      ctx.font = font(t, 600, 10.5);
      const rows = [];
      {
        let yy = topY + (ch - sumH);
        heights.forEach((h) => {
          rows.push(yy + h / 2);
          yy += h;
        });
      }
      const PITCH = 14;
      for (let i = 1; i < rows.length; i++) rows[i] = Math.max(rows[i], rows[i - 1] + PITCH);
      const floor = Math.min(H - 8, topY + ch + 18);
      for (let i = rows.length - 1; i >= 0; i--) rows[i] = Math.min(rows[i], i === rows.length - 1 ? floor : rows[i + 1] - PITCH);
      let y = topY + (ch - sumH);
      data.forEach((x, i) => {
        const h = heights[i];
        const rel0 = y - topY;
        const w0 = widthAt(rel0), w1 = widthAt(rel0 + h);
        const on = hov.idx === i;
        const col = on ? shade(colors[i], 1 + 0.12 * hov.amt) : colors[i];
        if (kind === "funnel" && m > 0.02) {
          ctx.fillStyle = col;
          ctx.beginPath();
          ctx.moveTo(cx2 - w0 / 2, y);
          ctx.lineTo(cx2 - w1 / 2, y + h);
          ctx.ellipse(cx2, y + h, Math.max(0.1, w1 / 2), Math.max(0.1, w1 / 2 * sq), 0, Math.PI, 0, true);
          ctx.lineTo(cx2 + w0 / 2, y);
          ctx.ellipse(cx2, y, Math.max(0.1, w0 / 2), Math.max(0.1, w0 / 2 * sq), 0, 0, Math.PI, false);
          ctx.closePath();
          ctx.fill();
          if (i === 0) {
            ctx.fillStyle = shade(colors[i], 1.22);
            ctx.beginPath();
            ctx.ellipse(cx2, y, Math.max(0.1, w0 / 2), Math.max(0.1, w0 / 2 * sq), 0, 0, Math.PI * 2);
            ctx.fill();
          }
        } else if (kind === "pyramid" && m > 5e-3) {
          const dxr = (w) => w * 0.2 * m, dyr = (w) => w * 0.075 * m;
          ctx.fillStyle = shade(colors[i], 0.72);
          ctx.beginPath();
          ctx.moveTo(cx2 + w0 / 2, y);
          ctx.lineTo(cx2 + w0 / 2 + dxr(w0), y - dyr(w0));
          ctx.lineTo(cx2 + w1 / 2 + dxr(w1), y + h - dyr(w1));
          ctx.lineTo(cx2 + w1 / 2, y + h);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = col;
          ctx.beginPath();
          ctx.moveTo(cx2 - w0 / 2, y);
          ctx.lineTo(cx2 + w0 / 2, y);
          ctx.lineTo(cx2 + w1 / 2, y + h);
          ctx.lineTo(cx2 - w1 / 2, y + h);
          ctx.closePath();
          ctx.fill();
          if (m < 0.98) {
            ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        } else {
          ctx.fillStyle = col;
          ctx.beginPath();
          ctx.moveTo(cx2 - w0 / 2, y);
          ctx.lineTo(cx2 + w0 / 2, y);
          ctx.lineTo(cx2 + w1 / 2, y + h);
          ctx.lineTo(cx2 - w1 / 2, y + h);
          ctx.closePath();
          ctx.fill();
          if (m < 0.98) {
            ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
        const midY = y + h / 2;
        const rowY = rows[i];
        const wMid = widthAt(rel0 + h / 2);
        const edgeX = cx2 + wMid / 2 + (kind === "pyramid" ? wMid * 0.2 * m : 0);
        const edgeY = midY - (kind === "pyramid" ? wMid * 0.075 * m : 0);
        const textX = laneX + 16;
        const ah = Math.min(3.8, Math.max(2.2, h / 2 - 0.5)), al = Math.max(4.5, ah * 2);
        ctx.strokeStyle = colors[i];
        ctx.lineWidth = 1.3;
        ctx.lineJoin = "round";
        ctx.beginPath();
        ctx.moveTo(edgeX + al, edgeY);
        if (Math.abs(rowY - edgeY) > 0.5) {
          ctx.lineTo(Math.max(edgeX + al + 4, laneX - 6), edgeY);
          ctx.lineTo(laneX, rowY);
        }
        ctx.lineTo(textX - 6, rowY);
        ctx.stroke();
        ctx.lineJoin = "miter";
        ctx.fillStyle = colors[i];
        ctx.beginPath();
        ctx.moveTo(edgeX + 0.5, edgeY);
        ctx.lineTo(edgeX + al + 0.5, edgeY - ah);
        ctx.lineTo(edgeX + al + 0.5, edgeY + ah);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.85)";
        ctx.lineWidth = 0.8;
        ctx.stroke();
        ctx.fillStyle = t.ink;
        ctx.textAlign = "left";
        const text = funnelLabel(x, total);
        ctx.fillText(full ? text : fitCtx(ctx, text, W - textX - 4), textX, rowY + 3.5);
        y += h;
      });
      ctx.textAlign = "left";
      return;
    }
    const g = circGeom(W, H, m, data, full);
    const { cx, cy, R: R0, depth, squash } = g;
    const rIn = kind === "donut" ? R0 * g.rInRatio : 0;
    let a = -Math.PI / 2;
    const segs = data.map((x, i) => {
      const a1 = a + x.value / total * Math.PI * 2 * p;
      const s = { a0: a, a1, i };
      a = a1;
      return s;
    });
    const hovAmt = (s) => hov.idx === s.i ? hov.amt : 0;
    const pullOf = (s) => 14 * hovAmt(s);
    const px = (ang, r) => cx + Math.cos(ang) * r;
    const py = (ang, r) => cy + Math.sin(ang) * r * squash;
    const OVER = 0.012;
    const offsetOf = (s) => {
      const a2 = hovAmt(s);
      if (!a2) return [0, 0];
      const mid = (s.a0 + s.a1) / 2, pull = pullOf(s);
      const offset = radialOffset(mid, pull, squash);
      return [offset.x, offset.y];
    };
    if (!d.bg && m < 0.999 && p > 0.05) {
      ctx.save();
      setShadow(ctx, 0, 7, 16, rgba(t.ink, 0.2 * (1 - m)));
      ctx.fillStyle = t.surface || "#e4e7e0";
      ctx.beginPath();
      ctx.ellipse(cx, cy + depth, R0 + 1, (R0 + 1) * squash, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    const vector = !!d.bg;
    const drawBody = (s, dx, dy) => {
      const faces = [];
      const Rx = R0;
      const col = hov.idx === s.i ? shade(colors[s.i], 1 + 0.08 * hov.amt) : colors[s.i];
      if (vector) {
        const vis0 = Math.max(s.a0, 0), vis1 = Math.min(s.a1, Math.PI);
        if (vis1 > vis0 + 1e-4) {
          faces.push({
            y: py((vis0 + vis1) / 2, Rx),
            draw: () => {
              const g2 = ctx.createLinearGradient(px(vis0, Rx) + dx, 0, px(vis1, Rx) + dx, 0);
              g2.addColorStop(0, shade(col, 0.62 + 0.2 * Math.cos(vis0)));
              g2.addColorStop(1, shade(col, 0.62 + 0.2 * Math.cos(vis1)));
              ctx.fillStyle = g2;
              ctx.beginPath();
              ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, vis0, vis1, false);
              ctx.ellipse(cx + dx, cy + dy + depth, Rx, Rx * squash, 0, vis1, vis0, true);
              ctx.closePath();
              ctx.fill();
            }
          });
        }
        if (rIn > 0) {
          const b0 = Math.max(s.a0, Math.PI), b1 = Math.min(s.a1, Math.PI * 2);
          const c0 = Math.max(s.a0, -Math.PI), c1 = Math.min(s.a1, 0);
          [[b0, b1], [c0, c1]].forEach(([q0, q1]) => {
            if (q1 <= q0 + 1e-4) return;
            faces.push({
              y: py((q0 + q1) / 2, rIn) - 900,
              draw: () => {
                ctx.fillStyle = shade(colors[s.i], 0.52);
                ctx.beginPath();
                ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, q0, q1, false);
                ctx.ellipse(cx + dx, cy + dy + depth, rIn, rIn * squash, 0, q1, q0, true);
                ctx.closePath();
                ctx.fill();
              }
            });
          });
        }
        [s.a0, s.a1].forEach((edge) => {
          faces.push({
            y: py(edge, (Rx + rIn) / 2) - 0.25,
            draw: () => {
              ctx.fillStyle = shade(colors[s.i], 0.72);
              ctx.beginPath();
              if (rIn > 0) {
                ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy);
                ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
                ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
                ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
              } else {
                ctx.moveTo(cx + dx, cy + dy);
                ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
                ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
                ctx.lineTo(cx + dx, cy + depth + dy);
              }
              ctx.closePath();
              ctx.fill();
            }
          });
        });
        return faces;
      }
      const steps = Math.max(3, Math.min(72, Math.ceil((s.a1 - s.a0) * Rx / 7)));
      for (let k = 0; k < steps; k++) {
        const b0 = s.a0 + (s.a1 - s.a0) * k / steps - OVER;
        const b1 = s.a0 + (s.a1 - s.a0) * (k + 1) / steps + OVER;
        const midS = (b0 + b1) / 2;
        if (Math.sin(midS) <= 0) continue;
        faces.push({
          y: py(midS, Rx),
          draw: () => {
            ctx.fillStyle = shade(col, 0.62 + 0.2 * Math.cos(midS));
            ctx.beginPath();
            ctx.moveTo(px(b0, Rx) + dx, py(b0, Rx) + dy);
            ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + dy);
            ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + depth + dy);
            ctx.lineTo(px(b0, Rx) + dx, py(b0, Rx) + depth + dy);
            ctx.closePath();
            ctx.fill();
          }
        });
      }
      if (rIn > 0) {
        const inner = Math.max(3, Math.min(48, Math.ceil((s.a1 - s.a0) * rIn / 7)));
        for (let k = 0; k < inner; k++) {
          const b0 = s.a0 + (s.a1 - s.a0) * k / inner - OVER;
          const b1 = s.a0 + (s.a1 - s.a0) * (k + 1) / inner + OVER;
          const midS = (b0 + b1) / 2;
          const back = Math.sin(midS) < 0;
          faces.push({
            y: back ? py(midS, rIn) - 900 : py(midS, rIn) - 0.5,
            draw: () => {
              ctx.fillStyle = shade(colors[s.i], back ? 0.52 : 0.44);
              ctx.beginPath();
              ctx.moveTo(px(b0, rIn) + dx, py(b0, rIn) + dy);
              ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + dy);
              ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + depth + dy);
              ctx.lineTo(px(b0, rIn) + dx, py(b0, rIn) + depth + dy);
              ctx.closePath();
              ctx.fill();
            }
          });
        }
      }
      [s.a0, s.a1].forEach((edge) => {
        faces.push({
          y: py(edge, (Rx + rIn) / 2) - 0.25,
          draw: () => {
            ctx.fillStyle = shade(colors[s.i], 0.88);
            ctx.beginPath();
            if (rIn > 0) {
              ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
              ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
            } else {
              ctx.moveTo(cx + dx, cy + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
              ctx.lineTo(cx + dx, cy + depth + dy);
            }
            ctx.closePath();
            ctx.fill();
          }
        });
      });
      return faces;
    };
    const drawTop = (s, dx, dy) => {
      const Rx = R0;
      const on = hov.idx === s.i;
      const pull = on ? 14 * hov.amt : 0;
      const o = OVER * clamp01(m * 8);
      if (on && pull > 0.5) {
        ctx.save();
        ctx.fillStyle = rgba(t.ink, 0.18 * hov.amt);
        ctx.beginPath();
        ctx.ellipse(cx + dx, cy + dy + 4, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
        if (rIn > 0) ctx.ellipse(cx + dx, cy + dy + 4, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
        else ctx.lineTo(cx + dx, cy + dy + 4);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      if (on && hov.amt > 0.01) {
        const mid = (s.a0 + s.a1) / 2;
        const px0 = cx + dx, py0 = cy + dy;
        const grad = ctx.createRadialGradient(
          px0 + Math.cos(mid) * Rx * 0.3,
          py0 + Math.sin(mid) * Rx * squash * 0.3,
          Rx * 0.1,
          px0,
          py0,
          Rx * 1.1
        );
        grad.addColorStop(0, shade(colors[s.i], 1 + 0.18 * hov.amt));
        grad.addColorStop(1, shade(colors[s.i], 0.95));
        ctx.fillStyle = grad;
      } else {
        ctx.fillStyle = colors[s.i];
      }
      ctx.beginPath();
      ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
      if (rIn > 0) ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
      else ctx.lineTo(cx + dx, cy + dy);
      ctx.closePath();
      ctx.fill();
      if (m > 0.1) {
        const mid = (s.a0 + s.a1) / 2;
        ctx.fillStyle = rgba("#ffffff", 0.22 * m * (on ? 1 + hov.amt : 1));
        ctx.beginPath();
        ctx.ellipse(cx + dx, cy + dy, Rx * 0.7, Rx * squash * 0.7, 0, mid - 0.4, mid - 0.05, false);
        ctx.closePath();
        ctx.fill();
      }
      if (m < 0.98) {
        ctx.strokeStyle = `rgba(255,255,255,${(0.55 * (1 - m)).toFixed(3)})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    };
    if (m > 5e-3) {
      const faces = segs.flatMap((s) => {
        const [dx, dy] = offsetOf(s);
        return drawBody(s, dx, dy).map((face) => ({ ...face, y: face.y + dy }));
      });
      faces.sort((a2, b) => a2.y - b.y).forEach((face) => face.draw());
    }
    segs.forEach((s) => {
      const [dx, dy] = offsetOf(s);
      drawTop(s, dx, dy);
    });
    if (p > 0.95) drawLeaders(ctx, cx, cy, R0, squash, data, colors, total, t, W, H, false, full);
    if (kind === "donut" && m < 0.5) {
      ctx.save();
      ctx.globalAlpha = clamp01(1 - m * 2);
      ctx.fillStyle = t.ink;
      ctx.font = font(t, 700, 16, true);
      ctx.textAlign = "center";
      ctx.fillText(String(total), cx, cy + 5);
      ctx.restore();
      ctx.textAlign = "left";
    }
  }
  function legendLayout(meas, items, W) {
    const padX = 14, gap = 18, dot = 13, rowH = 17;
    const rows = [];
    let x = padX, row = 0;
    items.forEach((it) => {
      const w = dot + meas(it.label);
      if (x + w > W - padX && x > padX) {
        x = padX;
        row++;
      }
      rows.push({ x, y: row * rowH, it });
      x += w + gap;
    });
    return { rows, height: items.length ? (row + 1) * rowH + 12 : 6 };
  }
  function scratchCtx() {
    return document.createElement("canvas").getContext("2d");
  }
  function drawComposition(ctx, title, chartW, chartH, legend, paintFn, t, lay, headH) {
    if (title) {
      ctx.fillStyle = "#1c2620";
      let fs = 15;
      ctx.font = font(t, 700, fs, true);
      while (fs > 11 && measureW(ctx, title) > chartW - 24) {
        fs -= 1;
        ctx.font = font(t, 700, fs, true);
      }
      ctx.textAlign = "left";
      ctx.fillText(fitCtx(ctx, title, chartW - 24), 12, 22);
    }
    ctx.save();
    ctx.translate(0, headH);
    paintFn(ctx);
    ctx.restore();
    ctx.font = font(t, 600, 10.5);
    lay.rows.forEach(({ x, y, it }) => {
      const yy = headH + chartH + 14 + y;
      ctx.fillStyle = it.color;
      ctx.beginPath();
      ctx.arc(x, yy - 3, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#39443d";
      ctx.textAlign = "left";
      ctx.fillText(it.label, x + 9, yy);
    });
  }
  function composeSvg(title, chartW, chartH, legend, paintFn, t = themeColors(true), fontCss = "") {
    const sc = scratchCtx();
    sc.font = font(t, 600, 10.5);
    const lay = legendLayout((s) => measureW(sc, s), legend, chartW);
    const headH = title ? 34 : 10;
    const rec = new SvgCtx(chartW, headH + chartH + lay.height);
    rec.fontCss = fontCss;
    drawComposition(rec, title, chartW, chartH, legend, paintFn, t, lay, headH);
    return rec.toString();
  }
  function setShadow(ctx, x, y, blur, color) {
    ctx.shadowOffsetX = x;
    ctx.shadowOffsetY = y;
    ctx.shadowBlur = blur;
    ctx.shadowColor = color;
  }
  function noShadow(ctx) {
    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    ctx.shadowColor = "rgba(0,0,0,0)";
  }

  // scripts/chart-test-entry.ts
  Object.assign(window, { chartTests: { paintChart, themeColors, sankeyLayout, PALETTE, radialOffset, distinctLineColor, composeSvg } });
})();
/*! Bundled license information:

react/cjs/react.production.js:
  (**
   * @license React
   * react.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.js:
  (**
   * @license React
   * react-dom.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
