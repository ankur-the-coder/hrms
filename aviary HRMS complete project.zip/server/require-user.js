import supabase from '../api/db-client.js';

export async function requireUser(req, res) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (!token) { res.status(401).json({ error: 'Please sign in to continue.' }); return null; }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) { res.status(401).json({ error: 'Your session has expired. Please sign in again.' }); return null; }
  return user;
}
