import { paintChart, themeColors, sankeyLayout, PALETTE, composeSvg } from '../src/shared/Charts';
import { radialOffset, distinctLineColor } from '../src/shared/chartGeometry';
Object.assign(window, { chartTests: { paintChart, themeColors, sankeyLayout, PALETTE, radialOffset, distinctLineColor, composeSvg } });
