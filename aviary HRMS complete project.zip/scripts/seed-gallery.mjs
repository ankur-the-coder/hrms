import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import sb from '../api/db-client.js';

// Migrate the original archive's chart fixtures into persistent datasets.
const source = fs.readFileSync('/tmp/hrms-original/src/pages/Playground.tsx', 'utf8');
const tree = ts.createSourceFile('Playground.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
let qa;
function locate(node) {
  if (ts.isVariableDeclaration(node) && node.name.getText(tree) === 'qa') qa = node.initializer.getText(tree);
  ts.forEachChild(node, locate);
}
locate(tree);
const run = expression => vm.runInNewContext(ts.transpile(`(${expression})`, { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS }), { qa: vm.runInNewContext(qa) });
const rows = [];
function visit(node) {
  if (ts.isJsxSelfClosingElement(node) && node.tagName.getText(tree) === 'Chart') {
    const payload = {};
    for (const attr of node.attributes.properties) {
      if (!ts.isJsxAttribute(attr) || !attr.initializer) continue;
      const key = attr.name.getText(tree), init = attr.initializer;
      if (key === 'loading') continue;
      try {
        if (ts.isStringLiteral(init)) payload[key] = init.text;
        else if (ts.isJsxExpression(init) && init.expression) payload[key] = run(init.expression.getText(tree));
      } catch { }
    }
    if (payload.title?.startsWith('QA ·') || payload.title?.startsWith('Hiring pipeline')) {
      rows.push({ name: payload.title.startsWith('Hiring') ? 'pipeline' : payload.title, payload });
    }
  }
  ts.forEachChild(node, visit);
}
visit(tree);
const { count } = await sb.from('hrms_chart_datasets').select('id', { count: 'exact', head: true });
if (!count) {
  const { error } = await sb.from('hrms_chart_datasets').insert(rows).select();
  if (error) throw error;
}
console.log(`Chart gallery: ${count || rows.length} persistent datasets`);
