// One-shot realistic seed for the Aviary preview database.
// Reads Supabase credentials from .env (never printed). Idempotent-ish: skips
// volume tables that already contain rows.
import sb from '../api/db-client.js';

/* deterministic PRNG so re-runs produce the same roster */
let seed = 20260901;
const rnd = () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };
const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
const weighted = (pairs) => { const t = pairs.reduce((s, [, w]) => s + w, 0); let r = rnd() * t; for (const [v, w] of pairs) { r -= w; if (r <= 0) return v; } return pairs[pairs.length - 1][0]; };
const iso = (d) => d.toISOString().slice(0, 10);
const daysAgo = (n) => { const d = new Date(); d.setUTCHours(0, 0, 0, 0); d.setUTCDate(d.getUTCDate() - n); return d; };

const { data: tenant, error: tErr } = await sb.from('hrms_tenants').select('*').eq('slug', 'aviary').maybeSingle();
if (tErr) throw tErr;
if (!tenant) throw new Error('Tenant "aviary" missing — insert hrms_tenants first.');
const tenant_id = tenant.id;

/* ---------------- reference data (must match hrms_* structure rows) ---------------- */
const DEPTS = [
  { name: 'Engineering', roles: ['Software Engineer', 'Senior Software Engineer', 'Staff Engineer', 'Engineering Manager', 'QA Engineer', 'DevOps Engineer', 'Data Engineer'], w: 34 },
  { name: 'Product', roles: ['Product Manager', 'Senior Product Manager', 'Product Analyst'], w: 7 },
  { name: 'Design', roles: ['Product Designer', 'UX Researcher', 'Visual Designer'], w: 7 },
  { name: 'Sales', roles: ['Account Executive', 'Sales Development Rep', 'Regional Sales Manager', 'Solutions Consultant'], w: 14 },
  { name: 'Marketing', roles: ['Content Marketer', 'Growth Marketer', 'Brand Manager', 'Marketing Analyst'], w: 8 },
  { name: 'Customer Success', roles: ['Customer Success Manager', 'Support Specialist', 'Implementation Lead'], w: 10 },
  { name: 'Human Resources', roles: ['HR Business Partner', 'Talent Acquisition Specialist', 'People Operations Analyst', 'L&D Specialist'], w: 6 },
  { name: 'Finance', roles: ['Financial Analyst', 'Accountant', 'Payroll Specialist', 'FP&A Manager'], w: 6 },
  { name: 'Operations', roles: ['Operations Manager', 'Office Manager', 'Procurement Specialist'], w: 5 },
  { name: 'Legal & Compliance', roles: ['Legal Counsel', 'Compliance Analyst'], w: 3 },
];
const LOCATIONS = [
  { name: 'Bengaluru HQ', country: 'India', le: 'Aviary Technologies Pvt Ltd', w: 40 },
  { name: 'Mumbai', country: 'India', le: 'Aviary Technologies Pvt Ltd', w: 14 },
  { name: 'Hyderabad', country: 'India', le: 'Aviary Technologies Pvt Ltd', w: 12 },
  { name: 'Pune', country: 'India', le: 'Aviary Technologies Pvt Ltd', w: 8 },
  { name: 'London', country: 'United Kingdom', le: 'Aviary Technologies UK Ltd', w: 10 },
  { name: 'Singapore', country: 'Singapore', le: 'Aviary Technologies Pte Ltd', w: 7 },
  { name: 'Dubai', country: 'UAE', le: 'Aviary Technologies FZ-LLC', w: 5 },
  { name: 'Remote', country: 'Remote', le: 'Aviary Technologies Pvt Ltd', w: 4 },
];
const BU_OF = { Engineering: 'Platform & Product', Product: 'Platform & Product', Design: 'Platform & Product', Sales: 'Go-to-Market', Marketing: 'Go-to-Market', 'Customer Success': 'Go-to-Market', 'Human Resources': 'Corporate Services', Finance: 'Corporate Services', Operations: 'Corporate Services', 'Legal & Compliance': 'Corporate Services' };
const CC_OF = { Engineering: 'CC-100', Product: 'CC-110', Design: 'CC-120', Sales: 'CC-200', Marketing: 'CC-210', 'Customer Success': 'CC-220', 'Human Resources': 'CC-300', Finance: 'CC-310', Operations: 'CC-320', 'Legal & Compliance': 'CC-330' };

const FIRST_F = ['Ananya', 'Priya', 'Sneha', 'Kavya', 'Meera', 'Divya', 'Ishita', 'Riya', 'Aishwarya', 'Nandini', 'Pooja', 'Shreya', 'Tanvi', 'Neha', 'Aditi', 'Sanya', 'Lakshmi', 'Deepika', 'Radhika', 'Swati', 'Emily', 'Charlotte', 'Sophie', 'Amelia', 'Grace', 'Hannah', 'Mei Ling', 'Wei', 'Fatima', 'Layla', 'Zara', 'Noor', 'Anahit', 'Lusine', 'Mariam', 'Isabella', 'Chloe', 'Olivia'];
const FIRST_M = ['Arjun', 'Rahul', 'Vikram', 'Rohan', 'Aditya', 'Karthik', 'Siddharth', 'Nikhil', 'Varun', 'Aman', 'Manish', 'Pranav', 'Rajesh', 'Suresh', 'Harsh', 'Kunal', 'Sameer', 'Dev', 'Yash', 'Akash', 'Oliver', 'James', 'Thomas', 'Harry', 'George', 'Daniel', 'Jun Wei', 'Kai', 'Omar', 'Yusuf', 'Hamza', 'Ali', 'Armen', 'Tigran', 'Davit', 'Lucas', 'Ethan', 'Noah'];
const LAST_IN = ['Sharma', 'Rao', 'Mehta', 'Iyer', 'Nair', 'Patel', 'Reddy', 'Gupta', 'Kulkarni', 'Menon', 'Verma', 'Singh', 'Joshi', 'Desai', 'Bose', 'Chatterjee', 'Kapoor', 'Pillai', 'Banerjee', 'Malhotra', 'Bhatt', 'Saxena', 'Choudhury', 'Agarwal'];
const LAST_UK = ['Bennett', 'Hughes', 'Walker', 'Wright', 'Turner', 'Clarke', 'Morgan', 'Cooper'];
const LAST_SG = ['Tan', 'Lim', 'Lee', 'Ng', 'Wong', 'Goh'];
const LAST_AE = ['Al-Farsi', 'Haddad', 'Rahman', 'Khan', 'Siddiqui'];
const LAST_AM = ['Petrosyan', 'Hakobyan', 'Sargsyan'];
const LAST_AW = ['Croes', 'Werleman', 'Tromp'];

function personFor(i) {
  const dept = weighted(DEPTS.map((d) => [d, d.w]));
  const loc = weighted(LOCATIONS.map((l) => [l, l.w]));
  const gender = weighted([['Female', 42], ['Male', 53], ['Non-binary', 2], ['Prefer not to respond', 2], ['Transgender', 1]]);
  const nationality = weighted(loc.country === 'India' ? [['India', 94], ['United Kingdom', 2], ['Armenia', 2], ['Aruba', 1], ['Not Specified', 1]]
    : loc.country === 'United Kingdom' ? [['United Kingdom', 70], ['India', 25], ['Armenia', 5]]
    : loc.country === 'Singapore' ? [['India', 55], ['Not Specified', 25], ['United Kingdom', 20]]
    : loc.country === 'UAE' ? [['India', 65], ['Not Specified', 25], ['United Kingdom', 10]] : [['India', 70], ['United Kingdom', 15], ['Aruba', 10], ['Armenia', 5]]);
  const lastPool = nationality === 'United Kingdom' ? LAST_UK : nationality === 'Armenia' ? LAST_AM : nationality === 'Aruba' ? LAST_AW : loc.country === 'Singapore' && nationality !== 'India' ? LAST_SG : loc.country === 'UAE' && nationality !== 'India' ? LAST_AE : LAST_IN;
  const first = gender === 'Female' ? pick(FIRST_F) : gender === 'Male' ? pick(FIRST_M) : pick([...FIRST_F, ...FIRST_M]);
  const last = pick(lastPool);
  const full_name = `${first} ${last}`;
  const email = `${first.toLowerCase().replace(/[^a-z]/g, '')}.${last.toLowerCase().replace(/[^a-z]/g, '')}${i}@aviary.io`;
  const worker_type = weighted([['Permanent', 86], ['Contingent', 14]]);
  const employment_type = worker_type === 'Contingent' ? weighted([['Part Time', 45], ['Full Time', 45], ['None', 10]]) : weighted([['Full Time', 93], ['Part Time', 7]]);
  const role = pick(dept.roles);

  // joins spread over the last ~9 years, heavier on recent years
  const joinDays = Math.floor(Math.pow(rnd(), 1.6) * 9 * 365);
  const joined = daysAgo(joinDays);

  // status
  let status = 'Active', exit_date = null, exit_reason = null, exit_type = null;
  const r = rnd();
  if (joinDays <= 30 && r < 0.75) status = 'Onboarding';
  else if (joinDays <= 120 && r < 0.6) status = 'Probation';
  else if (joinDays > 200 && r < 0.17) {
    status = 'Exited';
    const exitAgo = Math.floor(rnd() * Math.min(joinDays - 60, 540));
    exit_date = iso(daysAgo(exitAgo));
    exit_type = weighted([['Voluntary', 62], ['Involuntary', 20], ['Contract End', 12], ['Retirement', 6]]);
    exit_reason = exit_type === 'Retirement' ? 'Retirement' : exit_type === 'Contract End' ? 'Contract completed' : exit_type === 'Involuntary' ? pick(['Performance', 'Restructuring', 'Policy violation']) : pick(['Better opportunity', 'Relocation', 'Higher education', 'Personal reasons', 'Compensation', 'Career change']);
  }

  const age = Math.round(22 + Math.pow(rnd(), 1.3) * 36);
  const dob = new Date(Date.UTC(new Date().getUTCFullYear() - age, Math.floor(rnd() * 12), 1 + Math.floor(rnd() * 28)));
  const seniority = /Senior|Staff|Manager|Lead|Counsel|Head/.test(role) ? 1.7 : 1;
  const base = loc.country === 'India' ? 900000 : loc.country === 'United Kingdom' ? 5200000 : loc.country === 'Singapore' ? 5600000 : loc.country === 'UAE' ? 4300000 : 1400000;
  const salary = Math.round((base * seniority * (0.8 + rnd() * 0.7)) / 10000) * 10000;

  return {
    tenant_id, full_name, email, gender, dept: dept.name, role, status, location: loc.name, employment_type, worker_type, nationality,
    business_unit: BU_OF[dept.name], cost_center: CC_OF[dept.name], legal_entity: loc.le,
    joined: iso(joined), exit_date, exit_reason, exit_type, dob: iso(dob), salary,
  };
}

/* ---------------- people ---------------- */
const { count: peopleCount } = await sb.from('hrms_people').select('id', { count: 'exact', head: true });
if (!peopleCount) {
  const people = Array.from({ length: 168 }, (_, i) => personFor(i + 1));
  // guarantee dashboard richness: birthdays + anniversaries this month, recent joins/exits
  const now = new Date(); const m = now.getUTCMonth();
  people.slice(0, 6).forEach((p, k) => { if (p.status !== 'Exited') p.dob = iso(new Date(Date.UTC(now.getUTCFullYear() - 28 - k, m, 3 + k * 4))); });
  people.slice(6, 10).forEach((p, k) => { if (p.status !== 'Exited') p.joined = iso(new Date(Date.UTC(now.getUTCFullYear() - 1 - k, m, 2 + k * 6))); });
  people.slice(10, 15).forEach((p, k) => { p.status = k < 3 ? 'Onboarding' : 'Probation'; p.joined = iso(daysAgo(k < 3 ? 2 + k * 7 : 40 + k * 15)); p.exit_date = null; p.exit_reason = null; p.exit_type = null; });
  people.slice(15, 18).forEach((p, k) => { p.status = 'Exited'; p.joined = iso(daysAgo(700 + k * 100)); p.exit_date = iso(daysAgo(4 + k * 8)); p.exit_type = ['Voluntary', 'Involuntary', 'Contract End'][k]; p.exit_reason = ['Better opportunity', 'Restructuring', 'Contract completed'][k]; });
  for (let i = 0; i < people.length; i += 60) {
    const { error } = await sb.from('hrms_people').insert(people.slice(i, i + 60));
    if (error) throw error;
  }
  console.log(`people: inserted ${people.length}`);
} else console.log(`people: ${peopleCount} rows already present, skipped`);

/* ---------------- demo people (playground) ---------------- */
const { count: demoCount } = await sb.from('hrms_demo_people').select('id', { count: 'exact', head: true });
if (!demoCount) {
  const CITIES = ['Bengaluru', 'Mumbai', 'Hyderabad', 'Pune', 'Chennai', 'Delhi', 'London', 'Singapore'];
  const DD = ['Design', 'Engineering', 'Sales', 'Human Resources', 'Finance', 'Marketing'];
  const ROLES = { Design: ['Product Designer', 'UX Researcher'], Engineering: ['Software Engineer', 'Senior Engineer', 'QA Engineer'], Sales: ['Account Executive', 'SDR'], 'Human Resources': ['HR Partner', 'Recruiter'], Finance: ['Analyst', 'Accountant'], Marketing: ['Growth Marketer', 'Content Lead'] };
  const demo = Array.from({ length: 42 }, (_, i) => {
    const dept = pick(DD); const g = rnd() < 0.5;
    const first = g ? pick(FIRST_F) : pick(FIRST_M);
    return {
      tenant_id, full_name: `${first} ${pick(LAST_IN)}`, dept, role: pick(ROLES[dept]),
      status: weighted([['Active', 70], ['On Leave', 10], ['Contract', 12], ['Inactive', 8]]),
      city: pick(CITIES), joined: iso(daysAgo(Math.floor(rnd() * 1800))), salary: Math.round((600000 + rnd() * 2400000) / 10000) * 10000,
    };
  });
  const { error } = await sb.from('hrms_demo_people').insert(demo);
  if (error) throw error;
  console.log(`demo_people: inserted ${demo.length}`);
} else console.log(`demo_people: ${demoCount} rows already present, skipped`);

/* ---------------- audit events (last 45 days) ---------------- */
const { count: auditCount } = await sb.from('hrms_audit_events').select('id', { count: 'exact', head: true });
if (!auditCount) {
  const ACTORS = ['Ananya Rao', 'Vikram Mehta', 'Priya Sharma', 'Rahul Iyer', 'Admin', 'Meera Nair', 'Arjun Patel', 'Sneha Kulkarni', 'Oliver Bennett', 'Fatima Khan'];
  const TEMPLATES = [
    { category: 'Auth', sub_category: 'Session', attribute: 'Login', event: 'Login', detail: (a) => `${a} signed in via password`, w: 46 },
    { category: 'Auth', sub_category: 'Session', attribute: 'Login', event: 'Login', detail: (a) => `${a} signed in via Google`, w: 18 },
    { category: 'Auth', sub_category: 'Session', attribute: 'Logout', event: 'Logout', detail: (a) => `${a} signed out`, w: 14 },
    { category: 'Auth', sub_category: 'Security', attribute: 'Password', event: 'Failed Login', detail: (a) => `Failed login attempt for ${a}`, w: 4 },
    { category: 'Employee', sub_category: 'Profile', attribute: 'Personal Details', event: 'Updated', detail: (a) => `${a} updated phone number`, w: 8 },
    { category: 'Employee', sub_category: 'Profile', attribute: 'Address', event: 'Updated', detail: (a) => `${a} changed residential address`, w: 4 },
    { category: 'Employee', sub_category: 'Job', attribute: 'Department', event: 'Transferred', detail: (a) => `${a} moved to a new department`, w: 3 },
    { category: 'Employee', sub_category: 'Documents', attribute: 'ID Proof', event: 'Uploaded', detail: (a) => `${a} uploaded a government ID`, w: 5 },
    { category: 'Org', sub_category: 'Structure', attribute: 'departments', event: 'Created', detail: () => 'department "Data Platform" created', w: 2 },
    { category: 'Org', sub_category: 'Structure', attribute: 'locations', event: 'Updated', detail: () => 'location "Pune" address updated', w: 2 },
    { category: 'Org', sub_category: 'Structure', attribute: 'dept', event: 'Bulk Assign', detail: () => '12 employees assigned to Engineering', w: 2 },
    { category: 'Payroll', sub_category: 'Run', attribute: 'Monthly Payroll', event: 'Processed', detail: () => 'August payroll processed for 150 employees', w: 2 },
    { category: 'Payroll', sub_category: 'Configuration', attribute: 'Bank Account', event: 'Verified', detail: () => 'Salary disbursal account verified', w: 1 },
    { category: 'Settings', sub_category: 'Preferences', attribute: 'Theme', event: 'Changed', detail: (a) => `${a} switched theme`, w: 4 },
    { category: 'Reports', sub_category: 'Export', attribute: 'Employee Master', event: 'Exported', detail: (a) => `${a} exported Employee Master (Excel)`, w: 3 },
  ];
  const events = [];
  for (let d = 44; d >= 0; d--) {
    const isWeekend = [0, 6].includes(daysAgo(d).getUTCDay());
    const n = isWeekend ? 2 + Math.floor(rnd() * 3) : 7 + Math.floor(rnd() * 8);
    for (let k = 0; k < n; k++) {
      const t = weighted(TEMPLATES.map((x) => [x, x.w]));
      const actor = pick(ACTORS);
      const at = daysAgo(d); at.setUTCHours(3 + Math.floor(rnd() * 12), Math.floor(rnd() * 60), Math.floor(rnd() * 60));
      events.push({ tenant_id, actor, category: t.category, sub_category: t.sub_category, attribute: t.attribute, event: t.event, detail: t.detail(actor), created_at: at.toISOString() });
    }
  }
  for (let i = 0; i < events.length; i += 150) {
    const { error } = await sb.from('hrms_audit_events').insert(events.slice(i, i + 150));
    if (error) throw error;
  }
  console.log(`audit_events: inserted ${events.length}`);
} else console.log(`audit_events: ${auditCount} rows already present, skipped`);

console.log('seed complete');
