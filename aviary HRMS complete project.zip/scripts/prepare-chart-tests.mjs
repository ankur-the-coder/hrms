import { build } from 'esbuild';
import { mkdirSync, writeFileSync } from 'node:fs';
import sb from '../api/db-client.js';
mkdirSync('qa', { recursive: true });
await build({
  entryPoints: ['scripts/chart-test-entry.ts'], bundle: true, format: 'iife', outfile: 'qa/chart-test.js',
  loader: { '.css': 'empty' }, define: { 'process.env.NODE_ENV': '"production"' },
  plugins: [{ name: 'test-fonts', setup(b) {
    b.onResolve({ filter: /(?:\.\/|\.\.\/)fonts$|theme\/fonts$/ }, () => ({ path: 'fonts', namespace: 'test' }));
    b.onLoad({ filter: /.*/, namespace: 'test' }, () => ({ contents: 'export const FONT_LIBRARY = []; export const fontFaceCss = async () => ""; export const fontStack = () => "sans-serif"; export const loadFont = () => {};', loader: 'js' }));
  } }],
});
const { data, error } = await sb.from('hrms_chart_datasets').select('*').order('id');
if (error) throw error;
writeFileSync('qa/chart-data.json', JSON.stringify(data));
