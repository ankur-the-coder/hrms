"""Restore the supplied source archive without replacing deployment credentials or DB resilience."""
from pathlib import Path
import shutil

source = Path('/tmp/hrms-original')
root = Path.cwd()
protected = {'.env', 'vercel.json', 'api/db-client.js', 'api/db-wake.js'}
for directory in ('src', 'api', 'public', 'scripts'):
    for file in (source / directory).rglob('*'):
        if not file.is_file():
            continue
        relative = file.relative_to(source)
        if str(relative) in protected:
            continue
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file, target)
for name in ('package.json', 'package-lock.json', 'tsconfig.json', 'tsconfig.app.json', 'tsconfig.node.json', 'vite.config.ts', 'index.html'):
    shutil.copy2(source / name, root / name)
(root / 'reference').mkdir(exist_ok=True)
shutil.copy2('/tmp/date-range-reference.html', root / 'reference/date-range-picker.html')
print('Restored supplied React application; deployment environment and DB client preserved.')
