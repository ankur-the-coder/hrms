import json, subprocess, threading, mimetypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlsplit, parse_qsl
from pathlib import Path
from playwright.sync_api import sync_playwright

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self): self.handle_request()
    def do_POST(self): self.handle_request()
    def do_PUT(self): self.handle_request()
    def do_DELETE(self): self.handle_request()
    def handle_request(self):
        u=urlsplit(self.path)
        if u.path.startswith('/api/'):
            body=self.rfile.read(int(self.headers.get('Content-Length',0)))
            req={'route':u.path[5:],'method':self.command,'query':dict(parse_qsl(u.query)),'body':json.loads(body) if body else {},'headers':{k.lower():v for k,v in self.headers.items()}}
            r=subprocess.run(['node','--env-file=.env','scripts/invoke-api.mjs'],input=json.dumps(req),text=True,capture_output=True,timeout=35)
            try: result=json.loads(r.stdout.strip().splitlines()[-1])
            except: result={'code':500,'data':{'error':r.stderr}}
            content=json.dumps(result['data']).encode();self.send_response(result['code']);self.send_header('Content-Type','application/json')
        else:
            file=Path('dist')/u.path.lstrip('/')
            if not file.is_file(): file=Path('dist/index.html')
            content=file.read_bytes();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(file)[0] or 'application/octet-stream')
        self.end_headers()
        try: self.wfile.write(content)
        except BrokenPipeError: pass

server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base=f'http://127.0.0.1:{server.server_port}'
try:
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1440,'height':1000})
        errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
        page.goto(base+'/login');page.locator('button[type=submit]:visible').click()
        page.wait_for_url('**/home',timeout=45000)
        page.wait_for_timeout(1800)
        print('PASS: email login and profile bootstrap')
        page.goto(base+'/playground')
        page.get_by_text('Design system playground',exact=True).wait_for(timeout=45000)
        page.get_by_text('QA · Polar (2D)',exact=True).wait_for(timeout=45000)
        page.wait_for_timeout(2000)
        page.screenshot(path='qa/playground-desktop.png',full_page=False)
        print('PASS: database roster and chart gallery loaded')
        page.add_script_tag(path='qa/chart-test.js')
        links=json.loads(Path('qa/chart-data.json').read_text())
        links=next(r['payload']['links'] for r in links if r['payload']['defaultKind']=='sankey')
        sk=page.locator('text=QA · Sankey · hiring funnel by source').first.locator('xpath=ancestor::div[contains(@class,"tk-card")][1]')
        sk.scroll_into_view_if_needed();page.wait_for_timeout(600)
        # ensure the chart toolbar is in view
        sk_box=sk.bounding_box()
        cv=sk.locator('canvas').first
        flat=cv.evaluate('(e)=>e.toDataURL()')
        # 3D toggle should not be present (Sankey 3D mode is opt-in via the canvas dim button)
        dim_btn=sk.locator('button').filter(has_text='3D').first
        has_3d_toggle=dim_btn.count()>0
        if has_3d_toggle:
            dim_btn.scroll_into_view_if_needed();dim_btn.click();page.mouse.move(2,2);page.wait_for_timeout(900)
        solid=cv.evaluate('(e)=>e.toDataURL()');assert flat!=solid,'Sankey 2D/3D toggle missing'
        cv_box=cv.bounding_box()
        ribbon_pt=page.evaluate('''(args)=>{try{const l=chartTests.sankeyLayout(args.links,args.w,args.h,150,1);if(!l||!l.flows||!l.flows.length)return {reason:'empty',dim:args.w+'x'+args.h,links:args.links.length,raw:JSON.stringify(args.links).slice(0,160)};const f=l.flows[0];const cx=(l.nodes[f.si].x+l.nodeW+l.nodes[f.ti].x)/2;const cy=(f.sy0+f.sy1+f.ty0+f.ty1)/4;return {x:cx,y:cy};}catch(e){return {reason:String(e),dim:args.w+'x'+args.h}}}''',{'links':links,'w':cv_box['width'],'h':cv_box['height']})
        if not ribbon_pt or 'x' not in ribbon_pt:
            print('SANKEY-PROBE:',ribbon_pt)
        assert ribbon_pt is not None,'Sankey layout returned no flows'
        page.mouse.move(cv_box['x']+ribbon_pt['x'],cv_box['y']+ribbon_pt['y']);page.wait_for_timeout(500)
        hover=cv.evaluate('(e)=>e.toDataURL()');assert hover!=solid,'Sankey ribbon hover missing'
        tip_text=sk.locator('div.tk-pop').inner_text();assert '→' in tip_text,tip_text
        page.mouse.move(2,2);page.wait_for_timeout(700)
        reset=cv.evaluate('(e)=>e.toDataURL()');assert reset==solid,'Sankey hover animation did not reset smoothly'
        print('PASS: actual Sankey 3D toggle, ribbon hit testing, hover animation and smooth reset')
        page.get_by_text('Pick a range',exact=True).click()
        page.locator('button[aria-label="2026-09-07"]').click()
        page.locator('button[aria-label="2026-09-18"]').click()
        page.mouse.move(10,10)
        assert page.locator('.cal-badge').count()==2
        assert page.locator('.cal-day.in-trench').count()==12
        page.screenshot(path='qa/date-range-desktop.png',full_page=False)
        page.get_by_role('button',name='Submit',exact=True).click()
        assert page.get_by_text('7 Sept 26 → 18 Sept 26',exact=True).count() or page.locator('body').inner_text().find('18 Sept')>=0
        print('PASS: date range endpoints, continuous selection, submit')
        page.get_by_text('Pick month range',exact=True).click()
        page.locator('button[aria-label="2026-03"]').click()
        page.locator('button[aria-label="2026-08"]').click()
        ratios=page.locator('.cal-day.sq').evaluate_all('(els)=>els.map(e=>{const r=e.getBoundingClientRect();return r.width/r.height})')
        assert all(abs(v-4/3)<0.015 for v in ratios),ratios
        page.screenshot(path='qa/month-range-desktop.png',full_page=False)
        page.get_by_role('button',name='Submit',exact=True).click()
        print('PASS: month range selection and exact 4:3 button aspect ratio')
        page.get_by_text('Pick a month',exact=True).click()
        page.locator('button[aria-label="2026-09"]').click()
        assert page.get_by_text('September 2026',exact=True).count()>0
        print('PASS: single month picker')
        page.set_viewport_size({'width':375,'height':812})
        page.get_by_text('7 Sept 26 → 18 Sept 26',exact=True).click()
        page.wait_for_timeout(500)
        page.screenshot(path='qa/date-range-mobile.png')
        cells=page.locator('.cal-day').evaluate_all('(els)=>els.map(e=>{const r=e.getBoundingClientRect();return {left:r.left,right:r.right}})')
        assert all(c['left']>=0 and c['right']<=375 for c in cells), 'cal-day outside mobile viewport'
        print('PASS: mobile picker fits 375px viewport')
        assert not errors,errors
        print('PASS: no browser runtime errors')
        browser.close()
finally:
    server.shutdown();server.server_close()
