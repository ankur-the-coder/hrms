import assert from 'node:assert/strict';
import sb from '../api/db-client.js';
import bootstrap from '../api/bootstrap.js';
import org from '../api/organization.js';
import structure from '../api/orgstructure.js';
import demo from '../api/demo-data.js';
import studio from '../api/studio.js';
import charts from '../api/chart-data.js';

const { data: { session }, error } = await sb.auth.signInWithPassword({ email: 'demo@example.com', password: 'password123' });
assert.ifError(error);
async function call(handler, method = 'GET', body = {}, query = {}, authorized = true) {
  let status = 200, result;
  const req = { method, body, query, headers: authorized ? { authorization: `Bearer ${session.access_token}` } : {} };
  const res = { setHeader() {}, status(code) { status = code; return this; }, json(value) { result = value; return this; }, end() { return this; } };
  await handler(req, res);
  return { status, data: result };
}
for (const route of [bootstrap, org, structure, demo, studio, charts]) assert.equal((await call(route, 'GET', {}, {}, false)).status, 401);
let result = await call(bootstrap);
assert.equal(result.status, 200); assert.equal(result.data.email, 'demo@example.com');
const profile = result.data;
result = await call(bootstrap, 'PUT', { id: profile.id, prefs: profile.prefs }); assert.equal(result.status, 200);
result = await call(org, 'GET', {}, { resource: 'people' }); assert.equal(result.status, 200); assert.equal(result.data.length, 168);
result = await call(org, 'GET', {}, { resource: 'audit' }); assert.equal(result.status, 200); assert.ok(result.data.length > 0);
result = await call(structure); assert.equal(result.status, 200); assert.equal(Object.keys(result.data).length, 7);
for (const resource of Object.keys(result.data)) {
  const created = await call(structure, 'POST', { resource, action: 'create', data: { name: 'Verification record', description: undefined } });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  const id = created.data.id;
  assert.equal((await call(structure, 'POST', { resource, action: 'update', id, data: { name: 'Verification updated' } })).status, 200);
  assert.equal((await call(structure, 'POST', { resource, action: 'delete', id })).status, 200);
}
result = await call(demo); assert.equal(result.status, 200); assert.equal(result.data.length, 42);
const person = result.data[0];
assert.equal((await call(demo, 'PUT', { ids: [person.id], patch: { status: 'On Leave' } })).status, 200);
assert.equal((await call(demo, 'PUT', { ids: [person.id], patch: { status: person.status } })).status, 200);
for (const kind of ['document', 'idcard', 'email']) {
  const created = await call(studio, 'POST', { kind, name: 'Verification asset', payload: { test: true } });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  assert.equal((await call(studio, 'PUT', { id: created.data.id, name: 'Updated verification' })).status, 200);
  assert.equal((await call(studio, 'DELETE', { id: created.data.id })).status, 200);
}
result = await call(charts); assert.equal(result.status, 200); assert.ok(result.data.length >= 13);
console.log('PASS: authenticated APIs, profile preferences, 168-person roster, audit, all seven organization CRUD resources, employee updates, all three studio asset CRUD kinds, and persistent chart datasets.');
await sb.auth.signOut();
