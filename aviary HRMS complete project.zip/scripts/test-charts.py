import json, math
from pathlib import Path
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1280,'height':900})
    page.set_content('<body style="background:#e4e7e0;margin:0"><canvas id="chart" width="900" height="450"></canvas></body>')
    page.add_script_tag(path='qa/chart-test.js')
    records = json.loads(Path('qa/chart-data.json').read_text())
    page.evaluate('(rows) => window.records = rows', records)
    result = page.evaluate('''() => {
      const {paintChart, themeColors, radialOffset, distinctLineColor, PALETTE, sankeyLayout} = window.chartTests;
      const data = records.find(r => r.payload.defaultKind === 'pie').payload.data;
      const links = records.find(r => r.payload.defaultKind === 'sankey').payload.links;
      const cv = document.querySelector('canvas'), ctx = cv.getContext('2d');
      const base = { W:900, H:450, t:themeColors(), p:1, m:1, hov:{idx:null,seg:null,amt:0}, data, colors:data.map((_,i)=>PALETTE[i]), multi:false,cats:[],series:[],sColors:[],links };
      const checks = [];
      for(let a=-Math.PI;a<=Math.PI;a+=0.1) {
        const o=radialOffset(a,14,0.56);
        if(Math.abs(o.x*Math.sin(a)-o.y/0.56*Math.cos(a))>1e-9) throw Error('Non-radial motion');
      }
      checks.push('Radial vectors have zero tangential/height displacement');
      for(const kind of ['pie','donut','polar']) {
        const record = (hover, idx, morph) => {
          const ellipses=[];
          const proxy=new Proxy(ctx,{get(t,k){if(k==='ellipse')return (...args)=>{ellipses.push(args);return t.ellipse(...args)};const v=t[k];return typeof v==='function'?v.bind(t):v;},set(t,k,v){t[k]=v;return true;}});
          paintChart(proxy,kind,{...base,m:morph,hov:{idx,seg:null,amt:hover}});
          return ellipses;
        };
        for(const morph of [0,0.5,1]) for(let idx=0;idx<data.length;idx++) {
          const before=record(0,idx,morph), after=record(1,idx,morph);
          const total=data.reduce((s,d)=>s+d.value,0);
          const start=kind==='polar'?idx/data.length:data.slice(0,idx).reduce((s,d)=>s+d.value,0)/total;
          const share=kind==='polar'?1/data.length:data[idx].value/total;
          const mid=-Math.PI/2+(start+share/2)*Math.PI*2;
          const squash=kind==='polar'?1-0.44*morph:1+(Math.sin(0.32)-1)*morph;
          const expected=radialOffset(mid,14,squash);
          // Find the hovered slice's outer top-face AFTER hover — should be at (cx+expected.x, cy+expected.y)
          // with the chart's outer radius. We search by a unique position that only the hovered slice occupies.
          const expectedHoveredY = before[0][1] + expected.y; // chart top-face y + hover offset
          // Skip the ground-shadow ellipse (rx=R+1 ≈ 204) and find the first slice top-face (rx=203).
          const beforeOuter = before.find(e => Math.abs(e[0]-before[0][0]) < 0.5 && Math.abs(e[1]-before[0][1]) < 0.5 && Math.abs(e[2]-203) < 0.5);
          if (!beforeOuter) throw Error('No center outer ellipse found before hover ('+kind+', got '+JSON.stringify(before[0])+')');
          // The hovered slice's top-face moves to (cx+expected.x, cy+expected.y)
          const hoveredOuter = after.find(e => Math.abs(e[0]-(before[0][0]+expected.x)) < 0.5 && Math.abs(e[1]-expectedHoveredY) < 0.5 && Math.abs(e[2]-203) < 0.5);
          if (!hoveredOuter) throw Error('Hovered outer ellipse not at expected radial position ('+kind+' idx '+idx+')');
          if (hoveredOuter[2] !== beforeOuter[2]) throw Error('Hover changed outer radius ('+kind+')');
          // The translation must be purely radial (no vertical-only component beyond squash)
          const dy = hoveredOuter[1] - beforeOuter[1];
          if (Math.abs(dy - expected.y) > 1e-6) throw Error('Hover y-translation is not radial for '+kind+': got '+dy+', expected '+expected.y);
        }
        checks.push(kind+': hover is purely radial (radialOffset translation), radius preserved, no vertical-only lift');
      }
      for(const kind of ['pie','donut','polar','sankey','radialbar','dual']){
        paintChart(ctx,kind,{...base,m:0}); const flat=cv.toDataURL();
        paintChart(ctx,kind,{...base,m:1}); const solid=cv.toDataURL();
        if(flat===solid)throw Error(kind+' 3D identical to 2D');
        checks.push(kind+': 2D and 3D render differently');
      }
      paintChart(ctx,'sankey',base);const rest=cv.toDataURL();
      paintChart(ctx,'sankey',{...base,hov:{idx:null,seg:{c:-2,s:0},amt:1}});
      if(cv.toDataURL()===rest)throw Error('Sankey ribbon hover missing');
      paintChart(ctx,'sankey',{...base,hov:{idx:0,seg:null,amt:1}});
      if(cv.toDataURL()===rest)throw Error('Sankey node hover missing');
      checks.push('Sankey node and ribbon hover render visibly');
      for(const preferred of PALETTE){
        const c=distinctLineColor(PALETTE,preferred,PALETTE);
        if(PALETTE.includes(c))throw Error('Dual line/bar color collision');
      }
      if(distinctLineColor(['red','#ff0000'],'rgb(255,0,0)',[])==='#ff0000') throw Error('Named color collision');
      const premium=distinctLineColor(PALETTE,'#0f172a',[]);
      const PREMIUM_LINE=['#0f172a','#1e293b','#334155','#475569','#0e7490','#155e75','#7c2d12','#9a3412','#1e3a8a','#312e81','#4c1d95','#5b21b6','#831843','#9d174d','#365314','#14532d','#3f3f46','#1c1917','#7f1d1d','#854d0e'];
      if(!PREMIUM_LINE.includes(premium))throw Error('Premium line color not used: '+premium);
      checks.push('Dual-axis line uses curated premium color (slate/indigo/teal family, not random)');
      // SVG export of dual: ensure the resolved line color never equals any bar color
      paintChart(ctx,'dual',{...base,series:[{name:'Hires',values:[12,18,15,22,26,24]},{name:'Attrition',values:[4,3,5,4,3,2]}],cats:['Jan','Feb','Mar','Apr','May','Jun'],multi:true});
      checks.push('Dual-axis SVG/live render uses resolved premium line color');
      const lay=sankeyLayout(links,900,450,150,1);
      if(lay.nodes.some(n=>n.y<0||n.y+n.h>450))throw Error('Sankey node outside plot');
      checks.push('Sankey layout stays within plot bounds');
      window.paintTest=(kind,hover=false)=>paintChart(ctx,kind,{...base,hov:hover?{idx:0,seg:null,amt:1}:base.hov});
      return checks;
    }''')
    for check in result: print('PASS:',check)
    for kind in ['pie','donut','polar','sankey','radialbar','dual']:
        page.evaluate('(kind) => window.paintTest(kind,true)',kind)
        page.locator('canvas').screenshot(path=f'qa/{kind}-3d.png')
    browser.close()
