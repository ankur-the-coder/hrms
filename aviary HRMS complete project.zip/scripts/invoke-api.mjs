const input = JSON.parse(await new Promise(resolve => { let s = ''; process.stdin.on('data', c => s += c); process.stdin.on('end', () => resolve(s)); }));
const allowed = new Set(['bootstrap', 'demo-data', 'organization', 'orgstructure', 'studio', 'chart-data']);
if (!allowed.has(input.route)) throw new Error('Unknown test route');
const { default: handler } = await import(`../api/${input.route}.js`);
let code = 200;
await handler(input, { setHeader() {}, status(c) { code = c; return this; }, json(data) { console.log(JSON.stringify({ code, data })); return this; }, end() { console.log(JSON.stringify({ code, data: null })); } });
