import supabase from './db-client.js';
import { requireUser } from '../server/require-user.js';

// Studio assets — saved documents, ID-card designs and email templates.
// One table, discriminated by `kind`; payload is the editor's own JSON.
const cors = (res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
};
const KINDS = new Set(['document', 'idcard', 'email']);

async function tenantId() {
  const { data } = await supabase.from('hrms_tenants').select('id').eq('slug', 'aviary').maybeSingle();
  return data?.id || null;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (!await requireUser(req, res)) return;
    if (req.method === 'GET') {
      const { kind } = req.query;
      let q = supabase.from('hrms_studio_assets').select('*').order('updated_at', { ascending: false }).limit(200);
      if (kind && KINDS.has(kind)) q = q.eq('kind', kind);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { kind, name, payload, thumbnail } = req.body || {};
      if (!KINDS.has(kind)) return res.status(400).json({ error: 'kind must be document | idcard | email' });
      if (!name || !String(name).trim()) return res.status(400).json({ error: 'name required' });
      if (JSON.stringify(payload || {}).length > 1_500_000) return res.status(400).json({ error: 'Design too large to save (max 1.5 MB). Reduce embedded image sizes.' });
      const { data, error } = await supabase
        .from('hrms_studio_assets')
        .insert({ tenant_id: await tenantId(), kind, name: String(name).trim().slice(0, 120), payload: payload || {}, thumbnail: thumbnail || null })
        .select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, name, payload, thumbnail } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      if (payload && JSON.stringify(payload).length > 1_500_000) return res.status(400).json({ error: 'Design too large to save (max 1.5 MB).' });
      const patch = { updated_at: new Date().toISOString() };
      if (name) patch.name = String(name).trim().slice(0, 120);
      if (payload) patch.payload = payload;
      if (thumbnail !== undefined) patch.thumbnail = thumbnail;
      const { data, error } = await supabase.from('hrms_studio_assets').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('hrms_studio_assets').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('studio API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
