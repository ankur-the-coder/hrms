export function radialOffset(angle: number, distance: number, verticalScale = 1) {
  return { x: Math.cos(angle) * distance, y: Math.sin(angle) * distance * verticalScale };
}

/** Premium palette tuned for dual-axis lines: distinct from the brand bar
 *  palette and hand-picked (not random) so charts look professional, never dull. */
export const PREMIUM_LINE_PALETTE = [
  '#0f172a', // slate ink
  '#1e293b', // deeper slate
  '#334155', // slate
  '#475569', // blue slate
  '#0e7490', // deep teal
  '#155e75', // dark cyan
  '#7c2d12', // burnt sienna
  '#9a3412', // warm copper
  '#1e3a8a', // deep indigo
  '#312e81', // royal indigo
  '#4c1d95', // deep purple
  '#5b21b6', // regal purple
  '#831843', // mulberry
  '#9d174d', // deep magenta
  '#365314', // forest
  '#14532d', // pine
  '#3f3f46', // graphite
  '#1c1917', // onyx
  '#7f1d1d', // oxblood
  '#854d0e', // antique gold
];

/** Pick a line color perceptually separated from every actual bar color, drawn
 *  from a curated premium palette so it never looks dull. Used for SVG export
 *  and the live dual-axis chart alike. */
export function distinctLineColor(barColors: string[], preferred: string, palette: string[]) {
  const normalize = (color: string) => color.trim().toLowerCase();
  const browserColor = (color: string) => {
    if (typeof document === 'undefined') return color;
    const ctx = document.createElement('canvas').getContext('2d');
    if (!ctx) return color;
    ctx.fillStyle = color;
    return String(ctx.fillStyle);
  };
  const channels = (color: string): number[] | null => {
    color = browserColor(color);
    const hex = normalize(color).replace('#', '');
    if (/^[0-9a-f]{3}$/.test(hex)) return hex.split('').map(c => parseInt(c + c, 16));
    if (/^[0-9a-f]{6}$/.test(hex)) return [0, 2, 4].map(i => parseInt(hex.slice(i, i + 2), 16));
    const rgb = color.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/);
    return rgb ? rgb.slice(1, 4).map(Number) : null;
  };
  const distance = (a: string, b: string) => {
    const aa = channels(a), bb = channels(b);
    if (!aa || !bb) return normalize(a) === normalize(b) ? 0 : 100;
    return Math.sqrt(aa.reduce((sum, value, i) => sum + (value - bb[i]) ** 2, 0));
  };
  const score = (color: string) => Math.min(...barColors.map(bar => distance(color, bar)), Infinity);
  if (score(preferred) > 100) return preferred;
  const candidates = [...PREMIUM_LINE_PALETTE, ...palette];
  if (candidates.every(color => score(color) === 0)) {
    for (let i = 0; i <= barColors.length; i++) candidates.push('#' + ((i * 104729) % 0xffffff).toString(16).padStart(6, '0'));
  }
  return candidates.reduce((best, candidate) => score(candidate) > score(best) ? candidate : best, preferred);
}
