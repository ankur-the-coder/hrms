import React, { useMemo } from 'react';

export interface GirlAnimRefs {
  headGroup: SVGGElement | null;
  torsoGroup: SVGGElement | null;
  pupilsGroup: SVGGElement | null;
  normalEyesGroup: SVGGElement | null;
  happyEyesGroup: SVGGElement | null;
  eyelidsGroup: SVGGElement | null;
  browsGroup: SVGGElement | null;
  cheeksGroup: SVGGElement | null;
  mouthCalm: SVGPathElement | null;
  mouthCurious: SVGPathElement | null;
  mouthHappy: SVGGElement | null;
  handL: SVGGElement | null;
  handR: SVGGElement | null;
  laptopGlow: SVGPolygonElement | null;
}

interface PaperCutGirlProps {
  animRefs: React.MutableRefObject<GirlAnimRefs>;
  onClick?: () => void;
}

// Deterministic PRNG for authentic scissor-cut paper edges
function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const q = (n: number) => Math.round(n * 10) / 10;

function polygonArea(pts: [number, number][]) {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const u = pts[i];
    const v = pts[(i + 1) % pts.length];
    a += u[0] * v[1] - v[0] * u[1];
  }
  return a;
}

function orientPts(pts: [number, number][]): [number, number][] {
  return polygonArea(pts) < 0 ? pts.slice().reverse() : pts;
}

function makeCutPath(
  rawPts: [number, number][],
  rand: () => number,
  jitter = 0.65,
  step = 6.5
): string {
  const pts = orientPts(rawPts);
  let s = '';
  const n = pts.length;
  for (let i = 0; i < n; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % n];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const L = Math.hypot(dx, dy) || 1;
    const k = Math.max(1, Math.round(L / step));
    const nx = -dy / L;
    const ny = dx / L;
    for (let t = 0; t < k; t++) {
      let x = a[0] + (dx * t) / k;
      let y = a[1] + (dy * t) / k;
      if (t > 0) {
        const o = (rand() - 0.5) * 2 * jitter;
        x += nx * o;
        y += ny * o;
      }
      s += (s ? 'L' : 'M') + q(x) + ' ' + q(y);
    }
  }
  return s + 'Z';
}

function makeEllipsePts(
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  n = 20,
  rot = 0
): [number, number][] {
  const ca = Math.cos(rot);
  const sa = Math.sin(rot);
  return Array.from({ length: n }, (_, i) => {
    const ang = (i / n) * Math.PI * 2;
    const ux = Math.cos(ang) * rx;
    const uy = Math.sin(ang) * ry;
    return [cx + ux * ca - uy * sa, cy + ux * sa + uy * ca];
  });
}

export const PaperCutGirl: React.FC<PaperCutGirlProps> = ({ animRefs, onClick }) => {
  // Precompute all scissor-cut paper polygons in the exact 377x360 coordinate space
  const paths = useMemo(() => {
    const R = mulberry32(4815);
    const cut = (pts: [number, number][], j = 0.65, st = 6.5) =>
      makeCutPath(pts, R, j, st);

    // ==================== 1. STACK OF 3 BOOKS ON THE LEFT (x: 16..126, y: 284..354) ====================
    // Bottom Book (Slate-blue spine + cream pages + warm tan bottom board)
    const bookBotCover = cut(
      [
        [18, 333],
        [124, 333],
        [126, 353],
        [17, 353],
      ],
      0.55,
      6
    );
    const bookBotSpine = cut(
      [
        [17, 333],
        [36, 333],
        [36, 353],
        [17, 353],
      ],
      0.4,
      5
    );
    const bookBotPages = cut(
      [
        [35, 336],
        [121, 336],
        [121, 349],
        [35, 349],
      ],
      0.35,
      5
    );

    // Middle Book (Deep charcoal-navy cover + cream page block)
    const bookMidCover = cut(
      [
        [20, 316],
        [122, 316],
        [123, 334],
        [19, 334],
      ],
      0.55,
      6
    );
    const bookMidPages = cut(
      [
        [26, 320],
        [116, 320],
        [116, 330],
        [26, 330],
      ],
      0.35,
      5
    );

    // Top Book (Warm brown top cover + golden-ochre spine + thick cream pages + clasp)
    const bookTopCover = cut(
      [
        [19, 286],
        [120, 286],
        [122, 297],
        [18, 297],
      ],
      0.5,
      6
    );
    const bookTopBody = cut(
      [
        [19, 295],
        [121, 295],
        [122, 317],
        [19, 317],
      ],
      0.5,
      6
    );
    const bookTopSpine = cut(
      [
        [19, 295],
        [35, 295],
        [35, 317],
        [19, 317],
      ],
      0.4,
      5
    );
    const bookTopPages = cut(
      [
        [34, 297],
        [117, 297],
        [117, 314],
        [34, 314],
      ],
      0.35,
      5
    );
    const bookClasp = cut(
      [
        [45, 304],
        [53, 304],
        [52, 316],
        [46, 316],
      ],
      0.25,
      4
    );

    // ==================== 2. CROSS-LEGGED DENIM JEANS & SHOES (x: 132..326, y: 294..354) ====================
    // Left Shoe tucked under right ankle (x: 136..178, y: 334..354)
    const shoeLBody = cut(
      [
        [136, 336],
        [174, 334],
        [178, 351],
        [134, 352],
      ],
      0.5,
      5
    );
    const shoeLSole = cut(
      [
        [133, 348],
        [179, 347],
        [178, 354],
        [133, 354],
      ],
      0.35,
      5
    );

    // Right Shoe tucked under left ankle (x: 284..326, y: 334..354)
    const shoeRBody = cut(
      [
        [284, 334],
        [322, 336],
        [325, 352],
        [282, 351],
      ],
      0.5,
      5
    );
    const shoeRSole = cut(
      [
        [281, 347],
        [326, 348],
        [325, 354],
        [281, 354],
      ],
      0.35,
      5
    );

    // Left Knee & Thigh (Denim Blue #66ABCC + Shadow #1C7792)
    const legLeft = cut(
      [
        [134, 304],
        [188, 296],
        [236, 326],
        [226, 346],
        [152, 338],
        [130, 322],
      ],
      0.65,
      6.5
    );
    const legLeftShadow = cut(
      [
        [138, 324],
        [218, 332],
        [226, 346],
        [146, 340],
      ],
      0.5,
      6
    );

    // Right Knee & Calf Crossing In Front (Denim Blue #66ABCC + Deep Teal-Blue Shadow #1B7891)
    const legRight = cut(
      [
        [222, 314],
        [286, 296],
        [322, 308],
        [326, 328],
        [298, 344],
        [188, 352],
        [178, 336],
      ],
      0.65,
      6.5
    );
    const legRightShadow = cut(
      [
        [262, 304],
        [320, 308],
        [324, 328],
        [296, 344],
        [244, 348],
        [278, 324],
      ],
      0.55,
      6
    );
    const kneeCrease = cut(
      [
        [192, 316],
        [248, 308],
        [254, 316],
        [196, 324],
      ],
      0.4,
      5
    );

    // ==================== 3. CORAL-ROSE SWEATER, COLLAR & ARMS (x: 128..308, y: 176..292) ====================
    // Sweater Shoulder & Upper Chest (above laptop)
    const sweaterTop = cut(
      [
        [156, 182],
        [280, 182],
        [302, 212],
        [298, 286],
        [136, 286],
        [134, 212],
      ],
      0.65,
      6.5
    );
    // Left & Right Sleeve Shadow Folds (#B6594C)
    const sleeveLeftShadow = cut(
      [
        [130, 214],
        [148, 212],
        [150, 286],
        [130, 282],
      ],
      0.5,
      5.5
    );
    const sleeveRightShadow = cut(
      [
        [286, 212],
        [306, 214],
        [304, 282],
        [284, 286],
      ],
      0.5,
      5.5
    );
    // Cream Peter-Pan / Crew Collar & Neck
    const collarL = cut(
      [
        [190, 177],
        [218, 182],
        [212, 193],
        [184, 186],
      ],
      0.35,
      4
    );
    const collarR = cut(
      [
        [218, 182],
        [246, 177],
        [252, 186],
        [224, 193],
      ],
      0.35,
      4
    );
    const neck = cut(
      [
        [202, 166],
        [234, 166],
        [232, 186],
        [204, 186],
      ],
      0.35,
      4
    );

    // Hands peeking near lower edges of laptop
    const handL = cut(makeEllipsePts(136, 272, 9, 7, 14, 0.2), 0.35, 4);
    const handR = cut(makeEllipsePts(298, 272, 9, 7, 14, -0.2), 0.35, 4);

    // ==================== 4. POWDER-BLUE LAPTOP ON HER LAP (x: 138..296, y: 202..298) ====================
    // Outer Laptop Lid (#C0EDFF main paper, #86D1E8 right shaded bevel)
    const laptopOuter = cut(
      [
        [138, 204],
        [294, 204],
        [284, 294],
        [148, 294],
      ],
      0.55,
      6.5
    );
    const laptopRightShade = cut(
      [
        [256, 204],
        [294, 204],
        [284, 294],
        [248, 294],
      ],
      0.5,
      6.5
    );
    const laptopTopRim = cut(
      [
        [138, 202],
        [294, 202],
        [293, 208],
        [139, 208],
      ],
      0.35,
      6
    );
    // Laptop Bottom Base / Hinge
    const laptopBase = cut(
      [
        [152, 291],
        [280, 291],
        [276, 300],
        [156, 300],
      ],
      0.45,
      5.5
    );
    // Central Emblem Circle on Laptop Lid (center at x=216, y=251 -> FX=0.574, FY=0.697)
    const laptopLogoOuter = cut(makeEllipsePts(216, 251, 13, 13, 18), 0.35, 4);
    const laptopLogoInner = cut(makeEllipsePts(216, 251, 8.5, 8.5, 16), 0.3, 3.5);

    // ==================== 5. VOLUMINOUS CHESTNUT HAIR, FACE & EARS (x: 102..332, y: 8..176) ====================
    // Back Hair Silhouette (Deep warm brown #5E281F + Chestnut #9E695C)
    const hairBackOuter = cut(
      [
        [162, 16],
        [216, 12],
        [272, 16],
        [314, 48],
        [332, 96],
        [326, 138],
        [296, 146],
        [268, 168],
        [166, 168],
        [136, 146],
        [106, 138],
        [102, 96],
        [120, 48],
      ],
      0.75,
      6.5
    );
    // Chestnut Mid-Layer Hair Waves
    const hairChestnutL = cut(
      [
        [168, 18],
        [218, 16],
        [216, 58],
        [168, 108],
        [146, 144],
        [112, 136],
        [108, 94],
        [126, 48],
      ],
      0.65,
      6
    );
    const hairChestnutR = cut(
      [
        [218, 16],
        [270, 18],
        [308, 48],
        [326, 94],
        [320, 136],
        [288, 144],
        [268, 108],
        [218, 58],
      ],
      0.65,
      6
    );
    // Warm Hair Highlight Ribbons (#B57D6E)
    const hairHighlightL = cut(
      [
        [152, 32],
        [198, 22],
        [188, 56],
        [146, 96],
        [124, 118],
        [122, 82],
      ],
      0.5,
      5.5
    );
    const hairHighlightR = cut(
      [
        [236, 22],
        [282, 32],
        [310, 82],
        [308, 118],
        [286, 96],
        [246, 56],
      ],
      0.5,
      5.5
    );

    // Left & Right Ears (#F7D2B0)
    const earL = cut(makeEllipsePts(152, 134, 11, 13, 14, -0.15), 0.35, 4);
    const earR = cut(makeEllipsePts(284, 134, 11, 13, 14, 0.15), 0.35, 4);

    // Main Face Shape (Warm Peach #FFDFC0 + Soft Chin/Cheek Contour #F5CFAF)
    const faceShadow = cut(
      [
        [158, 84],
        [218, 54],
        [278, 84],
        [278, 138],
        [254, 168],
        [218, 176],
        [182, 168],
        [158, 138],
      ],
      0.5,
      5.5
    );
    const faceMain = cut(
      [
        [160, 82],
        [218, 52],
        [276, 82],
        [275, 135],
        [252, 165],
        [218, 173],
        [184, 165],
        [161, 135],
      ],
      0.48,
      5.5
    );

    // Center-Parted Front Hair Bangs Framing Forehead
    const bangsL = cut(
      [
        [218, 46],
        [204, 72],
        [176, 98],
        [156, 122],
        [150, 92],
        [168, 56],
      ],
      0.5,
      5
    );
    const bangsR = cut(
      [
        [218, 46],
        [268, 56],
        [286, 92],
        [280, 122],
        [260, 98],
        [232, 72],
      ],
      0.5,
      5
    );

    // Cute Sculpted Paper Nose & Rosy Cheeks
    const nose = cut(
      [
        [215, 128],
        [223, 128],
        [226, 142],
        [218, 145],
        [212, 142],
      ],
      0.25,
      3.5
    );
    const cheekL = cut(makeEllipsePts(176, 142, 10.5, 6.8, 14), 0.25, 3.5);
    const cheekR = cut(makeEllipsePts(260, 142, 10.5, 6.8, 14), 0.25, 3.5);

    return {
      bookBotCover,
      bookBotSpine,
      bookBotPages,
      bookMidCover,
      bookMidPages,
      bookTopCover,
      bookTopBody,
      bookTopSpine,
      bookTopPages,
      bookClasp,
      shoeLBody,
      shoeLSole,
      shoeRBody,
      shoeRSole,
      legLeft,
      legLeftShadow,
      legRight,
      legRightShadow,
      kneeCrease,
      sweaterTop,
      sleeveLeftShadow,
      sleeveRightShadow,
      collarL,
      collarR,
      neck,
      handL,
      handR,
      laptopOuter,
      laptopRightShade,
      laptopTopRim,
      laptopBase,
      laptopLogoOuter,
      laptopLogoInner,
      hairBackOuter,
      hairChestnutL,
      hairChestnutR,
      hairHighlightL,
      hairHighlightR,
      earL,
      earR,
      faceShadow,
      faceMain,
      bangsL,
      bangsR,
      nose,
      cheekL,
      cheekR,
    };
  }, []);

  return (
    <svg
      viewBox="0 0 377 360"
      width="100%"
      height="100%"
      overflow="visible"
      onClick={onClick}
      role="img"
      aria-label="Layered paper-cut girl sitting cross-legged with a laptop beside a stack of books"
    >
      <defs>
        {/* Crisp layered paper-cut shadow and top paper edge highlight */}
        <filter id="pc-layer" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow
            dx="0"
            dy="-0.9"
            stdDeviation="0.3"
            floodColor="#fffdf6"
            floodOpacity="0.68"
          />
          <feDropShadow
            dx="1.4"
            dy="3.0"
            stdDeviation="2.0"
            floodColor="#3a2412"
            floodOpacity="0.34"
          />
        </filter>
        <filter id="pc-soft" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow
            dx="0.8"
            dy="1.8"
            stdDeviation="1.2"
            floodColor="#3a2412"
            floodOpacity="0.26"
          />
        </filter>
      </defs>

      {/* ==================== 1. STACK OF 3 PAPER-CUT BOOKS ON THE LEFT ==================== */}
      <g id="book-stack">
        {/* Bottom Book */}
        <g filter="url(#pc-layer)">
          <path fill="#9f8d75" d={paths.bookBotCover} />
          <path fill="#ded7ca" d={paths.bookBotPages} />
          <path fill="#37597a" d={paths.bookBotSpine} />
          <path
            stroke="#b8ae9c"
            strokeWidth="1"
            d="M38 340H118 M38 345H117"
          />
          <path className="grain" d={paths.bookBotCover} />
        </g>

        {/* Middle Book */}
        <g filter="url(#pc-layer)">
          <path fill="#282c31" d={paths.bookMidCover} />
          <path fill="#e3dac9" d={paths.bookMidPages} />
          <path stroke="#b8ae9c" strokeWidth="1" d="M30 325H113" />
          <path className="grain" d={paths.bookMidCover} />
        </g>

        {/* Top Book */}
        <g filter="url(#pc-layer)">
          <path fill="#663b0b" d={paths.bookTopBody} />
          <path fill="#e3d6c5" d={paths.bookTopPages} />
          <path fill="#ae8034" d={paths.bookTopSpine} />
          <path fill="#523105" d={paths.bookTopCover} />
          <path
            stroke="#c4b5a2"
            strokeWidth="1"
            d="M37 302H114 M37 307H114 M37 311H113"
          />
          <path fill="#2b2618" d={paths.bookClasp} />
          <path className="grain" d={paths.bookTopBody} />
        </g>
      </g>

      {/* ==================== 2. GIRL BODY, JEANS, SWEATER, HEAD & LAPTOP ==================== */}
      <g
        ref={(el) => {
          animRefs.current.torsoGroup = el;
        }}
        style={{ transformOrigin: '218px 310px' }}
      >
        {/* Coral-Rose Sweater & Sleeves */}
        <g filter="url(#pc-layer)">
          <path fill="#e8a493" d={paths.sweaterTop} />
          <path fill="#b6594c" d={paths.sleeveLeftShadow} />
          <path fill="#b6594c" d={paths.sleeveRightShadow} />
          <path fill="#f7d2b0" d={paths.neck} />
          <path fill="#fffbe6" d={paths.collarL} />
          <path fill="#fffbe6" d={paths.collarR} />
          <path className="grain" d={paths.sweaterTop} />
        </g>

        {/* ==================== 3. DYNAMIC HEAD & FACIAL EXPRESSIONS ==================== */}
        <g
          ref={(el) => {
            animRefs.current.headGroup = el;
          }}
          style={{ transformOrigin: '218px 168px' }}
        >
          {/* Layered Voluminous Chestnut Hair Back & Waves */}
          <g filter="url(#pc-layer)">
            <path fill="#5e281f" d={paths.hairBackOuter} />
            <path fill="#9e695c" d={paths.hairChestnutL} />
            <path fill="#9e695c" d={paths.hairChestnutR} />
            <path fill="#b57d6e" d={paths.hairHighlightL} />
            <path fill="#b57d6e" d={paths.hairHighlightR} />
            <path className="grain" d={paths.hairBackOuter} />
          </g>

          {/* Left & Right Paper-Cut Ears */}
          <g filter="url(#pc-soft)">
            <path fill="#f5cfaf" d={paths.earL} />
            <path fill="#f5cfaf" d={paths.earR} />
            <path
              d="M150 130 Q155 134 151 139 M286 130 Q281 134 285 139"
              fill="none"
              stroke="#c98e6b"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </g>

          {/* Face Base & Subtle Contour Shadow */}
          <g filter="url(#pc-layer)">
            <path fill="#f2c49e" d={paths.faceShadow} />
            <path fill="#ffdfc0" d={paths.faceMain} />
            <path className="grain" d={paths.faceMain} />
          </g>

          {/* Rosy Paper-Cut Cheeks */}
          <g
            ref={(el) => {
              animRefs.current.cheeksGroup = el;
            }}
            opacity="0.65"
          >
            <path fill="#f09587" d={paths.cheekL} />
            <path fill="#f09587" d={paths.cheekR} />
          </g>

          {/* Cute Sculpted Paper-Cut Nose */}
          <g filter="url(#pc-soft)">
            <path fill="#e3b18a" d={paths.nose} />
          </g>

          {/* Dynamic Eyes (Normal Expressive Eyes vs Happy Celebration Eyes) */}
          <g
            ref={(el) => {
              animRefs.current.normalEyesGroup = el;
            }}
          >
            {/* Upper lash arches */}
            <path
              d="M177 123 Q190 114 203 123 M235 123 Q248 114 261 123"
              fill="none"
              stroke="#3b150c"
              strokeWidth="2.8"
              strokeLinecap="round"
            />
            {/* Eye whites */}
            <ellipse cx="190" cy="126" rx="8.2" ry="7.8" fill="#fffaf2" />
            <ellipse cx="248" cy="126" rx="8.2" ry="7.8" fill="#fffaf2" />

            {/* Moving Irises, Pupils & Catchlights */}
            <g
              ref={(el) => {
                animRefs.current.pupilsGroup = el;
              }}
            >
              {/* Left iris & pupil */}
              <circle cx="190" cy="126.5" r="5.4" fill="#46180d" />
              <circle cx="190" cy="126.5" r="3.1" fill="#1e0803" />
              <circle cx="188" cy="124.2" r="1.7" fill="#ffffff" />
              <circle cx="192.2" cy="128.4" r="0.8" fill="#ffffff" />

              {/* Right iris & pupil */}
              <circle cx="248" cy="126.5" r="5.4" fill="#46180d" />
              <circle cx="248" cy="126.5" r="3.1" fill="#1e0803" />
              <circle cx="246" cy="124.2" r="1.7" fill="#ffffff" />
              <circle cx="250.2" cy="128.4" r="0.8" fill="#ffffff" />
            </g>

            {/* Blinking Eyelids */}
            <g
              ref={(el) => {
                animRefs.current.eyelidsGroup = el;
              }}
              style={{ transformOrigin: '219px 124px', transform: 'scaleY(0)' }}
            >
              <ellipse cx="190" cy="126" rx="9" ry="8.5" fill="#f7d2b0" />
              <ellipse cx="248" cy="126" rx="9" ry="8.5" fill="#f7d2b0" />
              <path
                d="M178 127 Q190 133 202 127 M236 127 Q248 133 260 127"
                fill="none"
                stroke="#3b150c"
                strokeWidth="2.3"
                strokeLinecap="round"
              />
            </g>
          </g>

          {/* Happy Celebration Eyes (^ ^) */}
          <g
            ref={(el) => {
              animRefs.current.happyEyesGroup = el;
            }}
            opacity="0"
          >
            <path
              d="M179 128 Q190 116 201 128"
              fill="none"
              stroke="#3b150c"
              strokeWidth="3.2"
              strokeLinecap="round"
            />
            <path
              d="M237 128 Q248 116 259 128"
              fill="none"
              stroke="#3b150c"
              strokeWidth="3.2"
              strokeLinecap="round"
            />
          </g>

          {/* Dynamic Expressive Eyebrows */}
          <g
            ref={(el) => {
              animRefs.current.browsGroup = el;
            }}
          >
            <path
              d="M176 105 Q189 98 202 103"
              fill="none"
              stroke="#4d1d12"
              strokeWidth="3.2"
              strokeLinecap="round"
            />
            <path
              d="M236 103 Q249 98 262 105"
              fill="none"
              stroke="#4d1d12"
              strokeWidth="3.2"
              strokeLinecap="round"
            />
          </g>

          {/* Dynamic Mouth States (centered at x=219, y=154) */}
          {/* 1. Calm / Focused gentle smile */}
          <path
            ref={(el) => {
              animRefs.current.mouthCalm = el;
            }}
            d="M209 152 Q219 159 229 152"
            fill="none"
            stroke="#b84a49"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
          {/* 2. Curious / Amazed "o" when looking up at the flying paper dove */}
          <path
            ref={(el) => {
              animRefs.current.mouthCurious = el;
            }}
            d="M219 148.5 A5.2 5.8 0 1 1 218.99 148.5 Z"
            fill="#bf5453"
            stroke="#7a2826"
            strokeWidth="1.6"
            opacity="0"
          />
          {/* 3. Delighted Beaming Smile when ticket enters laptop */}
          <g
            ref={(el) => {
              animRefs.current.mouthHappy = el;
            }}
            opacity="0"
          >
            <path
              d="M205 149 Q219 152 233 149 Q230 164 219 164 Q208 164 205 149 Z"
              fill="#b84343"
              stroke="#7a2826"
              strokeWidth="1.8"
              strokeLinejoin="round"
            />
            <path
              d="M211 158 Q219 154 227 158 Q224 163 219 163 Q214 163 211 158 Z"
              fill="#f08c8c"
            />
          </g>

          {/* Swept Front Hair Bangs Framing Forehead */}
          <g filter="url(#pc-layer)">
            <path fill="#652e26" d={paths.bangsL} />
            <path fill="#652e26" d={paths.bangsR} />
            <path className="grain" d={paths.bangsL} />
            <path className="grain" d={paths.bangsR} />
          </g>
        </g>

        {/* ==================== 4. CROSS-LEGGED DENIM JEANS & SHOES ==================== */}
        {/* Left & Right Shoes */}
        <g filter="url(#pc-layer)">
          <path fill="#635d65" d={paths.shoeLBody} />
          <path fill="#332a22" d={paths.shoeLSole} />
          <path fill="#635d65" d={paths.shoeRBody} />
          <path fill="#332a22" d={paths.shoeRSole} />
        </g>

        {/* Left Leg (Denim Blue) */}
        <g filter="url(#pc-layer)">
          <path fill="#66abcc" d={paths.legLeft} />
          <path fill="#1c7792" d={paths.legLeftShadow} />
          <path className="grain" d={paths.legLeft} />
        </g>

        {/* Right Leg Crossing Over (Denim Blue + Shadow Fold) */}
        <g filter="url(#pc-layer)">
          <path fill="#66abcc" d={paths.legRight} />
          <path fill="#1b7891" d={paths.legRightShadow} />
          <path fill="#3d88a8" d={paths.kneeCrease} />
          <path className="grain" d={paths.legRight} />
        </g>

        {/* ==================== 5. POWDER-BLUE PAPER-CUT LAPTOP & HANDS ==================== */}
        {/* Soft Emerald-Gold Glow behind laptop when ticket arrives */}
        <polygon
          ref={(el) => {
            animRefs.current.laptopGlow = el;
          }}
          points="132,198 300,198 290,298 142,298"
          fill="rgba(138, 240, 175, 0.65)"
          opacity="0"
          style={{ filter: 'blur(8px)' }}
        />

        {/* Laptop Base & Lid */}
        <g filter="url(#pc-layer)">
          <path fill="#849fb2" d={paths.laptopBase} />
          <path fill="#c0edff" d={paths.laptopOuter} />
          <path fill="#86d1e8" d={paths.laptopRightShade} />
          <path fill="#ffffff" d={paths.laptopTopRim} />
          {/* Central Laptop Lid Emblem at (216, 251) */}
          <path fill="#f7fcff" d={paths.laptopLogoOuter} />
          <path fill="#3d4347" d={paths.laptopLogoInner} />
          <path className="grain" d={paths.laptopOuter} />
        </g>

        {/* Left & Right Hands (animated typing movement) */}
        <g
          ref={(el) => {
            animRefs.current.handL = el;
          }}
          filter="url(#pc-soft)"
        >
          <path fill="#ffdfc0" d={paths.handL} />
        </g>
        <g
          ref={(el) => {
            animRefs.current.handR = el;
          }}
          filter="url(#pc-soft)"
        >
          <path fill="#ffdfc0" d={paths.handR} />
        </g>
      </g>
    </svg>
  );
};
