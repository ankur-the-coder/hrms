import React, { useEffect, useRef, useState, useCallback } from 'react';
import { PaperCutGirl, GirlAnimRefs } from './components/PaperCutGirl';
import {
  DioramaTargets,
  renderBirdAndMail,
  getWingFreq,
  TR,
  TL,
} from './utils/birdMailRenderer';

// Deterministic PRNG for scissor-cut paper diorama geometry
function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const q = (n: number) => Math.round(n * 10) / 10;

export default function App() {
  const [showPassword, setShowPassword] = useState(false);
  const [authBtnText, setAuthBtnText] = useState('Initialize auth');

  // Refs for DOM layers and actors
  const grainImgRef = useRef<SVGImageElement | null>(null);
  const hangRef = useRef<HTMLDivElement | null>(null);
  const l1Ref = useRef<HTMLDivElement | null>(null);
  const l2Ref = useRef<HTMLDivElement | null>(null);
  const l3Ref = useRef<HTMLDivElement | null>(null);
  const l4Ref = useRef<HTMLDivElement | null>(null);
  const l5Ref = useRef<HTMLDivElement | null>(null);
  const l6Ref = useRef<HTMLDivElement | null>(null);
  const l7Ref = useRef<HTMLDivElement | null>(null);
  const logoSvgRef = useRef<SVGSVGElement | null>(null);

  const girlWrapRef = useRef<HTMLDivElement | null>(null);
  const girlShadowRef = useRef<HTMLDivElement | null>(null);
  const birdCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const msgRef = useRef<HTMLDivElement | null>(null);
  const ringRef = useRef<HTMLDivElement | null>(null);
  const planeRef = useRef<SVGSVGElement | null>(null);

  // Refs for the girl's dynamic SVG facial features & body parts
  const girlAnimRefs = useRef<GirlAnimRefs>({
    headGroup: null,
    torsoGroup: null,
    pupilsGroup: null,
    normalEyesGroup: null,
    happyEyesGroup: null,
    eyelidsGroup: null,
    browsGroup: null,
    cheeksGroup: null,
    mouthCalm: null,
    mouthCurious: null,
    mouthHappy: null,
    handL: null,
    handR: null,
    laptopGlow: null,
  });

  // Mutable animation & layout state
  const stateRef = useRef({
    T: 0,
    ph: 0,
    lastNow: performance.now(),
    ringTriggered: false,
    msgTriggered: false,
    lastDotTime: 0,
    headAngle: -2,
    pupilX: 0,
    pupilY: 0,
    browY: 0,
    curiousAlpha: 0,
    happyAlpha: 0,
    px: 0,
    py: 0,
    tx: 0,
    ty: 0,
    targets: {
      W: typeof window !== 'undefined' ? window.innerWidth : 1280,
      H: typeof window !== 'undefined' ? window.innerHeight : 800,
      dpr: 1,
      girlCx: 900,
      girlTop: 480,
      girlBot: 640,
      girlGw: 168,
      girlGh: 160,
      laptopX: 855,
      laptopY: 575,
    } as DioramaTargets,
  });

  const restartAnimation = useCallback(() => {
    const st = stateRef.current;
    st.T = 0;
    st.ph = 0;
    st.ringTriggered = false;
    st.msgTriggered = false;
    st.lastDotTime = 0;

    if (msgRef.current) {
      msgRef.current.style.opacity = '0';
      msgRef.current.classList.remove('on');
    }
    if (ringRef.current) {
      ringRef.current.style.opacity = '0';
      ringRef.current.classList.remove('on');
    }
    if (planeRef.current) {
      planeRef.current.style.opacity = '0';
    }
  }, []);

  useEffect(() => {
    // 1. Generate procedural paper grain texture for SVG <pattern id="g">
    const makeGrain = () => {
      const c = document.createElement('canvas');
      c.width = c.height = 160;
      const g = c.getContext('2d');
      if (!g) return;
      const id = g.createImageData(160, 160);
      const d = id.data;
      const R = mulberry32(77);
      for (let i = 0; i < d.length; i += 4) {
        const n = R();
        if (n < 0.5) {
          d[i] = 74;
          d[i + 1] = 52;
          d[i + 2] = 30;
          d[i + 3] = (0.5 - n) * 46;
        } else {
          d[i] = 255;
          d[i + 1] = 251;
          d[i + 2] = 240;
          d[i + 3] = (n - 0.5) * 40;
        }
      }
      g.putImageData(id, 0, 0);
      for (let k = 0; k < 90; k++) {
        g.strokeStyle =
          k % 3 ? 'rgba(255, 252, 242, 0.2)' : 'rgba(96, 66, 36, 0.13)';
        g.lineWidth = 0.6;
        g.beginPath();
        const x = R() * 160;
        const y = R() * 160;
        const a = R() * 6.28;
        const l = 4 + R() * 14;
        g.moveTo(x, y);
        g.quadraticCurveTo(
          x + Math.cos(a + 0.6) * l * 0.5,
          y + Math.sin(a + 0.6) * l * 0.5,
          x + Math.cos(a) * l,
          y + Math.sin(a) * l
        );
        g.stroke();
      }
      if (grainImgRef.current) {
        grainImgRef.current.setAttribute('href', c.toDataURL());
      }
    };
    makeGrain();

    // 2. Scissor-cut geometry helpers for diorama layers
    let R = mulberry32(1);
    const rr = (a: number, b: number) => a + (b - a) * R();

    const ar = (p: [number, number][]) => {
      let a = 0;
      for (let i = 0; i < p.length; i++) {
        const u = p[i];
        const v = p[(i + 1) % p.length];
        a += u[0] * v[1] - v[0] * u[1];
      }
      return a;
    };

    const or = (p: [number, number][]) => (ar(p) < 0 ? p.slice().reverse() : p);

    const trace = (p: [number, number][], j: number, st: number) => {
      let s = '';
      const n = p.length;
      for (let i = 0; i < n; i++) {
        const a = p[i];
        const b = p[(i + 1) % n];
        const dx = b[0] - a[0];
        const dy = b[1] - a[1];
        const L = Math.hypot(dx, dy) || 1;
        const k = Math.max(1, Math.round(L / st));
        const nx = -dy / L;
        const ny = dx / L;
        for (let t = 0; t < k; t++) {
          let x = a[0] + (dx * t) / k;
          let y = a[1] + (dy * t) / k;
          if (t) {
            const o = (R() - 0.5) * 2 * j;
            x += nx * o;
            y += ny * o;
          }
          s += (s ? 'L' : 'M') + q(x) + ' ' + q(y);
        }
      }
      return s + 'Z';
    };

    const cut = (p: [number, number][], j = 0.7, st = 7) => trace(or(p), j, st);
    const poly = (p: [number, number][]) => {
      const op = or(p);
      return 'M' + op.map((a) => q(a[0]) + ' ' + q(a[1])).join('L') + 'Z';
    };
    const circ = (cx: number, cy: number, r: number, n?: number): [number, number][] => {
      const count = n || Math.max(10, (r * 1.2) | 0);
      return Array.from({ length: count }, (_, i) => {
        const a = (i / count) * 6.283;
        return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
      });
    };
    const wave = (b: number, A: number[], Ls: number[]) => {
      const ph = A.map(() => R() * 6.28);
      return (x: number) => {
        let y = b;
        A.forEach((a, i) => {
          y += a * Math.sin((x / Ls[i]) * 6.283 + ph[i]);
        });
        return y;
      };
    };

    const M = 90;
    const buildLogo = () => {
      if (!logoSvgRef.current) return;
      R = mulberry32(42);
      let s = '';
      s += `<path fill="#3b2b1d" d="${poly([
        [58.6, 110],
        [58.8, 64],
        [61.2, 64],
        [61.4, 110],
      ])}${poly([
        [59, 76],
        [40, 64],
        [41.5, 62],
        [60, 73],
      ])}${poly([
        [61, 76],
        [80, 64],
        [78.5, 62],
        [60, 73],
      ])}"/>`;
      const discs: [number, number, number, string][] = [
        [28, 58, 19, '#c8642d'],
        [94, 56, 19, '#274e52'],
        [34, 34, 14, '#9bb89b'],
        [87, 32, 14, '#d98a5b'],
        [60, 32, 27, '#5f7f5b'],
        [60, 68, 17, '#d9a45b'],
        [44, 66, 12, '#efc27d'],
        [78, 68, 12, '#3d6a50'],
      ];
      for (const [x, y, r, c] of discs) {
        s += `<path fill="${c}" d="${cut(circ(x, y, r), 0.6, 4)}"/>`;
      }
      s += `<path fill="#3b2b1d" d="${cut(
        [
          [14, 108],
          [60, 104],
          [106, 108],
          [60, 112],
        ],
        0.4,
        5
      )}"/><path fill="url(#g)" d="${cut(circ(60, 32, 27), 0.2, 50)}"/>`;
      logoSvgRef.current.innerHTML = s;
    };

    const setLayerSvg = (ref: React.MutableRefObject<HTMLDivElement | null>, W: number, H: number, html: string) => {
      const svg = ref.current?.querySelector('svg');
      if (!svg) return;
      svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
      svg.innerHTML = html;
    };

    const mk = (f: string, d: string) => `<path fill="${f}" d="${d}"/><path class="grain" d="${d}"/>`;

    const buildSceneAndLayout = () => {
      const W = window.innerWidth;
      const H = window.innerHeight;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const port = W < 760 || H > W * 1.1;
      const GY = H * (port ? 0.86 : 0.8);

      if (birdCanvasRef.current) {
        birdCanvasRef.current.width = W * dpr;
        birdCanvasRef.current.height = H * dpr;
      }

      R = mulberry32(1847);
      const U = Math.sqrt(W * H) / 100;

      const ridge = (f: (x: number) => number, bot: number, st = 9) => {
        const p: [number, number][] = [];
        for (let x = -M; x <= W + M + st; x += st) {
          p.push([x, f(x) + (R() - 0.5) * 1.6]);
        }
        p.push([W + M + st, bot], [-M, bot]);
        return poly(p);
      };

      const pine = (cx: number, by: number, h: number, w: number) => {
        const n = h > 200 ? 7 : h > 80 ? 5 : 4;
        const tip = by - h;
        const st = (h * 0.92) / (n + 0.45);
        const j = Math.max(0.45, h / 520);
        const sp = Math.max(5, h / 70);
        let d = '';
        for (let i = 0; i < n; i++) {
          const top = tip + i * st;
          const bot = tip + (i + 1.45) * st;
          const b = w * 0.5 * (0.26 + 0.74 * Math.pow((i + 1) / n, 0.9));
          const hr = b * rr(0.92, 1.08);
          const hl = b * rr(0.92, 1.08);
          d += cut(
            [
              [cx, top],
              [cx + hr, bot],
              [cx + hr * 0.5, bot - st * 0.28],
              [cx, bot - st * 0.18],
              [cx - hl * 0.5, bot - st * 0.28],
              [cx - hl, bot],
            ],
            j,
            sp
          );
        }
        const t = Math.max(1.4, w * 0.055);
        return (
          d +
          cut(
            [
              [cx - t, by + 4],
              [cx - t, by - h * 0.12],
              [cx + t, by - h * 0.12],
              [cx + t, by + 4],
            ],
            0.3,
            8
          )
        );
      };

      const blade = (x: number, y: number, h: number, l: number, w: number) =>
        poly([
          [x - w / 2, y],
          [x + l * 0.5 - w * 0.3, y - h * 0.55],
          [x + l, y - h],
          [x + l * 0.5 + w * 0.3, y - h * 0.55],
          [x + w / 2, y],
        ]);

      // Layer 1: Far mountain ridge
      const f1 = wave(H * 0.41, [H * 0.032, H * 0.015], [W * 1.1, W * 0.4]);
      setLayerSvg(l1Ref, W, H, mk('#dfdec3', ridge(f1, H + M)));

      // Layer 2: Second hill with distant pines
      const f2 = wave(H * 0.5, [H * 0.034, H * 0.014], [W * 0.9, W * 0.3]);
      let d2 = ridge(f2, H + M);
      for (let x = -M; x < W + M; x += rr(6, 16)) {
        if (Math.sin((x / W) * 8.5) + Math.sin((x / W) * 21) * 0.5 > 0.35) {
          const h = rr(2, 4) * U;
          d2 += pine(x, f2(x) + 3, h, h * 0.55);
        }
      }
      setLayerSvg(l2Ref, W, H, mk('#bdcfb2', d2));

      // Layer 3: Mid forest ridge
      const f3 = wave(H * 0.56, [H * 0.014, H * 0.007], [W * 0.7, W * 0.23]);
      let d3 = ridge(f3, H + M);
      for (let x = -M; x < W + M; ) {
        const h = rr(3.6, 7.4) * U;
        const w = h * rr(0.46, 0.58);
        d3 += pine(x, f3(x) + 4, h, w);
        x += w * rr(0.42, 0.8);
      }
      setLayerSvg(l3Ref, W, H, mk('#9bb89b', d3));

      // Layer 4: Rolling green hill
      const f4 = wave(H * 0.62, [H * 0.008, H * 0.004], [W * 0.8, W * 0.25]);
      setLayerSvg(l4Ref, W, H, mk('#7e9c74', ridge(f4, H + M, 10)));

      // Layer 5: Tall framing pines
      let d5 = '';
      const framingPines: [number, number, number][] = port
        ? [
            [1.02, 0.5, 0.34],
            [0.04, 0.4, 0.3],
          ]
        : [
            [0.99, 0.9, 0.25],
            [0.935, 0.54, 0.21],
          ];
      for (const [gx, gh, gw] of framingPines) {
        d5 += pine(W * gx, GY + 6, H * gh, Math.min(H * gh * 0.42, W * gw));
      }
      setLayerSvg(l5Ref, W, H, mk('#274e52', d5));

      // Layer 6: Ochre ground, grass tufts, pebbles, and autumn leaves
      const gnd = wave(GY, [H * 0.006, H * 0.003], [W * 0.7, W * 0.22]);
      const d6 = ridge(gnd, H + M, 8);
      let tufts = '';
      let pebbles = '';
      let leaves1 = '';
      let leaves2 = '';
      for (let x = -M; x < W + M; x += rr(18, 60)) {
        const y = gnd(x) + 2;
        for (let k = 0; k < 4; k++) {
          tufts += blade(
            x + k * 2.2,
            y + 2,
            rr(0.9, 2.1) * U,
            rr(-0.6, 0.6) * U,
            rr(2, 3.4)
          );
        }
      }
      for (let i = 0; i < 10; i++) {
        const x = rr(0.03, 0.97) * W;
        const y = gnd(x) + rr(1, 6) * U;
        const r = rr(0.3, 0.7) * U;
        pebbles += cut(
          circ(x, y, r, 9).map(([a, b]) => [a, y + (b - y) * 0.6]),
          0.25,
          3
        );
      }
      for (let i = 0; i < W / 45; i++) {
        const x = rr(-0.02, 1.02) * W;
        const y =
          gnd(x) + U * 2 + Math.pow(R(), 1.3) * (H * 0.97 - gnd(x) - U * 2);
        const sz = rr(0.45, 0.9) * U;
        const a = R() * 3.1;
        const ca = Math.cos(a);
        const sa = Math.sin(a);
        const lp: [number, number][] = (
          [
            [-1, 0],
            [-0.3, -0.42],
            [0.35, -0.36],
            [1, 0],
            [0.3, 0.4],
            [-0.35, 0.36],
          ] as [number, number][]
        ).map(([u, v]) => [
          x + (u * ca - v * sa * 0.8) * sz,
          y + (u * sa + v * ca * 0.8) * sz * 0.62,
        ]);
        if (R() < 0.6) leaves1 += cut(lp, 0.2, 3);
        else leaves2 += cut(lp, 0.2, 3);
      }
      setLayerSvg(
        l6Ref,
        W,
        H,
        `<path fill="#d9a45b" d="${d6}"/><path fill="#c9713a" d="${leaves1}"/><path fill="#b98f4c" d="${leaves2}"/><path fill="#8a9a55" d="${tufts}"/><path fill="#e9dcc0" d="${pebbles}"/><path class="grain" d="${d6}"/>`
      );

      // Layer 7: Foreground bottom silhouette grass blades
      const g8 = wave(H * 0.965, [H * 0.006], [W * 0.5]);
      let d8 = ridge(g8, H + M, 9);
      let b2 = '';
      for (let x = -M; x < W + M; x += rr(3.5, 8)) {
        const s = Math.abs(x - W / 2) / (W / 2);
        const h =
          H * (0.012 + 0.1 * Math.pow(clamp(s, 0, 1.2), 2.4)) * rr(0.4, 1);
        const b = blade(x, g8(x) + 6, h, rr(-0.38, 0.38) * h, rr(4, 9));
        if (R() < 0.3) b2 += b;
        else d8 += b;
      }
      setLayerSvg(
        l7Ref,
        W,
        H,
        `<path fill="#3d6a50" d="${b2}"/><path fill="#1f4245" d="${d8}"/><path class="grain" d="${d8}${b2}"/>`
      );

      // Hanging Sun (raised higher!) and 5 Layered Paper-Cut Clouds (all well above the hills!)
      const rays: [number, number][] = [];
      for (let i = 0; i < 44; i++) {
        const a = (i / 44) * 6.283;
        const r = i % 2 ? 47 : 58;
        rays.push([Math.cos(a) * r, Math.sin(a) * r]);
      }
      const sd = clamp(Math.min(W, H) * 0.14, 68, 138);
      const sunSvg = `<svg viewBox="-62 -62 124 124" width="${sd}" height="${sd}">
        <path fill="#c8642d" d="${cut(rays, 0.5, 5)}"/>
        <path fill="#d9a45b" d="${cut(circ(0, 0, 42, 40), 0.5, 5)}"/>
        <path fill="#e6b772" d="${cut(circ(-4, -5, 29, 30), 0.4, 5)}"/>
        <path class="grain" d="${cut(circ(0, 0, 42, 40), 0.2, 16)}"/>
      </svg>`;

      const makeCloudPath = (sc: number, ox = 0, oy = 0) => {
        let d = '';
        const puffs: [number, number, number][] = [
          [-30, 4, 17],
          [-9, -9, 24],
          [16, -5, 20],
          [35, 6, 13],
        ];
        for (const [x, y, r] of puffs) {
          d += cut(circ((x + ox) * sc, (y + oy) * sc, r * sc, 22), 0.5, 5);
        }
        return (
          d +
          cut(
            [
              [(-46 + ox) * sc, (20 + oy) * sc],
              [(-46 + ox) * sc, (6 + oy) * sc],
              [(48 + ox) * sc, (6 + oy) * sc],
              [(48 + ox) * sc, (20 + oy) * sc],
            ],
            0.5,
            6
          )
        );
      };

      // Sun raised to y = 0.095; 5 clouds placed between y = 0.08 and y = 0.22 so none are ever hidden behind the hills!
      const hangingItems: [number, number, string | number, number][] = [
        [port ? 0.22 : 0.31, port ? 0.1 : 0.11, 0, 0.145],
        [port ? 0.42 : 0.45, port ? 0.17 : 0.18, 0, 0.175],
        [port ? 0.58 : 0.56, port ? 0.08 : 0.085, 0, 0.125],
        [port ? 0.76 : 0.67, port ? 0.11 : 0.095, sunSvg, sd],
        [port ? 0.86 : 0.8, port ? 0.19 : 0.16, 0, 0.16],
        [port ? 0.93 : 0.91, port ? 0.23 : 0.22, 0, 0.13],
      ];

      if (hangRef.current) {
        hangRef.current.innerHTML = hangingItems
          .map(([x, y, customSvg, s], k) => {
            const w = customSvg ? s : Math.min(W, H) * s * 1.1;
            const len = H * y;
            const backCloud = customSvg ? '' : makeCloudPath(1, 3.5, -2.5);
            const frontCloud = customSvg ? '' : makeCloudPath(1, 0, 0);
            const innerObj =
              typeof customSvg === 'string'
                ? customSvg
                : `<svg viewBox="-56 -40 112 66" width="${q(w)}" height="${q(w * 0.58)}">
                    <path fill="#efe4cc" d="${backCloud}"/>
                    <path fill="#fbf6ea" d="${frontCloud}"/>
                    <path class="grain" d="${frontCloud}"/>
                  </svg>`;
            return `<div class="hang" style="left:${q(W * x)}px;--len:${q(len)}px">
              <div class="swing" style="--sd:${4.2 + k * 0.95}s;--dl:-${k * 1.3}s">
                <span class="string"></span>
                <div class="obj">${innerObj}</div>
              </div>
            </div>`;
          })
          .join('');
      }

      // Position & Scale the Smaller Rebuilt Paper-Cut Girl
      // Aspect ratio of PaperCutGirl viewBox (377 x 360) -> AR = 1.0472
      const AR = 377 / 360;
      const FX = 0.5742;
      const FY = 0.6978;
      const gh = clamp(
        port
          ? Math.min(H * 0.21, (W * 0.36) / AR)
          : Math.min(H * 0.265, (W * 0.19) / AR),
        125,
        215
      );
      const gw = gh * AR;
      const cx = W * (port ? 0.52 : 0.71);
      const bot = gnd(cx) + 8;
      const top = bot - gh;
      const left = cx - gw / 2;

      if (girlWrapRef.current) {
        Object.assign(girlWrapRef.current.style, {
          left: `${q(left)}px`,
          top: `${q(top)}px`,
          width: `${q(gw)}px`,
          height: `${q(gh)}px`,
        });
      }

      if (girlShadowRef.current) {
        Object.assign(girlShadowRef.current.style, {
          left: `${q(cx - gw * 0.52)}px`,
          top: `${q(bot - 8)}px`,
          width: `${q(gw * 1.04)}px`,
          height: '15px',
        });
      }

      // Laptop center on the girl SVG (FX = 0.5742, FY = 0.6978)
      const laptopX = left + FX * gw;
      const laptopY = top + FY * gh;

      stateRef.current.targets = {
        W,
        H,
        dpr,
        girlCx: cx,
        girlTop: top,
        girlBot: bot,
        girlGw: gw,
        girlGh: gh,
        laptopX,
        laptopY,
      };
    };

    buildLogo();
    buildSceneAndLayout();
    restartAnimation();

    let resizeTimer: number;
    const onResize = () => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(() => {
        buildSceneAndLayout();
      }, 120);
    };

    const onPointerMove = (e: PointerEvent) => {
      const { W, H } = stateRef.current.targets;
      stateRef.current.tx = (e.clientX / W - 0.5) * 2;
      stateRef.current.ty = (e.clientY / H - 0.5) * 2;
    };

    window.addEventListener('resize', onResize);
    window.addEventListener('pointermove', onPointerMove);

    // 3. Main 60fps Animation Loop (Parallax + 3D Bird & Mail Canvas + Dynamic Girl Expressions + Paper Plane)
    let rafId = 0;
    const LOOP_DURATION = 14.8;

    const frame = (now: number) => {
      rafId = requestAnimationFrame(frame);
      const st = stateRef.current;
      const dt = Math.min(0.05, (now - st.lastNow) / 1000);
      st.lastNow = now;
      const clock = now / 1000;

      // Advance scene film clock
      st.T += dt;
      if (st.T > LOOP_DURATION) {
        restartAnimation();
      }
      st.ph = (st.ph + dt * getWingFreq(st.T)) % 1;

      // Smooth pointer parallax
      st.px += (st.tx - st.px) * 0.06;
      st.py += (st.ty - st.py) * 0.06;

      const parallaxLayers: [HTMLDivElement | null, number][] = [
        [l1Ref.current, 0.2],
        [l2Ref.current, 0.35],
        [l3Ref.current, 0.5],
        [l4Ref.current, 0.7],
        [l5Ref.current, 1.0],
        [l6Ref.current, 1.0],
        [l7Ref.current, 1.55],
        [hangRef.current, 0.28],
      ];
      for (const [el, f] of parallaxLayers) {
        if (el) {
          el.style.transform = `translate3d(${q(-st.px * f * 13)}px, ${q(
            -st.py * f * 7
          )}px, 0)`;
        }
      }
      if (girlWrapRef.current) {
        girlWrapRef.current.style.transform = `translate3d(${q(
          -st.px * 13
        )}px, ${q(-st.py * 7)}px, 0)`;
      }
      if (girlShadowRef.current) {
        girlShadowRef.current.style.transform = `translate3d(${q(
          -st.px * 13
        )}px, ${q(-st.py * 7)}px, 0)`;
      }

      // Render 3D Kinematic Paper Dove, Beak Mail, Falling Envelope & Curving Ticket on Canvas
      const cv = birdCanvasRef.current;
      const ctx = cv?.getContext('2d');
      const tg = st.targets;
      let birdState = {
        t: st.T,
        birdActive: false,
        birdX: 0,
        birdY: 0,
        mailDropped: false,
        envX: 0,
        envY: 0,
        ticketActive: false,
        ticketX: tg.laptopX,
        ticketY: tg.laptopY,
        ticketArrived: false,
        ticketArrivedTime: TL,
      };

      if (ctx) {
        ctx.setTransform(tg.dpr, 0, 0, tg.dpr, 0, 0);
        ctx.clearRect(0, 0, tg.W, tg.H);
        ctx.save();
        ctx.translate(-st.px * 13, -st.py * 7);
        birdState = renderBirdAndMail(ctx, st.T, st.ph, tg);
        ctx.restore();
      }

      // Trigger golden ring, "✓ Ticket created" badge, and paper airplane launch when ticket reaches laptop (t >= TL)
      const lxPar = tg.laptopX - st.px * 13;
      const lyPar = tg.laptopY - st.py * 7;

      if (st.T >= TL && !st.ringTriggered) {
        st.ringTriggered = true;
        st.msgTriggered = true;
        if (ringRef.current) {
          ringRef.current.style.left = `${q(lxPar)}px`;
          ringRef.current.style.top = `${q(lyPar)}px`;
          ringRef.current.classList.remove('on');
          void ringRef.current.offsetWidth;
          ringRef.current.classList.add('on');
        }
        if (msgRef.current) {
          msgRef.current.style.left = `${q(lxPar + 8)}px`;
          msgRef.current.style.top = `${q(tg.girlTop - st.py * 7 - 4)}px`;
          msgRef.current.classList.remove('on');
          void msgRef.current.offsetWidth;
          msgRef.current.classList.add('on');
        }
      }

      // Fade out notification badge after 4.2 seconds
      if (st.msgTriggered && msgRef.current) {
        msgRef.current.style.left = `${q(lxPar + 8)}px`;
        msgRef.current.style.top = `${q(tg.girlTop - st.py * 7 - 4)}px`;
        if (st.T > TL + 3.8) {
          const fade = Math.max(0, 1 - (st.T - (TL + 3.8)) * 1.8);
          msgRef.current.style.opacity = String(fade);
        }
      }

      // Paper airplane launch from laptop up and to the right (t from TL + 0.65 to TL + 4.25)
      const planeStart = TL + 0.65;
      const planeDur = 3.6;
      if (planeRef.current) {
        if (st.T >= planeStart && st.T <= planeStart + planeDur) {
          const u = clamp((st.T - planeStart) / planeDur, 0, 1);
          const e = Math.pow(u, 1.32);
          const p0 = [lxPar + 8, lyPar - 10];
          const p1 = [lxPar + tg.girlGw * 0.25, lyPar - tg.H * 0.28];
          const p2 = [tg.W * 0.82, lyPar - tg.H * 0.42];
          const p3 = [tg.W + 90, lyPar - tg.H * 0.52];

          const cubic = (tVal: number) => {
            const v = 1 - tVal;
            return [0, 1].map(
              (k) =>
                v * v * v * p0[k] +
                3 * v * v * tVal * p1[k] +
                3 * v * tVal * tVal * p2[k] +
                tVal * tVal * tVal * p3[k]
            );
          };

          const pp = cubic(e);
          const q2 = cubic(Math.min(1, e + 0.02));
          const ang = Math.atan2(q2[1] - pp[1], q2[0] - pp[0]);
          const sc = 0.4 + 0.6 * clamp(u * 5, 0, 1);

          planeRef.current.style.transform = `translate(${q(pp[0])}px, ${q(
            pp[1]
          )}px) rotate(${ang.toFixed(3)}rad) scale(${sc.toFixed(3)}, ${sc.toFixed(
            3
          )})`;
          planeRef.current.style.opacity = '1';

          if (st.T - st.lastDotTime > 0.075) {
            st.lastDotTime = st.T;
            const dot = document.createElement('i');
            dot.className = 'dot';
            dot.style.left = `${q(pp[0])}px`;
            dot.style.top = `${q(pp[1])}px`;
            document.body.appendChild(dot);
            window.setTimeout(() => dot.remove(), 1450);
          }
        } else {
          planeRef.current.style.opacity = '0';
        }
      }

      // 4. Update the Girl's Dynamic Facial Expressions, Eye Gaze, Blinking & Typing Hands
      const refs = girlAnimRefs.current;
      const isWatchingBird = st.T >= 0.85 && st.T < TR;
      const isWatchingDrop = st.T >= TR && st.T < TL;
      const isCelebrating = st.T >= TL && st.T < TL + 4.3;

      let targetHeadDeg = Math.sin(clock * 3.1) * 1.6; // Gentle focused typing nod
      let targetPupilX = Math.sin(clock * 4.2) * 1.6;
      let targetPupilY = 2.6; // Looking down at laptop screen while typing
      let targetBrowY = 0;
      let targetCurious = 0;
      let targetHappy = 0;

      if (isWatchingBird) {
        // Look up and track the flying dove overhead!
        const dx = birdState.birdX - tg.girlCx;
        const dy = birdState.birdY - (tg.girlTop + tg.girlGh * 0.34);
        targetHeadDeg = clamp((dx / tg.W) * 18, -11, 11);
        targetPupilX = clamp((dx / 220) * 3.4, -3.4, 3.4);
        targetPupilY = clamp((dy / 170) * 3.2, -3.5, 1.0);
        targetBrowY = -3.8;
        targetCurious = 1;
      } else if (isWatchingDrop) {
        // Follow the falling envelope & curving golden ticket down toward her laptop
        const focusX = birdState.ticketActive ? birdState.ticketX : birdState.envX;
        const focusY = birdState.ticketActive ? birdState.ticketY : birdState.envY;
        const dx = focusX - tg.girlCx;
        const dy = focusY - (tg.girlTop + tg.girlGh * 0.35);
        targetHeadDeg = clamp((dx / 240) * 6, -6, 6);
        targetPupilX = clamp((dx / 160) * 2.8, -3.0, 3.0);
        targetPupilY = clamp((dy / 120) * 2.8, -1.5, 3.0);
        targetBrowY = -2.5;
        targetCurious = 0.25;
      } else if (isCelebrating) {
        // Beaming happy celebration as ticket enters laptop & paper plane launches!
        const bounce = Math.sin((st.T - TL) * 9) * Math.exp(-(st.T - TL) * 0.8) * 4.5;
        targetHeadDeg = bounce;
        targetBrowY = -3.6;
        targetHappy = 1;
      }

      // Smoothly interpolate expression parameters
      const sm = 1 - Math.exp(-dt * 7.5);
      st.headAngle = lerp(st.headAngle, targetHeadDeg, sm);
      st.pupilX = lerp(st.pupilX, targetPupilX, sm);
      st.pupilY = lerp(st.pupilY, targetPupilY, sm);
      st.browY = lerp(st.browY, targetBrowY, sm);
      st.curiousAlpha = lerp(st.curiousAlpha, targetCurious, sm);
      st.happyAlpha = lerp(st.happyAlpha, targetHappy, sm);

      if (refs.headGroup) {
        refs.headGroup.style.transform = `rotate(${st.headAngle.toFixed(2)}deg)`;
      }
      if (refs.torsoGroup) {
        const breath = Math.sin(clock * 2.3) * 0.7;
        const happyBounce = isCelebrating
          ? Math.abs(Math.sin((st.T - TL) * 7.5)) *
            Math.exp(-(st.T - TL) * 0.9) *
            -2.8
          : 0;
        refs.torsoGroup.style.transform = `translateY(${(
          breath + happyBounce
        ).toFixed(2)}px)`;
      }
      if (refs.pupilsGroup) {
        refs.pupilsGroup.style.transform = `translate(${st.pupilX.toFixed(
          2
        )}px, ${st.pupilY.toFixed(2)}px)`;
      }
      if (refs.browsGroup) {
        refs.browsGroup.style.transform = `translateY(${st.browY.toFixed(2)}px)`;
      }

      // Natural periodic blinking when normal eyes are visible
      const blinkCycle = clock % 3.4;
      const isBlinking = blinkCycle > 3.24 && blinkCycle < 3.38;
      if (refs.eyelidsGroup) {
        refs.eyelidsGroup.style.transform = `scaleY(${isBlinking ? 1 : 0})`;
      }

      // Cross-fade between normal eyes and joyful crinkled happy eyes (^ ^)
      if (refs.normalEyesGroup && refs.happyEyesGroup) {
        refs.normalEyesGroup.setAttribute(
          'opacity',
          String(clamp(1 - st.happyAlpha * 1.25, 0, 1))
        );
        refs.happyEyesGroup.setAttribute(
          'opacity',
          String(clamp(st.happyAlpha * 1.15, 0, 1))
        );
      }

      // Cross-fade between Calm Smile, Curious "o", and Happy Open Grin
      const calmAlpha = clamp(1 - st.curiousAlpha - st.happyAlpha, 0, 1);
      if (refs.mouthCalm) {
        refs.mouthCalm.setAttribute('opacity', String(calmAlpha));
      }
      if (refs.mouthCurious) {
        refs.mouthCurious.setAttribute('opacity', String(st.curiousAlpha));
      }
      if (refs.mouthHappy) {
        refs.mouthHappy.setAttribute('opacity', String(st.happyAlpha));
      }
      if (refs.cheeksGroup) {
        refs.cheeksGroup.setAttribute(
          'opacity',
          String(0.6 + st.happyAlpha * 0.35)
        );
      }

      // Typing hands animation (active while typing, paused while watching bird)
      const typingAmp = isWatchingBird || isWatchingDrop ? 0.15 : 1;
      if (refs.handL) {
        const dyL = Math.sin(clock * 15) * 1.7 * typingAmp;
        refs.handL.style.transform = `translateY(${dyL.toFixed(2)}px)`;
      }
      if (refs.handR) {
        const dyR = Math.cos(clock * 17) * 1.7 * typingAmp;
        refs.handR.style.transform = `translateY(${dyR.toFixed(2)}px)`;
      }

      // Laptop screen emerald glow when ticket arrives
      if (refs.laptopGlow) {
        const glowAlpha =
          st.T >= TL && st.T < TL + 3.2
            ? Math.sin(clamp((st.T - TL) / 3.2, 0, 1) * Math.PI) * 0.75
            : 0;
        refs.laptopGlow.setAttribute('opacity', glowAlpha.toFixed(2));
      }
    };

    rafId = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('pointermove', onPointerMove);
    };
  }, [restartAnimation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    restartAnimation();
    setAuthBtnText('Authenticating…');
    window.setTimeout(() => {
      setAuthBtnText('Initialize auth');
    }, 1800);
  };

  return (
    <>
      {/* Hidden SVG pattern definition for paper grain overlay */}
      <svg width="0" height="0" style={{ position: 'absolute' }} aria-hidden="true">
        <defs>
          <pattern id="g" patternUnits="userSpaceOnUse" width="160" height="160">
            <image ref={grainImgRef} id="gi" width="160" height="160" />
          </pattern>
        </defs>
      </svg>

      {/* Sky backdrop */}
      <div className="sky" />

      {/* Hanging Sun (raised higher) & 5 Paper-Cut Clouds (all clear above hills) */}
      <div className="layer" id="hang" ref={hangRef} style={{ zIndex: 1 }} />

      {/* Multi-layered scissor-cut mountains, pines, and ground */}
      <div className="layer cut" id="l1" ref={l1Ref} style={{ zIndex: 2 }}>
        <svg />
      </div>
      <div className="layer cut" id="l2" ref={l2Ref} style={{ zIndex: 3 }}>
        <svg />
      </div>
      <div className="layer cut" id="l3" ref={l3Ref} style={{ zIndex: 4 }}>
        <svg />
      </div>
      <div className="layer cut" id="l4" ref={l4Ref} style={{ zIndex: 5 }}>
        <svg />
      </div>
      <div className="layer cut" id="l5" ref={l5Ref} style={{ zIndex: 6 }}>
        <svg />
      </div>
      <div className="layer cut" id="l6" ref={l6Ref} style={{ zIndex: 7 }}>
        <svg />
      </div>

      {/* Ground shadow & Smaller Rebuilt Layered Paper-Cut Girl with Dynamic Expressions */}
      <div id="gs" ref={girlShadowRef} />
      <div
        id="girl-wrap"
        ref={girlWrapRef}
        title="Click to replay mail delivery"
      >
        <PaperCutGirl animRefs={girlAnimRefs} onClick={restartAnimation} />
      </div>

      {/* Foreground bottom grass silhouette */}
      <div className="layer cut" id="l7" ref={l7Ref} style={{ zIndex: 12 }}>
        <svg />
      </div>

      {/* High-DPI Canvas for 3D Kinematic Paper Dove (holding mail in beak, bent legs) & Falling Mail */}
      <canvas
        id="bird-canvas"
        ref={birdCanvasRef}
        aria-label="A white layered paper-cut dove enters from the left carrying a letter in its beak, drops the letter to the girl on the ground, and exits to the right."
      />

      {/* Ticket Notification Badge, Ring Pulse & Paper Airplane */}
      <div className="fx" id="msg" ref={msgRef}>
        <b>✓</b>Ticket created
      </div>
      <div className="fx" id="ring" ref={ringRef} />
      <svg
        className="fx"
        id="pl"
        ref={planeRef}
        width="38"
        height="30"
        viewBox="0 0 38 30"
      >
        <path
          fill="#fbf4e4"
          stroke="#b89a6a"
          strokeWidth="0.7"
          d="M0 14L38 0L26 30L18 18Z"
        />
        <path fill="#e3d4b3" d="M18 18L38 0L20 22Z" />
      </svg>

      {/* Left Login Column (Request gateway access & V4.1.0-GREEN removed from bottom) */}
      <div className="col">
        <div className="brand wrap-shadow">
          <div className="tag">
            <span className="hole" />
            <svg
              ref={logoSvgRef}
              id="logo"
              viewBox="0 0 120 112"
              role="img"
              aria-label="UbiDesk logo"
            />
            <div className="word">
              Ubi<i>Desk</i>
            </div>
            <p>Sign in to your desk</p>
          </div>
        </div>

        <form className="auth-form" onSubmit={handleSubmit} autoComplete="off">
          <label htmlFor="uid">Enter ID // Email</label>
          <div className="fld">
            <input
              id="uid"
              placeholder="UID // e.g. admin"
              autoComplete="username"
            />
          </div>

          <label htmlFor="pw">Enter password</label>
          <div className="fld">
            <input
              id="pw"
              type={showPassword ? 'text' : 'password'}
              placeholder="••••••••••••"
              autoComplete="current-password"
            />
            <button
              type="button"
              id="eye"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              onClick={() => setShowPassword((prev) => !prev)}
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              >
                <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" />
                <circle cx="12" cy="12" r="3" />
                {!showPassword && <path id="slash" d="M4 4l16 16" />}
              </svg>
            </button>
          </div>

          <a
            className="forgot"
            href="#forgot"
            onClick={(e) => {
              e.preventDefault();
              restartAnimation();
            }}
          >
            Forgot password?
          </a>

          <div className="cta">
            <div className="fld">
              <button type="submit" id="go">
                {authBtnText}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Subtle Replay Button for convenience */}
      <div className="replay-chip-wrap">
        <button
          type="button"
          className="replay-chip"
          onClick={restartAnimation}
        >
          Replay
        </button>
      </div>

      {/* Warm paper vignette */}
      <div className="vig" />
    </>
  );
}
