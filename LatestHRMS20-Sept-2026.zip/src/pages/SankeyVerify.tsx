import { useEffect, useRef } from 'react';
import { paintChart, themeColors, activePalette } from '../shared/Charts';

/**
 * Temporary visual-verification harness for Sankey 3D (removed after check).
 * Renders the exact QA hiring-funnel dataset at m=1 (full 3D) on a plain
 * canvas, then exposes a ready flag + PNG export for Playwright capture.
 */
const LINKS = [
  { value: 120, source: 'Referrals', target: 'Screened' },
  { value: 260, source: 'Job boards', target: 'Screened' },
  { value: 180, source: 'LinkedIn', target: 'Screened' },
  { value: 210, source: 'Screened', target: 'Interviewed' },
  { value: 350, source: 'Screened', target: 'Rejected' },
  { value: 64, source: 'Interviewed', target: 'Offered' },
  { value: 146, source: 'Interviewed', target: 'Rejected' },
  { value: 48, source: 'Offered', target: 'Hired' },
  { value: 16, source: 'Offered', target: 'Declined' },
];

export default function SankeyVerify() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const W = 1160, H = 640;
    const dpr = 1;
    cv.width = W * dpr;
    cv.height = H * dpr;
    cv.style.width = `${W}px`;
    cv.style.height = `${H}px`;
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const pal = activePalette();
    paintChart(ctx, 'sankey', {
      W, H,
      t: themeColors(true),
      p: 1,
      m: 1,
      hov: { idx: null, seg: null, amt: 0 },
      data: [],
      colors: [],
      multi: false,
      cats: [],
      series: [],
      sColors: [],
      full: true,
      bg: '#f4f5f3',
      links: LINKS,
      orbit: { yaw: -0.30, pitch: 0.30 },
    });
    (window as unknown as { __sankeyReady?: boolean }).__sankeyReady = true;
    void pal;
  }, []);

  return (
    <div style={{ background: '#f4f5f3', minHeight: '100vh', padding: 24 }}>
      <h1 style={{ fontFamily: 'sans-serif', fontSize: 18, marginBottom: 12 }}>
        Sankey 3D verification (m=1, QA hiring funnel)
      </h1>
      <canvas ref={ref} />
    </div>
  );
}
