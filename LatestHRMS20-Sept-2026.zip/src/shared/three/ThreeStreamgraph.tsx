import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import type { ThreeChartHandle } from './ThreeSankey3D';
import type { ExportTheme } from './exportUtils';
import { buildThreePNG, withExportResolution } from './exportUtils';
import {
  NUM_QUARTERS, START_YEAR, STREAM_EMPLOYEES, STREAM_MILESTONES,
  buildRawMatrix, buildDisplayMatrix, splineSamples, stackCentered,
  quarterToNormX, normXToRealQuarter, quarterLabel,
  seriesToEmployees, type StreamEmployee,
} from './streamModel';
import type { StackedSeries } from '../Charts';

/* ============================================================
   Three.js Streamgraph — ported from Streamgraph3DTest.html.
   Structure / camera / lighting / river-flow plotting preserved:
   - 40-quarter monotonic-Hermite river with tapered lead-in tip,
     centered stacking, ghost hairlines for departed employees
   - Volumetric closed ribbons (front/back/top/bottom/end caps)
   - Camera presets: 3D oblique (-81,42,117), 2D head-on (0,0,138),
     ribbon Z-spread morphs 1→0 between them
   - Key/fill/rim studio rig + ACES + soft shadows + grid floor
   - Hover: dim others, emissive glow + lift, dashed crosshair + dot
   - Highcharts-style milestone callouts with collision avoidance
   Colors: glossy Sankey-3D family (app palette), NOT the ref palette.
   CPU/GPU opts: DPR cap, render-on-demand, shared geos, adaptive steps.
   ============================================================ */

interface Props {
  categories?: string[];
  series?: StackedSeries[];
  palette: string[];
  dim: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (idx: number | null, text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

const NUM_STEPS = 160;
const TOTAL_WIDTH = 135;
const HEIGHT_SCALE = 0.024;
const Z_TOTAL_SPAN = 22;
const FLOOR_Y = -22;
const HEIGHT_EPS = 0.0008;

function escXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

const ThreeStreamgraph = forwardRef<ThreeChartHandle, Props>(function ThreeStreamgraph(
  { categories, series, palette, dim, hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; name: string; sub: string; comp: string; total: string } | null>(null);
  const [zoomOn, setZoomOn] = useState(false);

  const api = useRef<{
    renderer: THREE.WebGLRenderer;
    labelRenderer: CSS2DRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    setMode: (m: '2D' | '3D') => void;
    setZoom: (on: boolean) => void;
    hoverSeries: (i: number | null) => void;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container: HTMLDivElement = containerRef.current!;
    if (!containerRef.current) return;

    /* ---- dataset: live series win, else the built-in company story ---- */
    let emps: StreamEmployee[];
    if (series && series.length >= 2 && (categories || []).length >= 2) {
      emps = seriesToEmployees(categories || [], series);
    } else {
      emps = STREAM_EMPLOYEES.map((e) => ({ ...e }));
    }
    const S = emps.length;
    emps.forEach((e, i) => { e.color = e.color || palette[i % palette.length]; });
    const Z_STEP = Z_TOTAL_SPAN / Math.max(1, S);

    const { values: rawValues, totals: rawTotals } = buildRawMatrix(emps);
    const display = buildDisplayMatrix(emps, rawValues);
    const sampled = emps.map((_, s) => splineSamples(display[s], NUM_STEPS));
    const { bottom: stackBottom, top: stackTop } = stackCentered(sampled, HEIGHT_SCALE, TOTAL_WIDTH);

    /* ---- renderer / scene (reference setup, DPR capped) ---- */
    const scene = new THREE.Scene();
    const W0 = container.clientWidth || 700, H0 = container.clientHeight || 420;
    const camera = new THREE.PerspectiveCamera(36, W0 / H0, 1, 1000);
    camera.position.set(-81, 42, 117);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.setSize(W0, H0);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.setSize(W0, H0);
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.target.set(0, -1, 0);
    controls.minDistance = 30;
    controls.maxDistance = 320;
    controls.maxPolarAngle = Math.PI / 2 + 0.05;
    controls.enableZoom = false;

    scene.add(new THREE.AmbientLight(0xffffff, 1.1));
    const keyLight = new THREE.DirectionalLight(0xfffbeb, 2.2);
    keyLight.position.set(-52, 65, 68);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 10;
    keyLight.shadow.camera.far = 260;
    keyLight.shadow.camera.left = -85;
    keyLight.shadow.camera.right = 85;
    keyLight.shadow.camera.top = 85;
    keyLight.shadow.camera.bottom = -85;
    keyLight.shadow.bias = -0.0003;
    scene.add(keyLight);
    const fillLight = new THREE.DirectionalLight(0xc7d2fe, 0.9);
    fillLight.position.set(68, -10, -60);
    scene.add(fillLight);
    const rimLight = new THREE.DirectionalLight(0xffffff, 0.7);
    rimLight.position.set(0, 30, -75);
    scene.add(rimLight);

    const shadowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(360, 360),
      new THREE.ShadowMaterial({ opacity: 0.1 }),
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = FLOOR_Y;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);
    const gridHelper = new THREE.GridHelper(240, 60, dark ? 0x3a4a5a : 0x94a3b8, dark ? 0x2a3542 : 0xe2e8f0);
    gridHelper.position.y = FLOOR_Y - 0.05;
    (gridHelper.material as THREE.Material).transparent = true;
    (gridHelper.material as THREE.Material).opacity = dark ? 0.35 : 0.8;
    scene.add(gridHelper);

    /* ---- volumetric ribbons (reference §4, verbatim topology) ---- */
    const ribbonGroup = new THREE.Group();
    scene.add(ribbonGroup);
    const ribbonMeshes: THREE.Mesh<THREE.BufferGeometry, THREE.MeshPhysicalMaterial>[] = [];
    const labelObjs: CSS2DObject[] = [];
    const ribbonDepth = 1.5;
    const zFront = ribbonDepth / 2, zBack = -ribbonDepth / 2;

    emps.forEach((emp, s) => {
      let firstActiveIdx = 0;
      while (firstActiveIdx < NUM_STEPS &&
        (stackTop[s][firstActiveIdx].y - stackBottom[s][firstActiveIdx].y) < HEIGHT_EPS) firstActiveIdx++;
      if (firstActiveIdx >= NUM_STEPS) return;

      const zCenter3D = (s - S / 2) * Z_STEP;
      const positions: number[] = [], normals: number[] = [], uvs: number[] = [], indices: number[] = [];
      let vertCount = 0;
      const V3 = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
      function addQuad(p1: THREE.Vector3, p2: THREE.Vector3, p3: THREE.Vector3, p4: THREE.Vector3, norm: THREE.Vector3) {
        positions.push(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, p3.x, p3.y, p3.z, p4.x, p4.y, p4.z);
        for (let k = 0; k < 4; k++) normals.push(norm.x, norm.y, norm.z);
        uvs.push(0, 0, 1, 0, 1, 1, 0, 1);
        indices.push(vertCount, vertCount + 1, vertCount + 2, vertCount, vertCount + 2, vertCount + 3);
        vertCount += 4;
      }
      for (let i = firstActiveIdx; i < NUM_STEPS; i++) {
        const b0 = stackBottom[s][i], b1 = stackBottom[s][i + 1];
        const t0 = stackTop[s][i], t1 = stackTop[s][i + 1];
        addQuad(V3(b0.x, b0.y, zFront), V3(b1.x, b1.y, zFront), V3(t1.x, t1.y, zFront), V3(t0.x, t0.y, zFront), V3(0, 0, 1));
        addQuad(V3(b1.x, b1.y, zBack), V3(b0.x, b0.y, zBack), V3(t0.x, t0.y, zBack), V3(t1.x, t1.y, zBack), V3(0, 0, -1));
        const topNorm = V3(-(t1.y - t0.y), t1.x - t0.x, 0).normalize();
        addQuad(V3(t0.x, t0.y, zFront), V3(t1.x, t1.y, zFront), V3(t1.x, t1.y, zBack), V3(t0.x, t0.y, zBack), topNorm);
        const botNorm = V3(b1.y - b0.y, -(b1.x - b0.x), 0).normalize();
        addQuad(V3(b1.x, b1.y, zFront), V3(b0.x, b0.y, zFront), V3(b0.x, b0.y, zBack), V3(b1.x, b1.y, zBack), botNorm);
      }
      const startB = stackBottom[s][firstActiveIdx], startT = stackTop[s][firstActiveIdx];
      addQuad(V3(startB.x, startB.y, zBack), V3(startB.x, startB.y, zFront), V3(startT.x, startT.y, zFront), V3(startT.x, startT.y, zBack), V3(-1, 0, 0));
      const endB = stackBottom[s][NUM_STEPS], endT = stackTop[s][NUM_STEPS];
      addQuad(V3(endB.x, endB.y, zFront), V3(endB.x, endB.y, zBack), V3(endT.x, endT.y, zBack), V3(endT.x, endT.y, zFront), V3(1, 0, 0));

      const geom = new THREE.BufferGeometry();
      geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geom.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      geom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
      geom.setIndex(indices);
      geom.computeVertexNormals();

      const mat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(emp.color),
        roughness: 0.28, metalness: 0.1,
        clearcoat: 0.7, clearcoatRoughness: 0.2,
        side: THREE.DoubleSide, transparent: true, opacity: 1,
        emissive: new THREE.Color(emp.color), emissiveIntensity: 0,
      });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.position.z = zCenter3D;
      mesh.userData = {
        emp, s, z3D: zCenter3D, z2D: s * 0.005,
        currentLift: 0, targetLift: 0, targetOpacity: 1, targetEmissive: 0,
      };
      ribbonGroup.add(mesh);
      ribbonMeshes.push(mesh);

      if (emp.labelQ !== undefined) {
        const stepIdx = Math.round(quarterToNormX(emp.labelQ) * NUM_STEPS);
        const posX = stackBottom[s][stepIdx].x;
        const posY = (stackBottom[s][stepIdx].y + stackTop[s][stepIdx].y) / 2;
        const div = document.createElement('div');
        div.className = 'sg-employee-tag';
        div.textContent = emp.name;
        div.style.fontFamily = theme.fontBody;
        const labelObj = new CSS2DObject(div);
        labelObj.position.set(posX, posY, zFront + 0.3);
        mesh.add(labelObj);
        labelObjs.push(labelObj);
      }
      if (!emp.intervals && (emp.end ?? NUM_QUARTERS - 1) < NUM_QUARTERS - 1) {
        const stepIdx = Math.round(quarterToNormX(emp.end ?? 0) * NUM_STEPS);
        const posX = stackBottom[s][stepIdx].x;
        const posY = (stackBottom[s][stepIdx].y + stackTop[s][stepIdx].y) / 2;
        const div = document.createElement('div');
        div.className = 'sg-employee-tag sg-ghost';
        div.textContent = `${emp.name} ✗`;
        div.style.fontFamily = theme.fontBody;
        const labelObj = new CSS2DObject(div);
        labelObj.position.set(posX, posY + 0.6, zFront + 0.3);
        mesh.add(labelObj);
        labelObjs.push(labelObj);
      }
    });

    /* ---- timeline axis (reference §5) ---- */
    const axisMat = new THREE.LineBasicMaterial({ color: dark ? 0x5a6a7a : 0xcfd8dc });
    for (let i = 0; i < NUM_QUARTERS; i++) {
      if (i % 4 !== 0 && i !== NUM_QUARTERS - 1) continue;
      const x = (quarterToNormX(i) - 0.5) * TOTAL_WIDTH;
      const lineGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(x, FLOOR_Y, -Z_TOTAL_SPAN / 2 - 3),
        new THREE.Vector3(x, FLOOR_Y, Z_TOTAL_SPAN / 2 + 5),
      ]);
      scene.add(new THREE.Line(lineGeo, axisMat));
      const div = document.createElement('div');
      div.className = 'sg-axis-label';
      div.textContent = `${START_YEAR + Math.floor(i / 4)} Q1`;
      div.style.fontFamily = theme.fontBody;
      if (dark) div.style.color = '#9fb2c5';
      const labelObj = new CSS2DObject(div);
      labelObj.position.set(x, FLOOR_Y - 0.2, Z_TOTAL_SPAN / 2 + 7);
      scene.add(labelObj);
      labelObjs.push(labelObj);
    }

    /* ---- milestone callouts (reference §6, container-scoped) ---- */
    const NS = 'http://www.w3.org/2000/svg';
    const svg = svgRef.current;
    const milestoneItems = STREAM_MILESTONES.map((m) => {
      const x = (quarterToNormX(m.q) - 0.5) * TOTAL_WIDTH;
      const worldPos = new THREE.Vector3(x, m.yPeak, Z_TOTAL_SPAN / 2 + 3.5);
      const box = document.createElement('div');
      box.className = 'sg-callout';
      box.style.fontFamily = theme.fontBody;
      box.innerHTML = `<strong>${escXml(m.title)}</strong><span>${escXml(m.text)}</span>`;
      container.appendChild(box);
      let line: SVGLineElement | null = null, circle: SVGCircleElement | null = null;
      if (svg) {
        line = document.createElementNS(NS, 'line');
        svg.appendChild(line);
        circle = document.createElementNS(NS, 'circle');
        circle.setAttribute('r', '3.2');
        svg.appendChild(circle);
      }
      return { m, worldPos, box, line, circle, boxCenterX: 0 };
    });
    const BOX_W = 148, BOX_M = 10;
    const projV = new THREE.Vector3();
    function updateMilestones() {
      const cw = container.clientWidth || 700;
      const rows = milestoneItems.map((item) => {
        projV.copy(item.worldPos).project(camera);
        return {
          item,
          x: (projV.x * 0.5 + 0.5) * cw,
          y: (-projV.y * 0.5 + 0.5) * (container.clientHeight || 420),
          visible: projV.z < 1,
        };
      });
      rows.sort((a, b) => a.x - b.x);
      let lastRight = -Infinity;
      rows.forEach((r) => {
        let left = r.x - BOX_W / 2;
        if (left < lastRight + BOX_M) left = lastRight + BOX_M;
        left = Math.max(6, Math.min(cw - BOX_W - 6, left));
        lastRight = left + BOX_W;
        r.item.boxCenterX = left + BOX_W / 2;
      });
      const rowTop = 8;
      rows.forEach((r) => {
        const { item, visible, x: ax, y: ay } = r;
        item.box.style.left = `${item.boxCenterX}px`;
        item.box.style.top = `${rowTop}px`;
        item.box.classList.toggle('visible', visible);
        const boxBottom = rowTop + (item.box.offsetHeight || 44);
        if (item.line) {
          item.line.setAttribute('x1', String(item.boxCenterX));
          item.line.setAttribute('y1', String(boxBottom));
          item.line.setAttribute('x2', String(ax));
          item.line.setAttribute('y2', String(ay));
          item.line.style.opacity = visible ? '0.9' : '0';
        }
        if (item.circle) {
          item.circle.setAttribute('cx', String(ax));
          item.circle.setAttribute('cy', String(ay));
          item.circle.style.opacity = visible ? '1' : '0';
        }
      });
    }

    /* ---- camera presets + spread morph (reference §7) ---- */
    const viewPresets = {
      view3D: { camPos: new THREE.Vector3(-81, 42, 117), target: new THREE.Vector3(0, -1, 0), spreadZ: 1.0 },
      view2D: { camPos: new THREE.Vector3(0, 0, 138), target: new THREE.Vector3(0, 0, 0), spreadZ: 0.0 },
    };
    let currentSpread = dim === '3d' ? 1 : 0;
    let targetSpread = currentSpread;
    const targetCamPos = camera.position.clone();
    const targetCamFocus = controls.target.clone();
    let isTransitioning = false;
    function setMode(m: '2D' | '3D') {
      const p = m === '3D' ? viewPresets.view3D : viewPresets.view2D;
      targetCamPos.copy(p.camPos);
      targetCamFocus.copy(p.target);
      targetSpread = p.spreadZ;
      isTransitioning = true;
    }
    setMode(dim === '3d' ? '3D' : '2D');
    // snap instantly on mount (no opening swoop)
    camera.position.copy(targetCamPos);
    controls.target.copy(targetCamFocus);
    currentSpread = targetSpread;
    isTransitioning = false;

    /* ---- hover: raycast + crosshair (reference §8) ---- */
    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    let hoveredMesh: THREE.Mesh | null = null;
    let hoverStepIdx: number | null = null;
    let hoverSeriesIdx: number | null = null;
    function setHoverTargets(hoveredM: THREE.Mesh | null) {
      ribbonMeshes.forEach((mm) => {
        const isH = mm === hoveredM;
        mm.userData.targetOpacity = hoveredM ? (isH ? 1 : 0.2) : 1;
        mm.userData.targetEmissive = isH ? 0.5 : 0;
        mm.userData.targetLift = isH ? 1.15 : 0;
      });
    }
    const crosshairLine = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
      new THREE.LineDashedMaterial({ color: dark ? 0xcbd5e1 : 0x0f172a, dashSize: 0.7, gapSize: 0.45, transparent: true, opacity: 0.4 }),
    );
    crosshairLine.visible = false;
    crosshairLine.frustumCulled = false;
    scene.add(crosshairLine);
    const crosshairDot = new THREE.Mesh(
      new THREE.SphereGeometry(0.26, 16, 16),
      new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.5, metalness: 0.3, roughness: 0.2 }),
    );
    crosshairDot.visible = false;
    scene.add(crosshairDot);

    function onPointerMove(e: PointerEvent) {
      const rect = container.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(ribbonMeshes, false);
      if (hits.length) {
        const mesh = hits[0].object as THREE.Mesh;
        const emp = mesh.userData.emp as StreamEmployee;
        if (hoveredMesh !== mesh) {
          hoveredMesh = mesh;
          setHoverTargets(mesh);
          onHover?.(mesh.userData.s, emp.name);
        }
        const normX = Math.max(0, Math.min(1, (hits[0].point.x / TOTAL_WIDTH) + 0.5));
        hoverStepIdx = Math.round(normX * NUM_STEPS);
        hoverSeriesIdx = mesh.userData.s;
        const qIdx = normXToRealQuarter(normX);
        const sal = rawValues[mesh.userData.s][qIdx] || 0;
        setTip({
          x: e.clientX - rect.left, y: e.clientY - rect.top,
          name: emp.name, sub: `${emp.role} · ${quarterLabel(qIdx)}`,
          comp: sal > 0 ? `₹${Math.round(sal * 1000).toLocaleString('en-IN')}/yr` : 'Inactive / Departed',
          total: `₹${Math.round((rawTotals[qIdx] || 0) * 1000).toLocaleString('en-IN')}/yr`,
        });
        container.style.cursor = 'pointer';
      } else if (hoveredMesh) {
        hoveredMesh = null;
        hoverStepIdx = null;
        hoverSeriesIdx = null;
        setHoverTargets(null);
        setTip(null);
        onHover?.(null, null);
        container.style.cursor = 'default';
      }
    }
    function onPointerLeave() {
      hoveredMesh = null;
      hoverStepIdx = null;
      hoverSeriesIdx = null;
      setHoverTargets(null);
      setTip(null);
      onHover?.(null, null);
    }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    function updateCrosshair() {
      if (hoveredMesh == null || hoverStepIdx == null || hoverSeriesIdx == null) {
        crosshairLine.visible = false;
        crosshairDot.visible = false;
        return;
      }
      const step = Math.max(0, Math.min(NUM_STEPS, hoverStepIdx));
      const x = stackBottom[0][step].x;
      const z = Z_TOTAL_SPAN / 2 + 3.6;
      crosshairLine.geometry.setFromPoints([
        new THREE.Vector3(x, stackBottom[0][step].y, z),
        new THREE.Vector3(x, stackTop[S - 1][step].y, z),
      ]);
      crosshairLine.computeLineDistances();
      crosshairLine.visible = true;
      crosshairDot.position.set(x, stackTop[hoverSeriesIdx][step].y, z);
      crosshairDot.visible = true;
    }

    function resize() {
      const W = container.clientWidth || 700, H = container.clientHeight || 420;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
    }
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    /* ---- render-on-demand loop (settled scenes park the GPU) ---- */
    let raf = 0;
    let settledFrames = 0;
    const lastCam = new THREE.Vector3(1e9, 1e9, 1e9);
    const animate = () => {
      raf = requestAnimationFrame(animate);
      const camMoved = camera.position.distanceToSquared(lastCam) > 1e-10;
      lastCam.copy(camera.position);
      const easing = ribbonMeshes.some((mm) =>
        Math.abs(mm.material.opacity - mm.userData.targetOpacity) > 0.004 ||
        Math.abs(mm.userData.currentLift - mm.userData.targetLift) > 0.004);
      const busy = isTransitioning || camMoved || easing || hoveredMesh !== null;
      if (!busy) {
        if (settledFrames === 0) { updateMilestones(); renderer.render(scene, camera); labelRenderer.render(scene, camera); }
        settledFrames++;
        return;
      }
      settledFrames = 0;
      if (isTransitioning) {
        camera.position.lerp(targetCamPos, 0.05);
        controls.target.lerp(targetCamFocus, 0.05);
        currentSpread += (targetSpread - currentSpread) * 0.05;
        if (camera.position.distanceTo(targetCamPos) < 0.08 && Math.abs(currentSpread - targetSpread) < 0.005) {
          isTransitioning = false;
          currentSpread = targetSpread;
        }
      }
      ribbonMeshes.forEach((mesh) => {
        const baseZ = THREE.MathUtils.lerp(mesh.userData.z2D, mesh.userData.z3D, currentSpread);
        mesh.userData.currentLift = THREE.MathUtils.lerp(mesh.userData.currentLift, mesh.userData.targetLift, 0.15);
        mesh.position.z = baseZ + mesh.userData.currentLift;
        mesh.material.opacity = THREE.MathUtils.lerp(mesh.material.opacity, mesh.userData.targetOpacity, 0.12);
        mesh.material.emissiveIntensity = THREE.MathUtils.lerp(mesh.material.emissiveIntensity, mesh.userData.targetEmissive, 0.12);
      });
      updateMilestones();
      updateCrosshair();
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    };
    animate();

    const dispose = () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      milestoneItems.forEach((it) => {
        it.box.remove();
        it.line?.remove();
        it.circle?.remove();
      });
      ribbonMeshes.forEach((mm) => { mm.geometry.dispose(); (mm.material as THREE.Material).dispose(); });
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement === container) container.removeChild(renderer.domElement);
      if (labelRenderer.domElement.parentElement === container) container.removeChild(labelRenderer.domElement);
    };

    api.current = {
      renderer, labelRenderer, scene, camera, controls, setMode,
      setZoom: (on: boolean) => { controls.enableZoom = on; },
      hoverSeries: (i: number | null) => {
        const target = i === null ? null : (ribbonMeshes[i] || null);
        hoveredMesh = target;
        setHoverTargets(target);
      },
      dispose,
    };
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [(categories || []).join('|'), JSON.stringify((series || []).map((s) => [s.name, s.values])), palette.join('|'), dark]);

  useEffect(() => { api.current?.setMode(dim === '3d' ? '3D' : '2D'); }, [dim]);
  useEffect(() => { api.current?.hoverSeries(hoverIndex ?? null); }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container.clientWidth, H = container.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(W, H, false);
      const cv = await buildThreePNG({
        title, imageDataUrl: dataUrl, chartW: W, chartH: H, labels: [],
        legend: [], theme, footnote: `Streamgraph · ${dim === '3d' ? '3D' : '2D'} view · 2015–2024`,
      });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      // Standalone vector river (reference §10 exporter, app-styled): the
      // SAME spline+stack model re-projected to 2D paths. True vector.
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container.clientWidth || 700, H = container.clientHeight || 420;
      let emps: StreamEmployee[];
      if (series && series.length >= 2 && (categories || []).length >= 2) {
        emps = seriesToEmployees(categories || [], series);
      } else {
        emps = STREAM_EMPLOYEES.map((e) => ({ ...e }));
      }
      emps.forEach((e, i) => { e.color = e.color || palette[i % palette.length]; });
      const { values: raw } = buildRawMatrix(emps);
      const disp = buildDisplayMatrix(emps, raw);
      const samp = emps.map((_, s) => splineSamples(disp[s], NUM_STEPS));
      const { bottom, top } = stackCentered(samp, HEIGHT_SCALE, TOTAL_WIDTH);
      const padX = 70, padTop = 64, padBot = 44;
      const drawW = W - padX * 2, drawH = H - padTop - padBot;
      const cy = padTop + drawH / 2;
      let maxAbs = 0.001;
      top.forEach((row) => row.forEach((pt) => { maxAbs = Math.max(maxAbs, Math.abs(pt.y)); }));
      bottom.forEach((row) => row.forEach((pt) => { maxAbs = Math.max(maxAbs, Math.abs(pt.y)); }));
      const scY = (drawH / 2 / maxAbs) * 0.96;
      let paths = '';
      emps.forEach((emp, s) => {
        let dTop = '', dBot = '';
        for (let i = 0; i <= NUM_STEPS; i++) {
          const x = padX + samp[0][i].x * drawW;
          const yT = cy - top[s][i].y * scY;
          const yB = cy - bottom[s][i].y * scY;
          if (i === 0) { dTop += `M ${x.toFixed(1)} ${yT.toFixed(1)}`; dBot = `L ${x.toFixed(1)} ${yB.toFixed(1)}`; }
          else { dTop += ` L ${x.toFixed(1)} ${yT.toFixed(1)}`; dBot = ` L ${x.toFixed(1)} ${yB.toFixed(1)}` + dBot; }
        }
        paths += `  <path d="${dTop} ${dBot} Z" fill="${emp.color}" opacity="0.94" stroke="#ffffff" stroke-width="0.8"/>\n`;
      });
      let miles = '';
      STREAM_MILESTONES.forEach((m) => {
        const mx = padX + quarterToNormX(m.q) * drawW;
        miles += `  <line x1="${mx.toFixed(1)}" y1="${padTop - 8}" x2="${mx.toFixed(1)}" y2="${H - padBot + 8}" stroke="#cbd5e1" stroke-dasharray="4,4" stroke-width="1.2"/>\n`;
        miles += `  <circle cx="${mx.toFixed(1)}" cy="${padTop - 8}" r="3.4" fill="#b45309"/>\n`;
        miles += `  <text x="${mx.toFixed(1)}" y="${padTop - 26}" text-anchor="middle" class="sgm-title">${escXml(m.title)}</text>\n`;
      });
      let axis = '';
      for (let i = 0; i < NUM_QUARTERS; i += 4) {
        const ax = padX + quarterToNormX(i) * drawW;
        axis += `  <text x="${ax.toFixed(1)}" y="${H - padBot + 22}" text-anchor="middle" class="sgm-axis">${START_YEAR + i / 4} Q1</text>\n`;
      }
      return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs><style>
    text { font-family: ${escXml(theme.fontBody)}; }
    .sgm-head { font-family: ${escXml(theme.fontDisplay)}; font-size: 15px; font-weight: 700; fill: #1c2620; }
    .sgm-sub { font-size: 11px; fill: #64748b; }
    .sgm-axis { font-size: 10px; font-weight: 600; fill: #64748b; }
    .sgm-title { font-size: 10.5px; font-weight: 700; fill: #b45309; }
  </style></defs>
  <rect width="100%" height="100%" fill="#ffffff"/>
  <text x="14" y="24" class="sgm-head">${escXml(title)}</text>
  <text x="14" y="40" class="sgm-sub">10-year salary river · 2015–2024 · ${dim === '3d' ? '3D' : '2D'} view</text>
  <g>${paths}</g>
  <g>${miles}</g>
  <g>${axis}</g>
</svg>`;
    },
    setZoom: (on: boolean) => { setZoomOn(on); api.current?.setZoom(on); },
  }), [categories, series, palette, theme, dim, dark]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full overflow-hidden">
      <svg ref={svgRef} className="sg-connector" />
      <button
        onClick={(e) => { e.stopPropagation(); const next = !zoomOn; setZoomOn(next); api.current?.setZoom(next); }}
        data-tip={zoomOn ? 'Scroll-zoom: on' : 'Scroll-zoom: off'}
        className={`absolute left-2 top-2 z-10 rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${zoomOn ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
        title={zoomOn ? 'Turn scroll-zoom off' : 'Turn scroll-zoom on'}
      >
        {zoomOn ? '🔍+ on' : '🔍+ off'}
      </button>
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 min-w-[190px] max-w-[250px] px-3 py-2"
          style={{ left: Math.min(tip.x + 14, (containerRef.current?.clientWidth || 300) - 220), top: Math.max(4, tip.y - 90) }}>
          <p className="font-body text-[12.5px] font-bold text-ink">{tip.name}</p>
          <p className="font-body text-[10.5px] text-muted">{tip.sub}</p>
          <p className="mt-1 flex justify-between font-body text-[11px]"><span className="text-muted">Salary</span><span className="font-bold text-primary">{tip.comp}</span></p>
          <p className="flex justify-between font-body text-[11px]"><span className="text-muted">Quarter total</span><span className="font-bold text-ink">{tip.total}</span></p>
        </div>
      )}
    </div>
  );
});

export default ThreeStreamgraph;
