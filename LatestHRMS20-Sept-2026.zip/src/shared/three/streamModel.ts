/* Streamgraph dataset model — ported from Streamgraph3DTest.html (structure preserved).
 * 40 quarters (2015 Q1 – 2024 Q4), per-employee salary intervals, bonus-year
 * multipliers, layoff windows, contractor spells, rejoiners. Colors come from
 * the app palette (glossy Sankey-3D family), NOT the reference's royal palette.
 * Pure data + math (no three.js) so the canvas fallback and the WebGL scene
 * share ONE model. */
import type { StackedSeries } from '../Charts';

export interface StreamEmployee {
  id: string; name: string; role: string;
  start?: number; end?: number;
  base?: number; growth?: number;
  intervals?: [number, number, number, number][]; // [startQ, endQ, base, growth]
  bonusMult?: number; labelQ?: number; tag?: string;
  color?: string;
}

export interface StreamMilestone { q: number; yPeak: number; year: string; title: string; text: string }

export const NUM_QUARTERS = 40;
export const START_YEAR = 2015;

export function quarterLabel(i: number): string {
  const yr = START_YEAR + Math.floor(i / 4);
  return `${yr} Q${(i % 4) + 1}`;
}

/* Default company story — same SHAPE as the reference (joins, exits,
 * contractors, layoffs, bonus year, rejoiners, AI wave) with app roster names. */
export const STREAM_EMPLOYEES: StreamEmployee[] = [
  { id: 'ananya', name: 'Ananya Rao', role: 'Co-Founder & CTO', start: 0, end: 39, base: 140, growth: 3.8, bonusMult: 1.45, labelQ: 20 },
  { id: 'vikram', name: 'Vikram Mehta', role: 'Principal Architect', intervals: [[0, 16, 115, 2.8], [32, 39, 250, 4.5]], bonusMult: 1.35, labelQ: 36, tag: 'Left & Rejoined' },
  { id: 'charlie', name: 'Charlie Davis', role: 'Sr. Frontend Lead', start: 0, end: 30, base: 90, growth: 2.1, labelQ: 14, tag: 'Laid Off 2022 · Never Returned' },
  { id: 'meera', name: 'Meera Nair', role: 'Staff Infra Eng', start: 2, end: 39, base: 100, growth: 2.7, bonusMult: 1.3, labelQ: 22 },
  { id: 'elena', name: 'Elena R', role: 'VP of Product', intervals: [[4, 20, 105, 3.2], [28, 39, 215, 3.9]], bonusMult: 1.4, labelQ: 30, tag: 'Rejoined' },
  { id: 'frank', name: 'Frank Zhang', role: 'Cloud Contractor', start: 12, end: 17, base: 175, growth: 0.5, labelQ: 15, tag: 'Contractor' },
  { id: 'grace', name: 'Grace Hopper', role: 'Security Specialist', start: 13, end: 18, base: 185, growth: 0.2, labelQ: 16, tag: 'Contractor' },
  { id: 'arjun', name: 'Arjun Patel', role: 'Director of AI', start: 8, end: 39, base: 130, growth: 5.2, bonusMult: 1.5, labelQ: 25, tag: 'Fast Climber' },
  { id: 'iris', name: 'Iris M', role: 'Design Lead', start: 9, end: 31, base: 92, growth: 1.9, labelQ: 22, tag: 'Laid Off 2022' },
  { id: 'rahul', name: 'Rahul Iyer', role: 'SecOps Lead', start: 14, end: 39, base: 110, growth: 2.4, bonusMult: 1.25, labelQ: 27 },
  { id: 'kiran', name: 'Kiran Patel', role: 'Staff Backend', start: 18, end: 39, base: 135, growth: 3.4, bonusMult: 1.35, labelQ: 32 },
  { id: 'sneha', name: 'Sneha Kulkarni', role: 'QA Director', start: 8, end: 32, base: 95, growth: 1.8, labelQ: 20, tag: 'Laid Off 2023' },
  { id: 'marcus', name: 'Marcus V', role: 'VP of Engineering', start: 22, end: 39, base: 260, growth: 3.4, bonusMult: 1.4, labelQ: 26 },
  { id: 'nina', name: 'Nina Simone', role: 'Lead LLM Scientist', start: 32, end: 39, base: 250, growth: 5.5, labelQ: 37, tag: 'AI Wave' },
  { id: 'oscar', name: 'Oscar I', role: 'Fullstack Eng', start: 24, end: 31, base: 120, growth: 1.6, labelQ: 28, tag: 'Laid Off 2022' },
  { id: 'priya', name: 'Priya Sharma', role: 'Growth Platforms', start: 26, end: 39, base: 125, growth: 2.5, bonusMult: 1.2, labelQ: 34 },
];

export const STREAM_MILESTONES: StreamMilestone[] = [
  { q: 14, yPeak: 14, year: '2018', title: 'Contractor Sprint', text: 'Rapid cloud migration & contractor influx' },
  { q: 21, yPeak: 11, year: '2020', title: 'Pandemic Shift', text: 'Remote workplace pivot, comp freeze implemented' },
  { q: 26, yPeak: 24, year: '2021', title: 'Tech Unicorn Boom', text: 'Record capital injection & bonuses up to +45%' },
  { q: 31, yPeak: 16, year: '2022', title: 'Market Correction', text: 'Workforce downsizing: 30% staff reduction' },
  { q: 36, yPeak: 21, year: '2024', title: 'Generative AI Era', text: 'Principal LLM scientists hired & key re-acquisitions' },
];

/** Salary of one employee at quarter t (reference formula, verbatim). */
export function salaryAt(emp: StreamEmployee, t: number): number {
  let sal = 0;
  if (emp.intervals) {
    emp.intervals.forEach(([s, e, b, g]) => {
      if (t >= s && t <= e) sal = b + (t - s) * g;
    });
  } else if (emp.start !== undefined && emp.end !== undefined) {
    if (t >= emp.start && t <= emp.end) sal = (emp.base || 0) + (t - emp.start) * (emp.growth || 0);
  }
  if (sal > 0 && t >= 24 && t <= 27) sal *= (emp.bonusMult || 1.3);
  return sal;
}

/** Raw 40-quarter matrix + per-quarter totals. */
export function buildRawMatrix(emps: StreamEmployee[]): { values: number[][]; totals: number[] } {
  const values: number[][] = emps.map(() => new Array(NUM_QUARTERS).fill(0));
  const totals = new Array(NUM_QUARTERS).fill(0);
  for (let t = 0; t < NUM_QUARTERS; t++) {
    emps.forEach((emp, s) => {
      const sal = salaryAt(emp, t);
      values[s][t] = sal;
      totals[t] += sal;
    });
  }
  return { values, totals };
}

/** Display matrix with ghost-height for departed-but-once-active employees
 * (reference verbatim — keeps departed ribbons visible as hairlines). */
export const GHOST_HEIGHT = 0.6;
export function buildDisplayMatrix(emps: StreamEmployee[], raw: number[][]): number[][] {
  const everActive = emps.map(() => false);
  return emps.map((_, s) => {
    const row = new Array(NUM_QUARTERS).fill(0);
    for (let t = 0; t < NUM_QUARTERS; t++) {
      const v = raw[s][t];
      if (v > 0) { everActive[s] = true; row[t] = v; }
      else if (everActive[s]) row[t] = GHOST_HEIGHT;
      else row[t] = 0;
    }
    return row;
  });
}

/* ---- monotonic Hermite spline (reference verbatim) ---- */
export function computeMonotonicTangents(ys: number[]): number[] {
  const n = ys.length;
  const d = new Array(n - 1);
  for (let i = 0; i < n - 1; i++) d[i] = ys[i + 1] - ys[i];
  const m = new Array(n);
  m[0] = d[0];
  m[n - 1] = d[n - 2];
  for (let i = 1; i < n - 1; i++) {
    if (d[i - 1] === 0 || d[i] === 0 || (d[i - 1] > 0) !== (d[i] > 0)) m[i] = 0;
    else m[i] = (d[i - 1] + d[i]) / 2;
  }
  for (let i = 0; i < n - 1; i++) {
    if (d[i] === 0) { m[i] = 0; m[i + 1] = 0; continue; }
    const a = m[i] / d[i], b = m[i + 1] / d[i];
    const s = a * a + b * b;
    if (s > 9) { const t = 3 / Math.sqrt(s); m[i] = t * a * d[i]; m[i + 1] = t * b * d[i]; }
  }
  return m;
}

function hermite(y0: number, y1: number, m0: number, m1: number, t: number): number {
  const t2 = t * t, t3 = t2 * t;
  const h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
  return h00 * y0 + h10 * m0 + h01 * y1 + h11 * m1;
}

export const EXT_LEAD_QUARTERS = 2; // virtual "zero" quarters prepended for the taper tip
export const EXT_QUARTERS = NUM_QUARTERS + EXT_LEAD_QUARTERS;

export function quarterToNormX(qIndexReal: number): number {
  return (qIndexReal + EXT_LEAD_QUARTERS) / (EXT_QUARTERS - 1);
}
export function normXToRealQuarter(normX: number): number {
  const extIdx = normX * (EXT_QUARTERS - 1);
  return Math.max(0, Math.min(NUM_QUARTERS - 1, Math.round(extIdx - EXT_LEAD_QUARTERS)));
}

/** Spline-sampled series (NUM_STEPS+1 samples of {x: normX, y}). */
export function splineSamples(displayRow: number[], numSteps: number): { x: number; y: number }[] {
  const ys = new Array(EXT_LEAD_QUARTERS).fill(0);
  for (let t = 0; t < NUM_QUARTERS; t++) ys.push(displayRow[t]);
  const m = computeMonotonicTangents(ys);
  const pts: { x: number; y: number }[] = [];
  for (let step = 0; step <= numSteps; step++) {
    const normX = step / numSteps;
    const scaledIdx = normX * (EXT_QUARTERS - 1);
    let seg = Math.floor(scaledIdx);
    if (seg >= EXT_QUARTERS - 1) seg = EXT_QUARTERS - 2;
    const t = scaledIdx - seg;
    const y = hermite(ys[seg], ys[seg + 1], m[seg], m[seg + 1], t);
    pts.push({ x: normX, y: Math.max(0, y) });
  }
  return pts;
}

/** Centered stacking → bottom/top boundaries per series per step. */
export function stackCentered(
  sampled: { x: number; y: number }[][], heightScale: number, totalWidth: number,
): { bottom: { x: number; y: number }[][]; top: { x: number; y: number }[][] } {
  const S = sampled.length, N = sampled[0].length;
  const bottom: { x: number; y: number }[][] = Array.from({ length: S }, () => []);
  const top: { x: number; y: number }[][] = Array.from({ length: S }, () => []);
  for (let step = 0; step < N; step++) {
    let totalH = 0;
    for (let s = 0; s < S; s++) totalH += Math.max(0, sampled[s][step].y);
    const normX = sampled[0][step].x;
    const x = (normX - 0.5) * totalWidth;
    let currentY = -totalH / 2;
    for (let s = 0; s < S; s++) {
      const val = Math.max(0, sampled[s][step].y);
      bottom[s].push({ x, y: currentY * heightScale });
      currentY += val;
      top[s].push({ x, y: currentY * heightScale });
    }
  }
  return { bottom, top };
}

/** Convert live multi-series chart data into the employee model when the
 * caller passes real series instead of using the built-in company story. */
export function seriesToEmployees(names: string[], series: StackedSeries[]): StreamEmployee[] {
  void names;
  return series.map((s, i) => {
    const vals = s.values || [];
    let start = vals.findIndex((v) => (v || 0) > 0);
    if (start < 0) start = 0;
    let end = vals.length - 1;
    while (end > start && !(vals[end] > 0)) end--;
    const span = Math.max(1, end - start);
    const base = vals[start] || 0;
    const growth = ((vals[end] || 0) - base) / span;
    // map the (possibly short) category axis onto the 40-quarter timeline
    const qStart = Math.round((start / Math.max(1, vals.length - 1)) * (NUM_QUARTERS - 1));
    const qEnd = Math.round((end / Math.max(1, vals.length - 1)) * (NUM_QUARTERS - 1));
    return {
      id: `series-${i}`, name: s.name, role: 'Series',
      start: qStart, end: Math.max(qStart, qEnd), base, growth,
      labelQ: Math.round((qStart + Math.max(qStart, qEnd)) / 2),
      color: s.color,
    };
  });
}
