/* Neumorphic tone helpers + canvas shadow utils (shared by painters). */
import type { ChartDatum, Theme } from '../core/types';
import { luma, shade, rgba, type Ctx } from '../core/utils';

export interface NeuTones { surface: string; hi: string; lo: string; shadowDark: string; shadowLight: string; groove: string; grooveHi: string; muted: string; grid: string }
export function neuTones(t: Theme): NeuTones {
  const dark = !!t.dark;
  const surface = t.surface || '#e4e7e0';
  return {
    surface,
    hi: shade(surface, dark ? 1.1 : 1.045),
    lo: shade(surface, dark ? 0.88 : 0.962),
    shadowDark: dark ? 'rgba(0,0,0,0.55)' : rgba(t.ink, 0.24),
    shadowLight: dark ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.92)',
    groove: dark ? 'rgba(0,0,0,0.5)' : rgba(t.ink, 0.14),
    grooveHi: dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.85)',
    muted: rgba(t.ink, 0.55),
    grid: rgba(t.ink, 0.16),
  };
}
export function setShadow(ctx: Ctx, x: number, y: number, blur: number, color: string) {
  ctx.shadowOffsetX = x; ctx.shadowOffsetY = y; ctx.shadowBlur = blur; ctx.shadowColor = color;
}
export function noShadow(ctx: Ctx) { ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; ctx.shadowColor = 'rgba(0,0,0,0)'; }
export function circle(ctx: Ctx, cx: number, cy: number, r: number) { ctx.beginPath(); ctx.arc(cx, cy, Math.max(0.1, r), 0, Math.PI * 2); ctx.closePath(); }
/** Extruded soft disc: dark shadow bottom-right, light shadow top-left, gentle sheen. */
export function raisedDisc(ctx: Ctx, cx: number, cy: number, r: number, n: NeuTones, spread = 1) {
  ctx.save();
  setShadow(ctx, 7 * spread, 7 * spread, 16 * spread, n.shadowDark); ctx.fillStyle = n.surface; circle(ctx, cx, cy, r); ctx.fill();
  setShadow(ctx, -6 * spread, -6 * spread, 14 * spread, n.shadowLight); circle(ctx, cx, cy, r); ctx.fill();
  noShadow(ctx);
  const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
  g.addColorStop(0, n.hi); g.addColorStop(1, n.lo);
  ctx.fillStyle = g; circle(ctx, cx, cy, r); ctx.fill();
  ctx.restore();
}
/** Inset groove ring (trench) — dark inner edge top-left, light edge bottom-right. */
export function grooveRing(ctx: Ctx, cx: number, cy: number, r: number, n: NeuTones, w = 2.6) {
  ctx.lineWidth = w; ctx.strokeStyle = n.groove; circle(ctx, cx - 0.7, cy - 0.7, r); ctx.stroke();
  ctx.lineWidth = w * 0.6; ctx.strokeStyle = n.grooveHi; circle(ctx, cx + 0.9, cy + 0.9, r); ctx.stroke();
  ctx.lineWidth = w * 0.45; ctx.strokeStyle = n.surface; circle(ctx, cx, cy, r); ctx.stroke();
  ctx.lineWidth = 1;
}
/** Inset track (rounded rect trench) for bars / columns / plot panels. */
export function insetTrack(ctx: Ctx, x: number, y: number, w: number, h: number, n: NeuTones, r?: number) {
  const rr = Math.min(r ?? h / 2, w / 2, h / 2);
  ctx.fillStyle = n.lo; ctx.beginPath(); ctx.roundRect(x, y, w, h, rr); ctx.fill();
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, n.groove); g.addColorStop(1, n.grooveHi);
  ctx.strokeStyle = g; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.roundRect(x + 0.6, y + 0.6, w - 1.2, h - 1.2, Math.max(0, rr - 0.6)); ctx.stroke();
  ctx.lineWidth = 1;
}
export function wedgePath(ctx: Ctx, cx: number, cy: number, R: number, rIn: number, a0: number, a1: number) {
  ctx.beginPath();
  if (rIn > 0) { ctx.arc(cx, cy, R, a0, a1); ctx.arc(cx, cy, rIn, a1, a0, true); ctx.closePath(); }
  else { ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, a0, a1); ctx.closePath(); }
}

export interface NeuDraw { data: ChartDatum[]; colors: string[]; t: Theme; p: number; hover: number | null; amt: number; centerLabel: string; full: boolean }

/* ---- circular: puck + groove ring + carved wedges + raised centre ---- */