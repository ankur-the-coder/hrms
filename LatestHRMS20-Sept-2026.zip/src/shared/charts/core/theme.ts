/* Theme tokens + palette. DOM reads isolated here. */
import { HONEST_PALETTE } from '../../../theme/themes';
import type { Theme } from './types';
import { luma } from './utils';

/** Brand palette — no purple, violet or indigo anywhere. */
export const PALETTE = ['#0d7a54', '#c9932b', '#0ea5e9', '#e11d63', '#f97316', '#14b8a6', '#1e5aa8', '#84cc16', '#f43f5e', '#a16207', '#06b6d4', '#64748b'];
/** Palette for the active theme — the Honest Paper theme brings Pie.’s slice colours with it. */
export function activePalette(): string[] {
  try { return document.documentElement.getAttribute('data-theme') === 'honest' ? HONEST_PALETTE : PALETTE; } catch { return PALETTE; }
}
export const font = (t: Theme | undefined, weight: number, size: number, display = false) =>
  `${weight} ${size}px ${display ? t?.fontDisplay || DEF_DISPLAY : t?.fontBody || DEF_BODY}`;
export const DEF_BODY = '"Outfit", ui-sans-serif, system-ui, sans-serif';
export const DEF_DISPLAY = '"Fraunces", Georgia, serif';
export function cssVar(name: string, fallback: string): string {
  try { return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback; } catch { return fallback; }
}
export function themeColors(forExport = false): Theme {
  const fontBody = cssVar('--t-font-body', DEF_BODY);
  const fontDisplay = cssVar('--t-font-display', DEF_DISPLAY);
  if (forExport) return { ink: '#1c2620', axis: '#39443d', grid: 'rgba(60,70,64,0.18)', surface: '#eef0ec', fontBody, fontDisplay, dark: false };
  const ink = cssVar('--t-ink', '#101914');
  const surface = cssVar('--t-surface', '#e4e7e0');
  return { ink, axis: ink, grid: 'rgba(128,128,128,0.18)', surface, fontBody, fontDisplay, dark: luma(ink) > 0.5 };
}
export function fontFamilies(t: Theme): string[] {
  const out = new Set<string>();
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem('aviary-prefs-v2') : null;
    if (raw) {
      const p = JSON.parse(raw);
      if (p.fontBody) out.add(p.fontBody.trim());
      if (p.fontDisplay) out.add(p.fontDisplay.trim());
    }
  } catch { /* ignore */ }
  [t.fontBody || DEF_BODY, t.fontDisplay || DEF_DISPLAY].forEach((stack) => {
    stack.split(',').forEach((part) => {
      const first = part.trim().replace(/^["']|["']$/g, '');
      if (first && !/^(serif|sans-serif|system-ui|ui-sans-serif|ui-serif|monospace|Georgia|Arial|Helvetica)$/i.test(first)) out.add(first);
    });
  });
  return [...out];
}
export const fontsReady = async () => { try { await (document as unknown as { fonts?: { ready: Promise<unknown> } }).fonts?.ready; } catch { /* noop */ } };
export type { Theme };
