/* Shared chart types — zero dependencies. */
export interface ChartDatum { label: string; value: number; color?: string }
export interface StackedSeries { name: string; color?: string; values: number[] }
export type ChartKind = 'bar' | 'line' | 'area' | 'pie' | 'donut' | 'radar' | 'polar' | 'radialbar' | 'radialbarclassic' | 'radialbars' | 'dual' | 'funnel' | 'pyramid' | 'calendarpie' | 'sankey' | 'sankey3d' | 'toroid' | 'gantt' | 'scatter' | 'stream';
/** Calendar-pie: one mini pie per day (ISO date → per-series values). */
export interface CalendarDay { date: string; values: number[] }
/** Sankey flow: source → target with a weight. */
export interface SankeyLink { source: string; target: string; value: number }
/** Gantt task: milestone / phase duration and progress. */
export interface GanttTask { id: string | number; name: string; start: string | number; end: string | number; progress?: number; color?: string; category?: string; assignee?: string; dependsOn?: (string | number)[]; milestone?: boolean; baselineStart?: string | number; baselineEnd?: string | number; slackDays?: number }
/** Scatter point: 2D numeric correlation coordinate. */
export interface ScatterPoint { x: number; y: number; label?: string; size?: number; color?: string; category?: string }
/** Streamgraph event flag (Highcharts-style plot-line label marking a special event on the timeline). */
export interface StreamEvent { at: number; label: string; detail?: string }
export interface Hover { idx: number | null; seg: { c: number; s: number } | null; amt: number }
export const NO_HOVER: Hover = { idx: null, seg: null, amt: 0 };
export interface LegendItem { label: string; color: string }
export interface XPlan { rot: number; stride: number; padB: number; maxW: number; fs: number; /** how far a rotated first label reaches left of its anchor */ overhang: number }
export interface Orbit3D { yaw: number; pitch: number }
export const ORBIT_REST: Orbit3D = { yaw: -0.30, pitch: 0.30 };
export interface Proj3D {
  px: (x: number, y: number, z: number) => number;
  py: (x: number, y: number, z: number) => number;
  sc: (x: number, y: number, z: number) => number;
  yaw: number; pitch: number; cx: number; cy: number;
}
export interface DrawCtx {
  W: number; H: number; t: Theme; p: number; m: number; hov: Hover;
  data: ChartDatum[]; colors: string[];
  multi: boolean; cats: string[]; series: StackedSeries[]; sColors: string[];
  yLabel?: string;
  /** fullscreen / export — labels are never truncated */
  full?: boolean;
  /** opaque background (exports) — otherwise the frame is cleared to transparent */
  bg?: string;
  /** calendar-pie input (series names come from `series`) */
  days?: CalendarDay[];
  /** sankey input */
  links?: SankeyLink[];
  /** gantt input */
  tasks?: GanttTask[];
  /** scatter input */
  scatter?: ScatterPoint[];
  /** camera orbit for rotatable true-3D scenes (Sankey 3D) */
  orbit?: Orbit3D;
  /** streamgraph event flags (Highcharts-style special-event labels) */
  streamEvents?: StreamEvent[];
}
export interface Theme { ink: string; axis: string; grid: string; surface?: string; fontBody?: string; fontDisplay?: string; dark?: boolean }
