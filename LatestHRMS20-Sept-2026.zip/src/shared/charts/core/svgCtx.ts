/* SvgCtx vector recorder — satisfies the Ctx surface so every painter
   renders identically to canvas and to exported SVG. */
import type { Theme } from './types';
import { parseColor } from './utils';
import { fontFamilies, themeColors } from './theme';

export const r2 = (n: number) => Math.round(n * 100) / 100;
export function splitColor(c: string): { color: string; opacity: number } {
  const p = parseColor(c);
  if (!p) return { color: c || '#000', opacity: 1 };
  return { color: `rgb(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])})`, opacity: p[3] };
}
export class SvgCtx {
  els: string[] = [];
  defs: string[] = [];
  /** embedded @font-face rules (base64 woff2) — fonts travel with the file, no CDN */
  fontCss = '';
  fillStyle: string | { __grad: string } = '#000';
  strokeStyle: string | { __grad: string } = '#000';
  lineWidth = 1;
  lineJoin = 'miter';
  lineCap = 'butt';
  font = '10px sans-serif';
  textAlign: 'left' | 'center' | 'right' | 'start' | 'end' = 'left';
  globalAlpha = 1;
  shadowBlur = 0; shadowOffsetX = 0; shadowOffsetY = 0; shadowColor = 'rgba(0,0,0,0)';
  private d = '';
  private tx = 0; private ty = 0; private rot = 0;
  private stack: { tx: number; ty: number; rot: number; alpha: number; sb: number; sx: number; sy: number; sc: string }[] = [];
  private gradN = 0;
  private filters = new Map<string, string>();
  private meas: CanvasRenderingContext2D;
  constructor(public W: number, public H: number) {
    this.meas = document.createElement('canvas').getContext('2d')!;
  }
  /* transforms / state */
  setTransform() { /* dpr no-op */ }
  clearRect() { /* no-op */ }
  save() { this.stack.push({ tx: this.tx, ty: this.ty, rot: this.rot, alpha: this.globalAlpha, sb: this.shadowBlur, sx: this.shadowOffsetX, sy: this.shadowOffsetY, sc: this.shadowColor }); }
  restore() {
    const s = this.stack.pop();
    if (s) { this.tx = s.tx; this.ty = s.ty; this.rot = s.rot; this.globalAlpha = s.alpha; this.shadowBlur = s.sb; this.shadowOffsetX = s.sx; this.shadowOffsetY = s.sy; this.shadowColor = s.sc; }
  }
  translate(x: number, y: number) { this.tx += x; this.ty += y; }
  rotate(a: number) { this.rot += a; }
  scale() { /* entrance scale is 1 at export */ }
  clip() { /* reveal clips are full-frame at export */ }
  setLineDash() { /* dashes only decorate live hover guides */ }
  rect(x: number, y: number, w: number, h: number) { this.d += `M ${this.px(x, y)} h ${r2(w)} v ${r2(h)} h ${r2(-w)} Z `; }
  /* path building */
  private px(x: number, y: number) { return `${r2(x + this.tx)} ${r2(y + this.ty)}`; }
  beginPath() { this.d = ''; }
  moveTo(x: number, y: number) { this.d += `M ${this.px(x, y)} `; }
  lineTo(x: number, y: number) { this.d += `L ${this.px(x, y)} `; }
  closePath() { this.d += 'Z '; }
  bezierCurveTo(c1x: number, c1y: number, c2x: number, c2y: number, x: number, y: number) {
    this.d += `C ${this.px(c1x, c1y)} ${this.px(c2x, c2y)} ${this.px(x, y)} `;
  }
  quadraticCurveTo(cx: number, cy: number, x: number, y: number) {
    this.d += `Q ${this.px(cx, cy)} ${this.px(x, y)} `;
  }
  arc(x: number, y: number, r: number, a0: number, a1: number, ccw = false) {
    this.ellipse(x, y, r, r, 0, a0, a1, ccw);
  }
  ellipse(x: number, y: number, rx: number, ry: number, _rot: number, a0: number, a1: number, ccw = false) {
    rx = Math.max(0.01, rx); ry = Math.max(0.01, ry);
    let d = a1 - a0;
    if (ccw && d > 0) d -= Math.PI * 2;
    if (!ccw && d < 0) d += Math.PI * 2;
    const full = Math.abs(d) >= Math.PI * 2 - 1e-4;
    const seg = full ? (d > 0 ? Math.PI : -Math.PI) : d;
    const steps = full ? 2 : 1;
    const sx = x + Math.cos(a0) * rx, sy = y + Math.sin(a0) * ry;
    if (this.d === '' || this.d.endsWith('Z ')) this.d += `M ${this.px(sx, sy)} `;
    else this.d += `L ${this.px(sx, sy)} `;
    let cur = a0;
    for (let i = 0; i < steps; i++) {
      const next = full ? cur + seg : a0 + d;
      const ex = x + Math.cos(next) * rx, ey = y + Math.sin(next) * ry;
      const large = Math.abs(next - cur) > Math.PI ? 1 : 0;
      const sweep = next > cur ? 1 : 0;
      this.d += `A ${r2(rx)} ${r2(ry)} 0 ${large} ${sweep} ${this.px(ex, ey)} `;
      cur = next;
    }
  }
  roundRect(x: number, y: number, w: number, h: number, r: number | number[]) {
    const lim = Math.min(w, h) / 2;
    const rr = (Array.isArray(r) ? r : [r, r, r, r]).map((v) => Math.min(lim, Math.max(0, v)));
    const [tl, tr, br, bl] = [rr[0] ?? 0, rr[1] ?? rr[0] ?? 0, rr[2] ?? rr[0] ?? 0, rr[3] ?? rr[1] ?? rr[0] ?? 0];
    this.d += `M ${this.px(x + tl, y)} H ${r2(x + w - tr + this.tx)} `;
    if (tr) this.d += `A ${r2(tr)} ${r2(tr)} 0 0 1 ${this.px(x + w, y + tr)} `;
    this.d += `V ${r2(y + h - br + this.ty)} `;
    if (br) this.d += `A ${r2(br)} ${r2(br)} 0 0 1 ${this.px(x + w - br, y + h)} `;
    this.d += `H ${r2(x + bl + this.tx)} `;
    if (bl) this.d += `A ${r2(bl)} ${r2(bl)} 0 0 1 ${this.px(x, y + h - bl)} `;
    this.d += `V ${r2(y + tl + this.ty)} `;
    if (tl) this.d += `A ${r2(tl)} ${r2(tl)} 0 0 1 ${this.px(x + tl, y)} `;
    this.d += 'Z ';
  }
  /* paint */
  private resolve(style: string | { __grad: string }): string {
    return typeof style === 'string' ? style : `url(#${style.__grad})`;
  }
  private fx(): string {
    let attr = this.globalAlpha < 1 ? ` opacity="${r2(this.globalAlpha)}"` : '';
    if (this.shadowBlur > 0 || this.shadowOffsetX || this.shadowOffsetY) {
      const { color, opacity } = splitColor(this.shadowColor);
      if (opacity > 0) {
        const key = `${r2(this.shadowOffsetX)}|${r2(this.shadowOffsetY)}|${r2(this.shadowBlur)}|${color}|${r2(opacity)}`;
        let id = this.filters.get(key);
        if (!id) {
          id = `sh${this.filters.size + 1}`;
          this.filters.set(key, id);
          // classic blur → offset → flood → composite → merge chain: renders in every
          // SVG engine (browsers, Inkscape, librsvg, Illustrator), unlike feDropShadow
          this.defs.push(`<filter id="${id}" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur in="SourceAlpha" stdDeviation="${r2(this.shadowBlur / 2)}"/><feOffset dx="${r2(this.shadowOffsetX)}" dy="${r2(this.shadowOffsetY)}" result="ob"/><feFlood flood-color="${color}" flood-opacity="${r2(opacity)}"/><feComposite in2="ob" operator="in" result="sh"/><feMerge><feMergeNode in="sh"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`);
        }
        attr += ` filter="url(#${id})"`;
      }
    }
    return attr;
  }
  fill() { if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`); }
  stroke() {
    if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="none" stroke="${this.resolve(this.strokeStyle)}" stroke-width="${r2(this.lineWidth)}" stroke-linejoin="${this.lineJoin === 'round' ? 'round' : 'miter'}" stroke-linecap="${this.lineCap === 'round' ? 'round' : 'butt'}"${this.fx()}/>`);
  }
  fillRect(x: number, y: number, w: number, h: number) {
    this.els.push(`<rect x="${r2(x + this.tx)}" y="${r2(y + this.ty)}" width="${r2(w)}" height="${r2(h)}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`);
  }
  fillText(text: string, x: number, y: number) {
    const fm = /(\d+(?:\.\d+)?)px\s+(.+)$/.exec(this.font);
    const size = fm ? +fm[1] : 10;
    const fam = fm ? fm[2] : 'sans-serif';
    const wm = /^(\d{3}|bold)\s/.exec(this.font);
    const weight = wm ? (wm[1] === 'bold' ? '700' : wm[1]) : '400';
    const anchor = this.textAlign === 'center' ? 'middle' : this.textAlign === 'right' || this.textAlign === 'end' ? 'end' : 'start';
    const esc = text.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const gx = r2(x + this.tx), gy = r2(y + this.ty);
    const tf = this.rot !== 0 ? ` transform="rotate(${r2((this.rot * 180) / Math.PI)} ${gx} ${gy})"` : '';
    this.els.push(`<text x="${gx}" y="${gy}" font-family="${fam.replace(/"/g, "'")}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}" fill="${this.resolve(this.fillStyle)}"${tf}${this.fx()}>${esc}</text>`);
  }
  measureText(t: string) { this.meas.font = this.font; return this.meas.measureText(t); }
  createLinearGradient(x0: number, y0: number, x1: number, y1: number) {
    const id = `g${++this.gradN}`;
    const stops: string[] = [];
    this.defs.push('');
    const idx = this.defs.length - 1;
    const self = this;
    const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
    return {
      __grad: id,
      addColorStop(off: number, col: string) {
        const sc = splitColor(col);
        stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
        self.defs[idx] = `<linearGradient id="${id}" x1="${r2(ax)}" y1="${r2(ay)}" x2="${r2(bx)}" y2="${r2(by)}" gradientUnits="userSpaceOnUse">${stops.join('')}</linearGradient>`;
      },
    };
  }
  /** SVG <radialGradient> support — required for dual-axis 3D line markers. */
  createRadialGradient(x0: number, y0: number, r0: number, x1: number, y1: number, r1: number) {
    const id = `g${++this.gradN}`;
    const stops: string[] = [];
    this.defs.push('');
    const idx = this.defs.length - 1;
    const self = this;
    const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
    return {
      __grad: id,
      addColorStop(off: number, col: string) {
        const sc = splitColor(col);
        stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
        self.defs[idx] = `<radialGradient id="${id}" cx="${r2(ax)}" cy="${r2(ay)}" r="${r2(Math.max(0.01, r0))}" fx="${r2(bx)}" fy="${r2(by)}" fr="${r2(Math.max(0.01, r1))}" gradientUnits="userSpaceOnUse">${stops.join('')}</radialGradient>`;
      },
    };
  }
  toString(): string {
    const fams = fontFamilies(themeColors(true));
    const googleImport = fams.length
      ? `@import url('https://fonts.googleapis.com/css2?family=${fams.map((f) => encodeURIComponent(f).replace(/%20/g, '+')).join('&family=')}:wght@400;600;700&display=swap');\n`
      : '';
    const style = `<style><![CDATA[\n${googleImport}${this.fontCss}]]></style>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${this.W}" height="${this.H}" viewBox="0 0 ${this.W} ${this.H}"><defs>${style}${this.defs.join('')}</defs><rect width="${this.W}" height="${this.H}" fill="#ffffff"/>${this.els.join('')}</svg>`;
  }
}
