/* Pure chart utilities: easing, color, text measure/fit. Zero React deps. */
import type { Theme } from './types';
export type Ctx = CanvasRenderingContext2D;


export const TILT = 0.32; // slight left-leaning perspective — aesthetic, not a full tilt
export const K = Math.sin(TILT);
export const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
export const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const SIN45 = Math.SQRT1_2;

/* ---------- colour utils ---------- */
export function parseColor(c: string): [number, number, number, number] | null {
  const s = (c || '').trim();
  let m = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(s);
  if (m) return [parseInt(m[1] + m[1], 16), parseInt(m[2] + m[2], 16), parseInt(m[3] + m[3], 16), 1];
  m = /^#([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(s);
  if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, m[2] ? parseInt(m[2], 16) / 255 : 1]; }
  m = /^rgba?\(([^)]+)\)$/i.exec(s);
  if (m) {
    const parts = m[1].split(/[\s,/]+/).filter(Boolean).map(parseFloat);
    if (parts.length >= 3) return [parts[0], parts[1], parts[2], parts.length > 3 ? parts[3] : 1];
  }
  return null;
}
const shadeCache = new Map<string, string>();
export const shade = (col: string, f: number) => {
  const key = col + '|' + f.toFixed(3);
  const hit = shadeCache.get(key);
  if (hit) return hit;
  const p = parseColor(col) || [136, 136, 136, 1];
  const c = (v: number) => Math.min(255, Math.max(0, Math.round(v * f)));
  const out = `rgb(${c(p[0])},${c(p[1])},${c(p[2])})`;
  if (shadeCache.size > 4000) shadeCache.clear();
  shadeCache.set(key, out);
  return out;
};
export const rgba = (col: string, a: number) => {
  const p = parseColor(col);
  return p ? `rgba(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])},${a})` : col;
};
export const withAlpha = (hex: string, a: string) => (/^#[0-9a-f]{6}$/i.test(hex) ? hex + a : rgba(hex, parseInt(a, 16) / 255));
export const luma = (col: string) => { const p = parseColor(col); return p ? (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) / 255 : 0.5; };

/* ---------- text helpers ---------- */
export const approxW = (s: string, fs = 10.5) => s.length * fs * 0.58;
/** Smart label fitting — ellipsis, prefers word boundaries. Deterministic (no ctx). */
export function fitText(s: string, maxW: number, fs = 10.5): string {
  const cw = fs * 0.58;
  const maxC = Math.max(2, Math.floor(maxW / cw));
  if (s.length <= maxC) return s;
  let cut = s.slice(0, maxC - 1);
  const sp = cut.lastIndexOf(' ');
  if (sp > maxC * 0.5) cut = cut.slice(0, sp);
  return cut.trimEnd() + '…';
}
export const fmtNum = (n: number) =>
  Math.abs(n) >= 1e6 ? `${(n / 1e6).toFixed(1).replace(/\.0$/, '')}M`
    : Math.abs(n) >= 1e3 ? `${(n / 1e3).toFixed(1).replace(/\.0$/, '')}k`
    : String(Math.round(n));
export const measureW = (ctx: Ctx, s: string) => {
  try { const w = ctx.measureText(s).width; return w > 0 && isFinite(w) ? w : approxW(s); } catch { return approxW(s); }
};
/** Measured ellipsis using the context's current font. */
export function fitCtx(ctx: Ctx, s: string, maxW: number): string {
  if (maxW === Infinity || measureW(ctx, s) <= maxW) return s;
  let lo = 0, hi = s.length;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (measureW(ctx, s.slice(0, mid) + '…') <= maxW) lo = mid; else hi = mid - 1; }
  let cut = s.slice(0, Math.max(1, lo));
  const sp = cut.lastIndexOf(' ');
  if (sp > cut.length * 0.5) cut = cut.slice(0, sp);
  return cut.trimEnd() + '…';
}
