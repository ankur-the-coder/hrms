/* Intelligent x-axis labels: measure → horizontal / rotated / strided. */
import type { Theme, XPlan } from '../core/types';
import { SIN45, approxW, fitCtx, measureW, type Ctx } from '../core/utils';
import { font } from '../core/theme';

/* ============================================================
   Intelligent x-axis labels
   measure → horizontal if they fit; otherwise rotate (-45° / -90°)
   and stride so labels never collide. Compact mode keeps things
   readable with measured ellipsis; full mode (fullscreen / export)
   never truncates and grows the bottom padding instead.
   ============================================================ */
export function planX(labels: string[], step: number, full: boolean, fs = 10.5): XPlan {
  const longest = labels.reduce((m, l) => Math.max(m, approxW(l, fs)), 0);
  const base = 34;
  if (!labels.length || longest <= step - 6) return { rot: 0, stride: 1, padB: base, maxW: Math.max(20, step - 4), fs, overhang: 0 };
  if (full) {
    const rot = longest * SIN45 + fs <= 130 ? -Math.PI / 4 : -Math.PI / 2;
    const foot = (fs * 1.4) / Math.abs(Math.sin(rot));
    const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
    const padB = Math.min(170, (rot === -Math.PI / 2 ? longest : longest * SIN45) + 22);
    return { rot, stride, padB, maxW: Infinity, fs, overhang: longest * Math.abs(Math.cos(rot)) + 4 };
  }
  if (step >= 56) return { rot: 0, stride: 1, padB: base, maxW: step - 4, fs, overhang: 0 };
  const rot = -Math.PI / 4;
  const foot = (fs * 1.4) / SIN45;
  const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
  const maxW = 78;
  const padB = Math.min(70, Math.min(longest, maxW) * SIN45 + 22);
  return { rot, stride, padB, maxW, fs, overhang: Math.min(longest, maxW) * SIN45 + 4 };
}
/** Plan labels for a plot of width `W - l - r`, growing the left pad when a rotated first label would spill off-canvas. */
export function planXFit(labels: string[], W: number, l: number, r: number, full: boolean, fs: number, slots: number, endpoints = false) {
  const stepOf = (left: number) => { const cw = Math.max(10, W - left - r); return endpoints ? (slots > 1 ? cw / (slots - 1) : cw) : cw / Math.max(1, slots); };
  let plan = planX(labels, stepOf(l), full, fs);
  if (plan.overhang > l) { l = plan.overhang; plan = planX(labels, stepOf(l), full, fs); }
  return { plan, l, step: stepOf(l) };
}
export function drawXLabels(ctx: Ctx, labels: string[], plan: XPlan, xOf: (i: number) => number, yAxis: number, t: Theme, W: number, weight = 600, color?: string) {
  ctx.font = font(t, weight, plan.fs);
  ctx.fillStyle = color || t.axis;
  const n = labels.length;
  for (let i = 0; i < n; i++) {
    const x = xOf(i);
    const isLast = i === n - 1;
    const shown = i % plan.stride === 0 || (isLast && plan.stride > 1 && (n - 1) % plan.stride >= Math.ceil(plan.stride * 0.6));
    if (!shown) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x, yAxis); ctx.lineTo(x, yAxis + 3); ctx.stroke();
      continue;
    }
    const text = plan.maxW === Infinity ? labels[i] : fitCtx(ctx, labels[i], plan.maxW);
    if (plan.rot === 0) {
      const w = measureW(ctx, text);
      const cx = Math.max(w / 2 + 2, Math.min(W - w / 2 - 2, x));
      ctx.textAlign = 'center';
      ctx.fillText(text, cx, yAxis + 16);
    } else {
      ctx.save(); ctx.translate(x, yAxis + 8); ctx.rotate(plan.rot); ctx.textAlign = 'right';
      ctx.fillText(text, 0, plan.fs * 0.35); ctx.restore();
    }
  }
  ctx.textAlign = 'left';
}

