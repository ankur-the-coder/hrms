/* Cartesian layout helpers. */
import type { StackedSeries, XPlan } from '../core/types';
import { planX, planXFit } from '../axes/xlabels';
import { approxW, fmtNum } from '../core/utils';

/* ================= geometry helpers ================= */
export const ZX = 15, ZY = 10, DZ = 7, DZY = 4.5; // 3D line/area: per-series depth step + (thin) slab thickness
export interface XY { pad: { l: number; r: number; t: number; b: number }; cw: number; ch: number; step: number; plan: XPlan; ox: number; oy: number }
export function xyLayout(kind: 'bar' | 'line' | 'area', W: number, H: number, m: number, labels: string[], nD: number, max: number, hasY: boolean, full: boolean): XY {
  const isBar = kind === 'bar';
  const ox = isBar ? 13 * m : ZX * m * Math.max(0, nD - 1) + DZ * m;
  const oy = isBar ? 9 * m : ZY * m * Math.max(0, nD - 1) + DZY * m;
  const l0 = 12 + approxW(fmtNum(max), 10.5) + 12 + (hasY ? 14 : 0);
  const r = 16 + (isBar ? 20 * m : ox);
  const tp = 18 + (isBar ? 12 * m : oy);
  const { plan, l, step } = planXFit(labels, W, l0, r, full, 10.5, labels.length);
  return { pad: { l, r, t: tp, b: plan.padB }, cw: W - l - r, ch: H - tp - plan.padB, step, plan, ox, oy };
}

/** Depth rank per series: 0 = front (smallest total) … n-1 = back (largest). */
export function seriesDepth(series: StackedSeries[]): number[] {
  const order = series.map((s, i) => ({ i, sum: s.values.reduce((a, b) => a + b, 0) })).sort((a, b) => a.sum - b.sum);
  const depth = new Array(series.length).fill(0);
  order.forEach((o, rank) => { depth[o.i] = rank; });
  return depth;
}
