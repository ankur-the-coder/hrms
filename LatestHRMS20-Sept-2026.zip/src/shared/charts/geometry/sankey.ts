/* True-3D projection core + sankey layout/ribbon samplers. */
import type { Orbit3D, Proj3D, SankeyLink } from '../core/types';
import { ORBIT_REST } from '../core/types';
import { shade, rgba, type Ctx } from '../core/utils';
import { activePalette } from '../core/theme';

/* ================= true-3D projection core (rotatable 3D scenes) =================
   A tiny software 3D pipeline shared by the rotatable 3D charts (currently
   Sankey 3D). World space is pixels in X/Y with a Z depth in pixels; the
   camera orbits around the scene centre by yaw (horizontal) and pitch
   (vertical tilt). Projection is a gentle perspective divide, so near edges
   grow and far edges shrink exactly like a modelled object in a viewport.
   Dragging the canvas orbits the camera; the angles ease back toward rest on
   release so the scene always settles into a readable default view. */
export { ORBIT_REST };
export type { Orbit3D, Proj3D };
export function makeProj(W: number, H: number, o: Orbit3D, dist?: number): Proj3D {
  // Focal length scales with canvas size so perspective strength is identical
  // in cards, fullscreen and exports.
  const D = dist ?? Math.max(W, H) * 2.2;
  const cx = W / 2, cy = H / 2;
  const cyaw = Math.cos(o.yaw), syaw = Math.sin(o.yaw);
  const cpit = Math.cos(o.pitch), spit = Math.sin(o.pitch);
  const rot = (x: number, y: number, z: number): [number, number, number] => {
    const dx = x - cx, dy = y - cy;
    // yaw around the vertical axis, then pitch around the horizontal axis
    const x1 = dx * cyaw - z * syaw;
    const z1 = dx * syaw + z * cyaw;
    const y2 = dy * cpit - z1 * spit;
    const z2 = dy * spit + z1 * cpit;
    return [x1, y2, z2];
  };
  const sc = (x: number, y: number, z: number) => D / (D + rot(x, y, z)[2]);
  return {
    px: (x, y, z) => cx + rot(x, y, z)[0] * sc(x, y, z),
    py: (x, y, z) => cy + rot(x, y, z)[1] * sc(x, y, z),
    sc, yaw: o.yaw, pitch: o.pitch, cx, cy,
  };
}

/* ---- sankey layout: longest-path column assignment, proportional node heights, flows stacked in node order ---- */
export interface SkNode { name: string; col: number; value: number; x: number; y: number; h: number; color: string }
export interface SkFlow { si: number; ti: number; value: number; sy0: number; sy1: number; ty0: number; ty1: number }
export function sankeyLayout(links: SankeyLink[], W: number, H: number, labelSpace: number) {
  const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
  const idx = new Map(names.map((n, i) => [n, i]));
  const outs = names.map(() => [] as number[]), ins = names.map(() => [] as number[]);
  links.forEach((l, li) => { outs[idx.get(l.source)!].push(li); ins[idx.get(l.target)!].push(li); });
  // column = longest path from a source (cycle-guarded)
  const col = new Array(names.length).fill(0);
  const visit = (i: number, depth: number, seen: Set<number>) => {
    if (seen.has(i) || depth > 32) return;
    col[i] = Math.max(col[i], depth);
    seen.add(i);
    outs[i].forEach((li) => visit(idx.get(links[li].target)!, depth + 1, seen));
    seen.delete(i);
  };
  names.forEach((_, i) => { if (!ins[i].length) visit(i, 0, new Set()); });
  const cols = Math.max(...col) + 1;
  if (cols < 2) return null;
  const value = names.map((_, i) => Math.max(outs[i].reduce((s2, li) => s2 + links[li].value, 0), ins[i].reduce((s2, li) => s2 + links[li].value, 0)));
  const padT = 14, padB = 14, padL = 8, padR = labelSpace;
  const nodeW = 12, gap = 10;
  const plotW = W - padL - padR - nodeW, plotH = H - padT - padB;
  const colX = Array.from({ length: cols }, (_, c) => padL + (plotW * c) / (cols - 1));
  const perCol = Array.from({ length: cols }, () => [] as number[]);
  names.forEach((_, i) => perCol[col[i]].push(i));
  // scale so the tallest column fits
  const colTotal = perCol.map((ids) => ids.reduce((s2, i) => s2 + value[i], 0) + gap * Math.max(0, ids.length - 1));
  const scale = (plotH) / Math.max(...colTotal, 1);
  const pal = activePalette();
  const nodes: SkNode[] = names.map((n, i) => ({ name: n, col: col[i], value: value[i], x: colX[col[i]], y: 0, h: value[i] * scale, color: pal[i % pal.length] }));
  perCol.forEach((ids) => {
    ids.sort((a, b) => value[b] - value[a]);
    const total = ids.reduce((s2, i) => s2 + nodes[i].h, 0) + gap * Math.max(0, ids.length - 1);
    let y = padT + (plotH - total) / 2;
    ids.forEach((i) => { nodes[i].y = y; y += nodes[i].h + gap; });
  });
  // flows: stack outgoing on the source (ordered by target y) and incoming on the target (ordered by source y)
  const flows: SkFlow[] = links.map((l) => ({ si: idx.get(l.source)!, ti: idx.get(l.target)!, value: l.value, sy0: 0, sy1: 0, ty0: 0, ty1: 0 }));
  nodes.forEach((n, i) => {
    let y = n.y;
    outs[i].map((li) => flows[li]).sort((a, b) => nodes[a.ti].y - nodes[b.ti].y).forEach((f) => { f.sy0 = y; y += f.value * scale; f.sy1 = y; });
    y = n.y;
    ins[i].map((li) => flows[li]).sort((a, b) => nodes[a.si].y - nodes[b.si].y).forEach((f) => { f.ty0 = y; y += f.value * scale; f.ty1 = y; });
  });
  return { nodes, flows, nodeW, cols, colX };
}

/** 3D layout: same flow math as 2D, but shifted right to reserve the
   left outside-label gutter and vertically centred in the taller 3D plot. */
export function sankeyLayout3D(links: SankeyLink[], W: number, H: number, labelSpace: number, padL3D: number) {
  const lay = sankeyLayout(links, W - padL3D, H, labelSpace);
  if (!lay) return null;
  const dx = padL3D;
  lay.nodes.forEach((n) => { n.x += dx; });
  lay.colX = lay.colX.map((x) => x + dx);
  return lay;
}

export function sankeyRibbon(ctx: Ctx, f: SkFlow, nodes: SkNode[], nodeW: number, emphasis = 0) {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x, mid = (x0 + x1) / 2;
  const spread = 5 * emphasis;
  ctx.beginPath(); ctx.moveTo(x0, f.sy0);
  ctx.bezierCurveTo(mid, f.sy0 - spread, mid, f.ty0 - spread, x1, f.ty0);
  ctx.lineTo(x1, f.ty1);
  ctx.bezierCurveTo(mid, f.ty1 + spread, mid, f.sy1 + spread, x0, f.sy1);
  ctx.closePath();
}

/* ---- sankey ribbon sampler: bezier ribbons as polylines so perspective
   projection can be applied per-vertex (true 3D), shared by painter + hit ---- */
export interface SlabPt { x: number; y: number }
// Shared glass-slab camera: the painter and the hit tester MUST use the same
// projection or hover will drift from the rotated artwork.
export function sankeyCam(W: number, H: number, o: Orbit3D) {
  // Oblique-cabinet projection tuned to the reference render: depth recedes
  // up-and-right at a fixed shallow angle, and yaw only *scales* that
  // direction (never a rotation matrix), so x-order can never flip and no
  // mirror/break can occur at any orbit, size or morph step.
  const yaw = Math.max(-1.1, Math.min(1.1, o.yaw));
  const tilt = Math.max(0, Math.min(1, (o.pitch + 0.15) / 1.25));
  const dir = yaw >= 0 ? 1 : -1;
  const k = 0.34 + 0.30 * Math.min(1, Math.abs(yaw) / 0.6); // 0.34..0.64
  const dx = dir * k, dy = -(0.30 + 0.34 * tilt);
  const px = (x: number, y: number, z: number): number => x + z * dx;
  const py = (x: number, y: number, z: number): number => {
    const s = 1 / (1 + Math.max(0, z) * 0.0009);
    return H / 2 + (y - H / 2) * (0.985 - tilt * 0.06) * s + z * -dy * -1 * s;
  };
  return { px, py };
}
const SK_SEG = 22;
export function sankeySlab(f: SkFlow, nodes: SkNode[], nodeW: number, spread: number): { top: SlabPt[]; bot: SlabPt[] } {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x;
  const c1 = x0 + (x1 - x0) * 0.5, c2 = x1 - (x1 - x0) * 0.5;
  const tA0 = f.sy0 - spread, tA1 = f.sy1 + spread, tB0 = f.ty0 - spread, tB1 = f.ty1 + spread;
  const top: SlabPt[] = [], bot: SlabPt[] = [];
  for (let s = 0; s <= SK_SEG; s++) {
    const tt = s / SK_SEG, u = 1 - tt;
    const bx = u * u * u * x0 + 3 * u * u * tt * c1 + 3 * u * tt * tt * c2 + tt * tt * tt * x1;
    const by0 = u * u * u * tA0 + 3 * u * u * tt * tA0 + 3 * u * tt * tt * tB0 + tt * tt * tt * tB0;
    const by1 = u * u * u * tA1 + 3 * u * u * tt * tA1 + 3 * u * tt * tt * tB1 + tt * tt * tt * tB1;
    top.push({ x: bx, y: by0 }); bot.push({ x: bx, y: by1 });
  }
  return { top, bot };
}

/* ---- radial bar geometry ---- */
/* ---- radial pipe renderer: solves the flat-tube problem ----
   A flat 3D ring reads as a ribbon because its top face is a single fill.
   A pipe reads as a pipe because light wraps around its circular cross
   section. pipeShade() reproduces that wrap analytically: given the
   fractional position v across the tube (0 = inner wall, 1 = outer wall),
   it returns the light factor of a cylinder lit from the top-left —
   bright crest, saturated flank, dark contact edge — so N stacked strokes
   fuse into one round tube. Ends are NOT round dots: they are flat radial
   cuts (butt caps) whose top edge follows the same perspective squash as
   the ring, exactly like a sawn pipe end. */
export const pipeShade = (v: number) => 0.62 + 0.78 * Math.sin(Math.PI * Math.min(1, Math.max(0, v)));

/* ---- sankey-3D glass-tube renderer (matches the reference render) ----
   Reference anatomy, observed pixel-by-pixel:
   - Nodes are OPAQUE vertical glass bars with a rounded top / elliptical cap,
     a bright vertical sheen band on the face, and the "Name · value" label
     printed ON the bar face (dark ink on light bars, white on dark bars).
   - Ribbons are TRANSLUCENT glass tubes: bright highlight along the TOP edge,
     saturated color through the middle, deep saturated color along the
     BOTTOM edge, with a soft blurred shadow cast beneath each tube onto the
     glossy off-white floor. Tube color = horizontal source→target blend.
   - Thin downstream ribbons (Offered→Hired/Declined) curve gracefully and
     the tiny end nodes sit as small glass blocks the tubes plug into.
   The helpers below reproduce exactly that construction. */
const SK3_TUBE_SEG = 40;
/** Sample a ribbon's S-curve edges into a polyline tube.
   Reference curvature: the bend concentrates ~55% across (smoothstep ease),
   NOT a symmetric cubic — that is what makes tubes swoop and settle like
   the reference instead of bowing evenly. Bevel bulbs at the mouths are
   intentional (the reference tubes bulge slightly as they leave the bars). */
export function sk3Smooth(u: number): number {
  const t = Math.max(0, Math.min(1, u));
  return t * t * t * (t * (t * 6 - 15) + 10);
}
export function sk3Tube(f: SkFlow, nodes: SkNode[], nodeW: number): { top: SlabPt[]; bot: SlabPt[] } {
  const x0 = nodes[f.si].x + nodeW, x1 = nodes[f.ti].x;
  const top: SlabPt[] = [], bot: SlabPt[] = [];
  for (let s = 0; s <= SK3_TUBE_SEG; s++) {
    const u = s / SK3_TUBE_SEG;
    const e = sk3Smooth(u);
    const bx = x0 + (x1 - x0) * u;
    const by0 = f.sy0 + (f.ty0 - f.sy0) * e;
    const by1 = f.sy1 + (f.ty1 - f.sy1) * e;
    // bevel bulb: tube mouths bulge ~12% near the bars, like the reference
    const bulb = 1 + 0.12 * (Math.exp(-Math.pow(u / 0.10, 2)) + Math.exp(-Math.pow((1 - u) / 0.10, 2)));
    const mid = (by0 + by1) / 2, half = ((by1 - by0) / 2) * bulb;
    top.push({ x: bx, y: mid - half }); bot.push({ x: bx, y: mid + half });
  }
  return { top, bot };
}
/** Fill the tube silhouette between two sampled edges. */
export function sk3FillTube(ctx: Ctx, T: SlabPt[], B: SlabPt[]) {
  ctx.beginPath();
  T.forEach((q, k) => { k === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y); });
  for (let k = B.length - 1; k >= 0; k--) ctx.lineTo(B[k].x, B[k].y);
  ctx.closePath(); ctx.fill();
}
/** Stroke one sampled edge. */
export function sk3StrokeEdge(ctx: Ctx, E: SlabPt[]) {
  ctx.beginPath();
  E.forEach((q, k) => { k === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y); });
  ctx.stroke();
}
/** Vertical glass gradient for a tube: bright crown → mid color → deep base. */
export function sk3TubeGrad(ctx: Ctx, yTop: number, yBot: number, c0: string, c1: string, a: number) {
  const g = ctx.createLinearGradient(0, yTop, 0, Math.max(yTop + 1, yBot));
  g.addColorStop(0, rgba(shade(c0, 1.45), a));
  g.addColorStop(0.28, rgba(shade(c0, 1.12), a));
  g.addColorStop(0.55, rgba(c1, a));
  g.addColorStop(1, rgba(shade(c1, 0.62), Math.min(1, a + 0.1)));
  return g;
}