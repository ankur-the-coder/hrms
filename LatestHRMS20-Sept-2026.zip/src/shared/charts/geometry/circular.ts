/* Circular/polar layout + leader labels + axes painter. */
import type { ChartDatum, Theme } from '../core/types';
import { approxW, fitCtx, fmtNum, lerp, measureW, K, type Ctx } from '../core/utils';
import { font } from '../core/theme';

export const leaderLabel = (d: ChartDatum, total: number) => `${d.label} · ${Math.round((d.value / total) * 100)}%`;
export function circGeom(W: number, H: number, m: number, data: ChartDatum[], full = false) {
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const longest = Math.max(0, ...data.map((x) => approxW(leaderLabel(x, total))));
  const labelSpace = full ? longest + 40 : Math.min(Math.max(60, longest) + 34, W * 0.32);
  const squash = lerp(1, K, m);
  // The diameter is FIXED across the 2D⇄3D morph: the disc is sized once for
  // the flat view (the binding constraint) and only tilts/extrudes afterwards.
  let R = Math.min(W / 2 - labelSpace, (H - 44) / 2);
  R = Math.max(full ? 60 : 40, R);
  // Keep the extruded disc's depth strictly proportional to its radius so the
  // 3D pie/donut/polar always read with a proper thickness in fullscreen,
  // regardless of how much vertical space the container offers.
  // Slimmer than the legacy 0.42 ratio: the old slab looked chunky in
  // fullscreen, so the extrusion now tops out at ~30 % of the radius with a
  // capped pixel ceiling.
  const depth = Math.min(58, Math.max(12, R * 0.3)) * m;
  const cy = (H - depth) / 2 + 4;
  return { cx: W / 2, cy, R, rInRatio: 0.55, depth, squash, total };
}

export function radialGeom(W: number, H: number, data: ChartDatum[], full: boolean, m = 0) {
  const n = Math.max(1, data.length);
  // Adaptive label column: only reserve side space when there is genuinely
  // room (large canvas or fullscreen). On small tiles / narrow exports every
  // pixel goes to the rings and labels render inside the tubes instead.
  const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
  const roomy = full || W >= 560;
  const labelSpace = roomy ? longest + 26 : 0;
  const squash = 1 - 0.44 * m;
  // Vertical budget accounts for the 3D squash: an untilted disc needs its
  // full radius, a squashed one needs far less height.
  const vBudget = full ? (H - 32) / 2 : (H - 24) / 2;
  const R = Math.max(26, Math.min((W - labelSpace) / 2 - 10, vBudget / Math.max(0.5, squash) - 4));
  const cx = labelSpace + (W - labelSpace) / 2, cy = H / 2;
  // Tube thickness adapts to ring count so N rings always fit: thin tubes for
  // many rings (min 3px), chunky tubes for few (max 22px). The inner hole
  // keeps a floor of 14px so the last (innermost) bar never splits/collapses.
  const avail = Math.max(30, R - 16);
  const thick = Math.max(3, Math.min(22, avail / Math.max(1, n * 1.22)));
  const gap = Math.max(1.5, Math.min(4, thick * 0.28));
  const radiusOf = (i: number) => R - thick / 2 - i * (thick + gap);
  // Clamp helper: keeps the innermost tube's inner edge >= minHole so the
  // last bar can never invert / split into a broken ring.
  const minHole = 13;
  const ringR = (i: number) => Math.max(thick / 2 + minHole, radiusOf(i));
  return { cx, cy, R, thick, gap, radiusOf, ringR, labelSpace, n, roomy };
}

export const funnelLabel = (x: ChartDatum, total: number) => `${x.label} · ${x.value} (${Math.round((x.value / total) * 100)}%)`;
export function funnelGeom(W: number, H: number, m: number, data: ChartDatum[], full: boolean, pyramid = false) {
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const longest = Math.max(0, ...data.map((x) => approxW(funnelLabel(x, total))));
  const labelSpace = full ? longest + 40 : Math.min(160, W * 0.3);
  const padT = 16, padB = 16;
  // the visual envelope is identical in 2D and 3D — the 3D body shrinks to
  // make room for its elliptical caps instead of growing past it
  const env = Math.min(H - padT - padB, W * 0.62);
  const sq = 0.16 * m;
  const ch = env / (1 + 1.2 * sq);
  // the 3D pyramid's side face extends 20 % of the base width to the right;
  // reserve that room so the leader lane always clears it
  const side = pyramid ? 0.2 * 0.96 * m : 0;
  const plotW = Math.min((W - labelSpace - 60) / (1 + side / 2), ch * 1.15);
  const capTop = (plotW / 2) * sq;
  const topY = padT + (H - padT - padB - env) / 2 + capTop;
  const cx = (W - labelSpace) / 2 + 10 - (plotW * side) / 4;
  // x where every leader turns towards its label: just right of the widest point
  const laneX = cx + (plotW / 2) * 0.96 + plotW * side + 14;
  return { total, labelSpace, ch, plotW, sq, topY, cx, capTop, laneX };
}

/* ================= leader labels — curved arrows attached ON the rim ================= */
export function drawLeaders(ctx: Ctx, cx: number, cy: number, R: number, squash: number, data: ChartDatum[], colors: string[], total: number, t: Theme, W: number, H: number, equalAngles = false, full = false) {
  ctx.font = font(t, 600, full ? 13 : 12);
  const n = data.length;
  let a = -Math.PI / 2;
  interface E { i: number; mid: number; right: boolean; y: number }
  const entries: E[] = data.map((d, i) => {
    let mid: number;
    if (equalAngles) mid = -Math.PI / 2 + ((i + 0.5) * Math.PI * 2) / n;
    else { const a2 = a + (d.value / total) * Math.PI * 2; mid = (a + a2) / 2; a = a2; }
    return { i, mid, right: Math.cos(mid) >= 0, y: cy + Math.sin(mid) * (R + 20) * squash };
  });
  const place = (list: E[]) => {
    list.sort((p, q) => p.y - q.y);
    let prev = -Infinity;
    list.forEach((e) => { e.y = Math.max(e.y, prev + 18); prev = e.y; });
    list.forEach((e) => { e.y = Math.max(12, Math.min(H - 8, e.y)); });
  };
  place(entries.filter((e) => e.right));
  place(entries.filter((e) => !e.right));

  entries.forEach((e) => {
    const d = data[e.i];
    const ax = cx + Math.cos(e.mid) * R;
    const ay = cy + Math.sin(e.mid) * R * squash;
    const qx = cx + Math.cos(e.mid) * (R + 18);
    const qy = cy + Math.sin(e.mid) * (R + 18) * squash;
    const ex = cx + (e.right ? R + 26 : -(R + 26));
    const tx = cx + (e.right ? R + 34 : -(R + 34));
    const c1x = (ex + qx) / 2, c1y = e.y;
    const c2x = qx, c2y = qy;
    // end tangent (anchor − c2) → arrow direction
    const dx = ax - c2x, dy = ay - c2y;
    const dl = Math.hypot(dx, dy) || 1;
    const ux = dx / dl, uy = dy / dl;
    const px2 = -uy, py2 = ux;
    // the curve stops where the arrowhead begins so nothing overdraws the head
    const bx = ax - ux * 8, by = ay - uy * 8;
    ctx.strokeStyle = colors[e.i];
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(tx, e.y);
    ctx.lineTo(ex, e.y);
    ctx.bezierCurveTo(c1x, c1y, c2x, c2y, bx, by);
    ctx.stroke();
    // arrowhead: tip sits ON the rim, outlined so it reads cleanly against any background
    ctx.fillStyle = colors[e.i];
    ctx.beginPath();
    ctx.moveTo(ax + ux * 0.5, ay + uy * 0.5);
    ctx.lineTo(bx - ux * 1.2 + px2 * 4.2, by - uy * 1.2 + py2 * 4.2);
    ctx.lineTo(bx - ux * 1.2 - px2 * 4.2, by - uy * 1.2 - py2 * 4.2);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.lineJoin = 'round';
    ctx.stroke();
    ctx.lineJoin = 'miter';
    // label — larger font (12px / 13px), clear legible text
    const avail = e.right ? W - tx - 8 : tx - 8;
    ctx.fillStyle = t.ink;
    ctx.textAlign = e.right ? 'left' : 'right';
    const text = leaderLabel(d, total);
    ctx.fillText(full ? text : fitCtx(ctx, text, avail), tx + (e.right ? 4 : -4), e.y + 4);
  });
  ctx.textAlign = 'left';
}

/* ================= axes ================= */
export function drawAxes(ctx: Ctx, W: number, H: number, pad: { l: number; r: number; t: number; b: number }, max: number, t: Theme, ox = 0, oy = 0) {
  const ch = H - pad.t - pad.b;
  ctx.font = font(t, 600, 10.5);
  for (let g = 0; g <= 4; g++) {
    const y = pad.t + ch - (ch * g) / 4;
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    ctx.beginPath();
    if (ox) { ctx.moveTo(pad.l, y); ctx.lineTo(pad.l + ox, y - oy); ctx.lineTo(W - pad.r + ox, y - oy); }
    else { ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); }
    ctx.stroke();
    ctx.fillStyle = t.axis; ctx.textAlign = 'right';
    ctx.fillText(fmtNum((max * g) / 4), pad.l - 7, y + 3.5);
  }
  ctx.strokeStyle = t.axis; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(pad.l, pad.t - 4); ctx.lineTo(pad.l, pad.t + ch); ctx.lineTo(W - pad.r, pad.t + ch); ctx.stroke();
  ctx.lineWidth = 1;
  ctx.textAlign = 'left';
}
