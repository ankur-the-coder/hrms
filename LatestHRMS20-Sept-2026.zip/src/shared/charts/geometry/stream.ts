/* Streamgraph model + geometry (Highcharts-style). Shared verbatim by the
   painter and the hit tester so hover always matches. */
import type { ChartDatum, StackedSeries, StreamEvent, XPlan } from '../core/types';
import { planX } from '../axes/xlabels';

/* ================= streamgraph model + geometry (Highcharts-style) =================
   Layers stack with an inside-out order (largest centred) over a smoothed
   silhouette baseline, drawn with freehand-smooth Catmull-Rom boundaries.
   Shared verbatim by the painter and the hit tester so hover always matches. */
export interface StreamLayer { name: string; color: string; values: number[] }
export interface StreamGeom {
  list: StreamLayer[]; labels: string[]; xs: number[];
  /** bound[k][j]: px y of the k-th stack boundary (0 = bottom) at column j */
  bound: number[][]; order: number[]; posOf: number[];
  padT: number; padB: number; plotW: number; plotH: number; midY: number;
  plan: XPlan;
  /** per-column totals (raw, unsmoothed) — for markers + hit % */
  totals: number[];
}
/** Canonical 10-year salary-story demo (Highcharts-style streamgraph):
 * TEN yearly salary layers (₹L p.a. salary mass per cohort) telling the
 * company's decade: joiners, exits, rejoiners, a layoff year (2021), a bonus
 * year (2023) and contract hiring (2025). Cohorts:
 *  Founders         — here all 10 years, steady compounding rises;
 *  Eng Early        — 2016 crew, fast early raises, some leave in 2021;
 *  Eng Growth       — joins 2018 hiring wave, fastest raises of anyone;
 *  Sales Core       — joins 2017, dips in the layoff, rebounds on bonus;
 *  Support          — joins 2017, flat middle years, exits partly in 2024;
 *  Marketing        — joins 2019, cut HARD in the 2021 layoff, regrows;
 *  People Ops       — joins 2018, slow-and-steady, never leaves;
 *  Finance          — joins 2018, steady, small bonus-year bump;
 *  Boomerangs       — leave in 2020–21, REJOIN in 2022 (zero middle years);
 *  Contract Flex    — contract hiring: bursts in 2020 and 2025, zero between.
 * Used as the honest built-in demo whenever no series data is supplied. */
export const STREAM_SALARY_10Y = {
  labels: ['2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
  layers: [
    { name: 'Founders', color: '#0d7a54', values: [46, 52, 60, 68, 76, 72, 80, 96, 102, 110] },
    { name: 'Eng Early', color: '#1e5aa8', values: [74, 104, 138, 172, 198, 158, 178, 226, 240, 258] },
    { name: 'Eng Growth', color: '#0ea5e9', values: [0, 0, 52, 92, 128, 112, 152, 214, 246, 288] },
    { name: 'Sales Core', color: '#c9932b', values: [0, 58, 82, 108, 122, 92, 116, 156, 168, 186] },
    { name: 'Support', color: '#14b8a6', values: [0, 34, 48, 62, 74, 58, 68, 82, 70, 76] },
    { name: 'Marketing', color: '#e11d63', values: [0, 0, 0, 56, 62, 28, 48, 84, 92, 104] },
    { name: 'People Ops', color: '#84cc16', values: [0, 0, 30, 38, 46, 42, 50, 62, 68, 74] },
    { name: 'Finance', color: '#64748b', values: [0, 0, 26, 32, 38, 34, 40, 50, 56, 60] },
    { name: 'Boomerangs', color: '#f97316', values: [26, 34, 30, 26, 12, 0, 22, 42, 48, 54] },
    { name: 'Contract Flex', color: '#a16207', values: [0, 0, 0, 0, 44, 18, 0, 0, 26, 58] },
  ],
  events: [
    { at: 1, label: 'Sales + Support join', detail: 'GTM founded' },
    { at: 2, label: 'Hiring wave', detail: '60+ joiners' },
    { at: 5, label: 'Layoff period', detail: '-18% salary base' },
    { at: 6, label: 'Boomerangs return', detail: 'Rejoiners + growth' },
    { at: 7, label: 'Bonus year', detail: '+24% payouts' },
    { at: 9, label: 'Contract hiring', detail: 'Flex workforce' },
  ] as StreamEvent[],
};
export function streamGeom(
  multi: boolean, cats: string[], series: StackedSeries[], sColors: string[],
  data: ChartDatum[], colors: string[], pal: string[],
  W: number, H: number, full: boolean,
): StreamGeom | null {
  let list: StreamLayer[] = [];
  let labels: string[] = [];
  if (multi && series.length && cats.length >= 2) {
    labels = cats;
    list = series.map((s, i) => ({
      name: s.name, color: s.color || sColors[i] || pal[i % pal.length],
      values: cats.map((_, j) => s.values[j] || 0),
    }));
  } else {
    // Honest built-in demo: the 10-year salary story (not a meander hack).
    // Layer colours resolve through the live palette when the demo's own
    // colours are absent so theme switching still works.
    labels = STREAM_SALARY_10Y.labels.slice();
    list = STREAM_SALARY_10Y.layers.map((l, i) => ({
      name: l.name, color: l.color || colors[i] || pal[i % pal.length], values: l.values.slice(),
    }));
    void data;
  }
  const n = labels.length;
  const padT = 46, padL = 14, padR = 14;
  const plotW = W - padL - padR;
  const xs = labels.map((_, j) => padL + (plotW * j) / Math.max(1, n - 1));
  const stepS = n > 1 ? plotW / (n - 1) : plotW;
  const plan = planX(labels, stepS, full);
  const padB = plan.padB;
  const plotH = Math.max(40, H - padT - padB);
  const midY = padT + plotH / 2;
  const totals = list.map((l) => l.values.reduce((a, b) => a + b, 0));
  // Onset order (Highcharts streamgraph): layers ordered by the column
  // where they FIRST become non-zero (ties → larger total first), then
  // inside-out around the centre. New joiners / rejoiners therefore enter
  // at the river's edge instead of tearing through the middle.
  const onset = list.map((l) => {
    const j = l.values.findIndex((v) => (v || 0) > 0);
    return j < 0 ? n : j;
  });
  const desc = list.map((_, i) => i).sort((a, b) => (onset[a] - onset[b]) || (totals[b] - totals[a]));
  const order: number[] = [];
  desc.forEach((si, k) => { if (k % 2 === 0) order.push(si); else order.unshift(si); });
  const S = labels.map((_, j) => list.reduce((a, l) => a + (l.values[j] || 0), 0));
  const maxS = Math.max(...S, 1);
  // ThemeRiver-style symmetric baseline: the smoothed silhouette centres on
  // midY (zero pinch at all-zero columns), so layers breathe like the
  // reference instead of shearing diagonally.
  const sm = S.map((s, j) => {
    if (s <= 0) return 0;
    let a = 0, c = 0;
    for (let k = -2; k <= 2; k++) { const jj = j + k; if (jj >= 0 && jj < n && S[jj] > 0) { a += S[jj]; c++; } }
    const avg = c ? a / c : s;
    return avg * 0.55 + s * 0.45;
  });
  const scaleY = plotH / (maxS * 1.06);
  const Y = (v: number) => midY - v * scaleY;
  const bound: number[][] = [];
  const acc = sm.map((s) => -s / 2);
  bound.push(acc.map(Y));
  order.forEach((si) => {
    for (let j = 0; j < n; j++) acc[j] += list[si].values[j] || 0;
    bound.push(acc.map(Y));
  });
  // Organic flow (reference look): smooth every stacked boundary so BOTH
  // edges of each band breathe smoothly even when raw column totals jump.
  // True-zero columns are re-pinched afterwards (gap years shut the river).
  for (let pass = 0; pass < 2; pass++) {
    bound.forEach((b) => {
      const c = b.slice();
      for (let j = 1; j < n - 1; j++) b[j] = (c[j - 1] + c[j] * 2 + c[j + 1]) / 4;
    });
  }
  for (let j = 0; j < n; j++) {
    if (S[j] <= 0) bound.forEach((b) => { b[j] = midY; });
  }
  // Rounded silhouette noses: taper the outer two columns toward midY.
  if (n > 3) {
    bound.forEach((b) => {
      b[0] = midY + (b[0] - midY) * 0.10;
      b[1] = midY + (b[1] - midY) * 0.45;
      b[n - 1] = midY + (b[n - 1] - midY) * 0.10;
      b[n - 2] = midY + (b[n - 2] - midY) * 0.45;
    });
  }
  const posOf = new Array(list.length).fill(0);
  order.forEach((si, k) => { posOf[si] = k; });
  return { list, labels, xs, bound, order, posOf, padT, padB, plotW, plotH, midY, plan, totals: S.slice() };
}
