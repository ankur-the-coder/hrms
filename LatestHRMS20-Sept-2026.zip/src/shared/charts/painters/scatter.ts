/* Painter: scatter — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, ScatterPoint, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintScatter(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const rawScatter: ScatterPoint[] = d.scatter && d.scatter.length ? d.scatter : (
    data.map((x, i) => ({
      x: 20 + i * 8 + ((i * 13) % 19),
      y: x.value,
      label: x.label,
      size: 7 + ((i * 3) % 5),
      color: colors[i % colors.length],
    }))
  );

  const padL = 52, padR = 24, padT = 34, padB = 40;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const xs = rawScatter.map((pt) => pt.x);
  const ys = rawScatter.map((pt) => pt.y);
  const minX = Math.min(...xs, 0), maxX = Math.max(...xs, minX + 1);
  const minY = Math.min(...ys, 0), maxY = Math.max(...ys, minY + 1);

  const sOx = 16 * m, sOy = 12 * m;
  drawAxes(ctx, W, H, { l: padL, r: padR, t: padT, b: padB }, maxY, t, sOx, sOy);

  const xSteps = 5;
  ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center';
  for (let s = 0; s <= xSteps; s++) {
    const val = minX + ((maxX - minX) * s) / xSteps;
    const gx = padL + (plotW * s) / xSteps;
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    ctx.beginPath();
    if (m > 0.02) { ctx.moveTo(gx, padT + plotH); ctx.lineTo(gx + sOx, padT + plotH - sOy); ctx.lineTo(gx + sOx, padT - sOy); }
    else { ctx.moveTo(gx, padT); ctx.lineTo(gx, padT + plotH); }
    ctx.stroke();
    ctx.fillStyle = t.axis; ctx.fillText(fmtNum(val), gx + (m > 0.02 ? sOx / 2 : 0), padT + plotH + 18);
  }
  ctx.textAlign = 'left';
  // 3D floor wash so the room reads
  if (m > 0.02) {
    ctx.fillStyle = rgba(t.ink, 0.05 * m);
    ctx.beginPath();
    ctx.moveTo(padL, padT + plotH); ctx.lineTo(padL + sOx, padT + plotH - sOy);
    ctx.lineTo(padL + plotW + sOx, padT + plotH - sOy); ctx.lineTo(padL + plotW, padT + plotH);
    ctx.closePath(); ctx.fill();
  }

  // Linear regression trendline
  if (rawScatter.length >= 2) {
    const n = rawScatter.length;
    const sumX = xs.reduce((a, b) => a + b, 0), sumY = ys.reduce((a, b) => a + b, 0);
    const sumXY = rawScatter.reduce((a, pt) => a + pt.x * pt.y, 0);
    const sumX2 = xs.reduce((a, b) => a + b * b, 0);
    const slope = (n * sumXY - sumX * sumY) / Math.max(1e-6, n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    const px0 = padL, py0 = padT + plotH - ((intercept + slope * minX - minY) / (maxY - minY)) * plotH;
    const px1 = padL + plotW, py1 = padT + plotH - ((intercept + slope * maxX - minY) / (maxY - minY)) * plotH;
    ctx.strokeStyle = rgba(t.axis, 0.4); ctx.lineWidth = 1.5; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(px0, py0); ctx.lineTo(px1, py1); ctx.stroke();
    ctx.setLineDash([]);
  }

  // Painter's order in 3D: far (small y-value → back) first so near spheres overlap correctly
  const sOrder = rawScatter.map((_, i) => i).sort((a, b) => (m > 0.02 ? rawScatter[a].y - rawScatter[b].y : a - b));
  sOrder.forEach((i) => {
    const pt = rawScatter[i];
    const lift = m > 0.02 ? (pt.size || 7) * 0.9 * m : 0;
    const px = padL + ((pt.x - minX) / (maxX - minX)) * plotW + (m > 0.02 ? sOx * 0.5 : 0);
    const py = padT + plotH - ((pt.y - minY) / (maxY - minY)) * plotH - (m > 0.02 ? sOy * 0.5 : 0) - lift;
    const baseR = pt.size || 7;
    const rad = Math.max(1.5, baseR * Math.max(0.05, p));
    const on = hov.idx === i;
    const col = pt.color || colors[i % colors.length] || '#0d7a54';

    if (m > 0.02) {
      // drop stem from sphere to floor + contact ellipse: classic 3D scatter depth cue
      const fx = px, fy = padT + plotH - sOy * 0.35;
      ctx.strokeStyle = rgba(col, 0.45);
      ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(px, py + rad * 0.8); ctx.lineTo(fx, fy); ctx.stroke();
      ctx.fillStyle = rgba(t.ink, 0.16 * m);
      ctx.beginPath(); ctx.ellipse(fx, fy, rad * 0.85, rad * 0.32, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = rgba(col, 0.30);
      ctx.beginPath(); ctx.ellipse(fx, fy, rad * 0.55, rad * 0.2, 0, 0, Math.PI * 2); ctx.fill();
    }

    if (on) {
      ctx.strokeStyle = rgba(col, 0.5); ctx.lineWidth = 1; ctx.setLineDash([2, 2]);
      ctx.beginPath(); ctx.moveTo(padL, py); ctx.lineTo(padL + plotW, py); ctx.moveTo(px, padT); ctx.lineTo(px, padT + plotH); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = rgba(col, 0.2); ctx.beginPath(); ctx.arc(px, py, rad + 6 + 3 * m, 0, Math.PI * 2); ctx.fill();
    }

    // shaded sphere: stronger light model in 3D + crisp specular dot
    const rr = on ? rad + 2 * hov.amt : rad;
    const r0 = Math.max(0.1, rr * 0.12);
    const g = ctx.createRadialGradient(px - rr * 0.35, py - rr * 0.4, r0, px, py, rr);
    g.addColorStop(0, shade(col, m > 0.02 ? 1.55 : 1.35));
    g.addColorStop(0.55, shade(col, on ? 1 + 0.12 * hov.amt : 1));
    g.addColorStop(1, shade(col, m > 0.02 ? 0.55 : 0.85));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, rr, 0, Math.PI * 2); ctx.fill();
    if (m > 0.02) {
      ctx.fillStyle = rgba('#ffffff', 0.85);
      ctx.beginPath(); ctx.arc(px - rr * 0.34, py - rr * 0.4, Math.max(0.8, rr * 0.16), 0, Math.PI * 2); ctx.fill();
    }
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1; ctx.stroke();
    // Labels: hovered point always; otherwise a decluttered subset —
    // greedy min-distance pass in 3D so dense clouds stay readable.
    (pt as ScatterPoint & { _lx?: number; _ly?: number })._lx = px;
    (pt as ScatterPoint & { _lx?: number; _ly?: number })._ly = py - rr - 6;
  });
  // second pass: collision-free labels (3D dense-data fix)
  const labelPts = sOrder
    .map((i) => ({ i, pt: rawScatter[i] }))
    .filter(({ pt, i }) => hov.idx === i || (m > 0.02 && pt.label && pt.label.trim().length > 0));
  const placed: { x: number; y: number; w: number }[] = [];
  ctx.font = font(t, 700, 9.5); ctx.textAlign = 'center';
  // hovered first so it always wins collisions
  labelPts.sort((a, b) => (hov.idx === b.i ? 1 : 0) - (hov.idx === a.i ? 1 : 0));
  labelPts.forEach(({ i, pt }) => {
    const on = hov.idx === i;
    const px = (pt as ScatterPoint & { _lx?: number })._lx ?? 0;
    const py = (pt as ScatterPoint & { _ly?: number })._ly ?? 0;
    const shown = fitCtx(ctx, pt.label || `(${fmtNum(pt.x)}, ${fmtNum(pt.y)})`, 90);
    const w = measureW(ctx, shown) + 8;
    if (!on) {
      for (const q of placed) {
        if (Math.abs(q.x - px) < (q.w + w) / 2 && Math.abs(q.y - py) < 13) return;
      }
      if (m <= 0.02) return; // 2D keeps hover-only labels (unchanged behaviour)
    }
    placed.push({ x: px, y: py, w });
    ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.82);
    const tw = measureW(ctx, shown);
    ctx.beginPath(); ctx.roundRect(px - tw / 2 - 4, py - 10, tw + 8, 14, 7); ctx.fill();
    ctx.fillStyle = on ? t.ink : t.axis;
    ctx.fillText(shown, px, py + 1);
  });
  return;
}
