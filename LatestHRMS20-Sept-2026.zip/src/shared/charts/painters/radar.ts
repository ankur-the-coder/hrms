/* Painter: radar — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintRadar(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  /* ============ RADAR — sticks + thread, no fill volume ============
     The chart shows ONLY vertical sticks (one per axis, height =
     value) and the thread polygon connecting the stick tips. There is
     deliberately NO filled area and NO extruded slab — in 2D or 3D.
     2D→3D is a pure camera tilt: the SAME vertex math (angle i, radius
     v/max·R) is projected through an oblique view whose pitch grows
     with m, plus stick verticals so height reads in 3D. Vertices
     never move off their data radius at any morph step. */
  const labels = multi ? cats : data.map((x) => x.label);
  const longest = Math.max(0, ...labels.map((l) => approxW(l)));
  const margin = full ? Math.min(W * 0.4, longest + 24) : 44;
  const cx = W / 2, cy = H / 2 + 6;
  const squash = 1 - 0.52 * m;
  const Rflat = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30) / Math.max(0.45, squash)));
  const depth = Math.min(46, Math.max(12, Rflat * 0.24)) * m;
  const R = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30 - depth) / Math.max(0.45, squash)));
  const n = Math.max(1, labels.length);
  const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
  const ang = (i: number) => -Math.PI / 2 + (i * Math.PI * 2) / n;
  // ONE projection for every element at every morph step: disc point +
  // vertical stick height h (in px). 2D: h collapses (sticks are dots);
  // 3D: h lifts tips toward the viewer-tilted plane. The disc itself is
  // identical in 2D and 3D, so 2D→3D never re-plots the data.
  const P = (a: number, r: number, h = 0) => ({
    x: cx + Math.cos(a) * r,
    y: cy + Math.sin(a) * r * squash - h,
  });

  // ---- floor shadow of the web (3D only) ----
  if (m > 0.02) {
    ctx.save();
    setShadow(ctx, 0, 9 * m + 2, 18, rgba(t.ink, 0.20 * m));
    ctx.fillStyle = rgba(t.ink, 0.08 * m);
    ctx.beginPath();
    for (let i = 0; i <= n; i++) {
      const q = P(ang(i % n), R);
      i === 0 ? ctx.moveTo(q.x, q.y + depth * 0.4) : ctx.lineTo(q.x, q.y + depth * 0.4);
    }
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }
  // ---- web rings (tilted ellipses in 3D) ----
  for (let ring = 1; ring <= 3; ring++) {
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i <= n; i++) {
      const q = P(ang(i % n), (R * ring) / 3);
      i === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y);
    }
    ctx.stroke();
  }
  ctx.font = font(t, 600, 10.5);
  labels.forEach((l, i) => {
    const aa = ang(i);
    const q = P(aa, R);
    ctx.strokeStyle = t.grid;
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(q.x, q.y); ctx.stroke();
    ctx.fillStyle = t.axis;
    ctx.textAlign = Math.abs(Math.cos(aa)) < 0.3 ? 'center' : Math.cos(aa) > 0 ? 'left' : 'right';
    const lx = cx + Math.cos(aa) * (R + 12);
    const avail = Math.abs(Math.cos(aa)) < 0.3 ? W - 8 : Math.cos(aa) > 0 ? W - lx - 4 : lx - 4;
    ctx.fillText(full ? l : fitCtx(ctx, l, Math.max(30, avail)), lx, cy + Math.sin(aa) * (R + 12) * squash + 3);
  });
  const polys = multi
    ? series.map((s, i) => ({ color: sColors[i], values: s.values }))
    : [{ color: colors[0], values: data.map((x) => x.value) }];
  // Stick height: value-proportional lift in 3D only (0 in 2D), so the
  // tips rise off the disc while the disc footprint stays data-true.
  const stickH = (pi: number, i: number) => {
    const v = (polys[pi].values[i % n] || 0) / max;
    return v * depth * p;
  };
  const vert = (pi: number, i: number) => {
    const v = (polys[pi].values[i % n] || 0) / max;
    return P(ang(i % n), v * R * p, stickH(pi, i));
  };
  const foot = (pi: number, i: number) => {
    const v = (polys[pi].values[i % n] || 0) / max;
    return P(ang(i % n), v * R * p, 0);
  };
  const traceThread = (pi: number) => {
    for (let i = 0; i <= n; i++) {
      const q = vert(pi, i);
      i === 0 ? ctx.moveTo(q.x, q.y) : ctx.lineTo(q.x, q.y);
    }
    ctx.closePath();
  };
  // ---- sticks: shaded verticals from disc foot to tip (3D), dots (2D) ----
  polys.forEach((poly, pi) => {
    const onS = multi && hov.seg?.s === pi;
    const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
    ctx.save();
    ctx.globalAlpha *= sDim;
    for (let i = 0; i < n; i++) {
      const f = foot(pi, i), v = vert(pi, i);
      if (m > 0.02 && v.y < f.y - 0.5) {
        // stick: dark foot → bright tip, width tapers with light
        const sg = ctx.createLinearGradient(0, f.y, 0, v.y);
        sg.addColorStop(0, shade(poly.color, 0.55));
        sg.addColorStop(1, onS ? shade(poly.color, 1.2 + 0.1 * hov.amt) : shade(poly.color, 1.05));
        ctx.strokeStyle = sg;
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(v.x, v.y); ctx.stroke();
        ctx.lineCap = 'butt';
        // foot dot on the disc
        ctx.fillStyle = shade(poly.color, 0.8);
        ctx.beginPath(); ctx.arc(f.x, f.y, 2.2, 0, Math.PI * 2); ctx.fill();
      }
    }
    ctx.restore();
    void pi;
  });
  // ---- thread: the connecting polygon through the stick tips ----
  polys.forEach((poly, pi) => {
    const onS = multi && hov.seg?.s === pi;
    const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
    ctx.save();
    ctx.globalAlpha *= sDim;
    ctx.beginPath();
    traceThread(pi);
    ctx.strokeStyle = onS ? shade(poly.color, 1.15) : poly.color;
    ctx.lineWidth = (onS ? 2.6 : 2) + m * 0.6;
    ctx.lineJoin = 'round';
    if (m > 0.02) {
      ctx.save();
      ctx.shadowColor = rgba(poly.color, 0.45 * m);
      ctx.shadowBlur = 6;
      ctx.stroke();
      ctx.restore();
    } else {
      ctx.stroke();
    }
    ctx.restore();
  });
  // ---- tip knots: glossy spheres on every stick tip ----
  polys.forEach((poly, pi) => {
    const sDim = multi && hov.seg && hov.seg.s !== pi ? 1 - 0.55 * hov.amt : 1;
    ctx.save();
    ctx.globalAlpha *= sDim;
    for (let i = 0; i < n; i++) {
      const q = vert(pi, i);
      const on = !multi && hov.idx === i;
      const rr = 3.4 + m * 1.2 + (on ? 2 * hov.amt : 0);
      const kg = ctx.createRadialGradient(q.x - rr * 0.3, q.y - rr * 0.35, rr * 0.1, q.x, q.y, rr);
      kg.addColorStop(0, '#ffffff');
      kg.addColorStop(0.4, shade(poly.color, 1.2));
      kg.addColorStop(1, shade(poly.color, 0.7));
      ctx.fillStyle = kg;
      ctx.beginPath(); ctx.arc(q.x, q.y, rr, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
    }
    ctx.restore();
  });
  ctx.textAlign = 'left';
  return;
}
