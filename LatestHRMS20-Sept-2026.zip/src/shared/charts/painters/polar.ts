/* Painter: polar — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintPolar(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const g = circGeom(W, H, m, data, full);
  const cx = g.cx, cy = g.cy, R = g.R;
  const squash = 1 - 0.44 * m;
  const depth = 16 * m;
  const max = Math.max(...data.map((x) => x.value), 1);

  if (m > 0.05) {
    ctx.save();
    setShadow(ctx, 0, 8, 20, rgba(t.ink, 0.22 * m));
    ctx.fillStyle = t.surface || '#e4e7e0';
    ctx.beginPath();
    ctx.ellipse(cx, cy + depth, R, R * squash, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  for (let ring = 1; ring <= 3; ring++) {
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(cx, cy, R * (ring / 3), R * (ring / 3) * squash, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  const n = Math.max(1, data.length);
  const pieces = data.map((x, i) => {
    const a0 = -Math.PI / 2 + (i * Math.PI * 2) / n;
    const a1 = a0 + (Math.PI * 2) / n;
    const offset = radialOffset((a0 + a1) / 2, hov.idx === i ? 14 * hov.amt : 0, squash);
    return { i, a0, a1, r: Math.max(2, (x.value / max) * R * p), dx: offset.x, dy: offset.y };
  });
  // Closed opaque prisms. All faces move together in the chart plane, never upward in Z.
  const faces: { y: number; draw: () => void }[] = [];
  pieces.forEach(({ i, a0, a1, r, dx, dy }) => {
    if (m <= 0.005) return;
    const x = (a: number) => cx + dx + Math.cos(a) * r;
    const y = (a: number) => cy + dy + Math.sin(a) * r * squash;
    [a0, a1].forEach(edge => faces.push({
      y: cy + dy + Math.sin(edge) * r * squash / 2,
      draw: () => {
        ctx.fillStyle = shade(colors[i], 0.72);
        ctx.beginPath(); ctx.moveTo(cx + dx, cy + dy); ctx.lineTo(x(edge), y(edge));
        ctx.lineTo(x(edge), y(edge) + depth); ctx.lineTo(cx + dx, cy + dy + depth);
        ctx.closePath(); ctx.fill();
      },
    }));
    const count = Math.max(3, Math.ceil((a1 - a0) * r / 6));
    for (let step = 0; step < count; step++) {
      const b0 = a0 + (a1 - a0) * step / count;
      const b1 = a0 + (a1 - a0) * (step + 1) / count;
      const mid = (b0 + b1) / 2;
      if (Math.sin(mid) <= 0) continue;
      faces.push({ y: y(mid), draw: () => {
        ctx.fillStyle = shade(colors[i], 0.64 + 0.16 * Math.cos(mid));
        ctx.beginPath(); ctx.moveTo(x(b0), y(b0)); ctx.lineTo(x(b1), y(b1));
        ctx.lineTo(x(b1), y(b1) + depth); ctx.lineTo(x(b0), y(b0) + depth);
        ctx.closePath(); ctx.fill();
      } });
    }
  });
  faces.sort((a, b) => a.y - b.y).forEach(face => face.draw());
  pieces.forEach(({ i, a0, a1, r, dx, dy }) => {
    ctx.fillStyle = hov.idx === i ? shade(colors[i], 1 + 0.1 * hov.amt) : colors[i];
    ctx.beginPath(); ctx.moveTo(cx + dx, cy + dy);
    ctx.ellipse(cx + dx, cy + dy, r, r * squash, 0, a0, a1);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 0.7; ctx.stroke();
  });
  if (p > 0.95) drawLeaders(ctx, cx, cy, R, squash, data, colors, total, t, W, H, true, full);
  return;
}
