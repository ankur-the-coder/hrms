/* Painter: pie + donut — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintPieDonut(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
const g = circGeom(W, H, m, data, full);
const { cx, cy, R: R0, depth, squash } = g;
const rIn = kind === 'donut' ? R0 * g.rInRatio : 0;

interface Seg { a0: number; a1: number; i: number }
let a = -Math.PI / 2;
const segs: Seg[] = data.map((x, i) => {
  const a1 = a + (x.value / total) * Math.PI * 2 * p;
  const s = { a0: a, a1, i };
  a = a1;
  return s;
});
// hover: the slice pops radially outward along its true angle vector from the center
const hovAmt = (s: Seg) => (hov.idx === s.i ? hov.amt : 0);
const pullOf = (s: Seg) => 14 * hovAmt(s);                 // radial pop along the bisector angle
const px = (ang: number, r: number) => cx + Math.cos(ang) * r;
const py = (ang: number, r: number) => cy + Math.sin(ang) * r * squash;
const OVER = 0.012;
// per-slice translation (dx, dy) in screen space: pure radial along angle vector
const offsetOf = (s: Seg): [number, number] => {
  const a = hovAmt(s);
  if (!a) return [0, 0];
  const mid = (s.a0 + s.a1) / 2, pull = pullOf(s);
  const offset = radialOffset(mid, pull, squash);
  return [offset.x, offset.y];
};

// soft ground shadow (live only) — replaces the CSS drop-shadow filter that
// made large-canvas morphs stutter; fades out as the chart extrudes
if (!d.bg && m < 0.999 && p > 0.05) {
  ctx.save();
  setShadow(ctx, 0, 7, 16, rgba(t.ink, 0.2 * (1 - m)));
  ctx.fillStyle = t.surface || '#e4e7e0';
  ctx.beginPath(); ctx.ellipse(cx, cy + depth, R0 + 1, (R0 + 1) * squash, 0, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

/** Draw one slice's 3D body (outer rim, inner rim, cut faces) depth-sorted. */
// exports (vector recorder) get ONE arc-bounded band per slice with a gradient
// instead of dozens of shaded strips — same look, a fraction of the file size
const vector = !!d.bg;
const drawBody = (s: Seg, dx: number, dy: number) => {
  const faces: { y: number; draw: () => void }[] = [];
  const Rx = R0;
  const col = hov.idx === s.i ? shade(colors[s.i], 1 + 0.08 * hov.amt) : colors[s.i];
  if (vector) {
    const vis0 = Math.max(s.a0, 0), vis1 = Math.min(s.a1, Math.PI); // front half only
    if (vis1 > vis0 + 1e-4) {
      faces.push({
        y: py((vis0 + vis1) / 2, Rx),
        draw: () => {
          const g = ctx.createLinearGradient(px(vis0, Rx) + dx, 0, px(vis1, Rx) + dx, 0);
          g.addColorStop(0, shade(col, 0.62 + 0.2 * Math.cos(vis0)));
          g.addColorStop(1, shade(col, 0.62 + 0.2 * Math.cos(vis1)));
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, vis0, vis1, false);
          ctx.ellipse(cx + dx, cy + dy + depth, Rx, Rx * squash, 0, vis1, vis0, true);
          ctx.closePath(); ctx.fill();
        },
      });
    }
    if (rIn > 0) {
      const b0 = Math.max(s.a0, Math.PI), b1 = Math.min(s.a1, Math.PI * 2); // inner wall visible at the back
      const c0 = Math.max(s.a0, -Math.PI), c1 = Math.min(s.a1, 0);
      [[b0, b1], [c0, c1]].forEach(([q0, q1]) => {
        if (q1 <= q0 + 1e-4) return;
        faces.push({
          y: py((q0 + q1) / 2, rIn) - 900,
          draw: () => {
            ctx.fillStyle = shade(colors[s.i], 0.52);
            ctx.beginPath();
            ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, q0, q1, false);
            ctx.ellipse(cx + dx, cy + dy + depth, rIn, rIn * squash, 0, q1, q0, true);
            ctx.closePath(); ctx.fill();
          },
        });
      });
    }
    ([s.a0, s.a1] as const).forEach((edge) => {
      faces.push({
        y: py(edge, (Rx + rIn) / 2) - 0.25,
        draw: () => {
          ctx.fillStyle = shade(colors[s.i], 0.72);
          ctx.beginPath();
          if (rIn > 0) {
            ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy); ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy); ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
          } else {
            ctx.moveTo(cx + dx, cy + dy); ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy); ctx.lineTo(cx + dx, cy + depth + dy);
          }
          ctx.closePath(); ctx.fill();
        },
      });
    });
    return faces;
  }
  const steps = Math.max(3, Math.min(72, Math.ceil(((s.a1 - s.a0) * Rx) / 7)));
  for (let k = 0; k < steps; k++) {
    const b0 = s.a0 + ((s.a1 - s.a0) * k) / steps - OVER;
    const b1 = s.a0 + ((s.a1 - s.a0) * (k + 1)) / steps + OVER;
    const midS = (b0 + b1) / 2;
    if (Math.sin(midS) <= 0) continue;
    faces.push({
      y: py(midS, Rx),
      draw: () => {
        ctx.fillStyle = shade(col, 0.62 + 0.2 * Math.cos(midS));
        ctx.beginPath();
        ctx.moveTo(px(b0, Rx) + dx, py(b0, Rx) + dy);
        ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + dy);
        ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + depth + dy);
        ctx.lineTo(px(b0, Rx) + dx, py(b0, Rx) + depth + dy);
        ctx.closePath(); ctx.fill();
      },
    });
  }
  if (rIn > 0) {
    const inner = Math.max(3, Math.min(48, Math.ceil(((s.a1 - s.a0) * rIn) / 7)));
    for (let k = 0; k < inner; k++) {
      const b0 = s.a0 + ((s.a1 - s.a0) * k) / inner - OVER;
      const b1 = s.a0 + ((s.a1 - s.a0) * (k + 1)) / inner + OVER;
      const midS = (b0 + b1) / 2;
      const back = Math.sin(midS) < 0;
      faces.push({
        y: back ? py(midS, rIn) - 900 : py(midS, rIn) - 0.5,
        draw: () => {
          ctx.fillStyle = shade(colors[s.i], back ? 0.52 : 0.44);
          ctx.beginPath();
          ctx.moveTo(px(b0, rIn) + dx, py(b0, rIn) + dy);
          ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + dy);
          ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + depth + dy);
          ctx.lineTo(px(b0, rIn) + dx, py(b0, rIn) + depth + dy);
          ctx.closePath(); ctx.fill();
        },
      });
    }
  }
  ([s.a0, s.a1] as const).forEach((edge) => {
    faces.push({
      y: py(edge, (Rx + rIn) / 2) - 0.25,
      draw: () => {
        ctx.fillStyle = shade(colors[s.i], 0.88);
        ctx.beginPath();
        if (rIn > 0) {
          ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy);
          ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
          ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
          ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
        } else {
          ctx.moveTo(cx + dx, cy + dy);
          ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
          ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
          ctx.lineTo(cx + dx, cy + depth + dy);
        }
        ctx.closePath(); ctx.fill();
      },
    });
  });
  return faces;
};
/** Draw one slice's top face — polar 3D style: radial pop + brightness boost
 *  on the hovered slice, soft glossy bevel that matches the polar chart. */
const drawTop = (s: Seg, dx: number, dy: number) => {
  const Rx = R0;
  const on = hov.idx === s.i;
  const pull = on ? 14 * hov.amt : 0;
  const o = OVER * clamp01(m * 8);
  // Soft drop shadow under the hovered slice — matches polar's hover lift feel
  if (on && pull > 0.5) {
    ctx.save();
    ctx.fillStyle = rgba(t.ink, 0.18 * hov.amt);
    ctx.beginPath();
    ctx.ellipse(cx + dx, cy + dy + 4, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
    if (rIn > 0) ctx.ellipse(cx + dx, cy + dy + 4, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
    else ctx.lineTo(cx + dx, cy + dy + 4);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }
  // Solid fill always — hover only lifts brightness uniformly. The old
  // radial-gradient wash faded the slice edge toward white, which read as a
  // hollow / washed-out ring on hover (notably on light slices like pink).
  ctx.fillStyle = on && hov.amt > 0.01 ? shade(colors[s.i], 1 + 0.14 * hov.amt) : colors[s.i];
  ctx.beginPath();
  ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
  if (rIn > 0) ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
  else ctx.lineTo(cx + dx, cy + dy);
  ctx.closePath(); ctx.fill();

  // NOTE: no specular wash is painted on the top face. The old white
  // overlay did two bad things in 3D: its auto-closed arc chord read as a
  // small white scratch on every slice, and the white fill made light
  // slices (e.g. pink) look non-solid. Slices stay 100 % solid color now.

  if (m < 0.02) {
    // Separator hint (2D only): stroke the rim arcs ONLY — never the full
    // slice path, whose radial cut edges used to flash as a fan of white
    // lines during the 2D⇄3D morph. 3D slices get no stroke at all, so the
    // top face stays perfectly clean and solid.
    ctx.strokeStyle = `rgba(255,255,255,${(0.55 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
    ctx.stroke();
    if (rIn > 0) {
      ctx.beginPath();
      ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, s.a0 - o, s.a1 + o, false);
      ctx.stroke();
    }
  }
};

// Hover is a planar translation, not elevation. Keep every body opaque and
// depth-sort all slices together rather than painting the active slice on top.
if (m > 0.005) {
  const faces = segs.flatMap((s) => {
    const [dx, dy] = offsetOf(s);
    return drawBody(s, dx, dy).map(face => ({ ...face, y: face.y + dy }));
  });
  faces.sort((a, b) => a.y - b.y).forEach(face => face.draw());
}
segs.forEach((s) => {
  const [dx, dy] = offsetOf(s);
  drawTop(s, dx, dy);
});

if (p > 0.95) drawLeaders(ctx, cx, cy, R0, squash, data, colors, total, t, W, H, false, full);
if (kind === 'donut' && m < 0.5) {
  ctx.save();
  ctx.globalAlpha = clamp01(1 - m * 2);
  ctx.fillStyle = t.ink;
  ctx.font = font(t, 700, 16, true);
  ctx.textAlign = 'center';
  ctx.fillText(String(total), cx, cy + 5);
  ctx.restore();
  ctx.textAlign = 'left';
}
}
