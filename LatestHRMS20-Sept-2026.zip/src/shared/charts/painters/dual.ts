/* Painter: dual axes — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintDual(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const labels = multi ? cats : data.map((x) => x.label);
  const colVals = multi ? cats.map((_, c) => series[0]?.values[c] || 0) : data.map((x) => x.value);
  const barColors = multi ? [sColors[0]] : colors;
  const lines: { name: string; color: string; values: number[] }[] = multi
    ? series.slice(1).map((s, i) => ({ name: s.name, color: distinctLineColor(barColors, sColors[i + 1], activePalette()), values: s.values }))
    : [{
      name: 'Cumulative %',
      // Premium slate ink for the Pareto cumulative line — never a bar color.
      color: distinctLineColor(barColors, '#0f172a', activePalette()),
      values: (() => {
        let acc = 0;
        return data.map((x) => { acc += x.value; return Math.round((acc / total) * 100); });
      })(),
    }];

  const ox = 20 * m, oy = 15 * m; // 3D isometric offset
  const maxL = Math.max(...colVals, 1);
  const maxR = Math.max(...lines.flatMap((l) => l.values), 1);
  const L = xyLayout('bar', W, H, 0, labels, 1, maxL, !!d.yLabel, full);
  const pad = { ...L.pad, r: 12 + approxW(fmtNum(maxR), 10.5) + 14 + ox, t: L.pad.t + oy };
  const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
  const step = cw / Math.max(1, labels.length);

  // 3D Isometric floor grid
  if (m > 0.05) {
    ctx.strokeStyle = rgba(t.grid, 0.4);
    ctx.lineWidth = 1;
    for (let g = 0; g <= 4; g++) {
      const y = pad.t + ch - (ch * g) / 4;
      ctx.beginPath();
      ctx.moveTo(pad.l, y);
      ctx.lineTo(pad.l + ox, y - oy);
      ctx.lineTo(W - pad.r + ox, y - oy);
      ctx.stroke();
    }
  }

  drawAxes(ctx, W, H, pad, maxL, t, m > 0.05 ? ox : 0, m > 0.05 ? oy : 0);

  // Right Y-axis
  ctx.font = font(t, 600, 10.5); ctx.fillStyle = t.axis; ctx.textAlign = 'left';
  for (let g = 0; g <= 4; g++) {
    const y = pad.t + ch - (ch * g) / 4;
    ctx.fillText(fmtNum((maxR * g) / 4) + (multi ? '' : '%'), W - pad.r + (m > 0.05 ? ox : 0) + 7, (m > 0.05 ? y - oy : y) + 3.5);
  }
  ctx.strokeStyle = t.axis; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t - 4 - (m > 0.05 ? oy : 0)); ctx.lineTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t + ch - (m > 0.05 ? oy : 0)); ctx.stroke(); ctx.lineWidth = 1;

  if (d.yLabel) {
    ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
    ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
  }
  drawXLabels(ctx, labels, planX(labels, step, full), (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);

  // 3D Columns
  labels.forEach((_, ci) => {
    const bw = Math.min(36, step * 0.5);
    const x = pad.l + step * ci + (step - bw) / 2;
    const h = (colVals[ci] / maxL) * ch * p;
    const yTop = pad.t + ch - h;
    const yBase = pad.t + ch;
    const on = multi ? !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === 0) : hov.idx === ci;
    const col = multi ? sColors[0] : colors[ci];
    const cFill = on ? shade(col, 1 + 0.16 * hov.amt) : col;

    if (m > 0.05 && h > 1) {
      // 3D Top face
      ctx.fillStyle = shade(cFill, 1.25);
      ctx.beginPath();
      ctx.moveTo(x, yTop);
      ctx.lineTo(x + ox, yTop - oy);
      ctx.lineTo(x + bw + ox, yTop - oy);
      ctx.lineTo(x + bw, yTop);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 1; ctx.stroke();

      // 3D Right face
      ctx.fillStyle = shade(cFill, 0.68);
      ctx.beginPath();
      ctx.moveTo(x + bw, yTop);
      ctx.lineTo(x + bw + ox, yTop - oy);
      ctx.lineTo(x + bw + ox, yBase - oy);
      ctx.lineTo(x + bw, yBase);
      ctx.closePath();
      ctx.fill();
    }

    // Front face
    ctx.fillStyle = cFill;
    ctx.beginPath(); ctx.roundRect(x, yTop, bw, Math.max(1, h), m > 0.05 ? 0 : [5, 5, 0, 0]); ctx.fill();
  });

  // Lines on the right axis
  lines.forEach((ln, li) => {
    const pts = ln.values.map((v, i) => ({
      x: pad.l + step * i + step / 2 + (m > 0.05 ? ox * 0.5 : 0),
      y: pad.t + ch - (v / maxR) * ch * p - (m > 0.05 ? oy * 0.5 : 0),
    }));
    if (!pts.length) return;

    // Freehand (Catmull-Rom → bezier) path shared by line AND shadow —
    // the shadow is the same curve translated down, so they always match.
    const traceFreehand = (dy: number) => {
      ctx.beginPath();
      pts.forEach((pt, i) => {
        if (i === 0) { ctx.moveTo(pt.x, pt.y + dy); return; }
        const p0 = pts[Math.max(0, i - 2)], p1 = pts[i - 1], p2 = pt, p3 = pts[Math.min(pts.length - 1, i + 1)];
        ctx.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + dy + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y + dy - (p3.y - p1.y) / 6, p2.x, p2.y + dy);
      });
    };
    // 3D Shadow ribbon (same freehand curve, offset down-right)
    if (m > 0.05) {
      ctx.strokeStyle = rgba(t.ink, 0.15);
      ctx.lineWidth = 3;
      traceFreehand(oy * 0.5);
      ctx.stroke();
    }

    ctx.strokeStyle = ln.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
    traceFreehand(0);
    ctx.stroke();

    const dense = step < 14;
    pts.forEach((pt, i) => {
      const on = multi ? !!(hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === li + 1) : hov.idx === i;
      if (dense && !on) return;
      const rad = (step < 26 ? 3.5 : 4.5) + (on ? 2 * hov.amt : 0);
      if (m > 0.05) {
        const g = ctx.createRadialGradient(pt.x - 1.5, pt.y - 1.5, 1, pt.x, pt.y, rad);
        g.addColorStop(0, shade(ln.color, 1.35));
        g.addColorStop(1, shade(ln.color, 0.75));
        ctx.fillStyle = g;
      } else {
        ctx.fillStyle = on ? shade(ln.color, 1.2) : ln.color;
      }
      ctx.beginPath(); ctx.arc(pt.x, pt.y, rad, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
    });
  });
  ctx.textAlign = 'left';
  return;
}
