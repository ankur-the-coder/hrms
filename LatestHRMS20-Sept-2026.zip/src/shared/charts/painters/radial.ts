/* Painter: radial classic + radial bars — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintRadialClassic(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  // `radialbars` (MUI-style multi-ring gauge) shares this circular-pipe
  // renderer: concentric round tubes, per-ring % of its own max, round caps.
  /* ============ RADIAL BAR (Classic + Radial Bars · circular pipes) ============
     TRUE circular pipes (round tube cross-section, not rectangular slabs):
     each datum is a torus-segment painted back-to-front in strict painter
     order (outer rings first — like the RadialBarText3D reference, far
     beads under near beads), so depth always reads correctly and nothing
     can invert or leave the frame.

     Pipe language (ported from RadialBarText3D.html, upgraded):
     - soft elliptical contact shadow per tube + glossy centre hub;
     - polar grid: concentric ellipses + radial % spokes with rim labels;
     - 2D: flat round-cap ring + thin crown gloss (clean dashboard read);
     - 3D: the SAME ring becomes a sphere-shaded pipe — concentric
       elliptical bands implement the reference's radial-gradient sphere
       (white-hot crown → light → base → dark limb), sampled along the
       exact projected tube normal, plus a bright lip + crest specular;
     - round sphere caps at both ends (never sawn rectangles);
     - frame contract: plot radius is derived from the canvas AFTER
       reserving tube radius + caps + labels, so pipes NEVER leave frame.

     Geometry contract (shared with radialGeom + the canvas hit test):
     - rings are concentric ellipses centred at (cx, cy), radii ringR(i);
     - the bar STARTS at 12 o'clock (-PI/2) and sweeps CLOCKWISE
       (angle increasing in atan2(y, x) terms) up to 0.985 of a turn;
     - ellipse squash applies to Y only: (cos a · r, sin a · r · squash). */
  const isRBS = kind === 'radialbars';
  const rg = radialGeom(W, H, data, full, 1);
  const squash = 1 - 0.44 * m;
  // Frame contract: shrink the working radius so tube + caps + depth + the
  // outer label sweep always fit. radialGeom already reserves the label
  // gutter; here we additionally reserve the tube half-width and 3D depth
  // so the pipe silhouette can never touch (let alone cross) the frame.
  const tubeHalf = rg.thick / 2;
  const depth = Math.min(14, Math.max(5, rg.thick * 0.85)) * m;
  const framePad = tubeHalf + 3 + depth * 0.6;
  const Rfit = Math.max(rg.thick + 16, Math.min(
    rg.R,
    (W - rg.labelSpace) / 2 - 10 - framePad,
    (H / 2 - 8) / Math.max(0.5, squash) - framePad - depth * 0.3,
  ));
  const kFit = rg.R > 0 ? Rfit / rg.R : 1;
  const cx = rg.cx;
  const cy = rg.cy - depth * 0.25;
  // Ring radii actually painted: scaled into the fitted frame; the hovered
  // ring slides outward, and every dependent element uses the same value.
  const ringR = (i: number) => Math.max(tubeHalf + 13, rg.ringR(i) * kFit + (hov.idx === i ? hov.amt * 3 : 0));
  const max = Math.max(...data.map((x) => x.value), 1);
  const sweepOf = (x: ChartDatum) => Math.min(Math.PI * 2 * 0.985, (x.value / max) * Math.PI * 2 * 0.985 * p);
  const A0 = -Math.PI / 2; // 12 o'clock
  // Ellipse point in screen space — the single source of truth.
  const ell = (r: number, a: number, y = cy): [number, number] =>
    [cx + Math.cos(a) * r, y + Math.sin(a) * r * squash];
  // Outward unit normal of the ellipse at angle a (for pipe shading bands).
  const ellN = (r: number, a: number): [number, number] => {
    const nx = Math.cos(a) / Math.max(0.2, r);
    const ny = Math.sin(a) / Math.max(0.2, r * squash);
    const L = Math.hypot(nx, ny) || 1;
    return [nx / L, ny / L];
  };

  // ---- polar grid: concentric ellipses + radial spokes (reference look) ----
  {
    const G = 4;
    ctx.strokeStyle = t.grid;
    ctx.lineWidth = 1;
    for (let gi = 1; gi <= G; gi++) {
      const gr = Math.max(4, (Rfit * gi) / G);
      ctx.beginPath();
      ctx.ellipse(cx, cy, gr, gr * squash, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    // spokes every 10% of the sweep with rim % labels
    ctx.font = font(t, 600, full ? 10 : 9);
    ctx.fillStyle = t.axis;
    ctx.textAlign = 'center';
    for (let pct = 10; pct <= 100; pct += 10) {
      const aa = A0 + (pct / 100) * Math.PI * 2 * 0.985;
      const [sx0, sy0] = ell(Math.max(4, Rfit / G), aa);
      const [sx1, sy1] = ell(Rfit, aa);
      ctx.strokeStyle = rgba(t.grid, 0.7);
      ctx.beginPath(); ctx.moveTo(sx0, sy0); ctx.lineTo(sx1, sy1); ctx.stroke();
      const [lx, ly] = ell(Rfit + tubeHalf + 9, aa);
      ctx.fillText(`${pct}%`, Math.max(14, Math.min(W - 14, lx)), Math.max(10, Math.min(H - 4, ly + 3)));
    }
    ctx.textAlign = 'left';
  }

  // ---- glossy centre hub (reference look) ----
  {
    const hr = Math.max(7, Math.min(20, tubeHalf * 1.15));
    ctx.fillStyle = rgba(t.ink, 0.10);
    ctx.beginPath(); ctx.ellipse(cx, cy + 3, hr + 3, (hr + 3) * squash, 0, 0, Math.PI * 2); ctx.fill();
    const hg = ctx.createLinearGradient(0, cy - hr, 0, cy + hr);
    hg.addColorStop(0, '#ffffff');
    hg.addColorStop(0.55, rgba(t.surface || '#e8e8e8', 1));
    hg.addColorStop(1, shade(t.surface || '#e8e8e8', 0.82));
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.ellipse(cx, cy, hr, hr * squash, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = rgba(t.ink, 0.14);
    ctx.lineWidth = 1;
    ctx.stroke();
    // total readout inside the hub
    ctx.font = font(t, 700, full ? 12 : 10.5);
    ctx.fillStyle = t.ink;
    ctx.textAlign = 'center';
    ctx.fillText(fmtNum(total), cx, cy + (full ? 4 : 3.5));
    ctx.textAlign = 'left';
  }

  // ---- soft contact shadow per tube (painted before any pipe) ----
  data.forEach((x, i) => {
    const sweep = sweepOf(x);
    if (sweep <= 0.01) return;
    const rr = ringR(i);
    ctx.save();
    ctx.strokeStyle = rgba(t.ink, 0.10);
    ctx.lineWidth = rg.thick;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.ellipse(cx, cy + 3 + depth * 0.4, rr, rr * squash, 0, A0, A0 + sweep);
    ctx.stroke();
    ctx.restore();
  });

  // ---- background tracks (full-circle grooves the pipes rest in) ----
  noShadow(ctx);
  data.forEach((_, i) => {
    const rr = ringR(i);
    ctx.save();
    ctx.strokeStyle = rgba(t.surface || '#e4e7e0', full ? 0.9 : 1);
    ctx.lineWidth = rg.thick;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.ellipse(cx, cy, rr, rr * squash, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = rgba(t.ink, 0.10);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(cx, cy, rr + tubeHalf, (rr + tubeHalf) * squash, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  });

  // ---- pipes, OUTER rings first (painter order = reference z-sort) ----
  const labeled: { i: number; x: ChartDatum; baseR: number; col: string; on: boolean; sweep: number; end: number }[] = [];
  const orderPipe = data.map((_, i) => i).sort((a, b) => ringR(b) - ringR(a));
  orderPipe.forEach((i) => {
    const x = data[i];
    const on = hov.idx === i;
    const col = colors[i];
    const sweep = sweepOf(x);
    const end = A0 + sweep;
    const baseR = ringR(i);
    if (sweep > 0.01) {
      if (m <= 0.05) {
        // 2D: flat round-cap tube + crown gloss thread.
        ctx.save();
        ctx.lineCap = 'round';
        ctx.strokeStyle = shade(col, 0.72);
        ctx.lineWidth = rg.thick + 1.5;
        ctx.beginPath();
        ctx.ellipse(cx, cy, baseR, baseR * squash, 0, A0, end);
        ctx.stroke();
        const grad = ctx.createLinearGradient(0, cy - baseR * squash, 0, cy + baseR * squash);
        grad.addColorStop(0, shade(col, 1.18));
        grad.addColorStop(0.5, on ? shade(col, 1 + 0.14 * hov.amt) : col);
        grad.addColorStop(1, shade(col, 0.86));
        ctx.strokeStyle = grad;
        ctx.lineWidth = rg.thick;
        ctx.beginPath();
        ctx.ellipse(cx, cy, baseR, baseR * squash, 0, A0, end);
        ctx.stroke();
        ctx.strokeStyle = rgba('#ffffff', 0.35);
        ctx.lineWidth = Math.max(1, rg.thick * 0.22);
        ctx.beginPath();
        ctx.ellipse(cx, cy - rg.thick * 0.12, baseR, baseR * squash, 0, A0 + 0.04, Math.max(A0 + 0.05, end - 0.04));
        ctx.stroke();
        ctx.restore();
      } else {
        // 3D: sphere-shaded circular pipe. Concentric elliptical bands
        // implement the reference's radial-gradient sphere shading: the
        // crown band (offset toward the light) is near-white, flanks fall
        // to base, limbs fall to dark — sampled along the true projected
        // tube normal so the pipe reads ROUND at every angle, never flat.
        const BANDS = 12;
        const base = on ? shade(col, 1 + 0.18 * hov.amt) : col;
        // pipe body: outer→inner bands, dark limbs → bright crown.
        // v=0 outer limb … v=0.5 crown … v=1 inner limb.
        for (let b = 0; b < BANDS; b++) {
          const v0 = b / BANDS, v1 = (b + 1) / BANDS;
          const vm = (v0 + v1) / 2;
          // sphere profile: sin curve peaking slightly outer-of-centre
          // (light from upper-left, like the reference spheres).
          const prof = Math.sin(Math.PI * Math.min(1, Math.max(0, vm * 0.92 + 0.04)));
          const f = (0.52 + 0.86 * prof) * m + (1 - m);
          ctx.fillStyle = shade(base, f);
          const oR = baseR + tubeHalf - (tubeHalf * 2 * b) / BANDS;
          const iR = baseR + tubeHalf - (tubeHalf * 2 * (b + 1)) / BANDS;
          ctx.beginPath();
          ctx.ellipse(cx, cy, Math.max(0.1, oR), Math.max(0.1, oR * squash), 0, A0, end);
          ctx.ellipse(cx, cy, Math.max(0.1, iR), Math.max(0.1, iR * squash), 0, end, A0, true);
          ctx.closePath(); ctx.fill();
        }
        // round sphere caps at both pipe ends (true circles in screen
        // space, shaded with the same sphere profile + white-hot core).
        ([A0, end] as const).forEach((edge, ei) => {
          if (sweep >= Math.PI * 2 * 0.985 - 1e-3 && ei === 1) return; // full ring: no seam
          const [pxx, pyy] = ell(baseR, edge);
          const rrCap = tubeHalf;
          const capG = ctx.createRadialGradient(pxx - rrCap * 0.3, pyy - rrCap * 0.35, rrCap * 0.08, pxx, pyy, rrCap);
          capG.addColorStop(0, '#ffffff');
          capG.addColorStop(0.35, shade(base, 1.22));
          capG.addColorStop(0.7, base);
          capG.addColorStop(1, shade(base, 0.55));
          ctx.fillStyle = capG;
          ctx.beginPath(); ctx.arc(pxx, pyy, rrCap, 0, Math.PI * 2); ctx.fill();
        });
        // crest specular: bright thread along the pipe crown.
        ctx.save();
        ctx.strokeStyle = rgba('#ffffff', 0.55 * m);
        ctx.lineWidth = Math.max(1, rg.thick * 0.16);
        ctx.lineCap = 'round';
        const crownR = baseR + tubeHalf * 0.30;
        ctx.beginPath();
        ctx.ellipse(cx, cy - tubeHalf * 0.18, crownR, crownR * squash, 0, A0 + 0.03, Math.max(A0 + 0.04, end - 0.03));
        ctx.stroke();
        // dark limb line on the outer edge for roundness.
        ctx.strokeStyle = rgba(shade(col, 0.4), 0.6 * m);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.ellipse(cx, cy, baseR + tubeHalf - 0.5, (baseR + tubeHalf - 0.5) * squash, 0, A0, end);
        ctx.stroke();
        ctx.restore();
      }
    }
    void ellN;

    // sweep-end dot: glossy pin at the bar tip — the leader anchor.
    if (sweep > 0.01) {
      const [dx, dy0] = ell(baseR, end);
      const dy = dy0 + depth * 0.3;
      ctx.fillStyle = shade(col, 0.55);
      ctx.beginPath(); ctx.arc(dx, dy + 1, Math.max(2.4, rg.thick * 0.32), 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = on ? shade(col, 1 + 0.18 * hov.amt) : col;
      ctx.beginPath(); ctx.arc(dx, dy, Math.max(2.4, rg.thick * 0.32), 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = rgba('#ffffff', 0.75);
      ctx.beginPath(); ctx.arc(dx - 0.8, dy - 0.9, Math.max(0.8, rg.thick * 0.1), 0, Math.PI * 2); ctx.fill();
    }

    // in-tube value chip on compact tiles when the arc is long enough.
    const arcLen = sweep * baseR;
    const canInline = !rg.roomy && arcLen > 64 && sweep > 0.5 && p > 0.9;
    if (canInline) {
      const labelAngle = A0 + sweep * 0.5;
      const [lx, ly0] = ell(baseR, labelAngle);
      ctx.font = font(t, 700, 10.5);
      ctx.fillStyle = '#fff';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const maxInline = Math.min(arcLen * 0.7, baseR * sweep * 0.8);
      ctx.fillText(fitCtx(ctx, x.label, Math.max(24, maxInline)), lx, ly0 + 0.5);
      ctx.textBaseline = 'alphabetic';
    }
    labeled.push({ i, x, baseR, col, on, sweep, end });
  });
  // Front lip overlay: re-draw ONLY the front-half pipe crown over the top
  // so near-side walls correctly overlap their own shading. Coverage: the
  // sweep can wrap past 2π, so clamp into segments.
  if (m > 0.05) labeled.forEach(({ col, baseR, sweep, end }) => {
    if (sweep <= 0.01) return;
    const rr = baseR;
    const a0 = A0, a1 = end;
    const TWO_PI = Math.PI * 2;
    const norm = (a: number) => ((a % TWO_PI) + TWO_PI) % TWO_PI;
    const n0 = norm(a0), n1 = norm(a1);
    const segs: [number, number][] = [];
    if (n1 >= n0 || sweep >= TWO_PI - 1e-3) {
      const lo = Math.max(n0, 0), hi = Math.min(n1 >= n0 ? n1 : n1 + TWO_PI, Math.PI);
      if (hi > lo) segs.push([lo, hi]);
      if (sweep >= TWO_PI - 1e-3) segs.push([0, Math.PI]);
    } else {
      if (Math.PI > n0) segs.push([n0, Math.PI]);
      if (n1 > 0) segs.push([0, Math.min(n1, Math.PI)]);
    }
    if (!segs.length) return;
    ctx.save();
    ctx.beginPath();
    segs.forEach(([lo, hi]) => {
      const outer = rr + tubeHalf, inner = Math.max(0.1, rr - tubeHalf);
      ctx.ellipse(cx, cy + depth * 0.4, outer, outer * squash, 0, lo, hi);
      ctx.ellipse(cx, cy + depth * 0.4, inner, inner * squash, 0, hi, lo, true);
      ctx.closePath();
    });
    ctx.clip();
    ctx.fillStyle = shade(col, 0.7);
    ctx.beginPath();
    segs.forEach(([lo, hi]) => {
      const outer = rr + tubeHalf, inner = Math.max(0.1, rr - tubeHalf);
      ctx.ellipse(cx, cy + depth * 0.4, outer, outer * squash, 0, lo, hi);
      ctx.ellipse(cx, cy + depth * 0.4, inner, inner * squash, 0, hi, lo, true);
      ctx.closePath();
    });
    ctx.fill();
    ctx.restore();
  });
  // Outside labels: pie/donut-style curved leaders + outlined arrowheads.
  // Each label anchors at its OWN sweep-end dot, fans out left/right by
  // anchor side, and is min-pitch stacked per side. Radial Bars shows
  // "label · pct%" (MUI gauge language); classic shows "label · value".
  const FS = full ? 12 : W >= 760 ? 11.5 : 10;
  ctx.font = font(t, 600, FS);
  const PITCH = FS + 8;
  interface RBCand { e: (typeof labeled)[number]; text: string; ax: number; ay: number; right: boolean; y: number }
  const wantLabel = (e: { on: boolean }) => (rg.roomy ? (e.on || full || rg.thick >= 5) : e.on);
  const cands: RBCand[] = labeled.filter(wantLabel).map((e) => {
    const anchorA = e.sweep > 0.03 ? e.end : A0;
    const [aX, aY0] = ell(e.baseR, anchorA);
    const aY = aY0 + depth * 0.3;
    const text = isRBS
      ? `${e.x.label} · ${Math.round((e.x.value / max) * 100)}%`
      : `${e.x.label} · ${fmtNum(e.x.value)}`;
    return { e, text, ax: aX, ay: aY, right: aX >= cx, y: aY };
  });
  const place = (list: RBCand[]) => {
    list.sort((p2, q) => p2.y - q.y);
    let prev = -Infinity;
    list.forEach((c) => { c.y = Math.max(c.y, prev + PITCH); prev = c.y; });
    list.forEach((c) => { c.y = Math.max(12, Math.min(H - 8, c.y)); });
  };
  place(cands.filter((c) => c.right));
  place(cands.filter((c) => !c.right));
  cands.forEach((c) => {
    const tx = c.right ? Math.min(W - 8, c.ax + 30) : Math.max(8, c.ax - 30);
    const ex = c.right ? tx - 8 : tx + 8;
    const mx2 = (ex + c.ax) / 2;
    ctx.strokeStyle = c.e.col;
    ctx.lineWidth = c.e.on ? 2 : 1.4;
    ctx.beginPath();
    ctx.moveTo(tx, c.y);
    ctx.lineTo(ex, c.y);
    ctx.bezierCurveTo(mx2, c.y, c.ax, c.ay, c.ax, c.ay);
    ctx.stroke();
    const dx = c.ax - mx2, dy = c.ay - c.y;
    const dl = Math.hypot(dx, dy) || 1;
    const ux = dx / dl, uy = dy / dl;
    const px2 = -uy, py2 = ux;
    const bx = c.ax - ux * 6, by = c.ay - uy * 6;
    ctx.fillStyle = c.e.col;
    ctx.beginPath();
    ctx.moveTo(c.ax + ux * 0.5, c.ay + uy * 0.5);
    ctx.lineTo(bx - ux * 1.2 + px2 * 4, by - uy * 1.2 + py2 * 4);
    ctx.lineTo(bx - ux * 1.2 - px2 * 4, by - uy * 1.2 - py2 * 4);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.lineJoin = 'round';
    ctx.stroke();
    ctx.lineJoin = 'miter';
    const avail = c.right ? W - tx - 8 : tx - 8;
    ctx.fillStyle = t.ink;
    ctx.textAlign = c.right ? 'left' : 'right';
    ctx.fillText(full ? c.text : fitCtx(ctx, c.text, Math.max(30, avail)), tx + (c.right ? 4 : -4), c.y + FS * 0.35);
  });
  ctx.textAlign = 'left';
  return;
}
