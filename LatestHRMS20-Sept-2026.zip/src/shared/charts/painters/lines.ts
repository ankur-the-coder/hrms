/* Painter: line + area — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintLines(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const list: { name: string; color: string; values: number[] }[] = multi
    ? series.map((s, i) => ({ name: s.name, color: sColors[i], values: s.values }))
    : [{ name: '', color: colors[0], values: data.map((x) => x.value) }];
  const nD = list.length;
  // smaller series sit in FRONT, larger ones recede — nothing gets hidden
  const depth = multi ? seriesDepth(series) : [0];
  const zx = ZX * m, zy = ZY * m, dz = DZ * m, dzy = DZY * m;
  const labels = multi ? cats : data.map((x) => x.label);
  const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
  const L = xyLayout(kind as 'line' | 'area', W, H, m, labels, nD, max, !!d.yLabel, full);
  const { pad, ch, step, ox, oy } = L;
  drawAxes(ctx, W, H, pad, max, t, ox, oy);
  if (d.yLabel) {
    ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
    ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
  }
  drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);

  const isArea = kind === 'area';
  const order = list.map((_, i) => i).sort((a, b) => depth[b] - depth[a]); // back → front
  for (const si of order) {
    const sr = list[si];
    const offX = zx * depth[si], offY = zy * depth[si];
    const baseY = pad.t + ch - offY;
    const pts = sr.values.map((v, i) => ({
      x: pad.l + step * i + step / 2 + offX,
      y: pad.t + ch - (v / max) * ch * p - offY,
    }));
    if (!pts.length) continue;

    // Smooth freehand curve through the points (Catmull-Rom → Bézier), the
    // SAME path builder used in 2D and 3D so the morph never kinks.
    const curve = (offX = 0, offY = 0) => {
      ctx.moveTo(pts[0].x + offX, pts[0].y + offY);
      if (pts.length === 2) { ctx.lineTo(pts[1].x + offX, pts[1].y + offY); return; }
      for (let i = 0; i < pts.length - 1; i++) {
        const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
        ctx.bezierCurveTo(
          p1.x + offX + (p2.x - p0.x) / 6, p1.y + offY + (p2.y - p0.y) / 6,
          p2.x + offX - (p3.x - p1.x) / 6, p2.y + offY - (p3.y - p1.y) / 6, p2.x + offX, p2.y + offY);
      }
    };
    // Reversed curve back along the same points — closes area bands and
    // ribbon walls without seams.
    const curveBack = (offX = 0, offY = 0) => {
      if (pts.length === 2) { ctx.lineTo(pts[0].x + offX, pts[0].y + offY); return; }
      for (let i = pts.length - 1; i > 0; i--) {
        const p0 = pts[Math.min(pts.length - 1, i + 1)], p1 = pts[i], p2 = pts[i - 1], p3 = pts[Math.max(0, i - 2)];
        ctx.bezierCurveTo(
          p1.x + offX + (p2.x - p0.x) / 6, p1.y + offY + (p2.y - p0.y) / 6,
          p2.x + offX - (p3.x - p1.x) / 6, p2.y + offY - (p3.y - p1.y) / 6, p2.x + offX, p2.y + offY);
      }
    };
    if (m > 0.02) {
      // TRUE 3D for BOTH line and area: the series floats as a smooth
      // ribbon above a soft floor shadow; the area adds a translucent
      // curtain down to the floor so depth reads at a glance.
      const lift = 10 * m + depth[si] * 3 * m;
      // floor shadow — same freehand silhouette, blurred onto the floor
      ctx.save();
      setShadow(ctx, 0, 6 * m + 3, 10, rgba(t.ink, 0.20 * m));
      ctx.fillStyle = rgba(t.ink, 0.10 * m);
      ctx.beginPath();
      curve(dz, lift - dzy + 6 * m);
      if (isArea) { ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy + 6 * m); ctx.lineTo(pts[0].x + dz, baseY - dzy + 6 * m); }
      ctx.closePath(); ctx.fill();
      ctx.restore();
      // back wall: the freehand curve swept through the depth vector —
      // front curve out, back curve reversed: a seamless smooth band
      ctx.fillStyle = shade(sr.color, isArea ? 0.62 : 0.78);
      ctx.beginPath();
      curve(0, 0);
      ctx.lineTo(pts[pts.length - 1].x + dz, pts[pts.length - 1].y - dzy);
      curveBack(dz, -dzy);
      ctx.closePath(); ctx.fill();
      if (isArea) {
        // back curtain (floor to curve, at depth) then front curtain
        ctx.fillStyle = shade(sr.color, 0.55);
        ctx.beginPath();
        curve(dz, -dzy);
        ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy);
        ctx.lineTo(pts[0].x + dz, baseY - dzy);
        ctx.closePath(); ctx.fill();
        const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ch);
        grad.addColorStop(0, withAlpha(sr.color, multi ? '66' : '7a'));
        grad.addColorStop(1, withAlpha(sr.color, '14'));
        ctx.fillStyle = grad;
        ctx.beginPath();
        curve(0, 0);
        ctx.lineTo(pts[pts.length - 1].x, baseY); ctx.lineTo(pts[0].x, baseY);
        ctx.closePath(); ctx.fill();
      } else {
        // line 3D: translucent floor curtain in the brand color
        ctx.fillStyle = withAlpha(sr.color, '26');
        ctx.beginPath();
        curve(dz, -dzy);
        ctx.lineTo(pts[pts.length - 1].x + dz, baseY - dzy);
        ctx.lineTo(pts[0].x + dz, baseY - dzy);
        ctx.closePath(); ctx.fill();
      }
      // glowing freehand crest on top
      ctx.save();
      setShadow(ctx, 0, 0, 6 * m, rgba(sr.color, 0.55 * m));
      ctx.strokeStyle = shade(sr.color, 1.18); ctx.lineWidth = isArea ? 2.2 : 2.8; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.beginPath(); curve(0, 0); ctx.stroke();
      ctx.restore();
      // end cap seals the ribbon at the last point
      ctx.fillStyle = shade(sr.color, 0.6);
      ctx.beginPath();
      ctx.moveTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
      ctx.lineTo(pts[pts.length - 1].x + dz, pts[pts.length - 1].y - dzy);
      ctx.lineTo(pts[pts.length - 1].x + dz, (isArea ? baseY : pts[pts.length - 1].y + 2) - dzy);
      ctx.lineTo(pts[pts.length - 1].x, isArea ? baseY : pts[pts.length - 1].y + 2);
      ctx.closePath(); ctx.fill();
      // markers float on the crest
      const dense = step < 14;
      pts.forEach((pt, i) => {
        const on = multi ? (hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === si) : hov.idx === i;
        if (dense && !on) return;
        ctx.save();
        setShadow(ctx, 0, 2, 4, rgba(t.ink, 0.3 * m));
        ctx.fillStyle = on ? shade(sr.color, 1 + 0.2 * hov.amt) : shade(sr.color, 1.1);
        ctx.beginPath(); ctx.arc(pt.x, pt.y, (step < 26 ? 3 : 4) + (on ? 2.5 * hov.amt : 0), 0, Math.PI * 2); ctx.fill();
        ctx.restore();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
      });
    } else {
      if (isArea) {
        ctx.beginPath(); curve();
        ctx.lineTo(pts[pts.length - 1].x, baseY); ctx.lineTo(pts[0].x, baseY); ctx.closePath();
        const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ch);
        grad.addColorStop(0, withAlpha(sr.color, multi ? '3d' : '59'));
        grad.addColorStop(1, withAlpha(sr.color, '08'));
        ctx.fillStyle = grad; ctx.fill();
        ctx.strokeStyle = sr.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
        ctx.beginPath(); curve(); ctx.stroke();
      } else {
        ctx.strokeStyle = sr.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        ctx.beginPath(); curve(); ctx.stroke();
      }
      // markers thin out automatically when points get dense
      const dense = step < 14;
      pts.forEach((pt, i) => {
        const on = multi ? (hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === si) : hov.idx === i;
        if (dense && !on) return;
        ctx.fillStyle = on ? shade(sr.color, 1 + 0.2 * hov.amt) : sr.color;
        ctx.beginPath(); ctx.arc(pt.x, pt.y, (step < 26 ? 3 : 4) + (on ? 2.5 * hov.amt : 0), 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
      });
    }
  }
  ctx.textAlign = 'left';
  return;
}
