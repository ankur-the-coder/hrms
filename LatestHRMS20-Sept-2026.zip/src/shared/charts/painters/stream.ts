/* Painter: streamgraph (legacy canvas river) — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintStream(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const gm = streamGeom(multi, cats, series, sColors, data, colors, activePalette(), W, H, full);
  if (!gm) return;
  const { list, labels, xs, bound, order, padT, plotH } = gm;
  const n = labels.length;
  const traceBound = (b: number[], dx = 0, dy = 0, upto = n) => {
    const lim = Math.max(2, Math.min(n, upto));
    ctx.moveTo(xs[0] + dx, b[0] + dy);
    if (lim === 2) { ctx.lineTo(xs[1] + dx, b[1] + dy); return; }
    for (let j = 0; j < lim - 1; j++) {
      const p0y = b[Math.max(0, j - 1)], p1y = b[j], p2y = b[j + 1], p3y = b[Math.min(n - 1, j + 2)];
      const p0x = xs[Math.max(0, j - 1)], p2x = xs[j + 1];
      const p1x = xs[j], p3x = xs[Math.min(n - 1, j + 2)];
      ctx.bezierCurveTo(
        p1x + dx + (p2x - p0x) / 6, p1y + dy + (p2y - p0y) / 6,
        xs[j + 1] + dx - (p3x - p1x) / 6, p2y + dy - (p3y - p1y) / 6,
        xs[j + 1] + dx, p2y + dy);
    }
  };
  const traceBoundBack = (b: number[], dx = 0, dy = 0, upto = n) => {
    const lim = Math.max(2, Math.min(n, upto));
    for (let j = lim - 1; j > 0; j--) {
      const p0y = b[Math.min(n - 1, j + 1)], p1y = b[j], p2y = b[j - 1], p3y = b[Math.max(0, j - 2)];
      const p0x = xs[Math.min(n - 1, j + 1)], p2x = xs[j - 1];
      const p1x = xs[j], p3x = xs[Math.max(0, j - 2)];
      ctx.bezierCurveTo(
        p1x + dx + (p2x - p0x) / 6, p1y + dy + (p2y - p0y) / 6,
        xs[j - 1] + dx - (p3x - p1x) / 6, p2y + dy - (p3y - p1y) / 6,
        xs[j - 1] + dx, p2y + dy);
    }
  };
  // column gridlines + rotated year axis (Highcharts has a bare plot area;
  // ours keeps the family's faint grid + the shared x-label planner).
  ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
  xs.forEach((x) => {
    ctx.beginPath(); ctx.moveTo(x, padT - 4); ctx.lineTo(x, padT + plotH + 4); ctx.stroke();
  });
  drawXLabels(ctx, labels, gm.plan, (j) => xs[j], padT + plotH, t, W);
  const activeS = hov.seg ? hov.seg.s : (hov.idx !== null ? hov.idx : null);
  const activeC = hov.seg ? hov.seg.c : null;
  const sFocused = activeS !== null;
  const dzS = 9 * m, dyS = 7 * m;
  const upto = Math.max(2, Math.ceil(n * easeOut(p)));
  const B = bound;
  const flat = m < 0.02;
  // ---- 3D floor shadow of the whole silhouette ----
  if (!flat) {
    ctx.save();
    setShadow(ctx, 0, 7 * m + 2, 14, rgba(t.ink, 0.18 * m));
    ctx.fillStyle = rgba(t.ink, 0.10 * m);
    ctx.beginPath();
    traceBound(B[0], dzS * 0.7, -dyS * 0.7 + 10 * m, upto);
    traceBoundBack(B[B.length - 1], dzS * 0.7, -dyS * 0.7 + 10 * m, upto);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }
  // ---- 3D slab walls, back layer first ----
  if (!flat) {
    for (let k = order.length - 1; k >= 0; k--) {
      const si = order[k];
      const b1 = B[k + 1], b0w = B[k];
      const on = activeS === si;
      const aMul = sFocused && !on ? 1 - 0.55 * hov.amt : 1;
      ctx.save();
      ctx.globalAlpha *= aMul;
      // recessed groove along the band's lower edge (paper-cut separation)
      ctx.strokeStyle = rgba(t.ink, 0.32 * m);
      ctx.lineWidth = 5; ctx.lineCap = 'round';
      ctx.beginPath();
      traceBound(b0w, dzS * 0.55, -dyS * 0.55 + 3.5, upto);
      ctx.stroke();
      ctx.lineCap = 'butt';
      // riser wall along the band's top edge (paper side, darker)
      ctx.fillStyle = shade(list[si].color, 0.50);
      ctx.beginPath();
      traceBound(b1, dzS, -dyS, upto);
      traceBoundBack(b1, 0, 0, upto);
      ctx.closePath(); ctx.fill();
      // front wall swept toward the viewer (the visible stacked strip)
      ctx.fillStyle = shade(list[si].color, 0.44);
      ctx.beginPath();
      traceBound(b0w, 0, 0, upto);
      traceBoundBack(b0w, dzS, -dyS + 4, upto);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = rgba(shade(list[si].color, 0.32), 0.9);
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      traceBound(b0w, dzS, -dyS + 4, upto);
      ctx.stroke();
      // bright rim where the riser meets the top skin
      ctx.strokeStyle = rgba('#ffffff', 0.55 * m);
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      traceBound(b1, dzS, -dyS, upto);
      ctx.stroke();
      // second inner rim: the card's cut edge catching the light
      ctx.strokeStyle = rgba('#ffffff', 0.28 * m);
      ctx.lineWidth = 1;
      ctx.beginPath();
      traceBound(b1, dzS * 0.45, -dyS * 0.45 + 1.5, upto);
      ctx.stroke();
      // end cap at the final column + toe shadow
      const ex = xs[Math.min(n - 1, upto - 1)];
      const yT = b1[Math.min(n - 1, upto - 1)], yB = b0w[Math.min(n - 1, upto - 1)];
      ctx.fillStyle = shade(list[si].color, 0.5);
      ctx.beginPath();
      ctx.moveTo(ex, yT); ctx.lineTo(ex + dzS, yT - dyS);
      ctx.lineTo(ex + dzS, yB - dyS); ctx.lineTo(ex, yB);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = rgba(t.ink, 0.12 * m);
      ctx.beginPath();
      ctx.moveTo(ex, yB); ctx.lineTo(ex + dzS, yB - dyS);
      ctx.lineTo(ex + dzS + 3, yB - dyS + 3); ctx.lineTo(ex + 3, yB + 3);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
  }
  // ---- faces: bottom layer first so upper layers overlap naturally ----
  const labelJobs: { si: number; dim: number; cx: number; x: number; w: number }[] = [];
  order.forEach((si) => {
    const k = order.indexOf(si);
    const b0 = B[k], b1 = B[k + 1];
    const on = activeS === si;
    const dim = sFocused && !on ? 1 - 0.62 * hov.amt : 1;
    ctx.save();
    ctx.globalAlpha *= dim;
    if (flat) {
      // Highcharts streamgraph: flat solid colour, gentle brighten on hover
      ctx.fillStyle = shade(list[si].color, on ? 1 + 0.14 * hov.amt : 1);
      ctx.globalAlpha *= 0.92;
    } else {
      // paper-cut 3D (reference look): each band is a thin card with a
      // bright LIT top skin, a saturated core and a deep paper edge; the
      // ramp is LOCAL to this band so every layer reads separately.
      const jm = Math.floor(n / 2);
      const gTop = b1[jm], gBot = Math.max(gTop + 2, b0[jm]);
      const grad = ctx.createLinearGradient(0, gTop, 0, gBot);
      const lift = on ? 0.10 * hov.amt : 0;
      grad.addColorStop(0, shade(list[si].color, 1.34 + lift));
      grad.addColorStop(0.28, shade(list[si].color, 1.10 + lift));
      grad.addColorStop(0.62, shade(list[si].color, 0.92));
      grad.addColorStop(1, shade(list[si].color, 0.62));
      ctx.fillStyle = grad;
    }
    ctx.beginPath();
    traceBound(b1, 0, 0, upto);
    traceBoundBack(b0, 0, 0, upto);
    ctx.closePath(); ctx.fill();
    ctx.restore();
    // crisp parting line between bands (+ white halo on the hovered layer)
    ctx.save();
    ctx.globalAlpha *= dim;
    ctx.strokeStyle = flat ? rgba('#ffffff', 0.85) : rgba('#ffffff', 0.7);
    ctx.lineWidth = flat ? 1.5 : 1;
    ctx.beginPath();
    traceBound(b1, 0, 0, upto);
    ctx.stroke();
    if (on) {
      ctx.strokeStyle = rgba('#ffffff', 0.95);
      ctx.lineWidth = flat ? 2.5 : 2;
      ctx.beginPath();
      traceBound(b1, 0, 0, upto);
      ctx.stroke();
    }
    ctx.restore();
    // in-stream label candidate at the layer's widest column
    let wj = 0, ww = -1;
    for (let j = 0; j < n; j++) { const w = b0[j] - b1[j]; if (w > ww) { ww = w; wj = j; } }
    labelJobs.push({ si, dim, cx: (b0[wj] + b1[wj]) / 2, x: xs[wj], w: ww });
  });
  // ---- Highcharts crosshair: vertical line + per-layer markers + total ----
  if (activeC !== null && activeC >= 0 && activeC < n && p > 0.9) {
    const j = activeC;
    const fx = xs[j];
    const yTop = Math.min(...B.map((b) => b[j]));
    const yBot = Math.max(...B.map((b) => b[j]));
    ctx.save();
    ctx.strokeStyle = rgba(t.ink, 0.45);
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.moveTo(fx, yTop - 8); ctx.lineTo(fx, padT + plotH + 2); ctx.stroke();
    ctx.setLineDash([]);
    // markers on every visible layer boundary at this column
    order.forEach((si) => {
      const k = order.indexOf(si);
      if (k < 0) return;
      const yT = B[k + 1][j], yB = B[k][j];
      if (yB - yT < 3) return;
      const mid = (yT + yB) / 2;
      ctx.fillStyle = list[si].color;
      ctx.beginPath(); ctx.arc(fx, mid, si === activeS ? 4.2 : 3, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
    });
    // total chip above the river
    const tot = gm.totals[j] || 0;
    const tTxt = `${labels[j]} · ${fmtNum(tot)}`;
    ctx.font = font(t, 700, 10.5);
    const tw = measureW(ctx, tTxt);
    const chx = Math.max(tw / 2 + 8, Math.min(W - tw / 2 - 8, fx));
    const chy = Math.max(16, yTop - 14);
    ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
    ctx.strokeStyle = rgba(t.ink, 0.22); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(chx - tw / 2 - 7, chy - 11, tw + 14, 18, 9); ctx.fill(); ctx.stroke();
    ctx.fillStyle = t.ink; ctx.textAlign = 'center';
    ctx.fillText(tTxt, chx, chy + 2);
    ctx.restore();
  }
  // ---- in-stream labels: widest bands win, never overlap ----
  // Reference look: white pills with ink text floating ON the band.
  labelJobs.sort((a, b) => b.w - a.w);
  const taken: { x0: number; x1: number; y0: number; y1: number }[] = [];
  labelJobs.forEach(({ si, dim, cx, x, w }) => {
    if (w < 22 || p <= 0.9) return;
    const flat = m < 0.02;
    const fs = w > 44 ? (full ? 12 : 11.5) : 10;
    ctx.font = font(t, 700, fs);
    const nm = fitCtx(ctx, list[si].name, Math.max(44, plotH / 6));
    const tw = measureW(ctx, nm);
    const pwP = tw + 16, phP = fs + 8;
    const box = { x0: x - pwP / 2, x1: x + pwP / 2, y0: cx - phP / 2, y1: cx + phP / 2 };
    if (box.x0 < 6 || box.x1 > W - 6) return;
    for (const q of taken) {
      if (box.x0 < q.x1 && box.x1 > q.x0 && box.y0 < q.y1 && box.y1 > q.y0) return;
    }
    taken.push(box);
    ctx.save();
    ctx.globalAlpha *= dim;
    ctx.font = font(t, 700, fs);
    ctx.textAlign = 'center';
    if (flat) {
      // 2D: white pill + ink text (reference look)
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.20)'; ctx.shadowBlur = 4; ctx.shadowOffsetY = 1;
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.beginPath(); ctx.roundRect(box.x0, box.y0, pwP, phP, phP / 2); ctx.fill();
      ctx.restore();
      ctx.fillStyle = shade(list[si].color, 0.55);
      ctx.fillText(nm, x, cx + fs * 0.35);
    } else {
      // 3D: ink-on-frost pill so it reads over the glossy skin
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.30)'; ctx.shadowBlur = 5; ctx.shadowOffsetY = 2;
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.beginPath(); ctx.roundRect(box.x0, box.y0, pwP, phP, phP / 2); ctx.fill();
      ctx.restore();
      ctx.fillStyle = shade(list[si].color, 0.45);
      ctx.fillText(nm, x, cx + fs * 0.35);
    }
    ctx.restore();
  });
  // ---- event flags: default to the salary-story events when the dataset
  // carries none (built-in demo), staggered bubble lanes above the river ----
  const evts = ((d.streamEvents && d.streamEvents.length ? d.streamEvents : STREAM_SALARY_10Y.events).filter((e) => e.at >= 0 && e.at < n));
  const riverTopAt = (j: number) => Math.min(...B.map((b) => b[Math.max(0, Math.min(n - 1, j))]));
  const riverBotAt = (j: number) => Math.max(...B.map((b) => b[Math.max(0, Math.min(n - 1, j))]));
  const placedEv: { x0: number; x1: number; lane: number }[] = [];
  evts.forEach((e) => {
    const jj0 = Math.round(e.at);
    const fx = xs[jj0];
    ctx.save();
    // anchor dot sits ON the river's top surface (never floating above it)
    const surfY = riverTopAt(jj0);
    const botY = riverBotAt(jj0);
    const anchorY = Math.max(padT + 2, Math.min(padT + plotH - 2, surfY));
    void botY;
    ctx.strokeStyle = rgba(t.ink, 0.4); ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(fx, anchorY); ctx.lineTo(fx, padT - 6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.25)'; ctx.shadowBlur = 3;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.arc(fx, anchorY, 4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ctx.fillStyle = t.ink;
    ctx.beginPath(); ctx.arc(fx, anchorY, 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(fx, anchorY, 1, 0, Math.PI * 2); ctx.fill();
    ctx.font = font(t, 600, 10);
    const words = e.label.split(' ');
    const lines: string[] = [];
    let cur = '';
    words.forEach((w) => {
      const trial = cur ? cur + ' ' + w : w;
      if (measureW(ctx, trial) > 132 && cur) { lines.push(cur); cur = w; } else cur = trial;
    });
    if (cur) lines.push(cur);
    const bh = lines.length * 13 + 12;
    const bw = Math.min(150, Math.max(...lines.map((l) => measureW(ctx, l))) + 18);
    let bx = fx - bw / 2;
    bx = Math.max(4, Math.min(W - bw - 4, bx));
    let lane = 0;
    for (;;) {
      const y0 = padT - 10 - bh - lane * (bh + 8);
      const clash = placedEv.some((q) => bx < q.x1 && bx + bw > q.x0 && Math.abs(y0 - (padT - 10 - bh - q.lane * (bh + 8))) < bh + 6);
      if (!clash || lane > 2) break;
      lane++;
    }
    placedEv.push({ x0: bx, x1: bx + bw, lane });
    const byTop = Math.max(4, padT - 10 - bh - lane * (bh + 8));
    ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
    ctx.strokeStyle = rgba(t.ink, 0.25); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(bx, byTop, bw, bh, 7); ctx.fill(); ctx.stroke();
    const tailX = Math.max(bx + 10, Math.min(bx + bw - 10, fx));
    ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.96);
    ctx.beginPath();
    ctx.moveTo(tailX - 5, byTop + bh - 0.5);
    ctx.lineTo(tailX + 5, byTop + bh - 0.5);
    ctx.lineTo(tailX, byTop + bh + 6);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = t.ink; ctx.textAlign = 'left';
    lines.forEach((l, li) => ctx.fillText(l, bx + 9, byTop + 14 + li * 13));
    ctx.restore();
    if (activeS !== null && p > 0.9) {
      const si = activeS;
      const k = order.indexOf(si);
      if (k >= 0) {
        const jj = Math.round(e.at);
        const yT = B[k + 1][jj], yB = B[k][jj];
        if (yB - yT > 8) {
          const vy = (yT + yB) / 2;
          const label = fmtNum(list[si].values[jj] || 0);
          ctx.save();
          ctx.font = font(t, 700, 10);
          const tw = measureW(ctx, label);
          const cxp = Math.max(tw / 2 + 8, Math.min(W - tw / 2 - 8, fx));
          ctx.fillStyle = rgba(list[si].color, 0.95);
          ctx.beginPath(); ctx.roundRect(cxp - tw / 2 - 6, vy - 10, tw + 12, 17, 8); ctx.fill();
          ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
          ctx.fillText(label, cxp, vy + 2.5);
          ctx.restore();
        }
      }
    }
  });
  ctx.textAlign = 'left';
  return;
}
