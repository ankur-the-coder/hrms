/* Painter registry — keeps paintChart() a thin dispatch. */
import type { ChartKind, DrawCtx } from '../core/types';
import type { Ctx } from '../core/utils';
import { paintBar } from './bars';
import { paintLines } from './lines';
import { paintRadar } from './radar';
import { paintPolar } from './polar';
import { paintCalendarPie } from './calendarpie';
import { paintSankey } from './sankey';
import { paintRadialClassic } from './radial';
import { paintRadialBars } from './radialbars';
import { paintToroid } from './toroid';
import { paintDual } from './dual';
import { paintGantt } from './gantt';
import { paintScatter } from './scatter';
import { paintStream } from './stream';
import { paintFunnel } from './funnel';
import { paintPieDonut } from './circular';

export function paintChart(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H } = d;
  if (d.bg) { ctx.fillStyle = d.bg; ctx.fillRect(0, 0, W, H); } else ctx.clearRect(0, 0, W, H);
  if (!d.data.length && !(d.multi && d.cats.length) && kind !== 'calendarpie' && kind !== 'sankey' && kind !== 'gantt' && kind !== 'scatter' && kind !== 'stream') return;
  switch (kind) {
    case 'bar': return paintBar(ctx, kind, d);
    case 'line':
    case 'area': return paintLines(ctx, kind, d);
    case 'radar': return paintRadar(ctx, kind, d);
    case 'polar': return paintPolar(ctx, kind, d);
    case 'calendarpie': return paintCalendarPie(ctx, kind, d);
    case 'sankey': return paintSankey(ctx, kind, d);
    case 'radialbarclassic': return paintRadialClassic(ctx, kind, d);
    case 'radialbars': return paintRadialBars(ctx, kind, d);
    case 'toroid': return paintToroid(ctx, kind, d);
    case 'dual': return paintDual(ctx, kind, d);
    case 'gantt': return paintGantt(ctx, kind, d);
    case 'scatter': return paintScatter(ctx, kind, d);
    case 'stream': return paintStream(ctx, kind, d);
    case 'funnel':
    case 'pyramid': return paintFunnel(ctx, kind, d);
    case 'pie':
    case 'donut': return paintPieDonut(ctx, kind, d);
    case 'radialbar':
    case 'sankey3d':
      return; // always covered by a WebGL overlay in the Chart component
  }
}
