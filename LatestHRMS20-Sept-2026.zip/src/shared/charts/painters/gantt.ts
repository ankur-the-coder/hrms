/* Painter: gantt — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, GanttTask, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintGantt(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  type GT = GanttTask & { _s: number; _e: number; _bS?: number; _bE?: number };
  const toMs = (v: string | number): number => (typeof v === 'number' ? v : new Date(v).getTime());
  const isDate = !!(d.tasks && d.tasks.length && typeof d.tasks[0].start === 'string');
  const rawTasks: GT[] = d.tasks && d.tasks.length ? d.tasks.map((tk) => ({
    ...tk,
    _s: toMs(tk.start), _e: Math.max(toMs(tk.start) + 1, toMs(tk.end)),
    _bS: tk.baselineStart !== undefined ? toMs(tk.baselineStart) : undefined,
    _bE: tk.baselineEnd !== undefined ? toMs(tk.baselineEnd) : undefined,
  })) : (
    data.map((x, i) => ({
      id: i, name: x.label, start: i * 3, end: i * 3 + Math.max(3, Math.round(x.value / 8)),
      progress: 35 + ((i * 17) % 60), color: colors[i], category: 'Milestone',
      _s: i * 3, _e: i * 3 + Math.max(3, Math.round(x.value / 8)),
    }))
  );
  const byId = new Map<string | number, number>();
  rawTasks.forEach((tk, i) => byId.set(tk.id, i));
  const padL = Math.max(150, Math.min(250, W * 0.27));
  const padR = 30 + 14 * m, padT = 52 + 10 * m, padB = 30;
  const chartW = W - padL - padR;
  const chartH = H - padT - padB;
  const rowH = Math.min(46, Math.max(28, chartH / Math.max(1, rawTasks.length)));
  const plotBot = padT + rowH * rawTasks.length;

  const starts = rawTasks.map((tk) => tk._s);
  const ends = rawTasks.map((tk) => tk._e);
  const minTime = Math.min(...starts);
  const maxTime = Math.max(...ends, minTime + 1);
  const timeSpan = maxTime - minTime || 1;
  // ONE oblique 3D projection for the whole Gantt scene: every 2D point
  // (x, y) at extrusion height z maps to (x + z·cosA, y − z·sinA) with a
  // fixed cabinet angle A=38°. Tracks sit at z=0, bar tops at z=barH·0.9,
  // elbows at z=barH·0.45 — so bars, caps, shadows and dependency links
  // share one consistent depth instead of ad-hoc per-element offsets.
  const G_ANG = (38 * Math.PI) / 180;
  const gOx = Math.cos(G_ANG) * 13 * m, gOy = Math.sin(G_ANG) * 13 * m;
  const X = (ms: number) => padL + ((ms - minTime) / timeSpan) * chartW;
  const ZP = (x: number, y: number, z: number): [number, number] =>
    [x + (z / 13) * gOx, y - (z / 13) * gOy];

  // ---- swim-lane grouping (by category) ----
  const lanes: { name: string; rows: number[] }[] = [];
  const laneOf = new Array(rawTasks.length).fill(0);
  rawTasks.forEach((tk, i) => {
    const nm = tk.category || 'Plan';
    let li = lanes.findIndex((l) => l.name === nm);
    if (li < 0) { lanes.push({ name: nm, rows: [] }); li = lanes.length - 1; }
    lanes[li].rows.push(i);
    laneOf[i] = li;
  });
  const laneColors = lanes.map((_, li) => colors[li % colors.length]);

  // ---- plot bay ----
  ctx.fillStyle = rgba(t.ink, m > 0.02 ? 0.05 : 0.035);
  ctx.beginPath(); ctx.roundRect(padL - 8, padT - 34, chartW + 16, plotBot - padT + 40, 10); ctx.fill();

  // ---- weekend shading (date mode) ----
  if (isDate) {
    const t0 = new Date(minTime); t0.setHours(0, 0, 0, 0);
    for (let dd = new Date(t0); dd.getTime() <= maxTime; dd = new Date(dd.getTime() + 864e5)) {
      const dow = dd.getDay();
      if (dow === 0 || dow === 6) {
        const x0 = X(dd.getTime()), x1 = X(dd.getTime() + 864e5);
        ctx.fillStyle = rgba(t.ink, 0.045);
        ctx.fillRect(x0, padT - 4, Math.max(1, x1 - x0), plotBot - padT + 8);
      }
    }
  }

  // ---- time axis: day gridlines + adaptive header (month/day or Day N) ----
  const cols = 5;
  ctx.font = font(t, 600, 10);
  ctx.textAlign = 'center';
  for (let c = 0; c <= cols; c++) {
    const gx = padL + (chartW * c) / cols;
    ctx.strokeStyle = t.grid;
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(gx, padT - 4);
    ctx.lineTo(gx, plotBot);
    if (m > 0.02) { ctx.moveTo(gx, plotBot); ctx.lineTo(gx + gOx, plotBot - gOy); }
    ctx.stroke();
    ctx.setLineDash([]);
    const tVal = minTime + (timeSpan * c) / cols;
    const tLabel = isDate
      ? new Date(tVal).toLocaleDateString('en', { month: 'short', day: 'numeric' })
      : `Day ${Math.round(tVal)}`;
    ctx.fillStyle = t.axis;
    ctx.fillText(tLabel, gx + (m > 0.02 ? gOx / 2 : 0), padT - 22);
  }
  if (isDate) {
    // month band above the day labels
    ctx.font = font(t, 700, 9);
    ctx.fillStyle = rgba(t.axis, 0.85);
    let lastM = '';
    for (let c = 0; c <= cols; c++) {
      const tVal = minTime + (timeSpan * c) / cols;
      const mm = new Date(tVal).toLocaleDateString('en', { month: 'long', year: 'numeric' });
      if (mm !== lastM) {
        const gx = padL + (chartW * c) / cols;
        ctx.fillText(mm.toUpperCase(), Math.min(gx + 34, padL + chartW - 40), padT - 34 - 10);
        lastM = mm;
      }
    }
  }
  // ---- today marker ----
  const nowMs = Date.now();
  if (isDate && nowMs >= minTime && nowMs <= maxTime) {
    const tx = X(nowMs);
    ctx.save();
    ctx.strokeStyle = '#e11d63'; ctx.lineWidth = 1.6; ctx.setLineDash([5, 3]);
    ctx.beginPath(); ctx.moveTo(tx, padT - 8); ctx.lineTo(tx, plotBot + 2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.font = font(t, 700, 9); ctx.textAlign = 'center';
    const tw = measureW(ctx, 'TODAY') + 12;
    ctx.fillStyle = '#e11d63';
    ctx.beginPath(); ctx.roundRect(tx - tw / 2, padT - 26, tw, 14, 7); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.fillText('TODAY', tx, padT - 15.5);
    ctx.restore();
  }
  ctx.textAlign = 'left';
  if (m > 0.02) {
    ctx.fillStyle = rgba(t.ink, 0.045 * m);
    ctx.beginPath();
    ctx.moveTo(padL, plotBot);
    ctx.lineTo(padL + gOx, plotBot - gOy);
    ctx.lineTo(padL + chartW + gOx, plotBot - gOy);
    ctx.lineTo(padL + chartW, plotBot);
    ctx.closePath(); ctx.fill();
  }

  // ---- critical path: longest dependency chain (finish-to-start) ----
  const crit = new Set<number>();
  {
    const memo = new Map<number, number>();
    const depth = (i: number, seen: Set<number>): number => {
      if (memo.has(i)) return memo.get(i)!;
      if (seen.has(i)) return 0;
      seen.add(i);
      const tk = rawTasks[i];
      let best = 1;
      (tk.dependsOn || []).forEach((dep) => {
        const j = byId.get(dep);
        if (j !== undefined) best = Math.max(best, 1 + depth(j, seen));
      });
      seen.delete(i);
      memo.set(i, best);
      return best;
    };
    let longest = 0;
    rawTasks.forEach((tk, i) => { if ((tk.dependsOn || []).length) longest = Math.max(longest, depth(i, new Set())); });
    if (longest >= 2) {
      // mark tasks lying on SOME longest chain (greedy from the deepest)
      let end = -1, bd = -1;
      rawTasks.forEach((_, i) => { const dd = depth(i, new Set()); if (dd > bd) { bd = dd; end = i; } });
      let cur = end;
      const guard = new Set<number>();
      while (cur >= 0 && !guard.has(cur)) {
        guard.add(cur);
        crit.add(cur);
        const tk = rawTasks[cur];
        let nxt = -1, nd = -1;
        (tk.dependsOn || []).forEach((dep) => {
          const j = byId.get(dep);
          if (j !== undefined) { const dd = depth(j, new Set()); if (dd > nd) { nd = dd; nxt = j; } }
        });
        cur = nxt;
      }
    }
  }
  rawTasks.forEach((task, i) => {
    const sx = X(task._s);
    const ex = X(task._e);
    const barW = Math.max(8, ex - sx);
    const ry = padT + i * rowH;
    const barH = Math.max(15, rowH - 13);
    const by = ry + (rowH - barH) / 2;
    const on = hov.idx === i;
    const col = task.color || colors[i % colors.length] || '#0d7a54';
    const prg = Math.min(100, Math.max(0, task.progress ?? 100)) / 100;
    const pw = Math.max(4, barW * prg * p);
    const pCol = on ? shade(col, 1 + 0.15 * hov.amt) : col;
    const isCrit = crit.has(i);
    const overdue = isDate && prg < 1 && task._e < nowMs;
    const laneCol = laneColors[laneOf[i] % laneColors.length];

    // swim-lane band: soft tint per category + hairline separators
    ctx.fillStyle = rgba(laneCol, i % 2 === 1 ? 0.07 : 0.045);
    ctx.fillRect(padL - 8, ry, chartW + 16, rowH);
    ctx.strokeStyle = rgba(t.ink, 0.06);
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(padL - 8, ry + rowH); ctx.lineTo(padL + chartW + 8, ry + rowH); ctx.stroke();
    // lane label on its first row
    if (lanes[laneOf[i]].rows[0] === i && lanes.length > 1) {
      ctx.font = font(t, 700, 8.5);
      ctx.fillStyle = rgba(laneCol, 0.95);
      ctx.textAlign = 'left';
      ctx.fillText(lanes[laneOf[i]].name.toUpperCase(), padL + chartW - Math.min(150, measureW(ctx, lanes[laneOf[i]].name.toUpperCase()) + 4), ry + 11);
    }
    // duration pill at the bar's right end (date-aware: "12d" / "3w")
    {
      const durMs = task._e - task._s;
      const durDays = isDate ? Math.max(1, Math.round(durMs / 864e5)) : Math.max(1, Math.round(durMs));
      const durTxt = isDate ? (durDays >= 14 ? `${Math.round(durDays / 7)}w` : `${durDays}d`) : `${durDays}d`;
      const slackTxt = task.slackDays !== undefined && task.slackDays !== null
        ? ` · slack ${task.slackDays}d`
        : '';
      ctx.font = font(t, 600, 8.5);
      const pill = `${durTxt}${slackTxt}`;
      const pwPill = measureW(ctx, pill) + 12;
      const pillX = Math.min(sx + barW + 6, padL + chartW - pwPill);
      if (sx + barW + 6 < padL + chartW - 10 && barH >= 14) {
        ctx.fillStyle = rgba(t.ink, 0.07);
        ctx.beginPath(); ctx.roundRect(pillX, by + barH / 2 - 8, pwPill, 15, 7); ctx.fill();
        ctx.fillStyle = t.axis;
        ctx.textAlign = 'left';
        ctx.fillText(pill, pillX + 6, by + barH / 2 + 3);
      }
    }
    // dependency count badge at the bar's left edge ("⑂2")
    if ((task.dependsOn || []).length) {
      ctx.font = font(t, 700, 8.5);
      const depTxt = `\u2442${(task.dependsOn || []).length}`;
      const dw = measureW(ctx, depTxt) + 10;
      if (sx - dw - 16 > padL) {
        ctx.fillStyle = rgba(t.ink, 0.08);
        ctx.beginPath(); ctx.roundRect(sx - dw - 4, by + barH / 2 - 8, dw, 15, 7); ctx.fill();
        ctx.fillStyle = t.axis;
        ctx.textAlign = 'left';
        ctx.fillText(depTxt, sx - dw + 1, by + barH / 2 + 3);
      }
    }
    if (on) {
      ctx.fillStyle = rgba(t.ink, 0.05);
      ctx.beginPath(); ctx.roundRect(8, ry + 1, W - 16, rowH - 2, 6); ctx.fill();
    }

    // critical-path glow behind the bar
    if (isCrit) {
      ctx.save();
      setShadow(ctx, 0, 0, 10, rgba('#e11d63', 0.5));
      ctx.fillStyle = rgba('#e11d63', 0.10);
      ctx.beginPath(); ctx.roundRect(sx - 3, by - 3, barW + 6, barH + 6, (barH + 6) / 2); ctx.fill();
      ctx.restore();
    }

    // name + date range + avatar chip in the label gutter
    ctx.font = font(t, 600, 11);
    ctx.fillStyle = on ? t.ink : shade(t.ink, 0.85);
    ctx.textAlign = 'left';
    ctx.fillText(fitCtx(ctx, task.name, padL - 66), 16, by + barH * 0.42);
    ctx.font = font(t, 500, 9);
    ctx.fillStyle = t.axis;
    const rangeTxt = isDate
      ? `${new Date(task._s).toLocaleDateString('en', { month: 'short', day: 'numeric' })} → ${new Date(task._e).toLocaleDateString('en', { month: 'short', day: 'numeric' })}`
      : `Day ${Math.round(task._s)} → ${Math.round(task._e)}`;
    ctx.fillText(fitCtx(ctx, rangeTxt, padL - 66), 16, by + barH * 0.42 + 12);
    if (task.assignee) {
      const init = task.assignee.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();
      const ax = padL - 30, ay = by + barH / 2;
      ctx.fillStyle = shade(col, 0.85);
      ctx.beginPath(); ctx.arc(ax, ay, 9, 0, Math.PI * 2); ctx.fill();
      ctx.font = font(t, 700, 8);
      ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
      ctx.fillText(init, ax, ay + 2.8);
      ctx.textAlign = 'left';
    }

    // baseline ghost (thin grey bar under the plan)
    if (task._bS !== undefined && task._bE !== undefined) {
      const bsx = X(task._bS), bex = X(task._bE);
      ctx.fillStyle = rgba(t.ink, 0.22);
      ctx.beginPath(); ctx.roundRect(bsx, by + barH + 1.5, Math.max(4, bex - bsx), 3, 1.5); ctx.fill();
    }

    // milestone diamond (zero-duration or flagged) — in 3D a true
    // diamond PRISM: back face + two visible side faces via ZP, glass front.
    if (task.milestone || task._e - task._s <= 1) {
      const dx = sx + (task.milestone ? barW / 2 : 0), dyy = by + barH / 2, rr = barH * 0.52;
      const zDia = Math.min(13, Math.max(7, barH * 0.6));
      const dT = ZP(dx, dyy - rr, zDia), dR = ZP(dx + rr, dyy, zDia),
        dB = ZP(dx, dyy + rr, zDia), dL = ZP(dx - rr, dyy, zDia);
      ctx.save();
      if (m > 0.02) { setShadow(ctx, 2 * m, 3 * m, 6, rgba(t.ink, 0.25 * m)); }
      if (m > 0.02) {
        // side faces (right flank darker than top flank)
        ctx.fillStyle = shade(pCol, 0.55);
        ctx.beginPath();
        ctx.moveTo(dx + rr, dyy); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dB[0], dB[1]); ctx.lineTo(dx, dyy + rr);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = shade(pCol, 0.8);
        ctx.beginPath();
        ctx.moveTo(dx, dyy - rr); ctx.lineTo(dT[0], dT[1]); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dx + rr, dyy);
        ctx.closePath(); ctx.fill();
      }
      const mg = ctx.createLinearGradient(0, dyy - rr, 0, dyy + rr);
      mg.addColorStop(0, shade(pCol, 1.3)); mg.addColorStop(1, shade(pCol, 0.75));
      ctx.fillStyle = mg;
      ctx.beginPath();
      if (m > 0.02) {
        ctx.moveTo(dT[0], dT[1]); ctx.lineTo(dR[0], dR[1]); ctx.lineTo(dB[0], dB[1]); ctx.lineTo(dL[0], dL[1]);
      } else {
        ctx.moveTo(dx, dyy - rr); ctx.lineTo(dx + rr, dyy); ctx.lineTo(dx, dyy + rr); ctx.lineTo(dx - rr, dyy);
      }
      ctx.closePath(); ctx.fill();
      ctx.restore();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
    } else if (m > 0.02) {
      // contact shadow for the whole group
      ctx.save();
      setShadow(ctx, 0, 3 * m + 1, 7, rgba(t.ink, 0.22 * m));
      ctx.fillStyle = rgba(t.ink, 0.10 * m);
      ctx.beginPath(); ctx.roundRect(sx + gOx * 0.4, by + gOy * 0.4 + 2 * m, barW, barH, barH / 2); ctx.fill();
      ctx.restore();
      // recessed track groove (dark inset rail)
      ctx.fillStyle = rgba(t.ink, 0.10 + 0.04 * m);
      ctx.beginPath(); ctx.roundRect(sx, by, barW, barH, barH / 2); ctx.fill();
      ctx.strokeStyle = rgba('#ffffff', 0.35);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(sx + 0.5, by + barH - 1.5, barW - 1, 1.2, 1); ctx.stroke();
      // progress lozenge: a ROUNDED extrusion of the same soft bar —
      // N stacked roundRect slices swept along the ZP vector (dark → light
      // toward the viewer), then the glass front. No sharp polygon box.
      const zBar = Math.min(13, Math.max(7, barH * 0.72));
      const SLICES = 10;
      for (let zi = SLICES; zi >= 1; zi--) {
        const zz = (zBar * zi) / SLICES;
        const [ox2, oy2] = ZP(0, 0, zz);
        const f = 1 - (zi / SLICES) * 0.42; // far = darkest, near = base
        ctx.fillStyle = shade(pCol, (zi === SLICES ? 0.52 : f));
        ctx.beginPath(); ctx.roundRect(sx + ox2, by + oy2, pw, barH, barH / 2); ctx.fill();
      }
      // top sheen slice: one bright rounded cap just under the glass front
      {
        const [ox3, oy3] = ZP(0, 0, zBar * 0.12);
        ctx.fillStyle = shade(pCol, 1.18);
        ctx.beginPath(); ctx.roundRect(sx + ox3, by + oy3, pw, Math.max(2, barH * 0.42), barH * 0.21); ctx.fill();
      }
      const gg = ctx.createLinearGradient(0, by, 0, by + barH);
      gg.addColorStop(0, shade(pCol, 1.22));
      gg.addColorStop(0.45, pCol);
      gg.addColorStop(1, shade(pCol, 0.74));
      ctx.fillStyle = gg;
      ctx.beginPath(); ctx.roundRect(sx, by, pw, barH, barH / 2); ctx.fill();
      // specular gloss band across the upper third
      ctx.fillStyle = 'rgba(255,255,255,0.30)';
      ctx.beginPath(); ctx.roundRect(sx + 3, by + 2.5, Math.max(1, pw - 6), Math.max(1, barH * 0.3), barH * 0.15); ctx.fill();
      ctx.strokeStyle = rgba('#ffffff', 0.55);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(sx + 0.5, by + 0.5, pw - 1, barH - 1, barH / 2 - 0.5); ctx.stroke();
      // progress pip at the leading edge of the lozenge
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(sx + pw - 1, by + barH / 2, Math.max(1.6, barH * 0.14), 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = pCol;
      ctx.beginPath(); ctx.arc(sx + pw - 1, by + barH / 2, Math.max(1, barH * 0.09), 0, Math.PI * 2); ctx.fill();
      // overdue: diagonal hatch over the unworked remainder
      if (overdue) {
        ctx.save();
        ctx.beginPath(); ctx.roundRect(sx + pw, by, Math.max(0, barW - pw), barH, 4); ctx.clip();
        ctx.strokeStyle = rgba('#e11d63', 0.5);
        ctx.lineWidth = 1.4;
        for (let hx = sx + pw - barH; hx < sx + barW + barH; hx += 6) {
          ctx.beginPath(); ctx.moveTo(hx, by + barH); ctx.lineTo(hx + barH, by); ctx.stroke();
        }
        ctx.restore();
      }
      // status dot: green = done, amber = in flight, grey = not started,
      // red ring when overdue
      const stCol = overdue ? '#e11d63' : prg >= 1 ? '#16a34a' : prg > 0 ? '#d97706' : '#9ca3af';
      ctx.fillStyle = stCol;
      ctx.beginPath(); ctx.arc(sx - 9, by + barH / 2, 3.2, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
      // dependency links from EXPLICIT dependsOn (finish-to-start elbows)
      // — lifted onto the bar-face plane (z = zBar·0.5) so arrowheads plug
      // into the 3D faces instead of floating behind them.
      (task.dependsOn || []).forEach((dep) => {
        const j = byId.get(dep);
        if (j === undefined || j === i) return;
        const fromX = X(rawTasks[j]._e);
        const py = padT + j * rowH + rowH / 2;
        const cy2 = by + barH / 2;
        const hot = crit.has(i) && crit.has(j);
        const midX = Math.max(fromX + 6, sx - 14);
        const zEl = Math.min(13, Math.max(7, barH * 0.72)) * 0.5;
        const e0 = ZP(fromX, py, zEl), e1 = ZP(midX, py, zEl),
          e2 = ZP(midX, cy2, zEl), e3 = ZP(sx - 2, cy2, zEl);
        ctx.save();
        ctx.strokeStyle = hot ? '#e11d63' : rgba(t.ink, 0.35);
        ctx.lineWidth = hot ? 1.8 : 1.2;
        if (!hot) ctx.setLineDash([3, 2.5]);
        ctx.beginPath();
        ctx.moveTo(e0[0], e0[1]);
        ctx.lineTo(e1[0], e1[1]);
        ctx.lineTo(e2[0], e2[1]);
        ctx.lineTo(e3[0], e3[1]);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = hot ? '#e11d63' : rgba(t.ink, 0.5);
        ctx.beginPath();
        ctx.moveTo(e3[0], e3[1]);
        ctx.lineTo(e3[0] - 5, e3[1] - 3);
        ctx.lineTo(e3[0] - 5, e3[1] + 3);
        ctx.closePath(); ctx.fill();
        ctx.restore();
      });
    } else {
      ctx.fillStyle = rgba(col, 0.2);
      ctx.beginPath(); ctx.roundRect(sx, by, barW, barH, 6); ctx.fill();
      // effort vs elapsed mini-track under the bar (thin, unobtrusive)
      if (barH >= 16) {
        const elapsed = isDate
          ? Math.max(0, Math.min(1, (nowMs - task._s) / Math.max(1, task._e - task._s)))
          : prg;
        ctx.fillStyle = rgba(t.ink, 0.14);
        ctx.beginPath(); ctx.roundRect(sx + 2, by + barH - 4.5, Math.max(2, barW - 4), 2.5, 1.2); ctx.fill();
        ctx.fillStyle = elapsed >= prg ? '#16a34a' : '#d97706';
        ctx.beginPath(); ctx.roundRect(sx + 2, by + barH - 4.5, Math.max(2, (barW - 4) * elapsed), 2.5, 1.2); ctx.fill();
      }
      ctx.fillStyle = on ? shade(col, 1.15) : col;
      ctx.beginPath(); ctx.roundRect(sx, by, pw, barH, 6); ctx.fill();
      ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.beginPath(); ctx.roundRect(sx, by, pw, barH / 2, [6, 6, 0, 0]); ctx.fill();
      // owner avatar overlapping the bar's leading edge (2D + 3D alike)
      if (task.assignee && barW > 30) {
        const init2 = task.assignee.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();
        const ox = sx + 9, oy = by + barH / 2;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(ox, oy, 7.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = shade(col, 0.7);
        ctx.beginPath(); ctx.arc(ox, oy, 6.2, 0, Math.PI * 2); ctx.fill();
        ctx.font = font(t, 700, 7);
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
        ctx.fillText(init2, ox, oy + 2.4);
        ctx.textAlign = 'left';
      }
      // start/end date caps under long bars
      if (isDate && barW > 120) {
        ctx.font = font(t, 600, 8);
        ctx.fillStyle = t.axis;
        ctx.textAlign = 'left';
        const sCap = new Date(task._s).toLocaleDateString('en', { month: 'short', day: 'numeric' });
        const eCap = new Date(task._e).toLocaleDateString('en', { month: 'short', day: 'numeric' });
        ctx.fillText(sCap, sx + 2, by + barH + 10);
        ctx.textAlign = 'right';
        ctx.fillText(eCap, sx + barW - 2, by + barH + 10);
        ctx.textAlign = 'left';
      }
      if (overdue) {
        ctx.save();
        ctx.beginPath(); ctx.roundRect(sx + pw, by, Math.max(0, barW - pw), barH, 4); ctx.clip();
        ctx.strokeStyle = rgba('#e11d63', 0.5);
        ctx.lineWidth = 1.4;
        for (let hx = sx + pw - barH; hx < sx + barW + barH; hx += 6) {
          ctx.beginPath(); ctx.moveTo(hx, by + barH); ctx.lineTo(hx + barH, by); ctx.stroke();
        }
        ctx.restore();
      }
      // status dot + dependency links in 2D as well (same language)
      const stCol2 = overdue ? '#e11d63' : prg >= 1 ? '#16a34a' : prg > 0 ? '#d97706' : '#9ca3af';
      ctx.fillStyle = stCol2;
      ctx.beginPath(); ctx.arc(sx - 9, by + barH / 2, 3.2, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke();
      (task.dependsOn || []).forEach((dep) => {
        const j = byId.get(dep);
        if (j === undefined || j === i) return;
        const fromX = X(rawTasks[j]._e);
        const py = padT + j * rowH + rowH / 2;
        const cy2 = by + barH / 2;
        const hot = crit.has(i) && crit.has(j);
        const midX = Math.max(fromX + 6, sx - 14);
        ctx.save();
        ctx.strokeStyle = hot ? '#e11d63' : rgba(t.ink, 0.35);
        ctx.lineWidth = hot ? 1.8 : 1.2;
        if (!hot) ctx.setLineDash([3, 2.5]);
        ctx.beginPath();
        ctx.moveTo(fromX, py);
        ctx.lineTo(midX, py);
        ctx.lineTo(midX, cy2);
        ctx.lineTo(sx - 2, cy2);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = hot ? '#e11d63' : rgba(t.ink, 0.5);
        ctx.beginPath();
        ctx.moveTo(sx - 2, cy2);
        ctx.lineTo(sx - 7, cy2 - 3);
        ctx.lineTo(sx - 7, cy2 + 3);
        ctx.closePath(); ctx.fill();
        ctx.restore();
      });
    }

    if (barW > 35 && !(task.milestone || task._e - task._s <= 1)) {
      ctx.fillStyle = '#ffffff'; ctx.font = font(t, 700, 9.5); ctx.textAlign = 'center';
      ctx.fillText(`${Math.round(prg * 100)}%`, sx + pw / 2, by + barH * 0.7);
    }
    if (isCrit) {
      ctx.font = font(t, 700, 8);
      ctx.fillStyle = '#e11d63'; ctx.textAlign = 'left';
      ctx.fillText('CRITICAL', sx + barW + 6, by + barH * 0.68);
    }
  });
  ctx.textAlign = 'left';
  return;
}
