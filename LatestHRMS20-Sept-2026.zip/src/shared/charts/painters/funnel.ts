/* Painter: funnel + pyramid — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintFunnel(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const g = funnelGeom(W, H, m, data, full, kind === 'pyramid');
  const { ch, plotW, sq, topY, cx, laneX } = g;
  const heights = data.map((x) => (x.value / total) * ch * p);
  const sumH = heights.reduce((a, b) => a + b, 0);
  const widthAt = (rel: number) => kind === 'funnel'
    ? plotW * (0.96 - 0.66 * (rel / ch))
    : plotW * (0.96 * (rel / ch)); // pyramid: true point at the top
  ctx.font = font(t, 600, 10.5);
  // label rows: pushed apart so thin segments never overlap, then pulled
  // back inside the plot from the bottom
  const rows: number[] = [];
  { let yy = topY + (ch - sumH); heights.forEach((h) => { rows.push(yy + h / 2); yy += h; }); }
  const PITCH = 14;
  for (let i = 1; i < rows.length; i++) rows[i] = Math.max(rows[i], rows[i - 1] + PITCH);
  const floor = Math.min(H - 8, topY + ch + 18);
  for (let i = rows.length - 1; i >= 0; i--) rows[i] = Math.min(rows[i], i === rows.length - 1 ? floor : rows[i + 1] - PITCH);
  let y = topY + (ch - sumH);
  data.forEach((x, i) => {
    const h = heights[i];
    const rel0 = y - topY;
    const w0 = widthAt(rel0), w1 = widthAt(rel0 + h);
    const on = hov.idx === i;
    const col = on ? shade(colors[i], 1 + 0.12 * hov.amt) : colors[i];
    if (kind === 'funnel' && m > 0.02) {
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.moveTo(cx - w0 / 2, y);
      ctx.lineTo(cx - w1 / 2, y + h);
      ctx.ellipse(cx, y + h, Math.max(0.1, w1 / 2), Math.max(0.1, (w1 / 2) * sq), 0, Math.PI, 0, true);
      ctx.lineTo(cx + w0 / 2, y);
      ctx.ellipse(cx, y, Math.max(0.1, w0 / 2), Math.max(0.1, (w0 / 2) * sq), 0, 0, Math.PI, false);
      ctx.closePath(); ctx.fill();
      if (i === 0) {
        ctx.fillStyle = shade(colors[i], 1.22);
        ctx.beginPath(); ctx.ellipse(cx, y, Math.max(0.1, w0 / 2), Math.max(0.1, (w0 / 2) * sq), 0, 0, Math.PI * 2); ctx.fill();
      }
    } else if (kind === 'pyramid' && m > 0.005) {
      // side face grows with the morph — no jump at the 2D/3D boundary
      const dxr = (w: number) => w * 0.2 * m, dyr = (w: number) => w * 0.075 * m;
      ctx.fillStyle = shade(colors[i], 0.72);
      ctx.beginPath();
      ctx.moveTo(cx + w0 / 2, y);
      ctx.lineTo(cx + w0 / 2 + dxr(w0), y - dyr(w0));
      ctx.lineTo(cx + w1 / 2 + dxr(w1), y + h - dyr(w1));
      ctx.lineTo(cx + w1 / 2, y + h);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.moveTo(cx - w0 / 2, y);
      ctx.lineTo(cx + w0 / 2, y);
      ctx.lineTo(cx + w1 / 2, y + h);
      ctx.lineTo(cx - w1 / 2, y + h);
      ctx.closePath(); ctx.fill();
      if (m < 0.98) { ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke(); }
    } else {
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.moveTo(cx - w0 / 2, y);
      ctx.lineTo(cx + w0 / 2, y);
      ctx.lineTo(cx + w1 / 2, y + h);
      ctx.lineTo(cx - w1 / 2, y + h);
      ctx.closePath(); ctx.fill();
      if (m < 0.98) { ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke(); }
    }
    // leader — attached at the segment's true mid-width edge, head fully outside
    const midY = y + h / 2;
    const rowY = rows[i];
    const wMid = widthAt(rel0 + h / 2);
    // anchor on the shape's true silhouette: the front edge in 2D, the side face's
    // outer edge in 3D (blended through the morph). The head is entirely outside it.
    const edgeX = cx + wMid / 2 + (kind === 'pyramid' ? wMid * 0.2 * m : 0);
    const edgeY = midY - (kind === 'pyramid' ? wMid * 0.075 * m : 0);
    // every leader turns in one shared vertical lane just right of the widest
    // part of the shape (incl. the 3D side face), then runs to its label row
    const textX = laneX + 16;
    // arrowhead scales with the segment but never below a legible 2.2px half-height
    const ah = Math.min(3.8, Math.max(2.2, h / 2 - 0.5)), al = Math.max(4.5, ah * 2);
    ctx.strokeStyle = colors[i];
    ctx.lineWidth = 1.3;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(edgeX + al, edgeY);
    if (Math.abs(rowY - edgeY) > 0.5) { ctx.lineTo(Math.max(edgeX + al + 4, laneX - 6), edgeY); ctx.lineTo(laneX, rowY); }
    ctx.lineTo(textX - 6, rowY);
    ctx.stroke();
    ctx.lineJoin = 'miter';
    ctx.fillStyle = colors[i];
    ctx.beginPath();
    ctx.moveTo(edgeX + 0.5, edgeY);
    ctx.lineTo(edgeX + al + 0.5, edgeY - ah);
    ctx.lineTo(edgeX + al + 0.5, edgeY + ah);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 0.8; ctx.stroke();
    ctx.fillStyle = t.ink;
    ctx.textAlign = 'left';
    const text = funnelLabel(x, total);
    ctx.fillText(full ? text : fitCtx(ctx, text, W - textX - 4), textX, rowY + 3.5);
    y += h;
  });
  ctx.textAlign = 'left';
  return;
}
