/* Painter: toroid donut — placeholder; real torus painter lands next. */
import type { ChartKind, DrawCtx } from '../core/types';
import type { Ctx } from '../core/utils';
export function paintToroid(_ctx: Ctx, _kind: ChartKind, _d: DrawCtx): void { /* replaced below */ }
