/* Painter: sankey (classic) — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad, type SkFlow, type SkNode } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintSankey(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const links = (d.links || []).filter((l) => l.value > 0 && l.source !== l.target);
  if (!links.length) return;
  const lay = sankeyLayout(links, W, H, full ? 200 : Math.min(150, W * 0.22));
  if (!lay) return;
  const { nodes, flows, nodeW, cols } = lay;
  const maxCol = Math.max(1, cols - 1);
  const ox = 7 * m, oy = 5 * m; // 3D isometric extrusion offset

  // Hover animation model (mirrors the 3D scene's isolate behaviour):
  //  - hovering a NODE spotlights it + every ribbon touching it;
  //  - hovering a FLOW spotlights that ribbon + its source/target nodes;
  //  - everything else dims. `hov.amt` (eased 0→1 in the Chart shell)
  //    drives the emphasis so the highlight blooms instead of popping.
  const hovFlowIdx = hov.seg && hov.seg.s === -2 ? hov.seg.c : -1;
  const hovNodeIdx = hov.idx;
  const hovActive = hovNodeIdx !== null || hovFlowIdx >= 0;
  const flowEmph = (fi: number, f: SkFlow) => {
    if (!hovActive) return 0;
    if (hovFlowIdx >= 0) return fi === hovFlowIdx ? hov.amt : 0;
    return (hovNodeIdx === f.si || hovNodeIdx === f.ti) ? hov.amt : 0;
  };
  const nodeEmph = (ni: number) => {
    if (!hovActive) return 0;
    if (hovFlowIdx >= 0) {
      const f = flows[hovFlowIdx];
      return f && (ni === f.si || ni === f.ti) ? hov.amt : 0;
    }
    return ni === hovNodeIdx ? hov.amt : 0;
  };
  const glow = (col: string, e: number) => e > 0.01 && hovActive ? shade(col, 1 + 0.28 * e) : col;

  // Sequential left-to-right sweep:
  // 1. Draw nodes per column
  // 2. Flow ribbons sweep outward from left to right along their path vectors
  flows.forEach((f, fi) => {
    const src = nodes[f.si], tgt = nodes[f.ti];
    const emph = flowEmph(fi, f); // 0 … 1 eased emphasis
    const isDimmed = hovActive && emph < 0.01;
    const x0 = src.x + nodeW, x1 = tgt.x;
    const c1 = x0 + (x1 - x0) * 0.5, c2 = x1 - (x1 - x0) * 0.5;
    const yA0 = f.sy0, yA1 = f.sy1, yB0 = f.ty0, yB1 = f.ty1;

    // Sequential progress: left ribbons begin early, right ribbons follow
    const pStart = 0.12 + (src.col / maxCol) * 0.45;
    const pEnd = Math.min(1, pStart + 0.38);
    const fp = clamp01((p - pStart) / (pEnd - pStart));
    if (fp <= 0.001) return;

    // hover bloom: the emphasised ribbon brightens, thickens and lifts
    const lift = emph * 3;
    const alpha = hovActive
      ? (emph > 0.01 ? 0.45 + 0.45 * emph : 0.45 * (1 - 0.78 * hov.amt))
      : 0.45;
    const grad = ctx.createLinearGradient(x0, 0, x1, 0);
    grad.addColorStop(0, rgba(glow(src.color, emph), alpha));
    grad.addColorStop(1, rgba(glow(tgt.color, emph), alpha));

    ctx.save();
    // Sweep outward along path vectors
    if (fp < 0.999) {
      const sweepX = x0 + (x1 - x0) * fp;
      ctx.beginPath();
      ctx.rect(0, 0, sweepX, H);
      ctx.clip();
    }

    // 3D Depth Shadow ribbon underneath in 3D mode
    if (m > 0.05) {
      ctx.fillStyle = rgba(t.ink, (0.08 + 0.14 * emph) * m * (isDimmed ? (1 - 0.7 * hov.amt) : 1));
      ctx.beginPath();
      ctx.moveTo(x0, yA0 + oy - lift * 0.4);
      ctx.bezierCurveTo(c1, yA0 + oy - lift * 0.4, c2, yB0 + oy - lift * 0.4, x1, yB0 + oy - lift * 0.4);
      ctx.lineTo(x1, yB1 + oy - lift * 0.4);
      ctx.bezierCurveTo(c2, yB1 + oy - lift * 0.4, c1, yA1 + oy - lift * 0.4, x0, yA1 + oy - lift * 0.4);
      ctx.closePath();
      ctx.fill();
    }

    // Main flow ribbon
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(x0, yA0 - lift);
    ctx.bezierCurveTo(c1, yA0 - lift, c2, yB0 - lift, x1, yB0 - lift);
    ctx.lineTo(x1, yB1 + lift * 0.6);
    ctx.bezierCurveTo(c2, yB1 + lift * 0.6, c1, yA1 + lift * 0.6, x0, yA1 + lift * 0.6);
    ctx.closePath();
    ctx.fill();

    // Top edge highlight in 3D mode or on hover
    if (emph > 0.01 || m > 0.1) {
      ctx.strokeStyle = emph > 0.01 ? rgba('#ffffff', 0.35 + 0.65 * emph) : 'rgba(255,255,255,0.35)';
      ctx.lineWidth = emph > 0.01 ? 0.8 + 1.2 * emph : 0.8;
      ctx.beginPath();
      ctx.moveTo(x0, yA0 - lift);
      ctx.bezierCurveTo(c1, yA0 - lift, c2, yB0 - lift, x1, yB0 - lift);
      ctx.stroke();
    }

    ctx.restore();
  });

  // Draw nodes sequentially from left to right with 3D cuboid depth
  nodes.forEach((n, i) => {
    const colP = n.col / maxCol;
    const np = clamp01((p - colP * 0.22) / 0.32);
    if (np <= 0.001) return;
    const emph = nodeEmph(i); // 0 … 1 eased emphasis
    const isDimmed = hovActive && emph < 0.01;
    const col = glow(n.color, emph);
    const nh = Math.max(2, n.h * np);
    const ny = n.y + (n.h - nh) / 2;
    // hovered node widens slightly; dimmed nodes fade
    const xW = nodeW + emph * 4;
    const xOff = emph * 2;
    if (isDimmed) ctx.globalAlpha = 1 - 0.62 * hov.amt;

    const nx = n.x - xOff;

    // 3D Cuboid extrusion in 3D mode
    if (m > 0.05) {
      // Top cap
      ctx.fillStyle = shade(col, 1.28);
      ctx.beginPath();
      ctx.moveTo(nx, ny);
      ctx.lineTo(nx + ox, ny - oy);
      ctx.lineTo(nx + xW + ox, ny - oy);
      ctx.lineTo(nx + xW, ny);
      ctx.closePath();
      ctx.fill();

      // Right side shadow face
      ctx.fillStyle = shade(col, 0.72);
      ctx.beginPath();
      ctx.moveTo(nx + xW, ny);
      ctx.lineTo(nx + xW + ox, ny - oy);
      ctx.lineTo(nx + xW + ox, ny + nh - oy);
      ctx.lineTo(nx + xW, ny + nh);
      ctx.closePath();
      ctx.fill();
    }

    // Front node face
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.roundRect(nx, ny, xW, nh, m > 0.05 ? 0 : 3);
    ctx.fill();

    // Hover glow border — eased width/alpha via emph
    if (emph > 0.01) {
      ctx.strokeStyle = rgba('#ffffff', 0.45 + 0.55 * emph);
      ctx.lineWidth = 1 + 1.4 * emph;
      ctx.stroke();
    }
    if (isDimmed) ctx.globalAlpha = 1;

    // Labels appear as node materializes
    if (np > 0.65) {
      const lx = n.x + nodeW + 8 + (m > 0.05 ? ox : 0);
      ctx.textAlign = 'left';
      const avail = n.col < lay.cols - 1 ? (lay.colX[n.col + 1] ?? W) - lx - 10 : W - lx - 6;
      const one = `${n.name} · ${fmtNum(n.value)}`;
      ctx.font = font(t, 600 + Math.round(emph * 100), 11);
      const labelCol = emph > 0.01 ? t.ink : shade(t.ink, 0.9);
      if (full || measureW(ctx, one) <= avail) {
        ctx.fillStyle = labelCol;
        ctx.fillText(one, lx, n.y + n.h / 2 + 3.5);
      } else {
        ctx.fillStyle = labelCol;
        ctx.fillText(fitCtx(ctx, n.name, Math.max(30, avail)), lx, n.y + n.h / 2 - 2);
        ctx.font = font(t, 600, 9.5);
        ctx.fillStyle = t.axis;
        ctx.fillText(fmtNum(n.value), lx, n.y + n.h / 2 + 9);
      }
    }
  });
  ctx.textAlign = 'left';
  return;
}
