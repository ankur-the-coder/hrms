/* Painter: radialbars — placeholder re-export; real MUI-style painter lands next. */
export { paintRadialClassic as paintRadialBars } from './radial';
