/* Painter: bar — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintBar(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const labels = multi ? cats : data.map((x) => x.label);
  const max = multi
    ? Math.max(...cats.map((_, c) => series.reduce((s, sr) => s + (sr.values[c] || 0), 0)), 1)
    : Math.max(...data.map((x) => x.value), 1);
  const L = xyLayout('bar', W, H, m, labels, 1, max, !!d.yLabel, full);
  const { pad, ch, step, ox, oy } = L;
  drawAxes(ctx, W, H, pad, max, t, ox, oy);
  if (d.yLabel) {
    ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
    ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
  }
  drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2 + ox / 2, pad.t + ch, t, W);

  labels.forEach((_, ci) => {
    const bw = Math.min(44, step * 0.52);
    const x = pad.l + step * ci + (step - bw) / 2;
    const segs = multi
      ? series.map((sr, si) => ({ v: sr.values[ci] || 0, col: sColors[si], on: !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === si) }))
      : [{ v: data[ci].value, col: colors[ci], on: hov.idx === ci }];
    let acc = 0;
    segs.forEach((sg, si) => {
      if (sg.v <= 0) return;
      const h = (sg.v / max) * ch * p;
      const yTop = pad.t + ch - ((acc / max) * ch * p) - h;
      const col = sg.on ? shade(sg.col, 1 + 0.16 * hov.amt) : sg.col;
      if (m > 0.02) {
        ctx.fillStyle = shade(sg.col, 0.7 * (sg.on ? 1 + 0.1 * hov.amt : 1));
        ctx.beginPath(); ctx.moveTo(x + bw, yTop); ctx.lineTo(x + bw + ox, yTop - oy);
        ctx.lineTo(x + bw + ox, yTop - oy + h); ctx.lineTo(x + bw, yTop + h); ctx.closePath(); ctx.fill();
        const isTop = si === segs.length - 1 || segs.slice(si + 1).every((z) => z.v <= 0);
        if (isTop) {
          ctx.fillStyle = shade(sg.col, 1.22);
          ctx.beginPath(); ctx.moveTo(x, yTop); ctx.lineTo(x + ox, yTop - oy);
          ctx.lineTo(x + bw + ox, yTop - oy); ctx.lineTo(x + bw, yTop); ctx.closePath(); ctx.fill();
        }
        ctx.fillStyle = col;
        ctx.fillRect(x, yTop, bw, h);
      } else {
        ctx.fillStyle = col;
        ctx.beginPath(); ctx.roundRect(x, yTop, bw, Math.max(1, h - (multi ? 1 : 0)), multi ? 2 : [6, 6, 0, 0]); ctx.fill();
      }
      acc += sg.v;
    });
  });
  ctx.textAlign = 'left';
  return;
}
