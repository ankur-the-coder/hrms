/* Painter: calendar pie — extracted verbatim from shared/Charts.tsx. */
import type { ChartDatum, ChartKind, DrawCtx, StackedSeries, Theme } from '../core/types';
import { approxW, clamp01, easeOut, fitCtx, fmtNum, lerp, measureW, rgba, shade, withAlpha, type Ctx } from '../core/utils';
import { activePalette, font, themeColors } from '../core/theme';
import { drawXLabels, planX, planXFit } from '../axes/xlabels';
import { xyLayout, seriesDepth, ZX, ZY, DZ, DZY, type XY } from '../geometry/xy';
import { circGeom, radialGeom, funnelGeom, funnelLabel, leaderLabel, drawLeaders, drawAxes } from '../geometry/circular';
import { ORBIT_REST, makeProj, sankeyLayout, sankeyLayout3D, sankeyRibbon, sankeyCam, sankeySlab, pipeShade, sk3Smooth, sk3Tube, sk3FillTube, sk3StrokeEdge, sk3TubeGrad } from '../geometry/sankey';
import { STREAM_SALARY_10Y, streamGeom } from '../geometry/stream';
import { radialOffset, distinctLineColor } from '../../chartGeometry';
import { setShadow, noShadow } from '../neu/tones';

export function paintCalendarPie(ctx: Ctx, kind: ChartKind, d: DrawCtx): void {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const days = d.days || [];
  const names = series.map((x) => x.name);
  if (!days.length || !names.length) return;
  const dates = days.map((x) => new Date(x.date + 'T00:00:00'));
  const first = new Date(Math.min(...dates.map((x) => x.getTime())));
  const monthStart = new Date(first.getFullYear(), first.getMonth(), 1);
  const monthEnd = new Date(first.getFullYear(), first.getMonth() + 1, 0);
  const byDay = new Map(days.map((x) => [x.date, x.values]));
  const padL = 12, padR = 12, padT = 34, padB = 10;
  const cols = 7;
  const leadBlank = (monthStart.getDay() + 6) % 7; // Monday-first grid, like the reference
  const rows = Math.ceil((leadBlank + monthEnd.getDate()) / cols);
  const cell = Math.min((W - padL - padR) / cols, (H - padT - padB) / rows);
  const gx = padL + ((W - padL - padR) - cell * cols) / 2, gy = padT + ((H - padT - padB) - cell * rows) / 2;
  const r = cell * 0.36;
  ctx.font = font(t, 700, Math.min(11, Math.max(8.5, cell * 0.16)));
  ctx.fillStyle = t.ink; ctx.textAlign = 'left';
  ctx.fillText(monthStart.toLocaleDateString('en', { month: 'long', year: 'numeric' }), padL, 18);
  ctx.font = font(t, 700, Math.min(10, Math.max(8, cell * 0.14))); ctx.fillStyle = t.axis; ctx.textAlign = 'center';
  ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].forEach((wd, i) => ctx.fillText(wd, gx + cell * i + cell / 2, gy - 6));
  // grid cells
  for (let dnum = 1; dnum <= monthEnd.getDate(); dnum++) {
    const idx = leadBlank + dnum - 1, c = idx % cols, rw = Math.floor(idx / cols);
    const x0 = gx + c * cell, y0 = gy + rw * cell;
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.rect(x0 + 0.5, y0 + 0.5, cell - 1, cell - 1); ctx.stroke();
    const iso = `${monthStart.getFullYear()}-${String(monthStart.getMonth() + 1).padStart(2, '0')}-${String(dnum).padStart(2, '0')}`;
    const vals = byDay.get(iso);
    ctx.font = font(t, 700, Math.min(10, Math.max(7.5, cell * 0.14))); ctx.fillStyle = vals ? t.ink : t.axis; ctx.textAlign = 'left';
    ctx.fillText(String(dnum), x0 + 4, y0 + Math.min(12, cell * 0.18));
    if (!vals) continue;
    const tot = vals.reduce((a2, b) => a2 + b, 0) || 1;
    const cx0 = x0 + cell / 2, cy0 = y0 + cell / 2 + cell * 0.05;
    const on = hov.seg && hov.seg.c === dnum;
    let a = -Math.PI / 2;
    vals.forEach((v, si) => {
      if (v <= 0) return;
      const a1 = a + (v / tot) * Math.PI * 2 * p;
      const hi = on && hov.seg!.s === si;
      const rr = r * (hi ? 1 + 0.1 * hov.amt : 1);
      ctx.fillStyle = hi ? shade(sColors[si], 1.12) : sColors[si];
      ctx.beginPath(); ctx.moveTo(cx0, cy0); ctx.arc(cx0, cy0, rr, a, a1); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = d.bg || t.surface || '#fff'; ctx.lineWidth = 1.2; ctx.stroke();
      // value labels inside slices when there is room
      if (cell >= 64 && v / tot >= 0.12 && p > 0.95) {
        const mid = (a + a1) / 2;
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
        ctx.font = font(t, 700, Math.max(7.5, Math.min(10, r * 0.28)));
        ctx.fillText(fmtNum(v), cx0 + Math.cos(mid) * rr * 0.62, cy0 + Math.sin(mid) * rr * 0.62 + 3);
      }
      a = a1;
    });
  }
  ctx.textAlign = 'left';
  return;
}
