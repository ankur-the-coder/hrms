import supabase from './db-client.js';
import { requireUser } from '../server/require-user.js';

const cors = (res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
};

/** Every profile in this single-tenant demo belongs to the "aviary" tenant. */
async function aviaryTenantId() {
  const { data, error } = await supabase.from('hrms_tenants').select('id').eq('slug', 'aviary').maybeSingle();
  if (error) throw error;
  if (data) return data.id;
  const { data: created, error: cErr } = await supabase.from('hrms_tenants').insert({ slug: 'aviary', name: 'Aviary Technologies' }).select().single();
  if (cErr) throw cErr;
  return created.id;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const user = await requireUser(req, res);
    if (!user) return;

    if (req.method === 'GET') {
      const { email, name, avatar, auth_id } = req.query;
      const authId = auth_id || user.id;
      const { data: existing, error: findErr } = await supabase.from('hrms_profiles').select('*').eq('auth_id', authId).maybeSingle();
      if (findErr) throw findErr;
      if (existing) {
        return res.status(200).json({
          id: existing.id, tenant_id: String(existing.tenant_id), email: existing.email,
          full_name: existing.full_name, avatar_url: existing.avatar_url, role: existing.role, prefs: existing.prefs,
        });
      }
      const tenant_id = await aviaryTenantId();
      const full_name = name || (email ? String(email).split('@')[0] : 'Member');
      const { data: created, error: cErr } = await supabase
        .from('hrms_profiles')
        .insert({ auth_id: authId, tenant_id, email: email || user.email, full_name, avatar_url: avatar || null, role: 'Admin', prefs: null })
        .select().single();
      if (cErr) throw cErr;
      return res.status(201).json({
        id: created.id, tenant_id: String(created.tenant_id), email: created.email,
        full_name: created.full_name, avatar_url: created.avatar_url, role: created.role, prefs: created.prefs,
      });
    }

    if (req.method === 'PUT') {
      const { id, prefs } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data, error } = await supabase.from('hrms_profiles').update({ prefs }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('bootstrap API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
