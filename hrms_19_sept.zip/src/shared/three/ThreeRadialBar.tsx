import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import type { ChartDatum } from '../Charts';
import { buildThreePNG, buildThreeSVG, captureLabelPositions, withExportResolution, type ExportTheme } from './exportUtils';
import type { ThreeChartHandle } from './ThreeSankey3D';

interface Props {
  data: ChartDatum[];
  palette: string[];
  dim: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (idx: number | null, text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

class ArcCurve3 extends THREE.Curve<THREE.Vector3> {
  radius: number; startAngle: number; endAngle: number;
  constructor(radius: number, startAngle: number, endAngle: number) {
    super();
    this.radius = radius; this.startAngle = startAngle; this.endAngle = endAngle;
  }
  getPoint(t: number, target = new THREE.Vector3()) {
    const angle = this.startAngle + t * (this.endAngle - this.startAngle);
    return target.set(Math.cos(angle) * this.radius, 0, -Math.sin(angle) * this.radius);
  }
}

/** Radial bar chart rendered as real 3D tube-arcs (ported from the reference
 * "Radial bar chart.html"). A single Three.js scene serves BOTH the 2D and
 * 3D views — only the camera position/up-vector and each arc's vertical lift
 * morph between them, exactly like the reference mock, so 2D⇄3D is a true
 * camera transition rather than a different chart. */
const ThreeRadialBar = forwardRef<ThreeChartHandle, Props>(function ThreeRadialBar(
  { data, palette, dim, hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);

  const api = useRef<{
    renderer: THREE.WebGLRenderer;
    labelRenderer: CSS2DRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    rings: { barGroup: THREE.Group; badge: CSS2DObject; valueObj: CSS2DObject; stem: THREE.Line; radius: number; mat: THREE.MeshPhysicalMaterial; name: string; value: number }[];
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    setMode: (m: '2D' | '3D') => void;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 500);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container!.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container!.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 - 0.03;
    controls.enabled = false;

    scene.add(new THREE.AmbientLight(0xffffff, 1.4));
    const key = new THREE.DirectionalLight(0xfffdfa, 2.1);
    key.position.set(8, 20, 10);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0006;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xa0c8ff, 0.8);
    fill.position.set(-10, 8, -10);
    scene.add(fill);

    const graphGroup = new THREE.Group();
    scene.add(graphGroup);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), new THREE.ShadowMaterial({ opacity: 0.1 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.05;
    floor.receiveShadow = true;
    graphGroup.add(floor);

    const INNER_R = 1.55, R_STEP = 0.44, TUBE_R = 0.12; // roomier rings — more breathing space per ring
    const items = (data || []).slice(0, 24);
    const MAX_VAL = Math.max(1, ...items.map((d) => d.value)) * 1.06;

    function makeBar(radius: number, startA: number, endA: number, color: string) {
      const group = new THREE.Group();
      const mat = new THREE.MeshPhysicalMaterial({ color: new THREE.Color(color), roughness: 0.25, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.15 });
      const curve = new ArcCurve3(radius, startA, endA);
      const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 96, TUBE_R, 20, false), mat);
      tube.castShadow = true; tube.receiveShadow = true;
      group.add(tube);
      const capGeo = new THREE.SphereGeometry(TUBE_R, 20, 20);
      const c0 = new THREE.Mesh(capGeo, mat); c0.position.copy(curve.getPoint(0)); c0.castShadow = true; group.add(c0);
      const c1 = new THREE.Mesh(capGeo, mat); c1.position.copy(curve.getPoint(1)); c1.castShadow = true; group.add(c1);
      return { group, mat, tube };
    }
    function makeTrack(radius: number) {
      const curve = new ArcCurve3(radius, 0, Math.PI * 2);
      const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, 128, TUBE_R * 0.82, 14, true), new THREE.MeshStandardMaterial({ color: dark ? 0x2a332c : 0xe4e2dc, roughness: 0.9 }));
      mesh.receiveShadow = true;
      return mesh;
    }

    const rings: NonNullable<typeof api.current>['rings'] = [];
    const hitMeshes: { mesh: THREE.Object3D; ringIdx: number }[] = [];
    const labelRefs: { el: HTMLElement; text: string; color?: string }[] = [];

    items.forEach((d, i) => {
      const color = d.color || palette[i % palette.length];
      const radius = INNER_R + i * R_STEP;
      graphGroup.add(makeTrack(radius));
      const frac = Math.min(1, d.value / MAX_VAL);
      const startA = Math.PI / 2;
      const sweep = frac * Math.PI * 2 * 0.97;
      const endA = startA - sweep;
      const { group: barGroup, mat, tube } = makeBar(radius, startA, endA, color);
      graphGroup.add(barGroup);
      hitMeshes.push({ mesh: tube, ringIdx: i });
      (barGroup as unknown as { userData: { targetY: number } }).userData = { targetY: 0.1 + frac * 0.42 };

      const cDiv = document.createElement('div');
      cDiv.textContent = `${d.label} · ${Math.round(d.value)}`;
      cDiv.style.font = '700 11px "Kalam","Outfit",sans-serif';
      cDiv.style.color = dark ? '#f1f5ef' : '#1a1a1a';
      cDiv.style.background = dark ? 'rgba(20,26,22,0.85)' : '#ffffff';
      cDiv.style.border = `1.5px solid ${color}`;
      cDiv.style.borderRadius = '10px';
      cDiv.style.padding = '1px 7px';
      cDiv.style.whiteSpace = 'nowrap';
      cDiv.style.pointerEvents = 'none';
      cDiv.style.boxShadow = '0 3px 8px rgba(0,0,0,0.12)';
      const cObj = new CSS2DObject(cDiv);
      graphGroup.add(cObj);
      (cObj as unknown as { userData: { targetY: number; radius: number } }).userData = { targetY: 0.6 + (items.length - i) * 0.17, radius };
      labelRefs.push({ el: cDiv, text: `${d.label} · ${Math.round(d.value)}`, color });

      const stemMat = new THREE.LineBasicMaterial({ color: dark ? 0x666 : 0xcccccc, transparent: true, opacity: 0.8 });
      const stemGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, -radius), new THREE.Vector3(0, 0, -radius)]);
      const stemLine = new THREE.Line(stemGeo, stemMat);
      graphGroup.add(stemLine);

      const vDiv = document.createElement('div');
      vDiv.textContent = String(Math.round(d.value));
      vDiv.style.font = '700 11px "Kalam","Outfit",sans-serif';
      vDiv.style.color = '#ffffff';
      vDiv.style.textShadow = '0 1px 4px rgba(0,0,0,0.8)';
      vDiv.style.pointerEvents = 'none';
      const vObj = new CSS2DObject(vDiv);
      const endPoint = new ArcCurve3(radius, startA, endA).getPoint(1);
      (vObj as unknown as { userData: { baseX: number; baseZ: number } }).userData = { baseX: endPoint.x, baseZ: endPoint.z };
      graphGroup.add(vObj);

      rings.push({ barGroup, badge: cObj, valueObj: vObj, stem: stemLine, radius, mat, name: d.label, value: d.value });
    });

    const state2D = { camPos: new THREE.Vector3(0, 22, 0.001), camTarget: new THREE.Vector3(0, 0, 0), up: new THREE.Vector3(0, 0, -1), lift: 0 };
    const maxR = INNER_R + items.length * R_STEP;
    const state3D = { camPos: new THREE.Vector3(maxR * 0.95, maxR * 1.05, maxR * 1.25), camTarget: new THREE.Vector3(0, 0, 0), up: new THREE.Vector3(0, 1, 0), lift: 1 };

    let mode: '2D' | '3D' = '2D';
    let transitioning = false, tProg = 1;
    const startPos = new THREE.Vector3(), startTarget = new THREE.Vector3(), startUp = new THREE.Vector3();
    camera.position.copy(state2D.camPos);
    camera.up.copy(state2D.up);
    controls.target.copy(state2D.camTarget);

    function setMode(m: '2D' | '3D') {
      if (mode === m) return;
      mode = m;
      controls.enabled = false;
      transitioning = true; tProg = 0;
      startPos.copy(camera.position); startTarget.copy(controls.target); startUp.copy(camera.up);
    }

    function resize() {
      const W = container!.clientWidth || 600, H = container!.clientHeight || 360;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
    }
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    let hoveredRing = -1;
    let origColor: THREE.Color | null = null;

    function applyHover(idx: number) {
      if (hoveredRing === idx) return;
      if (hoveredRing >= 0 && origColor) rings[hoveredRing].mat.color.copy(origColor);
      hoveredRing = idx;
      if (idx >= 0) {
        origColor = rings[idx].mat.color.clone();
        rings[idx].mat.color.offsetHSL(0, 0, 0.12);
      }
    }
    function clearHoverVisual() {
      if (hoveredRing >= 0 && origColor) rings[hoveredRing].mat.color.copy(origColor);
      hoveredRing = -1; origColor = null;
    }

    function onPointerMove(e: PointerEvent) {
      const rect = container!.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(hitMeshes.map((h) => h.mesh), false);
      if (hits.length) {
        const found = hitMeshes.find((h) => h.mesh === hits[0].object);
        if (found) {
          applyHover(found.ringIdx);
          const r = rings[found.ringIdx];
          setTip({ x: e.clientX - rect.left, y: e.clientY - rect.top, text: `${r.name} · ${Math.round(r.value)}` });
          onHover?.(found.ringIdx, `${r.name} · ${Math.round(r.value)}`);
          container!.style.cursor = 'pointer';
        }
      } else {
        clearHoverVisual();
        setTip(null);
        onHover?.(null, null);
        container!.style.cursor = mode === '3D' ? 'grab' : 'default';
      }
    }
    function onPointerLeave() { clearHoverVisual(); setTip(null); onHover?.(null, null); }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    let currentLift = 0;
    const tmpTarget = new THREE.Vector3();
    let raf = 0;
    const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
    const animate = () => {
      raf = requestAnimationFrame(animate);
      const target = mode === '2D' ? state2D : state3D;
      if (transitioning) {
        tProg += 0.022;
        if (tProg >= 1) { tProg = 1; transitioning = false; if (mode === '3D') controls.enabled = true; }
        const ease = easeOutCubic(tProg);
        camera.position.lerpVectors(startPos, target.camPos, ease);
        camera.up.lerpVectors(startUp, target.up, ease).normalize();
        tmpTarget.lerpVectors(startTarget, target.camTarget, ease);
        controls.target.copy(tmpTarget);
      }
      currentLift += (target.lift - currentLift) * 0.08;
      rings.forEach((r) => {
        const ud = (r.barGroup as unknown as { userData: { targetY: number } }).userData;
        const tubeY = ud.targetY * currentLift;
        r.barGroup.position.y = tubeY;
        const vud = (r.valueObj as unknown as { userData: { baseX: number; baseZ: number } }).userData;
        r.valueObj.position.set(vud.baseX, tubeY + 0.15, vud.baseZ);
        const bud = (r.badge as unknown as { userData: { targetY: number; radius: number } }).userData;
        const labelY = 0.02 + bud.targetY * currentLift;
        r.badge.position.set(0, labelY, -bud.radius);
        const pos = r.stem.geometry.attributes.position.array as Float32Array;
        pos[1] = labelY; pos[4] = tubeY;
        r.stem.geometry.attributes.position.needsUpdate = true;
        (r.stem.material as THREE.LineBasicMaterial).opacity = currentLift * 0.6;
      });
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    };
    animate();

    const dispose = () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      controls.dispose();
      renderer.dispose();
      container!.removeChild(renderer.domElement);
      container!.removeChild(labelRenderer.domElement);
    };

    api.current = { renderer, labelRenderer, scene, camera, controls, rings, labelRefs, setMode, dispose };
    setMode(dim === '3d' ? '3D' : '2D');
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, palette, dark]);

  useEffect(() => { api.current?.setMode(dim === '3d' ? '3D' : '2D'); }, [dim]);

  useEffect(() => {
    const a = api.current;
    if (!a) return;
    a.rings.forEach((r, i) => {
      const active = hoverIndex === i;
      const el = r.badge.element as HTMLElement;
      el.style.boxShadow = active ? '0 4px 14px rgba(0,0,0,0.25)' : '0 3px 8px rgba(0,0,0,0.12)';
      el.style.zIndex = active ? '5' : '1';
    });
  }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(W, H, false);
      const labels = captureLabelPositions(container, a.labelRefs);
      const legend = a.rings.map((r, i) => ({ label: r.name, color: palette[i % palette.length] }));
      const cv = await buildThreePNG({ title, imageDataUrl: dataUrl, chartW: W, chartH: H, labels, legend, theme, footnote: `Radial bar · ${dim === '3d' ? '3D' : '2D'} view` });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      const labels = captureLabelPositions(container, a.labelRefs);
      const legend = a.rings.map((r, i) => ({ label: r.name, color: palette[i % palette.length] }));
      return buildThreeSVG({ title, imageDataUrl: dataUrl, chartW: W, chartH: H, labels, legend, theme, footnote: `Radial bar · ${dim === '3d' ? '3D' : '2D'} view` });
    },
  }), [data, palette, theme, dim]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full">
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 max-w-[220px] px-2.5 py-1 font-body text-[11px] font-bold text-ink"
          style={{ left: Math.min(tip.x + 12, (containerRef.current?.clientWidth || 300) - 190), top: Math.max(0, tip.y - 34) }}>
          {tip.text}
        </div>
      )}
    </div>
  );
});

export default ThreeRadialBar;
