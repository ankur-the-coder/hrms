import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import type { StackedSeries } from '../Charts';
import { buildThreePNG, buildThreeSVG, captureLabelPositions, withExportResolution, type ExportTheme } from './exportUtils';
import type { ThreeChartHandle } from './ThreeSankey3D';

interface Props {
  categories: string[];
  series: StackedSeries[];
  palette: string[];
  hoverIndex?: number | null;
  onHover?: (idx: number | null, text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

/** Volumetric 3D streamgraph — every series is its own solid ribbon offset
 * into its own Z-lane (ported from the reference "3D stream graph.html"),
 * fed with the chart's real category/series data. */
const ThreeStreamGraph3D = forwardRef<ThreeChartHandle, Props>(function ThreeStreamGraph3D(
  { categories, series, palette, hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);
  const [preset, setPreset] = useState<'perspective' | 'top' | 'side'>('perspective');

  const api = useRef<{
    renderer: THREE.WebGLRenderer;
    labelRenderer: CSS2DRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    ribbons: THREE.Mesh[];
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    setPreset: (p: 'perspective' | 'top' | 'side') => void;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || !series.length || categories.length < 2) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true, logarithmicDepthBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setClearColor(0x000000, 0);
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container!.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container!.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.07;

    scene.add(new THREE.AmbientLight(0xffffff, 1.15));
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.2);
    keyLight.position.set(-24, 46, 34);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 5; keyLight.shadow.camera.far = 140;
    const sd = 40;
    keyLight.shadow.camera.left = -sd; keyLight.shadow.camera.right = sd;
    keyLight.shadow.camera.top = sd; keyLight.shadow.camera.bottom = -sd;
    keyLight.shadow.bias = -0.0004;
    scene.add(keyLight);
    const fillLight = new THREE.DirectionalLight(0xbdd7ff, 1.1);
    fillLight.position.set(30, -8, -30);
    scene.add(fillLight);
    const rimLight = new THREE.DirectionalLight(0xffffff, 0.85);
    rimLight.position.set(0, 24, -40);
    scene.add(rimLight);

    const labelRefs: { el: HTMLElement; text: string; color?: string }[] = [];

    const N = series.length;
    const cats = categories;
    const n = cats.length;
    const TOTAL_WIDTH = 60;
    const HEIGHT_SCALE = 0.34;
    const Z_SPAN = Math.min(18, Math.max(6, N * 1.4));
    const Z_STEP = Z_SPAN / Math.max(1, N);
    const numSteps = Math.min(180, Math.max(48, n * 10));

    function evalSpline(ys: number[], steps: number) {
      const pts = ys.map((y, i) => new THREE.Vector2(i / (n - 1), y));
      const curve = new THREE.SplineCurve(pts);
      return curve.getPoints(steps);
    }

    const sampled = series.map((s) => evalSpline(cats.map((_, j) => Math.max(0, s.values[j] || 0)), numSteps));

    const totals = series.map((s) => s.values.reduce((a, b) => a + b, 0));
    const desc = series.map((_, i) => i).sort((a, b) => totals[b] - totals[a]);
    const order: number[] = [];
    desc.forEach((si, k) => { if (k % 2 === 0) order.push(si); else order.unshift(si); });

    const stackBottom: THREE.Vector2[][] = Array.from({ length: N }, () => []);
    const stackTop: THREE.Vector2[][] = Array.from({ length: N }, () => []);
    for (let step = 0; step <= numSteps; step++) {
      let total = 0;
      for (let s = 0; s < N; s++) total += sampled[s][step].y;
      const normX = sampled[0][step].x;
      let curY = -total / 2;
      const x = (normX - 0.5) * TOTAL_WIDTH;
      order.forEach((si) => {
        const h = sampled[si][step].y;
        stackBottom[si].push(new THREE.Vector2(x, curY * HEIGHT_SCALE));
        curY += h;
        stackTop[si].push(new THREE.Vector2(x, curY * HEIGHT_SCALE));
      });
    }

    const ribbonMeshes: THREE.Mesh[] = [];
    const hitToSeries = new Map<THREE.Mesh, number>();
    const group = new THREE.Group();
    scene.add(group);

    order.forEach((si, laneIdx) => {
      const color = series[si].color || palette[si % palette.length];
      const zCenter = (laneIdx - N / 2) * Z_STEP;
      const depth = Math.max(0.6, Z_STEP * 0.82);
      const zF = zCenter + depth / 2, zB = zCenter - depth / 2;
      const positions: number[] = []; const normals: number[] = []; const idxs: number[] = [];
      let vc = 0;
      const addQuad = (p1: THREE.Vector3, p2: THREE.Vector3, p3: THREE.Vector3, p4: THREE.Vector3, nrm: THREE.Vector3) => {
        positions.push(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, p3.x, p3.y, p3.z, p4.x, p4.y, p4.z);
        for (let k = 0; k < 4; k++) normals.push(nrm.x, nrm.y, nrm.z);
        idxs.push(vc, vc + 1, vc + 2, vc, vc + 2, vc + 3);
        vc += 4;
      };
      for (let i = 0; i < numSteps; i++) {
        const b0 = stackBottom[si][i], b1 = stackBottom[si][i + 1];
        const t0 = stackTop[si][i], t1 = stackTop[si][i + 1];
        addQuad(new THREE.Vector3(b0.x, b0.y, zF), new THREE.Vector3(b1.x, b1.y, zF), new THREE.Vector3(t1.x, t1.y, zF), new THREE.Vector3(t0.x, t0.y, zF), new THREE.Vector3(0, 0, 1));
        addQuad(new THREE.Vector3(b1.x, b1.y, zB), new THREE.Vector3(b0.x, b0.y, zB), new THREE.Vector3(t0.x, t0.y, zB), new THREE.Vector3(t1.x, t1.y, zB), new THREE.Vector3(0, 0, -1));
        const topN = new THREE.Vector3(-(t1.y - t0.y), t1.x - t0.x, 0).normalize();
        addQuad(new THREE.Vector3(t0.x, t0.y, zF), new THREE.Vector3(t1.x, t1.y, zF), new THREE.Vector3(t1.x, t1.y, zB), new THREE.Vector3(t0.x, t0.y, zB), topN);
        const botN = new THREE.Vector3(b1.y - b0.y, -(b1.x - b0.x), 0).normalize();
        addQuad(new THREE.Vector3(b1.x, b1.y, zF), new THREE.Vector3(b0.x, b0.y, zF), new THREE.Vector3(b0.x, b0.y, zB), new THREE.Vector3(b1.x, b1.y, zB), botN);
      }
      const sB = stackBottom[si][0], sT = stackTop[si][0];
      addQuad(new THREE.Vector3(sB.x, sB.y, zB), new THREE.Vector3(sB.x, sB.y, zF), new THREE.Vector3(sT.x, sT.y, zF), new THREE.Vector3(sT.x, sT.y, zB), new THREE.Vector3(-1, 0, 0));
      const eB = stackBottom[si][numSteps], eT = stackTop[si][numSteps];
      addQuad(new THREE.Vector3(eB.x, eB.y, zF), new THREE.Vector3(eB.x, eB.y, zB), new THREE.Vector3(eT.x, eT.y, zB), new THREE.Vector3(eT.x, eT.y, zF), new THREE.Vector3(1, 0, 0));

      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      geo.setIndex(idxs);
      const mat = new THREE.MeshPhysicalMaterial({ color: new THREE.Color(color), roughness: 0.3, metalness: 0.08, clearcoat: 0.7, clearcoatRoughness: 0.2, side: THREE.DoubleSide });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true; mesh.receiveShadow = true;
      group.add(mesh);
      ribbonMeshes.push(mesh);
      hitToSeries.set(mesh, si);

      const midStep = Math.floor(numSteps / 2);
      const lx = stackBottom[si][midStep].x;
      const ly = (stackBottom[si][midStep].y + stackTop[si][midStep].y) / 2;
      const div = document.createElement('div');
      div.textContent = series[si].name;
      div.style.font = '800 12px "Outfit",sans-serif';
      div.style.color = '#ffffff';
      div.style.textShadow = '0 1px 4px rgba(0,0,0,0.6)';
      div.style.pointerEvents = 'none';
      div.style.letterSpacing = '0.2px';
      const labelObj = new CSS2DObject(div);
      labelObj.position.set(lx, ly, zF + 0.15);
      scene.add(labelObj);
      labelRefs.push({ el: div, text: series[si].name, color });
    });

    // shadow / grid floor
    const floorY = -Z_SPAN - 6;
    const shadowPlane = new THREE.Mesh(new THREE.PlaneGeometry(TOTAL_WIDTH * 2.4, TOTAL_WIDTH * 2.4), new THREE.ShadowMaterial({ opacity: 0.12 }));
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = floorY;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);
    const grid = new THREE.GridHelper(TOTAL_WIDTH * 1.6, 24, dark ? 0x2a3a30 : 0xdbeafe, dark ? 0x22281f : 0xedf2f7);
    grid.position.y = floorY + 0.02;
    scene.add(grid);

    cats.forEach((c, i) => {
      const x = (i / (n - 1) - 0.5) * TOTAL_WIDTH;
      const lineGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(x, floorY, -Z_SPAN / 2 - 1), new THREE.Vector3(x, floorY, Z_SPAN / 2 + 3)]);
      scene.add(new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ color: dark ? 0x445048 : 0xcfd8dc })));
      const div = document.createElement('div');
      div.textContent = c;
      div.style.font = '600 10px "Outfit",sans-serif';
      div.style.color = dark ? '#a8b3ac' : '#64748b';
      div.style.pointerEvents = 'none';
      div.style.whiteSpace = 'nowrap';
      const obj = new CSS2DObject(div);
      obj.position.set(x, floorY, Z_SPAN / 2 + 4.5);
      scene.add(obj);
      labelRefs.push({ el: div, text: c });
    });

    // camera presets, auto-scaled to data footprint
    const boxSpan = Math.max(TOTAL_WIDTH, Z_SPAN) * 1.05;
    const presets = {
      perspective: { pos: new THREE.Vector3(-boxSpan * 0.62, boxSpan * 0.46, boxSpan * 0.9), target: new THREE.Vector3(2, -boxSpan * 0.05, 0) },
      side: { pos: new THREE.Vector3(0, 0, boxSpan * 1.05), target: new THREE.Vector3(0, 0, 0) },
      top: { pos: new THREE.Vector3(0, boxSpan * 1.15, 0.01), target: new THREE.Vector3(0, 0, 0) },
    };
    camera.position.copy(presets.perspective.pos);
    controls.target.copy(presets.perspective.target);
    controls.minDistance = boxSpan * 0.3;
    controls.maxDistance = boxSpan * 2.4;

    let targetPos = camera.position.clone();
    let targetFocus = controls.target.clone();
    let transitioning = false;
    function setPresetFn(p: 'perspective' | 'top' | 'side') {
      targetPos.copy(presets[p].pos);
      targetFocus.copy(presets[p].target);
      transitioning = true;
    }

    function resize() {
      const W = container!.clientWidth || 700, H = container!.clientHeight || 380;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
    }
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    let hovered: THREE.Mesh | null = null;
    function onPointerMove(e: PointerEvent) {
      const rect = container!.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(ribbonMeshes, false);
      if (hits.length) {
        const obj = hits[0].object as THREE.Mesh;
        if (hovered !== obj) {
          if (hovered) (hovered.material as THREE.MeshPhysicalMaterial).emissive.setHex(0x000000);
          hovered = obj;
          (hovered.material as THREE.MeshPhysicalMaterial).emissive.setHex(0x2a2a2a);
        }
        const si = hitToSeries.get(obj);
        if (si !== undefined) {
          const yrFrac = Math.max(0, Math.min(1, hits[0].point.x / TOTAL_WIDTH + 0.5));
          const j = Math.round(yrFrac * (n - 1));
          const val = series[si].values[j] || 0;
          setTip({ x: e.clientX - rect.left, y: e.clientY - rect.top, text: `${series[si].name} · ${cats[j]}: ${val}` });
          onHover?.(si, `${series[si].name} · ${cats[j]}: ${val}`);
        }
        container!.style.cursor = 'pointer';
      } else {
        if (hovered) { (hovered.material as THREE.MeshPhysicalMaterial).emissive.setHex(0x000000); hovered = null; }
        setTip(null);
        onHover?.(null, null);
        container!.style.cursor = 'grab';
      }
    }
    function onPointerLeave() {
      if (hovered) { (hovered.material as THREE.MeshPhysicalMaterial).emissive.setHex(0x000000); hovered = null; }
      setTip(null); onHover?.(null, null);
    }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    let raf = 0;
    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (transitioning) {
        camera.position.lerp(targetPos, 0.07);
        controls.target.lerp(targetFocus, 0.07);
        if (camera.position.distanceTo(targetPos) < 0.05) transitioning = false;
      }
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    };
    animate();

    const dispose = () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      controls.dispose();
      renderer.dispose();
      container!.removeChild(renderer.domElement);
      container!.removeChild(labelRenderer.domElement);
    };

    api.current = { renderer, labelRenderer, scene, camera, controls, ribbons: ribbonMeshes, labelRefs, setPreset: setPresetFn, dispose };
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categories, series, palette, dark]);

  useEffect(() => { api.current?.setPreset(preset); }, [preset]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(W, H, false);
      const labels = captureLabelPositions(container, a.labelRefs);
      const legend = series.map((s, i) => ({ label: s.name, color: s.color || palette[i % palette.length] }));
      const cv = await buildThreePNG({ title, imageDataUrl: dataUrl, chartW: W, chartH: H, labels, legend, theme, footnote: 'Volumetric 3D streamgraph' });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      const labels = captureLabelPositions(container, a.labelRefs);
      const legend = series.map((s, i) => ({ label: s.name, color: s.color || palette[i % palette.length] }));
      return buildThreeSVG({ title, imageDataUrl: dataUrl, chartW: W, chartH: H, labels, legend, theme, footnote: 'Volumetric 3D streamgraph' });
    },
  }), [categories, series, palette, theme]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full" style={{ cursor: 'grab' }}>
      <div className="pointer-events-auto absolute right-2 top-2 z-10 flex gap-1">
        {(['perspective', 'top', 'side'] as const).map((p) => (
          <button key={p} onClick={() => setPreset(p)}
            className={`rounded-full px-2 py-0.5 font-body text-[10px] font-bold uppercase backdrop-blur-sm transition ${preset === p ? 'bg-ink text-white' : 'bg-white/70 text-ink/70 hover:bg-white'}`}>
            {p}
          </button>
        ))}
      </div>
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 max-w-[220px] px-2.5 py-1 font-body text-[11px] font-bold text-ink"
          style={{ left: Math.min(tip.x + 12, (containerRef.current?.clientWidth || 300) - 190), top: Math.max(0, tip.y - 34) }}>
          {tip.text}
        </div>
      )}
    </div>
  );
});

export default ThreeStreamGraph3D;
