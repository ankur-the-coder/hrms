import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { captureLabelPositions, buildThreePNG, withExportResolution, type ExportTheme } from './exportUtils';

/** Local, self-contained copy of the app's Sankey layout algorithm — kept
 * independent from Charts.tsx (which in turn lazily imports this component)
 * to avoid a circular module dependency. Produces the identical geometry
 * (same node heights / flow thicknesses) as the 2D canvas Sankey so the
 * chart's proportions never jump when switching 2D ⇄ 3D. */
export interface SankeyLink { source: string; target: string; value: number }
interface SkNode { name: string; col: number; value: number; x: number; y: number; h: number; color: string }
interface SkFlow { si: number; ti: number; value: number; sy0: number; sy1: number; ty0: number; ty1: number }
function sankeyLayout(links: SankeyLink[], W: number, H: number, labelSpace: number, palette: string[]) {
  const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
  const idx = new Map(names.map((nm, i) => [nm, i]));
  const outs = names.map(() => [] as number[]), ins = names.map(() => [] as number[]);
  links.forEach((l, li) => { outs[idx.get(l.source)!].push(li); ins[idx.get(l.target)!].push(li); });
  const col = new Array(names.length).fill(0);
  const visit = (i: number, depth: number, seen: Set<number>) => {
    if (seen.has(i) || depth > 32) return;
    col[i] = Math.max(col[i], depth);
    seen.add(i);
    outs[i].forEach((li) => visit(idx.get(links[li].target)!, depth + 1, seen));
    seen.delete(i);
  };
  names.forEach((_, i) => { if (!ins[i].length) visit(i, 0, new Set()); });
  const cols = Math.max(...col) + 1;
  if (cols < 2) return null;
  const value = names.map((_, i) => Math.max(outs[i].reduce((s2, li) => s2 + links[li].value, 0), ins[i].reduce((s2, li) => s2 + links[li].value, 0)));
  const padT = 14, padB = 14, padL = 8, padR = labelSpace;
  const nodeW = 12, gap = 10;
  const plotW = W - padL - padR - nodeW, plotH = H - padT - padB;
  const colX = Array.from({ length: cols }, (_, c) => padL + (plotW * c) / (cols - 1));
  const perCol = Array.from({ length: cols }, () => [] as number[]);
  names.forEach((_, i) => perCol[col[i]].push(i));
  const colTotal = perCol.map((ids) => ids.reduce((s2, i) => s2 + value[i], 0) + gap * Math.max(0, ids.length - 1));
  const scale = plotH / Math.max(...colTotal, 1);
  const nodes: SkNode[] = names.map((nm, i) => ({ name: nm, col: col[i], value: value[i], x: colX[col[i]], y: 0, h: value[i] * scale, color: palette[i % palette.length] }));
  perCol.forEach((ids) => {
    ids.sort((a, b) => value[b] - value[a]);
    const total = ids.reduce((s2, i) => s2 + nodes[i].h, 0) + gap * Math.max(0, ids.length - 1);
    let y = padT + (plotH - total) / 2;
    ids.forEach((i) => { nodes[i].y = y; y += nodes[i].h + gap; });
  });
  const flows: SkFlow[] = links.map((l) => ({ si: idx.get(l.source)!, ti: idx.get(l.target)!, value: l.value, sy0: 0, sy1: 0, ty0: 0, ty1: 0 }));
  nodes.forEach((nd, i) => {
    let y = nd.y;
    outs[i].map((li) => flows[li]).sort((a, b) => nodes[a.ti].y - nodes[b.ti].y).forEach((f) => { f.sy0 = y; y += f.value * scale; f.sy1 = y; });
    y = nd.y;
    ins[i].map((li) => flows[li]).sort((a, b) => nodes[a.si].y - nodes[b.si].y).forEach((f) => { f.ty0 = y; y += f.value * scale; f.ty1 = y; });
  });
  return { nodes, flows, nodeW, cols, colX };
}

export interface ThreeChartHandle {
  exportPNG: (title: string) => Promise<Blob>;
  exportSVG: (title: string) => Promise<string>;
}

interface Props {
  links: SankeyLink[];
  palette: string[];
  /** '2d' | '3d' — the SAME scene renders both; only the camera and a Z-scale
   * flatten morph between them, so node/flow dimensions never change. */
  dim?: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

const SCALE = 42; // px -> world units, keeps the 3D bar/flow proportions identical to the 2D canvas layout
const FLATTEN_Z = 0.045; // how thin the scene gets in the 2D morph (never fully 0 — keeps faint depth cue)

function escXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function adjustColor(hex: string, percent: number): string {
  const num = parseInt(hex.replace('#', ''), 16);
  let r = (num >> 16) + Math.round(255 * (percent / 100));
  let g = ((num >> 8) & 0x00ff) + Math.round(255 * (percent / 100));
  let b = (num & 0x0000ff) + Math.round(255 * (percent / 100));
  r = Math.min(255, Math.max(0, r)); g = Math.min(255, Math.max(0, g)); b = Math.min(255, Math.max(0, b));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

/** Per-node / per-flow LOCAL-space geometry captured at build time so the
 * SVG exporter can re-project every vertex through the live camera —
 * producing a true vector (not rasterised) SVG, exactly like the reference
 * "sankey 3D test" mock's exportSVG(). */
interface SvgNodeGeom { corners: THREE.Vector3[]; color: string; label: string }
interface SvgFlowGeom { topFront: THREE.Vector3[]; botFront: THREE.Vector3[]; topBack: THREE.Vector3[]; botBack: THREE.Vector3[]; color: string; label: string }

/** Three.js Sankey — real glass-look 3D geometry (ported from the reference
 * "sankey 3D test" mock), fed with the SAME layout math (`sankeyLayout`) the
 * classic 2D canvas Sankey uses — so node heights and flow thicknesses stay
 * perfectly proportional at every step. The 2D ⇄ 3D toggle NEVER rebuilds
 * geometry: it only scales the whole group's Z axis toward 0 and eases the
 * camera to a flatter framing, so dimensions are provably preserved. */
const ThreeSankey3D = forwardRef<ThreeChartHandle, Props>(function ThreeSankey3D(
  { links, palette, dim = '3d', hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);

  const sceneApi = useRef<{
    renderer: THREE.WebGLRenderer;
    labelRenderer: CSS2DRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    group: THREE.Group;
    hit: { mesh: THREE.Object3D; text: string }[];
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    svgGeom: { nodes: SvgNodeGeom[]; flows: SvgFlowGeom[] };
    setDim: (d: '2d' | '3d') => void;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 500);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    renderer.domElement.style.touchAction = 'none';
    container!.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container!.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 5;
    controls.maxDistance = 80;
    controls.maxPolarAngle = Math.PI * 0.62;
    controls.minPolarAngle = Math.PI * 0.12;
    controls.addEventListener('start', () => { transitioning = false; });

    scene.add(new THREE.AmbientLight(0xffffff, 1.3));
    const dirLight = new THREE.DirectionalLight(0xfffdfa, 2.4);
    dirLight.position.set(10, 20, 15);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.set(1024, 1024);
    dirLight.shadow.bias = -0.001;
    scene.add(dirLight);
    const rim = new THREE.DirectionalLight(0xffffff, 1.2);
    rim.position.set(-14, 8, -12);
    scene.add(rim);
    const LIGHT_3D = { amb: 1.3, dir: 2.4, rim: 1.2 };
    const LIGHT_2D = { amb: 1.9, dir: 1.0, rim: 0.3 };
    const ambientLight = scene.children[0] as THREE.AmbientLight;

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    let group = new THREE.Group();
    scene.add(group);
    const platformMat = new THREE.MeshStandardMaterial({ color: dark ? 0x1c2620 : 0xffffff, roughness: 0.85, metalness: 0.05, transparent: true });
    let platform: THREE.Mesh | null = null;

    const hitList: { mesh: THREE.Object3D; text: string }[] = [];
    const labelRefs: { el: HTMLElement; text: string; color?: string }[] = [];
    const svgNodes: SvgNodeGeom[] = [];
    const svgFlows: SvgFlowGeom[] = [];
    // type: 'node' | 'flow'; nodeIdx identifies a node record; si/ti identify
    // a flow's source/target node indices — lets applyHover keep CONNECTED
    // elements at full opacity exactly like the reference mock's setHover().
    const allMeshMats: { mesh: THREE.Mesh; mat: THREE.MeshPhysicalMaterial; baseOpacity: number; kind: 'node' | 'flow'; nodeIdx?: number; si?: number; ti?: number }[] = [];

    // Frosted-glass factory matched 1:1 to the reference mock's
    // createGlassMaterial(): metalness 0.1, roughness 0.25, transmission 0.9,
    // thickness 2.0, ior 1.5, clearcoat 1.0 / roughness 0.1, opaque (1.0).
    function glassMat(hex: string, transmission = 0.9) {
      return new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(hex), metalness: 0.1, roughness: 0.25,
        transmission, thickness: 2.0, ior: 1.5, transparent: true,
        opacity: 1.0, side: THREE.DoubleSide, clearcoat: 1.0, clearcoatRoughness: 0.1,
      });
    }

    function makeNodeLabel(text: string) {
      const div = document.createElement('div');
      div.textContent = text;
      div.style.font = '700 12px "Kalam", "Outfit", sans-serif';
      div.style.color = dark ? '#f1f5ef' : '#161f1a';
      div.style.whiteSpace = 'nowrap';
      div.style.textShadow = dark ? '0 0 6px rgba(0,0,0,0.6)' : '0 0 6px rgba(255,255,255,0.85)';
      div.style.pointerEvents = 'none';
      return div;
    }

    function screenToWorld(x: number, y: number, W: number, H: number): [number, number] {
      return [(x - W / 2) / SCALE, (H / 2 - y) / SCALE];
    }

    function rebuild() {
      const W = container!.clientWidth || 600;
      const H = container!.clientHeight || 360;
      scene.remove(group);
      group.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        if (m.material) { (Array.isArray(m.material) ? m.material : [m.material]).forEach((mm) => mm.dispose()); }
      });
      hitList.length = 0; labelRefs.length = 0; svgNodes.length = 0; svgFlows.length = 0; allMeshMats.length = 0;
      group = new THREE.Group();
      scene.add(group);

      const cleanLinks = (links || []).filter((l) => l.value > 0 && l.source !== l.target);
      if (!cleanLinks.length) return;
      const labelSpace = Math.min(150, W * 0.22);
      const lay = sankeyLayout(cleanLinks, W, H, labelSpace, palette);
      if (!lay) return;

      const [gx0] = screenToWorld(0, H / 2, W, H);
      const [gx1] = screenToWorld(W, H / 2, W, H);
      const platW = Math.abs(gx1 - gx0) + 2;
      const platH = H / SCALE + 1.4;
      if (platform) group.remove(platform);
      const platGeo = new RoundedBoxGeometry(platW, 0.35, platH, 4, 0.35);
      platform = new THREE.Mesh(platGeo, platformMat);
      platform.position.set((gx0 + gx1) / 2, -H / (2 * SCALE) - 0.35, 0);
      platform.receiveShadow = true;
      group.add(platform);

      const boxDepth = 1.15;
      const boxWidth = Math.max(0.35, (lay.nodeW / SCALE) * 1.7);
      lay.nodes.forEach((n, nodeIdx) => {
        const [wx0, wy0] = screenToWorld(n.x + lay.nodeW / 2, n.y, W, H);
        const [, wy1] = screenToWorld(n.x, n.y + n.h, W, H);
        const height3D = Math.max(0.05, wy0 - wy1);
        const cyWorld = (wy0 + wy1) / 2;
        const geo = new RoundedBoxGeometry(boxWidth, height3D, boxDepth, 3, Math.min(0.12, height3D * 0.15));
        const mat = glassMat(n.color);
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(wx0, cyWorld, 0);
        mesh.castShadow = true; mesh.receiveShadow = true;
        group.add(mesh);
        const labelText = `${n.name} · ${Math.round(n.value)}`;
        hitList.push({ mesh, text: labelText });
        allMeshMats.push({ mesh, mat, baseOpacity: 1.0, kind: 'node', nodeIdx });

        const div = makeNodeLabel(labelText);
        const label = new CSS2DObject(div);
        label.position.set(0, height3D / 2 + 0.22, boxDepth / 2 + 0.05);
        mesh.add(label);
        labelRefs.push({ el: div, text: labelText, color: n.color });

        // capture front-face corners in LOCAL (group) space for vector SVG export
        const w = boxWidth / 2, h = height3D / 2, z = boxDepth / 2;
        svgNodes.push({
          color: n.color, label: labelText,
          corners: [
            new THREE.Vector3(wx0 - w, cyWorld + h, z), new THREE.Vector3(wx0 + w, cyWorld + h, z),
            new THREE.Vector3(wx0 + w, cyWorld - h, z), new THREE.Vector3(wx0 - w, cyWorld - h, z),
            new THREE.Vector3(wx0 - w, cyWorld + h, -z), new THREE.Vector3(wx0 + w, cyWorld + h, -z),
            new THREE.Vector3(wx0 + w, cyWorld - h, -z), new THREE.Vector3(wx0 - w, cyWorld - h, -z),
          ],
        });
      });

      const SEG = 28;
      lay.flows.forEach((f) => {
        const x0 = lay.nodes[f.si].x + lay.nodeW, x1 = lay.nodes[f.ti].x;
        const midX = x0 + (x1 - x0) * 0.5;
        const verts: number[] = []; const idxs: number[] = [];
        const topFront: THREE.Vector3[] = [], botFront: THREE.Vector3[] = [], topBack: THREE.Vector3[] = [], botBack: THREE.Vector3[] = [];
        for (let i = 0; i <= SEG; i++) {
          const t = i / SEG; const mt = 1 - t;
          const bx = mt * mt * mt * x0 + 3 * mt * mt * t * midX + 3 * mt * t * t * midX + t * t * t * x1;
          const topY = f.sy0 + (f.ty0 - f.sy0) * (3 * mt * t * t + t * t * t);
          const botY = f.sy1 + (f.ty1 - f.sy1) * (3 * mt * t * t + t * t * t);
          const [wx, wTop] = screenToWorld(bx, topY, W, H);
          const [, wBot] = screenToWorld(bx, botY, W, H);
          const z = 0.42;
          verts.push(wx, wTop, z, wx, wBot, z, wx, wTop, -z, wx, wBot, -z);
          topFront.push(new THREE.Vector3(wx, wTop, z)); botFront.push(new THREE.Vector3(wx, wBot, z));
          topBack.push(new THREE.Vector3(wx, wTop, -z)); botBack.push(new THREE.Vector3(wx, wBot, -z));
          if (i > 0) {
            const c = i * 4, p = (i - 1) * 4;
            idxs.push(p, p + 1, c, p + 1, c + 1, c);
            idxs.push(p + 2, c + 2, p + 3, p + 3, c + 2, c + 3);
            idxs.push(p, c, p + 2, p + 2, c, c + 2);
            idxs.push(p + 1, p + 3, c + 1, p + 3, c + 3, c + 1);
          }
        }
        idxs.push(0, 2, 1, 1, 2, 3);
        const last = SEG * 4;
        idxs.push(last, last + 1, last + 2, last + 1, last + 3, last + 2);
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
        geo.setIndex(idxs);
        geo.computeVertexNormals();
        const mat = glassMat(lay.nodes[f.si].color);
        const mesh = new THREE.Mesh(geo, mat);
        mesh.castShadow = true; mesh.receiveShadow = true;
        group.add(mesh);
        const label = `${lay.nodes[f.si].name} → ${lay.nodes[f.ti].name} · ${Math.round(f.value)}`;
        hitList.push({ mesh, text: label });
        allMeshMats.push({ mesh, mat, baseOpacity: 1.0, kind: 'flow', si: f.si, ti: f.ti });
        svgFlows.push({ topFront, botFront, topBack, botBack, color: lay.nodes[f.si].color, label });
      });

      // auto-frame both camera presets to the built scene (same bounding
      // sphere — only the viewing angle/fov differ between 2D and 3D so
      // node/flow WORLD dimensions are identical either way).
      const box = new THREE.Box3().setFromObject(group);
      const sphere = new THREE.Sphere();
      box.getBoundingSphere(sphere);
      const dist = Math.max(6, sphere.radius * 2.05);
      cam3D.pos.set(sphere.center.x - dist * 0.18, sphere.center.y + dist * 0.55, sphere.center.z + dist * 0.85);
      cam3D.target.copy(sphere.center);
      cam3D.fov = 38;
      cam2D.pos.set(sphere.center.x, sphere.center.y, sphere.center.z + dist * 1.65);
      cam2D.target.copy(sphere.center);
      cam2D.fov = 22;
      camera.near = 0.1; camera.far = dist * 8;

      if (!transitioning) {
        const preset = currentDim === '2d' ? cam2D : cam3D;
        camera.position.copy(preset.pos);
        controls.target.copy(preset.target);
        camera.fov = preset.fov;
        camera.updateProjectionMatrix();
        group.scale.z = currentDim === '2d' ? FLATTEN_Z : 1;
      }
      controls.update();
    }

    // ---- 2D ⇄ 3D morph state: camera + Z-flatten ONLY, geometry untouched ----
    const cam3D = { pos: new THREE.Vector3(), target: new THREE.Vector3(), fov: 38 };
    const cam2D = { pos: new THREE.Vector3(), target: new THREE.Vector3(), fov: 22 };
    let currentDim: '2d' | '3d' = dim;
    let mix = dim === '2d' ? 1 : 0; // 0 = full 3D, 1 = flattened 2D
    let targetMix = mix;
    let transitioning = false;
    const startPos = new THREE.Vector3(), startTarget = new THREE.Vector3();
    let startFov = 38;
    const easeInOutCubic = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

    function setDim(d: '2d' | '3d') {
      if (currentDim === d) return;
      currentDim = d;
      targetMix = d === '2d' ? 1 : 0;
      transitioning = true;
      startPos.copy(camera.position); startTarget.copy(controls.target); startFov = camera.fov;
      controls.enabled = d === '3d';
    }

    function resize() {
      const W = container!.clientWidth || 600, H = container!.clientHeight || 360;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
      rebuild();
    }

    let roTimer = 0;
    const ro = new ResizeObserver(() => {
      clearTimeout(roTimer);
      roTimer = window.setTimeout(resize, 60);
    });
    ro.observe(container);
    resize();
    controls.enabled = dim === '3d';

    let hoveredIdx = -1;

    // Matches the reference mock's setHover()/resetHover(): the hovered mesh
    // pops to opacity 1 + a 2.5% scale bump; anything CONNECTED to it (the
    // flow's own source/target nodes, or a node's incident flows) also stays
    // fully opaque; everything else dims to 0.22.
    function applyHover(idx: number) {
      if (hoveredIdx === idx) return;
      hoveredIdx = idx;
      if (idx < 0) {
        allMeshMats.forEach((rec) => { rec.mat.opacity = rec.baseOpacity; rec.mesh.scale.set(1, 1, 1); });
        return;
      }
      const active = allMeshMats[idx];
      allMeshMats.forEach((rec, i) => {
        if (i === idx) { rec.mat.opacity = 1; rec.mesh.scale.set(1.025, 1.025, 1.025); return; }
        rec.mesh.scale.set(1, 1, 1);
        const connected = active.kind === 'flow'
          ? (rec.kind === 'node' && (rec.nodeIdx === active.si || rec.nodeIdx === active.ti))
          : (rec.kind === 'flow' && (rec.si === active.nodeIdx || rec.ti === active.nodeIdx));
        rec.mat.opacity = connected ? 1 : 0.22;
      });
    }

    function onPointerMove(e: PointerEvent) {
      const rect = container!.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);
      const meshes = hitList.map((h) => h.mesh);
      const hits = raycaster.intersectObjects(meshes, false);
      if (hits.length) {
        const hitObj = hits[0].object as THREE.Mesh;
        const idx = hitList.findIndex((h) => h.mesh === hitObj);
        applyHover(idx);
        setTip({ x: e.clientX - rect.left, y: e.clientY - rect.top, text: hitList[idx]?.text || '' });
        onHover?.(hitList[idx]?.text || null);
        container!.style.cursor = 'pointer';
      } else {
        applyHover(-1);
        setTip(null);
        onHover?.(null);
        container!.style.cursor = currentDim === '3d' ? 'grab' : 'default';
      }
    }
    function onPointerLeave() { applyHover(-1); setTip(null); onHover?.(null); }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);
    renderer.domElement.addEventListener('wheel', (e) => e.preventDefault(), { passive: false });

    let raf = 0;
    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (transitioning) {
        mix += (targetMix - mix) * 0.09;
        if (Math.abs(targetMix - mix) < 0.002) { mix = targetMix; transitioning = false; if (currentDim === '3d') controls.enabled = true; }
        const e = easeInOutCubic(mix);
        const toPreset = targetMix > 0.5 ? cam2D : cam3D;
        camera.position.lerpVectors(startPos, toPreset.pos, e);
        controls.target.lerpVectors(startTarget, toPreset.target, e);
        camera.fov = THREE.MathUtils.lerp(startFov, toPreset.fov, e);
        camera.updateProjectionMatrix();
        group.scale.z = THREE.MathUtils.lerp(1, FLATTEN_Z, mix);
        ambientLight.intensity = THREE.MathUtils.lerp(LIGHT_3D.amb, LIGHT_2D.amb, mix);
        dirLight.intensity = THREE.MathUtils.lerp(LIGHT_3D.dir, LIGHT_2D.dir, mix);
        rim.intensity = THREE.MathUtils.lerp(LIGHT_3D.rim, LIGHT_2D.rim, mix);
        platformMat.opacity = THREE.MathUtils.lerp(1, 0.15, mix);
        dirLight.castShadow = mix < 0.7;
      }
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    };
    animate();

    const dispose = () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      controls.dispose();
      renderer.dispose();
      container!.removeChild(renderer.domElement);
      container!.removeChild(labelRenderer.domElement);
    };

    sceneApi.current = { renderer, labelRenderer, scene, camera, controls, group, hit: hitList, labelRefs, svgGeom: { nodes: svgNodes, flows: svgFlows }, setDim, dispose };
    return () => { sceneApi.current?.dispose(); sceneApi.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [links, palette, dark]);

  useEffect(() => { sceneApi.current?.setDim(dim); }, [dim]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const api = sceneApi.current;
      const container = containerRef.current;
      if (!api || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      let dataUrl = '';
      withExportResolution(api.renderer, () => {
        api.renderer.setSize(W, H, false);
        api.renderer.render(api.scene, api.camera);
        dataUrl = api.renderer.domElement.toDataURL('image/png');
      });
      api.renderer.setSize(W, H, false);
      const labels = captureLabelPositions(container, api.labelRefs);
      const legend = [...new Set((links || []).flatMap((l) => [l.source, l.target]))].map((n, i) => ({ label: n, color: palette[i % palette.length] }));
      const cv = await buildThreePNG({ title, imageDataUrl: dataUrl, chartW: W, chartH: H, labels, legend, theme, footnote: `Sankey · hiring funnel · ${dim === '2d' ? '2D' : '3D'} · Three.js` });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    // True vector SVG export: every node/flow vertex is re-projected through
    // the LIVE camera (camera.project()) instead of embedding a raster
    // <image> — this is the "perfectly working svg export" from the
    // reference mock, ported 1:1. Scales losslessly at any zoom.
    exportSVG: async (title: string) => {
      const api = sceneApi.current;
      const container = containerRef.current;
      if (!api || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      api.group.updateMatrixWorld(true);
      const project = (local: THREE.Vector3): [number, number] => {
        const p = local.clone().applyMatrix4(api.group.matrixWorld);
        p.project(api.camera);
        return [((p.x * 0.5 + 0.5) * W), ((-(p.y * 0.5) + 0.5) * H)];
      };
      const fmt = (pt: [number, number]) => `${pt[0].toFixed(2)},${pt[1].toFixed(2)}`;
      const is3D = dim === '3d';

      let flowsSvg = '';
      api.svgGeom.flows.forEach((f) => {
        const tF = f.topFront.map(project), bF = f.botFront.map(project);
        const tB = f.topBack.map(project), bB = f.botBack.map(project);
        const light = adjustColor(f.color, 16), darkC = adjustColor(f.color, -22);
        if (is3D) {
          const topPath = `M ${tF.map(fmt).join(' L ')} L ${tB.slice().reverse().map(fmt).join(' L ')} Z`;
          flowsSvg += `<path d="${topPath}" fill="${light}" fill-opacity="0.7"/>`;
          const backPath = `M ${tB.map(fmt).join(' L ')} L ${bB.slice().reverse().map(fmt).join(' L ')} Z`;
          flowsSvg += `<path d="${backPath}" fill="${darkC}" fill-opacity="0.55"/>`;
        }
        const frontPath = `M ${tF.map(fmt).join(' L ')} L ${bF.slice().reverse().map(fmt).join(' L ')} Z`;
        flowsSvg += `<path d="${frontPath}" fill="${f.color}" fill-opacity="0.9" stroke="${f.color}" stroke-width="0.5"/>`;
      });

      let nodesSvg = '';
      api.svgGeom.nodes.forEach((n) => {
        const [flt, frt, frb, flb, blt, brt, brb] = n.corners.map(project);
        const light = adjustColor(n.color, 18), darkC = adjustColor(n.color, -18);
        if (is3D) {
          nodesSvg += `<polygon points="${[flt, frt, brt, blt].map(fmt).join(' ')}" fill="${light}"/>`;
          nodesSvg += `<polygon points="${[frt, frb, brb, brt].map(fmt).join(' ')}" fill="${darkC}"/>`;
        }
        nodesSvg += `<polygon points="${[flt, frt, frb, flb].map(fmt).join(' ')}" fill="${n.color}" stroke="${n.color}" stroke-width="0.5"/>`;
      });

      const labels = captureLabelPositions(container, api.labelRefs);
      let labelsSvg = '';
      labels.forEach((l) => {
        labelsSvg += `<text x="${l.x.toFixed(1)}" y="${l.y.toFixed(1)}" text-anchor="middle" class="node-text">${escXml(l.text)}</text>`;
      });

      const legend = [...new Set((links || []).flatMap((l) => [l.source, l.target]))].map((n, i) => ({ label: n, color: palette[i % palette.length] }));
      let legendSvg = ''; let lx = 16; const ly = H - 16;
      legend.forEach((item) => {
        legendSvg += `<rect x="${lx}" y="${ly - 9}" width="14" height="10" rx="4" fill="${item.color}"/>`;
        const tx = lx + 22;
        legendSvg += `<text x="${tx}" y="${ly}" class="legend-text">${escXml(item.label)}</text>`;
        lx = tx + item.label.length * 7.5 + 20;
      });

      return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs><style>
    text { font-family: ${theme.fontBody}; }
    .title-text { font-size: 15px; font-weight: 700; fill: #1c2620; }
    .legend-text { font-size: 10.5px; font-weight: 600; fill: #39443d; dominant-baseline: middle; }
    .node-text { font-size: 11px; font-weight: 700; fill: #111111; paint-order: stroke fill; stroke: #ffffff; stroke-width: 3px; stroke-linejoin: round; dominant-baseline: middle; }
  </style></defs>
  <rect width="100%" height="100%" fill="#ffffff"/>
  <text x="12" y="22" class="title-text">${escXml(title)}</text>
  <g id="sankey-flows">${flowsSvg}</g>
  <g id="sankey-nodes">${nodesSvg}</g>
  <g id="sankey-labels">${labelsSvg}</g>
  <g id="sankey-legend">${legendSvg}</g>
</svg>`;
    },
  }), [links, palette, theme, dim]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full" style={{ cursor: dim === '3d' ? 'grab' : 'default' }}>
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 max-w-[220px] px-2.5 py-1 font-body text-[11px] font-bold text-ink"
          style={{ left: Math.min(tip.x + 12, (containerRef.current?.clientWidth || 300) - 190), top: Math.max(0, tip.y - 34) }}>
          {tip.text}
        </div>
      )}
      {!tip && dim === '3d' && (
        <div className="pointer-events-none absolute bottom-1.5 right-2 z-10 rounded-full bg-ink/55 px-2.5 py-0.5 font-body text-[10px] font-semibold text-white/90 backdrop-blur-sm">
          Drag to orbit · scroll to zoom
        </div>
      )}
    </div>
  );
});

export default ThreeSankey3D;
