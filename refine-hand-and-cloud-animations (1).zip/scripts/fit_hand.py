"""Fit the supplied skeleton to manually traced reference landmarks.

Landmarks are estimates from the supplied illustration, not an exact image match.
The source mesh and all of its skinning weights remain unchanged.
"""
import json
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

data = json.loads(Path('artifacts/baseline-rig.json').read_text())
joints = np.array(data['HD']['JP']).reshape(-1, 3)
rim = np.array(data['RC'])
chains = [[20, 21, 22, 23, 24], [15, 16, 17, 18, 19],
          [10, 11, 12, 13, 14], [5, 6, 7, 8, 9]]
targets = {
    21: [1270, 94], 22: [1213, 110], 23: [1167, 153], 24: [1140, 185],
    16: [1304, 130], 17: [1244, 195], 18: [1207, 265], 19: [1190, 298],
    11: [1341, 116], 12: [1280, 207], 13: [1246, 286], 14: [1232, 324],
    6: [1381, 77], 7: [1323, 128], 8: [1301, 177], 9: [1295, 203],
    1: [1495, 174], 2: [1471, 210], 3: [1434, 260], 4: [1421, 287],
}


def rotation(axis, angle):
    return Rotation.from_rotvec(np.array(axis) * angle).as_matrix()


def pivot(point, axis, angle):
    matrix = np.eye(4)
    matrix[:3, :3] = rotation(axis, angle)
    matrix[:3, 3] = point - matrix[:3, :3] @ point
    return matrix


initial = np.array([
    .951, -.278, -2.2, 2810, 1, 1508, 163,
    .386, .297, 1.037, 0, 0,
    -.6, 1.554, .022, .113, 0,
    -.106, 1.6, .515, 0, 0,
    .476, 0, 0, 0, 0,
    -.241, -.575, 1., -1.5, -.085,
])
if Path('artifacts/fitted-pose.json').exists():
    initial = np.array(json.loads(Path('artifacts/fitted-pose.json').read_text()))

positions = np.array(data['HD']['pos']).reshape(-1, 3)
joint_ids = np.array(data['HD']['jid']).reshape(-1, 4)
weights = np.array(data['HD']['wt']).reshape(-1, 4) / 255
surface_targets = [[1136, 190], [1188, 307], [1230, 330], [1294, 224], [1423, 295]]
surface_vertices = []
for distal, tip in [(23, 24), (18, 19), (13, 14), (8, 9), (3, 4)]:
    membership = np.sum(weights * ((joint_ids == distal) | (joint_ids == tip)), axis=1)
    candidates = np.where(membership > .5)[0]
    direction = joints[tip] - joints[distal]
    along = positions[candidates] @ direction
    surface_vertices.append(candidates[np.argsort(along)[-8:]])


def surface_points(params, matrices, global_rotation):
    result = []
    for candidates in surface_vertices:
        posed = np.zeros((len(candidates), 3))
        for index, vertex in enumerate(candidates):
            for slot in range(4):
                posed[index] += weights[vertex, slot] * (matrices[joint_ids[vertex, slot]] @ np.r_[positions[vertex], 1])[:3]
        point = global_rotation @ (posed.mean(axis=0) - rim) * params[3]
        result.append([params[5] + point[0], params[6] - point[1] * params[4]])
    return np.array(result)


def project(params, return_matrices=False):
    rz, ry, rx, scale, stretch, wx, wy = params[:7]
    global_rotation = rotation([0, 0, 1], rz) @ rotation([0, 1, 0], ry) @ rotation([1, 0, 0], rx)
    matrices = [np.eye(4) for _ in range(25)]
    for i, (meta, p, q, d, tip) in enumerate(chains):
        spread, a, b, c, meta_angle = params[7 + i * 5:12 + i * 5]
        matrices[meta] = pivot(joints[meta], [0, 0, 1], meta_angle)
        axis = rotation([1, 0, 0], spread) @ np.array([0, 0, 1])
        matrices[p] = matrices[meta] @ pivot(joints[p], axis, -a) @ pivot(joints[p], [1, 0, 0], spread)
        matrices[q] = matrices[p] @ pivot(joints[q], [0, 0, 1], -b)
        matrices[d] = matrices[q] @ pivot(joints[d], [0, 0, 1], -c)
        matrices[tip] = matrices[d]
    a, b, c, d, e = params[-5:]
    matrices[1] = pivot(joints[1], [0, 0, 1], c) @ pivot(joints[1], [1, 0, 0], b) @ pivot(joints[1], [0, 1, 0], a)
    matrices[2] = matrices[1] @ pivot(joints[2], [0, 0, 1], d)
    matrices[3] = matrices[2] @ pivot(joints[3], [0, 0, 1], e)
    matrices[4] = matrices[3]
    projected = []
    for index, joint in enumerate(joints):
        posed = (matrices[index] @ np.r_[joint, 1])[:3]
        result = global_rotation @ (posed - rim) * scale
        projected.append([wx + result[0], wy - result[1] * stretch, 34 + result[2]])
    if return_matrices:
        return np.array(projected), matrices, global_rotation
    return np.array(projected)


def residual(params):
    points, matrices, global_rotation = project(params, True)
    errors = []
    for index, target in targets.items():
        weight = .15 if index in [4, 9, 14, 19, 24] else .65
        errors.extend((points[index, :2] - target) * weight)
    errors.extend(((surface_points(params, matrices, global_rotation) - surface_targets) * 3).ravel())
    # Prefer small metacarpal adjustments and a believable range of flexion.
    errors.extend(params[[11, 16, 21, 26]] * 18)
    errors.extend((params[:3] - initial[:3]) * 5)
    errors.append((params[3] - 2810) * .02)
    errors.append((params[4] - 1) * 30)
    errors.extend((params[5:7] - [1520, 166]) * .4)
    for i in range(4):
        errors.append(params[7 + i * 5] * 7)
    return np.array(errors)


lower = [-1, -1.4, -3.4, 2400, .94, 1480, 125]
upper = [2.5, 1.4, -.2, 3400, 1.12, 1560, 215]
for _ in chains:
    lower.extend([-1.3, -.2, -.1, -.1, -.45])
    upper.extend([1.3, 1.9, 1.8, 1.2, .45])
lower.extend([-1.8, -1.8, -1.4, -2.0, -1.5])
upper.extend([1.8, 1.8, 2.2, .3, 1.2])

initial = np.clip(initial, np.array(lower) + .00001, np.array(upper) - .00001)
fit = least_squares(residual, initial, bounds=(lower, upper), max_nfev=1200, ftol=1e-10, xtol=1e-10)
points = project(fit.x)
print('Parameters:', np.round(fit.x, 5).tolist())
_, matrices, global_rotation = project(fit.x, True)
print('Surface tips:', np.round(surface_points(fit.x, matrices, global_rotation), 1).tolist())
for index, target in targets.items():
    print(index, 'target', target, 'fitted', np.round(points[index], 1).tolist())
Path('artifacts/fitted-pose.json').write_text(json.dumps(fit.x.tolist()))