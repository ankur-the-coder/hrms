import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const browser = await chromium.launch({
  headless: true,
  args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
const base = process.env.TEST_URL || 'http://localhost:5173';

try {
  fs.mkdirSync('public/assets', { recursive: true });
  await page.goto(`${base}/scene.html?t=0&q=70`);
  await page.waitForFunction(() => Boolean(window.PuppetStudy));
  await page.waitForTimeout(2000);
  await page.screenshot({ path: 'public/assets/refined-render.jpg', type: 'jpeg', quality: 94 });
  await page.screenshot({ path: 'artifacts/final-render.png' });
  await page.screenshot({ path: 'artifacts/final-hand.png', clip: { x: 1080, y: 15, width: 600, height: 400 } });
  const cloudStart = await page.evaluate(() => window.__study.clouds.map(cloud => cloud.position.x));
  await page.evaluate(() => window.PuppetStudy.set({ time: 4 }));
  await page.waitForTimeout(250);
  const cloudMoved = await page.evaluate(() => window.__study.clouds.map(cloud => cloud.position.x));
  assert(cloudMoved.every((x, i) => Math.abs((x - cloudStart[i]) - 1.52) < .03), 'Clouds drift left to right.');
  await page.evaluate(() => window.PuppetStudy.set({ time: 8 }));
  await page.waitForTimeout(250);
  await page.screenshot({ path: 'artifacts/final-cloud-loop.png' });
  const cloudLoop = await page.evaluate(() => window.__study.clouds.map(cloud => cloud.position.x));
  assert(cloudLoop.some(x => x < 0 && x > -.8), 'A new cloud re-enters from the left edge.');
  await page.evaluate(() => window.PuppetStudy.set({ time: 0 }));
  await page.waitForTimeout(120);
  fs.writeFileSync('artifacts/final-vertices.json', JSON.stringify(await page.evaluate(() => Array.from(window.__study.hPos))));
  const rig = await page.evaluate(() => {
    const study = window.__study;
    const bindings = JSON.stringify(study.stringBindings);
    const samples = [], targets = [];
    if (study.stringBindings.length !== 5 || new Set(study.stringBindings.map(binding => binding.finger)).size !== 5) {
      throw new Error('Each finger must keep one unique string binding.');
    }
    const expectedTips = [[1136, 190], [1294, 224], [1188, 308], [1230, 330], [1423, 295]];
    let maxTipError = 0, stringCrossings = 0;
    const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
    const intersects = (a, b, c, d) => {
      const ab1 = cross(a, b, c), ab2 = cross(a, b, d), cd1 = cross(c, d, a), cd2 = cross(c, d, b);
      return ab1 * ab2 < 0 && cd1 * cd2 < 0;
    };
    for (let i = 0; i < 480; i++) {
      const t = i / 120, { ph, H } = study.pose(t);
      study.poseHand(t, ph, H - 1.16);
      samples.push(study.tips.map(point => [...point]));
      if (i === 0) study.tips.forEach((point, j) => {
        maxTipError = Math.max(maxTipError, Math.hypot(point[0] - expectedTips[j][0], point[1] - expectedTips[j][1]));
      });
      study.root.updateMatrixWorld(true);
      targets.push(study.stringBindings.map(binding => study.toDesign(study.anc[binding.target])));
      if (JSON.stringify(study.stringBindings) !== bindings) throw new Error('A string changed identity.');
      if (i % 12 === 0) {
        const paths = study.stringBindings.map((binding, index) => {
          const tip = study.tips[binding.finger], start = [tip[0] + binding.offset, tip[1] + 2], end = study.toDesign(study.anc[binding.target]);
          const dx = end[0] - start[0], dy = end[1] - start[1], length = Math.hypot(dx, dy) || 1;
          const nx = -dy / length, ny = dx / length, cx = start[0] + dx * .48, cy = start[1] + dy * .52;
          return Array.from({ length: 25 }, (_, j) => {
            const u = j / 24, offset = 2.5 * Math.sin(Math.PI * u) * (Math.sin(t * .9 + index * .7) * .7 + Math.sin(t * 1.35 + index) * .3);
            const a = (1 - u) ** 2, b = 2 * u * (1 - u), c = u * u;
            return [a * start[0] + b * cx + c * end[0] + nx * offset, a * start[1] + b * cy + c * end[1] + ny * offset];
          });
        });
        for (let a = 0; a < paths.length; a++) for (let b = a + 1; b < paths.length; b++) {
          let crossed = false;
          for (let j = 1; j < paths[a].length && !crossed; j++) for (let k = 1; k < paths[b].length; k++) {
            if (intersects(paths[a][j - 1], paths[a][j], paths[b][k - 1], paths[b][k])) { crossed = true; break; }
          }
          if (crossed) stringCrossings++;
        }
      }
    }
    let maxStep = 0, maxTargetStep = 0;
    for (let i = 1; i < samples.length; i++) {
      for (let j = 0; j < 5; j++) {
        maxStep = Math.max(maxStep, Math.hypot(samples[i][j][0] - samples[i - 1][j][0], samples[i][j][1] - samples[i - 1][j][1]));
      }
      for (let j = 0; j < study.stringBindings.length; j++) maxTargetStep = Math.max(maxTargetStep, Math.hypot(targets[i][j][0] - targets[i - 1][j][0], targets[i][j][1] - targets[i - 1][j][1]));
    }
    return { maxStep, maxTargetStep, maxTipError, stringCrossings, bindings: study.stringBindings, meshVertices: study.HD.nV, facing: study.root.rotation.y };
  });
  assert(rig.maxStep < 1, 'Finger movement must be continuous at 120 Hz.');
  assert(rig.maxTargetStep < 4, 'String endpoints must remain continuous across the gait cycle.');
  assert(rig.maxTipError < 2, 'Fingernail tips stay aligned to the traced reference landmarks.');
  assert.equal(rig.stringCrossings, 0, 'String paths stay visually separated throughout the cycle.');
  fs.writeFileSync('artifacts/rig-verification.json', JSON.stringify(rig, null, 2));

  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto(base);
  await page.locator('.stage.is-ready').waitFor({ timeout: 25000 });
  await page.waitForTimeout(2200);
  const scene = page.frames().find(frame => frame.url().includes('/scene.html'));
  assert(scene, 'Embedded original-derived scene is available.');
  const getState = () => scene.evaluate(() => window.PuppetStudy.state());
  await page.screenshot({ path: 'artifacts/desktop-viewer.png' });

  await page.getByRole('button', { name: 'Pause animation', exact: true }).click();
  await page.waitForTimeout(250);
  const paused = await getState();
  await page.waitForTimeout(400);
  assert.equal((await getState()).time, paused.time, 'Pause freezes the animation clock.');
  await page.getByLabel('Playback speed').selectOption('0.25');
  assert.equal((await getState()).speed, .25);
  await page.getByRole('button', { name: 'Hand detail', exact: true }).click();
  await page.waitForTimeout(1000);
  assert.equal((await getState()).view, 'hand');
  await page.screenshot({ path: 'artifacts/viewer-hand-detail.png' });
  await page.getByRole('button', { name: 'Zoom in', exact: true }).click();
  assert.equal(await page.locator('.zoom-value').textContent(), '125%');
  await page.getByTitle('Reset zoom', { exact: true }).click();
  await page.getByRole('button', { name: 'High quality', exact: true }).click();
  await page.getByRole('button', { name: 'Balanced', exact: true }).click();
  assert.equal((await getState()).quality, 50);
  await page.keyboard.press('Escape');

  const downloaded = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Save frame as PNG' }).click();
  const download = await downloaded;
  assert(download.suggestedFilename().endsWith('.png'));
  await download.saveAs('artifacts/exported-frame.png');

  await page.getByRole('button', { name: 'Compare', exact: true }).click();
  await page.getByRole('dialog').waitFor();
  assert.equal(await page.locator('.comparison-image').evaluateAll(images => images.every(image => image.complete && image.naturalWidth > 0)), true);
  const slider = page.getByRole('slider', { name: 'Slide to compare original and refined artwork' });
  await slider.focus(); await page.keyboard.press('ArrowRight');
  assert(Number(await slider.inputValue()) > 50);
  await page.screenshot({ path: 'artifacts/compare-hand.png' });
  await page.locator('input[type=file]').setInputFiles('public/assets/original-render.jpg');
  await page.getByText('Your image stays on this device.').waitFor();
  await page.getByRole('button', { name: 'Reset', exact: true }).click();
  await page.keyboard.press('Escape');
  assert.equal((await getState()).playing, false, 'Closing comparison preserves the paused state.');

  await page.getByRole('button', { name: 'Full composition', exact: true }).click();
  await page.keyboard.press('h');
  assert(await page.locator('.app.is-immersive').count());
  await page.getByRole('button', { name: /Show controls/ }).click();
  await page.getByRole('button', { name: 'About the study', exact: true }).click();
  assert(await page.getByText('Small gestures.').count());
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Keyboard shortcuts', exact: true }).click();
  assert.equal(await page.locator('.shortcut-list > div').count(), 8);
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Enter fullscreen', exact: true }).click();
  await page.waitForFunction(() => Boolean(document.fullscreenElement) || Boolean(document.querySelector('.is-immersive')));
  if (await page.evaluate(() => Boolean(document.fullscreenElement))) {
    await page.getByRole('button', { name: 'Exit fullscreen', exact: true }).click();
    await page.waitForFunction(() => !document.fullscreenElement);
  } else {
    await page.getByRole('button', { name: /Show controls/ }).click();
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(1200);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true, 'No mobile horizontal overflow.');
  await page.screenshot({ path: 'artifacts/mobile-viewer.png' });
  await page.getByRole('button', { name: 'Hand detail', exact: true }).click();
  await page.waitForTimeout(700);
  await page.screenshot({ path: 'artifacts/mobile-hand-detail.png' });

  assert.deepEqual(errors, [], 'No browser runtime errors.');
  console.log(JSON.stringify({ status: 'passed', tests: ['reference fingertip alignment', 'rig continuity', 'non-crossing strings', 'cloud drift and re-entry', 'pause', 'speed', 'camera views', 'zoom', 'quality', 'PNG export', 'comparison slider', 'reference upload', 'modal state restoration', 'immersive mode', 'about', 'keyboard shortcuts', 'fullscreen', 'mobile overflow'], maxFingertipStep: rig.maxStep, maxTipError: rig.maxTipError, stringCrossings: rig.stringCrossings, errors }, null, 2));
} finally {
  await browser.close();
}