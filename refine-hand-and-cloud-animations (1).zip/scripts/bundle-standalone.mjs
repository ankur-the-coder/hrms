import fs from 'node:fs';

const vendor = fs.readFileSync('public/vendor/three-r128.min.js', 'utf8');
const engine = fs.readFileSync('public/scene.js', 'utf8');
const html = `<!doctype html>
<!-- Refined from https://github.com/ankur-the-coder/hrms/blob/main/puppet_employee_glb_hand.html
     The supplied mesh, Three.js r128 renderer, and engraving materials are preserved.
     Reference matching is approximate. This file works offline without external assets. -->
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>The Puppet Employee | Refined Study</title><style>
:root{color-scheme:dark}html,body{margin:0;height:100%;overflow:hidden;background:#08445f;font-family:Georgia,serif;color:#f1e3c4}
#view{position:fixed;inset:0;width:100%;height:100%;display:block}#ui{position:fixed;bottom:20px;left:20px;width:245px;background:#082f44dc;border:1px solid #f1e3c44a;padding:17px;backdrop-filter:blur(8px);font-size:12px;transition:opacity .3s}
#ui.off{opacity:0;pointer-events:none}.row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}#q{width:100%;accent-color:#d87948;margin:0 0 12px}button{cursor:pointer;color:inherit;background:transparent;border:1px solid #f1e3c448;padding:7px 10px;font:inherit}button:hover{background:#f1e3c41a}#info{font-size:10px;opacity:.65}small{display:block;font-size:10px;opacity:.5;margin-top:8px}button:focus-visible,input:focus-visible{outline:2px solid #ed9a65;outline-offset:3px}
</style></head><body><canvas id="view" aria-label="The Puppet Employee, an engraved hand and a walking marionette"></canvas>
<div id="ui" role="group" aria-label="Animation controls"><div class="row"><span>The Puppet Employee</span><span>01</span></div><div class="row"><button id="play">Pause</button><button id="detail">Hand detail</button><button id="reset" aria-label="Restart">Reset</button></div><div class="row"><label for="q">Render quality</label><b id="qv">72</b></div><input id="q" type="range" min="20" max="100" value="72"><div id="info"></div><small>Space to pause. H to hide or show controls.</small></div>
<script>${vendor}</script><script>${engine}</script><script>
const play=document.getElementById('play'),detail=document.getElementById('detail');
play.textContent=PuppetStudy.state().playing?'Pause':'Play';
const toggle=()=>{const state=PuppetStudy.state();PuppetStudy.set({playing:!state.playing});play.textContent=state.playing?'Play':'Pause';};
play.addEventListener('click',toggle);detail.addEventListener('click',()=>{const close=PuppetStudy.state().view==='hand';PuppetStudy.set({view:close?'composition':'hand'});detail.textContent=close?'Hand detail':'Full scene';});
document.getElementById('reset').addEventListener('click',()=>PuppetStudy.set({time:0}));
addEventListener('keydown',e=>{if(e.code==='Space'&&!/INPUT|BUTTON/.test(e.target.tagName)){e.preventDefault();toggle();}});
</script></body></html>`;
fs.writeFileSync('public/puppet_employee_refined.html', html);
console.log('Bundled public/puppet_employee_refined.html with no external runtime dependencies.');