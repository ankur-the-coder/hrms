"""Apply fitted rig parameters without touching the embedded source mesh."""
import json
import re
from pathlib import Path

params = json.loads(Path('artifacts/fitted-pose.json').read_text())
path = Path('public/scene.js')
source = path.read_text()
source = re.sub(r'const WRIST=\{x:[^}]+\};', f'const WRIST={{x:{params[5]:.7f},y:{params[6]:.7f}}};', source)
source = re.sub(r'const S=[^,]+,POSE=\{z0:34,stretch:[^}]+\};', f'const S={params[3]:.7f},POSE={{z0:34,stretch:{params[4]:.7f}}};', source)
source = re.sub(r'const Rg=RZ\([^;]+;', f'const Rg=RZ({params[0]:.7f}).multiply(RY({params[1]:.7f})).multiply(RX({params[2]:.7f}));', source)
chains = [[20, 21, 22, 23, 24], [15, 16, 17, 18, 19], [10, 11, 12, 13, 14], [5, 6, 7, 8, 9]]
fingers = []
for i, chain in enumerate(chains):
    spread, a, b, c, meta = params[7 + i * 5:12 + i * 5]
    fingers.append('{j:' + json.dumps(chain, separators=(',', ':')) + f',f:[{a:.7f},{b:.7f},{c:.7f}],sp:{spread:.7f},meta:{meta:.7f}' + '}')
source = re.sub(r'const FINGERS=\[.*?\];', 'const FINGERS=[\n  ' + ',\n  '.join(fingers) + '];', source, flags=re.S)
a, b, c, d, e = params[-5:]
start = source.index('  { /*', source.index('function poseHand'))
end = source.index('  /* --- skin:', start)
source = source[:start] + f'''  {{ /* Thumb opposition, then MCP and IP flexion. */
    pivRot(JPv(1),V3(0,1,0),{a:.7f},_m);const a=_m.clone();pivRot(JPv(1),AX,{b:.7f},_m);a.premultiply(_m);pivRot(JPv(1),AZ,{c:.7f},_m);Mj[1].copy(_m).multiply(a);
    pivRot(JPv(2),AZ,{d:.7f}+Math.sin(t*.9)*.012,_m);Mj[2].copy(Mj[1]).multiply(_m);
    pivRot(JPv(3),AZ,{e:.7f}+Math.sin(t*1.2)*.009,_m);Mj[3].copy(Mj[2]).multiply(_m);Mj[4].copy(Mj[3])}}
''' + source[end:]
path.write_text(source)
print('Applied the fitted pose; hand mesh and skinning weights are unchanged.')