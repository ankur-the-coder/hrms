import { useCallback, useEffect, useRef, useState } from 'react';
import type { CSSProperties, ReactNode } from 'react';
import { ArrowDownToLine, ArrowLeft, ArrowLeftRight, ArrowUpRight, Check, ChevronDown, Expand, Focus, ImagePlus, Keyboard, Maximize2, Minus, Pause, Play, Plus, RotateCcw, SlidersHorizontal, SplitSquareHorizontal, X } from 'lucide-react';

type View = 'composition' | 'hand';
type Modal = 'about' | 'compare' | 'shortcuts' | null;
type SceneOptions = { playing?: boolean; speed?: number; time?: number; quality?: number; view?: View; zoom?: number };
type SceneState = { playing: boolean; time: number; speed: number; quality: number; fps: number; width: number; height: number; view: View };
type SceneWindow = Window & { PuppetStudy?: { set: (options: SceneOptions) => void; snapshot: () => string; state: () => SceneState } };
const CYCLE = 11.2;
const sourceUrl = 'https://github.com/ankur-the-coder/hrms/blob/main/puppet_employee_glb_hand.html';

function Mark() {
  return <svg width="30" height="34" viewBox="0 0 30 34" fill="none" aria-hidden="true">
    <path d="M3 7 15 2l12 5M3 7l12 5 12-5M15 2v10M5 8v15m10-11v17M25 8v15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="5" cy="26" r="2.5" fill="currentColor" /><circle cx="15" cy="31" r="2.5" fill="currentColor" /><circle cx="25" cy="26" r="2.5" fill="currentColor" />
  </svg>;
}

function Dialog({ children, onClose, label, wide = false }: { children: ReactNode; onClose: () => void; label: string; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const element = ref.current;
    element?.querySelector<HTMLElement>('button')?.focus();
    function trap(event: KeyboardEvent) {
      if (event.key !== 'Tab' || !element) return;
      const items = [...element.querySelectorAll<HTMLElement>('button:not(:disabled), a, input, select, [tabindex="0"]')];
      const first = items[0], last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
    document.addEventListener('keydown', trap);
    return () => { document.removeEventListener('keydown', trap); previous?.focus(); };
  }, []);
  return <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <div className={`dialog ${wide ? 'dialog-wide' : ''}`} ref={ref} role="dialog" aria-modal="true" aria-label={label}>
      <button className="icon-button close-dialog" onClick={onClose} aria-label="Close dialog"><X size={20} /></button>{children}
    </div>
  </div>;
}

export default function App() {
  const frame = useRef<HTMLIFrameElement>(null);
  const qualityPanel = useRef<HTMLDivElement>(null);
  const referenceInput = useRef<HTMLInputElement>(null);
  const resumeAfterModal = useRef(true);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');
  const [reloadKey, setReloadKey] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(.65);
  const [time, setTime] = useState(0);
  const [quality, setQuality] = useState(72);
  const [view, setView] = useState<View>('composition');
  const [zoom, setZoom] = useState(1);
  const [stats, setStats] = useState({ fps: 0, width: 0, height: 0 });
  const [modal, setModal] = useState<Modal>(null);
  const [qualityOpen, setQualityOpen] = useState(false);
  const [immersive, setImmersive] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [toast, setToast] = useState('');
  const [comparePosition, setComparePosition] = useState(50);
  const [compareHand, setCompareHand] = useState(true);
  const [reference, setReference] = useState('');
  const [referenceName, setReferenceName] = useState('');
  const api = useCallback(() => (frame.current?.contentWindow as SceneWindow | null)?.PuppetStudy, []);
  const setScene = useCallback((options: SceneOptions) => api()?.set(options), [api]);
  const notify = useCallback((text: string) => {
    setToast(text);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3400);
  }, []);

  useEffect(() => {
    function receive(event: MessageEvent) {
      if (event.origin !== location.origin || event.source !== frame.current?.contentWindow) return;
      const data = event.data;
      if (data.type === 'puppet:ready') { setReady(true); setError(''); setPlaying(data.playing); }
      if (data.type === 'puppet:stats') { setTime(data.time); setStats({ fps: data.fps, width: data.width, height: data.height }); }
      if (data.type === 'puppet:state') { setPlaying(data.playing); setTime(data.time); }
      if (data.type === 'puppet:error') setError(data.message);
    }
    window.addEventListener('message', receive);
    const onFullscreen = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFullscreen);
    return () => { window.removeEventListener('message', receive); document.removeEventListener('fullscreenchange', onFullscreen); };
  }, []);
  useEffect(() => {
    if (ready) return;
    const timer = setTimeout(() => {
      if (api()) { setReady(true); setPlaying(api()!.state().playing); }
      else setError('This study needs a browser with WebGL. Please enable hardware acceleration and try again.');
    }, 18000);
    return () => clearTimeout(timer);
  }, [ready, reloadKey, api]);
  useEffect(() => {
    if (!qualityOpen) return;
    const close = (event: MouseEvent) => { if (!qualityPanel.current?.contains(event.target as Node)) setQualityOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [qualityOpen]);
  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);
  useEffect(() => () => { if (reference) URL.revokeObjectURL(reference); }, [reference]);

  const togglePlaying = useCallback(() => { const next = !playing; setPlaying(next); setScene({ playing: next }); }, [playing, setScene]);
  const restart = useCallback(() => { setScene({ time: 0 }); setTime(0); notify('Back to the first gesture.'); }, [setScene, notify]);
  const changeView = useCallback((next: View) => { setView(next); setZoom(1); setScene({ view: next, zoom: 1 }); }, [setScene]);
  const closeModal = useCallback(() => { setModal(null); setScene({ playing: resumeAfterModal.current }); setPlaying(resumeAfterModal.current); }, [setScene]);
  const openModal = useCallback((next: Modal) => {
    resumeAfterModal.current = playing;
    setModal(next); setQualityOpen(false); setScene({ playing: false }); setPlaying(false);
  }, [playing, setScene]);
  const toggleFullscreen = useCallback(async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
      else setImmersive(value => !value);
    } catch { setImmersive(value => !value); }
  }, []);
  useEffect(() => {
    function shortcuts(event: KeyboardEvent) {
      const target = event.target as HTMLElement;
      if (event.key === 'Escape') {
        if (modal) closeModal(); else if (qualityOpen) setQualityOpen(false); else setImmersive(false);
        return;
      }
      if (/INPUT|SELECT|TEXTAREA/.test(target.tagName) || target.isContentEditable || modal || event.repeat) return;
      switch (event.key.toLowerCase()) {
        case ' ': event.preventDefault(); togglePlaying(); break;
        case 'h': setImmersive(value => !value); break;
        case 'f': void toggleFullscreen(); break;
        case 'r': restart(); break;
        case '1': changeView('composition'); break;
        case '2': changeView('hand'); break;
        case 'c': openModal('compare'); break;
        case '?': openModal('shortcuts'); break;
      }
    }
    window.addEventListener('keydown', shortcuts);
    return () => window.removeEventListener('keydown', shortcuts);
  }, [modal, qualityOpen, togglePlaying, closeModal, restart, changeView, openModal, toggleFullscreen]);

  const capture = () => {
    try {
      const image = api()?.snapshot();
      if (!image) return;
      const anchor = document.createElement('a');
      anchor.download = `the-puppet-employee-${view}-${time.toFixed(2)}.png`; anchor.href = image; anchor.click();
      notify('A little piece of motion, saved as a PNG.');
    } catch { notify('Unable to save this frame. Please try again.'); }
  };
  const uploadReference = (file?: File) => {
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) { notify('Please choose a PNG, JPEG, or WebP image.'); return; }
    if (file.size > 20 * 1024 * 1024) { notify('Please choose an image smaller than 20 MB.'); return; }
    const url = URL.createObjectURL(file), image = new Image();
    image.onload = () => { setReference(url); setReferenceName(file.name); setComparePosition(50); };
    image.onerror = () => { URL.revokeObjectURL(url); notify('That image could not be opened. Please try another.'); };
    image.src = url;
  };
  const changeQuality = (value: number) => { setQuality(value); setScene({ quality: value }); };
  const changeZoom = (value: number) => { const next = Math.min(2.5, Math.max(1, value)); setZoom(next); setScene({ zoom: next }); };
  const qualityLabel = quality >= 90 ? 'Ultra' : quality >= 65 ? 'High' : 'Balanced';
  const clock = `${Math.floor(time / 60).toString().padStart(2, '0')}:${Math.floor(time % 60).toString().padStart(2, '0')}`;

  return <div className={`app ${immersive ? 'is-immersive' : ''}`}>
    <header className="masthead">
      <button className="wordmark" onClick={() => { changeView('composition'); setImmersive(false); }} aria-label="Motion Studies, return to full composition"><Mark /><span>MOTION<br />STUDIES<span className="wordmark-period">.</span></span></button>
      <nav className="main-nav" aria-label="Main navigation"><button className="nav-link active" onClick={() => changeView('composition')}>The experience</button><button className="nav-link" onClick={() => openModal('compare')}><SplitSquareHorizontal size={14} /> Compare</button></nav>
      <button className="about-link" onClick={() => openModal('about')}>About the study <ArrowUpRight size={16} /></button>
    </header>
    <main className={`stage ${ready ? 'is-ready' : ''} ${view === 'hand' ? 'is-detail' : ''}`} aria-label="Interactive animation">
      <iframe key={reloadKey} ref={frame} className="scene-frame" title="The Puppet Employee, real-time animated scene" src="/scene.html" tabIndex={-1} />
      {!ready && !error && <div className="loading-scene" role="status"><Mark /><span>Bringing the study to life<span className="loading-dots">...</span></span></div>}
      {error && <div className="scene-error" role="alert"><p>A moment of stillness.</p><span>{error}</span><button onClick={() => { setError(''); setReady(false); setReloadKey(value => value + 1); }}><RotateCcw size={15} /> Reload the scene</button></div>}
      <div className="editorial" aria-hidden={view === 'hand' || immersive}>
        <div className="eyebrow"><span /> AN EXPLORATION IN MOTION <span className="study-number">NO. 001</span></div>
        <h1>The Puppet<br /><em>Employee.</em></h1>
        <p>A study of invisible strings.<br />And the gestures that move us.</p>
        <button className="inspect-button" onClick={() => changeView('hand')} tabIndex={view === 'hand' || immersive ? -1 : 0} disabled={!ready}><Focus size={17} /> Take a closer look <ArrowUpRight size={16} /></button>
      </div>
      {view === 'hand' && !immersive && <button className="back-to-scene" onClick={() => changeView('composition')}><ArrowLeft size={15} /> Back to the composition</button>}
      {!immersive && <div className="scene-bottomline"><span>{view === 'hand' ? 'THE HAND / A CLOSER STUDY' : 'A LITTLE MOVEMENT. A BIGGER STORY.'}</span><button onClick={() => setImmersive(true)} title="Hide the interface (H)"><Expand size={15} /> <span>Just the artwork</span></button></div>}
      {!immersive && view === 'hand' && <div className="zoom-controls" aria-label="Hand magnification"><button onClick={() => changeZoom(zoom - .25)} disabled={zoom <= 1} aria-label="Zoom out"><Minus size={16} /></button><button className="zoom-value" onClick={() => changeZoom(1)} title="Reset zoom">{Math.round(zoom * 100)}%</button><button onClick={() => changeZoom(zoom + .25)} disabled={zoom >= 2.5} aria-label="Zoom in"><Plus size={16} /></button></div>}
      {immersive && <button className="restore-interface" onClick={() => setImmersive(false)}><SlidersHorizontal size={16} /> Show controls <kbd>H</kbd></button>}
      {!immersive && <input className="timeline" type="range" aria-label="Animation position" min="0" max={CYCLE} step="0.01" value={time % CYCLE} onChange={event => { const value = +event.target.value; setTime(value); setScene({ time: value }); }} style={{ '--progress': `${time % CYCLE / CYCLE * 100}%` } as CSSProperties} />}
    </main>
    <footer className="viewer-footer">
      <div className="transport-bar">
        <div className="playback-controls"><button className="play-button" onClick={togglePlaying} disabled={!ready} aria-label={playing ? 'Pause animation' : 'Play animation'} title={playing ? 'Pause (Space)' : 'Play (Space)'}>{playing ? <Pause size={15} fill="currentColor" strokeWidth={1.5} /> : <Play size={15} fill="currentColor" strokeWidth={1.5} />}</button><div className="playback-status"><span>{playing ? 'In motion' : 'A moment, held'}</span><span className="time-code">{clock} <span>/ CONTINUOUS</span></span></div><button className="icon-button restart-button" onClick={restart} disabled={!ready} title="Restart (R)" aria-label="Restart animation"><RotateCcw size={17} /></button><div className="control-divider" /><label className="speed-control"><select value={speed} onChange={event => { const value = +event.target.value; setSpeed(value); setScene({ speed: value }); }} aria-label="Playback speed"><option value={.25}>0.25x</option><option value={.5}>0.5x</option><option value={.65}>0.65x</option><option value={1}>1x</option><option value={1.5}>1.5x</option></select><ChevronDown size={12} /></label></div>
        <div className="view-tabs" role="group" aria-label="Camera view"><button className={view === 'composition' ? 'selected' : ''} aria-pressed={view === 'composition'} onClick={() => changeView('composition')}>Full composition</button><button className={view === 'hand' ? 'selected' : ''} aria-pressed={view === 'hand'} onClick={() => changeView('hand')}><Focus size={14} /> Hand detail</button></div>
        <div className="render-controls"><div className="quality-anchor" ref={qualityPanel}><button className={`quality-trigger ${qualityOpen ? 'is-open' : ''}`} onClick={() => setQualityOpen(value => !value)} aria-expanded={qualityOpen} aria-controls="quality-panel"><span className="quality-bars" aria-hidden="true"><i /><i /><i /><i className={quality < 90 ? 'muted-bar' : ''} /></span><span>{qualityLabel} quality</span><ChevronDown size={12} /></button>
          {qualityOpen && <div className="quality-panel" id="quality-panel" role="group" aria-label="Render quality"><div className="popover-heading"><span>Make every detail count.</span><span>{quality}<small> / 100</small></span></div><input type="range" min="20" max="100" value={quality} onChange={event => changeQuality(+event.target.value)} aria-label="Render quality" /><div className="quality-presets">{[['Balanced', 50], ['High', 72], ['Ultra', 95]].map(([label, value]) => <button key={label} className={qualityLabel === label ? 'chosen' : ''} onClick={() => changeQuality(+value)}>{label}{qualityLabel === label && <Check size={12} />}</button>)}</div><p>Higher quality reveals finer engraving.<br />Lower it for smoother motion on your device.</p><div className="render-stats">{stats.width ? `${stats.width} x ${stats.height}` : 'Adaptive resolution'}<span>{stats.fps} FPS</span></div></div>}
        </div><div className="control-divider" /><button className="icon-button" onClick={capture} disabled={!ready} title="Save the current frame" aria-label="Save frame as PNG"><ArrowDownToLine size={18} /></button><button className="icon-button fullscreen-button" onClick={() => void toggleFullscreen()} title="Fullscreen (F)" aria-label={fullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}><Maximize2 size={17} /></button></div>
      </div>
      <div className="colophon"><span className="live-status"><i className={playing && ready ? 'live' : ''} /> {ready ? 'RENDERED IN REAL TIME' : 'PREPARING THE CANVAS'}</span><span className="colophon-note">Crafted in code. Captured in a gesture.</span><button onClick={() => openModal('shortcuts')}><Keyboard size={14} /> Keyboard shortcuts</button></div>
    </footer>
    {toast && <div className="toast" role="status"><Check size={15} /><span>{toast}</span></div>}
    {modal === 'about' && <Dialog onClose={closeModal} label="About the study"><div className="dialog-eyebrow">MOTION STUDIES / NO. 001</div><h2>Small gestures.<br /><em>Invisible strings.</em></h2><p className="dialog-intro">The Puppet Employee explores the delicate relationship between control and movement. An engraved world, brought to life one gesture at a time.</p><dl className="study-details"><div><dt>The hand</dt><dd>A refined, 25-joint articulated mesh</dd></div><div><dt>The movement</dt><dd>Continuous gestures, fixed string attachments</dd></div><div><dt>The finish</dt><dd>The original procedural engraving textures</dd></div></dl><p className="honest-note">Built on the supplied Three.js animation. The pose and cloud silhouettes are fitted toward the illustration; this is an interpretation, not a pixel-identical reproduction.</p><a className="source-link" href="/puppet_employee_refined.html" download>Download the upgraded HTML <ArrowDownToLine size={16} /></a><a className="original-source" href={sourceUrl} target="_blank" rel="noreferrer">View the original source <ArrowUpRight size={13} /></a></Dialog>}
    {modal === 'shortcuts' && <Dialog onClose={closeModal} label="Keyboard shortcuts"><div className="dialog-eyebrow">LESS CLICKING. MORE LOOKING.</div><h2>Make yourself<br /><em>at home.</em></h2><div className="shortcut-list">{[['Play / pause', 'Space'], ['Restart the gesture', 'R'], ['Full composition', '1'], ['Hand detail', '2'], ['Compare versions', 'C'], ['Hide / show interface', 'H'], ['Toggle fullscreen', 'F'], ['Close a panel', 'Esc']].map(([label, key]) => <div key={key}><span>{label}</span><kbd>{key}</kbd></div>)}</div></Dialog>}
    {modal === 'compare' && <Dialog onClose={closeModal} label="Compare the original and refined artwork" wide>
      <div className="comparison-heading"><div><div className="dialog-eyebrow">A STUDY IN THE DETAILS</div><h2>A closer <em>look.</em></h2></div><div className="compare-view-toggle" role="group" aria-label="Comparison view"><button onClick={() => setCompareHand(false)} aria-pressed={!compareHand} className={!compareHand ? 'selected' : ''}>Full scene</button><button onClick={() => setCompareHand(true)} aria-pressed={compareHand} className={compareHand ? 'selected' : ''}>The hand</button></div></div>
      <p className="compare-description">{reference ? 'Your reference and the refined pose. Slide to explore the differences.' : 'The original and refined render, held at the same moment. Slide to compare.'}</p>
      <div className={`comparison-canvas ${compareHand ? 'compare-hand' : ''}`} style={{ '--split': `${comparePosition}%` } as CSSProperties}><img className="comparison-image" src="/assets/refined-render.jpg" alt="Refined hand pose and engraving" /><div className="before-layer"><img className="comparison-image" src={reference || '/assets/original-render.jpg'} alt={reference ? 'Your uploaded reference image' : 'Original supplied animation at time zero'} /></div><span className="compare-label before-label">{reference ? 'YOUR REFERENCE' : 'ORIGINAL'}</span><span className="compare-label after-label">REFINED</span><div className="comparison-divider"><span><ArrowLeftRight size={18} /></span></div><input type="range" min="0" max="100" step=".1" value={comparePosition} onChange={event => setComparePosition(+event.target.value)} aria-label="Slide to compare original and refined artwork" /></div>
      <div className="comparison-footer"><div className="reference-caption"><span>{reference ? referenceName : 'STATIC FRAME / 00:00'}</span><p>{reference ? 'Your image stays on this device.' : 'Want to compare with the illustration? Add your reference.'}</p></div><input type="file" ref={referenceInput} accept="image/png,image/jpeg,image/webp" hidden onChange={event => { uploadReference(event.target.files?.[0]); event.target.value = ''; }} /><div className="reference-actions">{reference && <button className="text-button" onClick={() => { setReference(''); setReferenceName(''); }}>Reset</button>}<button className="reference-button" onClick={() => referenceInput.current?.click()}><ImagePlus size={16} /> {reference ? 'Change reference' : 'Add a reference'}</button></div></div>
    </Dialog>}
  </div>;
}
