// Full seed for Aviary HRMS — people, demo people, audit log, org structure,
// and the chart-gallery fixture dataset (feeds the Sankey 3D / Radial bar /
// Streamgraph Three.js charts with real proportions). Run: node scripts/seed-all.mjs
import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';

try {
  const env = fs.readFileSync('./.env', 'utf8');
  for (const line of env.split('\n')) {
    const m = /^\s*([A-Z_][A-Z0-9_]*)\s*=\s*"?([^"\n]*)"?\s*$/.exec(line);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2];
  }
} catch { /* no .env */ }

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) throw new Error('Missing Supabase env vars');
const sb = createClient(url, key);

let seed = 20260901;
const rnd = () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };
const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
const weighted = (pairs) => { const t = pairs.reduce((s, [, w]) => s + w, 0); let r = rnd() * t; for (const [v, w] of pairs) { r -= w; if (r <= 0) return v; } return pairs[pairs.length - 1][0]; };
const iso = (d) => d.toISOString().slice(0, 10);
const daysAgo = (n) => { const d = new Date(); d.setUTCHours(0, 0, 0, 0); d.setUTCDate(d.getUTCDate() - n); return d; };

const { data: tenant, error: tErr } = await sb.from('hrms_tenants').select('*').eq('slug', 'aviary').maybeSingle();
if (tErr) throw tErr;
if (!tenant) throw new Error('Tenant "aviary" missing');
const tenant_id = tenant.id;

const DEPTS = [
  { name: 'Engineering', roles: ['Software Engineer', 'Senior Software Engineer', 'Staff Engineer', 'Engineering Manager', 'QA Engineer', 'DevOps Engineer', 'Data Engineer'], w: 34 },
  { name: 'Product', roles: ['Product Manager', 'Senior Product Manager', 'Product Analyst'], w: 7 },
  { name: 'Design', roles: ['Product Designer', 'UX Researcher', 'Visual Designer'], w: 7 },
  { name: 'Sales', roles: ['Account Executive', 'Sales Development Rep', 'Regional Sales Manager', 'Solutions Consultant'], w: 14 },
  { name: 'Marketing', roles: ['Content Marketer', 'Growth Marketer', 'Brand Manager', 'Marketing Analyst'], w: 8 },
  { name: 'Customer Success', roles: ['Customer Success Manager', 'Support Specialist', 'Implementation Lead'], w: 10 },
  { name: 'Human Resources', roles: ['HR Business Partner', 'Talent Acquisition Specialist', 'People Operations Analyst', 'L&D Specialist'], w: 6 },
  { name: 'Finance', roles: ['Financial Analyst', 'Accountant', 'Payroll Specialist', 'FP&A Manager'], w: 6 },
  { name: 'Operations', roles: ['Operations Manager', 'Office Manager', 'Procurement Specialist'], w: 5 },
  { name: 'Legal & Compliance', roles: ['Legal Counsel', 'Compliance Analyst'], w: 3 },
];
const LOCATIONS = [
  { name: 'Bengaluru HQ', country: 'India', le: 'Aviary Technologies Pvt Ltd', w: 40 },
  { name: 'Mumbai', country: 'India', le: 'Aviary Technologies Pvt Ltd', w: 14 },
  { name: 'Hyderabad', country: 'India', le: 'Aviary Technologies Pvt Ltd', w: 12 },
  { name: 'Pune', country: 'India', le: 'Aviary Technologies Pvt Ltd', w: 8 },
  { name: 'London', country: 'United Kingdom', le: 'Aviary Technologies UK Ltd', w: 10 },
  { name: 'Singapore', country: 'Singapore', le: 'Aviary Technologies Pte Ltd', w: 7 },
  { name: 'Dubai', country: 'UAE', le: 'Aviary Technologies FZ-LLC', w: 5 },
  { name: 'Remote', country: 'Remote', le: 'Aviary Technologies Pvt Ltd', w: 4 },
];
const BU_OF = { Engineering: 'Platform & Product', Product: 'Platform & Product', Design: 'Platform & Product', Sales: 'Go-to-Market', Marketing: 'Go-to-Market', 'Customer Success': 'Go-to-Market', 'Human Resources': 'Corporate Services', Finance: 'Corporate Services', Operations: 'Corporate Services', 'Legal & Compliance': 'Corporate Services' };
const CC_OF = { Engineering: 'CC-100', Product: 'CC-110', Design: 'CC-120', Sales: 'CC-200', Marketing: 'CC-210', 'Customer Success': 'CC-220', 'Human Resources': 'CC-300', Finance: 'CC-310', Operations: 'CC-320', 'Legal & Compliance': 'CC-330' };

const FIRST_F = ['Ananya', 'Priya', 'Sneha', 'Kavya', 'Meera', 'Divya', 'Ishita', 'Riya', 'Aishwarya', 'Nandini', 'Pooja', 'Shreya', 'Tanvi', 'Neha', 'Aditi', 'Sanya', 'Lakshmi', 'Deepika', 'Radhika', 'Swati'];
const FIRST_M = ['Arjun', 'Rahul', 'Vikram', 'Rohan', 'Aditya', 'Karthik', 'Siddharth', 'Nikhil', 'Varun', 'Aman', 'Manish', 'Pranav', 'Rajesh', 'Suresh', 'Harsh', 'Kunal', 'Sameer', 'Dev', 'Yash', 'Akash'];
const LAST_IN = ['Sharma', 'Rao', 'Mehta', 'Iyer', 'Nair', 'Patel', 'Reddy', 'Gupta', 'Kulkarni', 'Menon', 'Verma', 'Singh', 'Joshi', 'Desai', 'Bose', 'Chatterjee', 'Kapoor', 'Pillai', 'Banerjee', 'Malhotra'];
const LAST_UK = ['Bennett', 'Hughes', 'Walker', 'Wright', 'Turner', 'Clarke', 'Morgan', 'Cooper'];

function personFor(i) {
  const dept = weighted(DEPTS.map((d) => [d, d.w]));
  const loc = weighted(LOCATIONS.map((l) => [l, l.w]));
  const gender = weighted([['Female', 42], ['Male', 53], ['Non-binary', 3], ['Prefer not to respond', 2]]);
  const nationality = loc.country === 'India' ? 'India' : loc.country === 'United Kingdom' ? weighted([['United Kingdom', 70], ['India', 30]]) : 'India';
  const lastPool = nationality === 'United Kingdom' ? LAST_UK : LAST_IN;
  const first = gender === 'Female' ? pick(FIRST_F) : pick(FIRST_M);
  const last = pick(lastPool);
  const full_name = `${first} ${last}`;
  const email = `${first.toLowerCase()}.${last.toLowerCase()}${i}@aviary.io`;
  const worker_type = weighted([['Permanent', 86], ['Contingent', 14]]);
  const employment_type = worker_type === 'Contingent' ? weighted([['Part Time', 45], ['Full Time', 45], ['None', 10]]) : weighted([['Full Time', 93], ['Part Time', 7]]);
  const role = pick(dept.roles);
  const joinDays = Math.floor(Math.pow(rnd(), 1.6) * 9 * 365);
  const joined = daysAgo(joinDays);
  let status = 'Active', exit_date = null, exit_reason = null, exit_type = null;
  const r = rnd();
  if (joinDays <= 30 && r < 0.75) status = 'Onboarding';
  else if (joinDays <= 120 && r < 0.6) status = 'Probation';
  else if (joinDays > 200 && r < 0.17) {
    status = 'Exited';
    const exitAgo = Math.floor(rnd() * Math.min(joinDays - 60, 540));
    exit_date = iso(daysAgo(exitAgo));
    exit_type = weighted([['Voluntary', 62], ['Involuntary', 20], ['Contract End', 12], ['Retirement', 6]]);
    exit_reason = exit_type === 'Retirement' ? 'Retirement' : exit_type === 'Contract End' ? 'Contract completed' : exit_type === 'Involuntary' ? pick(['Performance', 'Restructuring']) : pick(['Better opportunity', 'Relocation', 'Personal reasons']);
  }
  const age = Math.round(22 + Math.pow(rnd(), 1.3) * 36);
  const dob = new Date(Date.UTC(new Date().getUTCFullYear() - age, Math.floor(rnd() * 12), 1 + Math.floor(rnd() * 28)));
  const seniority = /Senior|Staff|Manager|Lead|Counsel|Head/.test(role) ? 1.7 : 1;
  const base = loc.country === 'India' ? 900000 : loc.country === 'United Kingdom' ? 5200000 : 1400000;
  const salary = Math.round((base * seniority * (0.8 + rnd() * 0.7)) / 10000) * 10000;
  return {
    tenant_id, full_name, email, gender, dept: dept.name, role, status, location: loc.name, employment_type, worker_type, nationality,
    business_unit: BU_OF[dept.name], cost_center: CC_OF[dept.name], legal_entity: loc.le,
    joined: iso(joined), exit_date, exit_reason, exit_type, dob: iso(dob), salary,
  };
}

async function seedTable(table, checkOnly, rows, chunk = 80) {
  const { count } = await sb.from(table).select('id', { count: 'exact', head: true });
  if (count) { console.log(`${table}: ${count} rows already present, skipped`); return; }
  for (let i = 0; i < rows.length; i += chunk) {
    const { error } = await sb.from(table).insert(rows.slice(i, i + chunk));
    if (error) throw error;
  }
  console.log(`${table}: inserted ${rows.length}`);
}

/* ---------------- people ---------------- */
const people = Array.from({ length: 96 }, (_, i) => personFor(i + 1));
await seedTable('hrms_people', true, people);

/* ---------------- demo people (playground) ---------------- */
const CITIES = ['Bengaluru', 'Mumbai', 'Hyderabad', 'Pune', 'Chennai', 'Delhi', 'London', 'Singapore'];
const DD = ['Design', 'Engineering', 'Sales', 'Human Resources', 'Finance', 'Marketing'];
const ROLES = { Design: ['Product Designer', 'UX Researcher'], Engineering: ['Software Engineer', 'Senior Engineer', 'QA Engineer'], Sales: ['Account Executive', 'SDR'], 'Human Resources': ['HR Partner', 'Recruiter'], Finance: ['Analyst', 'Accountant'], Marketing: ['Growth Marketer', 'Content Lead'] };
const demo = Array.from({ length: 36 }, () => {
  const dept = pick(DD); const g = rnd() < 0.5;
  const first = g ? pick(FIRST_F) : pick(FIRST_M);
  return {
    tenant_id, full_name: `${first} ${pick(LAST_IN)}`, dept, role: pick(ROLES[dept]),
    status: weighted([['Active', 70], ['On Leave', 10], ['Contract', 12], ['Inactive', 8]]),
    city: pick(CITIES), joined: iso(daysAgo(Math.floor(rnd() * 1800))), salary: Math.round((600000 + rnd() * 2400000) / 10000) * 10000,
  };
});
await seedTable('hrms_demo_people', true, demo);

/* ---------------- audit events ---------------- */
const ACTORS = ['Ananya Rao', 'Vikram Mehta', 'Priya Sharma', 'Rahul Iyer', 'Admin', 'Meera Nair', 'Arjun Patel', 'Sneha Kulkarni', 'Oliver Bennett'];
const TEMPLATES = [
  { category: 'Auth', sub_category: 'Session', attribute: 'Login', event: 'Login', detail: (a) => `${a} signed in via password`, w: 46 },
  { category: 'Auth', sub_category: 'Session', attribute: 'Login', event: 'Login', detail: (a) => `${a} signed in via Google`, w: 18 },
  { category: 'Auth', sub_category: 'Session', attribute: 'Logout', event: 'Logout', detail: (a) => `${a} signed out`, w: 14 },
  { category: 'Auth', sub_category: 'Security', attribute: 'Password', event: 'Failed Login', detail: (a) => `Failed login attempt for ${a}`, w: 4 },
  { category: 'Employee', sub_category: 'Profile', attribute: 'Personal Details', event: 'Updated', detail: (a) => `${a} updated phone number`, w: 8 },
  { category: 'Employee', sub_category: 'Job', attribute: 'Department', event: 'Transferred', detail: (a) => `${a} moved to a new department`, w: 3 },
  { category: 'Org', sub_category: 'Structure', attribute: 'departments', event: 'Created', detail: () => 'department "Data Platform" created', w: 2 },
  { category: 'Payroll', sub_category: 'Run', attribute: 'Monthly Payroll', event: 'Processed', detail: () => 'August payroll processed for 96 employees', w: 2 },
  { category: 'Settings', sub_category: 'Preferences', attribute: 'Theme', event: 'Changed', detail: (a) => `${a} switched theme`, w: 4 },
  { category: 'Reports', sub_category: 'Export', attribute: 'Employee Master', event: 'Exported', detail: (a) => `${a} exported Employee Master (Excel)`, w: 3 },
];
const events = [];
for (let d = 44; d >= 0; d--) {
  const isWeekend = [0, 6].includes(daysAgo(d).getUTCDay());
  const n = isWeekend ? 2 + Math.floor(rnd() * 3) : 6 + Math.floor(rnd() * 7);
  for (let k = 0; k < n; k++) {
    const t = weighted(TEMPLATES.map((x) => [x, x.w]));
    const actor = pick(ACTORS);
    const at = daysAgo(d); at.setUTCHours(3 + Math.floor(rnd() * 12), Math.floor(rnd() * 60), Math.floor(rnd() * 60));
    events.push({ tenant_id, actor, category: t.category, sub_category: t.sub_category, attribute: t.attribute, event: t.event, detail: t.detail(actor), created_at: at.toISOString() });
  }
}
await seedTable('hrms_audit_events', true, events, 150);

/* ---------------- org structure ---------------- */
await seedTable('hrms_legal_entities', true, [
  { tenant_id, name: 'Aviary Technologies Pvt Ltd', legal_name: 'Aviary Technologies Private Limited', cin: 'U72900KA2016PTC098765', incorporation_date: '2016-04-12', business_type: 'Private Limited', sector: 'Information Technology', nature: 'Product & Services', phone: '+91 80 4567 8900', email: 'finance@aviary.io', website: 'https://aviary.io', address1: '4th Floor, Prestige Tech Park', address2: 'Marathahalli Outer Ring Road', city: 'Bengaluru', state: 'Karnataka', zip: '560103', country: 'India' },
  { tenant_id, name: 'Aviary Technologies UK Ltd', legal_name: 'Aviary Technologies UK Limited', cin: '11223344', incorporation_date: '2019-02-01', business_type: 'Private Limited', sector: 'Information Technology', nature: 'Sales & Support', phone: '+44 20 7946 0958', email: 'uk-finance@aviary.io', website: 'https://aviary.io', address1: '1 Fore Street', address2: '', city: 'London', state: '', zip: 'EC2Y 9DT', country: 'United Kingdom' },
  { tenant_id, name: 'Aviary Technologies Pte Ltd', legal_name: 'Aviary Technologies Pte. Ltd.', cin: '201912345A', incorporation_date: '2020-06-15', business_type: 'Private Limited', sector: 'Information Technology', nature: 'Regional HQ (APAC)', phone: '+65 6789 0123', email: 'sg-finance@aviary.io', website: 'https://aviary.io', address1: '71 Robinson Road', address2: '', city: 'Singapore', state: '', zip: '068895', country: 'Singapore' },
]);
await seedTable('hrms_business_units', true, [
  { tenant_id, name: 'Platform & Product', head: 'Ananya Rao', parent: '', description: 'Engineering, Product and Design' },
  { tenant_id, name: 'Go-to-Market', head: 'Vikram Mehta', parent: '', description: 'Sales, Marketing and Customer Success' },
  { tenant_id, name: 'Corporate Services', head: 'Priya Sharma', parent: '', description: 'HR, Finance, Operations and Legal' },
]);
await seedTable('hrms_locations', true, LOCATIONS.map((l) => ({ tenant_id, name: l.name, group_email: `${l.name.toLowerCase().replace(/[^a-z]/g, '')}@aviary.io`, timezone: l.country === 'India' ? 'Asia/Kolkata' : l.country === 'United Kingdom' ? 'Europe/London' : l.country === 'Singapore' ? 'Asia/Singapore' : l.country === 'UAE' ? 'Asia/Dubai' : 'UTC', country: l.country, state: '', address1: '', address2: '', city: l.name, zip: '', description: `${l.name} office` })));
await seedTable('hrms_departments', true, DEPTS.map((d) => ({ tenant_id, name: d.name, display_name: d.name, parent_id: null, head: pick(ACTORS), description: `${d.name} department`, wall_posts: true, wall_announcements: true, wall_polls: true })));
await seedTable('hrms_cost_centers', true, Object.entries(CC_OF).map(([dept, code]) => ({ tenant_id, name: `${dept} Cost Center`, code, head: pick(ACTORS), description: `Cost center for ${dept}` })));
await seedTable('hrms_pay_grades', true, ['L1 — Associate', 'L2 — Professional', 'L3 — Senior Professional', 'L4 — Lead', 'L5 — Manager', 'L6 — Director'].map((name) => ({ tenant_id, name, description: 'Standard pay grade band' })));
await seedTable('hrms_bands', true, ['Band A', 'Band B', 'Band C', 'Band D', 'Band E'].map((name) => ({ tenant_id, name, description: 'Job band' })));

/* ---------------- chart gallery datasets ---------------- */
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const chartRows = [
  { name: 'pipeline', payload: { title: 'Hiring pipeline', defaultKind: 'funnel', height: 300, data: [
    { label: 'Applied', value: 1240 }, { label: 'Screened', value: 560 }, { label: 'Interviewed', value: 210 }, { label: 'Offered', value: 64 }, { label: 'Hired', value: 48 },
  ] } },
  { name: 'sankey_hiring', payload: { title: 'QA · Sankey (Classic) · hiring funnel by source', defaultKind: 'sankey', defaultDim: '3d', height: 480, links: [
    { value: 120, source: 'Referrals', target: 'Screened' },
    { value: 260, source: 'Job boards', target: 'Screened' },
    { value: 180, source: 'LinkedIn', target: 'Screened' },
    { value: 210, source: 'Screened', target: 'Interviewed' },
    { value: 350, source: 'Screened', target: 'Rejected' },
    { value: 64, source: 'Interviewed', target: 'Offered' },
    { value: 146, source: 'Interviewed', target: 'Rejected' },
    { value: 48, source: 'Offered', target: 'Hired' },
    { value: 16, source: 'Offered', target: 'Declined' },
  ] } },
  { name: 'sankey_hiring_pro', payload: { title: 'QA · Sankey (3D · Three.js) · hiring funnel by source', defaultKind: 'sankey3d', defaultDim: '3d', height: 500, links: [
    { value: 120, source: 'Referrals', target: 'Screened' },
    { value: 260, source: 'Job boards', target: 'Screened' },
    { value: 180, source: 'LinkedIn', target: 'Screened' },
    { value: 210, source: 'Screened', target: 'Interviewed' },
    { value: 350, source: 'Screened', target: 'Rejected' },
    { value: 64, source: 'Interviewed', target: 'Offered' },
    { value: 146, source: 'Interviewed', target: 'Rejected' },
    { value: 48, source: 'Offered', target: 'Hired' },
    { value: 16, source: 'Offered', target: 'Declined' },
  ] } },
  { name: 'radial_regions', payload: { title: 'Radial bar (3D · Three.js) · headcount by office (dense)', defaultKind: 'radialbar', defaultDim: '3d', height: 560, data: [
    { label: 'Bengaluru HQ', value: 42 }, { label: 'Mumbai', value: 28 }, { label: 'Hyderabad', value: 19 }, { label: 'Pune', value: 15 },
    { label: 'Chennai', value: 14 }, { label: 'Delhi', value: 11 }, { label: 'Kolkata', value: 8 }, { label: 'Ahmedabad', value: 6 },
    { label: 'Kochi', value: 5 }, { label: 'London', value: 24 }, { label: 'Manchester', value: 7 }, { label: 'Berlin', value: 6 },
    { label: 'Amsterdam', value: 5 }, { label: 'Singapore', value: 17 }, { label: 'Dubai', value: 9 }, { label: 'Sydney', value: 4 },
    { label: 'Toronto', value: 6 }, { label: 'Austin', value: 8 }, { label: 'Tokyo', value: 5 }, { label: 'Remote', value: 12 },
  ] } },
  { name: 'toroid_leave', payload: { title: 'Annual leave days by month · Toroid Donut', defaultKind: 'toroid', defaultDim: '3d', height: 460, data: [
    { label: 'Jan', value: 11 }, { label: 'Feb', value: 8 }, { label: 'Mar', value: 14 }, { label: 'Apr', value: 10 },
    { label: 'May', value: 17 }, { label: 'Jun', value: 13 }, { label: 'Jul', value: 20 }, { label: 'Aug', value: 15 },
    { label: 'Sep', value: 11 }, { label: 'Oct', value: 8 }, { label: 'Nov', value: 14 }, { label: 'Dec', value: 18 },
  ] } },
  { name: 'radialbars_dept', payload: { title: 'Headcount by department · Radial Bars (MUI)', defaultKind: 'radialbars', defaultDim: '2d', height: 520, data: DEPTS.map((d) => ({ label: d.name, value: Math.round(96 * d.w / 100) })) } },
  { name: 'radial_regions_classic', payload: { title: 'Radial bar (Classic) · headcount by office', defaultKind: 'radialbarclassic', defaultDim: '3d', height: 520, data: [
    { label: 'Bengaluru HQ', value: 42 }, { label: 'Mumbai', value: 28 }, { label: 'Hyderabad', value: 19 }, { label: 'Pune', value: 15 },
    { label: 'London', value: 24 }, { label: 'Singapore', value: 17 }, { label: 'Dubai', value: 9 }, { label: 'Remote', value: 12 },
  ] } },
  { name: 'stream_headcount', payload: { title: 'Headcount trend by department', defaultKind: 'stream', defaultDim: '2d', height: 560,
    categories: MONTHS,
    series: [
      { name: 'Engineering', values: [26, 27, 29, 30, 31, 33, 34, 35, 36, 37, 38, 40] },
      { name: 'Sales', values: [10, 10, 11, 12, 12, 13, 13, 14, 15, 15, 16, 17] },
      { name: 'Customer Success', values: [6, 7, 7, 8, 8, 9, 9, 9, 10, 10, 11, 11] },
      { name: 'Marketing', values: [5, 5, 6, 6, 6, 7, 7, 8, 8, 8, 9, 9] },
      { name: 'Human Resources', values: [4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7] },
      { name: 'Finance', values: [4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6] },
    ] } },
  { name: 'workforce_status', payload: { title: 'Workforce status', defaultKind: 'donut', height: 300, data: [
    { label: 'Active', value: 78 }, { label: 'On Leave', value: 8 }, { label: 'Probation', value: 6 }, { label: 'Onboarding', value: 4 }, { label: 'Exited', value: 12 },
  ] } },
  { name: 'dept_headcount', payload: { title: 'Headcount by department', defaultKind: 'bar', height: 300, data: DEPTS.map((d) => ({ label: d.name, value: Math.round(96 * d.w / 100) })) } },
  { name: 'salary_by_grade', payload: { title: 'Average salary by grade (₹L p.a.)', defaultKind: 'radar', height: 320, data: [
    { label: 'L1', value: 6 }, { label: 'L2', value: 10 }, { label: 'L3', value: 16 }, { label: 'L4', value: 24 }, { label: 'L5', value: 34 }, { label: 'L6', value: 52 },
  ] } },
  { name: 'attrition_trend', payload: { title: 'Attrition vs new hires', defaultKind: 'line', height: 300, categories: MONTHS,
    series: [ { name: 'New Hires', values: [4, 6, 5, 7, 6, 8, 7, 9, 6, 8, 7, 9] }, { name: 'Exits', values: [2, 3, 2, 4, 3, 3, 4, 3, 5, 4, 3, 4] } ] } },
  { name: 'gender_split', payload: { title: 'Gender diversity', defaultKind: 'polar', height: 300, data: [
    { label: 'Male', value: 53 }, { label: 'Female', value: 42 }, { label: 'Non-binary', value: 3 }, { label: 'Prefer not to respond', value: 2 },
  ] } },
  { name: 'recruiting_gantt', payload: { title: 'Recruiting drive · Q3 timeline', defaultKind: 'gantt', height: 320, tasks: [
    { id: 1, name: 'Sourcing', start: '2026-07-01', end: '2026-07-20', progress: 100, category: 'Talent' },
    { id: 2, name: 'Screening calls', start: '2026-07-15', end: '2026-08-05', progress: 90, category: 'Talent' },
    { id: 3, name: 'Panel interviews', start: '2026-08-01', end: '2026-08-25', progress: 65, category: 'Talent' },
    { id: 4, name: 'Offer & negotiation', start: '2026-08-20', end: '2026-09-05', progress: 40, category: 'Talent' },
    { id: 5, name: 'Onboarding prep', start: '2026-09-01', end: '2026-09-15', progress: 10, category: 'People Ops' },
  ] } },
  { name: 'tenure_vs_salary', payload: { title: 'Tenure vs salary (sample)', defaultKind: 'scatter', height: 320, scatter: Array.from({ length: 24 }, (_, i) => ({
    x: 1 + (i % 8), y: 6 + ((i * 37) % 46), label: `Employee ${i + 1}`,
  })) } },
];
await seedTable('hrms_chart_datasets', true, chartRows);

console.log('seed-all complete');
