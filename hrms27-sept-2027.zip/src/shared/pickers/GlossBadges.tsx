import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

/* ============================================================
   GlossBadges / GlossKnobs — transparent Three.js overlay that plots
   glossy 3D balls over DOM badges, faithful to glossyDatePicker.html:
     - OrthographicCamera in CSS-pixel units (positions map 1:1 to the DOM)
     - Shared high-res SphereGeometry(64, 64) per badge size, scale.z 0.65
     - Studio rig: warm key light + warm ambient + warm bottom fill +
       RoomEnvironment PMREM ("the shine") + ShadowMaterial catcher
     - MeshPhysicalMaterial { roughness .16, clearcoat 1,
       clearcoatRoughness .03, envMapIntensity 1.4 }
   Ball COLOUR is theme-dynamic (live --t-accent); only the light-rig
   constants come from the reference, so no theme colour is altered.

   Number engraving (reference .raised-badge): the DOM badge is fully
   transparent and floats ABOVE the canvas with crisp white text + a dark
   keyline shadow, so the number reads engraved on the sphere. The badge
   must NOT create its own stacking context (no isolation/transform/
   opacity/filter on it) — otherwise its z-index stops competing with the
   canvas and the number sinks UNDER the ball. See index.css.

   Ball-size stability: puck radii are measured ONCE per puck and locked
   (mid-flight fractional widths must never resize the sphere), and the
   canvas is counter-shifted by the host rect's fractional remainder each
   frame so balls can't drift or swell while moving.

   Interactive Shadow Engine (reference updateLightingForCursor): the
   shadow-casting key light pivots around the cursor (dx*1.8/-dy*1.8) so
   each ball's drop-shadow tilts AWAY from the pointer; on pointerleave
   the last cursor is retained, locking the shadow angle.

   Mount-once design: the WebGL rig is created a single time and value
   changes only re-plot the balls through the LIVE rig (recreating the
   context per value was the root cause of the clock ball detaching and
   lagging on hour/minute switches and drags).
   ============================================================ */

/** Read the live theme accent as a THREE colour (balls follow the theme). */
export function themeBallColor(): THREE.Color {
  try {
    const css = getComputedStyle(document.documentElement).getPropertyValue('--t-accent').trim();
    return new THREE.Color(css || '#0d7a54');
  } catch {
    return new THREE.Color('#0d7a54');
  }
}

interface GlossRig {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.OrthographicCamera;
  key: THREE.DirectionalLight;
  catcher: THREE.Mesh;
  group: THREE.Group;
  badgeMat: THREE.MeshPhysicalMaterial;
  pmrem: THREE.PMREMGenerator;
  geoCache: Map<number, THREE.SphereGeometry>;
}

function createRig(canvas: HTMLCanvasElement): GlossRig | null {
  let renderer: THREE.WebGLRenderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'high-performance' });
  } catch {
    return null; // no WebGL → CSS fallback stays visible
  }
  renderer.setClearColor(0x000000, 0);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 3));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.05).texture;

  const camera = new THREE.OrthographicCamera(0, 1, 0, -1, 1, 2000);
  camera.position.z = 600;

  /* Shadow-casting key light (pivots around the cursor, see below) */
  const key = new THREE.DirectionalLight(0xfff4ea, 1.85);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.bias = -0.0005;
  scene.add(key, key.target);

  /* Warm ambient for soft, natural illumination */
  scene.add(new THREE.AmbientLight(0xffedd8, 0.95));

  /* Warm bottom fill to soften underside shadows */
  const bottomFill = new THREE.DirectionalLight(0xffdbcd, 0.75);
  bottomFill.position.set(0, -300, 200);
  scene.add(bottomFill);

  /* Soft shadow catcher plane behind the spheres */
  const catcher = new THREE.Mesh(
    new THREE.PlaneGeometry(1, 1),
    new THREE.ShadowMaterial({ color: 0x7a3a20, opacity: 0.28 }),
  );
  catcher.receiveShadow = true;
  scene.add(catcher);

  const badgeMat = new THREE.MeshPhysicalMaterial({
    color: themeBallColor(), roughness: 0.16, metalness: 0.0,
    clearcoat: 1.0, clearcoatRoughness: 0.03, envMapIntensity: 1.4,
  });
  const group = new THREE.Group();
  scene.add(group);
  return { renderer, scene, camera, key, catcher, group, badgeMat, pmrem, geoCache: new Map() };
}

function useGlossLayer(
  hostRef: React.RefObject<HTMLElement | null>,
  canvasRef: React.RefObject<HTMLCanvasElement | null>,
  badgeSelector: string,
  observeStyle: boolean,
  flattenZ: number,
  tick: unknown,
) {
  const apiRef = useRef<{ replot: () => void } | null>(null);

  /* Mount-once: create the rig a single time per mount. */
  useEffect(() => {
    const host = hostRef.current;
    const canvas = canvasRef.current;
    if (!host || !canvas) return;
    host.classList.add('gloss-on');

    const rig = createRig(canvas);
    if (!rig) return;
    const { renderer, scene, camera, key, catcher, group, badgeMat, pmrem, geoCache } = rig;

    let W = 0, H = 0, raf = 0, pending = 0;
    let cursorX: number | null = null, cursorY: number | null = null;
    /* Radius lock: each puck's sphere radius is measured once per DOM node
       and frozen. Two compounding causes made balls swell while moving:
         (a) re-measuring every frame lets layout rounding / fractional
             widths inflate the ball mid-flight;
         (b) getBoundingClientRect on the clock puck returns the AABB of a
             ROTATED square (parent unit is rotate(deg)) — at 45° a 36px
             puck measures ~51px. offsetWidth/Height are transform-proof,
             so the radius is taken from layout size; the rect is used ONLY
             for the centre (rotation preserves centres, so it stays exact).
       Keyed by element (WeakMap): nodes React reuses keep their radius,
       freshly mounted badges measure once at creation. */
    const radiusLock = new WeakMap<HTMLElement, number>();
    /* Fractional-drift compensation, applied as a canvas translate in draw().
       The host rect's sub-pixel remainder would otherwise offset every ball
       by up to half a pixel from its number while animating. */
    let lastDX = 0, lastDY = 0;
    const draw = () => {
      canvas.style.transform = (lastDX || lastDY)
        ? `translate(${lastDX.toFixed(2)}px, ${lastDY.toFixed(2)}px)` : '';
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => renderer.render(scene, camera));
    };

    /* Reference cursor lighting: light, shading and cast shadow pivot
       with the cursor; with no cursor yet, a fixed default pose. */
    const updateLightingForCursor = (clientX?: number, clientY?: number) => {
      if (W === 0 || H === 0) return;
      const r = host.getBoundingClientRect();
      if (clientX !== undefined && clientY !== undefined) {
        cursorX = clientX; cursorY = clientY;
      }
      let mx: number, my: number;
      if (cursorX !== null && cursorY !== null) {
        mx = cursorX - r.left; my = cursorY - r.top;
      } else {
        mx = W * 0.2; my = H * 0.2;
      }
      const c = new THREE.Vector3(W / 2, -H / 2, 0);
      const dx = mx - W / 2, dy = my - H / 2;
      key.target.position.copy(c);
      key.position.set(c.x + dx * 1.8 - 80, c.y - dy * 1.8 + 80, 320);
      const s = key.shadow.camera, m = Math.max(W, H) * 1.5;
      s.left = -m; s.right = m; s.top = m; s.bottom = -m; s.near = 1; s.far = 1500;
      s.updateProjectionMatrix();
      draw();
    };

    const resize = () => {
      const r = host.getBoundingClientRect();
      W = Math.max(1, r.width); H = Math.max(1, r.height);
      renderer.setSize(W, H, false);
      camera.right = W; camera.bottom = -H; camera.updateProjectionMatrix();
      catcher.scale.set(W, H, 1);
      catcher.position.set(W / 2, -H / 2, -14);
      updateLightingForCursor();
    };

    /* Shared high-res sphere per badge size (reference: ONE 64x64 geo).
       Geometries are cached and reused across replots — never rebuilt. */
    const geoFor = (rad: number) => {
      const bucket = Math.max(8, Math.round(rad * 2) / 2);
      let g = geoCache.get(bucket);
      if (!g) { g = new THREE.SphereGeometry(bucket, 64, 64); geoCache.set(bucket, g); }
      return g;
    };

    const rebuild = () => {
      const c = host.getBoundingClientRect();
      if (c.width !== W || c.height !== H) resize();
      lastDX = c.left - Math.round(c.left);
      lastDY = c.top - Math.round(c.top);
      group.clear();
      host.querySelectorAll(badgeSelector).forEach((el) => {
        const node = el as HTMLElement;
        const r = node.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return;
        let rad = radiusLock.get(node);
        if (rad === undefined) {
          const ow = node.offsetWidth || r.width;
          const oh = node.offsetHeight || r.height;
          rad = Math.max(8, Math.min(ow, oh) / 2);
          radiusLock.set(node, rad);
        }
        const mesh = new THREE.Mesh(geoFor(rad), badgeMat);
        mesh.scale.z = flattenZ;
        mesh.position.set((r.left + r.right) / 2 - c.left, -((r.top + r.bottom) / 2 - c.top), 5);
        mesh.castShadow = mesh.receiveShadow = true;
        group.add(mesh);
      });
      updateLightingForCursor();
    };
    const schedule = () => { cancelAnimationFrame(pending); pending = requestAnimationFrame(rebuild); };
    apiRef.current = { replot: schedule };

    const mo = new MutationObserver(schedule);
    mo.observe(host, { childList: true, subtree: true, attributes: true, attributeFilter: observeStyle ? ['class', 'style'] : ['class'] });
    const ro = new ResizeObserver(schedule);
    ro.observe(host);

    // Track the whole picker modal (popover / sheet) so light + shadow keep
    // following the cursor anywhere inside the modal.
    const scope = host.closest('.tk-pop') || host;
    const onMove = (e: PointerEvent) => updateLightingForCursor(e.clientX, e.clientY);
    // Pointer leave retains the last cursor → shadow angle stays locked.
    const onLeave = () => updateLightingForCursor();
    scope.addEventListener('pointermove', onMove as EventListener);
    scope.addEventListener('pointerleave', onLeave);
    // theme swap → re-tint the balls live (green today, accent of any theme)
    const onTheme = () => { badgeMat.color.copy(themeBallColor()); draw(); };
    window.addEventListener('aviary:prefs', onTheme);

    resize(); rebuild();

    return () => {
      cancelAnimationFrame(raf); cancelAnimationFrame(pending);
      mo.disconnect(); ro.disconnect();
      scope.removeEventListener('pointermove', onMove as EventListener);
      scope.removeEventListener('pointerleave', onLeave);
      window.removeEventListener('aviary:prefs', onTheme);
      host.classList.remove('gloss-on');
      geoCache.forEach((g) => g.dispose());
      badgeMat.dispose(); pmrem.dispose(); renderer.dispose();
      apiRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hostRef, badgeSelector]);

  /* Value changes re-plot through the LIVE rig — the context is never
     torn down (this was the clock-ball detachment root cause). */
  useEffect(() => { apiRef.current?.replot(); }, [tick]);
}

export default function GlossBadges({ hostRef, badgeSelector = '.cal-badge' }: {
  hostRef: React.RefObject<HTMLElement | null>;
  badgeSelector?: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useGlossLayer(hostRef, canvasRef, badgeSelector, false, 0.65, badgeSelector);
  return <canvas ref={canvasRef} className="gloss-canvas" aria-hidden />;
}

/** Same glossy balls for the time picker's clock-hand tip + slider knobs. */
export function GlossKnobs({ hostRef, tick }: {
  hostRef: React.RefObject<HTMLElement | null>;
  tick: unknown;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useGlossLayer(hostRef, canvasRef, '[data-gloss-knob]', true, 0.65, tick);
  return <canvas ref={canvasRef} className="gloss-canvas" aria-hidden />;
}
