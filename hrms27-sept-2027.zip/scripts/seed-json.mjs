// Seed project data (from the hrms zip's seed-data/*.json) into Supabase.
// Run: node scripts/seed-json.mjs
import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';

try {
  const env = fs.readFileSync('./.env', 'utf8');
  for (const line of env.split('\n')) {
    const m = /^\s*([A-Z_][A-Z0-9_]*)\s*=\s*"?([^"\n]*)"?\s*$/.exec(line);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2];
  }
} catch { /* no .env */ }

const LIVE = (() => {
  try {
    const v = JSON.parse(fs.readFileSync('./vercel.json', 'utf8')).env;
    return { url: v.NEXT_PUBLIC_SUPABASE_URL, key: v.SUPABASE_SERVICE_ROLE_KEY };
  } catch { return null; }
})();
const url = process.env.SEED_URL || (LIVE && LIVE.url) || process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SEED_KEY || (LIVE && LIVE.key) || process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) throw new Error('Missing Supabase env vars');
const sb = createClient(url, key);

const DIR = '/tmp/hrms_ref/hrms_main/seed-data';
const load = (f) => JSON.parse(fs.readFileSync(`${DIR}/${f}`, 'utf8'));

async function seedTable(table, rows, chunk = 60) {
  const { count } = await sb.from(table).select('id', { count: 'exact', head: true });
  if (count) { console.log(`${table}: ${count} rows already present, skipped`); return; }
  for (let i = 0; i < rows.length; i += chunk) {
    const { error } = await sb.from(table).insert(rows.slice(i, i + chunk));
    if (error) throw error;
  }
  console.log(`${table}: inserted ${rows.length}`);
}

const people = [...load('p0.json'), ...load('p1.json'), ...load('p2.json')];
await seedTable('hrms_people', people);
await seedTable('hrms_demo_people', load('d0.json'));
await seedTable('hrms_audit_events', [...load('a0.json'), ...load('a1.json'), ...load('a2.json'), ...load('a3.json'), ...load('a4.json')], 120);

/* ---- org-chart employee roster (reference zip's dummy data shape) ---- */
const ORG = [
  { name: 'Aarav Kapoor', title: 'Chief Executive Officer', department: 'Executive', email: 'aarav.kapoor@aviary.io', phone: '+91 98200 10001', location: 'Bengaluru HQ', manager_id: null, photo_url: 'https://randomuser.me/api/portraits/men/32.jpg', level: 0, team_size: 11 },
  { name: 'Ananya Rao', title: 'VP Engineering', department: 'Engineering', email: 'ananya.rao@aviary.io', phone: '+91 98200 10002', location: 'Bengaluru HQ', manager_id: 1, photo_url: 'https://randomuser.me/api/portraits/women/44.jpg', level: 1, team_size: 5 },
  { name: 'Vikram Mehta', title: 'VP Sales', department: 'Sales', email: 'vikram.mehta@aviary.io', phone: '+91 98200 10003', location: 'Mumbai', manager_id: 1, photo_url: 'https://randomuser.me/api/portraits/men/45.jpg', level: 1, team_size: 4 },
  { name: 'Priya Sharma', title: 'VP People', department: 'Human Resources', email: 'priya.sharma@aviary.io', phone: '+91 98200 10004', location: 'Bengaluru HQ', manager_id: 1, photo_url: 'https://randomuser.me/api/portraits/women/68.jpg', level: 1, team_size: 2 },
  { name: 'Rohan Iyer', title: 'Engineering Manager', department: 'Engineering', email: 'rohan.iyer@aviary.io', phone: '+91 98200 10005', location: 'Bengaluru HQ', manager_id: 2, photo_url: 'https://randomuser.me/api/portraits/men/22.jpg', level: 2, team_size: 3 },
  { name: 'Sneha Kulkarni', title: 'Senior Product Manager', department: 'Product', email: 'sneha.kulkarni@aviary.io', phone: '+91 98200 10006', location: 'Bengaluru HQ', manager_id: 2, photo_url: 'https://randomuser.me/api/portraits/women/65.jpg', level: 2, team_size: 0 },
  { name: 'Karthik Nair', title: 'Staff Engineer', department: 'Engineering', email: 'karthik.nair@aviary.io', phone: '+91 98200 10007', location: 'Hyderabad', manager_id: 2, photo_url: 'https://randomuser.me/api/portraits/men/67.jpg', level: 2, team_size: 0 },
  { name: 'Meera Nair', title: 'Regional Sales Manager', department: 'Sales', email: 'meera.nair@aviary.io', phone: '+91 98200 10008', location: 'Mumbai', manager_id: 3, photo_url: 'https://randomuser.me/api/portraits/women/12.jpg', level: 2, team_size: 2 },
  { name: 'Arjun Patel', title: 'Account Executive', department: 'Sales', email: 'arjun.patel@aviary.io', phone: '+91 98200 10009', location: 'Delhi', manager_id: 3, photo_url: 'https://randomuser.me/api/portraits/men/41.jpg', level: 2, team_size: 0 },
  { name: 'Divya Menon', title: 'HR Business Partner', department: 'Human Resources', email: 'divya.menon@aviary.io', phone: '+91 98200 10010', location: 'Bengaluru HQ', manager_id: 4, photo_url: 'https://randomuser.me/api/portraits/women/33.jpg', level: 2, team_size: 0 },
  { name: 'Aditya Rao', title: 'Talent Acquisition Specialist', department: 'Human Resources', email: 'aditya.rao@aviary.io', phone: '+91 98200 10011', location: 'Pune', manager_id: 4, photo_url: 'https://randomuser.me/api/portraits/men/29.jpg', level: 2, team_size: 0 },
  { name: 'Ishita Singh', title: 'Software Engineer', department: 'Engineering', email: 'ishita.singh@aviary.io', phone: '+91 98200 10012', location: 'Bengaluru HQ', manager_id: 5, photo_url: 'https://randomuser.me/api/portraits/women/25.jpg', level: 3, team_size: 0 },
  { name: 'Nikhil Verma', title: 'QA Engineer', department: 'Engineering', email: 'nikhil.verma@aviary.io', phone: '+91 98200 10013', location: 'Bengaluru HQ', manager_id: 5, photo_url: 'https://randomuser.me/api/portraits/men/53.jpg', level: 3, team_size: 0 },
  { name: 'Kavya Reddy', title: 'DevOps Engineer', department: 'Engineering', email: 'kavya.reddy@aviary.io', phone: '+91 98200 10014', location: 'Hyderabad', manager_id: 5, photo_url: 'https://randomuser.me/api/portraits/women/50.jpg', level: 3, team_size: 0 },
  { name: 'Rahul Desai', title: 'Sales Development Rep', department: 'Sales', email: 'rahul.desai@aviary.io', phone: '+91 98200 10015', location: 'Mumbai', manager_id: 8, photo_url: 'https://randomuser.me/api/portraits/men/71.jpg', level: 3, team_size: 0 },
  { name: 'Tanvi Joshi', title: 'Solutions Consultant', department: 'Sales', email: 'tanvi.joshi@aviary.io', phone: '+91 98200 10016', location: 'Mumbai', manager_id: 8, photo_url: 'https://randomuser.me/api/portraits/women/17.jpg', level: 3, team_size: 0 },
];
await seedTable('hrms_org_employees', ORG);

console.log('seed-json complete');
