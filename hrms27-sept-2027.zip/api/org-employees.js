import supabase from './db-client.js';
import { requireUser } from '../server/require-user.js';

/** Org-chart roster (reference zip's dummy data shape, stored in hrms_org_employees). */
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (!await requireUser(req, res)) return;
    if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
    const { data, error } = await supabase
      .from('hrms_org_employees')
      .select('*')
      .order('level', { ascending: true })
      .order('id', { ascending: true });
    if (error) throw error;
    return res.status(200).json(data);
  } catch (err) {
    console.error('org-employees API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
