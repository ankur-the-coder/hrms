# The Puppet Employee

An interactive React viewer and a graphics upgrade built directly on the supplied [animation HTML](https://github.com/ankur-the-coder/hrms/blob/main/puppet_employee_glb_hand.html).

## Run

```sh
npm install
npm run dev
npm run build
```

The renderer and fonts are local. There are no runtime CDNs, API keys, or backend requirements.

## Source And Delivery

- `public/original/puppet_employee_glb_hand.html`: untouched downloaded source.
- `public/scene.js`: the extracted original scene, with targeted graphics corrections and a viewer bridge.
- `public/vendor/three-r128.min.js`: the original bundled Three.js, with its license retained.
- `public/puppet_employee_refined.html`: downloadable, self-contained upgraded HTML. Works offline.
- `src/App.tsx`: React playback, camera, quality, comparison, upload, and export controls.

## Graphics Changes

- Retains the original embedded 5,031-vertex hand mesh, skinning weights, glyph textures, cloth materials, and engraving pipeline.
- Fits finger flexion, spread, metacarpals, thumb opposition, wrist placement, and silhouette toward manually estimated illustration landmarks.
- Fits to the fingertip surface rather than internal joint endpoints. Adds small, continuous gestures instead of large arbitrary motion.
- Uses smooth, skin-weighted palm-volume and outer-knuckle correctives to improve the overall silhouette while leaving distal attachment points stable.
- Localizes crease shading to visible dorsal joint regions and reduces repeated dark rings.
- Replaces frame-by-frame string sorting and reassignment with eight persistent bindings. Surface attachment points, letter counts, and letter identities remain stable.
- Turns the existing employee toward the front-left without replacing the character or its materials.
- Reshapes clouds into asymmetric, scalloped masses with diffuse lower edges, retaining the engraving treatment.

## Inspection

Use the Hand Detail view and magnification controls. Space pauses, R restarts, 1/2 switch views, H hides the interface, and F enters fullscreen. PNG export contains only the rendered artwork.

Compare displays the original and refined render at time zero. An optional local PNG, JPEG, or WebP upload replaces the original-render comparison with the user's reference. Images never leave the device. Comparison snapshots are not the live animation.

## Verification

`node scripts/verify.mjs` runs Chromium checks against a running Vite server. It captures full scenes and hand close-ups, checks rig continuity and fixed attachment identity, and tests playback, speed, zoom, quality, image export, comparison, uploads, fullscreen, keyboard dialogs, and mobile overflow. Screenshots and metrics are in `artifacts/`.

`scripts/fit_hand.py` and `scripts/apply_pose.py` document and reproduce the pose-fitting work. They require Python with NumPy and SciPy and the captured baseline rig in `artifacts/`. `node scripts/bundle-standalone.mjs` regenerates the offline HTML after engine changes.

## Accuracy Limit

This is a fitted interpretation, not a verified pixel-identical reconstruction. The supplied illustration was visually traced into approximate landmarks; its original image bytes were not available as a project asset for a pixelwise comparison. Fine silhouette, anatomy, lighting, and engraving differences remain. No exact-match or photorealistic-equivalence claim is made.