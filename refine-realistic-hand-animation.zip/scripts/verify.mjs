import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const browser = await chromium.launch({
  headless: true,
  args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
const base = process.env.TEST_URL || 'http://localhost:5173';

try {
  await page.goto(`${base}/scene.html?t=0&q=70`);
  await page.waitForFunction(() => Boolean(window.PuppetStudy));
  await page.waitForTimeout(2000);
  await page.screenshot({ path: 'public/assets/refined-render.jpg', type: 'jpeg', quality: 94 });
  await page.screenshot({ path: 'artifacts/final-render.png' });
  await page.screenshot({ path: 'artifacts/final-hand.png', clip: { x: 1080, y: 15, width: 600, height: 400 } });
  fs.writeFileSync('artifacts/final-vertices.json', JSON.stringify(await page.evaluate(() => Array.from(window.__study.hPos))));
  const rig = await page.evaluate(() => {
    const study = window.__study;
    const bindings = JSON.stringify(study.stringBindings);
    const samples = [], targets = [];
    for (let i = 0; i < 480; i++) {
      const t = i / 120, { ph, H } = study.pose(t);
      study.poseHand(t, ph, H - 1.16);
      samples.push(study.tips.map(point => [...point]));
      study.root.updateMatrixWorld(true);
      targets.push(study.stringBindings.map(binding => study.toDesign(study.anc[binding.target])));
      if (JSON.stringify(study.stringBindings) !== bindings) throw new Error('A string changed identity.');
    }
    let maxStep = 0, maxTargetStep = 0;
    for (let i = 1; i < samples.length; i++) {
      for (let j = 0; j < 5; j++) {
        maxStep = Math.max(maxStep, Math.hypot(samples[i][j][0] - samples[i - 1][j][0], samples[i][j][1] - samples[i - 1][j][1]));
      }
      for (let j = 0; j < 8; j++) maxTargetStep = Math.max(maxTargetStep, Math.hypot(targets[i][j][0] - targets[i - 1][j][0], targets[i][j][1] - targets[i - 1][j][1]));
    }
    return { maxStep, maxTargetStep, bindings: study.stringBindings, meshVertices: study.HD.nV, facing: study.root.rotation.y };
  });
  assert(rig.maxStep < 1, 'Finger movement must be continuous at 120 Hz.');
  assert(rig.maxTargetStep < 4, 'String endpoints must remain continuous across the gait cycle.');
  fs.writeFileSync('artifacts/rig-verification.json', JSON.stringify(rig, null, 2));

  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto(base);
  await page.locator('.stage.is-ready').waitFor({ timeout: 25000 });
  await page.waitForTimeout(2200);
  const scene = page.frames().find(frame => frame.url().includes('/scene.html'));
  assert(scene, 'Embedded original-derived scene is available.');
  const getState = () => scene.evaluate(() => window.PuppetStudy.state());
  await page.screenshot({ path: 'artifacts/desktop-viewer.png' });

  await page.getByRole('button', { name: 'Pause animation', exact: true }).click();
  await page.waitForTimeout(250);
  const paused = await getState();
  await page.waitForTimeout(400);
  assert.equal((await getState()).time, paused.time, 'Pause freezes the animation clock.');
  await page.getByLabel('Playback speed').selectOption('0.25');
  assert.equal((await getState()).speed, .25);
  await page.getByRole('button', { name: 'Hand detail', exact: true }).click();
  await page.waitForTimeout(1000);
  assert.equal((await getState()).view, 'hand');
  await page.screenshot({ path: 'artifacts/viewer-hand-detail.png' });
  await page.getByRole('button', { name: 'Zoom in', exact: true }).click();
  assert.equal(await page.locator('.zoom-value').textContent(), '125%');
  await page.getByTitle('Reset zoom', { exact: true }).click();
  await page.getByRole('button', { name: 'High quality', exact: true }).click();
  await page.getByRole('button', { name: 'Balanced', exact: true }).click();
  assert.equal((await getState()).quality, 50);
  await page.keyboard.press('Escape');

  const downloaded = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Save frame as PNG' }).click();
  const download = await downloaded;
  assert(download.suggestedFilename().endsWith('.png'));
  await download.saveAs('artifacts/exported-frame.png');

  await page.getByRole('button', { name: 'Compare', exact: true }).click();
  await page.getByRole('dialog').waitFor();
  assert.equal(await page.locator('.comparison-image').evaluateAll(images => images.every(image => image.complete && image.naturalWidth > 0)), true);
  const slider = page.getByRole('slider', { name: 'Slide to compare original and refined artwork' });
  await slider.focus(); await page.keyboard.press('ArrowRight');
  assert(Number(await slider.inputValue()) > 50);
  await page.screenshot({ path: 'artifacts/compare-hand.png' });
  await page.locator('input[type=file]').setInputFiles('public/assets/original-render.jpg');
  await page.getByText('Your image stays on this device.').waitFor();
  await page.getByRole('button', { name: 'Reset', exact: true }).click();
  await page.keyboard.press('Escape');
  assert.equal((await getState()).playing, false, 'Closing comparison preserves the paused state.');

  await page.getByRole('button', { name: 'Full composition', exact: true }).click();
  await page.keyboard.press('h');
  assert(await page.locator('.app.is-immersive').count());
  await page.getByRole('button', { name: /Show controls/ }).click();
  await page.getByRole('button', { name: 'About the study', exact: true }).click();
  assert(await page.getByText('Small gestures.').count());
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Keyboard shortcuts', exact: true }).click();
  assert.equal(await page.locator('.shortcut-list > div').count(), 8);
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Enter fullscreen', exact: true }).click();
  await page.waitForFunction(() => Boolean(document.fullscreenElement) || Boolean(document.querySelector('.is-immersive')));
  if (await page.evaluate(() => Boolean(document.fullscreenElement))) {
    await page.getByRole('button', { name: 'Exit fullscreen', exact: true }).click();
    await page.waitForFunction(() => !document.fullscreenElement);
  } else {
    await page.getByRole('button', { name: /Show controls/ }).click();
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(1200);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true, 'No mobile horizontal overflow.');
  await page.screenshot({ path: 'artifacts/mobile-viewer.png' });
  await page.getByRole('button', { name: 'Hand detail', exact: true }).click();
  await page.waitForTimeout(700);
  await page.screenshot({ path: 'artifacts/mobile-hand-detail.png' });

  assert.deepEqual(errors, [], 'No browser runtime errors.');
  console.log(JSON.stringify({ status: 'passed', tests: ['rig continuity', 'fixed string identity', 'pause', 'speed', 'camera views', 'zoom', 'quality', 'PNG export', 'comparison slider', 'reference upload', 'modal state restoration', 'immersive mode', 'about', 'keyboard shortcuts', 'fullscreen', 'mobile overflow'], maxFingertipStep: rig.maxStep, errors }, null, 2));
} finally {
  await browser.close();
}