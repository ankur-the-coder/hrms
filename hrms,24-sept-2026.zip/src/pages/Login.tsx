import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowRight, AlertCircle, User, Eye, EyeOff } from 'lucide-react';
import supabase from '../lib/supabase';
import { signInWithGoogle } from '../lib/googleAuth';
import { useAuth } from '../contexts/AuthContext';

/*
 * Auth — signature angled flap sweep matching Gemini reference exactly.
 *  Phase 0  outgoing content lifts away as the sweep begins
 *  Phase 1  the raised dark-green flap expands (clip-path) across the screen
 *  Midpoint form column + flap resting side swap while hidden
 *  Phase 2  flap retracts to the opposite angled rest
 *  Phase 3  incoming content staggers upward into view
 */

const EXPAND_MS = 680;

function LeafGlyph({ className = 'w-4 h-4 text-emerald-300' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className}>
      <path
        d="M6 19c6.5 0 13-4 15-15-11 2-15 8.5-15 15Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6 19c2.5-3.5 5.5-6.5 9.5-9.5"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
    </svg>
  );
}

function InsetField({
  label,
  type,
  value,
  onChange,
  placeholder,
  icon,
  trailing,
  autoComplete,
}: {
  label: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  icon: React.ReactNode;
  trailing?: React.ReactNode;
  autoComplete?: string;
}) {
  return (
    <label className="lx-stagger block">
      <span className="mb-2 block font-body text-[10px] font-bold uppercase tracking-[0.2em] text-[#868175]">
        {label}
      </span>
      <div className="flex h-12 items-center gap-3 rounded-[14px] bg-[#dfdad0] px-4 shadow-[inset_3px_3px_6px_rgba(165,160,150,0.55),inset_-3px_-3px_6px_rgba(255,255,255,0.9)] transition-all focus-within:ring-2 focus-within:ring-[#4a7859]/30">
        <span className="shrink-0 text-[#7a756a]">{icon}</span>
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className="w-full bg-transparent font-body text-[14px] text-[#1c1c1a] outline-none placeholder:text-[#9c968a]"
        />
        {trailing}
      </div>
    </label>
  );
}

export default function Login() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [mode, setMode] = useState<'in' | 'up'>('in');
  const [side, setSide] = useState<'right' | 'left'>('right');
  const [covering, setCovering] = useState(false);
  const [phase, setPhase] = useState<'in' | 'out' | 'pre'>('pre');
  const animating = useRef(false);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate('/home', { replace: true });
  }, [user, loading, navigate]);

  useEffect(() => {
    const t = setTimeout(() => setPhase('in'), 60);
    return () => clearTimeout(t);
  }, []);

  const toggleForm = () => {
    if (animating.current) return;
    animating.current = true;
    setError('');
    setPhase('out');
    setCovering(true);
    setTimeout(() => {
      setMode((m) => (m === 'in' ? 'up' : 'in'));
      setSide((s) => (s === 'right' ? 'left' : 'right'));
      setPhase('pre');
      setCovering(false);
      requestAnimationFrame(() => requestAnimationFrame(() => setPhase('in')));
    }, EXPAND_MS);
    setTimeout(() => {
      animating.current = false;
    }, EXPAND_MS * 2);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (mode === 'up' && !name.trim()) {
      setError('Please tell us your name.');
      return;
    }
    if (!email.trim() || !password.trim()) {
      setError('Email and password are required.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    setBusy(true);
    try {
      if (mode === 'up') {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: name } },
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      navigate('/home');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setBusy(false);
    }
  };

  const staggerCls = phase === 'in' ? 'lx-in' : phase === 'out' ? 'lx-out' : '';

  const googleBtn = (
    <button
      type="button"
      onClick={() => signInWithGoogle('Aviary HRMS')}
      className="lx-stagger flex h-12 w-full items-center justify-center gap-3 rounded-[16px] bg-white font-body text-[13.5px] font-semibold text-[#1c1c1a] shadow-[3px_4px_14px_rgba(180,175,165,0.45),-2px_-2px_8px_rgba(255,255,255,0.9)] transition hover:bg-white/95 active:scale-[0.99]"
    >
      <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden>
        <path
          fill="#4285F4"
          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1z"
        />
        <path
          fill="#34A853"
          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23z"
        />
        <path
          fill="#FBBC05"
          d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84z"
        />
        <path
          fill="#EA4335"
          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15A11 11 0 0 0 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
        />
      </svg>
      Continue with Google
    </button>
  );

  const brand = (onFlap: boolean) => (
    <div className="lx-stagger mb-6 flex items-center gap-3.5">
      <div
        className={`flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-[18px] ${
          onFlap
            ? 'border border-white/10 bg-white/[0.08] shadow-[4px_6px_16px_rgba(0,0,0,0.35),inset_0_1px_1px_rgba(255,255,255,0.25)] backdrop-blur-md'
            : 'bg-[#eae6dc] shadow-[4px_4px_12px_rgba(180,175,165,0.65),-4px_-4px_12px_rgba(255,255,255,0.95)]'
        }`}
      >
        <div
          className={`flex h-8 w-8 items-center justify-center rounded-full ${
            onFlap ? 'bg-[#173824] text-[#a7f3d0]' : 'bg-[#264e37] text-[#c9f1ab]'
          }`}
        >
          <LeafGlyph className="h-4 w-4" />
        </div>
      </div>
      <div>
        <span
          className={`block font-display text-[20px] font-bold leading-none tracking-tight ${
            onFlap ? 'text-white' : 'text-[#1c1c1a]'
          }`}
        >
          Aviary
        </span>
        <span
          className={`mt-1 block font-body text-[9.5px] font-bold uppercase tracking-[0.24em] ${
            onFlap ? 'text-white/60' : 'text-[#868175]'
          }`}
        >
          People OS
        </span>
      </div>
    </div>
  );

  const formCore = (
    <>
      {brand(false)}
      <p className="lx-stagger mb-2 font-body text-[10.5px] font-bold uppercase tracking-[0.25em] text-[#3e6045]">
        {mode === 'in' ? 'Member access' : 'New membership'}
      </p>
      <h1 className="lx-stagger font-display text-[34px] font-medium leading-tight text-[#1c1c1a]">
        {mode === 'in' ? (
          <>
            Welcome <em className="italic text-[#3e6045]">back.</em>
          </>
        ) : (
          <>
            Start your <em className="italic text-[#3e6045]">workspace.</em>
          </>
        )}
      </h1>
      <p className="lx-stagger mt-1.5 font-body text-[13.5px] text-[#787368]">
        {mode === 'in'
          ? 'Sign in to continue exactly where you left off.'
          : 'Create your account for your organization’s People OS.'}
      </p>

      <form onSubmit={submit} className="mt-6 space-y-4">
        {mode === 'up' && (
          <InsetField
            label="Full name"
            type="text"
            value={name}
            onChange={setName}
            placeholder="Asha Verma"
            icon={<User size={15} />}
            autoComplete="name"
          />
        )}
        <InsetField
          label="Email address"
          type="email"
          value={email}
          onChange={setEmail}
          placeholder="you@company.com"
          icon={<Mail size={15} />}
          autoComplete="email"
        />
        <InsetField
          label="Password"
          type={showPw ? 'text' : 'password'}
          value={password}
          onChange={setPassword}
          placeholder="••••••••••"
          icon={<Lock size={15} />}
          autoComplete={mode === 'in' ? 'current-password' : 'new-password'}
          trailing={
            <button
              type="button"
              onClick={() => setShowPw(!showPw)}
              className="shrink-0 text-[#868175] transition hover:text-[#1c1c1a]"
              aria-label={showPw ? 'Hide password' : 'Show password'}
            >
              {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
          }
        />
        {error && (
          <div className="flex items-center gap-2 rounded-[14px] bg-[#dfdad0] px-4 py-2.5 font-body text-[12.5px] font-semibold text-rose-600 shadow-[inset_2px_2px_5px_rgba(165,160,150,0.55),inset_-2px_-2px_5px_rgba(255,255,255,0.85)]">
            <AlertCircle size={14} className="shrink-0" /> {error}
          </div>
        )}
        <button
          type="submit"
          disabled={busy}
          className="lx-stagger group flex h-12 w-full items-center justify-center gap-2.5 rounded-[14px] bg-[#4a7859] font-body text-[12.5px] font-bold uppercase tracking-[0.18em] text-white shadow-[0_8px_20px_rgba(45,80,58,0.32),inset_0_1px_1px_rgba(255,255,255,0.25)] transition hover:bg-[#3f674c] active:scale-[0.99] disabled:opacity-60"
        >
          {busy ? 'One moment…' : mode === 'in' ? 'Enter workspace' : 'Create account'}
          <ArrowRight size={15} className="transition-transform group-hover:translate-x-1" />
        </button>
      </form>

      {/* OR groove */}
      <div className="lx-stagger my-4 flex items-center gap-3">
        <span className="h-[2px] flex-1 rounded-full bg-[#dfdad0] shadow-[inset_1px_1px_2px_rgba(165,160,150,0.55),inset_-1px_-1px_2px_rgba(255,255,255,0.9)]" />
        <span className="font-body text-[9.5px] font-bold uppercase tracking-[0.25em] text-[#9c968a]">
          or
        </span>
        <span className="h-[2px] flex-1 rounded-full bg-[#dfdad0] shadow-[inset_1px_1px_2px_rgba(165,160,150,0.55),inset_-1px_-1px_2px_rgba(255,255,255,0.9)]" />
      </div>

      {googleBtn}

    </>
  );

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#eae6dc]">
      {/* ===== Form column (desktop) — swaps sides with the flap ===== */}
      <div
        className={`absolute inset-y-0 hidden w-[55%] lg:block ${
          side === 'right' ? 'left-0' : 'right-0'
        }`}
      >
        <div
          className={`flex h-full flex-col justify-center overflow-y-auto ${
            side === 'left' ? 'pl-28 xl:pl-44 pr-10' : 'px-12 xl:px-24'
          } ${staggerCls}`}
        >
          <div className={`w-full max-w-[390px] ${side === 'left' ? 'ml-auto mr-12 xl:mr-20' : ''}`}>{formCore}</div>
        </div>
      </div>

      {/* ===== Flap (raised accent slab, clip-path sweep) ===== */}
      <div
        className={`lx-flap hidden lg:block ${
          side === 'right' ? 'rest-right' : 'rest-left'
        } ${covering ? 'covering' : ''}`}
      >
        <div
          className={`absolute inset-y-0 flex w-[42%] flex-col justify-center ${
            side === 'right' ? 'right-0 pl-6 pr-12 xl:pr-20' : 'left-0 pl-12 pr-6 xl:pl-20'
          } ${staggerCls}`}
        >
          {brand(true)}
          <h2 className="lx-stagger font-display text-[34px] xl:text-[38px] font-medium leading-[1.18] text-white">
            {mode === 'in' ? (
              <>
                The quiet luxury of <em className="italic text-[#c5ea9d]">effortless HR.</em>
              </>
            ) : (
              <>
                Begin your <em className="italic text-[#c5ea9d]">membership.</em>
              </>
            )}
          </h2>
          <p className="lx-stagger mt-3.5 max-w-md font-body text-[13.5px] leading-relaxed text-white/70">
            {mode === 'in'
              ? 'Attendance, payroll, people and structure — curated into one serene workspace.'
              : 'Early access, private onboarding and a workspace tailored to your organization.'}
          </p>
          <button
            type="button"
            onClick={toggleForm}
            className="lx-stagger mt-8 w-fit rounded-full border border-white/20 bg-white/[0.12] px-7 py-3 font-body text-[11px] font-bold uppercase tracking-[0.2em] text-white shadow-[0_6px_20px_rgba(0,0,0,0.25),inset_0_1px_1px_rgba(255,255,255,0.25)] backdrop-blur-md transition hover:bg-white/[0.18] active:scale-[0.97]"
          >
            {mode === 'in' ? 'Create an account' : 'Sign in instead'}
          </button>
        </div>
      </div>

      {/* ===== Mobile: single full-screen column ===== */}
      <div
        className={`flex min-h-screen items-center justify-center overflow-y-auto px-5 py-8 lg:hidden bg-[#eae6dc] ${staggerCls}`}
      >
        <div className="w-full max-w-[380px]">
          {formCore}
          <p className="lx-stagger mt-5 text-center font-body text-[12.5px] text-[#787368]">
            {mode === 'in' ? 'New to Aviary?' : 'Already a member?'}{' '}
            <button
              type="button"
              onClick={() => {
                setMode(mode === 'in' ? 'up' : 'in');
                setError('');
              }}
              className="font-bold text-[#3e6045] underline underline-offset-4"
            >
              {mode === 'in' ? 'Create an account' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
