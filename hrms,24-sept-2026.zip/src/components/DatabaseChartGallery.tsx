import { useEffect, useState } from 'react';
import Chart, { type ChartDatum, type ChartKind, type StackedSeries, type CalendarDay, type SankeyLink, type GanttTask, type ScatterPoint, type StreamEvent } from '../shared/Charts';
import { api } from '../lib/api';
import { ChartSkeleton } from '../shared/primitives';

export interface GalleryPayload {
  title: string; defaultKind: ChartKind; defaultDim?: '2d' | '3d'; height?: number;
  data?: ChartDatum[]; categories?: string[]; series?: StackedSeries[];
  days?: CalendarDay[]; links?: SankeyLink[]; tasks?: GanttTask[]; scatter?: ScatterPoint[]; streamEvents?: StreamEvent[];
}
export interface GalleryRecord { id: number; name: string; payload: GalleryPayload }

export default function DatabaseChartGallery() {
  const [charts, setCharts] = useState<GalleryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const load = () => {
    setLoading(true); setError('');
    api<GalleryRecord[]>('chart-data').then(setCharts).catch(e => setError(e.message)).finally(() => setLoading(false));
  };
  useEffect(load, []);
  if (loading) return <div className="grid gap-5 lg:grid-cols-3"><ChartSkeleton height={240} /><ChartSkeleton height={240} /><ChartSkeleton height={240} /></div>;
  if (error) return <div role="alert" className="tk-card p-5 text-rose-600">{error} <button className="underline" onClick={load}>Retry</button></div>;
  return <div className="mb-6 grid min-w-0 grid-cols-1 gap-5 lg:grid-cols-3 lg:grid-flow-row-dense">{charts.filter(c => c.name !== 'pipeline' && c.payload.defaultKind !== 'radialbarclassic').map(chart => (
    <div key={chart.id} className={['sankey', 'sankey3d', 'calendarpie', 'gantt', 'scatter', 'stream', 'streamdyn', 'orgchart', 'timeline', 'radialbar', 'radialbars'].includes(chart.payload.defaultKind) ? 'min-w-0 lg:col-span-3' : 'min-w-0'}>
      <Chart {...chart.payload} />
    </div>
  ))}</div>;
}
