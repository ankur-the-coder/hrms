/**
 * Dataset-agnostic river-stream constructor.
 *
 * The Olympic 3D streamgraph (ThreeStreamgraph + streamModel) is a
 * volumetric port of one specific HTML reference and is left untouched.
 * This module is the reusable "river language" used by the 2D canvas
 * stream painter (`streamGeom` → `paintChart`) and by any future dataset:
 * ThemeRiver stacking, onset-order, zero-column pinch, rounded noses.
 *
 * See streamGraph.txt for the full analysis.
 */

export interface RiverLayer {
  name: string;
  color: string;
  values: number[];
}

export interface RiverStream {
  layers: RiverLayer[];
  labels: string[];
  xs: number[];
  /** bound[k][j]: pixel y of the k-th stack boundary (0 = bottom silhouette) at column j */
  bound: number[][];
  /** drawing order (inside-out around the centre) */
  order: number[];
  posOf: number[];
  padT: number;
  padB: number;
  plotW: number;
  plotH: number;
  midY: number;
  totals: number[];
}

export interface RiverOpts {
  padT?: number;
  padL?: number;
  padR?: number;
  padB?: number;
}

/**
 * Build a ThemeRiver stream from ANY aligned multi-series table.
 *
 * Contract:
 *  - `layers[i].values[j]` is the mass of series i at period j (0 = absent).
 *  - Join / leave / rejoin is expressed as zeros in the middle of a series
 *    (the river pinches shut on all-zero columns and reopens on return).
 *  - Onset order: a series that first becomes non-zero later enters at the
 *    river's EDGE, never cutting through the middle.
 *  - Symmetric baseline: the silhouette is centred on midY so the river
 *    breathes up and down instead of sitting on an axis.
 */
export function buildRiverStream(
  layers: RiverLayer[],
  labels: string[],
  W: number,
  H: number,
  opts: RiverOpts = {},
): RiverStream {
  const n = labels.length;
  const padT = opts.padT ?? 46;
  const padL = opts.padL ?? 14;
  const padR = opts.padR ?? 14;
  const padB = opts.padB ?? 28;
  const plotW = Math.max(8, W - padL - padR);
  const plotH = Math.max(40, H - padT - padB);
  const midY = padT + plotH / 2;
  const xs = labels.map((_, j) => padL + (plotW * j) / Math.max(1, n - 1));
  const totals = layers.map((l) => l.values.reduce((a, b) => a + b, 0));

  const onset = layers.map((l) => {
    const j = l.values.findIndex((v) => (v || 0) > 0);
    return j < 0 ? n : j;
  });
  const desc = layers.map((_, i) => i).sort((a, b) => (onset[a] - onset[b]) || (totals[b] - totals[a]));
  const order: number[] = [];
  desc.forEach((si, k) => { if (k % 2 === 0) order.push(si); else order.unshift(si); });

  const S = labels.map((_, j) => layers.reduce((a, l) => a + (l.values[j] || 0), 0));
  const maxS = Math.max(...S, 1);
  const sm = S.map((s, j) => {
    if (s <= 0) return 0;
    let a = 0, c = 0;
    for (let k = -2; k <= 2; k++) {
      const jj = j + k;
      if (jj >= 0 && jj < n && S[jj] > 0) { a += S[jj]; c++; }
    }
    const avg = c ? a / c : s;
    return avg * 0.55 + s * 0.45;
  });
  const scaleY = plotH / (maxS * 1.06);
  const Y = (v: number) => midY - v * scaleY;
  const bound: number[][] = [];
  const acc = sm.map((s) => -s / 2);
  bound.push(acc.map(Y));
  order.forEach((si) => {
    for (let j = 0; j < n; j++) acc[j] += layers[si].values[j] || 0;
    bound.push(acc.map(Y));
  });
  for (let pass = 0; pass < 2; pass++) {
    bound.forEach((b) => {
      const c = b.slice();
      for (let j = 1; j < n - 1; j++) b[j] = (c[j - 1] + c[j] * 2 + c[j + 1]) / 4;
    });
  }
  for (let j = 0; j < n; j++) {
    if (S[j] <= 0) bound.forEach((b) => { b[j] = midY; });
  }
  if (n > 3) {
    bound.forEach((b) => {
      b[0] = midY + (b[0] - midY) * 0.10;
      b[1] = midY + (b[1] - midY) * 0.45;
      b[n - 1] = midY + (b[n - 1] - midY) * 0.10;
      b[n - 2] = midY + (b[n - 2] - midY) * 0.45;
    });
  }
  const posOf = new Array(layers.length).fill(0);
  order.forEach((si, k) => { posOf[si] = k; });
  return {
    layers, labels, xs, bound, order, posOf,
    padT, padB, plotW, plotH, midY, totals: S.slice(),
  };
}
