import {
  type ChartDatum, type ChartKind, type Theme, type Ctx,
  themeColors, font, measureW, approxW, leaderLabel, funnelLabel, K, fitCtx,
} from './core';
import { SvgCtx } from './core';

interface LegendItem { label: string; color: string }
function legendLayout(meas: (s: string) => number, items: LegendItem[], W: number) {
  const padX = 14, gap = 18, dot = 13, rowH = 17;
  const rows: { x: number; y: number; it: LegendItem }[] = [];
  let x = padX, row = 0;
  items.forEach((it) => {
    const w = dot + meas(it.label);
    if (x + w > W - padX && x > padX) { x = padX; row++; }
    rows.push({ x, y: row * rowH, it });
    x += w + gap;
  });
  return { rows, height: items.length ? (row + 1) * rowH + 12 : 6 };
}
function scratchCtx(): Ctx { return document.createElement('canvas').getContext('2d')!; }

function drawComposition(ctx: Ctx, title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme, lay: ReturnType<typeof legendLayout>, headH: number) {
  if (title) {
    ctx.fillStyle = '#1c2620';
    let fs = 15;
    ctx.font = font(t, 700, fs, true);
    while (fs > 11 && measureW(ctx, title) > chartW - 24) { fs -= 1; ctx.font = font(t, 700, fs, true); }
    ctx.textAlign = 'left';
    ctx.fillText(fitCtx(ctx, title, chartW - 24), 12, 22);
  }
  ctx.save(); ctx.translate(0, headH);
  paintFn(ctx);
  ctx.restore();
  ctx.font = font(t, 600, 10.5);
  lay.rows.forEach(({ x, y, it }) => {
    const yy = headH + chartH + 14 + y;
    ctx.fillStyle = it.color;
    ctx.beginPath(); ctx.arc(x, yy - 3, 4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#39443d'; ctx.textAlign = 'left';
    ctx.fillText(it.label, x + 9, yy);
  });
}

/** PNG/PDF/Print bitmap — white background, theme fonts, full legend (wrapped, never truncated). */
export function composeExport(title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme = themeColors(true)): HTMLCanvasElement {
  const scale = 3;
  const sc = scratchCtx(); sc.font = font(t, 600, 10.5);
  const lay = legendLayout((s) => measureW(sc, s), legend, chartW);
  const headH = title ? 34 : 10;
  const W = chartW, H = headH + chartH + lay.height;
  const cv = document.createElement('canvas');
  cv.width = W * scale; cv.height = H * scale;
  const ctx = cv.getContext('2d')!;
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);
  drawComposition(ctx, title, chartW, chartH, legend, paintFn, t, lay, headH);
  return cv;
}

export function composeSvg(title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme = themeColors(true), fontCss = ''): string {
  const sc = scratchCtx(); sc.font = font(t, 600, 10.5);
  const lay = legendLayout((s) => measureW(sc, s), legend, chartW);
  const headH = title ? 34 : 10;
  const rec = new SvgCtx(chartW, headH + chartH + lay.height);
  rec.fontCss = fontCss;
  drawComposition(rec as unknown as Ctx, title, chartW, chartH, legend, paintFn, t, lay, headH);
  return rec.toString();
}

/** Export canvas size — wide enough that every label is complete. */
export function exportDims(kind: ChartKind, W: number, H: number, data: ChartDatum[], multi: boolean, cats: string[], m = 0): { W: number; H: number } {
  let Wx = Math.max(W, 720), Hx = Math.max(H, 360);
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  if (kind === 'pie' || kind === 'donut' || kind === 'toroid' || kind === 'polar') {
    const longest = Math.max(0, ...data.map((x) => approxW(leaderLabel(x, total))));
    Wx = Math.max(Wx, 2 * (longest + 40) + 280);
    // height follows the disc the width allows (a squashed 3D disc needs less)
    const Rw = Wx / 2 - (longest + 40);
    const need = m > 0.5 ? 2 * Rw * K + 46 + 70 : 2 * Rw + 56;
    Hx = Math.max(m > 0.5 ? 250 : 300, Math.round(need), Math.min(720, data.length * 14 + 120));
  } else if (kind === 'funnel' || kind === 'pyramid') {
    const longest = Math.max(0, ...data.map((x) => approxW(funnelLabel(x, total))));
    Wx = Math.max(Wx, longest + 40 + 440);
    Hx = Math.max(Hx, 380);
  } else if (kind === 'radar') {
    const labels = multi ? cats : data.map((x) => x.label);
    Wx = Math.max(Wx, 2 * Math.max(0, ...labels.map((l) => approxW(l))) + 380);
    Hx = Math.max(Hx, 400);
  } else if (kind === 'radialbar' || kind === 'radialbarclassic' || kind === 'radialbars') {
    // Mirror radialGeom's roomy/compact split: small-tile exports stay compact
    // (in-tube labels, no side gutter) while fullscreen exports reserve the
    // real measured label column. Either way the rings get a square-ish plot.
    const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
    const roomy = W >= 560;
    Wx = Math.max(Wx, roomy ? longest + 26 + 460 : 420);
    const side = Math.min(760, Math.max(roomy ? 430 : 360, data.length * 30 + 140));
    Hx = Math.max(Hx, side);
    Wx = Math.max(Wx, Hx + (roomy ? longest + 40 : 30));
  } else if (kind === 'stream') {
    Wx = Math.max(Wx, 860);
    Hx = Math.max(Hx, 420);
  } else {
    const labels = multi ? cats : data.map((x) => x.label);
    Wx = Math.max(Wx, 90 + labels.length * 16);
  }
  return { W: Math.round(Wx), H: Math.round(Hx) };
}
