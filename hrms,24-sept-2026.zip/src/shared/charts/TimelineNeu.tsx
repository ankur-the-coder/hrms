import { forwardRef, useImperativeHandle, useRef } from 'react';
import { Search, Handshake } from 'lucide-react';
import type { ThreeChartHandle } from '../three/ThreeSankey3D';
import type { ExportTheme } from '../three/exportUtils';

/* ============================================================
   Neumorphic Timeline — a faithful rebuild of the supplied reference
   (timelinechart.png): a serpentine blue→green track that snakes across
   three rows, numbered milestone discs alternating above / below the
   track, small station dots on the rail, and soft raised circular icons
   at the start and end. English copy only (the reference's Korean is
   replaced), and the reference's play cursor is intentionally omitted.

   Renders on a fixed 960×540 design canvas scaled to the tile via the SVG
   viewBox, so it always fits and exports crisply.
   ============================================================ */

export interface TimelineItem { n: number; label: string; detail?: string }

interface Props {
  items: TimelineItem[];
  theme: ExportTheme;
  dark?: boolean;
  startText?: string;
  endText?: string;
}

const VW = 960, VH = 540;
const ROWS = 3;
const X_LEFT = 230, X_RIGHT = 730;   // track horizontal extent
const Y_TOP = 180, ROW_GAP = 120;    // first row centreline + spacing

const trackY = (r: number) => Y_TOP + r * ROW_GAP;

const TimelineNeu = forwardRef<ThreeChartHandle, Props>(function TimelineNeu(
  { items, theme, dark, startText, endText }, ref,
) {
  const svgRef = useRef<SVGSVGElement>(null);

  const ink = dark ? '#e8eef6' : '#3a4757';
  const muted = dark ? '#93a2b5' : '#8a97a8';
  const surface = dark ? '#1b222b' : '#eef1f6';

  const list = (items && items.length ? items : Array.from({ length: 9 }, (_, i) => ({ n: i + 1, label: 'Enter details' }))).slice(0, 9);
  const N = list.length;
  const perRow = Math.max(1, Math.ceil(N / ROWS));
  const rowsUsed = Math.ceil(N / perRow);
  const stepX = perRow > 1 ? (X_RIGHT - X_LEFT) / (perRow - 1) : 0;

  // milestone positions along the snake (boustrophedon)
  const pts = list.map((it, i) => {
    const row = Math.floor(i / perRow);
    const inRow = i % perRow;
    const ltr = row % 2 === 0;
    const x = ltr ? X_LEFT + inRow * stepX : X_RIGHT - inRow * stepX;
    const y = trackY(row);
    const above = inRow % 2 === 0; // alternate disc above / below the rail
    return { ...it, x, y, above, row };
  });

  // serpentine track path with rounded U-turns
  let d = `M ${X_LEFT} ${trackY(0)}`;
  for (let r = 0; r < rowsUsed; r++) {
    const ltr = r % 2 === 0;
    const xEnd = ltr ? X_RIGHT : X_LEFT;
    d += ` L ${xEnd} ${trackY(r)}`;
    if (r < rowsUsed - 1) {
      const rad = ROW_GAP / 2;
      const sweep = ltr ? 1 : 0;
      d += ` A ${rad} ${rad} 0 0 ${sweep} ${xEnd} ${trackY(r + 1)}`;
    }
  }

  const startPt = pts[0] || { x: X_LEFT, y: trackY(0) };
  const endPt = pts[N - 1] || { x: X_RIGHT, y: trackY(rowsUsed - 1) };
  const fillId = dark ? 'tlNeuD' : 'tlNeuL';
  const shId = dark ? 'tlShD' : 'tlShL';

  const scene = (
    <>
      <defs>
        <linearGradient id="tlTrack" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#2f6fd0" />
          <stop offset="55%" stopColor="#2aa6a0" />
          <stop offset="100%" stopColor="#41c08a" />
        </linearGradient>
        <radialGradient id="tlNeuL" cx="38%" cy="30%" r="75%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="70%" stopColor="#f2f5fa" />
          <stop offset="100%" stopColor="#dde4ee" />
        </radialGradient>
        <radialGradient id="tlNeuD" cx="38%" cy="30%" r="75%">
          <stop offset="0%" stopColor="#3c4550" />
          <stop offset="100%" stopColor="#262d37" />
        </radialGradient>
        <filter id="tlShL" x="-60%" y="-60%" width="220%" height="220%">
          <feDropShadow dx="4" dy="6" stdDeviation="6" floodColor="#aab6c6" floodOpacity="0.55" />
          <feDropShadow dx="-3" dy="-4" stdDeviation="5" floodColor="#ffffff" floodOpacity="0.9" />
        </filter>
        <filter id="tlShD" x="-60%" y="-60%" width="220%" height="220%">
          <feDropShadow dx="4" dy="6" stdDeviation="7" floodColor="#12171f" floodOpacity="0.7" />
          <feDropShadow dx="-3" dy="-4" stdDeviation="5" floodColor="#49566a" floodOpacity="0.3" />
        </filter>
      </defs>

      {/* rail: soft base + gradient stroke */}
      <path d={d} fill="none" stroke={dark ? '#20272f' : '#e3e9f1'} strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" />
      <path d={d} fill="none" stroke="url(#tlTrack)" strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
      <path d={d} fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" transform="translate(0 -2.4)" />

      {/* station dots on the rail */}
      {pts.map((p) => (
        <g key={`dot${p.n}`}>
          <circle cx={p.x} cy={p.y} r={9} fill={dark ? '#2c333d' : '#ffffff'} filter={`url(#${shId})`} />
          <circle cx={p.x} cy={p.y} r={4.5} fill="url(#tlTrack)" />
        </g>
      ))}

      {/* stems + numbered milestone discs (alternating above/below) */}
      {pts.map((p) => {
        const discY = p.y + (p.above ? -64 : 64);
        return (
          <g key={`ms${p.n}`}>
            <line x1={p.x} y1={p.y} x2={p.x} y2={discY + (p.above ? 30 : -30)} stroke={dark ? '#3a4450' : '#cfd8e4'} strokeWidth={2} strokeDasharray="1 5" strokeLinecap="round" />
            <circle cx={p.x} cy={discY} r={28} fill={`url(#${fillId})`} filter={`url(#${shId})`} />
            <text x={p.x} y={discY + 6} textAnchor="middle" fontFamily={theme.fontDisplay} fontWeight={800} fontSize={17} fill={ink}>{String(p.n).padStart(2, '0')}</text>
            <text x={p.x} y={p.y + (p.above ? 34 : -26)} textAnchor="middle" fontFamily={theme.fontBody} fontWeight={600} fontSize={11} fill={muted}>{p.label}</text>
          </g>
        );
      })}

      {/* start icon (search + $) */}
      <g>
        <circle cx={startPt.x - 96} cy={startPt.y} r={40} fill={`url(#${fillId})`} filter={`url(#${shId})`} />
        <circle cx={startPt.x - 96} cy={startPt.y} r={40} fill="none" stroke={dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.85)'} strokeWidth={1.4} />
        <Search x={startPt.x - 96 - 15} y={startPt.y - 15} width={30} height={30} color="#2f6fd0" strokeWidth={1.8} />
      </g>

      {/* end icon (handshake / offering) */}
      <g>
        <circle cx={endPt.x + 96} cy={endPt.y} r={40} fill={`url(#${fillId})`} filter={`url(#${shId})`} />
        <circle cx={endPt.x + 96} cy={endPt.y} r={40} fill="none" stroke={dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.85)'} strokeWidth={1.4} />
        <Handshake x={endPt.x + 96 - 16} y={endPt.y - 16} width={32} height={32} color="#41c08a" strokeWidth={1.8} />
      </g>

      {/* side descriptions (English) */}
      <text x={70} y={startPt.y - 18} textAnchor="middle" fontFamily={theme.fontBody} fontWeight={600} fontSize={11.5} fill={muted}>
        <tspan x={70} dy="0">Build polished, on-brand</tspan>
        <tspan x={70} dy="16">infographic slides for any</tspan>
        <tspan x={70} dy="16">topic and design.</tspan>
      </text>
      <text x={VW - 78} y={endPt.y - 18} textAnchor="middle" fontFamily={theme.fontBody} fontWeight={600} fontSize={11.5} fill={muted}>
        <tspan x={VW - 78} dy="0">Build polished, on-brand</tspan>
        <tspan x={VW - 78} dy="16">infographic slides for any</tspan>
        <tspan x={VW - 78} dy="16">topic and design.</tspan>
      </text>
      {void startText}{void endText}
    </>
  );

  const buildSVG = (title: string) => {
    const inner = svgRef.current?.innerHTML || '';
    const head = title ? 40 : 0;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${VW}" height="${VH + head}" viewBox="0 0 ${VW} ${VH + head}"><rect width="${VW}" height="${VH + head}" fill="${dark ? '#1b222b' : '#ffffff'}"/>${title ? `<text x="24" y="28" font-family="${theme.fontDisplay}, sans-serif" font-weight="800" font-size="17" fill="${ink}">${title.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</text>` : ''}<g transform="translate(0 ${head})">${inner}</g></svg>`;
  };

  useImperativeHandle(ref, () => ({
    exportSVG: async (title: string) => `<?xml version="1.0" encoding="utf-8"?>\n${buildSVG(title)}`,
    exportPNG: async (title: string) => {
      const head = title ? 40 : 0;
      const raw = buildSVG(title);
      const blob = new Blob([raw], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      try {
        const img = await new Promise<HTMLImageElement>((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = url; });
        const scale = 2;
        const cv = document.createElement('canvas');
        cv.width = VW * scale; cv.height = (VH + head) * scale;
        const ctx = cv.getContext('2d')!;
        ctx.fillStyle = dark ? '#1b222b' : '#ffffff';
        ctx.fillRect(0, 0, cv.width, cv.height);
        ctx.drawImage(img, 0, 0, cv.width, cv.height);
        return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
      } finally { URL.revokeObjectURL(url); }
    },
    setZoom: () => { /* timeline has no zoom */ },
  }), [dark, theme]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="absolute inset-0 h-full w-full overflow-hidden" style={{ background: surface }}>
      <svg ref={svgRef} width="100%" height="100%" viewBox={`0 0 ${VW} ${VH}`} preserveAspectRatio="xMidYMid meet" style={{ display: 'block' }}>
        {scene}
      </svg>
    </div>
  );
});

export default TimelineNeu;
