import { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown, Check } from 'lucide-react';
import { Popover } from '../primitives';

export function MiniDrop({ label, items, onPick, icon, activeKey }: {
  label: string; items: { key: string; label: string; disabled?: boolean }[];
  onPick: (k: string) => void; icon?: React.ReactNode; activeKey?: string;
}) {
  const [open, setOpen] = useState(false);
  const anchorRef = useRef<HTMLDivElement>(null);
  const popRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number; minWidth: number } | null>(null);

  /* Measure the anchor on open and on scroll/resize so the portal menu
     tracks the button. Uses rAF-throttled viewport listeners. */
  useEffect(() => {
    if (!open) return;
    let raf = 0;
    const update = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const r = anchorRef.current?.getBoundingClientRect();
        if (!r) return;
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        const estH = Math.min(window.innerHeight * 0.6, items.length * 36 + 12);
        const below = vh - r.bottom - 8;
        const above = r.top - 8;
        // Flip upward when there is no room below but room above.
        const openUp = below < Math.min(estH, 180) && above > below;
        const menuH = openUp ? Math.min(estH, above) : Math.min(estH, Math.max(below, 120));
        const left = Math.min(Math.max(8, r.left), vw - 196);
        const top = openUp ? Math.max(8, r.top - 6 - menuH) : Math.min(r.bottom + 6, vh - 8 - 40);
        setPos({ left, top, minWidth: Math.max(180, r.width) });
      });
    };
    update();
    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true);
    return () => {
      window.removeEventListener('resize', update);
      window.removeEventListener('scroll', update, true);
      cancelAnimationFrame(raf);
    };
  }, [open, items.length]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (anchorRef.current?.contains(t)) return;
      if (popRef.current?.contains(t)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('mousedown', onDown);
    window.addEventListener('keydown', onKey, true);
    return () => {
      window.removeEventListener('mousedown', onDown);
      window.removeEventListener('keydown', onKey, true);
    };
  }, [open]);

  return (
    <div ref={anchorRef} className="relative">
      <button onClick={() => setOpen(!open)}
        className="tk-btn-ghost flex items-center gap-1.5 rounded-xl px-3 py-1.5 font-body text-[12px] font-bold">
        {icon} {label} <ChevronDown size={12} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {/* Portalled out of the chart card: the menu renders above ALL charts (and
          above the fullscreen overlays) instead of being clipped/covered by
          neighboring chart cards. `position: fixed` keeps it out of every
          scroll container so opening it can never introduce a page scrollbar.
          Target is the native-fullscreen element when one is active — a body
          portal would be invisible under native fullscreen. */}
      {open && createPortal(
        <div ref={popRef}
          style={{
            position: 'fixed',
            left: pos?.left ?? -9999,
            top: pos?.top ?? -9999,
            minWidth: pos?.minWidth ?? 180,
            maxWidth: 'calc(100vw - 16px)',
            backgroundColor: 'var(--t-surface)',
            zIndex: 9999,
            visibility: pos ? 'visible' : 'hidden',
          }}
          className="tk-pop max-h-[60vh] overflow-y-auto rounded-xl p-1 shadow-2xl border border-ink/15">
          {items.map((it) => (
            <button key={it.key} disabled={it.disabled}
              onClick={() => { setOpen(false); onPick(it.key); }}
              className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-left font-body text-[12.5px] font-semibold transition hover:bg-primary/10 disabled:opacity-35 ${activeKey === it.key ? 'text-primary font-bold bg-primary/5' : 'text-ink/80'}`}>
              {it.label}
              {activeKey === it.key && <Check size={13} className="shrink-0 text-primary" />}
            </button>
          ))}
        </div>,
        (typeof document !== 'undefined' && (document.fullscreenElement ?? document.body)) || document.body
      )}
    </div>
  );
}
