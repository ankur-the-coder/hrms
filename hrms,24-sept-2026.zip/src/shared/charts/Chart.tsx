import { useState, useRef, useEffect, useLayoutEffect, useCallback, useMemo, lazy, Suspense } from 'react';
import { createPortal } from 'react-dom';
import { Download, Box, Square, Eye, Minimize2, X } from 'lucide-react';
import { ChartSkeleton } from '../primitives';
import { radialOffset, distinctLineColor } from '../chartGeometry';
import type { ThreeChartHandle } from '../three/ThreeSankey3D';
import { RADIAL_PRESET_OPTIONS, radialLegendFor, type RadialPresetKey } from '../three/radialPresets';
import { STREAM_COUNTRIES, STREAM_EDITIONS, buildStreamModel, type StreamModel } from '../three/streamModel';
import { STREAM_DYN_DATASETS, EMPLOYEE_LIFECYCLE } from '../three/streamDatasets';
import type { OrgLink } from './OrgChartNeu';
import { fontFaceCss } from '../../theme/fonts';
import { MiniDrop } from './MiniDrop';
import { paintChart } from './paintChart';
import { composeExport, composeSvg, exportDims } from './compose';
import {
  type ChartDatum, type ChartKind, type StackedSeries, type CalendarDay, type SankeyLink,
  type GanttTask, type ScatterPoint, type StreamEvent, type Theme, type DrawCtx, type Ctx, type Hover,
  PALETTE, TOROID_GLOSS, activePalette, themeColors, font, shade, easeOut, easeInOut,
  downloadBlob, loadExcelJS, jpegToPdf, printCanvas, fmtNum, approxW, fontsReady, fontFamilies,
  circGeom, xyLayout, streamGeom, sankeyLayout, radialGeom, radialClassicGeom, funnelGeom, seriesDepth,
  NO_HOVER, ORBIT_REST, type Orbit3D, STREAM_SALARY_10Y, DEF_BODY, DEF_DISPLAY, ZY,
} from './core';

const ThreeSankey3D = lazy(() => import('../three/ThreeSankey3D'));
const ThreeStreamgraph = lazy(() => import('../three/ThreeStreamgraph'));
const ThreeReferenceRadialBar = lazy(() => import('../three/ThreeReferenceRadialBar'));
const ThreeRadialBarsCircular = lazy(() => import('../three/ThreeRadialBarsCircular'));
const ThreeOrgChart = lazy(() => import('./OrgChartNeu'));
const TimelineNeu = lazy(() => import('./TimelineNeu'));

function useThemeTick() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const handler = () => { setTick((t) => t + 1); timer = setTimeout(() => setTick((t) => t + 1), 720); };
    window.addEventListener('aviary:prefs', handler);
    return () => { window.removeEventListener('aviary:prefs', handler); clearTimeout(timer); };
  }, []);
  return tick;
}

const BASE_KINDS: { key: ChartKind; label: string; has3d: boolean }[] = [
  { key: 'bar', label: 'Bar', has3d: true },
  { key: 'line', label: 'Line', has3d: true },
  { key: 'area', label: 'Area', has3d: true },
  { key: 'pie', label: 'Pie', has3d: true },
  { key: 'donut', label: 'Donut', has3d: true },
  { key: 'toroid', label: 'Toroid Donut', has3d: true },
  { key: 'radar', label: 'Radar', has3d: true },
  { key: 'polar', label: 'Polar', has3d: true },
  { key: 'radialbar', label: 'Radial Bar', has3d: true },
  { key: 'radialbars', label: 'Radial Bars Circular', has3d: true },
  { key: 'dual', label: 'Dual Axes', has3d: true },
];
const EXTRA_KINDS: { key: ChartKind; label: string; has3d: boolean }[] = [
  { key: 'funnel', label: 'Funnel', has3d: true },
  { key: 'pyramid', label: 'Pyramid', has3d: true },
  { key: 'calendarpie', label: 'Calendar pie', has3d: false },
  { key: 'sankey', label: 'Sankey (Classic)', has3d: true },
  { key: 'sankey3d', label: 'Sankey (3D · Three.js)', has3d: true },
  { key: 'gantt', label: 'Gantt', has3d: true },
  { key: 'scatter', label: 'Scatter', has3d: true },
  { key: 'stream', label: 'Streamgraph', has3d: true },
  { key: 'streamdyn', label: 'Streamgraph (Dynamic)', has3d: true },
  { key: 'orgchart', label: 'Org chart', has3d: true },
  { key: 'timeline', label: 'Timeline', has3d: false },
];
const skeletonKind = (k: ChartKind): 'circle' | 'bars' | 'columns' | 'line' =>
  k === 'pie' || k === 'donut' || k === 'toroid' || k === 'polar' || k === 'radar' || k === 'radialbar' || k === 'radialbarclassic' || k === 'radialbars' || k === 'calendarpie' ? 'circle' : k === 'line' || k === 'area' || k === 'sankey' || k === 'sankey3d' || k === 'scatter' || k === 'stream' ? 'line' : k === 'funnel' || k === 'pyramid' || k === 'gantt' ? 'bars' : 'columns';


export interface ChartProps {
  data?: ChartDatum[];
  categories?: string[];
  series?: StackedSeries[];
  title?: string;
  defaultKind?: ChartKind;
  defaultDim?: '2d' | '3d';
  height?: number;
  loading?: boolean;
  extraKinds?: ('funnel' | 'pyramid' | 'gantt' | 'scatter' | 'stream')[];
  yLabel?: string;
  insight?: string[];
  isFullscreen?: boolean;
  /** calendar-pie: per-day values, one entry per `series` */
  days?: CalendarDay[];
  /** sankey: weighted flows */
  links?: SankeyLink[];
  /** gantt tasks */
  tasks?: GanttTask[];
  /** scatter points */
  scatter?: ScatterPoint[];
  /** streamgraph event flags */
  streamEvents?: StreamEvent[];
  /** Force the canvas ThemeRiver (reusable river language) instead of the Olympic Three.js stream. */
  streamCanvas?: boolean;
}

export default function Chart({
  data, categories, series, title, defaultKind = 'bar', defaultDim = '2d',
  height = 300, loading = false, extraKinds = [], yLabel, insight, isFullscreen = false, days, links, tasks, scatter, streamEvents,
  streamCanvas = false,
}: ChartProps) {
  const multi = !!(series && series.length && ((categories && categories.length) || defaultKind === 'calendarpie'));
  const themeTick = useThemeTick();
  const pal = useMemo(() => activePalette(), [themeTick]); // eslint-disable-line react-hooks/exhaustive-deps
  const sColors = useMemo(() => (series || []).map((s, i) => s.color || pal[i % pal.length]), [series, pal]);

  // Aggregate fallback data if user switches away from special chart types
  const singleData: ChartDatum[] = useMemo(() => {
    if (multi) return series!.map((s, i) => ({ label: s.name, value: s.values.reduce((a, b) => a + b, 0), color: sColors[i] }));
    if (data && data.length) return data;
    if (links && links.length) {
      const m = new Map<string, number>();
      links.forEach((l) => m.set(l.source, (m.get(l.source) || 0) + l.value));
      return [...m.entries()].map(([label, value], i) => ({ label, value, color: pal[i % pal.length] }));
    }
    if (days && days.length && series && series.length) {
      return series.map((s, i) => ({
        label: s.name,
        value: days.reduce((sum, d) => sum + (d.values[i] || 0), 0),
        color: s.color || pal[i % pal.length],
      }));
    }
    if (tasks && tasks.length) {
      return tasks.map((tk, i) => ({ label: tk.name, value: tk.progress ?? 100, color: tk.color || pal[i % pal.length] }));
    }
    if (scatter && scatter.length) {
      return scatter.slice(0, 16).map((pt, i) => ({ label: pt.label || `Point ${i + 1}`, value: pt.y, color: pt.color || pal[i % pal.length] }));
    }
    return [];
  }, [multi, series, data, sColors, links, days, tasks, scatter, pal]);


  // Context-aware KINDS dropdown list: genuine options only where suitable data exists
  const KINDS = useMemo(() => {
    const list: { key: ChartKind; label: string; has3d: boolean }[] = [];
    const baseKeys: ChartKind[] = ['bar', 'line', 'area', 'pie', 'donut', 'toroid'];
    baseKeys.forEach((k) => {
      const item = BASE_KINDS.find((b) => b.key === k);
      if (item) list.push(item);
    });

    if (singleData.length >= 3) {
      const rad = BASE_KINDS.find((b) => b.key === 'radar');
      const pol = BASE_KINDS.find((b) => b.key === 'polar');
      if (rad) list.push(rad);
      if (pol) list.push(pol);
    }
    if (singleData.length >= 2) {
      const rb = BASE_KINDS.find((b) => b.key === 'radialbar');
      if (rb) list.push(rb);
      const rbs = BASE_KINDS.find((k) => k.key === 'radialbars');
      if (rbs && !list.some((x) => x.key === 'radialbars')) list.push(rbs);
    }

    // Dual axes: visible only where genuine multi-series or >=2 data items exist
    const hasDualData = (series && series.length >= 2 && categories && categories.length > 0) || (singleData.length >= 2);
    if (hasDualData) {
      const dual = BASE_KINDS.find((b) => b.key === 'dual');
      if (dual && !list.some((x) => x.key === 'dual')) list.push(dual);
    }

    // Calendar pie: visible only where genuine daily data exists
    if (days && days.length > 0) {
      const cp = EXTRA_KINDS.find((k) => k.key === 'calendarpie');
      if (cp && !list.some((x) => x.key === 'calendarpie')) list.unshift(cp);
    }

    // Sankey: visible only where genuine link flow data exists — two
    // independent selectable kinds: the classic canvas chart (no Three.js)
    // and the Three.js-powered 3D-pro chart, both fed by the same `links`.
    if (links && links.length > 0) {
      const sk = EXTRA_KINDS.find((k) => k.key === 'sankey');
      if (sk && !list.some((x) => x.key === 'sankey')) list.unshift(sk);
      const sk3 = EXTRA_KINDS.find((k) => k.key === 'sankey3d');
      if (sk3 && !list.some((x) => x.key === 'sankey3d')) list.unshift(sk3);
    }

    // Gantt: visible only where genuine task timeline data exists
    if (tasks && tasks.length > 0) {
      const gt = EXTRA_KINDS.find((k) => k.key === 'gantt');
      if (gt && !list.some((x) => x.key === 'gantt')) list.unshift(gt);
    }

    // Scatter: visible only where genuine coordinate scatter data exists
    if (scatter && scatter.length > 0) {
      const sc = EXTRA_KINDS.find((k) => k.key === 'scatter');
      if (sc && !list.some((x) => x.key === 'scatter')) list.unshift(sc);
    }

    // Streamgraph: needs >=2 series over >=3 time columns (or >=3 items fallback)
    if ((series && series.length >= 2 && categories && categories.length >= 3) || singleData.length >= 3) {
      const st = EXTRA_KINDS.find((k) => k.key === 'stream');
      if (st && !list.some((x) => x.key === 'stream')) list.push(st);
    }

    // Dynamic 3D streamgraph: same data requirement as the classic stream —
    // plots ANY {series, categories} in the Olympic river-flow language.
    if (series && series.length >= 2 && categories && categories.length >= 3) {
      const sd = EXTRA_KINDS.find((k) => k.key === 'streamdyn');
      if (sd && !list.some((x) => x.key === 'streamdyn')) list.push(sd);
    }

    // Org chart: visible where genuine parent→child edge data exists (links).
    if (links && links.length > 0) {
      const oc = EXTRA_KINDS.find((k) => k.key === 'orgchart');
      if (oc && !list.some((x) => x.key === 'orgchart')) list.unshift(oc);
    }

    // Timeline: visible where there is a sequence of >=2 labelled items.
    if (singleData.length >= 2) {
      const tl = EXTRA_KINDS.find((k) => k.key === 'timeline');
      if (tl && !list.some((x) => x.key === 'timeline')) list.push(tl);
    }

    extraKinds.forEach((ek) => {
      const found = EXTRA_KINDS.find((k) => k.key === ek);
      if (found && !list.some((x) => x.key === ek)) list.push(found);
    });

    if (defaultKind !== 'radialbarclassic' && !list.some((x) => x.key === defaultKind)) {
      const fb = [...BASE_KINDS, ...EXTRA_KINDS].find((k) => k.key === defaultKind);
      if (fb) list.unshift(fb);
    }
    return list;
  }, [singleData.length, series, categories, days, links, tasks, scatter, extraKinds, defaultKind]);
  const [kind, setKind] = useState<ChartKind>(defaultKind === 'radialbarclassic' ? 'radialbar' : defaultKind);
  const [dim, setDim] = useState<'2d' | '3d'>(defaultDim);
  const meta = KINDS.find((k) => k.key === kind) || BASE_KINDS[0];
  const isSpecialFlow = kind === 'sankey' || kind === 'sankey3d' || kind === 'calendarpie';
  const effDim = meta.has3d ? dim : '2d';
  const colors = useMemo(() => singleData.map((x, i) => x.color || (kind === 'toroid' || kind === 'radialbars' ? TOROID_GLOSS[i % TOROID_GLOSS.length] : pal[i % pal.length])), [singleData, pal, kind]);

  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const [hoverSeg, setHoverSeg] = useState<{ c: number; s: number } | null>(null);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);
  const [full, setFull] = useState(false);
  /** Brief explicit "building" indicator for the Toroid Donut's first
   * paint (see the entrance-animation effect below) — separate from
   * `loading` (data fetch) and from the sweep-in reveal itself. */
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const progRef = useRef(0);
  const toroidRotRef = useRef(0);
  const idleRafRef = useRef(0);
  const dimRef = useRef(defaultDim === '3d' && meta.has3d ? 1 : 0);
  const rafRef = useRef(0);
  const dimRafRef = useRef(0);
  const hovRef = useRef<Hover>({ ...NO_HOVER });
  const hovRafRef = useRef(0);
  // True-3D camera orbit (Sankey 3D): drag to rotate like a modelled object.
  // Angles ease back to rest on release so the scene always settles readable.
  const orbitRef = useRef<Orbit3D>({ ...ORBIT_REST });
  const orbitTarget = useRef<Orbit3D>({ ...ORBIT_REST });
  const orbitRafRef = useRef(0);
  const dragRef = useRef<{ x: number; y: number; yaw: number; pitch: number; moved: boolean } | null>(null);
  const aspectRef = useRef(height / 560);
  // theme tokens are read once per theme change, never per animation frame
  const themeRef = useRef<Theme>(themeColors());
  useEffect(() => { themeRef.current = themeColors(); }, [themeTick]);

  // Three.js chart handles (Sankey 3D · Radial bar 2D/3D · Streamgraph 3D · Radial Bars Circular)
  const threeSankeyRef = useRef<ThreeChartHandle>(null);
  const threeRadialRef = useRef<ThreeChartHandle>(null);
  const threeStreamRef = useRef<ThreeChartHandle>(null);
  const threeRBCRef = useRef<ThreeChartHandle>(null);
  // Which of the reference Radial Bar's three built-in presets is showing —
  // switched via the "Version" dropdown next to the Kind dropdown, below.
  const [radialPreset, setRadialPreset] = useState<RadialPresetKey>('olympic');
  const [toroidSpin, setToroidSpin] = useState(false);
  const toroidSpinRef = useRef(false);
  useEffect(() => { toroidSpinRef.current = toroidSpin; }, [toroidSpin]);
  const exportTheme = useMemo(() => ({
    ink: themeRef.current.ink, fontBody: themeRef.current.fontBody || DEF_BODY, fontDisplay: themeRef.current.fontDisplay || DEF_DISPLAY,
  }), [themeTick]); // eslint-disable-line react-hooks/exhaustive-deps
  // `radialbar` and `sankey3d` are ALWAYS Three.js (both their 2D and 3D
  // views live inside the same WebGL scene so dimensions never jump on
  // toggle) — `sankey` stays pure canvas, no Three.js.
  const isThreeRadial = kind === 'radialbar';
  const isThreeSankeyPro = kind === 'sankey3d';
  // Streamgraph (Fix #6): the WebGL river from Streamgraph3DTest.html serves
  // BOTH 2D and 3D views (camera preset morph + ribbon Z-spread 1→0), so the
  // canvas painter underneath is kept only as the no-WebGL/export fallback.
  // Radial Bars Circular: full port of 3dRadialBarChart.html — always
  // Three.js in both dims (2D = the reference's top-down twin view).
  const isThreeStream = kind === 'stream' && !streamCanvas;
  // Dynamic 3D streamgraph — same WebGL river engine, fed a model built from
  // the live {series, categories} instead of the static Olympic dataset.
  const isThreeStreamDyn = kind === 'streamdyn';
  // Org chart — neumorphic SVG hierarchy card layout with 2D⇄3D framing.
  const isThreeOrg = kind === 'orgchart';
  // Timeline — neumorphic serpentine SVG milestone track (2D only).
  const isTimeline = kind === 'timeline';
  const isThreeRBC = kind === 'radialbars';
  const canvasHidden = isThreeRadial || isThreeSankeyPro || isThreeStream || isThreeStreamDyn || isThreeOrg || isTimeline || isThreeRBC;

  // Dynamic streamgraph — a "Dataset" dropdown switches between the chart's
  // own payload ('data') and 5+ built-in test datasets, so the dynamic river
  // can be exercised against many shapes without leaving the page.
  const [streamDynKey, setStreamDynKey] = useState<string>('data');
  const streamDynOptions = useMemo(
    () => [{ key: 'data', label: 'From this dataset' }, ...STREAM_DYN_DATASETS.map((d) => ({ key: d.key, label: d.label }))],
    [],
  );
  // Resolve which {categories, series, events} feed the dynamic river.
  const streamDynSource = useMemo(() => {
    if (streamDynKey !== 'data') {
      const ds = STREAM_DYN_DATASETS.find((d) => d.key === streamDynKey);
      if (ds) return { categories: ds.categories, series: ds.series, events: ds.events };
    }
    if (series && series.length >= 2 && categories && categories.length >= 2) {
      return {
        categories,
        series: series.map((s, i) => ({ name: s.name, values: s.values, color: s.color || TOROID_GLOSS[i % TOROID_GLOSS.length] })),
        events: (streamEvents || []).map((e) => ({ at: e.at, label: e.label, detail: e.detail })),
      };
    }
    // safe fallback so the chart always has content
    return { categories: EMPLOYEE_LIFECYCLE.categories, series: EMPLOYEE_LIFECYCLE.series, events: EMPLOYEE_LIFECYCLE.events };
  }, [streamDynKey, series, categories, streamEvents]);
  const streamDynModel = useMemo<StreamModel | undefined>(() => {
    if (kind !== 'streamdyn') return undefined;
    return buildStreamModel({
      categories: streamDynSource.categories,
      series: streamDynSource.series.map((s, i) => ({ name: s.name, values: s.values, color: s.color || TOROID_GLOSS[i % TOROID_GLOSS.length] })),
      annotations: (streamDynSource.events || []).map((e) => ({ atIndex: e.at, title: e.label, text: e.detail || '' })),
    });
  }, [kind, streamDynSource]);

  // Org edges (parent → child) for the org chart, derived from `links`.
  const orgLinks = useMemo<OrgLink[]>(() => (links || []).map((l) => ({ source: l.source, target: l.target, value: l.value })), [links]);
  // Timeline milestones, derived from the chart's labelled data items.
  const timelineItems = useMemo(
    () => singleData.map((x, i) => ({ n: i + 1, label: x.label, detail: (x as { detail?: string }).detail })),
    [singleData],
  );
  // Tier legend for the org chart (colours match ThreeOrgChart's per-depth palette).
  const orgLegend = useMemo(() => {
    if (kind !== 'orgchart' || !links || !links.length) return [];
    const parentOf = new Map<string, string>();
    links.forEach((l) => parentOf.set(l.target, l.source));
    const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
    const depthOf = (n: string): number => { let d = 0, cur = n; const seen = new Set<string>(); while (parentOf.has(cur) && !seen.has(cur)) { seen.add(cur); cur = parentOf.get(cur)!; d++; } return d; };
    const maxD = Math.max(...names.map(depthOf), 0);
    return Array.from({ length: maxD + 1 }, (_, d) => ({ label: `Tier ${d + 1}`, color: pal[d % pal.length] }));
  }, [kind, links, pal]);

  const dataSig = useMemo(() => JSON.stringify({
    d: singleData.map((x) => [x.label, x.value]),
    s: (series || []).map((s) => s.values), c: categories, k: days, l: links, t: tasks, sc: scatter, ev: streamEvents,
  }), [singleData, series, categories, days, links, tasks, scatter, streamEvents]);

  const buildCtx = useCallback((W: number, H: number, p: number, m: number, hov: Hover, forExport = false): DrawCtx => ({
    W, H, t: forExport ? themeColors(true) : themeRef.current, p, m, hov,
    data: singleData, colors, multi,
    cats: categories || [], series: series || [], sColors, yLabel,
    full: isFullscreen || forExport,
    bg: forExport ? '#ffffff' : undefined,
    days, links, tasks, scatter,
    orbit: kind === 'sankey' ? { ...orbitRef.current } : undefined,
    streamEvents,
    toroidRot: kind === 'toroid' && !forExport ? toroidRotRef.current : 0,
  }), [singleData, colors, multi, categories, series, sColors, yLabel, isFullscreen, days, links, tasks, scatter, kind, effDim, streamEvents]);

  const paint = useCallback((ctx: Ctx, W: number, H: number, p: number, m: number, hov: Hover, forExport = false) => {
    paintChart(ctx, kind, buildCtx(W, H, p, m, hov, forExport));
  }, [buildCtx, kind]);

  const render = useCallback(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth, H = cv.clientHeight;
    if (W <= 0 || H <= 0) { requestAnimationFrame(() => render()); return; }
    aspectRef.current = H / W;
    const bw = Math.round(W * dpr), bh = Math.round(H * dpr);
    if (cv.width !== bw || cv.height !== bh) { cv.width = bw; cv.height = bh; }
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    paint(ctx, W, H, easeOut(progRef.current), dimRef.current, hovRef.current);
  }, [paint]);

  /* entrance animation — data/kind change only (NOT dim) */
  useEffect(() => {
    if (loading) return;
    cancelAnimationFrame(rafRef.current);
    cancelAnimationFrame(idleRafRef.current);
    progRef.current = 0;
    toroidRotRef.current = 0;
    dimRef.current = effDim === '3d' ? 1 : 0;
    let t0 = performance.now();
    const tick = (now: number) => {
      progRef.current = Math.min(1, (now - t0) / 750);
      render();
      if (progRef.current < 1) rafRef.current = requestAnimationFrame(tick);
    };
    // Toroid: Segment Cascade from toroid_donut_cascade.html — 1500ms
    // staggered outBack pops, then idle spin (dRot += 0.003 / frame).
    if (kind === 'toroid') {
      const tickCascade = (now: number) => {
        progRef.current = Math.min(1, (now - t0) / 1500);
        render();
        if (progRef.current < 1) rafRef.current = requestAnimationFrame(tickCascade);
        else {
          const idle = () => {
            if (toroidSpinRef.current && hovRef.current.idx === null) toroidRotRef.current += 0.003;
            if (toroidSpinRef.current || hovRef.current.amt > 0.01 || hovRef.current.idx !== null) render();
            idleRafRef.current = requestAnimationFrame(idle);
          };
          idleRafRef.current = requestAnimationFrame(idle);
        }
      };
      rafRef.current = requestAnimationFrame(tickCascade);
      return () => { cancelAnimationFrame(rafRef.current); cancelAnimationFrame(idleRafRef.current); };
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(rafRef.current); cancelAnimationFrame(idleRafRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, dataSig, loading]);

  /* STALE-TILE FIX: while a Three.js-hosted kind (radialbar / sankey3d /
     stream / radialbars) is active, this 2D canvas sits at opacity:0 and
     the entrance-animation effect above may have last painted it for a
     DIFFERENT (now-stale) kind, or not at all. When leaving one of those
     kinds — i.e. `canvasHidden` flips from true to false and the canvas
     is about to fade back to opacity:1 — force a few fresh animation
     frames once the browser has committed the new layout, so the first
     visible frame is guaranteed to be a real, current paint of whatever
     kind is now selected rather than a leftover/blank one.
     BUG FIX: an earlier version of this effect (a) depended on `render`
     itself, which is a NEW function reference on almost every relevant
     state change, so it re-ran far more often than just the true→false
     transition it was meant to catch, and (b) forced a full DOM remount
     of the <canvas> (via a `key` bump) to "guarantee" a clean paint. That
     remount could commit AFTER the entrance-animation effect's own
     750ms repaint loop (below) had already finished — swapping in a
     brand-new BLANK canvas with nothing left to ever repaint it, which is
     exactly the "switching away from Radial Bar leaves the tile blank"
     bug. Rendering is idempotent and always reads the canvas's LIVE size
     on every call, so no remount is needed — this now only depends on the
     primitive `canvasHidden`/`loading` booleans (never re-firing on
     unrelated renders) and reads the latest `render` via a ref instead of
     a dependency, so it fires exactly once per real transition. */
  const renderRef = useRef(render);
  renderRef.current = render;
  const prevHiddenRef = useRef(canvasHidden);
  useEffect(() => {
    const wasHidden = prevHiddenRef.current;
    prevHiddenRef.current = canvasHidden;
    if (loading || canvasHidden || !wasHidden) return;
    let raf = requestAnimationFrame(() => {
      renderRef.current();
      raf = requestAnimationFrame(() => {
        renderRef.current();
        raf = requestAnimationFrame(() => renderRef.current());
      });
    });
    return () => cancelAnimationFrame(raf);
  }, [canvasHidden, loading]);

  /* RADIAL-BAR → PIE/DONUT SWITCH FIX: Three.js overlays (radialbar /
     stream / sankey3d / radialbars) sit on top of this canvas and the
     canvas itself was faded to opacity 0. When the user picks pie/donut
     (or any canvas kind) the overlay unmounts and the canvas fades back
     in — but if the first visible frame is a 0×0 bitmap or a leftover
     clear from the radialbar early-return, the tile reads blank. Paint
     SYNCHRONOUSLY (layout effect, before the browser paints) whenever
     the canvas is the live renderer, and force a bitmap resize so
     render() rebuilds from the live client size. */
  useLayoutEffect(() => {
    if (loading || canvasHidden) return;
    const cv = canvasRef.current;
    if (cv) {
      cv.width = 0;
      cv.height = 0;
    }
    renderRef.current();
  }, [kind, canvasHidden, loading, dataSig]);

  /* 2D ⇄ 3D morph — ease-in-out, duration scales gently with canvas size */
  useEffect(() => {
    if (loading) return;
    const target = effDim === '3d' ? 1 : 0;
    if (Math.abs(dimRef.current - target) < 0.001) return;
    cancelAnimationFrame(dimRafRef.current);
    const from = dimRef.current;
    const t0 = performance.now();
    const W = canvasRef.current?.clientWidth || 600;
    const DUR = 480 + Math.min(240, Math.max(0, W - 600) * 0.4);
    const tick = (now: number) => {
      const t = Math.min(1, (now - t0) / DUR);
      dimRef.current = from + (target - from) * easeInOut(t);
      render();
      if (t < 1) dimRafRef.current = requestAnimationFrame(tick);
    };
    dimRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(dimRafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effDim, loading]);

  /* smooth hover animation */
  useEffect(() => {
    const target = hoverIdx !== null || hoverSeg !== null;
    const h = hovRef.current;
    if (target && (hoverIdx !== h.idx || JSON.stringify(hoverSeg) !== JSON.stringify(h.seg))) {
      h.idx = hoverIdx; h.seg = hoverSeg;
      if (target) h.amt = Math.min(h.amt, 0.35);
    }
    cancelAnimationFrame(hovRafRef.current);
    // Toroid hover used to feel sluggish: its frame is the heaviest in the
    // family, so the generic ease rate under-delivered. Eased further still
    // (now ~3x the generic rate) so the pop settles in noticeably fewer
    // frames — paired with the trig-table memoization in paintTube above,
    // which removes real per-frame CPU work from every one of those frames.
    const hovRate = kind === 'toroid' ? 0.62 : 0.22;
    const tick = () => {
      const goal = target ? 1 : 0;
      const diff = goal - h.amt;
      if (Math.abs(diff) < 0.02) {
        h.amt = goal;
        if (!target) { h.idx = null; h.seg = null; }
        if (progRef.current >= 1) render();
        return;
      }
      h.amt += diff * hovRate;
      if (progRef.current >= 1) render();
      hovRafRef.current = requestAnimationFrame(tick);
    };
    hovRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(hovRafRef.current);
  }, [hoverIdx, hoverSeg, render]);

  useEffect(() => { if (progRef.current >= 1) render(); }, [themeTick, render]);
  useEffect(() => {
    const cv = canvasRef.current;
    const on = () => render();
    window.addEventListener('resize', on);
    let ro: ResizeObserver | null = null;
    if (cv && typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => render());
      ro.observe(cv);
    }
    return () => { window.removeEventListener('resize', on); ro?.disconnect(); };
  }, [render, loading]);

  /* hit testing — shares the exact layout helpers used by the painter */
  /* orbit easing: angles glide toward the target every frame while settling */
  useEffect(() => {
    if (kind !== 'sankey' || effDim !== '3d') return;
    cancelAnimationFrame(orbitRafRef.current);
    const tick = () => {
      const o = orbitRef.current, tg = orbitTarget.current;
      const dy = tg.yaw - o.yaw, dp = tg.pitch - o.pitch;
      if (Math.abs(dy) < 0.0004 && Math.abs(dp) < 0.0004) return;
      o.yaw += dy * 0.12; o.pitch += dp * 0.12;
      if (progRef.current >= 1) render();
      orbitRafRef.current = requestAnimationFrame(tick);
    };
    orbitRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(orbitRafRef.current);
  }, [kind, effDim, render]);

  /* Drag-orbit is no longer used by any canvas chart kind: the classic
     Sankey is now a fixed isometric painter (ported from the agon
     reference) and the Three.js Sankey rotates via its own OrbitControls
     inside <ThreeSankey3D/>. Kept as no-op stubs so the mouse handlers
     wired on the canvas element stay harmless. */
  const orbitDown = (_e: React.MouseEvent) => {};
  const orbitMove = (_e: React.MouseEvent) => {};
  const orbitUp = () => {};

  const hit = (e: React.MouseEvent) => {
    const cv = canvasRef.current;
    if (!cv || (!singleData.length && !isSpecialFlow && !tasks?.length && !scatter?.length)) return;
    const r = cv.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    const W = r.width, H = r.height;
    const m = dimRef.current;
    const total = singleData.reduce((s, x) => s + x.value, 0) || 1;
    let idx: number | null = null;
    let seg: { c: number; s: number } | null = null;
    let text = '';

    if (kind === 'sankey') {
      // Classic (canvas, no Three.js) hit test — node hover PLUS flow-ribbon
      // hover. The ribbon probe samples the rendered bezier edges (the same
      // curves the painter fills) so the highlight lands exactly on the art.
      const lay = sankeyLayout((links || []).filter((l) => l.value > 0 && l.source !== l.target), W, H, isFullscreen ? 200 : Math.min(150, W * 0.22));
      if (lay) {
        lay.nodes.forEach((n, i) => { if (mx >= n.x - 4 && mx <= n.x + lay.nodeW + 4 && my >= n.y && my <= n.y + n.h) idx = i; });
        if (idx !== null) {
          const n = lay.nodes[idx];
          text = `${n.name}: ${fmtNum(n.value)}`;
        } else {
          // flow pass: point-in-ribbon against the painter's bezier ribbons
          const cleanLinks = (links || []).filter((l) => l.value > 0 && l.source !== l.target);
          for (let fi = 0; fi < lay.flows.length; fi++) {
            const f = lay.flows[fi];
            const src = lay.nodes[f.si], tgt = lay.nodes[f.ti];
            const x0 = src.x + lay.nodeW, x1 = tgt.x, mid = (x0 + x1) / 2;
            if (mx < x0 - 2 || mx > x1 + 2) continue;
            // invert the x-bezier to find t (monotonic in x): bisection
            let lo = 0, hi = 1;
            for (let it = 0; it < 24; it++) {
              const tt = (lo + hi) / 2, u = 1 - tt;
              const bx = u * u * u * x0 + 3 * u * u * tt * mid + 3 * u * tt * tt * mid + tt * tt * tt * x1;
              if (bx < mx) lo = tt; else hi = tt;
            }
            const tt = (lo + hi) / 2, u = 1 - tt;
            const edge = (from: number, to: number) =>
              u * u * u * from + 3 * u * u * tt * from + 3 * u * tt * tt * to + tt * tt * tt * to;
            const topY = edge(f.sy0, f.ty0), botY = edge(f.sy1, f.ty1);
            if (my >= topY - 2 && my <= botY + 2) {
              seg = { c: fi, s: -2 }; // s === -2 marks "classic sankey flow"
              const L = cleanLinks[fi];
              text = L ? `${L.source} → ${L.target}: ${fmtNum(L.value)}` : '';
              break;
            }
          }
        }
      }
      setHoverIdx(idx); setHoverSeg(seg); setTip(idx !== null || seg ? { x: mx, y: my, text } : null);
      return;
    }
    if (kind === 'calendarpie') {
      const ds = days || [];
      if (ds.length && series?.length) {
        const first = new Date(Math.min(...ds.map((x) => new Date(x.date + 'T00:00:00').getTime())));
        const ms = new Date(first.getFullYear(), first.getMonth(), 1), me = new Date(first.getFullYear(), first.getMonth() + 1, 0);
        const padL = 12, padR = 12, padT = 34, padB = 10, cols = 7;
        const lead = (ms.getDay() + 6) % 7, rows = Math.ceil((lead + me.getDate()) / cols);
        const cell = Math.min((W - padL - padR) / cols, (H - padT - padB) / rows);
        const gx = padL + ((W - padL - padR) - cell * cols) / 2, gy = padT + ((H - padT - padB) - cell * rows) / 2;
        const c = Math.floor((mx - gx) / cell), rw = Math.floor((my - gy) / cell);
        const dnum = rw * cols + c - lead + 1;
        if (c >= 0 && c < cols && rw >= 0 && dnum >= 1 && dnum <= me.getDate()) {
          const iso = `${ms.getFullYear()}-${String(ms.getMonth() + 1).padStart(2, '0')}-${String(dnum).padStart(2, '0')}`;
          const vals = ds.find((x) => x.date === iso)?.values;
          if (vals) {
            const cx0 = gx + c * cell + cell / 2, cy0 = gy + rw * cell + cell / 2 + cell * 0.05;
            const rad = Math.hypot(mx - cx0, my - cy0);
            if (rad <= cell * 0.36 + 4) {
              const tot = vals.reduce((a2, b) => a2 + b, 0) || 1;
              let ang = Math.atan2(my - cy0, mx - cx0) + Math.PI / 2; ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
              let acc = 0;
              for (let si = 0; si < vals.length; si++) { acc += (vals[si] / tot) * Math.PI * 2; if (ang <= acc) { seg = { c: dnum, s: si }; break; } }
              if (seg) text = `${new Date(iso + 'T00:00:00').toLocaleDateString('en', { day: 'numeric', month: 'short' })} · ${series![seg.s].name}: ${vals[seg.s]}`;
            }
          }
        }
      }
      setHoverIdx(null); setHoverSeg(seg); setTip(seg ? { x: mx, y: my, text } : null);
      return;
    }

    if (kind === 'toroid') {
      // Toroid hover: mirror the PAINTER's torus (NOT the pie disc).
      // circGeom + tube: R = g.R*0.78, r = R*0.34, tilted by 0.52·m.
      // STRICT band test: hover fires ONLY when the cursor sits on the
      // tube itself (R±r in unsquashed space, +2px AA tolerance). Blank
      // centre, label gutters and corners must never trigger a segment.
      const tg = circGeom(W, H, 0, singleData, isFullscreen);
      const tR = Math.max(40, tg.R * 0.78);
      const tr = Math.max(14, tR * 0.34);
      const tTilt = 0.52 * m;
      const tCos = Math.cos(tTilt), tSin = Math.sin(tTilt);
      const cur = hovRef.current;
      // sticky: while a piece is eased open, test its CURRENT inflated tube
      // (r×(1+0.32·amt)) so the cursor doesn't fall off the swelling piece —
      // but never wider than that, or blank space starts hovering.
      const curR = tr * (1 + 0.32 * (cur.idx !== null ? cur.amt : 0));
      const probeTor = (dy: number, band: number): number | null => {
        const ex = mx - tg.cx, ey = (my - dy - tg.cy) / tCos;
        const rad = Math.hypot(ex, ey);
        if (Math.abs(rad - tR) > band) return null; // off-tube ⇒ no hover
        let ang = Math.atan2(ey, ex) + Math.PI / 2 - toroidRotRef.current;
        ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        let acc = 0;
        for (let i = 0; i < singleData.length; i++) {
          acc += (singleData[i].value / total) * Math.PI * 2;
          if (ang <= acc) return i;
        }
        return null;
      };
      idx = probeTor(0, curR + 2);
      if (idx === null && tTilt > 0.02) {
        // 3D crown band: the tube's lit front wall (up to r·sinTilt above
        // the centreline) belongs to the same piece — same strict band.
        for (const f of [0.5, 1]) { idx = probeTor(tr * tSin * f, curR + 2); if (idx !== null) break; }
      }
      if (idx !== null) {
        text = `${singleData[idx].label}: ${singleData[idx].value}`;
        let a0 = -Math.PI / 2;
        for (let j = 0; j < idx; j++) a0 += (singleData[j].value / total) * Math.PI * 2;
        const a1 = a0 + (singleData[idx].value / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2;
        const outR = tR + tr + 24;
        const tx = Math.max(16, Math.min(W - 140, tg.cx + Math.cos(mid) * outR));
        const ty = Math.max(16, Math.min(H - 40, tg.cy + Math.sin(mid) * outR * tCos));
        setHoverIdx(idx); setHoverSeg(null); setTip({ x: tx, y: ty, text });
        return;
      }
      // MISS ⇒ blank space. The toroid must NEVER fall through to the generic
      // xy hit test below (it treated the card like a column chart, so hover
      // fired "all over the place" — centre hole, gutters, corners). Off the
      // tube means no segment, no tooltip, full stop.
      setHoverIdx(null); setHoverSeg(null); setTip(null);
      return;
    }

    if (kind === 'pie' || kind === 'donut' || kind === 'polar') {
      const g = circGeom(W, H, m, singleData, isFullscreen);
      if (kind === 'polar') { g.squash = 1 - 0.44 * m; g.depth = 16 * m; }
      const rIn = kind === 'donut' ? g.R * g.rInRatio : 0;
      const sliceAt = (ang: number) => {
        if (kind === 'polar') return Math.min(singleData.length - 1, Math.floor(ang / (Math.PI * 2) * singleData.length));
        let acc = 0;
        for (let i = 0; i < singleData.length; i++) {
          acc += (singleData[i].value / total) * Math.PI * 2;
          if (ang <= acc) return i;
        }
        return null;
      };
      const probe = (dy: number, frontOnly: boolean): number | null => {
        const ex = mx - g.cx, ey = (my - dy - g.cy) / g.squash;
        const rad = Math.hypot(ex, ey);
        if (rad > g.R + 12 || rad < Math.max(0, rIn - 8)) return null;
        let ang = Math.atan2(ey, ex) + Math.PI / 2;
        ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        if (frontOnly && !(ang > Math.PI / 2 && ang < (3 * Math.PI) / 2)) return null;
        if (kind === 'polar') {
          const max = Math.max(...singleData.map((x) => x.value), 1);
          const i = Math.min(singleData.length - 1, Math.floor((ang / (Math.PI * 2)) * singleData.length));
          return (singleData[i].value / max) * g.R >= rad - 8 ? i : null;
        }
        return sliceAt(ang);
      };
      // sticky hover: while a slice is pulled out, test it first at its displaced
      // position so the cursor doesn't "fall off" the moving geometry
      const cur = hovRef.current;
      if (cur.idx !== null && cur.amt > 0.01) {
        let a0 = -Math.PI / 2;
        for (let i = 0; i < cur.idx; i++) a0 += (kind === 'polar' ? 1 / singleData.length : singleData[i].value / total) * Math.PI * 2;
        const a1 = a0 + (kind === 'polar' ? 1 / singleData.length : singleData[cur.idx].value / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2, pull = 14 * cur.amt;
        const { x: dx, y: dy } = radialOffset(mid, pull, g.squash);
        const activeR = kind === 'polar' ? g.R * singleData[cur.idx].value / Math.max(...singleData.map(x => x.value), 1) : g.R;
        const ex = mx - dx - g.cx;
        for (const band of [0, g.depth * 0.5, g.depth]) {
          const ey = (my - dy - band - g.cy) / g.squash;
          const rad = Math.hypot(ex, ey);
          if (rad > activeR + 10 || rad < Math.max(0, rIn - 8)) continue;
          let ang = Math.atan2(ey, ex) + Math.PI / 2;
          ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
          if (band > 0 && !(ang > Math.PI / 2 && ang < (3 * Math.PI) / 2)) continue;
          if (sliceAt(ang) === cur.idx) { idx = cur.idx; break; }
        }
      }
      if (idx === null) idx = probe(0, false);
      // extruded view: the side band (rim → rim + depth) belongs to the front slices too
      if (idx === null && g.depth > 0.5) {
        for (const f of [0.5, 1]) { idx = probe(g.depth * f, true); if (idx !== null) break; }
      }
      if (idx !== null) {
        text = `${singleData[idx].label}: ${singleData[idx].value}`;
        let a0 = -Math.PI / 2;
        for (let j = 0; j < idx; j++) a0 += (singleData[j].value / total) * Math.PI * 2;
        const a1 = a0 + (singleData[idx].value / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2;
        const outR = g.R + 24;
        const tx = Math.max(16, Math.min(W - 140, g.cx + Math.cos(mid) * outR));
        const ty = Math.max(16, Math.min(H - 40, g.cy + Math.sin(mid) * outR * g.squash));
        setHoverIdx(idx); setHoverSeg(null); setTip({ x: tx, y: ty, text });
        return;
      }
    } else if (kind === 'radialbars') {
      // Radial Bars Circular (MUI): mirror the PAINTER's polar frame
      // verbatim — label band reserve, plotMax, rIn, A0, lane/gaps — and
      // invert the pointer in UNSQUASHED ellipse space. The painter draws
      // y = cy + r·sin·squash, so dividing by squash recovers r exactly in
      // BOTH 2D and 3D (no separate 2D/3D hit paths to drift apart).
      const FS = isFullscreen ? 12 : W >= 760 ? 11 : 10;
      const squash = 1 - 0.5 * m;
      const hitNames: string[] = multi ? (categories || []) : singleData.map((x) => x.label);
      const nRB = Math.max(1, multi ? (categories || []).length || singleData.length : singleData.length);
      const labBand = Math.min(W * 0.24, Math.max(34, Math.max(0, ...hitNames.map((l) => approxW(l))) * 0.62 + 26));
      const plotR = Math.max(60, Math.min((W - labBand * 2) / 2 - 6, (H - 56) / 2 / Math.max(0.5, squash) - 6));
      const cxRB = W / 2, cyRB = H / 2 + 2;
      const rIn = Math.max(22, plotR * 0.34);
      const maxRB = multi ? Math.max(...series!.flatMap((s) => s.values), 1) : Math.max(...singleData.map((x) => x.value), 1);
      const laneRB = (Math.PI * 2) / nRB;
      const catGapRB = laneRB * 0.30;
      const nSRB = multi ? Math.max(1, series!.length) : 1;
      const barGapRB = nSRB > 1 ? (laneRB - catGapRB) * 0.10 : 0;
      const barWRB = nSRB > 1 ? (laneRB - catGapRB - barGapRB * (nSRB - 1)) / nSRB : laneRB - catGapRB;
      const radOfRB = (v: number) => rIn + (Math.max(0, v) / maxRB) * (plotR - rIn);
      // 3D wall: bars rise wallH above the disc — fold back down first
      const wallBack = (rO: number) => (m > 0.05 ? Math.min(44, Math.max(12, (rO - rIn) * 0.5)) * m : 0);
      const eyRB = (my - cyRB) / squash;
      const radRB = Math.hypot(mx - cxRB, eyRB);
      let angRB = Math.atan2(eyRB, mx - cxRB);
      angRB = ((angRB % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
      const reachRB = ((angRB - (3 * Math.PI) / 2 + Math.PI * 2) % (Math.PI * 2));
      const liRB = Math.floor(reachRB / laneRB);
      if (liRB >= 0 && liRB < nRB && radRB >= rIn - 4) {
        const inLane = reachRB - liRB * laneRB - catGapRB / 2;
        if (inLane >= -0.02 && inLane <= laneRB - catGapRB + 0.02) {
          if (!multi) {
            const rO = radOfRB(singleData[liRB].value);
            // accept body band AND the raised cap above it (3D)
            const eyCap = (my - cyRB + wallBack(rO)) / squash;
            const radCap = Math.hypot(mx - cxRB, eyCap);
            if (radRB <= rO + 6 || radCap <= rO + 6) {
              idx = liRB;
              const dd = singleData[liRB];
              text = dd.prior != null
                ? `${dd.label}: ${dd.value} · prior ${dd.prior} (${dd.value >= dd.prior ? '▲ +' : '▼ '}${Math.round((dd.value - dd.prior) * 10) / 10})`
                : `${dd.label}: ${dd.value}`;
            }
          } else {
            for (let si = 0; si < nSRB; si++) {
              const bS = si * (barWRB + barGapRB), bE = bS + barWRB;
              const rO = radOfRB(series![si].values[liRB] || 0);
              const eyCap = (my - cyRB + wallBack(rO)) / squash;
              const radCap = Math.hypot(mx - cxRB, eyCap);
              if (inLane >= bS - 0.02 && inLane <= bE + 0.02 && (radRB <= rO + 6 || radCap <= rO + 6)) {
                seg = { c: liRB, s: si };
                text = `${categories![liRB]} · ${series![si].name}: ${series![si].values[liRB] || 0}`;
                break;
              }
            }
          }
        }
      }
      void FS;
    } else if (kind === 'radialbarclassic') {
      // Hover labels were dead because this test inverted the WRONG geometry:
      // it used radialGeom's fitted frame (Rfit/kFit scaling, 0.44 squash,
      // depth-shifted centre) while the painter draws radialClassicGeom
      // (fixed diameter, 0.5 squash, no depth shift) — the bands never lined
      // up with the painted rings. The test now mirrors the painter's
      // contract VERBATIM: same helper, same ring radii (incl. the +2.5·amt
      // hover swell), same squash, same clockwise-from-12-o'clock sweep.
      const rg = radialClassicGeom(W, H, singleData, isFullscreen);
      const squash = 1 - 0.5 * m;
      const maxVal = Math.max(...singleData.map((x) => x.value), 1);
      const cur = hovRef.current;
      const ex = mx - rg.cx, ey = (my - rg.cy) / squash;
      const rad = Math.hypot(ex, ey);
      let ang = Math.atan2(ey, ex);
      ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
      const A0 = (3 * Math.PI) / 2; // 12 o'clock in [0, 2π)
      for (let i = 0; i < singleData.length; i++) {
        const rr = rg.ringR(i) + (cur.idx === i ? cur.amt * 2.5 : 0);
        if (Math.abs(rad - rr) > rg.thick / 2 + 2) continue;
        const sweep = Math.min(Math.PI * 2 * 0.985, (singleData[i].value / maxVal) * Math.PI * 2 * 0.985);
        // clockwise-from-top reach, with a small angular tolerance
        const reach = ((ang - A0 + Math.PI * 2) % (Math.PI * 2));
        if (reach <= sweep + 0.06) { idx = i; break; }
      }
      if (idx !== null) text = `${singleData[idx].label}: ${singleData[idx].value}`;
    } else if (kind === 'dual') {
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const colVals = multi ? categories!.map((_, c) => series![0]?.values[c] || 0) : singleData.map((x) => x.value);
      const maxL = Math.max(...colVals, 1);
      const L = xyLayout('bar', W, H, 0, labels, 1, maxL, !!yLabel, isFullscreen);
      const lineVals = multi ? series!.slice(1).map((s) => s.values) : [];
      const maxR = Math.max(...lineVals.flat(), 1);
      const pad = { ...L.pad, r: 12 + approxW(fmtNum(maxR), 10.5) + 14 };
      const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
      const step = cw / Math.max(1, labels.length);
      const ci = Math.floor((mx - pad.l) / step);
      if (ci >= 0 && ci < labels.length && mx >= pad.l) {
        if (multi) {
          let best = 16, bs: number | null = null;
          lineVals.forEach((vals, li) => { const yy = pad.t + ch - ((vals[ci] || 0) / maxR) * ch; if (Math.abs(my - yy) < best) { best = Math.abs(my - yy); bs = li + 1; } });
          const colTop = pad.t + ch - (colVals[ci] / maxL) * ch;
          if (bs === null && my >= colTop - 4) bs = 0;
          if (bs !== null) { seg = { c: ci, s: bs }; text = `${labels[ci]} · ${series![bs].name}: ${series![bs].values[ci] || 0}`; }
        } else {
          idx = ci; text = `${singleData[ci].label}: ${singleData[ci].value}`;
        }
      }
    } else if (kind === 'funnel' || kind === 'pyramid') {
      const g = funnelGeom(W, H, m, singleData, isFullscreen, kind === 'pyramid');
      const heights = singleData.map((x) => (x.value / total) * g.ch);
      let y = g.topY;
      for (let i = 0; i < singleData.length; i++) {
        if (my >= y && my <= y + heights[i] && Math.abs(mx - g.cx) <= g.plotW / 2 + 24) { idx = i; break; }
        y += heights[i];
      }
      if (idx !== null) text = `${singleData[idx].label}: ${singleData[idx].value}`;
    } else if (kind === 'stream') {
      const gm = streamGeom(multi, categories || [], series || [], sColors, singleData, colors, pal, W, H, isFullscreen);
      if (gm) {
        const { list, labels, xs, bound, order } = gm;
        const n = labels.length;
        // nearest column, then the layer whose band contains the cursor
        let j = 0, best = Infinity;
        xs.forEach((x, k) => { const dd = Math.abs(mx - x); if (dd < best) { best = dd; j = k; } });
        let si: number | null = null;
        for (let k = order.length - 1; k >= 0; k--) {
          if (my >= bound[k + 1][j] - 2 && my <= bound[k][j] + 2) { si = order[k]; break; }
        }
        if (si === null) {
          // snap to nearest boundary when between hairline layers
          let bd = Infinity;
          bound.forEach((b) => { const dd = Math.abs(my - b[j]); if (dd < bd) { bd = dd; } });
          if (bd < 10) {
            for (let k = order.length - 1; k >= 0; k--) {
              if (my >= bound[k + 1][j] - 10 && my <= bound[k][j] + 10) { si = order[k]; break; }
            }
          }
        }
        if (si !== null) {
          seg = { c: j, s: si };
          const tot = list.reduce((a, l) => a + (l.values[j] || 0), 0) || 1;
          text = `${labels[j]} · ${list[si].name}: ${fmtNum(list[si].values[j] || 0)} (${Math.round(((list[si].values[j] || 0) / tot) * 100)}%)`;
        }
      }
    } else if (kind === 'gantt') {
      const rawTasks: GanttTask[] = tasks && tasks.length ? tasks : singleData.map((x, i) => ({
        id: i, name: x.label, start: i * 3, end: i * 3 + Math.max(3, Math.round(x.value / 8)), progress: 50,
      }));
      const padL = Math.max(140, Math.min(240, W * 0.26));
      const padR = 28 + 14 * m, padT = 40 + 10 * m, padB = 30;
      const chartW = W - padL - padR, chartH = H - padT - padB;
      const rowH = Math.min(42, Math.max(26, chartH / Math.max(1, rawTasks.length)));
      const ri = Math.floor((my - padT) / rowH);
      if (ri >= 0 && ri < rawTasks.length) {
        const tk = rawTasks[ri];
        idx = ri;
        const prg = tk.progress ?? 100;
        text = `${tk.name}: ${prg}%${tk.assignee ? ` · ${tk.assignee}` : ''}`;
      }
    } else if (kind === 'scatter') {
      const rawScatter: ScatterPoint[] = scatter && scatter.length ? scatter : singleData.map((x, i) => ({
        x: 20 + i * 8 + ((i * 13) % 19), y: x.value, label: x.label, size: 7 + ((i * 3) % 5),
      }));
      const padL = 52, padR = 24, padT = 34, padB = 40;
      const plotW = W - padL - padR, plotH = H - padT - padB;
      const xs = rawScatter.map((pt) => pt.x), ys = rawScatter.map((pt) => pt.y);
      const minX = Math.min(...xs, 0), maxX = Math.max(...xs, minX + 1);
      const minY = Math.min(...ys, 0), maxY = Math.max(...ys, minY + 1);
      const sOx = 16 * m, sOy = 12 * m;
      let best = 16;
      rawScatter.forEach((pt, i) => {
        const lift = m > 0.02 ? (pt.size || 7) * 0.9 * m : 0;
        const px = padL + ((pt.x - minX) / (maxX - minX)) * plotW + (m > 0.02 ? sOx * 0.5 : 0);
        const py = padT + plotH - ((pt.y - minY) / (maxY - minY)) * plotH - (m > 0.02 ? sOy * 0.5 : 0) - lift;
        const dd = Math.hypot(mx - px, my - py);
        if (dd < best + (pt.size || 7) * 0.5) { best = dd; idx = i; }
      });
      if (idx !== null) {
        const pt = rawScatter[idx];
        text = `${pt.label || `Point ${idx + 1}`}: (${fmtNum(pt.x)}, ${fmtNum(pt.y)})`;
      }
    } else if (kind === 'radar') {
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const longest = Math.max(0, ...labels.map((l) => approxW(l)));
      const margin = isFullscreen ? Math.min(W * 0.4, longest + 24) : 44;
      const squash = 1 - 0.52 * m;
      const Rflat = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30) / Math.max(0.45, squash)));
      const depth = Math.min(46, Math.max(12, Rflat * 0.24)) * m;
      const cy = H / 2 + 6, R = Math.max(30, Math.min(W / 2 - margin, (H / 2 - 30 - depth) / Math.max(0.45, squash)));
      const max = multi ? Math.max(...series!.flatMap((s) => s.values), 1) : Math.max(...singleData.map((x) => x.value), 1);
      // Tips ride `depth` above the disc in 3D (sticks + thread, no slab) —
      // hover the tip knot, with a tolerance band covering the stick body.
      let best = 14;
      labels.forEach((_, i) => {
        const aa = -Math.PI / 2 + (i * Math.PI * 2) / labels.length;
        const v = multi ? Math.max(...series!.map((s) => s.values[i] || 0)) : singleData[i].value;
        const vr = (v / max) * R;
        const vx = W / 2 + Math.cos(aa) * vr, vy = cy + Math.sin(aa) * vr * squash - (v / max) * depth;
        const dy = my < vy ? vy - my : my > vy + depth ? my - vy - depth : 0;
        const dd = Math.hypot(mx - vx, dy);
        if (dd < best) { best = dd; idx = i; }
      });
      if (idx !== null) text = multi
        ? `${categories![idx]} · ${series!.map((s) => `${s.name}: ${s.values[idx!] || 0}`).join(' · ')}`
        : `${singleData[idx].label}: ${singleData[idx].value}`;
    } else {
      const isBar = kind === 'bar';
      const nD = multi ? series!.length : 1;
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const max = isBar
        ? (multi ? Math.max(...categories!.map((_, c) => series!.reduce((s, sr) => s + (sr.values[c] || 0), 0)), 1) : Math.max(...singleData.map((x) => x.value), 1))
        : (multi ? Math.max(...series!.flatMap((s) => s.values), 1) : Math.max(...singleData.map((x) => x.value), 1));
      const L = xyLayout(kind as 'bar' | 'line' | 'area', W, H, m, labels, nD, max, !!yLabel, isFullscreen);
      const { pad, ch, step } = L;
      const ci = Math.floor((mx - pad.l) / step);
      if (ci >= 0 && ci < labels.length && mx >= pad.l) {
        if (multi && isBar) {
          const totals = categories!.map((_, c) => series!.reduce((s, sr) => s + (sr.values[c] || 0), 0));
          const yVal = ((pad.t + ch - my) / ch) * max;
          let acc = 0, si: number | null = null;
          for (let s = 0; s < series!.length; s++) {
            acc += series![s].values[ci] || 0;
            if (yVal <= acc) { si = s; break; }
          }
          if (si !== null && yVal <= totals[ci]) {
            seg = { c: ci, s: si };
            text = `${categories![ci]} · ${series![si].name}: ${series![si].values[ci] || 0} (total ${totals[ci]})`;
          }
        } else if (multi) {
          const depth = seriesDepth(series!);
          let best = 20, bs: number | null = null;
          series!.forEach((s, si) => {
            const yy = pad.t + ch - ((s.values[ci] || 0) / max) * ch - ZY * m * depth[si];
            const dd = Math.abs(my - yy);
            if (dd < best) { best = dd; bs = si; }
          });
          if (bs !== null) {
            seg = { c: ci, s: bs };
            text = `${categories![ci]} · ${series![bs].name}: ${series![bs].values[ci] || 0}`;
          }
        } else {
          idx = ci;
          text = `${singleData[ci].label}: ${singleData[ci].value}`;
        }
      }
    }

    setHoverIdx(idx);
    setHoverSeg(seg);
    setTip(idx !== null || seg !== null ? { x: mx, y: my, text } : null);
  };

  const legend = kind === 'timeline'
    ? []
    : kind === 'stream'
    // ONE labelled row under the card — the ONLY place nation colour
    // labels appear. The scene itself never renders its own legend/shelf,
    // so there is no double set of colour labels anywhere for this chart.
    ? STREAM_COUNTRIES.map((c) => ({ label: c.name, color: c.color }))
    : kind === 'streamdyn'
    // Dynamic stream: one row of the SELECTED dataset in ribbon-input colours.
    ? streamDynSource.series.map((s, i) => ({ label: s.name, color: s.color || TOROID_GLOSS[i % TOROID_GLOSS.length] }))
    : kind === 'orgchart'
    ? orgLegend
    : (kind === 'radialbars' && !multi)
      // Semantic legend mirroring 3dRadialBarChart.html's legend card — the
      // bars are ONE blue material, so per-category swatches would lie.
      ? [
        { label: 'Current (bar)', color: '#2563eb' },
        { label: 'Prior (marker)', color: '#ef4444' },
        { label: '▲ Increased', color: '#2563eb' },
        { label: '▼ Fell', color: '#ef4444' },
        { label: 'Average (dashed)', color: '#f87171' },
      ]
      : kind === 'radialbar'
        ? radialLegendFor(radialPreset)
        : (kind === 'sankey' || kind === 'sankey3d')
        ? (() => { const names = [...new Set((links || []).flatMap((l) => [l.source, l.target]))]; return names.map((n, i) => ({ label: n, color: pal[i % pal.length] })); })()
        : multi
          ? series!.map((s, i) => ({ label: s.name, color: kind === 'dual' && i > 0 ? distinctLineColor([sColors[0]], sColors[i], pal) : sColors[i] }))
          : singleData.map((x, i) => ({ label: x.label, color: colors[i] }));

  /* exports */
  const doExport = async (fmt: string) => {
    const cv = canvasRef.current;
    if (!cv) return;
    const base = (title || 'chart').toLowerCase().replace(/\s+/g, '-');
    const m = effDim === '3d' ? 1 : 0;
    const legendItems = legend;

    if ((fmt === 'png' || fmt === 'svg' || fmt === 'pdf' || fmt === 'print') && (isThreeRadial || isThreeSankeyPro || isThreeStream || isThreeStreamDyn || isThreeOrg || isTimeline || isThreeRBC)) {
      const api = isThreeRadial ? threeRadialRef.current : (isThreeStream || isThreeStreamDyn) ? threeStreamRef.current : isThreeRBC ? threeRBCRef.current : threeSankeyRef.current;
      if (!api) return;
      if (fmt === 'svg') {
        const svg = await api.exportSVG(title || 'Chart');
        downloadBlob(`${base}.svg`, new Blob([svg], { type: 'image/svg+xml' }));
        return;
      }
      const blob = await api.exportPNG(title || 'Chart');
      if (fmt === 'png') { downloadBlob(`${base}.png`, blob); return; }
      const dataUrl: string = await new Promise((resolve) => { const r = new FileReader(); r.onload = () => resolve(r.result as string); r.readAsDataURL(blob); });
      const img = await new Promise<HTMLImageElement>((resolve) => { const im = new Image(); im.onload = () => resolve(im); im.src = dataUrl; });
      const out = document.createElement('canvas'); out.width = img.width; out.height = img.height;
      out.getContext('2d')!.drawImage(img, 0, 0);
      if (fmt === 'pdf') {
        const jpegUrl = out.toDataURL('image/jpeg', 0.94);
        const bytes = Uint8Array.from(atob(jpegUrl.split(',')[1]), (c) => c.charCodeAt(0));
        downloadBlob(`${base}.pdf`, jpegToPdf(bytes, out.width, out.height));
      } else if (fmt === 'print') {
        printCanvas(title || 'Chart', out);
      }
      return;
    }

    if (fmt === 'csv' && (kind === 'sankey' || kind === 'sankey3d')) {
      downloadBlob(`${base}.csv`, new Blob(['source,target,value\n' + (links || []).map((l) => `"${l.source}","${l.target}",${l.value}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'csv' && kind === 'calendarpie') {
      downloadBlob(`${base}.csv`, new Blob(['date,' + series!.map((x) => `"${x.name}"`).join(',') + '\n' + (days || []).map((x) => `${x.date},${x.values.join(',')}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if ((fmt === 'csv' || fmt === 'json' || fmt === 'excel') && kind === 'stream') {
      const periods = STREAM_EDITIONS.map((e) => `${e.yr} ${e.name}`);
      if (fmt === 'csv') {
        const csv = 'edition,' + STREAM_COUNTRIES.map((c) => `"${c.name}"`).join(',') + '\n' +
          periods.map((p, i) => `"${p}",` + STREAM_COUNTRIES.map((c) => c.vals[i] || 0).join(',')).join('\n');
        downloadBlob(`${base}.csv`, new Blob([csv], { type: 'text/csv' }));
        return;
      }
      if (fmt === 'json') {
        downloadBlob(`${base}.json`, new Blob([JSON.stringify({ editions: STREAM_EDITIONS, countries: STREAM_COUNTRIES }, null, 2)], { type: 'application/json' }));
        return;
      }
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Chart Data');
      ws.mergeCells(1, 1, 1, STREAM_COUNTRIES.length + 1);
      const titleCell = ws.getCell(1, 1);
      titleCell.value = (title || 'Chart').toUpperCase();
      titleCell.font = { bold: true, size: 13, color: { argb: 'FF0D7A54' } };
      const head0 = ws.addRow(['Edition', ...STREAM_COUNTRIES.map((c) => c.name)]);
      head0.eachCell((cell: { font: unknown; fill: unknown }) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
      });
      periods.forEach((p, i) => ws.addRow([p, ...STREAM_COUNTRIES.map((c) => c.vals[i] || 0)]));
      ws.getColumn(1).width = 24;
      const buf0 = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf0], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }
    if (fmt === 'json' && isSpecialFlow) {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify((kind === 'sankey' || kind === 'sankey3d') ? { links } : { series: series!.map((x) => x.name), days }, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel' && isSpecialFlow) {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Chart Data');
      const head = ws.addRow((kind === 'sankey' || kind === 'sankey3d') ? ['Source', 'Target', 'Value'] : ['Date', ...series!.map((x) => x.name)]);
      head.eachCell((cell: { font: unknown; fill: unknown }) => { cell.font = { bold: true, color: { argb: 'FFFFFFFF' } }; cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } }; });
      if (kind === 'sankey' || kind === 'sankey3d') (links || []).forEach((l) => ws.addRow([l.source, l.target, l.value])); else (days || []).forEach((x) => ws.addRow([x.date, ...x.values]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }

    if (fmt === 'csv') {
      const csv = multi
        ? 'category,' + series!.map((s) => `"${s.name}"`).join(',') + '\n' +
          categories!.map((c, i) => `"${c}",` + series!.map((s) => s.values[i] || 0).join(',')).join('\n')
        : 'label,value\n' + singleData.map((x) => `"${x.label}",${x.value}`).join('\n');
      downloadBlob(`${base}.csv`, new Blob([csv], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'json') {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify(multi ? { categories, series } : singleData, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel') {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Chart Data');
      ws.mergeCells(1, 1, 1, multi ? series!.length + 1 : 2);
      const titleCell = ws.getCell(1, 1);
      titleCell.value = (title || 'Chart').toUpperCase();
      titleCell.font = { bold: true, size: 13, color: { argb: 'FF0D7A54' } };
      const head = ws.addRow(multi ? ['Category', ...series!.map((s) => s.name)] : ['Label', 'Value']);
      head.eachCell((cell: { font: unknown; fill: unknown }) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
      });
      if (multi) categories!.forEach((c, i) => ws.addRow([c, ...series!.map((s) => s.values[i] || 0)]));
      else singleData.forEach((x) => ws.addRow([x.label, x.value]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }

    await fontsReady();
    const tEx = themeColors(true);
    if (fmt === 'svg') {
      // SVG mirrors the chart EXACTLY as shown: same canvas size, same layout mode
      // (compact/fullscreen label fitting), same fonts — embedded so it renders
      // identically anywhere, at any zoom, without depending on installed fonts.
      // Toroid included: its painter has a dedicated TRUE-vector branch (a
      // faceted torus mesh emitted as flat-shaded polygons through this SVG
      // recorder — pure <path> nodes, no <image>, identical lighting to the
      // live canvas), so the generic recorder path IS the true-SVG path.
      //
      // SMALL-TILE FIX: the toroid's quad/facet COUNT is already fixed
      // (data.length-based, independent of canvas size — see `ringSteps`/
      // `tubeSteps` in the toroid painter), but exporting used the LIVE
      // on-screen tile's own client size — a small, non-fullscreen card
      // could be as little as ~140px across. At that size the torus's own
      // radius shrinks to just a few dozen px, so the SAME facet count
      // spans far fewer degrees each — every facet edge becomes a
      // visually larger fraction of the whole shape once someone actually
      // VIEWS the exported file at a normal size, reading as "not smooth"
      // even though the vector data itself never lost precision. PNG/PDF
      // exports never had this problem because they already render at a
      // canonical `exportDims()` size regardless of the live tile — the
      // toroid's SVG export now does the same, so its absolute size (and
      // therefore facet density) is always consistent.
      const useCanonicalDims = kind === 'toroid';
      const { W: Ws, H: Hs } = useCanonicalDims
        ? exportDims(kind, cv.clientWidth, cv.clientHeight, singleData, multi, categories || [], m)
        : { W: cv.clientWidth, H: cv.clientHeight };
      // FILE-SIZE FIX: embedded @font-face base64 (not the geometry) is the
      // dominant cost of the toroid's SVG — the generic path always
      // requests BOTH weights (600 AND 700) for BOTH the body AND display
      // font families (up to 4 separate ~20–40 KB embedded files), but the
      // toroid painter only ever actually sets body-600 (leader labels)
      // and display-700 (centre total). Requesting exactly those two
      // (font,weight) pairs — not the generic 2×2 — roughly halves the
      // embedded payload with zero loss: every glyph the file actually
      // uses is still embedded, nothing else is.
      const fontCss = kind === 'toroid'
        ? (await Promise.all([
          fontFaceCss([tEx.fontBody || DEF_BODY], ['600']),
          (tEx.fontDisplay || DEF_DISPLAY) === (tEx.fontBody || DEF_BODY) ? Promise.resolve('') : fontFaceCss([tEx.fontDisplay || DEF_DISPLAY], ['700']),
        ])).join('')
        : await fontFaceCss(fontFamilies(tEx), ['600', '700']);
      const svgPainter = (ctx: Ctx) => paintChart(ctx, kind, { ...buildCtx(Ws, Hs, 1, m, NO_HOVER, true), full: useCanonicalDims ? true : isFullscreen });
      downloadBlob(`${base}.svg`, new Blob([composeSvg(title || '', Ws, Hs, legendItems, svgPainter, tEx, fontCss)], { type: 'image/svg+xml' }));
      return;
    }
    const { W: Wx, H: Hx } = exportDims(kind, cv.clientWidth, cv.clientHeight, singleData, multi, categories || [], m);
    const painter = (ctx: Ctx) => paint(ctx, Wx, Hx, 1, m, NO_HOVER, true);
    const out = composeExport(title || '', Wx, Hx, legendItems, painter, tEx);
    if (fmt === 'png') out.toBlob((b) => b && downloadBlob(`${base}.png`, b), 'image/png');
    else if (fmt === 'pdf') {
      const dataUrl = out.toDataURL('image/jpeg', 0.94);
      const bytes = Uint8Array.from(atob(dataUrl.split(',')[1]), (c) => c.charCodeAt(0));
      downloadBlob(`${base}.pdf`, jpegToPdf(bytes, out.width, out.height));
    } else if (fmt === 'print') printCanvas(title || 'Chart', out);
  };


  const containerRef = useRef<HTMLDivElement>(null);
  const [isFs, setIsFs] = useState(false);

  useEffect(() => {
    const onFs = () => {
      const active = !!document.fullscreenElement && document.fullscreenElement === containerRef.current;
      setIsFs(active);
    };
    document.addEventListener('fullscreenchange', onFs);
    document.addEventListener('webkitfullscreenchange', onFs);
    return () => {
      document.removeEventListener('fullscreenchange', onFs);
      document.removeEventListener('webkitfullscreenchange', onFs);
    };
  }, []);

  /* Lock the page scroll while the CSS-fallback overlay is open so the page
     behind the fullscreen dialog never shifts or gains scrollbars. */
  useEffect(() => {
    if (!full) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, [full]);

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      try {
        if (containerRef.current?.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        } else if ((containerRef.current as unknown as { webkitRequestFullscreen?: () => Promise<void> })?.webkitRequestFullscreen) {
          await (containerRef.current as unknown as { webkitRequestFullscreen: () => Promise<void> }).webkitRequestFullscreen();
        }
        setIsFs(true);
      } catch {
        setFull(true);
      }
    } else {
      try {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as unknown as { webkitExitFullscreen?: () => Promise<void> })?.webkitExitFullscreen) {
          await (document as unknown as { webkitExitFullscreen: () => Promise<void> }).webkitExitFullscreen();
        }
      } catch { /* noop */ }
      setIsFs(false);
      setFull(false);
    }
  };

  const body = (
    <div ref={containerRef} className={`tk-card ${isFs ? '!fixed !inset-0 !z-[100] !w-screen !h-screen !max-w-[100vw] !m-0 !rounded-none !p-6 sm:!p-10 flex flex-col overflow-y-auto overflow-x-hidden bg-(--t-surface)' : 'p-4'}`}>
      {/* The toolbar no longer carries a z-index: the MiniDrop menus are
          portalled out of the card, so no stacking-context arms race is
          needed (or wanted) between sibling chart cards. */}
      <div className="relative mb-3 flex flex-wrap items-center gap-2">
        {title && <p className={`mr-auto font-display font-semibold text-ink ${isFs ? 'text-xl' : 'text-[15px]'}`}>{title}</p>}
        {meta.has3d && (
          <div className="tk-inset flex gap-0.5 p-1">
            {(['2d', '3d'] as const).map((dd) => (
              <button key={dd} onClick={() => setDim(dd)} disabled={loading || (dd === '3d' && !meta.has3d)}
                className={`flex items-center gap-1 rounded-lg px-2.5 py-1 font-body text-[11px] font-bold uppercase transition disabled:opacity-30 ${effDim === dd ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}>
                {dd === '2d' ? <Square size={11} /> : <Box size={11} />} {dd}
              </button>
            ))}
          </div>
        )}
        <MiniDrop label={meta.label} activeKey={kind}
          items={KINDS.map((k) => ({ key: k.key, label: k.label }))}
          onPick={(k) => { setKind(k as ChartKind); setHoverIdx(null); setHoverSeg(null); setTip(null); }} />
        {isThreeRadial && (
          <MiniDrop label="Version" activeKey={radialPreset}
            items={RADIAL_PRESET_OPTIONS.map((o) => ({ key: o.key, label: o.label }))}
            onPick={(k) => { setRadialPreset(k as RadialPresetKey); setHoverIdx(null); }} />
        )}
        {isThreeStreamDyn && (
          <MiniDrop label="Dataset" activeKey={streamDynKey}
            items={streamDynOptions}
            onPick={(k) => { setStreamDynKey(k); setHoverIdx(null); setHoverSeg(null); }} />
        )}
        <MiniDrop label="Export" icon={<Download size={12} />}
          items={[
            { key: 'png', label: 'PNG image' },
            { key: 'svg', label: 'SVG vector' },
            { key: 'pdf', label: 'PDF document' },
            { key: 'excel', label: 'Excel workbook' },
            { key: 'print', label: 'Print…' },
            { key: 'csv', label: 'CSV data' },
            { key: 'json', label: 'JSON data' },
          ]}
          onPick={doExport} />
        {!isFullscreen && (
          <button onClick={toggleFullscreen} data-tip={isFs ? "Exit fullscreen" : "View fullscreen"} className="tk-btn-ghost rounded-xl p-2">
            {isFs ? <Minimize2 size={15} /> : <Eye size={14} />}
          </button>
        )}
      </div>

      <div className="relative flex-1 w-full min-h-0" style={{ height: isFs ? 'calc(100vh - 160px)' : (isThreeStream || isThreeStreamDyn) ? Math.max(height, 720) : isThreeOrg ? Math.max(height, 620) : isTimeline ? Math.max(height, 520) : (isThreeRadial || kind === 'radialbars') ? Math.max(height, 460) : height }}>
        {loading ? (
          <ChartSkeleton kind={skeletonKind(kind)} height={isFs ? 500 : height} legend={false} />
        ) : (
          <>
            <canvas ref={canvasRef}
              style={{
                width: '100%', height: '100%',
                cursor: undefined,
                /* Keep the canvas fully opaque so switching off a Three.js
                   kind (Radial Bar → pie/donut/…) never fades in a blank
                   first frame. Visibility just hides it under the overlay. */
                opacity: 1,
                visibility: canvasHidden ? 'hidden' : 'visible',
                pointerEvents: canvasHidden ? 'none' : 'auto',
              }}
              onMouseMove={(e) => { orbitMove(e); if (!dragRef.current?.moved) hit(e); }}
              onMouseDown={orbitDown} onMouseUp={orbitUp}
              onMouseLeave={() => { orbitUp(); setHoverIdx(null); setHoverSeg(null); setTip(null); }} />
            {!canvasHidden && tip && (
              <div className="tk-pop pointer-events-none absolute z-10 px-2.5 py-1 font-body text-[11px] font-bold text-ink"
                style={{ left: Math.min(tip.x + 12, (canvasRef.current?.clientWidth || 300) - 170), top: Math.max(0, tip.y - 34) }}>
                {tip.text}
              </div>
            )}
            {kind === 'toroid' && !canvasHidden && (
              <div className="absolute right-2 top-2 z-10 flex gap-1.5">
                <button
                  onClick={(e) => { e.stopPropagation(); setToroidSpin((v) => !v); }}
                  className={`rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${toroidSpin ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
                  title="Auto-rotate"
                >
                  ⟳ Rotate
                </button>
              </div>
            )}
            {isThreeSankeyPro && (
              <div className="absolute inset-0" style={{ opacity: 1, transition: 'opacity 320ms ease' }}>
                <Suspense fallback={null}>
                  <ThreeSankey3D ref={threeSankeyRef} links={links || []} palette={pal} theme={exportTheme}
                    dim={effDim} dark={themeRef.current.dark} hoverIndex={hoverIdx}
                    onHover={(text) => {
                      // Hovering inside the 3D scene mirrors back to the card
                      // legend; the 3D tooltip itself is owned by the scene.
                      if (!text) { setHoverIdx(null); return; }
                      const names = [...new Set((links || []).flatMap((l) => [l.source, l.target]))];
                      const ni = names.findIndex((n) => text.startsWith(n));
                      setHoverIdx(ni >= 0 ? ni : null);
                    }} />
                </Suspense>
              </div>
            )}
            {isThreeRadial && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <ThreeReferenceRadialBar ref={threeRadialRef} presetKey={radialPreset} dim={effDim} theme={exportTheme}
                    dark={themeRef.current.dark} hoverIndex={hoverIdx}
                    onHover={(idx) => setHoverIdx(idx)} />
                </Suspense>
              </div>
            )}
            {isThreeStream && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <ThreeStreamgraph ref={threeStreamRef} categories={multi ? categories : undefined}
                    series={multi ? series : undefined} palette={TOROID_GLOSS} dim={effDim} theme={exportTheme}
                    dark={themeRef.current.dark} hoverIndex={hoverSeg ? hoverSeg.s : null}
                    onHover={(_idx, text) => {
                      // Mirror the WebGL hover back to the card legend; the
                      // 3D tooltip itself is owned by the scene.
                      if (_idx === null || _idx === undefined) { setHoverSeg(null); return; }
                      setHoverSeg({ c: -1, s: _idx });
                      void text;
                    }} />
                </Suspense>
              </div>
            )}
            {isThreeStreamDyn && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <ThreeStreamgraph ref={threeStreamRef} model={streamDynModel}
                    palette={TOROID_GLOSS} dim={effDim} theme={exportTheme}
                    dark={themeRef.current.dark} hoverIndex={hoverSeg ? hoverSeg.s : null}
                    onHover={(_idx, text) => {
                      if (_idx === null || _idx === undefined) { setHoverSeg(null); return; }
                      setHoverSeg({ c: -1, s: _idx });
                      void text;
                    }} />
                </Suspense>
              </div>
            )}
            {isThreeOrg && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <ThreeOrgChart ref={threeSankeyRef} links={orgLinks} palette={pal} dim={effDim} theme={exportTheme}
                    dark={themeRef.current.dark} hoverIndex={hoverIdx}
                    onHover={(idx) => setHoverIdx(idx)} />
                </Suspense>
              </div>
            )}
            {isTimeline && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <TimelineNeu ref={threeSankeyRef} items={timelineItems} theme={exportTheme}
                    dark={themeRef.current.dark} />
                </Suspense>
              </div>
            )}
            {isThreeRBC && (
              <div className="absolute inset-0">
                <Suspense fallback={null}>
                  <ThreeRadialBarsCircular ref={threeRBCRef} data={singleData}
                    categories={multi ? categories : undefined} series={multi ? series : undefined}
                    palette={pal} dim={effDim} theme={exportTheme}
                    dark={themeRef.current.dark} hoverIndex={hoverIdx}
                    onHover={(idx) => setHoverIdx(idx)} />
                </Suspense>
              </div>
            )}
          </>
        )}
      </div>

      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <span key={i} className="tk-skeleton h-2.5" style={{ width: 48 + (i % 3) * 18 }} />)
          : legend.map((l, i) => (
            <button key={l.label + i}
              onMouseEnter={() => ((kind === 'sankey' || kind === 'sankey3d') ? setHoverIdx(i) : (multi || kind === 'stream') ? setHoverSeg({ c: -1, s: i }) : setHoverIdx(i))}
              onMouseLeave={() => { setHoverIdx(null); setHoverSeg(null); }}
              className={`flex items-center gap-1.5 font-body text-[11px] font-semibold transition ${(multi ? hoverSeg?.s === i : hoverIdx === i) ? 'text-ink' : 'text-muted'}`}>
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: l.color }} /> {l.label}
            </button>
          ))}
      </div>

      {insight && insight.length > 0 && (
        <div className="tk-inset mt-3 space-y-1 rounded-xl px-3.5 py-2.5">
          {insight.map((line, i) => <p key={i} className="font-body text-[11.5px] text-ink/70">• {line}</p>)}
        </div>
      )}
    </div>
  );

  return (
    <>
      {body}
      {/* CSS-fallback fullscreen (used when native requestFullscreen fails or is
          unavailable, e.g. inside an iframe without allow="fullscreen"). The
          overlay locks the page scroll (body overflow hidden) so the page
          behind never scrolls, and clips horizontally so an opening dropdown
          can never summon an x-axis scrollbar. */}
      {full && createPortal(
        <div className="fixed inset-0 z-[100] flex flex-col bg-(--t-surface) p-6 sm:p-10 backdrop-blur-md overflow-y-auto overflow-x-hidden max-w-[100vw]"
          onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) setFull(false); }}>
          <div className="mb-3 flex justify-between items-center">
            {title && <h2 className="font-display text-xl font-bold text-ink">{title}</h2>}
            <button onClick={() => setFull(false)} className="tk-btn-ghost rounded-full p-2.5 ml-auto"><X size={18} /></button>
          </div>
          <div className="flex-1 w-full min-w-0 max-w-full">
            <Chart data={data} categories={categories} series={series} title={title}
              defaultKind={kind} defaultDim={effDim} height={window.innerHeight - 180} extraKinds={extraKinds}
              yLabel={yLabel} insight={insight} days={days} links={links} tasks={tasks} scatter={scatter} streamEvents={streamEvents} streamCanvas={streamCanvas} isFullscreen />
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

/* ================= StackedColumns (compat wrapper) ================= */
export function StackedColumns({ title, categories, series, height = 300, yLabel = 'Employees', insight }: {
  title: string; categories: string[]; series: StackedSeries[]; height?: number; yLabel?: string; insight?: string[];
}) {
  return <Chart title={title} categories={categories} series={series} defaultKind="bar" height={height} yLabel={yLabel} insight={insight} />;
}
