import { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Download, Eye, Minimize2, X } from 'lucide-react';
import { ChartSkeleton } from '../primitives';
import { MiniDrop } from './MiniDrop';
import {
  type ChartDatum, type Theme, type Ctx,
  themeColors, font, shade, withAlpha, luma, easeOut, easeInOut, rgba, clamp01, fitCtx, fitText,
  downloadBlob, loadExcelJS, jpegToPdf, printCanvas, fmtNum, svgToCanvas,
  SvgCtx, measureW, fontsReady, fontFamilies, planXFit, drawXLabels, type XPlan, approxW, activePalette,
} from './core';
import { fontFaceCss } from '../../theme/fonts';

function useThemeTick() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const handler = () => { setTick((t) => t + 1); timer = setTimeout(() => setTick((t) => t + 1), 720); };
    window.addEventListener('aviary:prefs', handler);
    return () => { window.removeEventListener('aviary:prefs', handler); clearTimeout(timer); };
  }, []);
  return tick;
}

/* ============================================================
   Neumorphic chart family v3 — reference soft-UI depth
   (extruded puck · inset groove ring · carved wedges with divider
   grooves · raised centre button · on-slice % labels). ONE canvas
   painter drives the live chart AND every export, so nothing is
   ever missing or truncated and fonts are preserved.
   ============================================================ */
export type NeuKind = 'donut' | 'pie' | 'bars' | 'columns' | 'line' | 'area';
const NEU_KINDS: { key: NeuKind; label: string }[] = [
  { key: 'donut', label: 'Donut' },
  { key: 'pie', label: 'Pie' },
  { key: 'bars', label: 'Bars' },
  { key: 'columns', label: 'Columns' },
  { key: 'line', label: 'Line' },
  { key: 'area', label: 'Area' },
];

interface NeuTones { surface: string; hi: string; lo: string; shadowDark: string; shadowLight: string; groove: string; grooveHi: string; muted: string; grid: string }
function neuTones(t: Theme): NeuTones {
  const dark = !!t.dark;
  const surface = t.surface || '#e4e7e0';
  return {
    surface,
    hi: shade(surface, dark ? 1.1 : 1.045),
    lo: shade(surface, dark ? 0.88 : 0.962),
    shadowDark: dark ? 'rgba(0,0,0,0.55)' : rgba(t.ink, 0.24),
    shadowLight: dark ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.92)',
    groove: dark ? 'rgba(0,0,0,0.5)' : rgba(t.ink, 0.14),
    grooveHi: dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.85)',
    muted: rgba(t.ink, 0.55),
    grid: rgba(t.ink, 0.16),
  };
}
function setShadow(ctx: Ctx, x: number, y: number, blur: number, color: string) {
  ctx.shadowOffsetX = x; ctx.shadowOffsetY = y; ctx.shadowBlur = blur; ctx.shadowColor = color;
}
function noShadow(ctx: Ctx) { ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; ctx.shadowColor = 'rgba(0,0,0,0)'; }
function circle(ctx: Ctx, cx: number, cy: number, r: number) { ctx.beginPath(); ctx.arc(cx, cy, Math.max(0.1, r), 0, Math.PI * 2); ctx.closePath(); }
/** Extruded soft disc: dark shadow bottom-right, light shadow top-left, gentle sheen. */
function raisedDisc(ctx: Ctx, cx: number, cy: number, r: number, n: NeuTones, spread = 1) {
  ctx.save();
  setShadow(ctx, 7 * spread, 7 * spread, 16 * spread, n.shadowDark); ctx.fillStyle = n.surface; circle(ctx, cx, cy, r); ctx.fill();
  setShadow(ctx, -6 * spread, -6 * spread, 14 * spread, n.shadowLight); circle(ctx, cx, cy, r); ctx.fill();
  noShadow(ctx);
  const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
  g.addColorStop(0, n.hi); g.addColorStop(1, n.lo);
  ctx.fillStyle = g; circle(ctx, cx, cy, r); ctx.fill();
  ctx.restore();
}
/** Inset groove ring (trench) — dark inner edge top-left, light edge bottom-right. */
function grooveRing(ctx: Ctx, cx: number, cy: number, r: number, n: NeuTones, w = 2.6) {
  ctx.lineWidth = w; ctx.strokeStyle = n.groove; circle(ctx, cx - 0.7, cy - 0.7, r); ctx.stroke();
  ctx.lineWidth = w * 0.6; ctx.strokeStyle = n.grooveHi; circle(ctx, cx + 0.9, cy + 0.9, r); ctx.stroke();
  ctx.lineWidth = w * 0.45; ctx.strokeStyle = n.surface; circle(ctx, cx, cy, r); ctx.stroke();
  ctx.lineWidth = 1;
}
/** Inset track (rounded rect trench) for bars / columns / plot panels. */
function insetTrack(ctx: Ctx, x: number, y: number, w: number, h: number, n: NeuTones, r?: number) {
  const rr = Math.min(r ?? h / 2, w / 2, h / 2);
  ctx.fillStyle = n.lo; ctx.beginPath(); ctx.roundRect(x, y, w, h, rr); ctx.fill();
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, n.groove); g.addColorStop(1, n.grooveHi);
  ctx.strokeStyle = g; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.roundRect(x + 0.6, y + 0.6, w - 1.2, h - 1.2, Math.max(0, rr - 0.6)); ctx.stroke();
  ctx.lineWidth = 1;
}
function wedgePath(ctx: Ctx, cx: number, cy: number, R: number, rIn: number, a0: number, a1: number) {
  ctx.beginPath();
  if (rIn > 0) { ctx.arc(cx, cy, R, a0, a1); ctx.arc(cx, cy, rIn, a1, a0, true); ctx.closePath(); }
  else { ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, a0, a1); ctx.closePath(); }
}

export interface NeuDraw { data: ChartDatum[]; colors: string[]; t: Theme; p: number; hover: number | null; amt: number; centerLabel: string; full: boolean }

/* ---- circular: puck + groove ring + carved wedges + raised centre ---- */
export function paintNeuCircular(ctx: Ctx, isDonut: boolean, cx: number, cy: number, R: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const { data, colors, p, hover, amt } = d;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const rIn = isDonut ? R * 0.56 : 0;
  const scale = 0.94 + 0.06 * clamp01(p * 1.4);

  ctx.save();
  if (scale < 0.999) { ctx.translate(cx, cy); ctx.scale(scale, scale); ctx.translate(-cx, -cy); }
  raisedDisc(ctx, cx, cy, R + 18, n);
  grooveRing(ctx, cx, cy, R + 9, n);

  let a = -Math.PI / 2;
  const mids: number[] = [];
  data.forEach((x, i) => {
    const frac = x.value / total;
    const a1 = a + frac * Math.PI * 2 * p;
    const mid = (a + a1) / 2;
    mids.push(mid);
    const on = hover === i;
    const off = on ? 6 * amt : 0;
    const col = colors[i];
    ctx.save();
    ctx.globalAlpha = hover !== null && !on ? 1 - 0.42 * amt : 1;
    ctx.translate(Math.cos(mid) * off, Math.sin(mid) * off);
    wedgePath(ctx, cx, cy, R, rIn, a, a1);
    const g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
    g.addColorStop(0, shade(col, 1.14)); g.addColorStop(1, shade(col, 0.86));
    setShadow(ctx, 2, 3, on ? 10 : 6, on ? rgba(col, 0.55) : 'rgba(0,0,0,0.28)');
    ctx.fillStyle = g; ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = n.surface; ctx.lineWidth = 3; ctx.lineJoin = 'round'; ctx.stroke(); // divider grooves
    ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 1; ctx.stroke();          // bevel
    ctx.lineJoin = 'miter';
    ctx.restore();
    a = a1;
  });

  // on-slice % labels (fade in as the sweep completes)
  if (p > 0.85) {
    ctx.save();
    ctx.globalAlpha = clamp01((p - 0.85) / 0.15);
    ctx.font = font(d.t, 700, R >= 110 ? 12 : R >= 80 ? 10.5 : 9.5);
    ctx.textAlign = 'center';
    setShadow(ctx, 0, 1, 2, 'rgba(0,0,0,0.45)');
    data.forEach((x, i) => {
      const frac = x.value / total;
      if (frac < 0.06) return;
      const on = hover === i;
      const off = on ? 6 * amt : 0;
      const lr = (rIn > 0 ? (R + rIn) / 2 : R * 0.62) + off;
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`${Math.round(frac * 100)}%`, cx + Math.cos(mids[i]) * lr, cy + Math.sin(mids[i]) * lr + 3.5);
    });
    ctx.restore();
  }

  // raised centre button (donut) — total or hovered slice
  if (isDonut) {
    const cr = rIn - 7;
    raisedDisc(ctx, cx, cy, cr, n, 0.7);
    ctx.strokeStyle = rgba(d.t.ink, 0.08); ctx.lineWidth = 1; circle(ctx, cx, cy, cr - 3); ctx.stroke();
    const value = hover !== null ? data[hover].value : total;
    const label = hover !== null ? data[hover].label : d.centerLabel;
    const vs = Math.max(13, Math.min(28, cr * 0.5));
    ctx.textAlign = 'center';
    ctx.fillStyle = d.t.ink; ctx.font = font(d.t, 700, vs, true);
    ctx.fillText(fitCtx(ctx, String(value), cr * 1.7), cx, cy + vs * 0.18);
    ctx.fillStyle = n.muted; ctx.font = font(d.t, 700, Math.max(7.5, Math.min(10, cr * 0.18)));
    ctx.fillText(fitCtx(ctx, label.toUpperCase(), cr * 1.7), cx, cy + vs * 0.18 + Math.max(10, cr * 0.24));
  }
  ctx.restore();
  ctx.textAlign = 'left';
}

/* ---- horizontal soft bars (export painter; live uses DOM) ---- */
function paintNeuBars(ctx: Ctx, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const max = Math.max(...d.data.map((x) => x.value), 1);
  const N = d.data.length;
  const rowH = Math.min(48, (H - 12) / Math.max(1, N));
  d.data.forEach((x, i) => {
    const y = 8 + i * rowH;
    const col = d.colors[i];
    ctx.font = font(d.t, 600, 11.5); ctx.fillStyle = rgba(d.t.ink, 0.78); ctx.textAlign = 'left';
    ctx.fillText(x.label, 14, y + 12);
    ctx.font = font(d.t, 700, 11.5); ctx.fillStyle = d.t.ink; ctx.textAlign = 'right';
    ctx.fillText(String(x.value), W - 14, y + 12);
    const tx = 14, ty = y + 19, tw = W - 28, th = 14;
    insetTrack(ctx, tx, ty, tw, th, n);
    const bw = Math.max(th, tw * (x.value / max) * d.p);
    const g = ctx.createLinearGradient(tx, ty, tx + bw, ty + th);
    g.addColorStop(0, col); g.addColorStop(1, shade(col, 0.82));
    setShadow(ctx, 1, 1, 3, 'rgba(0,0,0,0.25)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(tx, ty, bw, th, 7); ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(tx + 1, ty + 1, bw - 2, th - 2, 6); ctx.stroke();
  });
  ctx.textAlign = 'left';
}

/* ---- vertical soft columns (export painter; live uses DOM) ---- */
function paintNeuColumns(ctx: Ctx, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const max = Math.max(...d.data.map((x) => x.value), 1);
  const N = d.data.length;
  const padT = 28, padR = 14;
  const { plan, l: padL, step } = planXFit(d.data.map((x) => x.label), W, 14, padR, d.full, 9.5, N);
  const ch = Math.max(30, H - padT - plan.padB - 6);
  const colW = Math.min(44, step * 0.62);
  d.data.forEach((x, i) => {
    const cx = padL + step * i + step / 2;
    const col = d.colors[i];
    insetTrack(ctx, cx - colW / 2, padT, colW, ch, n, 12);
    const h = Math.max(6, ch * (x.value / max) * d.p);
    const g = ctx.createLinearGradient(cx - colW / 2, padT + ch - h, cx + colW / 2, padT + ch);
    g.addColorStop(0, col); g.addColorStop(1, shade(col, 0.82));
    setShadow(ctx, 0, -1, 3, 'rgba(0,0,0,0.18)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(cx - colW / 2, padT + ch - h, colW, h, 12); ctx.fill();
    noShadow(ctx);
    ctx.font = font(d.t, 700, 10.5); ctx.fillStyle = rgba(d.t.ink, 0.72); ctx.textAlign = 'center';
    ctx.fillText(String(x.value), cx, padT - 9);
  });
  drawXLabels(ctx, d.data.map((x) => x.label), plan, (i) => padL + step * i + step / 2, padT + ch, d.t, W, 700, n.muted);
}

/* ---- soft line / area: inset panel, dotted grid, adaptive labels & markers ---- */
interface NeuLineLayout { padL: number; padT: number; cw: number; ch: number; step: number; plan: XPlan; xOf: (i: number) => number; yOf: (v: number) => number; max: number }
function neuLineLayout(W: number, H: number, data: ChartDatum[], full: boolean): NeuLineLayout {
  const max = Math.max(...data.map((x) => x.value), 1);
  const fs = 10;
  const padR = 18, padT = 24;
  const N = data.length;
  const { plan, l: padL, step } = planXFit(data.map((x) => x.label), W, 14 + approxW(fmtNum(max), 9.5) + 12, padR, full, fs, N, true);
  const cw = Math.max(10, W - padL - padR);
  const ch = Math.max(20, H - padT - plan.padB - 6);
  return {
    padL, padT, cw, ch, step, plan, max,
    xOf: (i) => padL + (N > 1 ? step * i : cw / 2),
    yOf: (v) => padT + ch * (1 - v / max),
  };
}
export function paintNeuLine(ctx: Ctx, isArea: boolean, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const { data, colors, p, hover } = d;
  if (!data.length) return;
  const L = neuLineLayout(W, H, data, d.full);
  const { padL, padT, cw, ch, step, plan, xOf, yOf, max } = L;
  const col = colors[0];
  const N = data.length;

  // inset plot panel
  const px0 = padL - 10, py0 = padT - 12, pw = cw + 22, ph = ch + 24;
  insetTrack(ctx, px0, py0, pw, ph, n, 16);
  // dotted grid — aligns to points when few, otherwise a 6-column lattice
  const gcols = N <= 12 ? N : 6;
  ctx.fillStyle = n.grid;
  for (let gx = 0; gx < gcols; gx++) for (let gy = 0; gy <= 3; gy++) {
    const x = N <= 12 ? xOf(gx) : padL + (gx * cw) / 5;
    circle(ctx, x, padT + (gy * ch) / 3, 1.4); ctx.fill();
  }
  // y ticks
  ctx.font = font(d.t, 600, 9.5); ctx.fillStyle = n.muted; ctx.textAlign = 'right';
  for (let g = 0; g <= 3; g++) ctx.fillText(fmtNum((max * g) / 3), padL - 14, padT + ch - (ch * g) / 3 + 3.5);

  const pts = data.map((x, i) => ({ x: xOf(i), y: yOf(x.value) }));
  // reveal left → right while the entrance animation runs (live only)
  const revealing = p < 1 && typeof ctx.clip === 'function';
  if (revealing) { ctx.save(); ctx.beginPath(); ctx.rect(0, 0, padL + cw * p + 10, H); ctx.clip(); }
  const curve = () => {
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
      ctx.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y - (p3.y - p1.y) / 6, p2.x, p2.y);
    }
  };
  if (isArea && N > 1) {
    ctx.beginPath(); curve();
    ctx.lineTo(pts[pts.length - 1].x, padT + ch); ctx.lineTo(pts[0].x, padT + ch); ctx.closePath();
    const g = ctx.createLinearGradient(0, padT, 0, padT + ch);
    g.addColorStop(0, rgba(col, 0.36)); g.addColorStop(1, rgba(col, 0.03));
    ctx.fillStyle = g; ctx.fill();
  }
  if (N > 1) {
    setShadow(ctx, 2, 3, 3, rgba(d.t.ink, 0.28));
    ctx.strokeStyle = col; ctx.lineWidth = N > 40 ? 2.2 : 3.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); curve(); ctx.stroke();
    noShadow(ctx);
    ctx.lineCap = 'butt'; ctx.lineJoin = 'miter';
  }
  // markers thin out automatically; the hovered point is always shown
  const showAll = step >= 12;
  pts.forEach((pt, i) => {
    const on = hover === i;
    if (!showAll && !on) return;
    setShadow(ctx, 1.5, 1.5, 2, rgba(d.t.ink, 0.25));
    ctx.fillStyle = n.surface; circle(ctx, pt.x, pt.y, on ? 7 : step < 26 ? 4.2 : 5.5); ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = col; ctx.lineWidth = 2.5; ctx.stroke();
  });
  if (revealing) ctx.restore();

  drawXLabels(ctx, data.map((x) => x.label), plan, xOf, padT + ch + 10, d.t, W, 700, n.muted);
}

/* ---- export composition for the neumorphic family ---- */
export function neuExportDims(kind: NeuKind, data: ChartDatum[]): { W: number; H: number } {
  const N = data.length;
  if (kind === 'donut' || kind === 'pie') {
    const total = data.reduce((s, x) => s + x.value, 0) || 1;
    const legW = data.reduce((m, x) => Math.max(m, approxW(x.label, 11.5) + approxW(`  ${x.value} · ${Math.round((x.value / total) * 100)}%`, 11.5)), 0) + 44;
    const cols = Math.max(1, Math.ceil(N / 16));
    return { W: Math.round(Math.max(600, 24 + 340 + 28 + legW * cols + 20)), H: Math.max(400, 60 + Math.min(N, 16) * 20 + 40) };
  }
  if (kind === 'bars') return { W: 640, H: 40 + N * 48 + 16 };
  if (kind === 'columns') return { W: Math.max(640, N * 42 + 60), H: 400 };
  return { W: Math.max(720, N * 24 + 120), H: 400 };
}
export function paintNeuExport(ctx: Ctx, W: number, H: number, kind: NeuKind, d: NeuDraw, title: string) {
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H);
  const top = title ? 40 : 14;
  if (title) { ctx.fillStyle = '#1c2620'; ctx.font = font(d.t, 700, 15, true); ctx.textAlign = 'left'; ctx.fillText(fitCtx(ctx, title, W - 32), 16, 26); }
  if (kind === 'donut' || kind === 'pie') {
    const total = d.data.reduce((s, x) => s + x.value, 0) || 1;
    const S = Math.min(H - top - 16, 340);
    const R = S / 2 - 22;
    const cx = 24 + S / 2, cy = top + (H - top) / 2;
    paintNeuCircular(ctx, kind === 'donut', cx, cy, R, d);
    // legend — right-aligned value column guarantees zero text overlap in SVG vector exports
    const maxLblW = d.data.reduce((m, x) => Math.max(m, approxW(x.label, 11.5)), 0);
    const legW = Math.max(220, maxLblW + 90);
    const x0 = 24 + S + 28;
    d.data.forEach((x, i) => {
      const colI = Math.floor(i / 16), row = i % 16;
      const lx = x0 + colI * legW, ly = top + 26 + row * 22;
      ctx.fillStyle = d.colors[i]; circle(ctx, lx + 4, ly - 4, 4.5); ctx.fill();
      ctx.font = font(d.t, 600, 11.5); ctx.fillStyle = '#1c2620'; ctx.textAlign = 'left';
      ctx.fillText(x.label, lx + 15, ly);
      ctx.fillStyle = '#6b746e'; ctx.textAlign = 'right';
      ctx.fillText(`${x.value} · ${Math.round((x.value / total) * 100)}%`, lx + legW - 10, ly);
      ctx.textAlign = 'left';
    });
  } else {
    ctx.save(); ctx.translate(0, top);
    const h = H - top;
    if (kind === 'bars') paintNeuBars(ctx, W, h, d);
    else if (kind === 'columns') paintNeuColumns(ctx, W, h, d);
    else paintNeuLine(ctx, kind === 'area', W, h, d);
    ctx.restore();
  }
  ctx.textAlign = 'left';
}

/* ---- live canvas for the neumorphic kinds (circular + line/area) ---- */
function NeuCanvas({ kind, data, colors, size, height, centerLabel, hover, onHover, full }: {
  kind: NeuKind; data: ChartDatum[]; colors: string[]; size: number; height: number; centerLabel: string;
  hover: number | null; onHover: (i: number | null) => void; full: boolean;
}) {
  const circular = kind === 'donut' || kind === 'pie';
  const S = size + 36;
  const ref = useRef<HTMLCanvasElement>(null);
  const progRef = useRef(0);
  const amtRef = useRef(0);
  const hovRef = useRef<number | null>(null);
  const rafRef = useRef(0);
  const hovRafRef = useRef(0);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);
  const themeTick = useThemeTick();
  const themeRef = useRef<Theme>(themeColors());
  useEffect(() => { themeRef.current = themeColors(); }, [themeTick]);
  const dataSig = useMemo(() => JSON.stringify(data.map((x) => [x.label, x.value])), [data]);

  const draw = useCallback(() => {
    const cv = ref.current;
    if (!cv) return;
    const W = circular ? S : cv.clientWidth, H = circular ? S : height;
    if (W <= 0 || H <= 0) { requestAnimationFrame(() => draw()); return; }
    const dpr = window.devicePixelRatio || 1;
    const bw = Math.round(W * dpr), bh = Math.round(H * dpr);
    if (cv.width !== bw || cv.height !== bh) { cv.width = bw; cv.height = bh; }
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const d: NeuDraw = { data, colors, t: themeRef.current, p: easeOut(progRef.current), hover: hovRef.current, amt: amtRef.current, centerLabel, full };
    if (circular) paintNeuCircular(ctx, kind === 'donut', W / 2, H / 2, size / 2 - 4, d);
    else paintNeuLine(ctx, kind === 'area', W, H, d);
  }, [circular, S, height, data, colors, centerLabel, full, kind, size]);

  /* entrance sweep / draw-in */
  useEffect(() => {
    cancelAnimationFrame(rafRef.current);
    progRef.current = 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      progRef.current = Math.min(1, (now - t0) / 900);
      draw();
      if (progRef.current < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, dataSig]);

  /* hover amount animation */
  useEffect(() => {
    const goal = hover !== null ? 1 : 0;
    if (hover !== null) {
      // moving straight from one slice to another re-plays part of the pop
      if (hovRef.current !== null && hovRef.current !== hover) amtRef.current = Math.min(amtRef.current, 0.35);
      hovRef.current = hover;
    }
    cancelAnimationFrame(hovRafRef.current);
    const tick = () => {
      const diff = goal - amtRef.current;
      if (Math.abs(diff) < 0.02) {
        amtRef.current = goal;
        if (goal === 0) hovRef.current = null;
        if (progRef.current >= 1) draw();
        return;
      }
      amtRef.current += diff * 0.22;
      if (progRef.current >= 1) draw();
      hovRafRef.current = requestAnimationFrame(tick);
    };
    hovRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(hovRafRef.current);
  }, [hover, draw]);

  useEffect(() => { if (progRef.current >= 1) draw(); }, [themeTick, draw]);
  useEffect(() => {
    const cv = ref.current;
    let ro: ResizeObserver | null = null;
    if (cv && typeof ResizeObserver !== 'undefined') { ro = new ResizeObserver(() => draw()); ro.observe(cv); }
    window.addEventListener('resize', draw);
    return () => { ro?.disconnect(); window.removeEventListener('resize', draw); };
  }, [draw]);

  const hit = (e: React.MouseEvent) => {
    const cv = ref.current;
    if (!cv || !data.length) return;
    const r = cv.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    let idx: number | null = null;
    if (circular) {
      const R = size / 2 - 4, rIn = kind === 'donut' ? R * 0.56 : 0;
      const ex = mx - S / 2, ey = my - S / 2;
      const rad = Math.hypot(ex, ey);
      if (rad <= R + 8 && rad >= Math.max(0, rIn - 6)) {
        const total = data.reduce((s, x) => s + x.value, 0) || 1;
        let ang = Math.atan2(ey, ex) + Math.PI / 2;
        ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        let acc = 0;
        for (let i = 0; i < data.length; i++) { acc += (data[i].value / total) * Math.PI * 2; if (ang <= acc) { idx = i; break; } }
      }
      onHover(idx);
      setTip(null);
    } else {
      const L = neuLineLayout(r.width, height, data, full);
      let best = Math.max(10, L.step / 2), bi: number | null = null;
      data.forEach((_, i) => { const dd = Math.abs(mx - L.xOf(i)); if (dd < best) { best = dd; bi = i; } });
      idx = bi;
      onHover(idx);
      if (idx !== null) {
        const px = L.xOf(idx), py = L.yOf(data[idx].value);
        setTip({ x: Math.max(4, Math.min(r.width - 150, px - 50)), y: Math.max(0, py - 40), text: `${data[idx].label}: ${data[idx].value}` });
      } else setTip(null);
    }
  };

  return (
    <div className="relative shrink-0" style={circular ? { width: S, height: S } : { width: '100%', height }}>
      <canvas ref={ref} style={{ width: '100%', height: '100%', display: 'block', cursor: 'pointer' }}
        onMouseMove={hit} onMouseLeave={() => { onHover(null); setTip(null); }} />
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 px-2.5 py-1 font-body text-[11px] font-bold text-ink" style={{ left: tip.x, top: tip.y }}>
          {tip.text}
        </div>
      )}
    </div>
  );
}

export function NeuChart({ data, title, defaultKind = 'donut', size = 158, centerLabel = 'total', legendSide = false, loading = false, isFullscreen = false }: {
  data: ChartDatum[]; title?: string; defaultKind?: NeuKind; size?: number; centerLabel?: string; legendSide?: boolean; loading?: boolean; isFullscreen?: boolean;
}) {
  const [kind, setKind] = useState<NeuKind>(defaultKind);
  const [hover, setHover] = useState<number | null>(null);
  const [full, setFull] = useState(false);
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const max = Math.max(...data.map((d) => d.value), 1);
  const themeTick = useThemeTick();
  const pal = useMemo(() => activePalette(), [themeTick]); // eslint-disable-line react-hooks/exhaustive-deps
  const colors = useMemo(() => data.map((d, i) => d.color || pal[i % pal.length]), [data, pal]);
  const dataSig = useMemo(() => JSON.stringify(data.map((x) => [x.label, x.value])), [data]);
  const circular = kind === 'donut' || kind === 'pie';

  const doExport = async (fmt: string) => {
    const base = (title || 'chart').toLowerCase().replace(/\s+/g, '-');
    if (fmt === 'csv') {
      downloadBlob(`${base}.csv`, new Blob(['label,value\n' + data.map((d) => `"${d.label}",${d.value}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'json') {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel') {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Data');
      const head = ws.addRow(['Label', 'Value']);
      head.eachCell((cell: { font: unknown; fill: unknown }) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
      });
      data.forEach((d) => ws.addRow([d.label, d.value]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }
    await fontsReady();
    const t = themeColors(true);
    const { W, H } = neuExportDims(kind, data);
    const d: NeuDraw = { data, colors, t, p: 1, hover: null, amt: 0, centerLabel, full: true };
    if (fmt === 'svg') {
      const rec = new SvgCtx(W, H);
      rec.fontCss = await fontFaceCss(fontFamilies(t), ['600', '700']);
      paintNeuExport(rec as unknown as Ctx, W, H, kind, d, title || 'Chart');
      downloadBlob(`${base}.svg`, new Blob([rec.toString()], { type: 'image/svg+xml' }));
      return;
    }
    const scale = 3;
    const cv = document.createElement('canvas');
    cv.width = W * scale; cv.height = H * scale;
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    paintNeuExport(ctx, W, H, kind, d, title || 'Chart');
    if (fmt === 'png') cv.toBlob((b) => b && downloadBlob(`${base}.png`, b), 'image/png');
    else if (fmt === 'pdf') {
      const dataUrl = cv.toDataURL('image/jpeg', 0.94);
      const bytes = Uint8Array.from(atob(dataUrl.split(',')[1]), (c) => c.charCodeAt(0));
      downloadBlob(`${base}.pdf`, jpegToPdf(bytes, cv.width, cv.height));
    } else if (fmt === 'print') printCanvas(title || 'Chart', cv);
  };

  /* ---- horizontal soft bars (DOM, CSS-grown on entrance) ---- */
  const bars = (
    <div key={`bars-${dataSig}`} className="w-full space-y-3">
      {data.map((d, i) => (
        <div key={d.label} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
          <div className="mb-1 flex justify-between font-body text-[11.5px]">
            <span className={`font-semibold ${hover === i ? 'text-ink' : 'text-ink/75'}`}>{d.label}</span>
            <span className="font-bold tabular-nums text-ink">{d.value}</span>
          </div>
          <div className="tk-inset h-4 overflow-hidden rounded-full">
            <div className="tk-grow-w h-full rounded-full transition-[filter] duration-300"
              style={{
                width: `${(d.value / max) * 100}%`, animationDelay: `${i * 70}ms`,
                background: `linear-gradient(145deg, ${shade(colors[i], 1.08)}, ${shade(colors[i], 0.8)})`,
                boxShadow: '1px 1px 3px rgba(0,0,0,0.25), inset 0 1px 1px rgba(255,255,255,0.4)',
                filter: hover === i ? 'brightness(1.12)' : hover !== null ? 'saturate(0.6) opacity(0.7)' : undefined,
              }} />
          </div>
        </div>
      ))}
    </div>
  );

  /* ---- vertical soft columns (DOM, CSS-grown on entrance, adaptive labels) ---- */
  const columns = (() => {
    const N = Math.max(1, data.length);
    const rotate = N > 6;
    return (
      <div key={`cols-${dataSig}`} className="w-full">
        <div className="flex w-full items-end justify-around gap-1.5" style={{ height: size + 24 }}>
          {data.map((d, i) => (
            <div key={d.label} className="flex min-w-0 flex-1 flex-col items-center gap-1.5"
              onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              <span className="font-body text-[10.5px] font-bold tabular-nums text-ink/70">{d.value}</span>
              <div className="tk-inset flex w-full max-w-[44px] items-end overflow-hidden rounded-xl" style={{ height: size - 10 }}>
                <div className="tk-grow-h w-full rounded-xl transition-[filter] duration-300"
                  style={{
                    height: `${(d.value / max) * 100}%`, animationDelay: `${i * 70}ms`,
                    background: `linear-gradient(145deg, ${shade(colors[i], 1.08)}, ${shade(colors[i], 0.8)})`,
                    boxShadow: 'inset 0 2px 2px rgba(255,255,255,0.35), 0 -1px 3px rgba(0,0,0,0.15)',
                    filter: hover === i ? 'brightness(1.12)' : hover !== null ? 'saturate(0.6) opacity(0.7)' : undefined,
                  }} />
              </div>
            </div>
          ))}
        </div>
        <div className="mt-1.5 flex w-full justify-around gap-1.5" style={{ height: rotate ? 52 : 16 }}>
          {data.map((d, i) => (
            <div key={d.label} className="flex min-w-0 flex-1 justify-center">
              <span data-tip={d.label} title={d.label}
                className={`font-body text-[9.5px] font-bold uppercase tracking-wide ${hover === i ? 'text-ink' : 'text-muted'} ${rotate ? 'origin-top-right whitespace-nowrap' : 'w-full truncate text-center'}`}
                style={rotate ? { maxWidth: 64, overflow: 'hidden', textOverflow: 'ellipsis', transform: 'translateX(-50%) rotate(-45deg)' } : undefined}>
                {rotate ? d.label : fitText(d.label, 52, 9.5)}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  })();

  const containerRef = useRef<HTMLDivElement>(null);
  const [isFs, setIsFs] = useState(false);

  useEffect(() => {
    const onFs = () => {
      const active = !!document.fullscreenElement && document.fullscreenElement === containerRef.current;
      setIsFs(active);
    };
    document.addEventListener('fullscreenchange', onFs);
    document.addEventListener('webkitfullscreenchange', onFs);
    return () => {
      document.removeEventListener('fullscreenchange', onFs);
      document.removeEventListener('webkitfullscreenchange', onFs);
    };
  }, []);

  /* Lock the page scroll while the CSS-fallback overlay is open. */
  useEffect(() => {
    if (!full) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, [full]);

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      try {
        if (containerRef.current?.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        } else if ((containerRef.current as unknown as { webkitRequestFullscreen?: () => Promise<void> })?.webkitRequestFullscreen) {
          await (containerRef.current as unknown as { webkitRequestFullscreen: () => Promise<void> }).webkitRequestFullscreen();
        }
        setIsFs(true);
      } catch {
        setFull(true);
      }
    } else {
      try {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as unknown as { webkitExitFullscreen?: () => Promise<void> })?.webkitExitFullscreen) {
          await (document as unknown as { webkitExitFullscreen: () => Promise<void> }).webkitExitFullscreen();
        }
      } catch { /* noop */ }
      setIsFs(false);
      setFull(false);
    }
  };

  const legendEl = (
    <div className={legendSide && circular ? 'min-w-0 flex-1 space-y-2' : 'mt-3 flex flex-wrap justify-center gap-x-4 gap-y-1.5'}>
      {data.map((d, i) => {
        const pct = Math.round((d.value / total) * 100);
        const on = hover === i;
        return (
          <button key={d.label} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}
            className={`flex items-center gap-2 font-body text-[11.5px] font-semibold transition ${on ? 'text-ink' : 'text-ink/75'} ${legendSide && circular ? 'w-full pr-1' : ''}`}>
            <span className="flex min-w-0 flex-1 items-center gap-2">
              <span className="h-2.5 w-2.5 shrink-0 rounded-full transition-shadow"
                style={{ background: colors[i], boxShadow: on ? `0 0 0 3px ${rgba(colors[i], 0.22)}` : '0.5px 0.5px 1.5px rgba(0,0,0,0.3)' }} />
              <span className="truncate">{d.label}</span>
              <span className="shrink-0 text-muted text-[10.5px]">({pct}%)</span>
            </span>
            {legendSide && circular && (
              <span className="ml-2 shrink-0 tabular-nums font-bold text-ink/80 text-[11px] px-2 py-0.5 rounded-md bg-black/5 dark:bg-white/10">{d.value}</span>
            )}
          </button>
        );
      })}
    </div>
  );

  const canvasEl = (
    <NeuCanvas kind={kind} data={data} colors={colors} size={isFs ? Math.min(380, window.innerHeight - 240) : size} height={isFs ? Math.min(420, window.innerHeight - 200) : size + 40} centerLabel={centerLabel}
      hover={hover} onHover={setHover} full={isFullscreen || isFs} />
  );

  const body = (
    <div ref={containerRef} className={`tk-card ${isFs ? '!fixed !inset-0 !z-[100] !w-screen !h-screen !m-0 !rounded-none !p-6 sm:!p-10 flex flex-col justify-between overflow-y-auto overflow-x-hidden bg-(--t-surface)' : 'p-4'}`}>
      {/* No toolbar z-index: MiniDrop menus are portalled to document.body. */}
      <div className="relative mb-3 flex flex-wrap items-center gap-2">
        {title && <p className={`mr-auto font-display font-semibold text-ink ${isFs ? 'text-xl' : 'text-[14px]'}`}>{title}</p>}
        <MiniDrop label={NEU_KINDS.find((k) => k.key === kind)!.label} activeKey={kind}
          items={NEU_KINDS.map((k) => ({ key: k.key, label: k.label }))}
          onPick={(k) => { setKind(k as NeuKind); setHover(null); }} />
        <MiniDrop label="Export" icon={<Download size={12} />}
          items={[
            { key: 'png', label: 'PNG image' },
            { key: 'svg', label: 'SVG vector' },
            { key: 'pdf', label: 'PDF document' },
            { key: 'excel', label: 'Excel workbook' },
            { key: 'print', label: 'Print…' },
            { key: 'csv', label: 'CSV data' },
            { key: 'json', label: 'JSON data' },
          ]}
          onPick={doExport} />
        {!isFullscreen && (
          <button onClick={toggleFullscreen} data-tip={isFs ? "Exit fullscreen" : "View fullscreen"} className="tk-btn-ghost rounded-xl p-2">
            {isFs ? <Minimize2 size={15} /> : <Eye size={14} />}
          </button>
        )}
      </div>

      {loading ? (
        <ChartSkeleton kind={circular ? 'circle' : kind === 'bars' ? 'bars' : kind === 'columns' ? 'columns' : 'line'} height={size + 40} legend={legendSide && circular} />
      ) : data.length === 0 ? (
        <div className="flex items-center justify-center font-body text-[12.5px] text-muted" style={{ minHeight: size + 40 }}>No data to chart.</div>
      ) : circular ? (
        legendSide
          ? <div className={`flex items-center gap-6 ${isFs ? 'max-w-4xl mx-auto w-full my-auto' : ''}`}>{canvasEl}{legendEl}</div>
          : <div className={`flex flex-col items-center ${isFs ? 'my-auto' : ''}`}>{canvasEl}{legendEl}</div>
      ) : kind === 'bars' ? bars
        : kind === 'columns' ? columns
        : canvasEl}
    </div>
  );

  return (
    <>
      {body}
      {full && createPortal(
        <div className="fixed inset-0 z-[100] flex flex-col bg-(--t-surface) p-6 sm:p-10 backdrop-blur-md overflow-y-auto overflow-x-hidden max-w-[100vw]"
          onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) setFull(false); }}>
          <div className="mb-3 flex justify-between items-center">
            {title && <h2 className="font-display text-xl font-bold text-ink">{title}</h2>}
            <button onClick={() => setFull(false)} className="tk-btn-ghost rounded-full p-2.5 ml-auto"><X size={18} /></button>
          </div>
          <div className="flex-1 w-full min-w-0 max-w-full flex items-center justify-center">
            <NeuChart data={data} title={title} defaultKind={kind}
              size={Math.max(240, Math.min(380, window.innerHeight - 300))} centerLabel={centerLabel} legendSide isFullscreen />
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

/* compat wrappers */
export function NeuDonut(props: { data: ChartDatum[]; title?: string; size?: number; centerLabel?: string; legendSide?: boolean; loading?: boolean }) {
  return <NeuChart {...props} defaultKind="donut" />;
}
export function NeuBars({ data, title, loading }: { data: ChartDatum[]; title?: string; loading?: boolean }) {
  return <NeuChart data={data} title={title} defaultKind="bars" loading={loading} />;
}


