/* ============================================================
   Radial Bar reference presets — the EXACT three datasets from the
   supplied interativeRadialBarChart.html (`const PRESETS = {...}`),
   copied verbatim (including the reference's own "Lorem Ipsum" slide
   labels). This is the single source of truth for both the Three.js
   scene builder (ThreeReferenceRadialBar) and the card's outer legend
   row / export legend, so the chart never shows two different label
   sets for the same preset.
   ============================================================ */

export type RadialPresetKey = 'olympic' | 'slide_template' | 'updating_points';

export interface OlympicRow { country: string; gold: number; silver: number; bronze: number }
export interface SlideRow { label: string; value: string; percent: number; color: string; radius: number }
export interface UpdatingRow { ring: number; val1: number; val2: number }

export interface RadialPresets {
  olympic: { title: string; subtitle: string; data: OlympicRow[]; colors: { gold: string; silver: string; bronze: string }; maxVal: number };
  slide_template: { title: string; subtitle: string; data: SlideRow[] };
  updating_points: { title: string; subtitle: string; data: UpdatingRow[]; colors: string[] };
}

export const RADIAL_PRESETS: RadialPresets = {
  olympic: {
    title: 'Winter Olympic medals per existing country (TOP 5)',
    subtitle: 'Source: Wikipedia',
    data: [
      { country: 'Norway', gold: 148, silver: 133, bronze: 124 },
      { country: 'United States', gold: 114, silver: 121, bronze: 95 },
      { country: 'Germany', gold: 104, silver: 98, bronze: 65 },
      { country: 'Austria', gold: 71, silver: 88, bronze: 91 },
      { country: 'Canada', gold: 77, silver: 72, bronze: 76 },
    ],
    colors: { gold: '#f5cc00', silver: '#b5b8bd', bronze: '#d97d38' },
    maxVal: 425,
  },
  slide_template: {
    title: 'Radial Bar Chart – Slide Template',
    subtitle: 'Custom racetrack percentage arcs',
    data: [
      { label: 'Lorem Ipsum', value: '90%', percent: 0.90, color: '#9bbd5c', radius: 3.2 },
      { label: 'Lorem Ipsum', value: '60%', percent: 0.60, color: '#c8381e', radius: 2.6 },
      { label: 'Lorem Ipsum', value: '20%', percent: 0.20, color: '#41b6e6', radius: 2.0 },
      { label: 'Lorem Ipsum', value: '50%', percent: 0.50, color: '#f08c28', radius: 1.4 },
      { label: 'Lorem Ipsum', value: '30%', percent: 0.30, color: '#385272', radius: 0.8 },
    ],
  },
  updating_points: {
    title: 'Updating points with color axis',
    subtitle: 'Polar radial visualization with continuous color gradient',
    data: [
      { ring: 0, val1: 1.8, val2: 1.2 },
      { ring: 1, val1: 3.2, val2: 0.8 },
      { ring: 2, val1: 4.5, val2: 0.0 },
      { ring: 3, val1: 5.8, val2: 0.0 },
      { ring: 4, val1: 6.2, val2: 0.0 },
      { ring: 5, val1: 7.0, val2: 0.0 },
      { ring: 6, val1: 5.5, val2: 1.5 },
      { ring: 7, val1: 4.8, val2: 2.1 },
      { ring: 8, val1: 1.1, val2: 0.9 },
      { ring: 9, val1: 0.6, val2: 0.4 },
    ],
    colors: ['#a7f3d0', '#34d399', '#38bdf8', '#0284c7'],
  },
};

export const RADIAL_PRESET_OPTIONS: { key: RadialPresetKey; label: string }[] = [
  { key: 'olympic', label: 'Winter Olympic Medals (TOP 5)' },
  { key: 'slide_template', label: 'Slide Template (Percentage Radial)' },
  { key: 'updating_points', label: 'Updating Points with Color Axis' },
];

/** ONE colour-labelled legend per preset — shared by the card's outer
 * legend row and by every export (PNG/SVG), so labels never appear twice
 * or disagree between the on-screen legend and a downloaded file. */
export function radialLegendFor(key: RadialPresetKey): { label: string; color: string }[] {
  if (key === 'olympic') {
    const c = RADIAL_PRESETS.olympic.colors;
    return [
      { label: 'Gold medals', color: c.gold },
      { label: 'Silver medals', color: c.silver },
      { label: 'Bronze medals', color: c.bronze },
    ];
  }
  if (key === 'slide_template') {
    return RADIAL_PRESETS.slide_template.data.map((row) => ({ label: `${row.label} (${row.value})`, color: row.color }));
  }
  return RADIAL_PRESETS.updating_points.colors.map((color, i) => ({ label: `Scale ${i * 2}–${i * 2 + 2}`, color }));
}
