import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import type { ThreeChartHandle } from './ThreeSankey3D';
import type { ExportTheme } from './exportUtils';
import { buildThreePNG, captureLabelPositions, withExportResolution } from './exportUtils';
import { RADIAL_PRESETS, radialLegendFor, type RadialPresetKey } from './radialPresets';
import { applyFramedLerp, beginFramedTween, capturePose, easeInOutCubic, endFramedTween, type CamPose } from './framedTween';

/* ============================================================
   Radial Bar — native Three.js port of the supplied
   interativeRadialBarChart.html, byte-faithful to its own geometry,
   camera, animation and labelling method, but wired into this app's
   OWN chart chrome instead of an isolated iframe:
     - no separate white panel / header — the scene is transparent and
       sits directly inside the card, camera positions/targets and the
       Cubic-Out 1100ms tween EXACTLY as the reference (cameraPos2D /
       cameraPos3D / target2D / target3D), driven by the card's own 2D/3D
       toggle instead of the reference's own buttons;
     - the reference's THREE `RacetrackCurve` + `ArcCurve` classes and
       `createArcTubeMesh` (TubeGeometry + hemisphere end caps,
       MeshStandardMaterial roughness .35/metalness .1) are ported as-is;
     - the reference's own DOM label projection (`updateLabelsPosition`) is
       kept verbatim — country/axis/badge/slide labels are plain projected
       divs, not CSS2DObjects, exactly like the source file;
     - hover dimming (matched segment 1.0 / rest 0.22) and the tooltip
       (title + coloured dot + label + value) are ported as-is;
     - the reference's own header title/subtitle and preset `<select>` are
       REMOVED here — the card supplies its own heading and a matching
       "Version" dropdown for the same three presets, so nothing is
       duplicated;
     - the reference's own footer legend is REMOVED — `radialLegendFor()`
       feeds the card's single outer legend row instead, so labels are
       never shown twice;
     - scroll-zoom starts OFF (matching every other Three.js chart's zoom
       lock convention) and is exposed via the same `setZoom` handle. ===== */

interface Props {
  presetKey: RadialPresetKey;
  dim: '2d' | '3d';
  theme: ExportTheme;
  dark?: boolean;
  hoverIndex?: number | null;
  onHover?: (idx: number | null, text: string | null) => void;
}

interface SegmentData { title: string; label: string; value: string | number; color: string; typeKey: string; legendIndex: number | null }


/** Reference `RacetrackCurve` — verbatim. */
class RacetrackCurve extends THREE.Curve<THREE.Vector3> {
  radius: number; lBottom: number; lTop: number; centerX: number; centerY: number; totLen: number;
  constructor(radius: number, lBottom: number, lTop: number, centerX = -1.2, centerY = 0) {
    super();
    this.radius = radius; this.lBottom = lBottom; this.lTop = lTop; this.centerX = centerX; this.centerY = centerY;
    this.totLen = lBottom + Math.PI * radius + lTop;
  }
  getPoint(t: number, target = new THREE.Vector3()): THREE.Vector3 {
    const s = t * this.totLen;
    let x: number, y: number;
    if (s <= this.lBottom) { x = this.lBottom - s; y = -this.radius; }
    else if (s <= this.lBottom + Math.PI * this.radius) {
      const sArc = s - this.lBottom;
      const angle = -Math.PI / 2 - sArc / this.radius;
      x = this.radius * Math.cos(angle); y = this.radius * Math.sin(angle);
    } else { const sTop = s - (this.lBottom + Math.PI * this.radius); x = sTop; y = this.radius; }
    return target.set(x + this.centerX, y + this.centerY, 0);
  }
}
/** Reference `ArcCurve` (defined inline inside `createArcTubeMesh` in the
 * source file) — verbatim. */
class ArcCurve extends THREE.Curve<THREE.Vector3> {
  r: number; sAngle: number; eAngle: number; cx: number;
  constructor(r: number, sAngle: number, eAngle: number, cx: number) {
    super(); this.r = r; this.sAngle = sAngle; this.eAngle = eAngle; this.cx = cx;
  }
  getPoint(t: number, target = new THREE.Vector3()): THREE.Vector3 {
    const angle = this.sAngle + t * (this.eAngle - this.sAngle);
    return target.set(this.cx + this.r * Math.cos(angle), this.r * Math.sin(angle), 0);
  }
}

function escXml(s: string): string {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

const ThreeReferenceRadialBar = forwardRef<ThreeChartHandle, Props>(function ThreeReferenceRadialBar(
  { presetKey, dim, theme, dark, hoverIndex, onHover }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const labelsRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; title: string; label: string; value: string | number; color: string } | null>(null);
  const [ready, setReady] = useState(false);
  const [zoomOn, setZoomOn] = useState(false);

  const api = useRef<{
    renderer: THREE.WebGLRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    setMode: (m: '2D' | '3D') => void;
    setZoom: (on: boolean) => void;
    highlightLegend: (idx: number | null) => void;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    const labelsHost = labelsRef.current;
    if (!container || !labelsHost) return;
    setReady(false);
    labelsHost.innerHTML = '';

    const preset = RADIAL_PRESETS[presetKey];
    const scene = new THREE.Scene();
    scene.background = null; // transparent — sits directly in the card tile
    scene.fog = null;

    const W0 = container.clientWidth || 640, H0 = container.clientHeight || 460;
    const camera = new THREE.PerspectiveCamera(42, W0 / H0, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(W0, H0);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = false;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container.insertBefore(renderer.domElement, container.firstChild);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.enableZoom = false; // zoom lock, same convention as every other Three.js chart
    controls.minDistance = 6;
    controls.maxDistance = 28;

    let onScreen = true;
    let needsFrame = true;
    let dampingTail = 0;
    function wake(tail = 0) { needsFrame = true; if (tail > dampingTail) dampingTail = tail; }

    // LIGHTING: bumped again — all three presets (Olympic / Slide template
    // / Updating points) read noticeably better-lit now, tubes carry
    // visible gloss/depth without blowing out highlights.
    scene.add(new THREE.AmbientLight(0xffffff, dark ? 1.05 : 1.3));
    const dirLight1 = new THREE.DirectionalLight(0xffffff, dark ? 0.7 : 0.9);
    dirLight1.position.set(10, 15, 20);
    dirLight1.castShadow = true;
    scene.add(dirLight1);
    const dirLight2 = new THREE.DirectionalLight(0xffffff, 0.62);
    dirLight2.position.set(-10, -10, -10);
    scene.add(dirLight2);

    const interactive: THREE.Mesh[] = [];
    const labelRefs: { el: HTMLElement; text: string; color?: string }[] = [];
    const labelEls: { el: HTMLDivElement; ds: Record<string, string> }[] = [];
    const chartGroup = new THREE.Group();
    scene.add(chartGroup);

    function createDOMElement(className: string, text: string | number, dataset: Record<string, string | number>, color?: string) {
      const el = document.createElement('div');
      el.className = className;
      el.textContent = String(text);
      el.style.fontFamily = theme.fontBody;
      if (color) el.style.color = color;
      const ds: Record<string, string> = {};
      Object.entries(dataset).forEach(([k, v]) => { ds[k] = String(v); });
      labelsHost!.appendChild(el);
      labelEls.push({ el, ds });
      labelRefs.push({ el, text: String(text), color });
    }

    function createArcTubeMesh(
      radius: number, startAngle: number, endAngle: number, tubeRadius: number, colorHex: string,
      segmentData: SegmentData, centerX = 0,
    ): THREE.Group {
      const group = new THREE.Group();
      const curve = new ArcCurve(radius, startAngle, endAngle, centerX);
      const tubularSegments = Math.max(12, Math.floor(Math.abs(endAngle - startAngle) * 32));
      const tubeGeo = new THREE.TubeGeometry(curve, tubularSegments, tubeRadius, 24, false);
      const material = new THREE.MeshStandardMaterial({ color: new THREE.Color(colorHex), roughness: 0.35, metalness: 0.1, transparent: true, opacity: 1.0 });
      const mainTube = new THREE.Mesh(tubeGeo, material);
      mainTube.castShadow = true; mainTube.receiveShadow = true;
      group.add(mainTube);
      const capGeo = new THREE.SphereGeometry(tubeRadius, 16, 16);
      const startCap = new THREE.Mesh(capGeo, material); startCap.position.copy(curve.getPoint(0)); startCap.castShadow = true; group.add(startCap);
      const endCap = new THREE.Mesh(capGeo, material); endCap.position.copy(curve.getPoint(1)); endCap.castShadow = true; group.add(endCap);
      group.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          (child as THREE.Mesh).userData = { ...segmentData, parentGroup: group, baseColor: colorHex, isTube: child === mainTube, curve, tubeRadius };
          interactive.push(child as THREE.Mesh);
        }
      });
      return group;
    }

    /* ---- preset builders — verbatim geometry from the reference ---- */
    if (presetKey === 'olympic') {
      const innerRadius = 1.7, radiusStep = 0.8, tubeRadius = 0.28;
      const startAngleOffset = Math.PI / 2, maxSweepAngle = Math.PI * 1.85;
      const p = RADIAL_PRESETS.olympic;
      p.data.forEach((countryData, index) => {
        const currentRadius = innerRadius + (p.data.length - 1 - index) * radiusStep;
        let currentAngle = startAngleOffset;
        (['gold', 'silver', 'bronze'] as const).forEach((type, ti) => {
          const count = countryData[type];
          const sweepAngle = -(count / p.maxVal) * maxSweepAngle;
          const nextAngle = currentAngle + sweepAngle;
          const seg: SegmentData = { title: countryData.country, label: `${type[0].toUpperCase()}${type.slice(1)} medals:`, value: count, color: p.colors[type], typeKey: type, legendIndex: ti };
          chartGroup.add(createArcTubeMesh(currentRadius, currentAngle, nextAngle, tubeRadius, p.colors[type], seg));
          currentAngle = nextAngle;
        });
        createDOMElement('rrb-country-label', countryData.country, { radius: currentRadius, type: 'country' });
      });
      const outerRadius = innerRadius + (p.data.length - 1) * radiusStep + 0.55;
      [0, 25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 325, 350, 375, 400].forEach((val) => {
        const angle = startAngleOffset - (val / p.maxVal) * maxSweepAngle;
        createDOMElement('rrb-axis-label', val, { angle, radius: outerRadius, type: 'axis' });
      });
    } else if (presetKey === 'slide_template') {
      const tubeRadius = 0.20, maxTopLen = 4.5, lBottom = 1.6, centerX = -1.2;
      RADIAL_PRESETS.slide_template.data.forEach((item, index) => {
        const lTop = item.percent * maxTopLen;
        const curve = new RacetrackCurve(item.radius, lBottom, lTop, centerX, 0);
        const tubeGeo = new THREE.TubeGeometry(curve, 96, tubeRadius, 24, false);
        const material = new THREE.MeshStandardMaterial({ color: new THREE.Color(item.color), roughness: 0.35, metalness: 0.1, transparent: true, opacity: 1.0 });
        const group = new THREE.Group();
        const mainTube = new THREE.Mesh(tubeGeo, material); mainTube.castShadow = true; mainTube.receiveShadow = true; group.add(mainTube);
        const capGeo = new THREE.SphereGeometry(tubeRadius, 16, 16);
        const startCap = new THREE.Mesh(capGeo, material); startCap.position.copy(curve.getPoint(0)); startCap.castShadow = true; group.add(startCap);
        const endCap = new THREE.Mesh(capGeo, material); endCap.position.copy(curve.getPoint(1)); endCap.castShadow = true; group.add(endCap);
        const seg: SegmentData = { title: `Track ${index + 1}`, label: 'Completion Rate:', value: item.value, color: item.color, typeKey: `item_${index}`, legendIndex: index };
        group.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) { (child as THREE.Mesh).userData = { ...seg, parentGroup: group, baseColor: item.color, isTube: child === mainTube, curve, tubeRadius }; interactive.push(child as THREE.Mesh); }
        });
        chartGroup.add(group);
        const startPt = curve.getPoint(0);
        createDOMElement('rrb-slide-start-label', item.label, { type: 'slide_start', x: startPt.x, y: startPt.y }, item.color);
        const endPt = curve.getPoint(1);
        createDOMElement('rrb-slide-end-badge', item.value, { type: 'slide_end', x: endPt.x, y: endPt.y });
      });
    } else {
      const innerRadius = 0.6, radiusStep = 0.42, tubeRadius = 0.18, startAngle = Math.PI / 2, maxVal = 8.0, maxSweep = Math.PI * 1.85;
      const p = RADIAL_PRESETS.updating_points;
      p.data.forEach((item, index) => {
        const r = innerRadius + (p.data.length - 1 - index) * radiusStep;
        const sweep1 = -(item.val1 / maxVal) * maxSweep;
        const endA1 = startAngle + sweep1;
        const colorHex = p.colors[Math.min(p.colors.length - 1, Math.floor((item.val1 / maxVal) * p.colors.length))];
        const seg1: SegmentData = { title: `Point ${index}`, label: 'Primary Value:', value: item.val1, color: colorHex, typeKey: 'grad', legendIndex: null };
        chartGroup.add(createArcTubeMesh(r, startAngle, endA1, tubeRadius, colorHex, seg1));
        if (item.val2 > 0) {
          const sweep2 = -(item.val2 / maxVal) * maxSweep;
          const endA2 = endA1 + sweep2;
          const seg2: SegmentData = { title: `Point ${index}`, label: 'Secondary Value:', value: item.val2, color: p.colors[0], typeKey: 'grad', legendIndex: null };
          chartGroup.add(createArcTubeMesh(r, endA1, endA2, tubeRadius, p.colors[0], seg2));
        }
        createDOMElement('rrb-axis-label', item.ring, { angle: startAngle, radius: r, type: 'ring_index' });
      });
      const outerR = innerRadius + (p.data.length - 1) * radiusStep + 0.45;
      for (let t = 0; t <= 9; t++) {
        const angle = startAngle - (t / 10) * maxSweep;
        createDOMElement('rrb-axis-label', t, { angle, radius: outerR, type: 'axis' });
      }
    }

    // ---- entrance: quick radial scale-in stagger (Back.Out), same
    // language as the app's other 3D charts — every bar/track pops in
    // from nothing on mount AND on every "Version" switch, so loading a
    // bar type always has a visible build animation instead of the
    // geometry simply materialising at full size. ----
    let disposed = false;
    // Entrance driven by the SAME rAF as the renderer.
    //
    // STUCK-ON-SLOW-SCROLL FIX: the entrance clock is anchored to the FIRST
    // ON-SCREEN FRAME, not to mount. Previously `enterT0`/`enteringUntil` were
    // captured at mount while the growth (`tickEntrance`) only ran inside the
    // onScreen-gated render loop. If a tile mounted below the fold and the user
    // scrolled to it SLOWLY — taking longer than the ~1s entrance window — the
    // wall clock was already past `enteringUntil` by the time the tile became
    // visible, so `tickEntrance` never ran once and every bar group stayed
    // frozen at scale 0.01: tiny, off-centre bars against a full-size axis and
    // full-size labels (exactly the reported frozen frame). Anchoring the clock
    // to first visibility + a terminal snap to full scale makes the entrance
    // always play when the chart appears and makes "stuck at 0.01" impossible.
    const enterDur = 460, enterStagger = 26;
    const nKids = chartGroup.children.length;
    chartGroup.children.forEach((group) => group.scale.setScalar(0.01));
    let enterT0 = 0;
    let enteringUntil = 0;
    let entranceStarted = false;
    let entranceDone = false;
    const easeOutBack = (tt: number) => { const c1 = 1.70158; return 1 + (c1 + 1) * Math.pow(tt - 1, 3) + c1 * Math.pow(tt - 1, 2); };
    const tickEntrance = (now: number) => {
      chartGroup.children.forEach((group, gi) => {
        const t = Math.min(1, Math.max(0, (now - (enterT0 + gi * enterStagger)) / enterDur));
        group.scale.setScalar(Math.max(0.01, t <= 0 ? 0.01 : easeOutBack(t)));
      });
    };
    const finishEntrance = () => {
      chartGroup.children.forEach((group) => group.scale.setScalar(1));
      entranceDone = true;
    };

    /* ---- hover: raycast + dim/tooltip (reference verbatim) ---- */
    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    let hoveredData: SegmentData & { parentGroup: THREE.Group } | null = null;
    function highlightSegment(active: SegmentData & { parentGroup: THREE.Group }) {
      container!.style.cursor = 'pointer';
      interactive.forEach((mesh) => {
        const match = (mesh.userData as { parentGroup: THREE.Group }).parentGroup === active.parentGroup;
        (mesh.material as THREE.MeshStandardMaterial).opacity = match ? 1.0 : 0.22;
      });
    }
    function resetHighlight() {
      container!.style.cursor = 'default';
      interactive.forEach((mesh) => { (mesh.material as THREE.MeshStandardMaterial).opacity = 1.0; });
    }
    function onPointerMove(e: PointerEvent) {
      wake(1);
      const rect = container!.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(interactive, false);
      if (hits.length) {
        const data = hits[0].object.userData as SegmentData & { parentGroup: THREE.Group };
        if (hoveredData !== data) { hoveredData = data; highlightSegment(data); onHover?.(data.legendIndex, data.title); }
        setTip({ x: e.clientX - rect.left, y: e.clientY - rect.top - 15, title: data.title, label: data.label, value: data.value, color: data.color });
      } else if (hoveredData) {
        hoveredData = null; resetHighlight(); setTip(null); onHover?.(null, null);
      }
    }
    function onPointerLeave() { hoveredData = null; resetHighlight(); setTip(null); onHover?.(null, null); wake(2); }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    /* ---- camera modes: reference's own positions, Cubic.Out 1100ms ---- */
    // FRAMING FIX: the reference's verbatim rig cropped part of the chart
    // (outer axis labels / arrow markers near the rim) out of frame on
    // some presets. Zoomed out ~15% (keeps the SAME viewing angle — every
    // component scaled together) for margin on every edge, and nudged the
    // vertical aim point up a touch so the whole chart settles higher in
    // the tile instead of tight against — or past — the bottom edge.
    const cameraPos2D = new THREE.Vector3(0, -0.25, 17.3);
    const cameraPos3D = new THREE.Vector3(4.0, -6.9, 14.4);
    const target3D = new THREE.Vector3(-0.2, 0.75, 0);
    const target2D = new THREE.Vector3(0, -0.25, 0);
    let mode: '2D' | '3D' = dim === '3d' ? '3D' : '2D';
    let transitioning = false, tStart = 0;
    const TWEEN_MS = 980;
    const poseOf = (mm: '2D' | '3D'): CamPose => ({
      pos: (mm === '3D' ? cameraPos3D : cameraPos2D).clone(),
      target: (mm === '3D' ? target3D : target2D).clone(),
      up: new THREE.Vector3(0, 1, 0),
      fov: camera.fov,
    });
    let fromPose: CamPose = capturePose(camera, controls);
    let toPose: CamPose = poseOf(mode);
    controls.target.copy(mode === '3D' ? target3D : target2D);
    camera.position.copy(mode === '3D' ? cameraPos3D : cameraPos2D);
    camera.up.set(0, 1, 0);
    controls.enableRotate = mode === '3D';

    function setMode(mm: '2D' | '3D') {
      if (mode === mm) return;
      fromPose = beginFramedTween(controls, camera);
      fromPose.fov = camera.fov;
      mode = mm;
      toPose = poseOf(mm);
      toPose.fov = camera.fov;
      transitioning = true; tStart = performance.now();
      controls.enableRotate = mm === '3D';
      renderer.shadowMap.needsUpdate = true;
      wake(2);
    }

    function adjustFov() {
      const aspect = camera.aspect;
      camera.fov = aspect < 1 ? 42 / aspect : 42;
      camera.updateProjectionMatrix();
    }
    function resize() {
      const rw = container!.clientWidth || 640, rh = container!.clientHeight || 460;
      camera.aspect = rw / rh; adjustFov();
      renderer.setSize(rw, rh);
      renderer.shadowMap.needsUpdate = true;
      wake(2);
    }
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();
    const io = new IntersectionObserver((es) => {
      onScreen = es.some((e) => e.isIntersecting);
      if (onScreen) {
        // Re-anchor the entrance to the moment the tile actually becomes
        // visible, so a slow scroll into view plays the build animation from
        // the start instead of skipping it (see the entrance block above).
        if (!entranceDone) entranceStarted = false;
        wake(2);
      }
    }, { threshold: 0 });
    io.observe(container);
    const onCtxLost = (e: Event) => e.preventDefault();
    const onCtxRestored = () => { resize(); wake(2); };
    renderer.domElement.addEventListener('webglcontextlost', onCtxLost, false);
    renderer.domElement.addEventListener('webglcontextrestored', onCtxRestored, false);
    controls.addEventListener('change', () => { wake(2); renderer.shadowMap.needsUpdate = true; });
    controls.addEventListener('end', () => wake(28));

    /* ---- reference `updateLabelsPosition` — verbatim projection math ---- */
    const tempV = new THREE.Vector3();
    function updateLabelsPosition() {
      const lw = container!.clientWidth || 640, lh = container!.clientHeight || 460;
      labelEls.forEach(({ el, ds }) => {
        const cx = ds.cx ? parseFloat(ds.cx) : 0;
        if (ds.type === 'country') { const r = parseFloat(ds.radius); tempV.set(-0.2 + cx, r, 0); }
        else if (ds.type === 'ring_index') { const r = parseFloat(ds.radius); tempV.set(-0.15 + cx, r, 0); }
        else if (ds.type === 'slide_start' || ds.type === 'slide_end') { tempV.set(parseFloat(ds.x), parseFloat(ds.y), 0); }
        else { const angle = parseFloat(ds.angle), r = parseFloat(ds.radius); tempV.set(cx + r * Math.cos(angle), r * Math.sin(angle), 0); }
        tempV.project(camera);
        const x = (tempV.x * 0.5 + 0.5) * lw;
        const y = (-(tempV.y * 0.5) + 0.5) * lh;
        el.style.left = `${x}px`; el.style.top = `${y}px`;
        el.style.opacity = (tempV.z > 1 || x < 0 || x > lw || y < 0 || y > lh) ? '0' : '1';
      });
    }

    let raf = 0;
    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (!onScreen || document.hidden) return;
      const now = performance.now();
      // Start (or restart) the entrance clock on the first visible frame.
      if (!entranceStarted) {
        entranceStarted = true;
        enterT0 = now;
        enteringUntil = now + enterDur + nKids * enterStagger + 80;
      }
      if (!entranceDone) {
        if (now < enteringUntil) tickEntrance(now);
        else finishEntrance();
      }
      if (!needsFrame && !transitioning && dampingTail <= 0 && entranceDone) return;
      if (transitioning) {
        const t = Math.min(1, (performance.now() - tStart) / TWEEN_MS);
        const e = easeInOutCubic(t);
        chartGroup.updateWorldMatrix(true, true);
        const liveBox = new THREE.Box3().setFromObject(chartGroup);
        applyFramedLerp(camera, controls, fromPose, toPose, e, { box: liveBox, pad: 1.16 });
        renderer.shadowMap.needsUpdate = true;
        if (t >= 1) {
          transitioning = false;
          endFramedTween(controls, camera, toPose);
          controls.enableRotate = mode === '3D';
        }
      } else {
        controls.update();
      }
      updateLabelsPosition();
      renderer.render(scene, camera);
      needsFrame = transitioning || dampingTail > 0 || !entranceDone;
      if (dampingTail > 0) dampingTail -= 1;
    };
    animate();
    requestAnimationFrame(() => requestAnimationFrame(() => setReady(true)));

    const dispose = () => {
      disposed = true;
      cancelAnimationFrame(raf);
      ro.disconnect(); io.disconnect();
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      renderer.domElement.removeEventListener('webglcontextlost', onCtxLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onCtxRestored);
      controls.dispose();
      interactive.forEach((m) => { m.geometry.dispose(); (m.material as THREE.Material).dispose(); });
      renderer.dispose();
      // GPU FIX: force the WebGL context lost immediately on unmount
      // (rather than waiting for browser GC) so its VRAM is reclaimed
      // right away — this is what caused OTHER charts on the same page to
      // occasionally blank out after this tile had been switched away
      // from: too many still-resident (if not yet GC'd) WebGL contexts
      // can make the browser evict/reset an unrelated canvas's context.
      try { renderer.getContext().getExtension('WEBGL_lose_context')?.loseContext(); } catch { /* noop */ }
      if (renderer.domElement.parentElement === container) container!.removeChild(renderer.domElement);
      labelsHost.innerHTML = '';
    };

    api.current = {
      renderer, scene, camera, controls, labelRefs, setMode,
      setZoom: (on: boolean) => { controls.enableZoom = on; },
      highlightLegend: (idx: number | null) => {
        if (idx === null) { resetHighlight(); return; }
        container!.style.cursor = 'default';
        interactive.forEach((mesh) => {
          const li = (mesh.userData as SegmentData).legendIndex;
          (mesh.material as THREE.MeshStandardMaterial).opacity = li === idx ? 1.0 : 0.22;
        });
      },
      dispose,
    };
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [presetKey, dark, theme.fontBody]);

  useEffect(() => { api.current?.setMode(dim === '3d' ? '3D' : '2D'); }, [dim]);
  useEffect(() => { if (hoverIndex === undefined) return; api.current?.highlightLegend(hoverIndex); }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const expW = container.clientWidth, expH = container.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(expW, expH, false);
      a.renderer.render(a.scene, a.camera);
      const cv = await buildThreePNG({
        title, imageDataUrl: dataUrl, chartW: expW, chartH: expH,
        labels: captureLabelPositions(container, a.labelRefs),
        legend: radialLegendFor(presetKey),
        theme, footnote: `Radial Bar · ${RADIAL_PRESETS[presetKey].title} · ${dim === '3d' ? '3D' : '2D'} view`,
      });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      /* TRUE-vector export, camera-aware in both dims. Walks each tube's
         OWN curve (the exact ArcCurve/RacetrackCurve the mesh was built
         from) and reconstructs the SAME circular cross-section
         TubeGeometry itself uses for a planar curve (tangent ⟂ frame:
         in-plane normal + world Z), lit by the SAME ambient + two
         directional lights as the live scene, projected through the
         CURRENT camera. GEOMETRY-CORRECTNESS FIX: this used to draw ONE
         STANDALONE cross-section ring per curve sample. At samples where
         the curve's tangent points nearly straight at/away from the
         camera, that lone ring's own two basis directions land almost on
         top of each other on screen — a real projection degeneracy, not a
         bug in the maths — collapsing that ring into a thin sliver (the
         "bunch of loosely packed lines" artefact). A ring, by itself, is
         never solid: it's just an outline sample. The fix connects EVERY
         PAIR of adjacent rings into a strip of small QUADS (one tube
         "collar" per step) — even where one ring is momentarily
         degenerate, the strip still carries real area from its
         neighbour, so the tube surface stays continuously solid along
         its entire length, in whichever view (2D or 3D) is on screen —
         same colour, same radius, same lighting, same font. No raster,
         no per-triangle mesh dump. */
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const svgW = container.clientWidth || 640, svgH = container.clientHeight || 460;
      a.camera.updateMatrixWorld(true);
      const project = (v: THREE.Vector3) => {
        const p = v.clone().project(a.camera);
        return { x: (p.x * 0.5 + 0.5) * svgW, y: (-p.y * 0.5 + 0.5) * svgH, z: p.z };
      };
      // Matches the live scene's (bumped) lighting rig exactly, so exported
      // brightness never drifts from what's on screen.
      const AMBIENT = dark ? 1.05 : 1.3;
      const L1 = new THREE.Vector3(10, 15, 20).normalize();
      const L1I = dark ? 0.7 : 0.9;
      const L2 = new THREE.Vector3(-10, -10, -10).normalize();
      const L2I = 0.62;
      type Face = { z: number; svg: string };
      const faces: Face[] = [];
      const seen = new Set<THREE.Group>();
      const RING_N = 10;
      const ringCos: number[] = [], ringSin: number[] = [];
      for (let k = 0; k < RING_N; k++) { const phi = (Math.PI * 2 * k) / RING_N; ringCos.push(Math.cos(phi)); ringSin.push(Math.sin(phi)); }
      const brightnessOf = (n: THREE.Vector3) => AMBIENT + Math.max(0, n.dot(L1)) * L1I + Math.max(0, n.dot(L2)) * L2I;
      const shadeFill = (base: THREE.Color, bright: number) =>
        `rgb(${Math.min(255, Math.round(base.r * 255 * bright))},${Math.min(255, Math.round(base.g * 255 * bright))},${Math.min(255, Math.round(base.b * 255 * bright))})`;
      a.scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        const ud = mesh.userData as Partial<SegmentData> & { parentGroup?: THREE.Group; curve?: THREE.Curve<THREE.Vector3>; tubeRadius?: number; isTube?: boolean };
        if (!ud.isTube || !ud.curve || !ud.parentGroup || seen.has(ud.parentGroup)) return;
        seen.add(ud.parentGroup);
        const curve = ud.curve;
        const tubeR = ud.tubeRadius || 0.18;
        const col = (ud.color as string) || '#94a3b8';
        const base = new THREE.Color(col);
        const arcLen = curve.getLength();
        const samples = Math.max(10, Math.min(28, Math.round(arcLen * 3.4)));
        const EPS = 0.5 / samples;
        type Ring = { world: THREE.Vector3; normal: THREE.Vector3 }[];
        let prevRing: Ring | null = null;
        for (let i = 0; i <= samples; i++) {
          const t = i / samples;
          const pc = mesh.localToWorld(curve.getPoint(t));
          const p0 = mesh.localToWorld(curve.getPoint(Math.max(0, t - EPS)));
          const p1 = mesh.localToWorld(curve.getPoint(Math.min(1, t + EPS)));
          const tangent = p1.clone().sub(p0);
          const ring: Ring = [];
          if (tangent.lengthSq() >= 1e-9) {
            tangent.normalize();
            // Cross-section frame for a curve planar in world Z=0: the
            // in-plane perpendicular to the tangent, plus world Z —
            // exactly how THREE.TubeGeometry frames a flat curve like these.
            const n1 = new THREE.Vector3(-tangent.y, tangent.x, 0);
            if (n1.lengthSq() < 1e-6) n1.set(1, 0, 0); else n1.normalize();
            const n2 = new THREE.Vector3(0, 0, 1);
            for (let k = 0; k < RING_N; k++) {
              const nrm = n1.clone().multiplyScalar(ringCos[k]).add(n2.clone().multiplyScalar(ringSin[k])).normalize();
              ring.push({ world: pc.clone().addScaledVector(nrm, tubeR), normal: nrm });
            }
          }
          if (ring.length && prevRing) {
            for (let k = 0; k < RING_N; k++) {
              const k2 = (k + 1) % RING_N;
              const quadPts = [prevRing[k], prevRing[k2], ring[k2], ring[k]];
              const proj = quadPts.map((qp) => project(qp.world));
              if (proj.every((pp) => pp.z > 1 || pp.z < -1)) continue;
              const normal = prevRing[k].normal.clone().add(prevRing[k2].normal).add(ring[k2].normal).add(ring[k].normal).normalize();
              const fill = shadeFill(base, brightnessOf(normal));
              const zAvg = proj.reduce((s, pp) => s + pp.z, 0) / proj.length;
              const pts = proj.map((pp) => `${pp.x.toFixed(1)},${pp.y.toFixed(1)}`).join(' ');
              faces.push({ z: zAvg, svg: `<polygon points="${pts}" fill="${fill}"/>` });
            }
          }
          prevRing = ring.length ? ring : prevRing;
        }
        // Rounded end caps — small filled discs matching the sphere caps'
        // colour/shading at each tube end.
        [0, 1].forEach((tEnd) => {
          const pc = mesh.localToWorld(curve.getPoint(tEnd));
          const pp = project(pc);
          if (pp.z > 1 || pp.z < -1) return;
          const rimPt = project(pc.clone().add(new THREE.Vector3(tubeR, 0, 0)));
          const rad = Math.max(1.2, Math.hypot(rimPt.x - pp.x, rimPt.y - pp.y));
          const fill = shadeFill(base, AMBIENT + L1I * 0.75);
          faces.push({ z: pp.z + 0.0005, svg: `<circle cx="${pp.x.toFixed(1)}" cy="${pp.y.toFixed(1)}" r="${rad.toFixed(1)}" fill="${fill}"/>` });
        });
      });
      faces.sort((p, q) => q.z - p.z);
      const labels = captureLabelPositions(container, a.labelRefs);
      const legend = radialLegendFor(presetKey);
      const scratch = document.createElement('canvas').getContext('2d')!;
      scratch.font = `600 10.5px ${theme.fontBody}`;
      const headH = title ? 34 : 8, legH = 26;
      const TH = headH + svgH + legH;
      let leg = ''; let lxx = 12; const lyy = TH - 9;
      legend.forEach((it) => {
        leg += `<rect x="${lxx}" y="${lyy - 8}" width="9" height="9" rx="2" fill="${it.color}"/>`;
        leg += `<text x="${lxx + 13}" y="${lyy}" font-size="10.5" font-weight="600" fill="#39443d">${escXml(it.label)}</text>`;
        lxx += 13 + scratch.measureText(it.label).width + 18;
      });
      let labelSvg = '';
      labels.forEach((l) => {
        const fs = l.fontSize || 11;
        scratch.font = `${l.bold ? 700 : 600} ${fs}px ${theme.fontBody}`;
        labelSvg += `<text x="${l.x.toFixed(1)}" y="${(headH + l.y + fs * 0.32).toFixed(1)}" text-anchor="middle" font-size="${fs}" font-weight="${l.bold ? 700 : 600}" fill="${l.color || '#334155'}">${escXml(l.text)}</text>`;
      });
      return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${svgW}" height="${TH}" viewBox="0 0 ${svgW} ${TH}">
<defs><style>text { font-family: ${escXml(theme.fontBody)}, -apple-system, sans-serif; }</style></defs>
<rect width="${svgW}" height="${TH}" fill="#ffffff"/>
${title ? `<text x="12" y="22" font-family="${escXml(theme.fontDisplay)}" font-size="15" font-weight="700" fill="#1c2620">${escXml(title)}</text>` : ''}
<g id="rrb-scene" transform="translate(0 ${headH})">${faces.map((f) => f.svg).join('')}${labelSvg}</g>
<g id="rrb-legend">${leg}</g>
</svg>`;
    },
    setZoom: (on: boolean) => { setZoomOn(on); api.current?.setZoom(on); },
  }), [presetKey, dim, theme]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full overflow-hidden rounded-lg">
      <div ref={labelsRef} className="pointer-events-none absolute inset-0 overflow-hidden" />
      {!ready && (
        <div className="absolute inset-0 z-20 flex items-center justify-center gap-2.5 bg-(--t-surface) font-body text-[12.5px] font-semibold text-muted">
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent opacity-70" />
          Loading chart…
        </div>
      )}
      <button
        onClick={(e) => { e.stopPropagation(); const next = !zoomOn; setZoomOn(next); api.current?.setZoom(next); }}
        data-tip={zoomOn ? 'Scroll-zoom: on' : 'Scroll-zoom: off'}
        className={`absolute left-2 top-2 z-10 rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${zoomOn ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
        title={zoomOn ? 'Turn scroll-zoom off' : 'Turn scroll-zoom on'}
      >
        {zoomOn ? '🔍+ on' : '🔍+ off'}
      </button>
      {tip && (
        <div className="rrb-tip font-body" style={{ left: Math.min(Math.max(tip.x, 90), (containerRef.current?.clientWidth || 300) - 90), top: Math.max(8, tip.y) }}>
          <div className="rrb-tip-title">{tip.title}</div>
          <div className="rrb-tip-row"><span className="rrb-tip-dot" style={{ background: tip.color }} />{tip.label} <b>{tip.value}</b></div>
        </div>
      )}
    </div>
  );
});

export default ThreeReferenceRadialBar;
