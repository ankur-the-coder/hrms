import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import type { ThreeChartHandle } from './ThreeSankey3D';
import type { ExportTheme } from './exportUtils';
import { buildThreePNG, captureLabelPositions, withExportResolution } from './exportUtils';
import {
  applyFramedLerp, beginFramedTween, capturePose, easeInOutCubic, endFramedTween, type CamPose,
} from './framedTween';

/* ============================================================
   Three.js Org Chart — a hierarchical company tree that toggles between a
   flat 2D org-chart (head-on, all tiers on one plane) and a layered 3D
   view (each tier recedes into depth, oblique camera) with the SAME
   smooth, framed camera tween every other 3D chart in this app uses:
   the FROM pose is the live camera (so a user orbit/pan is respected) and
   the TO pose is a freshly-fitted preset, spherically interpolated so the
   tree never flies out of frame. The org depth is a group Z-scale that
   flattens 1 → ~0.03 for 2D and back for 3D, tweened together with the
   camera so nodes & connectors morph as one.

   Input: `links` as parent → child edges (source = manager, target =
   report, value = headcount under that report). Nodes, tiers and a tidy
   left-to-right layout are derived from the edges.
   ============================================================ */

export interface OrgLink { source: string; target: string; value?: number }

interface Props {
  links: OrgLink[];
  palette: string[];
  dim: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (idx: number | null, name: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

interface OrgNode {
  name: string; value: number; depth: number;
  x: number; y: number; z: number;
  parent: string | null;
  color: string;
  idx: number;
}

const TIER_GAP_Y = 7.2;      // vertical distance between tiers
const TIER_GAP_Z = 6.5;      // 3D depth pushed per tier
const NODE_GAP_X = 5.6;      // horizontal slot width per leaf
const FLATTEN_MIN = 0.03;    // group Z-scale in the 2D view

/** Derive nodes + tidy layout from parent→child edges. */
function buildOrg(links: OrgLink[], palette: string[]): { nodes: OrgNode[]; edges: [number, number][] } {
  const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
  const parentOf = new Map<string, string>();
  const childrenOf = new Map<string, string[]>();
  const valOf = new Map<string, number>();
  for (const l of links) {
    parentOf.set(l.target, l.source);
    if (!childrenOf.has(l.source)) childrenOf.set(l.source, []);
    childrenOf.get(l.source)!.push(l.target);
    if (l.value) valOf.set(l.target, (valOf.get(l.target) || 0) + l.value);
  }
  const roots = names.filter((n) => !parentOf.has(n));
  const root = roots[0] || names[0];

  // depth via BFS
  const depth = new Map<string, number>();
  const queue: string[] = [root];
  depth.set(root, 0);
  while (queue.length) {
    const cur = queue.shift()!;
    for (const c of childrenOf.get(cur) || []) {
      if (!depth.has(c)) { depth.set(c, (depth.get(cur) || 0) + 1); queue.push(c); }
    }
  }
  // any orphan (missing root link) → depth 1 under root
  for (const n of names) if (!depth.has(n)) depth.set(n, 1);

  // tidy layout: assign leaf x slots in-order, parents centre over children
  let leafCursor = 0;
  const xOf = new Map<string, number>();
  const assignX = (n: string): number => {
    const kids = childrenOf.get(n) || [];
    if (!kids.length) { const x = leafCursor * NODE_GAP_X; leafCursor += 1; xOf.set(n, x); return x; }
    const xs = kids.map(assignX);
    const x = (Math.min(...xs) + Math.max(...xs)) / 2;
    xOf.set(n, x); return x;
  };
  assignX(root);
  // orphans not reachable from root
  for (const n of names) if (!xOf.has(n)) { xOf.set(n, leafCursor * NODE_GAP_X); leafCursor += 1; }

  const maxX = Math.max(...names.map((n) => xOf.get(n)!), 0);
  const maxDepth = Math.max(...names.map((n) => depth.get(n)!), 0);
  const idxOf = new Map<string, number>();
  const nodes: OrgNode[] = names.map((name, i) => {
    idxOf.set(name, i);
    const d = depth.get(name)!;
    return {
      name,
      value: valOf.get(name) || (childrenOf.get(name) || []).reduce((s, c) => s + (valOf.get(c) || 0), 0) || 1,
      depth: d,
      x: xOf.get(name)! - maxX / 2,
      y: (maxDepth / 2 - d) * TIER_GAP_Y,
      z: (maxDepth / 2 - d) * TIER_GAP_Z, // base 3D depth per tier (flattened for 2D)
      parent: parentOf.get(name) || null,
      color: palette[d % palette.length],
      idx: i,
    };
  });
  const edges: [number, number][] = links
    .filter((l) => idxOf.has(l.source) && idxOf.has(l.target))
    .map((l) => [idxOf.get(l.source)!, idxOf.get(l.target)!]);
  return { nodes, edges };
}

const ThreeOrgChart = forwardRef<ThreeChartHandle, Props>(function ThreeOrgChart(
  { links, palette, dim, hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; name: string; sub: string; color: string } | null>(null);
  const [zoomOn, setZoomOn] = useState(false);
  const [ready, setReady] = useState(false);
  const linksRef = useRef(links);
  linksRef.current = links;

  const api = useRef<{
    renderer: THREE.WebGLRenderer; labelRenderer: CSS2DRenderer;
    scene: THREE.Scene; camera: THREE.PerspectiveCamera; controls: OrbitControls;
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    setMode: (m: '2D' | '3D') => void; setZoom: (on: boolean) => void;
    hoverNode: (i: number | null) => void; dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    setReady(false);

    const scene = new THREE.Scene();
    const W0 = container.clientWidth || 700, H0 = container.clientHeight || 460;
    const camera = new THREE.PerspectiveCamera(40, W0 / H0, 0.1, 2000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setClearColor(0x000000, 0);
    renderer.setSize(W0, H0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = false;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.setSize(W0, H0);
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.enableZoom = false;
    controls.maxPolarAngle = Math.PI / 2 + 0.15;

    /* lighting */
    scene.add(new THREE.AmbientLight(0xffffff, 1.15));
    const key = new THREE.DirectionalLight(0xfffaed, 2.3);
    key.position.set(-20, 40, 40); key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.camera.near = 1; key.shadow.camera.far = 200;
    const shD = 60;
    key.shadow.camera.left = -shD; key.shadow.camera.right = shD;
    key.shadow.camera.top = shD; key.shadow.camera.bottom = -shD;
    key.shadow.bias = -0.0004;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xbdd7ff, 1.1); fill.position.set(30, -10, -30); scene.add(fill);
    const rim = new THREE.DirectionalLight(0xffffff, 0.8); rim.position.set(0, 20, -40); scene.add(rim);

    /* build org data + geometry */
    const { nodes, edges } = buildOrg(linksRef.current, palette);
    const orgGroup = new THREE.Group();
    scene.add(orgGroup);

    let flattenAmt = dim === '3d' ? 0 : 1;
    let fromFlatten = flattenAmt;
    const applyFlatten = (t: number) => { orgGroup.scale.z = 1 - (1 - FLATTEN_MIN) * t; };

    const maxVal = Math.max(...nodes.map((n) => n.value), 1);
    const nodeMeshes: THREE.Mesh<THREE.BufferGeometry, THREE.MeshPhysicalMaterial>[] = [];
    const nodeLabels: CSS2DObject[] = [];
    const boxGeoCache = new Map<string, RoundedBoxGeometry>();

    nodes.forEach((n) => {
      // box size scales gently with headcount so hierarchy reads at a glance
      const s = 0.6 + 0.5 * Math.sqrt(n.value / maxVal);
      const w = 3.4 * s, h = 1.7 * s, d = 1.0;
      const key = `${w.toFixed(2)}x${h.toFixed(2)}`;
      let geo = boxGeoCache.get(key);
      if (!geo) { geo = new RoundedBoxGeometry(w, h, d, 4, 0.22); boxGeoCache.set(key, geo); }
      const mat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(n.color), roughness: 0.32, metalness: 0.1,
        clearcoat: 0.8, clearcoatRoughness: 0.25,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(n.x, n.y, n.z);
      mesh.castShadow = true; mesh.receiveShadow = true;
      mesh.userData = { idx: n.idx, name: n.name, value: n.value, depth: n.depth };
      orgGroup.add(mesh);
      nodeMeshes.push(mesh);

      const div = document.createElement('div');
      div.textContent = n.name;
      div.style.fontFamily = theme.fontBody;
      div.style.fontSize = '11px';
      div.style.fontWeight = '700';
      div.style.color = dark ? '#eaf1f8' : '#1c2620';
      div.style.textShadow = dark ? '0 1px 3px rgba(0,0,0,0.6)' : '0 1px 3px rgba(255,255,255,0.7)';
      div.style.whiteSpace = 'nowrap';
      div.style.pointerEvents = 'none';
      const lo = new CSS2DObject(div);
      lo.position.set(n.x, n.y, n.z + d / 2 + 0.05);
      orgGroup.add(lo);
      nodeLabels.push(lo);
    });

    /* connectors: elbow lines parent → child (children of the group so they
       flatten with the nodes) */
    const connMat = new THREE.LineBasicMaterial({ color: dark ? 0x64768a : 0x94a3b8, transparent: true, opacity: 0.85 });
    const connectors: THREE.Line[] = [];
    edges.forEach(([pi, ci]) => {
      const p = nodes[pi], c = nodes[ci];
      const midY = (p.y + c.y) / 2;
      const pts = [
        new THREE.Vector3(p.x, p.y - 0.85, p.z),
        new THREE.Vector3(p.x, midY, p.z),
        new THREE.Vector3(c.x, midY, c.z),
        new THREE.Vector3(c.x, c.y + 0.85, c.z),
      ];
      const g = new THREE.BufferGeometry().setFromPoints(pts);
      const line = new THREE.Line(g, connMat);
      orgGroup.add(line);
      connectors.push(line);
    });

    /* shadow-catching floor */
    const bounds = new THREE.Box3().setFromObject(orgGroup);
    const floorY = bounds.min.y - 2.2;
    const shadowPlane = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.ShadowMaterial({ opacity: 0.14 }));
    shadowPlane.rotation.x = -Math.PI / 2; shadowPlane.position.y = floorY; shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);

    /* ---- camera presets, fitted to the tree ---- */
    const center = bounds.getCenter(new THREE.Vector3());
    const size = bounds.getSize(new THREE.Vector3());
    let dist3D = 90, dist2D = 120;
    function fitDistance(fovDeg: number, aspect: number, dims: [number, number], pad = 1.16) {
      const fov = THREE.MathUtils.degToRad(fovDeg);
      const fitH = (dims[1] / 2) / Math.tan(fov / 2);
      const fitW = (dims[0] / 2) / (Math.tan(fov / 2) * aspect);
      return Math.max(fitH, fitW) * pad;
    }
    const FOV = 40;
    function refit() {
      const aspect = camera.aspect;
      dist3D = fitDistance(FOV, aspect, [size.x + 4, size.y + 4], 1.12);
      dist2D = fitDistance(FOV, aspect, [size.x + 4, size.y + 4], 1.18);
    }
    refit();
    const view3D = (): CamPose => ({
      pos: new THREE.Vector3(center.x - dist3D * 0.28, center.y + dist3D * 0.34, center.z + dist3D * 0.9),
      target: center.clone(), up: new THREE.Vector3(0, 1, 0), fov: FOV,
    });
    const view2D = (): CamPose => ({
      pos: new THREE.Vector3(center.x, center.y, center.z + dist2D),
      target: center.clone(), up: new THREE.Vector3(0, 1, 0), fov: FOV,
    });

    let mode: '2D' | '3D' = dim === '3d' ? '3D' : '2D';
    let transitioning = false, tStart = 0;
    const TWEEN_MS = 950;
    let fromPose: CamPose = capturePose(camera, controls);
    let toPose: CamPose = mode === '3D' ? view3D() : view2D();
    function applyInstant(m: '2D' | '3D') {
      const v = m === '3D' ? view3D() : view2D();
      flattenAmt = m === '2D' ? 1 : 0;
      applyFlatten(flattenAmt);
      camera.position.copy(v.pos); controls.target.copy(v.target);
      camera.up.copy(v.up); camera.fov = v.fov; camera.updateProjectionMatrix();
      controls.enableRotate = m === '3D';
      controls.update();
    }
    function setMode(m: '2D' | '3D') {
      if (mode === m) return;
      refit();
      fromPose = beginFramedTween(controls, camera);
      fromFlatten = flattenAmt;
      mode = m;
      toPose = m === '3D' ? view3D() : view2D();
      transitioning = true; tStart = performance.now();
      controls.enableRotate = m === '3D';
      renderer.shadowMap.needsUpdate = true;
      wake(2);
    }
    applyInstant(mode);

    /* ---- hover: raycast → dim others + tooltip ---- */
    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    let hovered: number | null = null;
    function setHighlight(i: number | null) {
      nodeMeshes.forEach((m) => { m.material.opacity = 1; m.material.transparent = false; });
      if (i !== null) {
        nodeMeshes.forEach((m, k) => {
          const on = k === i;
          m.material.transparent = !on;
          m.material.opacity = on ? 1 : 0.28;
          m.material.emissive.setHex(on ? 0x222222 : 0x000000);
        });
      } else {
        nodeMeshes.forEach((m) => m.material.emissive.setHex(0x000000));
      }
    }
    function onPointerMove(e: PointerEvent) {
      const rect = container!.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(nodeMeshes, false);
      if (hits.length) {
        const ud = hits[0].object.userData as { idx: number; name: string; value: number; depth: number };
        if (hovered !== ud.idx) { hovered = ud.idx; setHighlight(ud.idx); onHover?.(ud.idx, ud.name); }
        setTip({ x: e.clientX - rect.left, y: e.clientY - rect.top - 14, name: ud.name, sub: `${ud.value} reports · Tier ${ud.depth + 1}`, color: nodes[ud.idx].color });
        container!.style.cursor = 'pointer'; wake();
      } else if (hovered !== null) {
        hovered = null; setHighlight(null); setTip(null); onHover?.(null, null); container!.style.cursor = 'default'; wake();
      }
    }
    function onPointerLeave() { hovered = null; setHighlight(null); setTip(null); onHover?.(null, null); wake(); }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    /* ---- render-on-demand ---- */
    let raf = 0, onScreen = true, needsFrame = true, dampingTail = 0;
    function wake(tail = 0) { needsFrame = true; if (tail > dampingTail) dampingTail = tail; }
    const resize = () => {
      const W = container!.clientWidth || 700, H = container!.clientHeight || 460;
      camera.aspect = W / H; refit(); camera.updateProjectionMatrix();
      renderer.setSize(W, H); labelRenderer.setSize(W, H);
      if (!transitioning) applyInstant(mode);
      renderer.shadowMap.needsUpdate = true; wake(2);
    };
    const ro = new ResizeObserver(resize); ro.observe(container); resize();
    const io = new IntersectionObserver((es) => { onScreen = es.some((e) => e.isIntersecting); if (onScreen) { resize(); } }, { threshold: 0 });
    io.observe(container);
    const onVis = () => { if (!document.hidden) resize(); };
    document.addEventListener('visibilitychange', onVis);
    const onFs = () => { resize(); requestAnimationFrame(resize); };
    document.addEventListener('fullscreenchange', onFs);
    const onCtxLost = (e: Event) => e.preventDefault();
    const onCtxRestored = () => resize();
    renderer.domElement.addEventListener('webglcontextlost', onCtxLost, false);
    renderer.domElement.addEventListener('webglcontextrestored', onCtxRestored, false);
    controls.addEventListener('change', () => { wake(2); renderer.shadowMap.needsUpdate = true; });
    controls.addEventListener('end', () => wake(28));

    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (!onScreen || document.hidden) return;
      if (!needsFrame && !transitioning && dampingTail <= 0) return;
      if (transitioning) {
        const t = Math.min(1, (performance.now() - tStart) / TWEEN_MS);
        const e = easeInOutCubic(t);
        flattenAmt = THREE.MathUtils.lerp(fromFlatten, mode === '2D' ? 1 : 0, e);
        applyFlatten(flattenAmt);
        applyFramedLerp(camera, controls, fromPose, toPose, e);
        renderer.shadowMap.needsUpdate = true;
        if (t >= 1) {
          transitioning = false;
          flattenAmt = mode === '2D' ? 1 : 0; applyFlatten(flattenAmt);
          endFramedTween(controls, camera, toPose);
          controls.enableRotate = mode === '3D';
        }
      } else {
        controls.update();
      }
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
      needsFrame = transitioning || dampingTail > 0;
      if (dampingTail > 0) dampingTail -= 1;
    };
    animate();
    requestAnimationFrame(() => requestAnimationFrame(() => setReady(true)));

    const dispose = () => {
      cancelAnimationFrame(raf); ro.disconnect(); io.disconnect();
      document.removeEventListener('visibilitychange', onVis);
      document.removeEventListener('fullscreenchange', onFs);
      renderer.domElement.removeEventListener('webglcontextlost', onCtxLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onCtxRestored);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      nodeMeshes.forEach((m) => m.material.dispose());
      boxGeoCache.forEach((g) => g.dispose());
      connectors.forEach((l) => l.geometry.dispose());
      connMat.dispose();
      controls.dispose(); renderer.dispose();
      try { renderer.getContext().getExtension('WEBGL_lose_context')?.loseContext(); } catch { /* noop */ }
      if (renderer.domElement.parentElement === container) container.removeChild(renderer.domElement);
      if (labelRenderer.domElement.parentElement === container) container.removeChild(labelRenderer.domElement);
    };

    api.current = {
      renderer, labelRenderer, scene, camera, controls,
      labelRefs: nodeLabels.map((o) => ({ el: o.element as HTMLElement, text: (o.element as HTMLElement).textContent || '' })),
      setMode, setZoom: (on: boolean) => { controls.enableZoom = on; },
      hoverNode: (i: number | null) => { hovered = i; setHighlight(i); wake(); },
      dispose,
    };
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [links, dark, theme.fontBody]);

  useEffect(() => { api.current?.setMode(dim === '3d' ? '3D' : '2D'); }, [dim]);
  useEffect(() => { api.current?.hoverNode(hoverIndex ?? null); }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current, container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container.clientWidth, H = container.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(W, H, false);
      a.renderer.render(a.scene, a.camera); a.labelRenderer.render(a.scene, a.camera);
      const cv = await buildThreePNG({
        title, imageDataUrl: dataUrl, chartW: W, chartH: H,
        labels: captureLabelPositions(container, a.labelRefs), legend: [], theme,
        footnote: `Org chart · ${dim === '3d' ? 'Layered 3D' : 'Flat 2D'} view`,
      });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      const a = api.current, container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container.clientWidth, H = container.clientHeight;
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); });
      const dataUrl = a.renderer.domElement.toDataURL('image/png');
      a.renderer.setSize(W, H, false); a.renderer.render(a.scene, a.camera);
      return `<?xml version="1.0" encoding="utf-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${W}" height="${H + (title ? 36 : 0)}" viewBox="0 0 ${W} ${H + (title ? 36 : 0)}">
<rect width="100%" height="100%" fill="#ffffff"/>
${title ? `<text x="12" y="23" font-family="${theme.fontDisplay}, sans-serif" font-weight="700" font-size="15" fill="#1c2620">${title.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</text>` : ''}
<image x="0" y="${title ? 36 : 0}" width="${W}" height="${H}" xlink:href="${dataUrl}"/>
</svg>`;
    },
    setZoom: (on: boolean) => { setZoomOn(on); api.current?.setZoom(on); },
  }), [dim, theme]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full overflow-hidden">
      {!ready && (
        <div className="absolute inset-0 z-20 flex items-center justify-center gap-2.5 bg-(--t-surface) font-body text-[12.5px] font-semibold text-muted">
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent opacity-70" />
          Loading chart…
        </div>
      )}
      <button
        onClick={(e) => { e.stopPropagation(); const next = !zoomOn; setZoomOn(next); api.current?.setZoom(next); }}
        data-tip={zoomOn ? 'Scroll-zoom: on' : 'Scroll-zoom: off'}
        className={`absolute left-2 top-2 z-10 rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${zoomOn ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
        title={zoomOn ? 'Turn scroll-zoom off' : 'Turn scroll-zoom on'}
      >
        {zoomOn ? '🔍+ on' : '🔍+ off'}
      </button>
      {tip && (
        <div className="sg-tip font-body"
          style={{ left: Math.min(Math.max(tip.x, 90), (containerRef.current?.clientWidth || 300) - 90), top: Math.max(tip.y, 50) }}>
          <div className="tt-name"><span>{tip.name}</span><span style={{ fontSize: 10, color: tip.color, fontWeight: 700 }}>●</span></div>
          <div className="tt-role">{tip.sub}</div>
        </div>
      )}
    </div>
  );
});

export default ThreeOrgChart;
