import * as THREE from 'three';
import type { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { freezeOrbit, seatOrbit } from './orbitSeat';

export const easeInOutCubic = (t: number) =>
  t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

export interface CamPose {
  pos: THREE.Vector3;
  target: THREE.Vector3;
  up: THREE.Vector3;
  fov: number;
}

export function capturePose(camera: THREE.PerspectiveCamera, controls: OrbitControls): CamPose {
  return {
    pos: camera.position.clone(),
    target: controls.target.clone(),
    up: camera.up.clone().normalize(),
    fov: camera.fov,
  };
}

function sph(pos: THREE.Vector3, target: THREE.Vector3) {
  const o = pos.clone().sub(target);
  const r = Math.max(0.001, o.length());
  return {
    r,
    phi: Math.acos(THREE.MathUtils.clamp(o.y / r, -1, 1)),
    theta: Math.atan2(o.x, o.z),
  };
}

function fromSph(s: { r: number; phi: number; theta: number }, target: THREE.Vector3) {
  const sinP = Math.sin(s.phi);
  return new THREE.Vector3(
    target.x + s.r * sinP * Math.sin(s.theta),
    target.y + s.r * Math.cos(s.phi),
    target.z + s.r * sinP * Math.cos(s.theta),
  );
}

/** Minimum camera distance so `box` stays inside the frustum at this FOV. */
export function fitRadiusForBox(box: THREE.Box3, fovDeg: number, aspect: number, pad = 1.2): number {
  if (box.isEmpty()) return 1;
  const size = box.getSize(new THREE.Vector3());
  const fov = THREE.MathUtils.degToRad(Math.max(1, fovDeg));
  const fitH = (size.y / 2) / Math.tan(fov / 2);
  const fitW = (size.x / 2) / (Math.tan(fov / 2) * Math.max(0.2, aspect));
  const sphere = Math.max(size.x, size.y, size.z) * 0.5 / Math.sin(fov / 2);
  return Math.max(fitH, fitW, sphere * 0.5) * pad;
}

/**
 * Spherical lerp of camera around a moving look-at, with an optional bbox
 * clamp so the subject never leaves the frame. `e` is already eased 0..1.
 */
export function applyFramedLerp(
  camera: THREE.PerspectiveCamera,
  controls: OrbitControls,
  from: CamPose,
  to: CamPose,
  e: number,
  opts?: { box?: THREE.Box3; pad?: number },
) {
  const tg = from.target.clone().lerp(to.target, e);
  const a = sph(from.pos, from.target);
  const b = sph(to.pos, to.target);
  let dTheta = b.theta - a.theta;
  while (dTheta > Math.PI) dTheta -= Math.PI * 2;
  while (dTheta < -Math.PI) dTheta += Math.PI * 2;
  const s = {
    r: THREE.MathUtils.lerp(a.r, b.r, e),
    phi: THREE.MathUtils.lerp(a.phi, b.phi, e),
    theta: a.theta + dTheta * e,
  };
  camera.fov = THREE.MathUtils.lerp(from.fov, to.fov, e);
  camera.updateProjectionMatrix();
  if (opts?.box && !opts.box.isEmpty()) {
    const need = fitRadiusForBox(opts.box, camera.fov, camera.aspect, opts.pad ?? 1.2);
    if (s.r < need) s.r = need;
  }
  camera.position.copy(fromSph(s, tg));
  camera.up.copy(from.up).lerp(to.up, e).normalize();
  controls.target.copy(tg);
  camera.lookAt(tg);
}

export function beginFramedTween(
  controls: OrbitControls,
  camera: THREE.PerspectiveCamera,
): CamPose {
  freezeOrbit(controls);
  controls.enabled = false;
  return capturePose(camera, controls);
}

export function endFramedTween(
  controls: OrbitControls,
  camera: THREE.PerspectiveCamera,
  to: CamPose,
) {
  seatOrbit(controls, camera, to.pos, to.target, to.up, to.fov);
  controls.enabled = true;
  controls.enableDamping = true;
}
