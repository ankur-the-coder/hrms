import * as THREE from 'three';

/**
 * Dataset-agnostic volumetric ThemeRiver (Olympic 3D stream language).
 *
 * The live Olympic chart (ThreeStreamgraph + streamModel) stays on its
 * own hardcoded tables. This module is the reusable constructor: feed it
 * any aligned multi-series table (zeros = absent / left / not-yet-joined)
 * and it returns the same centred-stack + spline + box-ribbon topology.
 *
 * See streamGraph.txt.
 */

export interface VolumetricLayer {
  name: string;
  color: string;
  values: number[];
}

export interface VolumetricBlock {
  start: number;
  end: number;
  segs: number;
}

export interface VolumetricRiverOpts {
  totalWidth?: number;
  heightScale?: number;
  zSpan?: number;
  ribbonDepth?: number;
  drift?: number;
}

export interface RibbonBuild {
  name: string;
  color: string;
  z: number;
  geometry: THREE.BufferGeometry;
  top: { x: number; y: number }[];
  bottom: { x: number; y: number }[];
}

export function buildVolumetricRiver(
  layers: VolumetricLayer[],
  periodCount: number,
  blocks: readonly VolumetricBlock[],
  opts: VolumetricRiverOpts = {},
): RibbonBuild[] {
  const totalWidth = opts.totalWidth ?? 84;
  const heightScale = opts.heightScale ?? 0.32;
  const zSpan = opts.zSpan ?? 16;
  const ribbonDepth = opts.ribbonDepth ?? 1.6;
  const driftAmt = opts.drift ?? 6;
  const n = layers.length;
  const zStep = zSpan / Math.max(1, n);
  const out: RibbonBuild[] = [];

  blocks.forEach((blk) => {
    const numSteps = blk.segs;
    const xs: number[] = [];
    for (let i = blk.start; i <= blk.end; i++) xs.push(i / Math.max(1, periodCount - 1));
    const sampled = layers.map((c) => {
      const pts: THREE.Vector2[] = [];
      for (let i = blk.start; i <= blk.end; i++) pts.push(new THREE.Vector2(xs[i - blk.start], c.values[i] || 0));
      return new THREE.SplineCurve(pts).getPoints(numSteps);
    });
    const stackBottom: THREE.Vector2[][] = Array.from({ length: n }, () => []);
    const stackTop: THREE.Vector2[][] = Array.from({ length: n }, () => []);
    for (let step = 0; step <= numSteps; step++) {
      let totalH = 0;
      for (let s = 0; s < n; s++) totalH += Math.max(0, sampled[s][step].y);
      const normX = sampled[0][step].x;
      const drift = -normX * driftAmt;
      let currentY = -totalH / 2 + drift;
      for (let s = 0; s < n; s++) {
        const h = Math.max(0, sampled[s][step].y);
        const x = (normX - 0.5) * totalWidth;
        stackBottom[s].push(new THREE.Vector2(x, currentY * heightScale));
        currentY += h;
        stackTop[s].push(new THREE.Vector2(x, currentY * heightScale));
      }
    }

    layers.forEach((layer, s) => {
      let maxV = 0;
      for (const p of sampled[s]) if (p.y > maxV) maxV = p.y;
      if (maxV < 0.05) return;
      const zCenter = (s - n / 2) * zStep;
      const zFront = zCenter + ribbonDepth / 2, zBack = zCenter - ribbonDepth / 2;
      const positions: number[] = [], normals: number[] = [], uvs: number[] = [], indices: number[] = [];
      let vertCount = 0;
      const V3 = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
      const addQuad = (p1: THREE.Vector3, p2: THREE.Vector3, p3: THREE.Vector3, p4: THREE.Vector3, nn: THREE.Vector3) => {
        positions.push(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, p3.x, p3.y, p3.z, p4.x, p4.y, p4.z);
        for (let k = 0; k < 4; k++) normals.push(nn.x, nn.y, nn.z);
        uvs.push(0, 0, 1, 0, 1, 1, 0, 1);
        indices.push(vertCount, vertCount + 1, vertCount + 2, vertCount, vertCount + 2, vertCount + 3);
        vertCount += 4;
      };
      for (let i = 0; i < numSteps; i++) {
        const b0 = stackBottom[s][i], b1 = stackBottom[s][i + 1];
        const t0 = stackTop[s][i], t1 = stackTop[s][i + 1];
        addQuad(V3(b0.x, b0.y, zFront), V3(b1.x, b1.y, zFront), V3(t1.x, t1.y, zFront), V3(t0.x, t0.y, zFront), V3(0, 0, 1));
        addQuad(V3(b1.x, b1.y, zBack), V3(b0.x, b0.y, zBack), V3(t0.x, t0.y, zBack), V3(t1.x, t1.y, zBack), V3(0, 0, -1));
        const topNorm = V3(-(t1.y - t0.y), t1.x - t0.x, 0).normalize();
        addQuad(V3(t0.x, t0.y, zFront), V3(t1.x, t1.y, zFront), V3(t1.x, t1.y, zBack), V3(t0.x, t0.y, zBack), topNorm);
        const botNorm = V3(b1.y - b0.y, -(b1.x - b0.x), 0).normalize();
        addQuad(V3(b1.x, b1.y, zFront), V3(b0.x, b0.y, zFront), V3(b0.x, b0.y, zBack), V3(b1.x, b1.y, zBack), botNorm);
      }
      const startB = stackBottom[s][0], startT = stackTop[s][0];
      addQuad(V3(startB.x, startB.y, zBack), V3(startB.x, startB.y, zFront), V3(startT.x, startT.y, zFront), V3(startT.x, startT.y, zBack), V3(-1, 0, 0));
      const endB = stackBottom[s][numSteps], endT = stackTop[s][numSteps];
      addQuad(V3(endB.x, endB.y, zFront), V3(endB.x, endB.y, zBack), V3(endT.x, endT.y, zBack), V3(endT.x, endT.y, zFront), V3(1, 0, 0));
      const geom = new THREE.BufferGeometry();
      geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geom.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      geom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
      geom.setIndex(indices);
      geom.computeVertexNormals();
      out.push({
        name: layer.name, color: layer.color, z: zCenter, geometry: geom,
        top: stackTop[s].map((p) => ({ x: p.x, y: p.y })),
        bottom: stackBottom[s].map((p) => ({ x: p.x, y: p.y })),
      });
    });
  });
  return out;
}
