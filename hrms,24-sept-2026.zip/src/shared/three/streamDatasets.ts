/* Dynamic streamgraph test datasets — used by the "Dataset" dropdown on the
 * Streamgraph (Dynamic) chart. Each plots in the exact Olympic river-flow
 * language via buildStreamModel(). Every dataset is DENSE (many stacked
 * cohorts over 10 time steps) so the river meanders and layers richly like
 * the source Olympic chart — these exist to test the chart to its fullest.
 *
 * The first (employee_lifecycle) models a real org over 10 years. Column
 * sums start at 15 active people and finish above 50, with a mid-period
 * layoff dip, boomerang rejoiners, a bonus year, a salary-cut cohort and
 * contract/flex hires. Because of churn, well over 80 distinct employees
 * pass through the lifecycle across the decade. */

export interface StreamDynSeries { name: string; color: string; values: number[] }
export interface StreamDynEvent { at: number; label: string; detail?: string }
export interface StreamDynDataset {
  key: string;
  label: string;
  title: string;
  categories: string[];
  series: StreamDynSeries[];
  events: StreamDynEvent[];
}

const YEARS = ['2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'];
const QUARTERS = ['Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7', 'Q8', 'Q9', 'Q10'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'];

/* ---- 1. Employee lifecycle (active headcount by cohort) ----
   Column sums (active headcount): 15, 21, 30, 37, 44, 33(layoff), 40, 50, 57, 64.
   11 cohorts capture founders, growth hires, new grads, every department,
   contractors, boomerangs and a salary-cut cohort — > 80 distinct people
   pass through once churn is counted. */
export const EMPLOYEE_LIFECYCLE: StreamDynDataset = {
  key: 'employee_lifecycle',
  label: 'Employee lifecycle (15 → 50+, with turnover)',
  title: 'Employee lifecycle & active headcount by cohort, 2016–2025',
  categories: YEARS,
  series: [
    { name: 'Founders & Early Hires', color: '#0d7a54', values: [6, 6, 6, 5, 5, 5, 4, 4, 4, 4] },
    { name: 'Engineering — Core', color: '#1e5aa8', values: [3, 4, 6, 8, 10, 7, 9, 11, 13, 14] },
    { name: 'Engineering — New Grads', color: '#3b82f6', values: [0, 1, 2, 3, 4, 2, 3, 5, 6, 7] },
    { name: 'Product', color: '#0ea5e9', values: [1, 2, 2, 3, 3, 2, 3, 4, 4, 5] },
    { name: 'Design', color: '#06b6d4', values: [1, 1, 2, 2, 3, 2, 2, 3, 3, 4] },
    { name: 'Sales', color: '#c9932b', values: [2, 3, 4, 5, 6, 4, 5, 6, 7, 8] },
    { name: 'Marketing', color: '#e11d63', values: [0, 1, 2, 3, 3, 2, 3, 3, 4, 4] },
    { name: 'Customer Success', color: '#14b8a6', values: [1, 1, 2, 3, 3, 3, 4, 4, 5, 5] },
    { name: 'People & Finance', color: '#84cc16', values: [1, 1, 2, 2, 3, 3, 3, 4, 4, 4] },
    { name: 'Contract / Flex Hires', color: '#a16207', values: [0, 1, 1, 2, 3, 2, 2, 3, 4, 5] },
    { name: 'Boomerangs (Rejoined)', color: '#f97316', values: [0, 0, 1, 1, 1, 1, 2, 3, 3, 4] },
  ],
  events: [
    { at: 1, label: 'GTM founded', detail: 'Sales + support cohorts join' },
    { at: 4, label: 'Hiring wave', detail: 'Peak headcount before downturn' },
    { at: 5, label: 'Layoff period', detail: '−25% active headcount; salary cuts' },
    { at: 6, label: 'Boomerangs return', detail: 'Alumni rejoin, growth resumes' },
    { at: 7, label: 'Bonus year', detail: 'Retention payouts across cohorts' },
    { at: 9, label: 'Contract hiring', detail: 'Flex workforce doubles' },
  ],
};

/* ---- 2. Product adoption by plan tier (active accounts, thousands) ---- */
export const PRODUCT_ADOPTION: StreamDynDataset = {
  key: 'product_adoption',
  label: 'Product adoption by plan tier',
  title: 'Active accounts by plan tier (thousands), Q1–Q10',
  categories: QUARTERS,
  series: [
    { name: 'Free', color: '#38bdf8', values: [12, 18, 26, 34, 40, 44, 52, 58, 63, 70] },
    { name: 'Starter', color: '#0ea5e9', values: [5, 8, 11, 15, 18, 21, 25, 29, 32, 36] },
    { name: 'Pro', color: '#1e5aa8', values: [3, 5, 8, 12, 16, 19, 24, 29, 33, 38] },
    { name: 'Team', color: '#0d7a54', values: [1, 2, 4, 6, 9, 12, 15, 18, 22, 26] },
    { name: 'Business', color: '#14b8a6', values: [0, 1, 2, 4, 6, 9, 12, 16, 20, 24] },
    { name: 'Enterprise', color: '#a855f7', values: [0, 1, 1, 2, 4, 6, 8, 11, 14, 18] },
    { name: 'Education', color: '#8b5cf6', values: [1, 2, 3, 4, 5, 6, 8, 9, 11, 13] },
    { name: 'Trial (converting)', color: '#f97316', values: [4, 6, 7, 8, 6, 9, 10, 8, 11, 12] },
    { name: 'Churned (win-back)', color: '#ef4444', values: [0, 1, 2, 3, 5, 4, 5, 6, 7, 8] },
  ],
  events: [
    { at: 2, label: 'Pro launch', detail: 'Paid tier introduced' },
    { at: 5, label: 'Enterprise GA', detail: 'Large accounts onboard' },
    { at: 8, label: 'PLG motion', detail: 'Self-serve conversions rise' },
  ],
};

/* ---- 3. Cloud spend by service (₹ lakh / month) ---- */
export const CLOUD_SPEND: StreamDynDataset = {
  key: 'cloud_spend',
  label: 'Cloud spend by service',
  title: 'Monthly cloud spend by service (₹L), Jan–Oct',
  categories: MONTHS,
  series: [
    { name: 'Compute (VMs)', color: '#1e5aa8', values: [18, 20, 24, 30, 36, 33, 40, 46, 52, 58] },
    { name: 'Serverless', color: '#3b82f6', values: [3, 4, 6, 8, 11, 12, 15, 18, 22, 26] },
    { name: 'Object Storage', color: '#0ea5e9', values: [8, 9, 11, 13, 15, 16, 19, 22, 25, 28] },
    { name: 'Databases', color: '#a855f7', values: [6, 7, 9, 11, 13, 14, 16, 19, 21, 24] },
    { name: 'Networking / CDN', color: '#0d7a54', values: [4, 5, 6, 7, 9, 10, 12, 13, 15, 17] },
    { name: 'Analytics / Warehouse', color: '#14b8a6', values: [2, 3, 5, 7, 9, 11, 13, 16, 19, 22] },
    { name: 'AI / GPU', color: '#f97316', values: [0, 1, 2, 4, 8, 12, 18, 26, 34, 44] },
    { name: 'Observability', color: '#eab308', values: [2, 3, 3, 4, 5, 6, 7, 8, 9, 10] },
    { name: 'Security', color: '#ef4444', values: [3, 3, 4, 5, 6, 7, 8, 9, 10, 11] },
  ],
  events: [
    { at: 4, label: 'Traffic spike', detail: 'Compute scale-out' },
    { at: 6, label: 'ML platform', detail: 'GPU spend accelerates' },
    { at: 9, label: 'Cost review', detail: 'FinOps optimisation begins' },
  ],
};

/* ---- 4. Support tickets by channel (thousands / month) ---- */
export const SUPPORT_TICKETS: StreamDynDataset = {
  key: 'support_tickets',
  label: 'Support tickets by channel',
  title: 'Monthly support volume by channel (000s), Jan–Oct',
  categories: MONTHS,
  series: [
    { name: 'Email', color: '#64748b', values: [14, 15, 16, 15, 14, 13, 12, 11, 10, 9] },
    { name: 'Live Chat', color: '#0ea5e9', values: [4, 6, 8, 11, 14, 16, 19, 22, 24, 26] },
    { name: 'Phone', color: '#1e5aa8', values: [8, 8, 7, 7, 6, 6, 5, 5, 4, 4] },
    { name: 'Social', color: '#a855f7', values: [2, 3, 3, 4, 5, 5, 6, 7, 8, 9] },
    { name: 'Community Forum', color: '#8b5cf6', values: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] },
    { name: 'In-App', color: '#14b8a6', values: [2, 3, 5, 6, 8, 9, 11, 12, 14, 16] },
    { name: 'WhatsApp', color: '#22c55e', values: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] },
    { name: 'Self-serve (deflected)', color: '#0d7a54', values: [3, 5, 7, 10, 13, 17, 21, 25, 30, 35] },
  ],
  events: [
    { at: 3, label: 'Chat rollout', detail: 'Live chat opened' },
    { at: 6, label: 'Help center', detail: 'Self-serve deflection grows' },
    { at: 9, label: 'AI assistant', detail: 'Automated resolutions' },
  ],
};

/* ---- 5. Revenue by region (₹ crore / quarter) ---- */
export const REVENUE_REGION: StreamDynDataset = {
  key: 'revenue_region',
  label: 'Revenue by region',
  title: 'Quarterly revenue by region (₹Cr), Q1–Q10',
  categories: QUARTERS,
  series: [
    { name: 'North America', color: '#1e5aa8', values: [10, 13, 17, 22, 26, 24, 30, 36, 41, 46] },
    { name: 'Western Europe', color: '#3b82f6', values: [6, 8, 11, 14, 17, 16, 20, 24, 28, 32] },
    { name: 'Eastern Europe', color: '#0ea5e9', values: [2, 3, 4, 6, 8, 8, 10, 12, 14, 17] },
    { name: 'India', color: '#f59e0b', values: [3, 5, 7, 10, 13, 15, 19, 23, 28, 34] },
    { name: 'APAC (ex-India)', color: '#14b8a6', values: [2, 4, 6, 8, 11, 13, 16, 20, 24, 29] },
    { name: 'LATAM', color: '#f97316', values: [1, 2, 3, 4, 5, 6, 7, 9, 11, 13] },
    { name: 'Middle East', color: '#a855f7', values: [0, 1, 2, 3, 4, 5, 6, 8, 10, 12] },
    { name: 'Africa', color: '#84cc16', values: [0, 1, 1, 2, 3, 4, 5, 6, 7, 9] },
  ],
  events: [
    { at: 3, label: 'APAC expansion', detail: 'Singapore + India GTM' },
    { at: 5, label: 'Macro slowdown', detail: 'NA growth softens' },
    { at: 8, label: 'India overtakes EU', detail: 'Fastest-growing region' },
  ],
};

/* ---- 6. Website traffic by source (visits, millions / month) ---- */
export const TRAFFIC_SOURCE: StreamDynDataset = {
  key: 'traffic_source',
  label: 'Website traffic by source',
  title: 'Monthly visits by acquisition source (M), Jan–Oct',
  categories: MONTHS,
  series: [
    { name: 'Organic Search', color: '#0d7a54', values: [6, 7, 9, 11, 13, 14, 17, 19, 22, 25] },
    { name: 'Paid Search', color: '#f59e0b', values: [3, 4, 5, 6, 6, 5, 7, 8, 8, 9] },
    { name: 'Paid Social', color: '#f97316', values: [2, 3, 4, 5, 4, 3, 5, 6, 5, 7] },
    { name: 'Organic Social', color: '#0ea5e9', values: [3, 4, 6, 8, 11, 13, 15, 18, 20, 23] },
    { name: 'Referral', color: '#a855f7', values: [2, 2, 3, 4, 5, 5, 6, 7, 8, 9] },
    { name: 'Direct', color: '#1e5aa8', values: [4, 5, 5, 6, 7, 8, 9, 10, 11, 12] },
    { name: 'Email', color: '#64748b', values: [1, 2, 3, 3, 4, 5, 5, 6, 7, 8] },
    { name: 'Affiliate', color: '#14b8a6', values: [0, 1, 1, 2, 3, 3, 4, 5, 6, 7] },
    { name: 'App Store', color: '#8b5cf6', values: [0, 1, 2, 2, 3, 4, 5, 6, 7, 8] },
  ],
  events: [
    { at: 2, label: 'SEO investment', detail: 'Content engine live' },
    { at: 5, label: 'Viral campaign', detail: 'Social surges' },
    { at: 8, label: 'Brand growth', detail: 'Direct + organic compound' },
  ],
};

export const STREAM_DYN_DATASETS: StreamDynDataset[] = [
  EMPLOYEE_LIFECYCLE,
  PRODUCT_ADOPTION,
  CLOUD_SPEND,
  SUPPORT_TICKETS,
  REVENUE_REGION,
  TRAFFIC_SOURCE,
];
