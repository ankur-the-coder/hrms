import * as THREE from 'three';
import type { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

/** Kill leftover spherical/pan inertia so a programmatic camera seat
 *  cannot be overwritten by the next controls.update(). */
export function freezeOrbit(controls: OrbitControls) {
  controls.enableDamping = false;
  const c = controls as unknown as { sphericalDelta?: THREE.Vector3; panOffset?: THREE.Vector3 };
  c.sphericalDelta?.set(0, 0, 0);
  c.panOffset?.set(0, 0, 0);
}

/** Place the camera on a fitted pose and sync OrbitControls to it. */
export function seatOrbit(
  controls: OrbitControls,
  camera: THREE.PerspectiveCamera,
  pos: THREE.Vector3,
  target: THREE.Vector3,
  up?: THREE.Vector3,
  fov?: number,
) {
  freezeOrbit(controls);
  if (up) camera.up.copy(up);
  if (fov !== undefined) {
    camera.fov = fov;
    camera.updateProjectionMatrix();
  }
  camera.position.copy(pos);
  controls.target.copy(target);
  camera.lookAt(target);
  controls.update();
  controls.saveState();
}
