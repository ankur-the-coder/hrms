/* ============================================================
   Shared PNG / SVG export composer for the Three.js-powered charts
   (Sankey 3D, Radial Bar 2D/3D, Streamgraph 3D).

   Mirrors the look of the canvas chart exports elsewhere in the app
   (`composeExport` / `composeSvg` in Charts.tsx): a white card with the
   chart title top-left, the rasterised 3D scene in the middle, real
   vector `<text>` labels overlaid at their exact on-screen positions
   (captured from the CSS2D label DOM nodes), and a colour-swatch legend
   row at the bottom. This keeps every exported file self-describing —
   nothing is ever unlabeled in a PNG or SVG export.
   ============================================================ */

export interface ExportLabel {
  x: number;
  y: number;
  text: string;
  color?: string;
  bold?: boolean;
  fontSize?: number;
  pill?: boolean;
  /** Dark outline stroked behind light text (employee tags over ribbons). */
  halo?: string;
}
export interface ExportLegendItem { label: string; color: string }
export interface ExportTheme { ink: string; fontBody: string; fontDisplay: string }
/** A white-translucent callout box (milestone annotation) with an optional
   arrowed connector down to its anchor point on the chart. */
export interface ExportCallout {
  x: number; y: number; w: number; h: number;
  title: string; text: string;
  anchor: { x1: number; y1: number; x2: number; y2: number } | null;
}

function escXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

export function legendRows(measure: (s: string) => number, items: ExportLegendItem[], W: number) {
  const padX = 14, gap = 18, dot = 13, rowH = 18;
  const rows: { x: number; y: number; it: ExportLegendItem }[] = [];
  let x = padX, row = 0;
  items.forEach((it) => {
    const w = dot + measure(it.label);
    if (x + w > W - padX && x > padX) { x = padX; row++; }
    rows.push({ x, y: row * rowH, it });
    x += w + gap;
  });
  return { rows, height: items.length ? (row + 1) * rowH + 12 : 6 };
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export async function buildThreePNG(opts: {
  title: string;
  imageDataUrl: string;
  chartW: number;
  chartH: number;
  labels: ExportLabel[];
  legend: ExportLegendItem[];
  theme: ExportTheme;
  footnote?: string;
  callouts?: ExportCallout[];
}): Promise<HTMLCanvasElement> {
  const { title, imageDataUrl, chartW, chartH, labels, legend, theme, footnote, callouts } = opts;
  const scale = 2;
  const scratch = document.createElement('canvas').getContext('2d')!;
  scratch.font = `600 11px ${theme.fontBody}`;
  const lay = legendRows((s) => scratch.measureText(s).width, legend, chartW);
  const headH = title ? 36 : 10;
  const footH = footnote ? 20 : 0;
  const H = headH + chartH + lay.height + footH;
  const cv = document.createElement('canvas');
  cv.width = chartW * scale; cv.height = H * scale;
  const ctx = cv.getContext('2d')!;
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, chartW, H);

  if (title) {
    ctx.fillStyle = '#1c2620';
    ctx.font = `700 15px ${theme.fontDisplay}`;
    ctx.textAlign = 'left';
    ctx.fillText(title, 12, 23);
  }

  const img = await loadImage(imageDataUrl);
  ctx.drawImage(img, 0, headH, chartW, chartH);

  // Milestone callout boxes + arrowed connectors — baked in so PNG/PDF
  // exports carry the same annotations the live panel shows (they used to
  // be missing entirely).
  (callouts || []).forEach((c) => {
    const oy = headH;
    if (c.anchor) {
      ctx.strokeStyle = '#b7c0cc'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(c.anchor.x1, oy + c.anchor.y1); ctx.lineTo(c.anchor.x2, oy + c.anchor.y2); ctx.stroke();
      const ang = Math.atan2(c.anchor.y2 - c.anchor.y1, c.anchor.x2 - c.anchor.x1);
      ctx.fillStyle = '#b45309';
      ctx.beginPath();
      ctx.moveTo(c.anchor.x2, oy + c.anchor.y2);
      ctx.lineTo(c.anchor.x2 - 6.4 * Math.cos(ang - 0.42), oy + c.anchor.y2 - 6.4 * Math.sin(ang - 0.42));
      ctx.lineTo(c.anchor.x2 - 6.4 * Math.cos(ang + 0.42), oy + c.anchor.y2 - 6.4 * Math.sin(ang + 0.42));
      ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.arc(c.anchor.x2, oy + c.anchor.y2, 3.2, 0, Math.PI * 2); ctx.fill();
    }
    // white-translucent glass box (same language as the on-screen callouts)
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.strokeStyle = 'rgba(15,23,42,0.14)'; ctx.lineWidth = 1;
    ctx.beginPath();
    // @ts-ignore roundRect widely supported in modern browsers used for export
    ctx.roundRect(c.x, oy + c.y, c.w, c.h, 6);
    ctx.fill(); ctx.stroke();
    ctx.textAlign = 'left';
    ctx.font = `700 11px ${theme.fontBody}`;
    ctx.fillStyle = '#b45309';
    ctx.fillText(c.title, c.x + 9, oy + c.y + 15, c.w - 14);
    ctx.font = `500 9.5px ${theme.fontBody}`;
    ctx.fillStyle = '#475569';
    const maxW = c.w - 18;
    const words = c.text.split(' ');
    let line = ''; let ly = oy + c.y + 28;
    words.forEach((wd) => {
      const test = line ? `${line} ${wd}` : wd;
      if (ctx.measureText(test).width > maxW && line) { ctx.fillText(line, c.x + 9, ly); ly += 11; line = wd; }
      else line = test;
    });
    if (line) ctx.fillText(line, c.x + 9, ly);
  });

  labels.forEach((l) => {
    const fs = l.fontSize || 11;
    ctx.font = `${l.bold ? 700 : 600} ${fs}px ${theme.fontBody}`;
    ctx.textAlign = 'center';
    const tw = ctx.measureText(l.text).width;
    const lx = Math.max(tw / 2 + 4, Math.min(chartW - tw / 2 - 4, l.x));
    const ly = headH + l.y;
    if (l.pill !== false) {
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.strokeStyle = 'rgba(0,0,0,0.08)';
      ctx.lineWidth = 1;
      const px = 6, py = 3;
      ctx.beginPath();
      // @ts-ignore roundRect widely supported in modern browsers used for export
      ctx.roundRect(lx - tw / 2 - px, ly - fs * 0.72 - py, tw + px * 2, fs + py * 2, 6);
      ctx.fill(); ctx.stroke();
    }
    if (l.halo) {
      ctx.lineJoin = 'round'; ctx.miterLimit = 2;
      ctx.strokeStyle = l.halo; ctx.lineWidth = 2.6;
      ctx.strokeText(l.text, lx, ly + fs * 0.32);
      ctx.lineJoin = 'miter';
    }
    ctx.fillStyle = l.color || theme.ink;
    ctx.fillText(l.text, lx, ly + fs * 0.32);
  });

  ctx.font = `600 10.5px ${theme.fontBody}`;
  lay.rows.forEach(({ x, y, it }) => {
    const yy = headH + chartH + 14 + y;
    ctx.fillStyle = it.color;
    ctx.beginPath(); ctx.arc(x + 5, yy - 3, 4.5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#39443d'; ctx.textAlign = 'left';
    ctx.fillText(it.label, x + 13, yy);
  });

  if (footnote) {
    ctx.font = `500 9.5px ${theme.fontBody}`;
    ctx.fillStyle = 'rgba(28,38,32,0.5)';
    ctx.textAlign = 'left';
    ctx.fillText(footnote, 12, H - 6);
  }

  return cv;
}

export function buildThreeSVG(opts: {
  title: string;
  imageDataUrl: string;
  chartW: number;
  chartH: number;
  labels: ExportLabel[];
  legend: ExportLegendItem[];
  theme: ExportTheme;
  footnote?: string;
}): string {
  const { title, imageDataUrl, chartW, chartH, labels, legend, theme, footnote } = opts;
  const scratch = document.createElement('canvas').getContext('2d')!;
  scratch.font = `600 11px ${theme.fontBody}`;
  const lay = legendRows((s) => scratch.measureText(s).width, legend, chartW);
  const headH = title ? 36 : 10;
  const footH = footnote ? 20 : 0;
  const H = headH + chartH + lay.height + footH;

  const parts: string[] = [];
  parts.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${chartW}" height="${H}" viewBox="0 0 ${chartW} ${H}" font-family="${escXml(theme.fontBody)}">`);
  parts.push(`<rect x="0" y="0" width="${chartW}" height="${H}" fill="#ffffff"/>`);
  if (title) {
    parts.push(`<text x="12" y="23" font-family="${escXml(theme.fontDisplay)}" font-weight="700" font-size="15" fill="#1c2620">${escXml(title)}</text>`);
  }
  parts.push(`<image x="0" y="${headH}" width="${chartW}" height="${chartH}" href="${imageDataUrl}" preserveAspectRatio="none"/>`);

  labels.forEach((l) => {
    const fs = l.fontSize || 11;
    scratch.font = `${l.bold ? 700 : 600} ${fs}px ${theme.fontBody}`;
    const tw = scratch.measureText(l.text).width;
    const lx = Math.max(tw / 2 + 4, Math.min(chartW - tw / 2 - 4, l.x));
    const ly = headH + l.y;
    if (l.pill !== false) {
      parts.push(`<rect x="${(lx - tw / 2 - 6).toFixed(1)}" y="${(ly - fs * 0.72 - 3).toFixed(1)}" width="${(tw + 12).toFixed(1)}" height="${(fs + 6).toFixed(1)}" rx="6" fill="rgba(255,255,255,0.92)" stroke="rgba(0,0,0,0.08)"/>`);
    }
    parts.push(`<text x="${lx.toFixed(1)}" y="${(ly + fs * 0.32).toFixed(1)}" text-anchor="middle" font-weight="${l.bold ? 700 : 600}" font-size="${fs}" fill="${l.color || theme.ink}">${escXml(l.text)}</text>`);
  });

  lay.rows.forEach(({ x, y, it }) => {
    const yy = headH + chartH + 14 + y;
    parts.push(`<circle cx="${x + 5}" cy="${yy - 3}" r="4.5" fill="${it.color}"/>`);
    parts.push(`<text x="${x + 13}" y="${yy}" font-size="10.5" font-weight="600" fill="#39443d">${escXml(it.label)}</text>`);
  });

  if (footnote) {
    parts.push(`<text x="12" y="${H - 6}" font-size="9.5" fill="rgba(28,38,32,0.5)">${escXml(footnote)}</text>`);
  }

  parts.push('</svg>');
  return parts.join('');
}

/** Capture on-screen CSS2D label positions relative to a container, for baking into exports. */
export function captureLabelPositions(container: HTMLElement, refs: { el: HTMLElement; text: string; color?: string; bold?: boolean; fontSize?: number; halo?: string; pill?: boolean }[]): ExportLabel[] {
  const cRect = container.getBoundingClientRect();
  const out: ExportLabel[] = [];
  refs.forEach((r) => {
    const rect = r.el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return;
    const x = rect.left - cRect.left + rect.width / 2;
    const y = rect.top - cRect.top + rect.height / 2;
    if (x < -20 || y < -20 || x > cRect.width + 20 || y > cRect.height + 20) return;
    out.push({ x, y, text: r.text, color: r.color, bold: r.bold, fontSize: r.fontSize, halo: r.halo, pill: r.pill });
  });
  return out;
}

/** Render at an up-scaled pixel ratio for one frame so exports look crisp, then restore. */
export function withExportResolution<T extends { setPixelRatio: (n: number) => void }>(renderer: T, render: () => void): void {
  const prev = (renderer as unknown as { getPixelRatio?: () => number }).getPixelRatio?.() ?? 1;
  const target = Math.min(3, Math.max(prev, (typeof window !== 'undefined' ? window.devicePixelRatio : 1) * 1.5));
  renderer.setPixelRatio(target);
  render();
  render();
  renderer.setPixelRatio(prev);
}
