import supabase from '../api/db-client.js';

export async function requireUser(req, res) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (!token) { res.status(401).json({ error: 'Please sign in to continue.' }); return null; }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) { res.status(401).json({ error: 'Your session has expired. Please sign in again.' }); return null; }
  return user;
}

export async function requireTenant(req, res) {
  const user = await requireUser(req, res);
  if (!user) return null;
  const { data: profile, error } = await supabase.from('hrms_profiles').select('tenant_id, role, full_name').eq('auth_id', user.id).maybeSingle();
  if (error) throw error;
  if (!profile) { res.status(409).json({ error: 'Your workspace is being prepared. Please reload in a moment.' }); return null; }
  return { user, ...profile };
}

export const cors = (res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Cache-Control', 'no-store');
};
