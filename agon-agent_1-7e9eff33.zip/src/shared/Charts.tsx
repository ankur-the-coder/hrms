import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown, Download, Box, Square, Eye, X, Check, Minimize2 } from 'lucide-react';
import { useFlip, Popover, ChartSkeleton } from './primitives';
import { HONEST_PALETTE } from '../theme/themes';
import { fontFaceCss } from '../theme/fonts';

/* ============================================================
   Shared Charts v5
   - Single or multi-series (categories + series ⇒ stacked/grouped)
   - Kinds: bar · line · area · pie · donut · radar · polar
     (+ funnel · pyramid opt-in), 3D for bar/area/pie/donut/funnel/pyramid
   - Continuous, ease-in-out 2D⇄3D morph (no geometry jumps at any size)
   - Intelligent x-axis labels: measure → horizontal / rotated / strided,
     never overlapping; fullscreen & exports always show complete text
   - Leader arrows anchored ON the rim with an outline — never hidden
   - Exports: PNG (white bg, theme fonts, nothing trimmed) / PDF / Print /
     true-vector SVG (fonts @imported) / Excel / CSV / JSON
   - Neumorphic family (donut · pie · bars · columns · line · area) painted
     on canvas from ONE painter so the live chart and every export match
   - Palette deliberately free of purple / violet / indigo
   ============================================================ */

export interface ChartDatum { label: string; value: number; color?: string }
export interface StackedSeries { name: string; color?: string; values: number[] }
export type ChartKind = 'bar' | 'line' | 'area' | 'pie' | 'donut' | 'radar' | 'polar' | 'radialbar' | 'dual' | 'funnel' | 'pyramid' | 'calendarpie' | 'sankey' | 'gantt' | 'scatter';
/** Calendar-pie: one mini pie per day (ISO date → per-series values). */
export interface CalendarDay { date: string; values: number[] }
/** Sankey flow: source → target with a weight. */
export interface SankeyLink { source: string; target: string; value: number }
/** Gantt task: milestone / phase duration and progress. */
export interface GanttTask { id: string | number; name: string; start: string | number; end: string | number; progress?: number; color?: string; category?: string; assignee?: string }
/** Scatter point: 2D numeric correlation coordinate. */
export interface ScatterPoint { x: number; y: number; label?: string; size?: number; color?: string; category?: string }

/** Brand palette — no purple, violet or indigo anywhere. */
export const PALETTE = ['#0d7a54', '#c9932b', '#0ea5e9', '#e11d63', '#f97316', '#14b8a6', '#1e5aa8', '#84cc16', '#f43f5e', '#a16207', '#06b6d4', '#64748b'];
/** Palette for the active theme — the Honest Paper theme brings Pie.’s slice colours with it. */
export function activePalette(): string[] {
  try { return document.documentElement.getAttribute('data-theme') === 'honest' ? HONEST_PALETTE : PALETTE; } catch { return PALETTE; }
}

const TILT = 0.42;
const K = Math.sin(TILT);
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const SIN45 = Math.SQRT1_2;

/* ---------- colour utils ---------- */
function parseColor(c: string): [number, number, number, number] | null {
  const s = (c || '').trim();
  let m = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(s);
  if (m) return [parseInt(m[1] + m[1], 16), parseInt(m[2] + m[2], 16), parseInt(m[3] + m[3], 16), 1];
  m = /^#([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(s);
  if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, m[2] ? parseInt(m[2], 16) / 255 : 1]; }
  m = /^rgba?\(([^)]+)\)$/i.exec(s);
  if (m) {
    const parts = m[1].split(/[\s,/]+/).filter(Boolean).map(parseFloat);
    if (parts.length >= 3) return [parts[0], parts[1], parts[2], parts.length > 3 ? parts[3] : 1];
  }
  return null;
}
const shadeCache = new Map<string, string>();
const shade = (col: string, f: number) => {
  const key = col + '|' + f.toFixed(3);
  const hit = shadeCache.get(key);
  if (hit) return hit;
  const p = parseColor(col) || [136, 136, 136, 1];
  const c = (v: number) => Math.min(255, Math.max(0, Math.round(v * f)));
  const out = `rgb(${c(p[0])},${c(p[1])},${c(p[2])})`;
  if (shadeCache.size > 4000) shadeCache.clear();
  shadeCache.set(key, out);
  return out;
};
const rgba = (col: string, a: number) => {
  const p = parseColor(col);
  return p ? `rgba(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])},${a})` : col;
};
const withAlpha = (hex: string, a: string) => (/^#[0-9a-f]{6}$/i.test(hex) ? hex + a : rgba(hex, parseInt(a, 16) / 255));
const luma = (col: string) => { const p = parseColor(col); return p ? (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) / 255 : 0.5; };

/* ---------- theme (colours + fonts read from the live token set) ---------- */
export interface Theme { ink: string; axis: string; grid: string; surface?: string; fontBody?: string; fontDisplay?: string; dark?: boolean }
const DEF_BODY = '"Outfit", ui-sans-serif, system-ui, sans-serif';
const DEF_DISPLAY = '"Fraunces", Georgia, serif';
function cssVar(name: string, fallback: string): string {
  try { return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback; } catch { return fallback; }
}
export function themeColors(forExport = false): Theme {
  const fontBody = cssVar('--t-font-body', DEF_BODY);
  const fontDisplay = cssVar('--t-font-display', DEF_DISPLAY);
  if (forExport) return { ink: '#1c2620', axis: '#39443d', grid: 'rgba(60,70,64,0.18)', surface: '#eef0ec', fontBody, fontDisplay, dark: false };
  const ink = cssVar('--t-ink', '#101914');
  const surface = cssVar('--t-surface', '#e4e7e0');
  return { ink, axis: ink, grid: 'rgba(128,128,128,0.18)', surface, fontBody, fontDisplay, dark: luma(ink) > 0.5 };
}
const font = (t: Theme | undefined, weight: number, size: number, display = false) =>
  `${weight} ${size}px ${display ? t?.fontDisplay || DEF_DISPLAY : t?.fontBody || DEF_BODY}`;
/** Families to @import inside exported SVGs so text renders with the app's fonts. */
function fontFamilies(t: Theme): string[] {
  const out = new Set<string>();
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem('aviary-prefs-v2') : null;
    if (raw) {
      const p = JSON.parse(raw);
      if (p.fontBody) out.add(p.fontBody.trim());
      if (p.fontDisplay) out.add(p.fontDisplay.trim());
    }
  } catch { /* ignore */ }
  [t.fontBody || DEF_BODY, t.fontDisplay || DEF_DISPLAY].forEach((stack) => {
    stack.split(',').forEach((part) => {
      const first = part.trim().replace(/^["']|["']$/g, '');
      if (first && !/^(serif|sans-serif|system-ui|ui-sans-serif|ui-serif|monospace|Georgia|Arial|Helvetica)$/i.test(first)) out.add(first);
    });
  });
  return [...out];
}
const fontsReady = async () => { try { await (document as unknown as { fonts?: { ready: Promise<unknown> } }).fonts?.ready; } catch { /* noop */ } };

/* ---------- text helpers ---------- */
const approxW = (s: string, fs = 10.5) => s.length * fs * 0.58;
/** Smart label fitting — ellipsis, prefers word boundaries. Deterministic (no ctx). */
export function fitText(s: string, maxW: number, fs = 10.5): string {
  const cw = fs * 0.58;
  const maxC = Math.max(2, Math.floor(maxW / cw));
  if (s.length <= maxC) return s;
  let cut = s.slice(0, maxC - 1);
  const sp = cut.lastIndexOf(' ');
  if (sp > maxC * 0.5) cut = cut.slice(0, sp);
  return cut.trimEnd() + '…';
}
export const fmtNum = (n: number) =>
  Math.abs(n) >= 1e6 ? `${(n / 1e6).toFixed(1).replace(/\.0$/, '')}M`
    : Math.abs(n) >= 1e3 ? `${(n / 1e3).toFixed(1).replace(/\.0$/, '')}k`
    : String(Math.round(n));
type Ctx = CanvasRenderingContext2D;
const measureW = (ctx: Ctx, s: string) => {
  try { const w = ctx.measureText(s).width; return w > 0 && isFinite(w) ? w : approxW(s); } catch { return approxW(s); }
};
/** Measured ellipsis using the context's current font. */
function fitCtx(ctx: Ctx, s: string, maxW: number): string {
  if (maxW === Infinity || measureW(ctx, s) <= maxW) return s;
  let lo = 0, hi = s.length;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (measureW(ctx, s.slice(0, mid) + '…') <= maxW) lo = mid; else hi = mid - 1; }
  let cut = s.slice(0, Math.max(1, lo));
  const sp = cut.lastIndexOf(' ');
  if (sp > cut.length * 0.5) cut = cut.slice(0, sp);
  return cut.trimEnd() + '…';
}

/* ================= CDN loaders ================= */
const scriptCache = new Map<string, Promise<void>>();
function loadScript(src: string): Promise<void> {
  if (!scriptCache.has(src)) {
    scriptCache.set(src, new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = () => resolve();
      s.onerror = () => { scriptCache.delete(src); reject(new Error('Failed to load ' + src)); };
      document.head.appendChild(s);
    }));
  }
  return scriptCache.get(src)!;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
export async function loadPdfMake(): Promise<any> {
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.12/pdfmake.min.js');
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.12/vfs_fonts.js');
  return (window as any).pdfMake;
}
export async function loadExcelJS(): Promise<any> {
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js');
  return (window as any).ExcelJS;
}
/* eslint-enable @typescript-eslint/no-explicit-any */

export function downloadBlob(name: string, blob: Blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

export function jpegToPdf(jpegBytes: Uint8Array, wPx: number, hPx: number): Blob {
  const wPt = (wPx * 0.75) / 3, hPt = (hPx * 0.75) / 3;
  const enc = new TextEncoder();
  const chunks: (Uint8Array | string)[] = [];
  const offsets: number[] = [];
  let len = 0;
  const push = (s: Uint8Array | string) => { chunks.push(s); len += typeof s === 'string' ? enc.encode(s).length : s.length; };
  const obj = (body: string) => { offsets.push(len); push(body); };
  push('%PDF-1.4\n');
  obj('1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n');
  obj('2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n');
  obj(`3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${wPt.toFixed(1)} ${hPt.toFixed(1)}]/Resources<</XObject<</Im0 4 0 R>>>>/Contents 5 0 R>>endobj\n`);
  offsets.push(len);
  push(`4 0 obj<</Type/XObject/Subtype/Image/Width ${wPx}/Height ${hPx}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ${jpegBytes.length}>>stream\n`);
  push(jpegBytes);
  push('\nendstream endobj\n');
  const content = `q ${wPt.toFixed(1)} 0 0 ${hPt.toFixed(1)} 0 0 cm /Im0 Do Q`;
  obj(`5 0 obj<</Length ${content.length}>>stream\n${content}\nendstream endobj\n`);
  const xrefAt = len;
  push(`xref\n0 6\n0000000000 65535 f \n${offsets.map((o) => String(o).padStart(10, '0') + ' 00000 n \n').join('')}`);
  push(`trailer<</Size 6/Root 1 0 R>>\nstartxref\n${xrefAt}\n%%EOF`);
  return new Blob(chunks.map((c) => (typeof c === 'string' ? enc.encode(c) : c)) as BlobPart[], { type: 'application/pdf' });
}

export function printCanvas(title: string, cv: HTMLCanvasElement) {
  const url = cv.toDataURL('image/png');
  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'position:fixed;right:200vw;bottom:200vh;width:980px;height:720px;border:0;';
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow!.document;
  doc.open();
  doc.write(`<html><head><title>${title}</title><style>@page{margin:12mm;}body{margin:0;display:grid;place-items:center;background:#fff;}img{max-width:100%;}</style></head><body><img src="${url}"/></body></html>`);
  doc.close();
  const cleanup = () => { try { iframe.remove(); } catch { /* noop */ } };
  iframe.contentWindow!.onafterprint = cleanup;
  const img = doc.querySelector('img')!;
  const go = () => setTimeout(() => {
    try { iframe.contentWindow!.focus(); iframe.contentWindow!.print(); } catch { cleanup(); }
    setTimeout(cleanup, 60000);
  }, 150);
  if ((img as HTMLImageElement).complete) go(); else img.addEventListener('load', go);
}

/** Rasterize an SVG string to a canvas (white background). */
export function svgToCanvas(svg: string, w: number, h: number, scale = 3): Promise<HTMLCanvasElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
    img.onload = () => {
      const cv = document.createElement('canvas');
      cv.width = w * scale; cv.height = h * scale;
      const ctx = cv.getContext('2d')!;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.drawImage(img, 0, 0, cv.width, cv.height);
      URL.revokeObjectURL(url);
      resolve(cv);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('SVG rasterize failed')); };
    img.src = url;
  });
}

/* ============================================================
   Canvas → SVG recorder. Implements the 2D-context subset used
   by the painters (paths, text, gradients, soft shadows, alpha,
   transforms) emitting true vector SVG — so EVERY chart, including
   the neumorphic family, exports as vector with fonts intact.
   ============================================================ */
const r2 = (n: number) => Math.round(n * 100) / 100;
function splitColor(c: string): { color: string; opacity: number } {
  const p = parseColor(c);
  if (!p) return { color: c || '#000', opacity: 1 };
  return { color: `rgb(${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])})`, opacity: p[3] };
}
class SvgCtx {
  els: string[] = [];
  defs: string[] = [];
  /** embedded @font-face rules (base64 woff2) — fonts travel with the file, no CDN */
  fontCss = '';
  fillStyle: string | { __grad: string } = '#000';
  strokeStyle: string | { __grad: string } = '#000';
  lineWidth = 1;
  lineJoin = 'miter';
  lineCap = 'butt';
  font = '10px sans-serif';
  textAlign: 'left' | 'center' | 'right' | 'start' | 'end' = 'left';
  globalAlpha = 1;
  shadowBlur = 0; shadowOffsetX = 0; shadowOffsetY = 0; shadowColor = 'rgba(0,0,0,0)';
  private d = '';
  private tx = 0; private ty = 0; private rot = 0;
  private stack: { tx: number; ty: number; rot: number; alpha: number; sb: number; sx: number; sy: number; sc: string }[] = [];
  private gradN = 0;
  private filters = new Map<string, string>();
  private meas: CanvasRenderingContext2D;
  constructor(public W: number, public H: number) {
    this.meas = document.createElement('canvas').getContext('2d')!;
  }
  /* transforms / state */
  setTransform() { /* dpr no-op */ }
  clearRect() { /* no-op */ }
  save() { this.stack.push({ tx: this.tx, ty: this.ty, rot: this.rot, alpha: this.globalAlpha, sb: this.shadowBlur, sx: this.shadowOffsetX, sy: this.shadowOffsetY, sc: this.shadowColor }); }
  restore() {
    const s = this.stack.pop();
    if (s) { this.tx = s.tx; this.ty = s.ty; this.rot = s.rot; this.globalAlpha = s.alpha; this.shadowBlur = s.sb; this.shadowOffsetX = s.sx; this.shadowOffsetY = s.sy; this.shadowColor = s.sc; }
  }
  translate(x: number, y: number) { this.tx += x; this.ty += y; }
  rotate(a: number) { this.rot += a; }
  scale() { /* entrance scale is 1 at export */ }
  clip() { /* reveal clips are full-frame at export */ }
  setLineDash() { /* dashes only decorate live hover guides */ }
  rect(x: number, y: number, w: number, h: number) { this.d += `M ${this.px(x, y)} h ${r2(w)} v ${r2(h)} h ${r2(-w)} Z `; }
  /* path building */
  private px(x: number, y: number) { return `${r2(x + this.tx)} ${r2(y + this.ty)}`; }
  beginPath() { this.d = ''; }
  moveTo(x: number, y: number) { this.d += `M ${this.px(x, y)} `; }
  lineTo(x: number, y: number) { this.d += `L ${this.px(x, y)} `; }
  closePath() { this.d += 'Z '; }
  bezierCurveTo(c1x: number, c1y: number, c2x: number, c2y: number, x: number, y: number) {
    this.d += `C ${this.px(c1x, c1y)} ${this.px(c2x, c2y)} ${this.px(x, y)} `;
  }
  quadraticCurveTo(cx: number, cy: number, x: number, y: number) {
    this.d += `Q ${this.px(cx, cy)} ${this.px(x, y)} `;
  }
  arc(x: number, y: number, r: number, a0: number, a1: number, ccw = false) {
    this.ellipse(x, y, r, r, 0, a0, a1, ccw);
  }
  ellipse(x: number, y: number, rx: number, ry: number, _rot: number, a0: number, a1: number, ccw = false) {
    rx = Math.max(0.01, rx); ry = Math.max(0.01, ry);
    let d = a1 - a0;
    if (ccw && d > 0) d -= Math.PI * 2;
    if (!ccw && d < 0) d += Math.PI * 2;
    const full = Math.abs(d) >= Math.PI * 2 - 1e-4;
    const seg = full ? (d > 0 ? Math.PI : -Math.PI) : d;
    const steps = full ? 2 : 1;
    const sx = x + Math.cos(a0) * rx, sy = y + Math.sin(a0) * ry;
    if (this.d === '' || this.d.endsWith('Z ')) this.d += `M ${this.px(sx, sy)} `;
    else this.d += `L ${this.px(sx, sy)} `;
    let cur = a0;
    for (let i = 0; i < steps; i++) {
      const next = full ? cur + seg : a0 + d;
      const ex = x + Math.cos(next) * rx, ey = y + Math.sin(next) * ry;
      const large = Math.abs(next - cur) > Math.PI ? 1 : 0;
      const sweep = next > cur ? 1 : 0;
      this.d += `A ${r2(rx)} ${r2(ry)} 0 ${large} ${sweep} ${this.px(ex, ey)} `;
      cur = next;
    }
  }
  roundRect(x: number, y: number, w: number, h: number, r: number | number[]) {
    const lim = Math.min(w, h) / 2;
    const rr = (Array.isArray(r) ? r : [r, r, r, r]).map((v) => Math.min(lim, Math.max(0, v)));
    const [tl, tr, br, bl] = [rr[0] ?? 0, rr[1] ?? rr[0] ?? 0, rr[2] ?? rr[0] ?? 0, rr[3] ?? rr[1] ?? rr[0] ?? 0];
    this.d += `M ${this.px(x + tl, y)} H ${r2(x + w - tr + this.tx)} `;
    if (tr) this.d += `A ${r2(tr)} ${r2(tr)} 0 0 1 ${this.px(x + w, y + tr)} `;
    this.d += `V ${r2(y + h - br + this.ty)} `;
    if (br) this.d += `A ${r2(br)} ${r2(br)} 0 0 1 ${this.px(x + w - br, y + h)} `;
    this.d += `H ${r2(x + bl + this.tx)} `;
    if (bl) this.d += `A ${r2(bl)} ${r2(bl)} 0 0 1 ${this.px(x, y + h - bl)} `;
    this.d += `V ${r2(y + tl + this.ty)} `;
    if (tl) this.d += `A ${r2(tl)} ${r2(tl)} 0 0 1 ${this.px(x + tl, y)} `;
    this.d += 'Z ';
  }
  /* paint */
  private resolve(style: string | { __grad: string }): string {
    return typeof style === 'string' ? style : `url(#${style.__grad})`;
  }
  private fx(): string {
    let attr = this.globalAlpha < 1 ? ` opacity="${r2(this.globalAlpha)}"` : '';
    if (this.shadowBlur > 0 || this.shadowOffsetX || this.shadowOffsetY) {
      const { color, opacity } = splitColor(this.shadowColor);
      if (opacity > 0) {
        const key = `${r2(this.shadowOffsetX)}|${r2(this.shadowOffsetY)}|${r2(this.shadowBlur)}|${color}|${r2(opacity)}`;
        let id = this.filters.get(key);
        if (!id) {
          id = `sh${this.filters.size + 1}`;
          this.filters.set(key, id);
          // classic blur → offset → flood → composite → merge chain: renders in every
          // SVG engine (browsers, Inkscape, librsvg, Illustrator), unlike feDropShadow
          this.defs.push(`<filter id="${id}" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur in="SourceAlpha" stdDeviation="${r2(this.shadowBlur / 2)}"/><feOffset dx="${r2(this.shadowOffsetX)}" dy="${r2(this.shadowOffsetY)}" result="ob"/><feFlood flood-color="${color}" flood-opacity="${r2(opacity)}"/><feComposite in2="ob" operator="in" result="sh"/><feMerge><feMergeNode in="sh"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`);
        }
        attr += ` filter="url(#${id})"`;
      }
    }
    return attr;
  }
  fill() { if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`); }
  stroke() {
    if (this.d) this.els.push(`<path d="${this.d.trim()}" fill="none" stroke="${this.resolve(this.strokeStyle)}" stroke-width="${r2(this.lineWidth)}" stroke-linejoin="${this.lineJoin === 'round' ? 'round' : 'miter'}" stroke-linecap="${this.lineCap === 'round' ? 'round' : 'butt'}"${this.fx()}/>`);
  }
  fillRect(x: number, y: number, w: number, h: number) {
    this.els.push(`<rect x="${r2(x + this.tx)}" y="${r2(y + this.ty)}" width="${r2(w)}" height="${r2(h)}" fill="${this.resolve(this.fillStyle)}"${this.fx()}/>`);
  }
  fillText(text: string, x: number, y: number) {
    const fm = /(\d+(?:\.\d+)?)px\s+(.+)$/.exec(this.font);
    const size = fm ? +fm[1] : 10;
    const fam = fm ? fm[2] : 'sans-serif';
    const wm = /^(\d{3}|bold)\s/.exec(this.font);
    const weight = wm ? (wm[1] === 'bold' ? '700' : wm[1]) : '400';
    const anchor = this.textAlign === 'center' ? 'middle' : this.textAlign === 'right' || this.textAlign === 'end' ? 'end' : 'start';
    const esc = text.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const gx = r2(x + this.tx), gy = r2(y + this.ty);
    const tf = this.rot !== 0 ? ` transform="rotate(${r2((this.rot * 180) / Math.PI)} ${gx} ${gy})"` : '';
    this.els.push(`<text x="${gx}" y="${gy}" font-family="${fam.replace(/"/g, "'")}" font-size="${size}" font-weight="${weight}" text-anchor="${anchor}" fill="${this.resolve(this.fillStyle)}"${tf}${this.fx()}>${esc}</text>`);
  }
  measureText(t: string) { this.meas.font = this.font; return this.meas.measureText(t); }
  createLinearGradient(x0: number, y0: number, x1: number, y1: number) {
    const id = `g${++this.gradN}`;
    const stops: string[] = [];
    this.defs.push('');
    const idx = this.defs.length - 1;
    const self = this;
    const ax = x0 + this.tx, ay = y0 + this.ty, bx = x1 + this.tx, by = y1 + this.ty;
    return {
      __grad: id,
      addColorStop(off: number, col: string) {
        const sc = splitColor(col);
        stops.push(`<stop offset="${r2(off * 100)}%" stop-color="${sc.color}" stop-opacity="${r2(sc.opacity)}"/>`);
        self.defs[idx] = `<linearGradient id="${id}" x1="${r2(ax)}" y1="${r2(ay)}" x2="${r2(bx)}" y2="${r2(by)}" gradientUnits="userSpaceOnUse">${stops.join('')}</linearGradient>`;
      },
    };
  }
  toString(): string {
    const fams = fontFamilies(themeColors(true));
    const googleImport = fams.length
      ? `@import url('https://fonts.googleapis.com/css2?family=${fams.map((f) => encodeURIComponent(f).replace(/%20/g, '+')).join('&family=')}:wght@400;600;700&display=swap');\n`
      : '';
    const style = `<style><![CDATA[\n${googleImport}${this.fontCss}]]></style>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${this.W}" height="${this.H}" viewBox="0 0 ${this.W} ${this.H}"><defs>${style}${this.defs.join('')}</defs><rect width="${this.W}" height="${this.H}" fill="#ffffff"/>${this.els.join('')}</svg>`;
  }
}

/* ================= Mini dropdown (shows current selection) ================= */
export function MiniDrop({ label, items, onPick, icon, activeKey }: {
  label: string; items: { key: string; label: string; disabled?: boolean }[];
  onPick: (k: string) => void; icon?: React.ReactNode; activeKey?: string;
}) {
  const [open, setOpen] = useState(false);
  const anchorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (anchorRef.current && !anchorRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    window.addEventListener('mousedown', onDown);
    return () => window.removeEventListener('mousedown', onDown);
  }, [open]);

  return (
    <div ref={anchorRef} className="relative z-40">
      <button onClick={() => setOpen(!open)}
        className="tk-btn-ghost flex items-center gap-1.5 rounded-xl px-3 py-1.5 font-body text-[12px] font-bold">
        {icon} {label} <ChevronDown size={12} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div style={{ backgroundColor: 'var(--t-surface)', zIndex: 9999 }}
          className="tk-pop absolute left-0 top-full mt-1.5 min-w-[180px] max-h-[70vh] overflow-y-auto rounded-xl p-1 shadow-2xl border border-ink/15">
          {items.map((it) => (
            <button key={it.key} disabled={it.disabled}
              onClick={() => { setOpen(false); onPick(it.key); }}
              className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-left font-body text-[12.5px] font-semibold transition hover:bg-primary/10 disabled:opacity-35 ${activeKey === it.key ? 'text-primary font-bold bg-primary/5' : 'text-ink/80'}`}>
              {it.label}
              {activeKey === it.key && <Check size={13} className="shrink-0 text-primary" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function useThemeTick() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const handler = () => { setTick((t) => t + 1); timer = setTimeout(() => setTick((t) => t + 1), 720); };
    window.addEventListener('aviary:prefs', handler);
    return () => { window.removeEventListener('aviary:prefs', handler); clearTimeout(timer); };
  }, []);
  return tick;
}

/* ============================================================
   Intelligent x-axis labels
   measure → horizontal if they fit; otherwise rotate (-45° / -90°)
   and stride so labels never collide. Compact mode keeps things
   readable with measured ellipsis; full mode (fullscreen / export)
   never truncates and grows the bottom padding instead.
   ============================================================ */
interface XPlan { rot: number; stride: number; padB: number; maxW: number; fs: number; /** how far a rotated first label reaches left of its anchor */ overhang: number }
function planX(labels: string[], step: number, full: boolean, fs = 10.5): XPlan {
  const longest = labels.reduce((m, l) => Math.max(m, approxW(l, fs)), 0);
  const base = 34;
  if (!labels.length || longest <= step - 6) return { rot: 0, stride: 1, padB: base, maxW: Math.max(20, step - 4), fs, overhang: 0 };
  if (full) {
    const rot = longest * SIN45 + fs <= 130 ? -Math.PI / 4 : -Math.PI / 2;
    const foot = (fs * 1.4) / Math.abs(Math.sin(rot));
    const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
    const padB = Math.min(170, (rot === -Math.PI / 2 ? longest : longest * SIN45) + 22);
    return { rot, stride, padB, maxW: Infinity, fs, overhang: longest * Math.abs(Math.cos(rot)) + 4 };
  }
  if (step >= 56) return { rot: 0, stride: 1, padB: base, maxW: step - 4, fs, overhang: 0 };
  const rot = -Math.PI / 4;
  const foot = (fs * 1.4) / SIN45;
  const stride = Math.max(1, Math.ceil(foot / Math.max(1, step)));
  const maxW = 78;
  const padB = Math.min(70, Math.min(longest, maxW) * SIN45 + 22);
  return { rot, stride, padB, maxW, fs, overhang: Math.min(longest, maxW) * SIN45 + 4 };
}
/** Plan labels for a plot of width `W - l - r`, growing the left pad when a rotated first label would spill off-canvas. */
function planXFit(labels: string[], W: number, l: number, r: number, full: boolean, fs: number, slots: number, endpoints = false) {
  const stepOf = (left: number) => { const cw = Math.max(10, W - left - r); return endpoints ? (slots > 1 ? cw / (slots - 1) : cw) : cw / Math.max(1, slots); };
  let plan = planX(labels, stepOf(l), full, fs);
  if (plan.overhang > l) { l = plan.overhang; plan = planX(labels, stepOf(l), full, fs); }
  return { plan, l, step: stepOf(l) };
}
function drawXLabels(ctx: Ctx, labels: string[], plan: XPlan, xOf: (i: number) => number, yAxis: number, t: Theme, W: number, weight = 600, color?: string) {
  ctx.font = font(t, weight, plan.fs);
  ctx.fillStyle = color || t.axis;
  const n = labels.length;
  for (let i = 0; i < n; i++) {
    const x = xOf(i);
    const isLast = i === n - 1;
    const shown = i % plan.stride === 0 || (isLast && plan.stride > 1 && (n - 1) % plan.stride >= Math.ceil(plan.stride * 0.6));
    if (!shown) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x, yAxis); ctx.lineTo(x, yAxis + 3); ctx.stroke();
      continue;
    }
    const text = plan.maxW === Infinity ? labels[i] : fitCtx(ctx, labels[i], plan.maxW);
    if (plan.rot === 0) {
      const w = measureW(ctx, text);
      const cx = Math.max(w / 2 + 2, Math.min(W - w / 2 - 2, x));
      ctx.textAlign = 'center';
      ctx.fillText(text, cx, yAxis + 16);
    } else {
      ctx.save(); ctx.translate(x, yAxis + 8); ctx.rotate(plan.rot); ctx.textAlign = 'right';
      ctx.fillText(text, 0, plan.fs * 0.35); ctx.restore();
    }
  }
  ctx.textAlign = 'left';
}

/* ================= geometry helpers ================= */
const ZX = 15, ZY = 10, DZ = 7, DZY = 4.5; // 3D line/area: per-series depth step + (thin) slab thickness
interface XY { pad: { l: number; r: number; t: number; b: number }; cw: number; ch: number; step: number; plan: XPlan; ox: number; oy: number }
function xyLayout(kind: 'bar' | 'line' | 'area', W: number, H: number, m: number, labels: string[], nD: number, max: number, hasY: boolean, full: boolean): XY {
  const isBar = kind === 'bar';
  const ox = isBar ? 13 * m : ZX * m * Math.max(0, nD - 1) + DZ * m;
  const oy = isBar ? 9 * m : ZY * m * Math.max(0, nD - 1) + DZY * m;
  const l0 = 12 + approxW(fmtNum(max), 10.5) + 12 + (hasY ? 14 : 0);
  const r = 16 + (isBar ? 20 * m : ox);
  const tp = 18 + (isBar ? 12 * m : oy);
  const { plan, l, step } = planXFit(labels, W, l0, r, full, 10.5, labels.length);
  return { pad: { l, r, t: tp, b: plan.padB }, cw: W - l - r, ch: H - tp - plan.padB, step, plan, ox, oy };
}

/** Depth rank per series: 0 = front (smallest total) … n-1 = back (largest). */
export function seriesDepth(series: StackedSeries[]): number[] {
  const order = series.map((s, i) => ({ i, sum: s.values.reduce((a, b) => a + b, 0) })).sort((a, b) => a.sum - b.sum);
  const depth = new Array(series.length).fill(0);
  order.forEach((o, rank) => { depth[o.i] = rank; });
  return depth;
}

const leaderLabel = (d: ChartDatum, total: number) => `${d.label} · ${Math.round((d.value / total) * 100)}%`;
function circGeom(W: number, H: number, m: number, data: ChartDatum[], full = false) {
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const longest = Math.max(0, ...data.map((x) => approxW(leaderLabel(x, total))));
  const labelSpace = full ? longest + 40 : Math.min(Math.max(60, longest) + 34, W * 0.32);
  const squash = lerp(1, K, m);
  // The diameter is FIXED across the 2D⇄3D morph: the disc is sized once for
  // the flat view (the binding constraint) and only tilts/extrudes afterwards.
  let R = Math.min(W / 2 - labelSpace, (H - 44) / 2);
  R = Math.max(full ? 60 : 40, R);
  const depth = Math.max(22, Math.min(46, R * 0.38)) * m;
  const cy = (H - depth) / 2 + 4;
  return { cx: W / 2, cy, R, rInRatio: 0.55, depth, squash, total };
}

/* ---- sankey layout: longest-path column assignment, proportional node heights, flows stacked in node order ---- */
interface SkNode { name: string; col: number; value: number; x: number; y: number; h: number; color: string }
interface SkFlow { si: number; ti: number; value: number; sy0: number; sy1: number; ty0: number; ty1: number }
export function sankeyLayout(links: SankeyLink[], W: number, H: number, labelSpace: number) {
  const names = [...new Set(links.flatMap((l) => [l.source, l.target]))];
  const idx = new Map(names.map((n, i) => [n, i]));
  const outs = names.map(() => [] as number[]), ins = names.map(() => [] as number[]);
  links.forEach((l, li) => { outs[idx.get(l.source)!].push(li); ins[idx.get(l.target)!].push(li); });
  // column = longest path from a source (cycle-guarded)
  const col = new Array(names.length).fill(0);
  const visit = (i: number, depth: number, seen: Set<number>) => {
    if (seen.has(i) || depth > 32) return;
    col[i] = Math.max(col[i], depth);
    seen.add(i);
    outs[i].forEach((li) => visit(idx.get(links[li].target)!, depth + 1, seen));
    seen.delete(i);
  };
  names.forEach((_, i) => { if (!ins[i].length) visit(i, 0, new Set()); });
  const cols = Math.max(...col) + 1;
  if (cols < 2) return null;
  const value = names.map((_, i) => Math.max(outs[i].reduce((s2, li) => s2 + links[li].value, 0), ins[i].reduce((s2, li) => s2 + links[li].value, 0)));
  const padT = 14, padB = 14, padL = 8, padR = labelSpace;
  const nodeW = 12, gap = 10;
  const plotW = W - padL - padR - nodeW, plotH = H - padT - padB;
  const colX = Array.from({ length: cols }, (_, c) => padL + (plotW * c) / (cols - 1));
  const perCol = Array.from({ length: cols }, () => [] as number[]);
  names.forEach((_, i) => perCol[col[i]].push(i));
  // scale so the tallest column fits
  const colTotal = perCol.map((ids) => ids.reduce((s2, i) => s2 + value[i], 0) + gap * Math.max(0, ids.length - 1));
  const scale = (plotH) / Math.max(...colTotal, 1);
  const pal = activePalette();
  const nodes: SkNode[] = names.map((n, i) => ({ name: n, col: col[i], value: value[i], x: colX[col[i]], y: 0, h: value[i] * scale, color: pal[i % pal.length] }));
  perCol.forEach((ids) => {
    ids.sort((a, b) => value[b] - value[a]);
    const total = ids.reduce((s2, i) => s2 + nodes[i].h, 0) + gap * Math.max(0, ids.length - 1);
    let y = padT + (plotH - total) / 2;
    ids.forEach((i) => { nodes[i].y = y; y += nodes[i].h + gap; });
  });
  // flows: stack outgoing on the source (ordered by target y) and incoming on the target (ordered by source y)
  const flows: SkFlow[] = links.map((l) => ({ si: idx.get(l.source)!, ti: idx.get(l.target)!, value: l.value, sy0: 0, sy1: 0, ty0: 0, ty1: 0 }));
  nodes.forEach((n, i) => {
    let y = n.y;
    outs[i].map((li) => flows[li]).sort((a, b) => nodes[a.ti].y - nodes[b.ti].y).forEach((f) => { f.sy0 = y; y += f.value * scale; f.sy1 = y; });
    y = n.y;
    ins[i].map((li) => flows[li]).sort((a, b) => nodes[a.si].y - nodes[b.si].y).forEach((f) => { f.ty0 = y; y += f.value * scale; f.ty1 = y; });
  });
  return { nodes, flows, nodeW, cols, colX };
}

/* ---- radial bar geometry ---- */
function radialGeom(W: number, H: number, data: ChartDatum[], full: boolean) {
  const n = Math.max(1, data.length);
  const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
  const labelSpace = full ? longest + 26 : Math.min(W * 0.3, Math.max(48, longest) + 22);
  const R = Math.max(30, Math.min((W - labelSpace) / 2 - 12, H / 2 - 16));
  const cx = labelSpace + (W - labelSpace) / 2, cy = H / 2;
  const gap = 3;
  const thick = Math.max(4, Math.min(22, (R * 0.72 - gap * (n - 1)) / n));
  const radiusOf = (i: number) => R - thick / 2 - i * (thick + gap);
  return { cx, cy, R, thick, gap, radiusOf, labelSpace, n };
}

const funnelLabel = (x: ChartDatum, total: number) => `${x.label} · ${x.value} (${Math.round((x.value / total) * 100)}%)`;
function funnelGeom(W: number, H: number, m: number, data: ChartDatum[], full: boolean, pyramid = false) {
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const longest = Math.max(0, ...data.map((x) => approxW(funnelLabel(x, total))));
  const labelSpace = full ? longest + 40 : Math.min(160, W * 0.3);
  const padT = 16, padB = 16;
  // the visual envelope is identical in 2D and 3D — the 3D body shrinks to
  // make room for its elliptical caps instead of growing past it
  const env = Math.min(H - padT - padB, W * 0.62);
  const sq = 0.16 * m;
  const ch = env / (1 + 1.2 * sq);
  // the 3D pyramid's side face extends 20 % of the base width to the right;
  // reserve that room so the leader lane always clears it
  const side = pyramid ? 0.2 * 0.96 * m : 0;
  const plotW = Math.min((W - labelSpace - 60) / (1 + side / 2), ch * 1.15);
  const capTop = (plotW / 2) * sq;
  const topY = padT + (H - padT - padB - env) / 2 + capTop;
  const cx = (W - labelSpace) / 2 + 10 - (plotW * side) / 4;
  // x where every leader turns towards its label: just right of the widest point
  const laneX = cx + (plotW / 2) * 0.96 + plotW * side + 14;
  return { total, labelSpace, ch, plotW, sq, topY, cx, capTop, laneX };
}

/* ================= leader labels — curved arrows attached ON the rim ================= */
function drawLeaders(ctx: Ctx, cx: number, cy: number, R: number, squash: number, data: ChartDatum[], colors: string[], total: number, t: Theme, W: number, H: number, equalAngles = false, full = false) {
  ctx.font = font(t, 600, full ? 13 : 12);
  const n = data.length;
  let a = -Math.PI / 2;
  interface E { i: number; mid: number; right: boolean; y: number }
  const entries: E[] = data.map((d, i) => {
    let mid: number;
    if (equalAngles) mid = -Math.PI / 2 + ((i + 0.5) * Math.PI * 2) / n;
    else { const a2 = a + (d.value / total) * Math.PI * 2; mid = (a + a2) / 2; a = a2; }
    return { i, mid, right: Math.cos(mid) >= 0, y: cy + Math.sin(mid) * (R + 20) * squash };
  });
  const place = (list: E[]) => {
    list.sort((p, q) => p.y - q.y);
    let prev = -Infinity;
    list.forEach((e) => { e.y = Math.max(e.y, prev + 18); prev = e.y; });
    list.forEach((e) => { e.y = Math.max(12, Math.min(H - 8, e.y)); });
  };
  place(entries.filter((e) => e.right));
  place(entries.filter((e) => !e.right));

  entries.forEach((e) => {
    const d = data[e.i];
    const ax = cx + Math.cos(e.mid) * R;
    const ay = cy + Math.sin(e.mid) * R * squash;
    const qx = cx + Math.cos(e.mid) * (R + 18);
    const qy = cy + Math.sin(e.mid) * (R + 18) * squash;
    const ex = cx + (e.right ? R + 26 : -(R + 26));
    const tx = cx + (e.right ? R + 34 : -(R + 34));
    const c1x = (ex + qx) / 2, c1y = e.y;
    const c2x = qx, c2y = qy;
    // end tangent (anchor − c2) → arrow direction
    const dx = ax - c2x, dy = ay - c2y;
    const dl = Math.hypot(dx, dy) || 1;
    const ux = dx / dl, uy = dy / dl;
    const px2 = -uy, py2 = ux;
    // the curve stops where the arrowhead begins so nothing overdraws the head
    const bx = ax - ux * 8, by = ay - uy * 8;
    ctx.strokeStyle = colors[e.i];
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(tx, e.y);
    ctx.lineTo(ex, e.y);
    ctx.bezierCurveTo(c1x, c1y, c2x, c2y, bx, by);
    ctx.stroke();
    // arrowhead: tip sits ON the rim, outlined so it reads cleanly against any background
    ctx.fillStyle = colors[e.i];
    ctx.beginPath();
    ctx.moveTo(ax + ux * 0.5, ay + uy * 0.5);
    ctx.lineTo(bx - ux * 1.2 + px2 * 4.2, by - uy * 1.2 + py2 * 4.2);
    ctx.lineTo(bx - ux * 1.2 - px2 * 4.2, by - uy * 1.2 - py2 * 4.2);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.lineJoin = 'round';
    ctx.stroke();
    ctx.lineJoin = 'miter';
    // label — larger font (12px / 13px), clear legible text
    const avail = e.right ? W - tx - 8 : tx - 8;
    ctx.fillStyle = t.ink;
    ctx.textAlign = e.right ? 'left' : 'right';
    const text = leaderLabel(d, total);
    ctx.fillText(full ? text : fitCtx(ctx, text, avail), tx + (e.right ? 4 : -4), e.y + 4);
  });
  ctx.textAlign = 'left';
}

/* ================= axes ================= */
function drawAxes(ctx: Ctx, W: number, H: number, pad: { l: number; r: number; t: number; b: number }, max: number, t: Theme, ox = 0, oy = 0) {
  const ch = H - pad.t - pad.b;
  ctx.font = font(t, 600, 10.5);
  for (let g = 0; g <= 4; g++) {
    const y = pad.t + ch - (ch * g) / 4;
    ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
    ctx.beginPath();
    if (ox) { ctx.moveTo(pad.l, y); ctx.lineTo(pad.l + ox, y - oy); ctx.lineTo(W - pad.r + ox, y - oy); }
    else { ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); }
    ctx.stroke();
    ctx.fillStyle = t.axis; ctx.textAlign = 'right';
    ctx.fillText(fmtNum((max * g) / 4), pad.l - 7, y + 3.5);
  }
  ctx.strokeStyle = t.axis; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(pad.l, pad.t - 4); ctx.lineTo(pad.l, pad.t + ch); ctx.lineTo(W - pad.r, pad.t + ch); ctx.stroke();
  ctx.lineWidth = 1;
  ctx.textAlign = 'left';
}

/* ================= hover model ================= */
interface Hover { idx: number | null; seg: { c: number; s: number } | null; amt: number }
const NO_HOVER: Hover = { idx: null, seg: null, amt: 0 };

export interface DrawCtx {
  W: number; H: number; t: Theme; p: number; m: number; hov: Hover;
  data: ChartDatum[]; colors: string[];
  multi: boolean; cats: string[]; series: StackedSeries[]; sColors: string[];
  yLabel?: string;
  /** fullscreen / export — labels are never truncated */
  full?: boolean;
  /** opaque background (exports) — otherwise the frame is cleared to transparent */
  bg?: string;
  /** calendar-pie input (series names come from `series`) */
  days?: CalendarDay[];
  /** sankey input */
  links?: SankeyLink[];
  /** gantt input */
  tasks?: GanttTask[];
  /** scatter input */
  scatter?: ScatterPoint[];
}

/* ================= unified painter (m = 3D morph 0..1) ================= */
export function paintChart(ctx: Ctx, kind: ChartKind, d: DrawCtx) {
  const { W, H, t, p, m, hov, data, colors, multi, cats, series, sColors } = d;
  const full = !!d.full;
  if (d.bg) { ctx.fillStyle = d.bg; ctx.fillRect(0, 0, W, H); } else ctx.clearRect(0, 0, W, H);
  if (!data.length && !(multi && cats.length) && kind !== 'calendarpie' && kind !== 'sankey' && kind !== 'gantt' && kind !== 'scatter') return;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;

  /* ============ BAR ============ */
  if (kind === 'bar') {
    const labels = multi ? cats : data.map((x) => x.label);
    const max = multi
      ? Math.max(...cats.map((_, c) => series.reduce((s, sr) => s + (sr.values[c] || 0), 0)), 1)
      : Math.max(...data.map((x) => x.value), 1);
    const L = xyLayout('bar', W, H, m, labels, 1, max, !!d.yLabel, full);
    const { pad, ch, step, ox, oy } = L;
    drawAxes(ctx, W, H, pad, max, t, ox, oy);
    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2 + ox / 2, pad.t + ch, t, W);

    labels.forEach((_, ci) => {
      const bw = Math.min(44, step * 0.52);
      const x = pad.l + step * ci + (step - bw) / 2;
      const segs = multi
        ? series.map((sr, si) => ({ v: sr.values[ci] || 0, col: sColors[si], on: !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === si) }))
        : [{ v: data[ci].value, col: colors[ci], on: hov.idx === ci }];
      let acc = 0;
      segs.forEach((sg, si) => {
        if (sg.v <= 0) return;
        const h = (sg.v / max) * ch * p;
        const yTop = pad.t + ch - ((acc / max) * ch * p) - h;
        const col = sg.on ? shade(sg.col, 1 + 0.16 * hov.amt) : sg.col;
        if (m > 0.02) {
          ctx.fillStyle = shade(sg.col, 0.7 * (sg.on ? 1 + 0.1 * hov.amt : 1));
          ctx.beginPath(); ctx.moveTo(x + bw, yTop); ctx.lineTo(x + bw + ox, yTop - oy);
          ctx.lineTo(x + bw + ox, yTop - oy + h); ctx.lineTo(x + bw, yTop + h); ctx.closePath(); ctx.fill();
          const isTop = si === segs.length - 1 || segs.slice(si + 1).every((z) => z.v <= 0);
          if (isTop) {
            ctx.fillStyle = shade(sg.col, 1.22);
            ctx.beginPath(); ctx.moveTo(x, yTop); ctx.lineTo(x + ox, yTop - oy);
            ctx.lineTo(x + bw + ox, yTop - oy); ctx.lineTo(x + bw, yTop); ctx.closePath(); ctx.fill();
          }
          ctx.fillStyle = col;
          ctx.fillRect(x, yTop, bw, h);
        } else {
          ctx.fillStyle = col;
          ctx.beginPath(); ctx.roundRect(x, yTop, bw, Math.max(1, h - (multi ? 1 : 0)), multi ? 2 : [6, 6, 0, 0]); ctx.fill();
        }
        acc += sg.v;
      });
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ LINE (2D only) & AREA (2D + thin 3D slabs) ============ */
  if (kind === 'line' || kind === 'area') {
    const list: { name: string; color: string; values: number[] }[] = multi
      ? series.map((s, i) => ({ name: s.name, color: sColors[i], values: s.values }))
      : [{ name: '', color: colors[0], values: data.map((x) => x.value) }];
    const nD = list.length;
    // smaller series sit in FRONT, larger ones recede — nothing gets hidden
    const depth = multi ? seriesDepth(series) : [0];
    const zx = ZX * m, zy = ZY * m, dz = DZ * m, dzy = DZY * m;
    const labels = multi ? cats : data.map((x) => x.label);
    const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
    const L = xyLayout(kind, W, H, m, labels, nD, max, !!d.yLabel, full);
    const { pad, ch, step, ox, oy } = L;
    drawAxes(ctx, W, H, pad, max, t, ox, oy);
    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, L.plan, (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);

    const isArea = kind === 'area';
    const order = list.map((_, i) => i).sort((a, b) => depth[b] - depth[a]); // back → front
    for (const si of order) {
      const sr = list[si];
      const offX = zx * depth[si], offY = zy * depth[si];
      const baseY = pad.t + ch - offY;
      const pts = sr.values.map((v, i) => ({
        x: pad.l + step * i + step / 2 + offX,
        y: pad.t + ch - (v / max) * ch * p - offY,
      }));
      if (!pts.length) continue;

      if (isArea && m > 0.02) {
        const back = pts.map((pt) => ({ x: pt.x + dz, y: pt.y - dzy }));
        ctx.fillStyle = shade(sr.color, 0.72);
        ctx.beginPath();
        ctx.moveTo(back[0].x, baseY - dzy);
        back.forEach((pt) => ctx.lineTo(pt.x, pt.y));
        ctx.lineTo(back[back.length - 1].x, baseY - dzy);
        ctx.closePath(); ctx.fill();
        for (let i = 0; i < pts.length - 1; i++) {
          ctx.fillStyle = shade(sr.color, 0.95);
          ctx.beginPath();
          ctx.moveTo(pts[i].x, pts[i].y);
          ctx.lineTo(pts[i + 1].x, pts[i + 1].y);
          ctx.lineTo(back[i + 1].x, back[i + 1].y);
          ctx.lineTo(back[i].x, back[i].y);
          ctx.closePath(); ctx.fill();
        }
        ctx.fillStyle = shade(sr.color, 0.6);
        ctx.beginPath();
        ctx.moveTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
        ctx.lineTo(back[back.length - 1].x, back[back.length - 1].y);
        ctx.lineTo(back[back.length - 1].x, baseY - dzy);
        ctx.lineTo(pts[pts.length - 1].x, baseY);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = withAlpha(sr.color, 'e6');
        ctx.beginPath();
        ctx.moveTo(pts[0].x, baseY);
        pts.forEach((pt) => ctx.lineTo(pt.x, pt.y));
        ctx.lineTo(pts[pts.length - 1].x, baseY);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = shade(sr.color, 1.15); ctx.lineWidth = 1.5;
        ctx.beginPath();
        pts.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
        ctx.stroke();
      } else {
        const curve = () => {
          ctx.moveTo(pts[0].x, pts[0].y);
          for (let i = 0; i < pts.length - 1; i++) {
            const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
            ctx.bezierCurveTo(
              p1.x + (p2.x - p0.x) / 6, p1.y + (p2.y - p0.y) / 6,
              p2.x - (p3.x - p1.x) / 6, p2.y - (p3.y - p1.y) / 6, p2.x, p2.y);
          }
        };
        if (isArea) {
          ctx.beginPath(); curve();
          ctx.lineTo(pts[pts.length - 1].x, baseY); ctx.lineTo(pts[0].x, baseY); ctx.closePath();
          const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ch);
          grad.addColorStop(0, withAlpha(sr.color, multi ? '3d' : '59'));
          grad.addColorStop(1, withAlpha(sr.color, '08'));
          ctx.fillStyle = grad; ctx.fill();
          ctx.strokeStyle = sr.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
          ctx.beginPath(); curve(); ctx.stroke();
        } else {
          ctx.strokeStyle = sr.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
          ctx.beginPath();
          pts.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
          ctx.stroke();
        }
        // markers thin out automatically when points get dense
        const dense = step < 14;
        pts.forEach((pt, i) => {
          const on = multi ? (hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === si) : hov.idx === i;
          if (dense && !on) return;
          ctx.fillStyle = on ? shade(sr.color, 1 + 0.2 * hov.amt) : sr.color;
          ctx.beginPath(); ctx.arc(pt.x, pt.y, (step < 26 ? 3 : 4) + (on ? 2.5 * hov.amt : 0), 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
        });
      }
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ RADAR (2D) ============ */
  if (kind === 'radar') {
    const labels = multi ? cats : data.map((x) => x.label);
    const longest = Math.max(0, ...labels.map((l) => approxW(l)));
    const margin = full ? Math.min(W * 0.4, longest + 24) : 44;
    const cx = W / 2, cy = H / 2 + 6, R = Math.max(30, Math.min(W / 2 - margin, H / 2 - 30));
    const n = Math.max(1, labels.length);
    const max = multi ? Math.max(...series.flatMap((s) => s.values), 1) : Math.max(...data.map((x) => x.value), 1);
    const ang = (i: number) => -Math.PI / 2 + (i * Math.PI * 2) / n;
    for (let ring = 1; ring <= 3; ring++) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i <= n; i++) {
        const aa = ang(i % n);
        i === 0 ? ctx.moveTo(cx + Math.cos(aa) * R * (ring / 3), cy + Math.sin(aa) * R * (ring / 3))
          : ctx.lineTo(cx + Math.cos(aa) * R * (ring / 3), cy + Math.sin(aa) * R * (ring / 3));
      }
      ctx.stroke();
    }
    ctx.font = font(t, 600, 10.5);
    labels.forEach((l, i) => {
      const aa = ang(i);
      ctx.strokeStyle = t.grid;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(aa) * R, cy + Math.sin(aa) * R); ctx.stroke();
      ctx.fillStyle = t.axis;
      ctx.textAlign = Math.abs(Math.cos(aa)) < 0.3 ? 'center' : Math.cos(aa) > 0 ? 'left' : 'right';
      const lx = cx + Math.cos(aa) * (R + 12);
      const avail = Math.abs(Math.cos(aa)) < 0.3 ? W - 8 : Math.cos(aa) > 0 ? W - lx - 4 : lx - 4;
      ctx.fillText(full ? l : fitCtx(ctx, l, Math.max(30, avail)), lx, cy + Math.sin(aa) * (R + 12) + 3);
    });
    const polys = multi
      ? series.map((s, i) => ({ color: sColors[i], values: s.values }))
      : [{ color: colors[0], values: data.map((x) => x.value) }];
    polys.forEach((poly) => {
      ctx.beginPath();
      for (let i = 0; i <= n; i++) {
        const aa = ang(i % n), v = ((poly.values[i % n] || 0) / max) * R * p;
        i === 0 ? ctx.moveTo(cx + Math.cos(aa) * v, cy + Math.sin(aa) * v) : ctx.lineTo(cx + Math.cos(aa) * v, cy + Math.sin(aa) * v);
      }
      ctx.closePath();
      ctx.fillStyle = withAlpha(poly.color, multi ? '2e' : '40'); ctx.fill();
      ctx.strokeStyle = poly.color; ctx.lineWidth = 2; ctx.stroke();
    });
    if (!multi) {
      data.forEach((x, i) => {
        const aa = ang(i), v = (x.value / max) * R * p;
        const on = hov.idx === i;
        ctx.fillStyle = on ? shade(colors[0], 1 + 0.25 * hov.amt) : colors[0];
        ctx.beginPath(); ctx.arc(cx + Math.cos(aa) * v, cy + Math.sin(aa) * v, 4 + (on ? 2 * hov.amt : 0), 0, Math.PI * 2); ctx.fill();
      });
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ POLAR (2D ⇄ 3D) ============ */
  if (kind === 'polar') {
    const g = circGeom(W, H, m, data, full);
    const cx = g.cx, cy = g.cy, R = g.R;
    const squash = 1 - 0.44 * m;
    const depth = 16 * m;
    const max = Math.max(...data.map((x) => x.value), 1);

    if (m > 0.05) {
      ctx.save();
      setShadow(ctx, 0, 8, 20, rgba(t.ink, 0.22 * m));
      ctx.fillStyle = t.surface || '#e4e7e0';
      ctx.beginPath();
      ctx.ellipse(cx, cy + depth, R, R * squash, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    for (let ring = 1; ring <= 3; ring++) {
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(cx, cy, R * (ring / 3), R * (ring / 3) * squash, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    const n = Math.max(1, data.length);
    data.forEach((x, i) => {
      const a0 = -Math.PI / 2 + (i * Math.PI * 2) / n;
      const a1 = a0 + (Math.PI * 2) / n;
      const on = hov.idx === i;
      const r = Math.max(2, (x.value / max) * R * p);
      const dy = on ? -4 * hov.amt * m : 0;
      const col = colors[i];

      // 3D extrusion wall
      if (m > 0.05) {
        ctx.fillStyle = shade(col, 0.72);
        ctx.beginPath();
        ctx.ellipse(cx, cy + depth + dy, r, r * squash, 0, a0, a1, false);
        ctx.ellipse(cx, cy + dy, r, r * squash, 0, a1, a0, true);
        ctx.closePath();
        ctx.fill();
      }

      ctx.fillStyle = on ? shade(col, 1.1) : withAlpha(col, 'dd');
      ctx.beginPath();
      ctx.moveTo(cx, cy + dy);
      ctx.ellipse(cx, cy + dy, r, r * squash, 0, a0, a1, false);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 1; ctx.stroke();
    });
    if (p > 0.95) drawLeaders(ctx, cx, cy, R, squash, data, colors, total, t, W, H, true, full);
    return;
  }

  /* ============ CALENDAR PIE — one mini pie per day (echarts calendar-pie) ============ */
  if (kind === 'calendarpie') {
    const days = d.days || [];
    const names = series.map((x) => x.name);
    if (!days.length || !names.length) return;
    const dates = days.map((x) => new Date(x.date + 'T00:00:00'));
    const first = new Date(Math.min(...dates.map((x) => x.getTime())));
    const monthStart = new Date(first.getFullYear(), first.getMonth(), 1);
    const monthEnd = new Date(first.getFullYear(), first.getMonth() + 1, 0);
    const byDay = new Map(days.map((x) => [x.date, x.values]));
    const padL = 12, padR = 12, padT = 34, padB = 10;
    const cols = 7;
    const leadBlank = (monthStart.getDay() + 6) % 7; // Monday-first grid, like the reference
    const rows = Math.ceil((leadBlank + monthEnd.getDate()) / cols);
    const cell = Math.min((W - padL - padR) / cols, (H - padT - padB) / rows);
    const gx = padL + ((W - padL - padR) - cell * cols) / 2, gy = padT + ((H - padT - padB) - cell * rows) / 2;
    const r = cell * 0.36;
    ctx.font = font(t, 700, Math.min(11, Math.max(8.5, cell * 0.16)));
    ctx.fillStyle = t.ink; ctx.textAlign = 'left';
    ctx.fillText(monthStart.toLocaleDateString('en', { month: 'long', year: 'numeric' }), padL, 18);
    ctx.font = font(t, 700, Math.min(10, Math.max(8, cell * 0.14))); ctx.fillStyle = t.axis; ctx.textAlign = 'center';
    ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].forEach((wd, i) => ctx.fillText(wd, gx + cell * i + cell / 2, gy - 6));
    // grid cells
    for (let dnum = 1; dnum <= monthEnd.getDate(); dnum++) {
      const idx = leadBlank + dnum - 1, c = idx % cols, rw = Math.floor(idx / cols);
      const x0 = gx + c * cell, y0 = gy + rw * cell;
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.rect(x0 + 0.5, y0 + 0.5, cell - 1, cell - 1); ctx.stroke();
      const iso = `${monthStart.getFullYear()}-${String(monthStart.getMonth() + 1).padStart(2, '0')}-${String(dnum).padStart(2, '0')}`;
      const vals = byDay.get(iso);
      ctx.font = font(t, 700, Math.min(10, Math.max(7.5, cell * 0.14))); ctx.fillStyle = vals ? t.ink : t.axis; ctx.textAlign = 'left';
      ctx.fillText(String(dnum), x0 + 4, y0 + Math.min(12, cell * 0.18));
      if (!vals) continue;
      const tot = vals.reduce((a2, b) => a2 + b, 0) || 1;
      const cx0 = x0 + cell / 2, cy0 = y0 + cell / 2 + cell * 0.05;
      const on = hov.seg && hov.seg.c === dnum;
      let a = -Math.PI / 2;
      vals.forEach((v, si) => {
        if (v <= 0) return;
        const a1 = a + (v / tot) * Math.PI * 2 * p;
        const hi = on && hov.seg!.s === si;
        const rr = r * (hi ? 1 + 0.1 * hov.amt : 1);
        ctx.fillStyle = hi ? shade(sColors[si], 1.12) : sColors[si];
        ctx.beginPath(); ctx.moveTo(cx0, cy0); ctx.arc(cx0, cy0, rr, a, a1); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = d.bg || t.surface || '#fff'; ctx.lineWidth = 1.2; ctx.stroke();
        // value labels inside slices when there is room
        if (cell >= 64 && v / tot >= 0.12 && p > 0.95) {
          const mid = (a + a1) / 2;
          ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
          ctx.font = font(t, 700, Math.max(7.5, Math.min(10, r * 0.28)));
          ctx.fillText(fmtNum(v), cx0 + Math.cos(mid) * rr * 0.62, cy0 + Math.sin(mid) * rr * 0.62 + 3);
        }
        a = a1;
      });
    }
    ctx.textAlign = 'left';
    return;
  }

  /* ============ SANKEY — flows between nodes, left → right ============ */
  if (kind === 'sankey') {
    const links = (d.links || []).filter((l) => l.value > 0 && l.source !== l.target);
    if (!links.length) return;
    const lay = sankeyLayout(links, W, H, full ? 200 : Math.min(150, W * 0.22));
    if (!lay) return;
    const { nodes, flows, nodeW, cols } = lay;
    const maxCol = Math.max(1, cols - 1);

    // Sequential left-to-right sweep:
    // 1. Draw nodes per column
    // 2. Flow ribbons sweep outward from left to right along their path vectors
    flows.forEach((f) => {
      const src = nodes[f.si], tgt = nodes[f.ti];
      const on = hov.idx === null || hov.idx === f.si || hov.idx === f.ti;
      const x0 = src.x + nodeW, x1 = tgt.x;
      const c1 = x0 + (x1 - x0) * 0.5, c2 = x1 - (x1 - x0) * 0.5;
      const yA0 = f.sy0, yA1 = f.sy1, yB0 = f.ty0, yB1 = f.ty1;

      // Sequential progress: left ribbons begin early, right ribbons follow
      const pStart = 0.15 + (src.col / maxCol) * 0.45;
      const pEnd = Math.min(1, pStart + 0.38);
      const fp = clamp01((p - pStart) / (pEnd - pStart));
      if (fp <= 0.001) return;

      const grad = ctx.createLinearGradient(x0, 0, x1, 0);
      grad.addColorStop(0, rgba(src.color, on ? 0.6 : 0.15));
      grad.addColorStop(1, rgba(tgt.color, on ? 0.6 : 0.15));
      ctx.fillStyle = grad;

      ctx.save();
      // Sweep outward along path vectors
      if (fp < 0.999) {
        const sweepX = x0 + (x1 - x0) * fp;
        ctx.beginPath();
        ctx.rect(0, 0, sweepX, H);
        ctx.clip();
      }
      ctx.beginPath();
      ctx.moveTo(x0, yA0);
      ctx.bezierCurveTo(c1, yA0, c2, yB0, x1, yB0);
      ctx.lineTo(x1, yB1);
      ctx.bezierCurveTo(c2, yB1, c1, yA1, x0, yA1);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    });

    // Draw nodes sequentially from left to right
    nodes.forEach((n, i) => {
      const colP = n.col / maxCol;
      const np = clamp01((p - colP * 0.25) / 0.32);
      if (np <= 0.001) return;
      const on = hov.idx === i;
      ctx.fillStyle = on ? shade(n.color, 1.15) : n.color;
      const nh = Math.max(2, n.h * np);
      const ny = n.y + (n.h - nh) / 2;
      ctx.beginPath();
      ctx.roundRect(n.x, ny, nodeW, nh, 3);
      ctx.fill();

      // Labels appear as node materializes
      if (np > 0.65) {
        const lx = n.x + nodeW + 8;
        ctx.textAlign = 'left';
        const avail = n.col < lay.cols - 1 ? (lay.colX[n.col + 1] ?? W) - lx - 10 : W - lx - 6;
        const one = `${n.name} · ${fmtNum(n.value)}`;
        ctx.font = font(t, 600, 11);
        if (full || measureW(ctx, one) <= avail) {
          ctx.fillStyle = t.ink;
          ctx.fillText(one, lx, n.y + n.h / 2 + 3.5);
        } else {
          ctx.fillStyle = t.ink;
          ctx.fillText(fitCtx(ctx, n.name, Math.max(30, avail)), lx, n.y + n.h / 2 - 2);
          ctx.font = font(t, 600, 9.5);
          ctx.fillStyle = t.axis;
          ctx.fillText(fmtNum(n.value), lx, n.y + n.h / 2 + 9);
        }
      }
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ RADIAL BAR (2D ⇄ 3D) ============ */
  if (kind === 'radialbar') {
    const rg = radialGeom(W, H, data, full);
    const max = Math.max(...data.map((x) => x.value), 1);
    const squash = 1 - 0.44 * m;
    const depth = 14 * m;
    const cx = rg.cx;
    const cy = rg.cy - depth * 0.35;

    ctx.font = font(t, 600, Math.min(11, Math.max(9, rg.thick * 0.8)));

    // Ground shadow aligned precisely under the rings' true outer footprint
    if (m > 0.05) {
      ctx.save();
      setShadow(ctx, 0, 8, 20, rgba(t.ink, 0.22 * m));
      ctx.fillStyle = t.surface || '#e4e7e0';
      const outerR = rg.radiusOf(0) + rg.thick * 0.5 + 4;
      ctx.beginPath();
      ctx.ellipse(cx, cy + depth, outerR, outerR * squash, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    data.forEach((x, i) => {
      const r = rg.radiusOf(i);
      if (r <= rg.thick / 2) return;
      const on = hov.idx === i;
      const col = colors[i];
      // Arc length strictly proportional to underlying value
      const sweep = Math.min(Math.PI * 2 * 0.985, (x.value / max) * Math.PI * 2 * 0.985 * p);

      // 3D Extrusion Wall with uniform depth
      if (m > 0.05) {
        ctx.lineWidth = rg.thick;
        ctx.strokeStyle = shade(col, 0.65);
        ctx.beginPath();
        ctx.ellipse(cx, cy + depth, r, r * squash, 0, -Math.PI / 2, -Math.PI / 2 + Math.max(0.01, sweep));
        ctx.stroke();
      }

      // Background track sharing the exact same concentric center
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = rg.thick;
      ctx.beginPath();
      ctx.ellipse(cx, cy, r, r * squash, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Top value arc
      ctx.strokeStyle = on ? shade(col, 1 + 0.18 * hov.amt) : col;
      ctx.lineWidth = rg.thick - (on ? 0 : 1);
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.ellipse(cx, cy, r, r * squash, 0, -Math.PI / 2, -Math.PI / 2 + Math.max(0.01, sweep));
      ctx.stroke();
      ctx.lineCap = 'butt';

      // Top specular bevel highlight in 3D
      if (m > 0.1) {
        ctx.strokeStyle = `rgba(255, 255, 255, ${(0.45 * m).toFixed(2)})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.ellipse(cx, cy - 1, r + rg.thick * 0.45, (r + rg.thick * 0.45) * squash, 0, -Math.PI / 2, -Math.PI / 2 + Math.max(0.01, sweep));
        ctx.stroke();
      }

      // Label + value at the ring start (12 o'clock)
      if (rg.thick >= 8 || full) {
        const text = `${x.label} · ${fmtNum(x.value)}`;
        const avail = full ? Infinity : cx - 14;
        const shown = fitCtx(ctx, text, avail);
        const tw = measureW(ctx, shown);
        const tx = cx - 14, ty = cy - r * squash + 4;
        ctx.fillStyle = rgba(d.bg || t.surface || '#ffffff', 0.88);
        ctx.beginPath();
        ctx.roundRect(tx - tw - 6, ty - 10, tw + 12, 14, 7);
        ctx.fill();
        ctx.fillStyle = on ? t.ink : t.axis;
        ctx.textAlign = 'right';
        ctx.fillText(shown, tx, ty);
        // connector tick
        ctx.strokeStyle = col;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(tx + 3, cy - r * squash);
        ctx.lineTo(cx - 1, cy - r * squash);
        ctx.stroke();
      }
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ DUAL AXES — columns (left) + lines (right) (2D ⇄ 3D) ============ */
  if (kind === 'dual') {
    const labels = multi ? cats : data.map((x) => x.label);
    const colVals = multi ? cats.map((_, c) => series[0]?.values[c] || 0) : data.map((x) => x.value);
    const lines: { name: string; color: string; values: number[] }[] = multi
      ? series.slice(1).map((s, i) => ({ name: s.name, color: sColors[i + 1], values: s.values }))
      : [{
        name: 'Cumulative %',
        color: t.dark ? '#ffc857' : '#c9932b',
        values: (() => {
          let acc = 0;
          return data.map((x) => { acc += x.value; return Math.round((acc / total) * 100); });
        })(),
      }];

    const ox = 20 * m, oy = 15 * m; // 3D isometric offset
    const maxL = Math.max(...colVals, 1);
    const maxR = Math.max(...lines.flatMap((l) => l.values), 1);
    const L = xyLayout('bar', W, H, 0, labels, 1, maxL, !!d.yLabel, full);
    const pad = { ...L.pad, r: 12 + approxW(fmtNum(maxR), 10.5) + 14 + ox, t: L.pad.t + oy };
    const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
    const step = cw / Math.max(1, labels.length);

    // 3D Isometric floor grid
    if (m > 0.05) {
      ctx.strokeStyle = rgba(t.grid, 0.4);
      ctx.lineWidth = 1;
      for (let g = 0; g <= 4; g++) {
        const y = pad.t + ch - (ch * g) / 4;
        ctx.beginPath();
        ctx.moveTo(pad.l, y);
        ctx.lineTo(pad.l + ox, y - oy);
        ctx.lineTo(W - pad.r + ox, y - oy);
        ctx.stroke();
      }
    }

    drawAxes(ctx, W, H, pad, maxL, t, m > 0.05 ? ox : 0, m > 0.05 ? oy : 0);

    // Right Y-axis
    ctx.font = font(t, 600, 10.5); ctx.fillStyle = t.axis; ctx.textAlign = 'left';
    for (let g = 0; g <= 4; g++) {
      const y = pad.t + ch - (ch * g) / 4;
      ctx.fillText(fmtNum((maxR * g) / 4) + (multi ? '' : '%'), W - pad.r + (m > 0.05 ? ox : 0) + 7, (m > 0.05 ? y - oy : y) + 3.5);
    }
    ctx.strokeStyle = t.axis; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t - 4 - (m > 0.05 ? oy : 0)); ctx.lineTo(W - pad.r + (m > 0.05 ? ox : 0), pad.t + ch - (m > 0.05 ? oy : 0)); ctx.stroke(); ctx.lineWidth = 1;

    if (d.yLabel) {
      ctx.save(); ctx.translate(11, pad.t + ch / 2); ctx.rotate(-Math.PI / 2);
      ctx.textAlign = 'center'; ctx.fillStyle = t.axis; ctx.fillText(d.yLabel, 0, 0); ctx.restore();
    }
    drawXLabels(ctx, labels, planX(labels, step, full), (i) => pad.l + step * i + step / 2, pad.t + ch, t, W);

    // 3D Columns
    labels.forEach((_, ci) => {
      const bw = Math.min(36, step * 0.5);
      const x = pad.l + step * ci + (step - bw) / 2;
      const h = (colVals[ci] / maxL) * ch * p;
      const yTop = pad.t + ch - h;
      const yBase = pad.t + ch;
      const on = multi ? !!(hov.seg && (hov.seg.c === ci || hov.seg.c === -1) && hov.seg.s === 0) : hov.idx === ci;
      const col = multi ? sColors[0] : colors[ci];
      const cFill = on ? shade(col, 1 + 0.16 * hov.amt) : col;

      if (m > 0.05 && h > 1) {
        // 3D Top face
        ctx.fillStyle = shade(cFill, 1.25);
        ctx.beginPath();
        ctx.moveTo(x, yTop);
        ctx.lineTo(x + ox, yTop - oy);
        ctx.lineTo(x + bw + ox, yTop - oy);
        ctx.lineTo(x + bw, yTop);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 1; ctx.stroke();

        // 3D Right face
        ctx.fillStyle = shade(cFill, 0.68);
        ctx.beginPath();
        ctx.moveTo(x + bw, yTop);
        ctx.lineTo(x + bw + ox, yTop - oy);
        ctx.lineTo(x + bw + ox, yBase - oy);
        ctx.lineTo(x + bw, yBase);
        ctx.closePath();
        ctx.fill();
      }

      // Front face
      ctx.fillStyle = cFill;
      ctx.beginPath(); ctx.roundRect(x, yTop, bw, Math.max(1, h), m > 0.05 ? 0 : [5, 5, 0, 0]); ctx.fill();
    });

    // Lines on the right axis
    lines.forEach((ln, li) => {
      const pts = ln.values.map((v, i) => ({
        x: pad.l + step * i + step / 2 + (m > 0.05 ? ox * 0.5 : 0),
        y: pad.t + ch - (v / maxR) * ch * p - (m > 0.05 ? oy * 0.5 : 0),
      }));
      if (!pts.length) return;

      // 3D Shadow ribbon
      if (m > 0.05) {
        ctx.strokeStyle = rgba(t.ink, 0.15);
        ctx.lineWidth = 3;
        ctx.beginPath();
        pts.forEach((pt, i) => {
          if (i === 0) ctx.moveTo(pt.x, pt.y + oy * 0.5);
          else ctx.lineTo(pt.x, pt.y + oy * 0.5);
        });
        ctx.stroke();
      }

      ctx.strokeStyle = ln.color; ctx.lineWidth = 2.5; ctx.lineJoin = 'round';
      ctx.beginPath();
      pts.forEach((pt, i) => {
        if (i === 0) { ctx.moveTo(pt.x, pt.y); return; }
        const p0 = pts[Math.max(0, i - 2)], p1 = pts[i - 1], p2 = pt, p3 = pts[Math.min(pts.length - 1, i + 1)];
        ctx.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y - (p3.y - p1.y) / 6, p2.x, p2.y);
      });
      ctx.stroke();

      const dense = step < 14;
      pts.forEach((pt, i) => {
        const on = multi ? !!(hov.seg && (hov.seg.c === i || hov.seg.c === -1) && hov.seg.s === li + 1) : hov.idx === i;
        if (dense && !on) return;
        const rad = (step < 26 ? 3.5 : 4.5) + (on ? 2 * hov.amt : 0);
        if (m > 0.05) {
          const g = ctx.createRadialGradient(pt.x - 1.5, pt.y - 1.5, 1, pt.x, pt.y, rad);
          g.addColorStop(0, shade(ln.color, 1.35));
          g.addColorStop(1, shade(ln.color, 0.75));
          ctx.fillStyle = g;
        } else {
          ctx.fillStyle = on ? shade(ln.color, 1.2) : ln.color;
        }
        ctx.beginPath(); ctx.arc(pt.x, pt.y, rad, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
      });
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ GANTT CHART ============ */
  if (kind === 'gantt') {
    const rawTasks: GanttTask[] = d.tasks && d.tasks.length ? d.tasks : (
      data.map((x, i) => ({
        id: i,
        name: x.label,
        start: i * 3,
        end: i * 3 + Math.max(3, Math.round(x.value / 8)),
        progress: 35 + ((i * 17) % 60),
        color: colors[i],
        category: 'Milestone',
      }))
    );
    const padL = Math.max(140, Math.min(240, W * 0.26));
    const padR = 28, padT = 40, padB = 30;
    const chartW = W - padL - padR;
    const chartH = H - padT - padB;
    const rowH = Math.min(42, Math.max(26, chartH / Math.max(1, rawTasks.length)));

    const starts = rawTasks.map((tk) => typeof tk.start === 'number' ? tk.start : new Date(tk.start).getTime());
    const ends = rawTasks.map((tk) => typeof tk.end === 'number' ? tk.end : new Date(tk.end).getTime());
    const minTime = Math.min(...starts);
    const maxTime = Math.max(...ends, minTime + 1);
    const timeSpan = maxTime - minTime || 1;

    // Time axis grid lines and headers
    const cols = 5;
    ctx.font = font(t, 600, 10);
    ctx.textAlign = 'center';
    for (let c = 0; c <= cols; c++) {
      const gx = padL + (chartW * c) / cols;
      ctx.strokeStyle = t.grid;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(gx, padT - 4);
      ctx.lineTo(gx, padT + rowH * rawTasks.length);
      ctx.stroke();
      ctx.setLineDash([]);
      const tVal = minTime + (timeSpan * c) / cols;
      const tLabel = typeof rawTasks[0].start === 'string'
        ? new Date(tVal).toLocaleDateString('en', { month: 'short', day: 'numeric' })
        : `Day ${Math.round(tVal)}`;
      ctx.fillStyle = t.axis;
      ctx.fillText(tLabel, gx, padT - 12);
    }
    ctx.textAlign = 'left';

    rawTasks.forEach((task, i) => {
      const tStart = typeof task.start === 'number' ? task.start : new Date(task.start).getTime();
      const tEnd = typeof task.end === 'number' ? task.end : new Date(task.end).getTime();
      const sx = padL + ((tStart - minTime) / timeSpan) * chartW;
      const ex = padL + ((tEnd - minTime) / timeSpan) * chartW;
      const barW = Math.max(8, ex - sx);
      const ry = padT + i * rowH;
      const barH = Math.max(14, rowH - 12);
      const by = ry + (rowH - barH) / 2;
      const on = hov.idx === i;
      const col = task.color || colors[i % colors.length] || '#0d7a54';

      if (on) {
        ctx.fillStyle = rgba(t.ink, 0.05);
        ctx.beginPath(); ctx.roundRect(8, ry + 1, W - 16, rowH - 2, 6); ctx.fill();
      }

      ctx.font = font(t, 600, 11);
      ctx.fillStyle = on ? t.ink : shade(t.ink, 0.85);
      ctx.textAlign = 'left';
      ctx.fillText(fitCtx(ctx, task.name, padL - 24), 16, by + barH * 0.65);

      ctx.fillStyle = rgba(col, 0.2);
      ctx.beginPath(); ctx.roundRect(sx, by, barW, barH, 6); ctx.fill();

      const prg = Math.min(100, Math.max(0, task.progress ?? 100)) / 100;
      const pw = Math.max(4, barW * prg * p);
      ctx.fillStyle = on ? shade(col, 1.15) : col;
      ctx.beginPath(); ctx.roundRect(sx, by, pw, barH, 6); ctx.fill();

      ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.beginPath(); ctx.roundRect(sx, by, pw, barH / 2, [6, 6, 0, 0]); ctx.fill();

      if (barW > 35) {
        ctx.fillStyle = '#ffffff'; ctx.font = font(t, 700, 9.5); ctx.textAlign = 'center';
        ctx.fillText(`${Math.round(prg * 100)}%`, sx + pw / 2, by + barH * 0.7);
      }
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ SCATTER PLOT ============ */
  if (kind === 'scatter') {
    const rawScatter: ScatterPoint[] = d.scatter && d.scatter.length ? d.scatter : (
      data.map((x, i) => ({
        x: 20 + i * 8 + ((i * 13) % 19),
        y: x.value,
        label: x.label,
        size: 7 + ((i * 3) % 5),
        color: colors[i % colors.length],
      }))
    );

    const padL = 52, padR = 24, padT = 34, padB = 40;
    const plotW = W - padL - padR, plotH = H - padT - padB;
    const xs = rawScatter.map((pt) => pt.x);
    const ys = rawScatter.map((pt) => pt.y);
    const minX = Math.min(...xs, 0), maxX = Math.max(...xs, minX + 1);
    const minY = Math.min(...ys, 0), maxY = Math.max(...ys, minY + 1);

    drawAxes(ctx, W, H, { l: padL, r: padR, t: padT, b: padB }, maxY, t);

    const xSteps = 5;
    ctx.font = font(t, 600, 10.5); ctx.textAlign = 'center';
    for (let s = 0; s <= xSteps; s++) {
      const val = minX + ((maxX - minX) * s) / xSteps;
      const gx = padL + (plotW * s) / xSteps;
      ctx.strokeStyle = t.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(gx, padT); ctx.lineTo(gx, padT + plotH); ctx.stroke();
      ctx.fillStyle = t.axis; ctx.fillText(fmtNum(val), gx, padT + plotH + 18);
    }
    ctx.textAlign = 'left';

    // Linear regression trendline
    if (rawScatter.length >= 2) {
      const n = rawScatter.length;
      const sumX = xs.reduce((a, b) => a + b, 0), sumY = ys.reduce((a, b) => a + b, 0);
      const sumXY = rawScatter.reduce((a, pt) => a + pt.x * pt.y, 0);
      const sumX2 = xs.reduce((a, b) => a + b * b, 0);
      const slope = (n * sumXY - sumX * sumY) / Math.max(1e-6, n * sumX2 - sumX * sumX);
      const intercept = (sumY - slope * sumX) / n;
      const px0 = padL, py0 = padT + plotH - ((intercept + slope * minX - minY) / (maxY - minY)) * plotH;
      const px1 = padL + plotW, py1 = padT + plotH - ((intercept + slope * maxX - minY) / (maxY - minY)) * plotH;
      ctx.strokeStyle = rgba(t.axis, 0.4); ctx.lineWidth = 1.5; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(px0, py0); ctx.lineTo(px1, py1); ctx.stroke();
      ctx.setLineDash([]);
    }

    rawScatter.forEach((pt, i) => {
      const px = padL + ((pt.x - minX) / (maxX - minX)) * plotW;
      const py = padT + plotH - ((pt.y - minY) / (maxY - minY)) * plotH;
      const baseR = pt.size || 7;
      const rad = Math.max(1.5, baseR * Math.max(0.05, p));
      const on = hov.idx === i;
      const col = pt.color || colors[i % colors.length] || '#0d7a54';

      if (on) {
        ctx.strokeStyle = rgba(col, 0.5); ctx.lineWidth = 1; ctx.setLineDash([2, 2]);
        ctx.beginPath(); ctx.moveTo(padL, py); ctx.lineTo(padL + plotW, py); ctx.moveTo(px, padT); ctx.lineTo(px, padT + plotH); ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = rgba(col, 0.2); ctx.beginPath(); ctx.arc(px, py, rad + 6, 0, Math.PI * 2); ctx.fill();
      }

      const r0 = Math.max(0.1, rad * 0.15);
      const g = ctx.createRadialGradient(px - rad * 0.3, py - rad * 0.3, r0, px, py, rad);
      g.addColorStop(0, shade(col, 1.35)); g.addColorStop(1, shade(col, 0.85));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, on ? rad + 2 : rad, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1; ctx.stroke();
    });
    return;
  }

  /* ============ FUNNEL / PYRAMID (2D + 3D) ============ */
  if (kind === 'funnel' || kind === 'pyramid') {
    const g = funnelGeom(W, H, m, data, full, kind === 'pyramid');
    const { ch, plotW, sq, topY, cx, laneX } = g;
    const heights = data.map((x) => (x.value / total) * ch * p);
    const sumH = heights.reduce((a, b) => a + b, 0);
    const widthAt = (rel: number) => kind === 'funnel'
      ? plotW * (0.96 - 0.66 * (rel / ch))
      : plotW * (0.96 * (rel / ch)); // pyramid: true point at the top
    ctx.font = font(t, 600, 10.5);
    // label rows: pushed apart so thin segments never overlap, then pulled
    // back inside the plot from the bottom
    const rows: number[] = [];
    { let yy = topY + (ch - sumH); heights.forEach((h) => { rows.push(yy + h / 2); yy += h; }); }
    const PITCH = 14;
    for (let i = 1; i < rows.length; i++) rows[i] = Math.max(rows[i], rows[i - 1] + PITCH);
    const floor = Math.min(H - 8, topY + ch + 18);
    for (let i = rows.length - 1; i >= 0; i--) rows[i] = Math.min(rows[i], i === rows.length - 1 ? floor : rows[i + 1] - PITCH);
    let y = topY + (ch - sumH);
    data.forEach((x, i) => {
      const h = heights[i];
      const rel0 = y - topY;
      const w0 = widthAt(rel0), w1 = widthAt(rel0 + h);
      const on = hov.idx === i;
      const col = on ? shade(colors[i], 1 + 0.12 * hov.amt) : colors[i];
      if (kind === 'funnel' && m > 0.02) {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.ellipse(cx, y + h, Math.max(0.1, w1 / 2), Math.max(0.1, (w1 / 2) * sq), 0, Math.PI, 0, true);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.ellipse(cx, y, Math.max(0.1, w0 / 2), Math.max(0.1, (w0 / 2) * sq), 0, 0, Math.PI, false);
        ctx.closePath(); ctx.fill();
        if (i === 0) {
          ctx.fillStyle = shade(colors[i], 1.22);
          ctx.beginPath(); ctx.ellipse(cx, y, Math.max(0.1, w0 / 2), Math.max(0.1, (w0 / 2) * sq), 0, 0, Math.PI * 2); ctx.fill();
        }
      } else if (kind === 'pyramid' && m > 0.005) {
        // side face grows with the morph — no jump at the 2D/3D boundary
        const dxr = (w: number) => w * 0.2 * m, dyr = (w: number) => w * 0.075 * m;
        ctx.fillStyle = shade(colors[i], 0.72);
        ctx.beginPath();
        ctx.moveTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w0 / 2 + dxr(w0), y - dyr(w0));
        ctx.lineTo(cx + w1 / 2 + dxr(w1), y + h - dyr(w1));
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        if (m < 0.98) { ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke(); }
      } else {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx - w0 / 2, y);
        ctx.lineTo(cx + w0 / 2, y);
        ctx.lineTo(cx + w1 / 2, y + h);
        ctx.lineTo(cx - w1 / 2, y + h);
        ctx.closePath(); ctx.fill();
        if (m < 0.98) { ctx.strokeStyle = `rgba(255,255,255,${(0.5 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke(); }
      }
      // leader — attached at the segment's true mid-width edge, head fully outside
      const midY = y + h / 2;
      const rowY = rows[i];
      const wMid = widthAt(rel0 + h / 2);
      // anchor on the shape's true silhouette: the front edge in 2D, the side face's
      // outer edge in 3D (blended through the morph). The head is entirely outside it.
      const edgeX = cx + wMid / 2 + (kind === 'pyramid' ? wMid * 0.2 * m : 0);
      const edgeY = midY - (kind === 'pyramid' ? wMid * 0.075 * m : 0);
      // every leader turns in one shared vertical lane just right of the widest
      // part of the shape (incl. the 3D side face), then runs to its label row
      const textX = laneX + 16;
      // arrowhead scales with the segment but never below a legible 2.2px half-height
      const ah = Math.min(3.8, Math.max(2.2, h / 2 - 0.5)), al = Math.max(4.5, ah * 2);
      ctx.strokeStyle = colors[i];
      ctx.lineWidth = 1.3;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(edgeX + al, edgeY);
      if (Math.abs(rowY - edgeY) > 0.5) { ctx.lineTo(Math.max(edgeX + al + 4, laneX - 6), edgeY); ctx.lineTo(laneX, rowY); }
      ctx.lineTo(textX - 6, rowY);
      ctx.stroke();
      ctx.lineJoin = 'miter';
      ctx.fillStyle = colors[i];
      ctx.beginPath();
      ctx.moveTo(edgeX + 0.5, edgeY);
      ctx.lineTo(edgeX + al + 0.5, edgeY - ah);
      ctx.lineTo(edgeX + al + 0.5, edgeY + ah);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 0.8; ctx.stroke();
      ctx.fillStyle = t.ink;
      ctx.textAlign = 'left';
      const text = funnelLabel(x, total);
      ctx.fillText(full ? text : fitCtx(ctx, text, W - textX - 4), textX, rowY + 3.5);
      y += h;
    });
    ctx.textAlign = 'left';
    return;
  }

  /* ============ PIE / DONUT (2D ⇄ 3D morph) ============ */
  const g = circGeom(W, H, m, data, full);
  const { cx, cy, R: R0, depth, squash } = g;
  const rIn = kind === 'donut' ? R0 * g.rInRatio : 0;

  interface Seg { a0: number; a1: number; i: number }
  let a = -Math.PI / 2;
  const segs: Seg[] = data.map((x, i) => {
    const a1 = a + (x.value / total) * Math.PI * 2 * p;
    const s = { a0: a, a1, i };
    a = a1;
    return s;
  });
  // hover: the slice pops radially outward along its true angle vector from the center
  const hovAmt = (s: Seg) => (hov.idx === s.i ? hov.amt : 0);
  const pullOf = (s: Seg) => 14 * hovAmt(s);                 // radial pop along the bisector angle
  const px = (ang: number, r: number) => cx + Math.cos(ang) * r;
  const py = (ang: number, r: number) => cy + Math.sin(ang) * r * squash;
  const OVER = 0.012;
  // per-slice translation (dx, dy) in screen space: pure radial along angle vector
  const offsetOf = (s: Seg): [number, number] => {
    const a = hovAmt(s);
    if (!a) return [0, 0];
    const mid = (s.a0 + s.a1) / 2, pull = pullOf(s);
    return [Math.cos(mid) * pull, Math.sin(mid) * pull * squash];
  };

  // soft ground shadow (live only) — replaces the CSS drop-shadow filter that
  // made large-canvas morphs stutter; fades out as the chart extrudes
  if (!d.bg && m < 0.999 && p > 0.05) {
    ctx.save();
    setShadow(ctx, 0, 7, 16, rgba(t.ink, 0.2 * (1 - m)));
    ctx.fillStyle = t.surface || '#e4e7e0';
    ctx.beginPath(); ctx.ellipse(cx, cy + depth, R0 + 1, (R0 + 1) * squash, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  /** Draw one slice's 3D body (outer rim, inner rim, cut faces) depth-sorted. */
  // exports (vector recorder) get ONE arc-bounded band per slice with a gradient
  // instead of dozens of shaded strips — same look, a fraction of the file size
  const vector = !!d.bg;
  const drawBody = (s: Seg, dx: number, dy: number) => {
    const faces: { y: number; draw: () => void }[] = [];
    const Rx = R0;
    const col = hov.idx === s.i ? shade(colors[s.i], 1 + 0.08 * hov.amt) : colors[s.i];
    if (vector) {
      const vis0 = Math.max(s.a0, 0), vis1 = Math.min(s.a1, Math.PI); // front half only
      if (vis1 > vis0 + 1e-4) {
        faces.push({
          y: py((vis0 + vis1) / 2, Rx),
          draw: () => {
            const g = ctx.createLinearGradient(px(vis0, Rx) + dx, 0, px(vis1, Rx) + dx, 0);
            g.addColorStop(0, shade(col, 0.62 + 0.2 * Math.cos(vis0)));
            g.addColorStop(1, shade(col, 0.62 + 0.2 * Math.cos(vis1)));
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, vis0, vis1, false);
            ctx.ellipse(cx + dx, cy + dy + depth, Rx, Rx * squash, 0, vis1, vis0, true);
            ctx.closePath(); ctx.fill();
          },
        });
      }
      if (rIn > 0) {
        const b0 = Math.max(s.a0, Math.PI), b1 = Math.min(s.a1, Math.PI * 2); // inner wall visible at the back
        const c0 = Math.max(s.a0, -Math.PI), c1 = Math.min(s.a1, 0);
        [[b0, b1], [c0, c1]].forEach(([q0, q1]) => {
          if (q1 <= q0 + 1e-4) return;
          faces.push({
            y: py((q0 + q1) / 2, rIn) - 900,
            draw: () => {
              ctx.fillStyle = shade(colors[s.i], 0.52);
              ctx.beginPath();
              ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, q0, q1, false);
              ctx.ellipse(cx + dx, cy + dy + depth, rIn, rIn * squash, 0, q1, q0, true);
              ctx.closePath(); ctx.fill();
            },
          });
        });
      }
      ([s.a0, s.a1] as const).forEach((edge) => {
        faces.push({
          y: py(edge, (Rx + rIn) / 2) - 0.25,
          draw: () => {
            ctx.fillStyle = shade(colors[s.i], 0.72);
            ctx.beginPath();
            if (rIn > 0) {
              ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy); ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy); ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
            } else {
              ctx.moveTo(cx + dx, cy + dy); ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
              ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy); ctx.lineTo(cx + dx, cy + depth + dy);
            }
            ctx.closePath(); ctx.fill();
          },
        });
      });
      return faces;
    }
    const steps = Math.max(3, Math.min(72, Math.ceil(((s.a1 - s.a0) * Rx) / 7)));
    for (let k = 0; k < steps; k++) {
      const b0 = s.a0 + ((s.a1 - s.a0) * k) / steps - OVER;
      const b1 = s.a0 + ((s.a1 - s.a0) * (k + 1)) / steps + OVER;
      const midS = (b0 + b1) / 2;
      if (Math.sin(midS) <= 0) continue;
      faces.push({
        y: py(midS, Rx),
        draw: () => {
          ctx.fillStyle = shade(col, 0.62 + 0.2 * Math.cos(midS));
          ctx.beginPath();
          ctx.moveTo(px(b0, Rx) + dx, py(b0, Rx) + dy);
          ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + dy);
          ctx.lineTo(px(b1, Rx) + dx, py(b1, Rx) + depth + dy);
          ctx.lineTo(px(b0, Rx) + dx, py(b0, Rx) + depth + dy);
          ctx.closePath(); ctx.fill();
        },
      });
    }
    if (rIn > 0) {
      const inner = Math.max(3, Math.min(48, Math.ceil(((s.a1 - s.a0) * rIn) / 7)));
      for (let k = 0; k < inner; k++) {
        const b0 = s.a0 + ((s.a1 - s.a0) * k) / inner - OVER;
        const b1 = s.a0 + ((s.a1 - s.a0) * (k + 1)) / inner + OVER;
        const midS = (b0 + b1) / 2;
        const back = Math.sin(midS) < 0;
        faces.push({
          y: back ? py(midS, rIn) - 900 : py(midS, rIn) - 0.5,
          draw: () => {
            ctx.fillStyle = shade(colors[s.i], back ? 0.52 : 0.44);
            ctx.beginPath();
            ctx.moveTo(px(b0, rIn) + dx, py(b0, rIn) + dy);
            ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + dy);
            ctx.lineTo(px(b1, rIn) + dx, py(b1, rIn) + depth + dy);
            ctx.lineTo(px(b0, rIn) + dx, py(b0, rIn) + depth + dy);
            ctx.closePath(); ctx.fill();
          },
        });
      }
    }
    ([s.a0, s.a1] as const).forEach((edge) => {
      faces.push({
        y: py(edge, (Rx + rIn) / 2) - 0.25,
        draw: () => {
          ctx.fillStyle = shade(colors[s.i], 0.88);
          ctx.beginPath();
          if (rIn > 0) {
            ctx.moveTo(px(edge, rIn) + dx, py(edge, rIn) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
            ctx.lineTo(px(edge, rIn) + dx, py(edge, rIn) + depth + dy);
          } else {
            ctx.moveTo(cx + dx, cy + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + dy);
            ctx.lineTo(px(edge, Rx) + dx, py(edge, Rx) + depth + dy);
            ctx.lineTo(cx + dx, cy + depth + dy);
          }
          ctx.closePath(); ctx.fill();
        },
      });
    });
    return faces;
  };
  /** Draw one slice's top face. */
  const drawTop = (s: Seg, dx: number, dy: number) => {
    const Rx = R0;
    const on = hov.idx === s.i;
    ctx.fillStyle = on ? shade(colors[s.i], 1.05) : colors[s.i];
    ctx.beginPath();
    const o = OVER * clamp01(m * 8);
    ctx.ellipse(cx + dx, cy + dy, Rx, Rx * squash, 0, s.a0 - o, s.a1 + o, false);
    if (rIn > 0) ctx.ellipse(cx + dx, cy + dy, rIn, rIn * squash, 0, s.a1 + o, s.a0 - o, true);
    else ctx.lineTo(cx + dx, cy + dy);
    ctx.closePath(); ctx.fill();
    if (m < 0.98) {
      ctx.strokeStyle = `rgba(255,255,255,${(0.55 * (1 - m)).toFixed(3)})`; ctx.lineWidth = 1; ctx.stroke();
    }
  };

  // Render order: non-hovered slices dim slightly to let active segment stand out
  const rest = segs.filter((s) => hov.idx !== s.i || hov.amt < 0.01);
  const lifted = segs.filter((s) => hov.idx === s.i && hov.amt >= 0.01);
  if (m > 0.005) {
    const faces = rest.flatMap((s) => drawBody(s, 0, 0));
    faces.sort((f1, f2) => f1.y - f2.y).forEach((f) => {
      ctx.save();
      if (hov.idx !== null) ctx.globalAlpha = 1 - 0.28 * hov.amt;
      f.draw();
      ctx.restore();
    });
  }
  rest.forEach((s) => {
    ctx.save();
    if (hov.idx !== null) ctx.globalAlpha = 1 - 0.28 * hov.amt;
    drawTop(s, 0, 0);
    ctx.restore();
  });
  lifted.forEach((s) => {
    const [dx, dy] = offsetOf(s);
    if (m > 0.005) drawBody(s, dx, dy).sort((f1, f2) => f1.y - f2.y).forEach((f) => f.draw());
    drawTop(s, dx, dy);
  });

  if (p > 0.95) drawLeaders(ctx, cx, cy, R0, squash, data, colors, total, t, W, H, false, full);
  if (kind === 'donut' && m < 0.5) {
    ctx.save();
    ctx.globalAlpha = clamp01(1 - m * 2);
    ctx.fillStyle = t.ink;
    ctx.font = font(t, 700, 16, true);
    ctx.textAlign = 'center';
    ctx.fillText(String(total), cx, cy + 5);
    ctx.restore();
    ctx.textAlign = 'left';
  }
}

/* ================= export composition ================= */
interface LegendItem { label: string; color: string }
function legendLayout(meas: (s: string) => number, items: LegendItem[], W: number) {
  const padX = 14, gap = 18, dot = 13, rowH = 17;
  const rows: { x: number; y: number; it: LegendItem }[] = [];
  let x = padX, row = 0;
  items.forEach((it) => {
    const w = dot + meas(it.label);
    if (x + w > W - padX && x > padX) { x = padX; row++; }
    rows.push({ x, y: row * rowH, it });
    x += w + gap;
  });
  return { rows, height: items.length ? (row + 1) * rowH + 12 : 6 };
}
function scratchCtx(): Ctx { return document.createElement('canvas').getContext('2d')!; }

function drawComposition(ctx: Ctx, title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme, lay: ReturnType<typeof legendLayout>, headH: number) {
  if (title) {
    ctx.fillStyle = '#1c2620';
    let fs = 15;
    ctx.font = font(t, 700, fs, true);
    while (fs > 11 && measureW(ctx, title) > chartW - 24) { fs -= 1; ctx.font = font(t, 700, fs, true); }
    ctx.textAlign = 'left';
    ctx.fillText(fitCtx(ctx, title, chartW - 24), 12, 22);
  }
  ctx.save(); ctx.translate(0, headH);
  paintFn(ctx);
  ctx.restore();
  ctx.font = font(t, 600, 10.5);
  lay.rows.forEach(({ x, y, it }) => {
    const yy = headH + chartH + 14 + y;
    ctx.fillStyle = it.color;
    ctx.beginPath(); ctx.arc(x, yy - 3, 4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#39443d'; ctx.textAlign = 'left';
    ctx.fillText(it.label, x + 9, yy);
  });
}

/** PNG/PDF/Print bitmap — white background, theme fonts, full legend (wrapped, never truncated). */
export function composeExport(title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme = themeColors(true)): HTMLCanvasElement {
  const scale = 3;
  const sc = scratchCtx(); sc.font = font(t, 600, 10.5);
  const lay = legendLayout((s) => measureW(sc, s), legend, chartW);
  const headH = title ? 34 : 10;
  const W = chartW, H = headH + chartH + lay.height;
  const cv = document.createElement('canvas');
  cv.width = W * scale; cv.height = H * scale;
  const ctx = cv.getContext('2d')!;
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);
  drawComposition(ctx, title, chartW, chartH, legend, paintFn, t, lay, headH);
  return cv;
}

function composeSvg(title: string, chartW: number, chartH: number, legend: LegendItem[], paintFn: (ctx: Ctx) => void, t: Theme = themeColors(true), fontCss = ''): string {
  const sc = scratchCtx(); sc.font = font(t, 600, 10.5);
  const lay = legendLayout((s) => measureW(sc, s), legend, chartW);
  const headH = title ? 34 : 10;
  const rec = new SvgCtx(chartW, headH + chartH + lay.height);
  rec.fontCss = fontCss;
  drawComposition(rec as unknown as Ctx, title, chartW, chartH, legend, paintFn, t, lay, headH);
  return rec.toString();
}

/** Export canvas size — wide enough that every label is complete. */
export function exportDims(kind: ChartKind, W: number, H: number, data: ChartDatum[], multi: boolean, cats: string[], m = 0): { W: number; H: number } {
  let Wx = Math.max(W, 720), Hx = Math.max(H, 360);
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  if (kind === 'pie' || kind === 'donut' || kind === 'polar') {
    const longest = Math.max(0, ...data.map((x) => approxW(leaderLabel(x, total))));
    Wx = Math.max(Wx, 2 * (longest + 40) + 280);
    // height follows the disc the width allows (a squashed 3D disc needs less)
    const Rw = Wx / 2 - (longest + 40);
    const need = m > 0.5 ? 2 * Rw * K + 46 + 70 : 2 * Rw + 56;
    Hx = Math.max(m > 0.5 ? 250 : 300, Math.round(need), Math.min(720, data.length * 14 + 120));
  } else if (kind === 'funnel' || kind === 'pyramid') {
    const longest = Math.max(0, ...data.map((x) => approxW(funnelLabel(x, total))));
    Wx = Math.max(Wx, longest + 40 + 440);
    Hx = Math.max(Hx, 380);
  } else if (kind === 'radar') {
    const labels = multi ? cats : data.map((x) => x.label);
    Wx = Math.max(Wx, 2 * Math.max(0, ...labels.map((l) => approxW(l))) + 380);
    Hx = Math.max(Hx, 400);
  } else if (kind === 'radialbar') {
    const longest = Math.max(0, ...data.map((x) => approxW(x.label)));
    Wx = Math.max(Wx, longest + 26 + 420);
    Hx = Math.max(Hx, 380, Math.min(720, data.length * 26 + 60));
  } else {
    const labels = multi ? cats : data.map((x) => x.label);
    Wx = Math.max(Wx, 90 + labels.length * 16);
  }
  return { W: Math.round(Wx), H: Math.round(Hx) };
}

/* ================= main Chart ================= */
const BASE_KINDS: { key: ChartKind; label: string; has3d: boolean }[] = [
  { key: 'bar', label: 'Bar', has3d: true },
  { key: 'line', label: 'Line', has3d: false }, // 3D line intentionally disabled
  { key: 'area', label: 'Area', has3d: true },
  { key: 'pie', label: 'Pie', has3d: true },
  { key: 'donut', label: 'Donut', has3d: true },
  { key: 'radar', label: 'Radar', has3d: false },
  { key: 'polar', label: 'Polar', has3d: true },
  { key: 'radialbar', label: 'Radial Bar', has3d: true },
  { key: 'dual', label: 'Dual Axes', has3d: true },
];
const EXTRA_KINDS: { key: ChartKind; label: string; has3d: boolean }[] = [
  { key: 'funnel', label: 'Funnel', has3d: true },
  { key: 'pyramid', label: 'Pyramid', has3d: true },
  { key: 'calendarpie', label: 'Calendar pie', has3d: false },
  { key: 'sankey', label: 'Sankey', has3d: true },
  { key: 'gantt', label: 'Gantt', has3d: false },
  { key: 'scatter', label: 'Scatter', has3d: false },
];
const skeletonKind = (k: ChartKind): 'circle' | 'bars' | 'columns' | 'line' =>
  k === 'pie' || k === 'donut' || k === 'polar' || k === 'radar' || k === 'radialbar' || k === 'calendarpie' ? 'circle' : k === 'line' || k === 'area' || k === 'sankey' || k === 'scatter' ? 'line' : k === 'funnel' || k === 'pyramid' || k === 'gantt' ? 'bars' : 'columns';

export interface ChartProps {
  data?: ChartDatum[];
  categories?: string[];
  series?: StackedSeries[];
  title?: string;
  defaultKind?: ChartKind;
  defaultDim?: '2d' | '3d';
  height?: number;
  loading?: boolean;
  extraKinds?: ('funnel' | 'pyramid' | 'gantt' | 'scatter')[];
  yLabel?: string;
  insight?: string[];
  isFullscreen?: boolean;
  /** calendar-pie: per-day values, one entry per `series` */
  days?: CalendarDay[];
  /** sankey: weighted flows */
  links?: SankeyLink[];
  /** gantt tasks */
  tasks?: GanttTask[];
  /** scatter points */
  scatter?: ScatterPoint[];
}

export default function Chart({
  data, categories, series, title, defaultKind = 'bar', defaultDim = '2d',
  height = 300, loading = false, extraKinds = [], yLabel, insight, isFullscreen = false, days, links, tasks, scatter,
}: ChartProps) {
  const multi = !!(series && series.length && ((categories && categories.length) || defaultKind === 'calendarpie'));
  const themeTick = useThemeTick();
  const pal = useMemo(() => activePalette(), [themeTick]); // eslint-disable-line react-hooks/exhaustive-deps
  const sColors = useMemo(() => (series || []).map((s, i) => s.color || pal[i % pal.length]), [series, pal]);

  // Aggregate fallback data if user switches away from special chart types
  const singleData: ChartDatum[] = useMemo(() => {
    if (multi) return series!.map((s, i) => ({ label: s.name, value: s.values.reduce((a, b) => a + b, 0), color: sColors[i] }));
    if (data && data.length) return data;
    if (links && links.length) {
      const m = new Map<string, number>();
      links.forEach((l) => m.set(l.source, (m.get(l.source) || 0) + l.value));
      return [...m.entries()].map(([label, value], i) => ({ label, value, color: pal[i % pal.length] }));
    }
    if (days && days.length && series && series.length) {
      return series.map((s, i) => ({
        label: s.name,
        value: days.reduce((sum, d) => sum + (d.values[i] || 0), 0),
        color: s.color || pal[i % pal.length],
      }));
    }
    if (tasks && tasks.length) {
      return tasks.map((tk, i) => ({ label: tk.name, value: tk.progress ?? 100, color: tk.color || pal[i % pal.length] }));
    }
    if (scatter && scatter.length) {
      return scatter.slice(0, 16).map((pt, i) => ({ label: pt.label || `Point ${i + 1}`, value: pt.y, color: pt.color || pal[i % pal.length] }));
    }
    return [];
  }, [multi, series, data, sColors, links, days, tasks, scatter, pal]);

  const colors = useMemo(() => singleData.map((x, i) => x.color || pal[i % pal.length]), [singleData, pal]);

  // Context-aware KINDS dropdown list: genuine options only where suitable data exists
  const KINDS = useMemo(() => {
    const list: { key: ChartKind; label: string; has3d: boolean }[] = [];
    const baseKeys: ChartKind[] = ['bar', 'line', 'area', 'pie', 'donut'];
    baseKeys.forEach((k) => {
      const item = BASE_KINDS.find((b) => b.key === k);
      if (item) list.push(item);
    });

    if (singleData.length >= 3) {
      const rad = BASE_KINDS.find((b) => b.key === 'radar');
      const pol = BASE_KINDS.find((b) => b.key === 'polar');
      if (rad) list.push(rad);
      if (pol) list.push(pol);
    }
    if (singleData.length >= 2) {
      const rb = BASE_KINDS.find((b) => b.key === 'radialbar');
      if (rb) list.push(rb);
    }

    // Dual axes: visible only where genuine multi-series or >=2 data items exist
    const hasDualData = (series && series.length >= 2 && categories && categories.length > 0) || (singleData.length >= 2);
    if (hasDualData) {
      const dual = BASE_KINDS.find((b) => b.key === 'dual');
      if (dual && !list.some((x) => x.key === 'dual')) list.push(dual);
    }

    // Calendar pie: visible only where genuine daily data exists
    if (days && days.length > 0) {
      const cp = EXTRA_KINDS.find((k) => k.key === 'calendarpie');
      if (cp && !list.some((x) => x.key === 'calendarpie')) list.unshift(cp);
    }

    // Sankey: visible only where genuine link flow data exists
    if (links && links.length > 0) {
      const sk = EXTRA_KINDS.find((k) => k.key === 'sankey');
      if (sk && !list.some((x) => x.key === 'sankey')) list.unshift(sk);
    }

    // Gantt: visible only where genuine task timeline data exists
    if (tasks && tasks.length > 0) {
      const gt = EXTRA_KINDS.find((k) => k.key === 'gantt');
      if (gt && !list.some((x) => x.key === 'gantt')) list.unshift(gt);
    }

    // Scatter: visible only where genuine coordinate scatter data exists
    if (scatter && scatter.length > 0) {
      const sc = EXTRA_KINDS.find((k) => k.key === 'scatter');
      if (sc && !list.some((x) => x.key === 'scatter')) list.unshift(sc);
    }

    extraKinds.forEach((ek) => {
      const found = EXTRA_KINDS.find((k) => k.key === ek);
      if (found && !list.some((x) => x.key === ek)) list.push(found);
    });

    if (!list.some((x) => x.key === defaultKind)) {
      const fb = [...BASE_KINDS, ...EXTRA_KINDS].find((k) => k.key === defaultKind);
      if (fb) list.unshift(fb);
    }
    return list;
  }, [singleData.length, series, categories, days, links, tasks, scatter, extraKinds, defaultKind]);
  const [kind, setKind] = useState<ChartKind>(defaultKind);
  const [dim, setDim] = useState<'2d' | '3d'>(defaultDim);
  const meta = KINDS.find((k) => k.key === kind) || BASE_KINDS[0];
  const isSpecialFlow = kind === 'sankey' || kind === 'calendarpie';
  const effDim = meta.has3d ? dim : '2d';

  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const [hoverSeg, setHoverSeg] = useState<{ c: number; s: number } | null>(null);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);
  const [full, setFull] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const progRef = useRef(0);
  const dimRef = useRef(defaultDim === '3d' && meta.has3d ? 1 : 0);
  const rafRef = useRef(0);
  const dimRafRef = useRef(0);
  const hovRef = useRef<Hover>({ ...NO_HOVER });
  const hovRafRef = useRef(0);
  const aspectRef = useRef(height / 560);
  // theme tokens are read once per theme change, never per animation frame
  const themeRef = useRef<Theme>(themeColors());
  useEffect(() => { themeRef.current = themeColors(); }, [themeTick]);

  const dataSig = useMemo(() => JSON.stringify({
    d: singleData.map((x) => [x.label, x.value]),
    s: (series || []).map((s) => s.values), c: categories, k: days, l: links, t: tasks, sc: scatter,
  }), [singleData, series, categories, days, links, tasks, scatter]);

  const buildCtx = useCallback((W: number, H: number, p: number, m: number, hov: Hover, forExport = false): DrawCtx => ({
    W, H, t: forExport ? themeColors(true) : themeRef.current, p, m, hov,
    data: singleData, colors, multi,
    cats: categories || [], series: series || [], sColors, yLabel,
    full: isFullscreen || forExport,
    bg: forExport ? '#ffffff' : undefined,
    days, links, tasks, scatter,
  }), [singleData, colors, multi, categories, series, sColors, yLabel, isFullscreen, days, links, tasks, scatter]);

  const paint = useCallback((ctx: Ctx, W: number, H: number, p: number, m: number, hov: Hover, forExport = false) => {
    paintChart(ctx, kind, buildCtx(W, H, p, m, hov, forExport));
  }, [buildCtx, kind]);

  const render = useCallback(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth, H = cv.clientHeight;
    if (W <= 0 || H <= 0) { requestAnimationFrame(() => render()); return; }
    aspectRef.current = H / W;
    const bw = Math.round(W * dpr), bh = Math.round(H * dpr);
    if (cv.width !== bw || cv.height !== bh) { cv.width = bw; cv.height = bh; }
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    paint(ctx, W, H, easeOut(progRef.current), dimRef.current, hovRef.current);
  }, [paint]);

  /* entrance animation — data/kind change only (NOT dim) */
  useEffect(() => {
    if (loading) return;
    cancelAnimationFrame(rafRef.current);
    progRef.current = 0;
    dimRef.current = effDim === '3d' ? 1 : 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      progRef.current = Math.min(1, (now - t0) / 750);
      render();
      if (progRef.current < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, dataSig, loading]);

  /* 2D ⇄ 3D morph — ease-in-out, duration scales gently with canvas size */
  useEffect(() => {
    if (loading) return;
    const target = effDim === '3d' ? 1 : 0;
    if (Math.abs(dimRef.current - target) < 0.001) return;
    cancelAnimationFrame(dimRafRef.current);
    const from = dimRef.current;
    const t0 = performance.now();
    const W = canvasRef.current?.clientWidth || 600;
    const DUR = 480 + Math.min(240, Math.max(0, W - 600) * 0.4);
    const tick = (now: number) => {
      const t = Math.min(1, (now - t0) / DUR);
      dimRef.current = from + (target - from) * easeInOut(t);
      render();
      if (t < 1) dimRafRef.current = requestAnimationFrame(tick);
    };
    dimRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(dimRafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effDim, loading]);

  /* smooth hover animation */
  useEffect(() => {
    const target = hoverIdx !== null || hoverSeg !== null;
    const h = hovRef.current;
    if (hoverIdx !== h.idx || JSON.stringify(hoverSeg) !== JSON.stringify(h.seg)) {
      h.idx = hoverIdx; h.seg = hoverSeg;
      if (target) h.amt = Math.min(h.amt, 0.35);
    }
    cancelAnimationFrame(hovRafRef.current);
    const tick = () => {
      const goal = target ? 1 : 0;
      const diff = goal - h.amt;
      if (Math.abs(diff) < 0.02) {
        h.amt = goal;
        if (!target) { h.idx = null; h.seg = null; }
        if (progRef.current >= 1) render();
        return;
      }
      h.amt += diff * 0.22;
      if (progRef.current >= 1) render();
      hovRafRef.current = requestAnimationFrame(tick);
    };
    hovRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(hovRafRef.current);
  }, [hoverIdx, hoverSeg, render]);

  useEffect(() => { if (progRef.current >= 1) render(); }, [themeTick, render]);
  useEffect(() => {
    const cv = canvasRef.current;
    const on = () => render();
    window.addEventListener('resize', on);
    let ro: ResizeObserver | null = null;
    if (cv && typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => render());
      ro.observe(cv);
    }
    return () => { window.removeEventListener('resize', on); ro?.disconnect(); };
  }, [render, loading]);

  /* hit testing — shares the exact layout helpers used by the painter */
  const hit = (e: React.MouseEvent) => {
    const cv = canvasRef.current;
    if (!cv || (!singleData.length && !isSpecialFlow && !tasks?.length && !scatter?.length)) return;
    const r = cv.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    const W = r.width, H = r.height;
    const m = dimRef.current;
    const total = singleData.reduce((s, x) => s + x.value, 0) || 1;
    let idx: number | null = null;
    let seg: { c: number; s: number } | null = null;
    let text = '';

    if (kind === 'sankey') {
      const lay = sankeyLayout((links || []).filter((l) => l.value > 0 && l.source !== l.target), W, H, isFullscreen ? 200 : Math.min(150, W * 0.22));
      if (lay) {
        lay.nodes.forEach((n, i) => { if (mx >= n.x - 4 && mx <= n.x + lay.nodeW + 4 && my >= n.y && my <= n.y + n.h) idx = i; });
        if (idx !== null) { const n = lay.nodes[idx]; text = `${n.name}: ${n.value}`; }
      }
      setHoverIdx(idx); setHoverSeg(null); setTip(idx !== null ? { x: mx, y: my, text } : null);
      return;
    }
    if (kind === 'calendarpie') {
      const ds = days || [];
      if (ds.length && series?.length) {
        const first = new Date(Math.min(...ds.map((x) => new Date(x.date + 'T00:00:00').getTime())));
        const ms = new Date(first.getFullYear(), first.getMonth(), 1), me = new Date(first.getFullYear(), first.getMonth() + 1, 0);
        const padL = 12, padR = 12, padT = 34, padB = 10, cols = 7;
        const lead = (ms.getDay() + 6) % 7, rows = Math.ceil((lead + me.getDate()) / cols);
        const cell = Math.min((W - padL - padR) / cols, (H - padT - padB) / rows);
        const gx = padL + ((W - padL - padR) - cell * cols) / 2, gy = padT + ((H - padT - padB) - cell * rows) / 2;
        const c = Math.floor((mx - gx) / cell), rw = Math.floor((my - gy) / cell);
        const dnum = rw * cols + c - lead + 1;
        if (c >= 0 && c < cols && rw >= 0 && dnum >= 1 && dnum <= me.getDate()) {
          const iso = `${ms.getFullYear()}-${String(ms.getMonth() + 1).padStart(2, '0')}-${String(dnum).padStart(2, '0')}`;
          const vals = ds.find((x) => x.date === iso)?.values;
          if (vals) {
            const cx0 = gx + c * cell + cell / 2, cy0 = gy + rw * cell + cell / 2 + cell * 0.05;
            const rad = Math.hypot(mx - cx0, my - cy0);
            if (rad <= cell * 0.36 + 4) {
              const tot = vals.reduce((a2, b) => a2 + b, 0) || 1;
              let ang = Math.atan2(my - cy0, mx - cx0) + Math.PI / 2; ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
              let acc = 0;
              for (let si = 0; si < vals.length; si++) { acc += (vals[si] / tot) * Math.PI * 2; if (ang <= acc) { seg = { c: dnum, s: si }; break; } }
              if (seg) text = `${new Date(iso + 'T00:00:00').toLocaleDateString('en', { day: 'numeric', month: 'short' })} · ${series![seg.s].name}: ${vals[seg.s]}`;
            }
          }
        }
      }
      setHoverIdx(null); setHoverSeg(seg); setTip(seg ? { x: mx, y: my, text } : null);
      return;
    }

    if (kind === 'pie' || kind === 'donut' || kind === 'polar') {
      const g = circGeom(W, H, kind === 'polar' ? 0 : m, singleData, isFullscreen);
      const rIn = kind === 'donut' ? g.R * g.rInRatio : 0;
      const sliceAt = (ang: number) => {
        let acc = 0;
        for (let i = 0; i < singleData.length; i++) {
          acc += (singleData[i].value / total) * Math.PI * 2;
          if (ang <= acc) return i;
        }
        return null;
      };
      const probe = (dy: number, frontOnly: boolean): number | null => {
        const ex = mx - g.cx, ey = (my - dy - g.cy) / g.squash;
        const rad = Math.hypot(ex, ey);
        if (rad > g.R + 12 || rad < Math.max(0, rIn - 8)) return null;
        let ang = Math.atan2(ey, ex) + Math.PI / 2;
        ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        if (frontOnly && !(ang > Math.PI / 2 && ang < (3 * Math.PI) / 2)) return null;
        if (kind === 'polar') {
          const max = Math.max(...singleData.map((x) => x.value), 1);
          const i = Math.min(singleData.length - 1, Math.floor((ang / (Math.PI * 2)) * singleData.length));
          return (singleData[i].value / max) * g.R >= rad - 8 ? i : null;
        }
        return sliceAt(ang);
      };
      // sticky hover: while a slice is pulled out, test it first at its displaced
      // position so the cursor doesn't "fall off" the moving geometry
      const cur = hovRef.current;
      if (cur.idx !== null && cur.amt > 0.01 && kind !== 'polar') {
        let a0 = -Math.PI / 2;
        for (let i = 0; i < cur.idx; i++) a0 += (singleData[i].value / total) * Math.PI * 2;
        const a1 = a0 + (singleData[cur.idx].value / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2, pull = 9 * cur.amt;
        const dx = Math.cos(mid) * pull, dy = Math.sin(mid) * pull * g.squash;
        const ex = mx - dx - g.cx;
        for (const band of [0, g.depth * 0.5, g.depth]) {
          const ey = (my - dy - band - g.cy) / g.squash;
          const rad = Math.hypot(ex, ey);
          if (rad > g.R + 10 || rad < Math.max(0, rIn - 8)) continue;
          let ang = Math.atan2(ey, ex) + Math.PI / 2;
          ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
          if (band > 0 && !(ang > Math.PI / 2 && ang < (3 * Math.PI) / 2)) continue;
          if (sliceAt(ang) === cur.idx) { idx = cur.idx; break; }
        }
      }
      if (idx === null) idx = probe(0, false);
      // extruded view: the side band (rim → rim + depth) belongs to the front slices too
      if (idx === null && g.depth > 0.5) {
        for (const f of [0.5, 1]) { idx = probe(g.depth * f, true); if (idx !== null) break; }
      }
      if (idx !== null) {
        text = `${singleData[idx].label}: ${singleData[idx].value}`;
        let a0 = -Math.PI / 2;
        for (let j = 0; j < idx; j++) a0 += (singleData[j].value / total) * Math.PI * 2;
        const a1 = a0 + (singleData[idx].value / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2;
        const outR = g.R + 24;
        const tx = Math.max(16, Math.min(W - 140, g.cx + Math.cos(mid) * outR));
        const ty = Math.max(16, Math.min(H - 40, g.cy + Math.sin(mid) * outR * g.squash));
        setHoverIdx(idx); setHoverSeg(null); setTip({ x: tx, y: ty, text });
        return;
      }
    } else if (kind === 'radialbar') {
      const rg = radialGeom(W, H, singleData, isFullscreen);
      const rad = Math.hypot(mx - rg.cx, my - rg.cy);
      for (let i = 0; i < singleData.length; i++) {
        if (Math.abs(rad - rg.radiusOf(i)) <= rg.thick / 2 + 1.5) { idx = i; break; }
      }
      if (idx !== null) text = `${singleData[idx].label}: ${singleData[idx].value}`;
    } else if (kind === 'dual') {
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const colVals = multi ? categories!.map((_, c) => series![0]?.values[c] || 0) : singleData.map((x) => x.value);
      const maxL = Math.max(...colVals, 1);
      const L = xyLayout('bar', W, H, 0, labels, 1, maxL, !!yLabel, isFullscreen);
      const lineVals = multi ? series!.slice(1).map((s) => s.values) : [];
      const maxR = Math.max(...lineVals.flat(), 1);
      const pad = { ...L.pad, r: 12 + approxW(fmtNum(maxR), 10.5) + 14 };
      const cw = W - pad.l - pad.r, ch = H - pad.t - pad.b;
      const step = cw / Math.max(1, labels.length);
      const ci = Math.floor((mx - pad.l) / step);
      if (ci >= 0 && ci < labels.length && mx >= pad.l) {
        if (multi) {
          let best = 16, bs: number | null = null;
          lineVals.forEach((vals, li) => { const yy = pad.t + ch - ((vals[ci] || 0) / maxR) * ch; if (Math.abs(my - yy) < best) { best = Math.abs(my - yy); bs = li + 1; } });
          const colTop = pad.t + ch - (colVals[ci] / maxL) * ch;
          if (bs === null && my >= colTop - 4) bs = 0;
          if (bs !== null) { seg = { c: ci, s: bs }; text = `${labels[ci]} · ${series![bs].name}: ${series![bs].values[ci] || 0}`; }
        } else {
          idx = ci; text = `${singleData[ci].label}: ${singleData[ci].value}`;
        }
      }
    } else if (kind === 'funnel' || kind === 'pyramid') {
      const g = funnelGeom(W, H, m, singleData, isFullscreen, kind === 'pyramid');
      const heights = singleData.map((x) => (x.value / total) * g.ch);
      let y = g.topY;
      for (let i = 0; i < singleData.length; i++) {
        if (my >= y && my <= y + heights[i] && Math.abs(mx - g.cx) <= g.plotW / 2 + 24) { idx = i; break; }
        y += heights[i];
      }
      if (idx !== null) text = `${singleData[idx].label}: ${singleData[idx].value}`;
    } else if (kind === 'radar') {
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const longest = Math.max(0, ...labels.map((l) => approxW(l)));
      const margin = isFullscreen ? Math.min(W * 0.4, longest + 24) : 44;
      const cy = H / 2 + 6, R = Math.max(30, Math.min(W / 2 - margin, H / 2 - 30));
      const max = multi ? Math.max(...series!.flatMap((s) => s.values), 1) : Math.max(...singleData.map((x) => x.value), 1);
      let best = 12;
      labels.forEach((_, i) => {
        const aa = -Math.PI / 2 + (i * Math.PI * 2) / labels.length;
        const v = multi ? Math.max(...series!.map((s) => s.values[i] || 0)) : singleData[i].value;
        const vr = (v / max) * R;
        const dd = Math.hypot(mx - (W / 2 + Math.cos(aa) * vr), my - (cy + Math.sin(aa) * vr));
        if (dd < best) { best = dd; idx = i; }
      });
      if (idx !== null) text = multi
        ? `${categories![idx]} · ${series!.map((s) => `${s.name}: ${s.values[idx!] || 0}`).join(' · ')}`
        : `${singleData[idx].label}: ${singleData[idx].value}`;
    } else {
      const isBar = kind === 'bar';
      const nD = multi ? series!.length : 1;
      const labels = multi ? categories! : singleData.map((x) => x.label);
      const max = isBar
        ? (multi ? Math.max(...categories!.map((_, c) => series!.reduce((s, sr) => s + (sr.values[c] || 0), 0)), 1) : Math.max(...singleData.map((x) => x.value), 1))
        : (multi ? Math.max(...series!.flatMap((s) => s.values), 1) : Math.max(...singleData.map((x) => x.value), 1));
      const L = xyLayout(kind as 'bar' | 'line' | 'area', W, H, m, labels, nD, max, !!yLabel, isFullscreen);
      const { pad, ch, step } = L;
      const ci = Math.floor((mx - pad.l) / step);
      if (ci >= 0 && ci < labels.length && mx >= pad.l) {
        if (multi && isBar) {
          const totals = categories!.map((_, c) => series!.reduce((s, sr) => s + (sr.values[c] || 0), 0));
          const yVal = ((pad.t + ch - my) / ch) * max;
          let acc = 0, si: number | null = null;
          for (let s = 0; s < series!.length; s++) {
            acc += series![s].values[ci] || 0;
            if (yVal <= acc) { si = s; break; }
          }
          if (si !== null && yVal <= totals[ci]) {
            seg = { c: ci, s: si };
            text = `${categories![ci]} · ${series![si].name}: ${series![si].values[ci] || 0} (total ${totals[ci]})`;
          }
        } else if (multi) {
          const depth = seriesDepth(series!);
          let best = 20, bs: number | null = null;
          series!.forEach((s, si) => {
            const yy = pad.t + ch - ((s.values[ci] || 0) / max) * ch - ZY * m * depth[si];
            const dd = Math.abs(my - yy);
            if (dd < best) { best = dd; bs = si; }
          });
          if (bs !== null) {
            seg = { c: ci, s: bs };
            text = `${categories![ci]} · ${series![bs].name}: ${series![bs].values[ci] || 0}`;
          }
        } else {
          idx = ci;
          text = `${singleData[ci].label}: ${singleData[ci].value}`;
        }
      }
    }

    setHoverIdx(idx);
    setHoverSeg(seg);
    setTip(idx !== null || seg !== null ? { x: mx, y: my, text } : null);
  };

  const legend = kind === 'sankey'
    ? (() => { const names = [...new Set((links || []).flatMap((l) => [l.source, l.target]))]; return names.map((n, i) => ({ label: n, color: pal[i % pal.length] })); })()
    : multi
      ? series!.map((s, i) => ({ label: s.name, color: sColors[i] }))
      : singleData.map((x, i) => ({ label: x.label, color: colors[i] }));

  /* exports */
  const doExport = async (fmt: string) => {
    const cv = canvasRef.current;
    if (!cv) return;
    const base = (title || 'chart').toLowerCase().replace(/\s+/g, '-');
    const m = effDim === '3d' ? 1 : 0;
    const legendItems = legend;

    if (fmt === 'csv' && kind === 'sankey') {
      downloadBlob(`${base}.csv`, new Blob(['source,target,value\n' + (links || []).map((l) => `"${l.source}","${l.target}",${l.value}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'csv' && kind === 'calendarpie') {
      downloadBlob(`${base}.csv`, new Blob(['date,' + series!.map((x) => `"${x.name}"`).join(',') + '\n' + (days || []).map((x) => `${x.date},${x.values.join(',')}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'json' && isSpecialFlow) {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify(kind === 'sankey' ? { links } : { series: series!.map((x) => x.name), days }, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel' && isSpecialFlow) {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Chart Data');
      const head = ws.addRow(kind === 'sankey' ? ['Source', 'Target', 'Value'] : ['Date', ...series!.map((x) => x.name)]);
      head.eachCell((cell: { font: unknown; fill: unknown }) => { cell.font = { bold: true, color: { argb: 'FFFFFFFF' } }; cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } }; });
      if (kind === 'sankey') (links || []).forEach((l) => ws.addRow([l.source, l.target, l.value])); else (days || []).forEach((x) => ws.addRow([x.date, ...x.values]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }

    if (fmt === 'csv') {
      const csv = multi
        ? 'category,' + series!.map((s) => `"${s.name}"`).join(',') + '\n' +
          categories!.map((c, i) => `"${c}",` + series!.map((s) => s.values[i] || 0).join(',')).join('\n')
        : 'label,value\n' + singleData.map((x) => `"${x.label}",${x.value}`).join('\n');
      downloadBlob(`${base}.csv`, new Blob([csv], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'json') {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify(multi ? { categories, series } : singleData, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel') {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Chart Data');
      ws.mergeCells(1, 1, 1, multi ? series!.length + 1 : 2);
      const titleCell = ws.getCell(1, 1);
      titleCell.value = (title || 'Chart').toUpperCase();
      titleCell.font = { bold: true, size: 13, color: { argb: 'FF0D7A54' } };
      const head = ws.addRow(multi ? ['Category', ...series!.map((s) => s.name)] : ['Label', 'Value']);
      head.eachCell((cell: { font: unknown; fill: unknown }) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
      });
      if (multi) categories!.forEach((c, i) => ws.addRow([c, ...series!.map((s) => s.values[i] || 0)]));
      else singleData.forEach((x) => ws.addRow([x.label, x.value]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }

    await fontsReady();
    const tEx = themeColors(true);
    if (fmt === 'svg') {
      // SVG mirrors the chart EXACTLY as shown: same canvas size, same layout mode
      // (compact/fullscreen label fitting), same fonts — embedded so it renders
      // identically anywhere, at any zoom, without depending on installed fonts.
      const Ws = cv.clientWidth, Hs = cv.clientHeight;
      const fontCss = await fontFaceCss(fontFamilies(tEx), ['600', '700']);
      const svgPainter = (ctx: Ctx) => paintChart(ctx, kind, { ...buildCtx(Ws, Hs, 1, m, NO_HOVER, true), full: isFullscreen });
      downloadBlob(`${base}.svg`, new Blob([composeSvg(title || '', Ws, Hs, legendItems, svgPainter, tEx, fontCss)], { type: 'image/svg+xml' }));
      return;
    }
    const { W: Wx, H: Hx } = exportDims(kind, cv.clientWidth, cv.clientHeight, singleData, multi, categories || [], m);
    const painter = (ctx: Ctx) => paint(ctx, Wx, Hx, 1, m, NO_HOVER, true);
    const out = composeExport(title || '', Wx, Hx, legendItems, painter, tEx);
    if (fmt === 'png') out.toBlob((b) => b && downloadBlob(`${base}.png`, b), 'image/png');
    else if (fmt === 'pdf') {
      const dataUrl = out.toDataURL('image/jpeg', 0.94);
      const bytes = Uint8Array.from(atob(dataUrl.split(',')[1]), (c) => c.charCodeAt(0));
      downloadBlob(`${base}.pdf`, jpegToPdf(bytes, out.width, out.height));
    } else if (fmt === 'print') printCanvas(title || 'Chart', out);
  };


  const containerRef = useRef<HTMLDivElement>(null);
  const [isFs, setIsFs] = useState(false);

  useEffect(() => {
    const onFs = () => {
      const active = !!document.fullscreenElement && document.fullscreenElement === containerRef.current;
      setIsFs(active);
    };
    document.addEventListener('fullscreenchange', onFs);
    document.addEventListener('webkitfullscreenchange', onFs);
    return () => {
      document.removeEventListener('fullscreenchange', onFs);
      document.removeEventListener('webkitfullscreenchange', onFs);
    };
  }, []);

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      try {
        if (containerRef.current?.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        } else if ((containerRef.current as unknown as { webkitRequestFullscreen?: () => Promise<void> })?.webkitRequestFullscreen) {
          await (containerRef.current as unknown as { webkitRequestFullscreen: () => Promise<void> }).webkitRequestFullscreen();
        }
        setIsFs(true);
      } catch {
        setFull(true);
      }
    } else {
      try {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as unknown as { webkitExitFullscreen?: () => Promise<void> })?.webkitExitFullscreen) {
          await (document as unknown as { webkitExitFullscreen: () => Promise<void> }).webkitExitFullscreen();
        }
      } catch { /* noop */ }
      setIsFs(false);
      setFull(false);
    }
  };

  const body = (
    <div ref={containerRef} className={`tk-card ${isFs ? '!fixed !inset-0 !z-[100] !w-screen !h-screen !m-0 !rounded-none !p-6 sm:!p-10 flex flex-col justify-between overflow-auto bg-(--t-surface)' : 'p-4'}`}>
      <div className="mb-3 flex flex-wrap items-center gap-2 relative z-50">
        {title && <p className={`mr-auto font-display font-semibold text-ink ${isFs ? 'text-xl' : 'text-[15px]'}`}>{title}</p>}
        {meta.has3d && (
          <div className="tk-inset flex gap-0.5 p-1">
            {(['2d', '3d'] as const).map((dd) => (
              <button key={dd} onClick={() => setDim(dd)} disabled={loading || (dd === '3d' && !meta.has3d)}
                className={`flex items-center gap-1 rounded-lg px-2.5 py-1 font-body text-[11px] font-bold uppercase transition disabled:opacity-30 ${effDim === dd ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}>
                {dd === '2d' ? <Square size={11} /> : <Box size={11} />} {dd}
              </button>
            ))}
          </div>
        )}
        <MiniDrop label={meta.label} activeKey={kind}
          items={KINDS.map((k) => ({ key: k.key, label: k.label }))}
          onPick={(k) => { setKind(k as ChartKind); setHoverIdx(null); setHoverSeg(null); setTip(null); }} />
        <MiniDrop label="Export" icon={<Download size={12} />}
          items={[
            { key: 'png', label: 'PNG image' },
            { key: 'svg', label: 'SVG vector' },
            { key: 'pdf', label: 'PDF document' },
            { key: 'excel', label: 'Excel workbook' },
            { key: 'print', label: 'Print…' },
            { key: 'csv', label: 'CSV data' },
            { key: 'json', label: 'JSON data' },
          ]}
          onPick={doExport} />
        {!isFullscreen && (
          <button onClick={toggleFullscreen} data-tip={isFs ? "Exit fullscreen" : "View fullscreen"} className="tk-btn-ghost rounded-xl p-2">
            {isFs ? <Minimize2 size={15} /> : <Eye size={14} />}
          </button>
        )}
      </div>

      <div className="relative flex-1 w-full" style={{ height: isFs ? 'calc(100vh - 160px)' : height }}>
        {loading ? (
          <ChartSkeleton kind={skeletonKind(kind)} height={isFs ? 500 : height} legend={false} />
        ) : (
          <>
            <canvas ref={canvasRef} style={{ width: '100%', height: '100%' }}
              onMouseMove={hit} onMouseLeave={() => { setHoverIdx(null); setHoverSeg(null); setTip(null); }} />
            {tip && (
              <div className="tk-pop pointer-events-none absolute z-10 px-2.5 py-1 font-body text-[11px] font-bold text-ink"
                style={{ left: Math.min(tip.x + 12, (canvasRef.current?.clientWidth || 300) - 170), top: Math.max(0, tip.y - 34) }}>
                {tip.text}
              </div>
            )}
          </>
        )}
      </div>

      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <span key={i} className="tk-skeleton h-2.5" style={{ width: 48 + (i % 3) * 18 }} />)
          : legend.map((l, i) => (
            <button key={l.label + i}
              onMouseEnter={() => (kind === 'sankey' ? setHoverIdx(i) : multi ? setHoverSeg({ c: -1, s: i }) : setHoverIdx(i))}
              onMouseLeave={() => { setHoverIdx(null); setHoverSeg(null); }}
              className={`flex items-center gap-1.5 font-body text-[11px] font-semibold transition ${(multi ? hoverSeg?.s === i : hoverIdx === i) ? 'text-ink' : 'text-muted'}`}>
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: l.color }} /> {l.label}
            </button>
          ))}
      </div>

      {insight && insight.length > 0 && (
        <div className="tk-inset mt-3 space-y-1 rounded-xl px-3.5 py-2.5">
          {insight.map((line, i) => <p key={i} className="font-body text-[11.5px] text-ink/70">• {line}</p>)}
        </div>
      )}
    </div>
  );

  return (
    <>
      {body}
      {full && createPortal(
        <div className="fixed inset-0 z-[100] flex flex-col bg-(--t-surface) p-6 sm:p-10 backdrop-blur-md overflow-auto"
          onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) setFull(false); }}>
          <div className="mb-3 flex justify-between items-center">
            {title && <h2 className="font-display text-xl font-bold text-ink">{title}</h2>}
            <button onClick={() => setFull(false)} className="tk-btn-ghost rounded-full p-2.5 ml-auto"><X size={18} /></button>
          </div>
          <div className="flex-1 w-full">
            <Chart data={data} categories={categories} series={series} title={title}
              defaultKind={kind} defaultDim={effDim} height={window.innerHeight - 180} extraKinds={extraKinds}
              yLabel={yLabel} insight={insight} days={days} links={links} tasks={tasks} scatter={scatter} isFullscreen />
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

/* ================= StackedColumns (compat wrapper) ================= */
export function StackedColumns({ title, categories, series, height = 300, yLabel = 'Employees', insight }: {
  title: string; categories: string[]; series: StackedSeries[]; height?: number; yLabel?: string; insight?: string[];
}) {
  return <Chart title={title} categories={categories} series={series} defaultKind="bar" height={height} yLabel={yLabel} insight={insight} />;
}

/* ============================================================
   Neumorphic chart family v3 — reference soft-UI depth
   (extruded puck · inset groove ring · carved wedges with divider
   grooves · raised centre button · on-slice % labels). ONE canvas
   painter drives the live chart AND every export, so nothing is
   ever missing or truncated and fonts are preserved.
   ============================================================ */
export type NeuKind = 'donut' | 'pie' | 'bars' | 'columns' | 'line' | 'area';
const NEU_KINDS: { key: NeuKind; label: string }[] = [
  { key: 'donut', label: 'Donut' },
  { key: 'pie', label: 'Pie' },
  { key: 'bars', label: 'Bars' },
  { key: 'columns', label: 'Columns' },
  { key: 'line', label: 'Line' },
  { key: 'area', label: 'Area' },
];

interface NeuTones { surface: string; hi: string; lo: string; shadowDark: string; shadowLight: string; groove: string; grooveHi: string; muted: string; grid: string }
function neuTones(t: Theme): NeuTones {
  const dark = !!t.dark;
  const surface = t.surface || '#e4e7e0';
  return {
    surface,
    hi: shade(surface, dark ? 1.1 : 1.045),
    lo: shade(surface, dark ? 0.88 : 0.962),
    shadowDark: dark ? 'rgba(0,0,0,0.55)' : rgba(t.ink, 0.24),
    shadowLight: dark ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.92)',
    groove: dark ? 'rgba(0,0,0,0.5)' : rgba(t.ink, 0.14),
    grooveHi: dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.85)',
    muted: rgba(t.ink, 0.55),
    grid: rgba(t.ink, 0.16),
  };
}
function setShadow(ctx: Ctx, x: number, y: number, blur: number, color: string) {
  ctx.shadowOffsetX = x; ctx.shadowOffsetY = y; ctx.shadowBlur = blur; ctx.shadowColor = color;
}
function noShadow(ctx: Ctx) { ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; ctx.shadowColor = 'rgba(0,0,0,0)'; }
function circle(ctx: Ctx, cx: number, cy: number, r: number) { ctx.beginPath(); ctx.arc(cx, cy, Math.max(0.1, r), 0, Math.PI * 2); ctx.closePath(); }
/** Extruded soft disc: dark shadow bottom-right, light shadow top-left, gentle sheen. */
function raisedDisc(ctx: Ctx, cx: number, cy: number, r: number, n: NeuTones, spread = 1) {
  ctx.save();
  setShadow(ctx, 7 * spread, 7 * spread, 16 * spread, n.shadowDark); ctx.fillStyle = n.surface; circle(ctx, cx, cy, r); ctx.fill();
  setShadow(ctx, -6 * spread, -6 * spread, 14 * spread, n.shadowLight); circle(ctx, cx, cy, r); ctx.fill();
  noShadow(ctx);
  const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
  g.addColorStop(0, n.hi); g.addColorStop(1, n.lo);
  ctx.fillStyle = g; circle(ctx, cx, cy, r); ctx.fill();
  ctx.restore();
}
/** Inset groove ring (trench) — dark inner edge top-left, light edge bottom-right. */
function grooveRing(ctx: Ctx, cx: number, cy: number, r: number, n: NeuTones, w = 2.6) {
  ctx.lineWidth = w; ctx.strokeStyle = n.groove; circle(ctx, cx - 0.7, cy - 0.7, r); ctx.stroke();
  ctx.lineWidth = w * 0.6; ctx.strokeStyle = n.grooveHi; circle(ctx, cx + 0.9, cy + 0.9, r); ctx.stroke();
  ctx.lineWidth = w * 0.45; ctx.strokeStyle = n.surface; circle(ctx, cx, cy, r); ctx.stroke();
  ctx.lineWidth = 1;
}
/** Inset track (rounded rect trench) for bars / columns / plot panels. */
function insetTrack(ctx: Ctx, x: number, y: number, w: number, h: number, n: NeuTones, r?: number) {
  const rr = Math.min(r ?? h / 2, w / 2, h / 2);
  ctx.fillStyle = n.lo; ctx.beginPath(); ctx.roundRect(x, y, w, h, rr); ctx.fill();
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, n.groove); g.addColorStop(1, n.grooveHi);
  ctx.strokeStyle = g; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.roundRect(x + 0.6, y + 0.6, w - 1.2, h - 1.2, Math.max(0, rr - 0.6)); ctx.stroke();
  ctx.lineWidth = 1;
}
function wedgePath(ctx: Ctx, cx: number, cy: number, R: number, rIn: number, a0: number, a1: number) {
  ctx.beginPath();
  if (rIn > 0) { ctx.arc(cx, cy, R, a0, a1); ctx.arc(cx, cy, rIn, a1, a0, true); ctx.closePath(); }
  else { ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, a0, a1); ctx.closePath(); }
}

export interface NeuDraw { data: ChartDatum[]; colors: string[]; t: Theme; p: number; hover: number | null; amt: number; centerLabel: string; full: boolean }

/* ---- circular: puck + groove ring + carved wedges + raised centre ---- */
export function paintNeuCircular(ctx: Ctx, isDonut: boolean, cx: number, cy: number, R: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const { data, colors, p, hover, amt } = d;
  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const rIn = isDonut ? R * 0.56 : 0;
  const scale = 0.94 + 0.06 * clamp01(p * 1.4);

  ctx.save();
  if (scale < 0.999) { ctx.translate(cx, cy); ctx.scale(scale, scale); ctx.translate(-cx, -cy); }
  raisedDisc(ctx, cx, cy, R + 18, n);
  grooveRing(ctx, cx, cy, R + 9, n);

  let a = -Math.PI / 2;
  const mids: number[] = [];
  data.forEach((x, i) => {
    const frac = x.value / total;
    const a1 = a + frac * Math.PI * 2 * p;
    const mid = (a + a1) / 2;
    mids.push(mid);
    const on = hover === i;
    const off = on ? 6 * amt : 0;
    const col = colors[i];
    ctx.save();
    ctx.globalAlpha = hover !== null && !on ? 1 - 0.42 * amt : 1;
    ctx.translate(Math.cos(mid) * off, Math.sin(mid) * off);
    wedgePath(ctx, cx, cy, R, rIn, a, a1);
    const g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
    g.addColorStop(0, shade(col, 1.14)); g.addColorStop(1, shade(col, 0.86));
    setShadow(ctx, 2, 3, on ? 10 : 6, on ? rgba(col, 0.55) : 'rgba(0,0,0,0.28)');
    ctx.fillStyle = g; ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = n.surface; ctx.lineWidth = 3; ctx.lineJoin = 'round'; ctx.stroke(); // divider grooves
    ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 1; ctx.stroke();          // bevel
    ctx.lineJoin = 'miter';
    ctx.restore();
    a = a1;
  });

  // on-slice % labels (fade in as the sweep completes)
  if (p > 0.85) {
    ctx.save();
    ctx.globalAlpha = clamp01((p - 0.85) / 0.15);
    ctx.font = font(d.t, 700, R >= 110 ? 12 : R >= 80 ? 10.5 : 9.5);
    ctx.textAlign = 'center';
    setShadow(ctx, 0, 1, 2, 'rgba(0,0,0,0.45)');
    data.forEach((x, i) => {
      const frac = x.value / total;
      if (frac < 0.06) return;
      const on = hover === i;
      const off = on ? 6 * amt : 0;
      const lr = (rIn > 0 ? (R + rIn) / 2 : R * 0.62) + off;
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`${Math.round(frac * 100)}%`, cx + Math.cos(mids[i]) * lr, cy + Math.sin(mids[i]) * lr + 3.5);
    });
    ctx.restore();
  }

  // raised centre button (donut) — total or hovered slice
  if (isDonut) {
    const cr = rIn - 7;
    raisedDisc(ctx, cx, cy, cr, n, 0.7);
    ctx.strokeStyle = rgba(d.t.ink, 0.08); ctx.lineWidth = 1; circle(ctx, cx, cy, cr - 3); ctx.stroke();
    const value = hover !== null ? data[hover].value : total;
    const label = hover !== null ? data[hover].label : d.centerLabel;
    const vs = Math.max(13, Math.min(28, cr * 0.5));
    ctx.textAlign = 'center';
    ctx.fillStyle = d.t.ink; ctx.font = font(d.t, 700, vs, true);
    ctx.fillText(fitCtx(ctx, String(value), cr * 1.7), cx, cy + vs * 0.18);
    ctx.fillStyle = n.muted; ctx.font = font(d.t, 700, Math.max(7.5, Math.min(10, cr * 0.18)));
    ctx.fillText(fitCtx(ctx, label.toUpperCase(), cr * 1.7), cx, cy + vs * 0.18 + Math.max(10, cr * 0.24));
  }
  ctx.restore();
  ctx.textAlign = 'left';
}

/* ---- horizontal soft bars (export painter; live uses DOM) ---- */
function paintNeuBars(ctx: Ctx, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const max = Math.max(...d.data.map((x) => x.value), 1);
  const N = d.data.length;
  const rowH = Math.min(48, (H - 12) / Math.max(1, N));
  d.data.forEach((x, i) => {
    const y = 8 + i * rowH;
    const col = d.colors[i];
    ctx.font = font(d.t, 600, 11.5); ctx.fillStyle = rgba(d.t.ink, 0.78); ctx.textAlign = 'left';
    ctx.fillText(x.label, 14, y + 12);
    ctx.font = font(d.t, 700, 11.5); ctx.fillStyle = d.t.ink; ctx.textAlign = 'right';
    ctx.fillText(String(x.value), W - 14, y + 12);
    const tx = 14, ty = y + 19, tw = W - 28, th = 14;
    insetTrack(ctx, tx, ty, tw, th, n);
    const bw = Math.max(th, tw * (x.value / max) * d.p);
    const g = ctx.createLinearGradient(tx, ty, tx + bw, ty + th);
    g.addColorStop(0, col); g.addColorStop(1, shade(col, 0.82));
    setShadow(ctx, 1, 1, 3, 'rgba(0,0,0,0.25)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(tx, ty, bw, th, 7); ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(tx + 1, ty + 1, bw - 2, th - 2, 6); ctx.stroke();
  });
  ctx.textAlign = 'left';
}

/* ---- vertical soft columns (export painter; live uses DOM) ---- */
function paintNeuColumns(ctx: Ctx, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const max = Math.max(...d.data.map((x) => x.value), 1);
  const N = d.data.length;
  const padT = 28, padR = 14;
  const { plan, l: padL, step } = planXFit(d.data.map((x) => x.label), W, 14, padR, d.full, 9.5, N);
  const ch = Math.max(30, H - padT - plan.padB - 6);
  const colW = Math.min(44, step * 0.62);
  d.data.forEach((x, i) => {
    const cx = padL + step * i + step / 2;
    const col = d.colors[i];
    insetTrack(ctx, cx - colW / 2, padT, colW, ch, n, 12);
    const h = Math.max(6, ch * (x.value / max) * d.p);
    const g = ctx.createLinearGradient(cx - colW / 2, padT + ch - h, cx + colW / 2, padT + ch);
    g.addColorStop(0, col); g.addColorStop(1, shade(col, 0.82));
    setShadow(ctx, 0, -1, 3, 'rgba(0,0,0,0.18)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(cx - colW / 2, padT + ch - h, colW, h, 12); ctx.fill();
    noShadow(ctx);
    ctx.font = font(d.t, 700, 10.5); ctx.fillStyle = rgba(d.t.ink, 0.72); ctx.textAlign = 'center';
    ctx.fillText(String(x.value), cx, padT - 9);
  });
  drawXLabels(ctx, d.data.map((x) => x.label), plan, (i) => padL + step * i + step / 2, padT + ch, d.t, W, 700, n.muted);
}

/* ---- soft line / area: inset panel, dotted grid, adaptive labels & markers ---- */
interface NeuLineLayout { padL: number; padT: number; cw: number; ch: number; step: number; plan: XPlan; xOf: (i: number) => number; yOf: (v: number) => number; max: number }
function neuLineLayout(W: number, H: number, data: ChartDatum[], full: boolean): NeuLineLayout {
  const max = Math.max(...data.map((x) => x.value), 1);
  const fs = 10;
  const padR = 18, padT = 24;
  const N = data.length;
  const { plan, l: padL, step } = planXFit(data.map((x) => x.label), W, 14 + approxW(fmtNum(max), 9.5) + 12, padR, full, fs, N, true);
  const cw = Math.max(10, W - padL - padR);
  const ch = Math.max(20, H - padT - plan.padB - 6);
  return {
    padL, padT, cw, ch, step, plan, max,
    xOf: (i) => padL + (N > 1 ? step * i : cw / 2),
    yOf: (v) => padT + ch * (1 - v / max),
  };
}
export function paintNeuLine(ctx: Ctx, isArea: boolean, W: number, H: number, d: NeuDraw) {
  const n = neuTones(d.t);
  const { data, colors, p, hover } = d;
  if (!data.length) return;
  const L = neuLineLayout(W, H, data, d.full);
  const { padL, padT, cw, ch, step, plan, xOf, yOf, max } = L;
  const col = colors[0];
  const N = data.length;

  // inset plot panel
  const px0 = padL - 10, py0 = padT - 12, pw = cw + 22, ph = ch + 24;
  insetTrack(ctx, px0, py0, pw, ph, n, 16);
  // dotted grid — aligns to points when few, otherwise a 6-column lattice
  const gcols = N <= 12 ? N : 6;
  ctx.fillStyle = n.grid;
  for (let gx = 0; gx < gcols; gx++) for (let gy = 0; gy <= 3; gy++) {
    const x = N <= 12 ? xOf(gx) : padL + (gx * cw) / 5;
    circle(ctx, x, padT + (gy * ch) / 3, 1.4); ctx.fill();
  }
  // y ticks
  ctx.font = font(d.t, 600, 9.5); ctx.fillStyle = n.muted; ctx.textAlign = 'right';
  for (let g = 0; g <= 3; g++) ctx.fillText(fmtNum((max * g) / 3), padL - 14, padT + ch - (ch * g) / 3 + 3.5);

  const pts = data.map((x, i) => ({ x: xOf(i), y: yOf(x.value) }));
  // reveal left → right while the entrance animation runs (live only)
  const revealing = p < 1 && typeof ctx.clip === 'function';
  if (revealing) { ctx.save(); ctx.beginPath(); ctx.rect(0, 0, padL + cw * p + 10, H); ctx.clip(); }
  const curve = () => {
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
      ctx.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y - (p3.y - p1.y) / 6, p2.x, p2.y);
    }
  };
  if (isArea && N > 1) {
    ctx.beginPath(); curve();
    ctx.lineTo(pts[pts.length - 1].x, padT + ch); ctx.lineTo(pts[0].x, padT + ch); ctx.closePath();
    const g = ctx.createLinearGradient(0, padT, 0, padT + ch);
    g.addColorStop(0, rgba(col, 0.36)); g.addColorStop(1, rgba(col, 0.03));
    ctx.fillStyle = g; ctx.fill();
  }
  if (N > 1) {
    setShadow(ctx, 2, 3, 3, rgba(d.t.ink, 0.28));
    ctx.strokeStyle = col; ctx.lineWidth = N > 40 ? 2.2 : 3.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); curve(); ctx.stroke();
    noShadow(ctx);
    ctx.lineCap = 'butt'; ctx.lineJoin = 'miter';
  }
  // markers thin out automatically; the hovered point is always shown
  const showAll = step >= 12;
  pts.forEach((pt, i) => {
    const on = hover === i;
    if (!showAll && !on) return;
    setShadow(ctx, 1.5, 1.5, 2, rgba(d.t.ink, 0.25));
    ctx.fillStyle = n.surface; circle(ctx, pt.x, pt.y, on ? 7 : step < 26 ? 4.2 : 5.5); ctx.fill();
    noShadow(ctx);
    ctx.strokeStyle = col; ctx.lineWidth = 2.5; ctx.stroke();
  });
  if (revealing) ctx.restore();

  drawXLabels(ctx, data.map((x) => x.label), plan, xOf, padT + ch + 10, d.t, W, 700, n.muted);
}

/* ---- export composition for the neumorphic family ---- */
export function neuExportDims(kind: NeuKind, data: ChartDatum[]): { W: number; H: number } {
  const N = data.length;
  if (kind === 'donut' || kind === 'pie') {
    const total = data.reduce((s, x) => s + x.value, 0) || 1;
    const legW = data.reduce((m, x) => Math.max(m, approxW(x.label, 11.5) + approxW(`  ${x.value} · ${Math.round((x.value / total) * 100)}%`, 11.5)), 0) + 44;
    const cols = Math.max(1, Math.ceil(N / 16));
    return { W: Math.round(Math.max(600, 24 + 340 + 28 + legW * cols + 20)), H: Math.max(400, 60 + Math.min(N, 16) * 20 + 40) };
  }
  if (kind === 'bars') return { W: 640, H: 40 + N * 48 + 16 };
  if (kind === 'columns') return { W: Math.max(640, N * 42 + 60), H: 400 };
  return { W: Math.max(720, N * 24 + 120), H: 400 };
}
export function paintNeuExport(ctx: Ctx, W: number, H: number, kind: NeuKind, d: NeuDraw, title: string) {
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H);
  const top = title ? 40 : 14;
  if (title) { ctx.fillStyle = '#1c2620'; ctx.font = font(d.t, 700, 15, true); ctx.textAlign = 'left'; ctx.fillText(fitCtx(ctx, title, W - 32), 16, 26); }
  if (kind === 'donut' || kind === 'pie') {
    const total = d.data.reduce((s, x) => s + x.value, 0) || 1;
    const S = Math.min(H - top - 16, 340);
    const R = S / 2 - 22;
    const cx = 24 + S / 2, cy = top + (H - top) / 2;
    paintNeuCircular(ctx, kind === 'donut', cx, cy, R, d);
    // legend — right-aligned value column guarantees zero text overlap in SVG vector exports
    const maxLblW = d.data.reduce((m, x) => Math.max(m, approxW(x.label, 11.5)), 0);
    const legW = Math.max(220, maxLblW + 90);
    const x0 = 24 + S + 28;
    d.data.forEach((x, i) => {
      const colI = Math.floor(i / 16), row = i % 16;
      const lx = x0 + colI * legW, ly = top + 26 + row * 22;
      ctx.fillStyle = d.colors[i]; circle(ctx, lx + 4, ly - 4, 4.5); ctx.fill();
      ctx.font = font(d.t, 600, 11.5); ctx.fillStyle = '#1c2620'; ctx.textAlign = 'left';
      ctx.fillText(x.label, lx + 15, ly);
      ctx.fillStyle = '#6b746e'; ctx.textAlign = 'right';
      ctx.fillText(`${x.value} · ${Math.round((x.value / total) * 100)}%`, lx + legW - 10, ly);
      ctx.textAlign = 'left';
    });
  } else {
    ctx.save(); ctx.translate(0, top);
    const h = H - top;
    if (kind === 'bars') paintNeuBars(ctx, W, h, d);
    else if (kind === 'columns') paintNeuColumns(ctx, W, h, d);
    else paintNeuLine(ctx, kind === 'area', W, h, d);
    ctx.restore();
  }
  ctx.textAlign = 'left';
}

/* ---- live canvas for the neumorphic kinds (circular + line/area) ---- */
function NeuCanvas({ kind, data, colors, size, height, centerLabel, hover, onHover, full }: {
  kind: NeuKind; data: ChartDatum[]; colors: string[]; size: number; height: number; centerLabel: string;
  hover: number | null; onHover: (i: number | null) => void; full: boolean;
}) {
  const circular = kind === 'donut' || kind === 'pie';
  const S = size + 36;
  const ref = useRef<HTMLCanvasElement>(null);
  const progRef = useRef(0);
  const amtRef = useRef(0);
  const hovRef = useRef<number | null>(null);
  const rafRef = useRef(0);
  const hovRafRef = useRef(0);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);
  const themeTick = useThemeTick();
  const themeRef = useRef<Theme>(themeColors());
  useEffect(() => { themeRef.current = themeColors(); }, [themeTick]);
  const dataSig = useMemo(() => JSON.stringify(data.map((x) => [x.label, x.value])), [data]);

  const draw = useCallback(() => {
    const cv = ref.current;
    if (!cv) return;
    const W = circular ? S : cv.clientWidth, H = circular ? S : height;
    if (W <= 0 || H <= 0) { requestAnimationFrame(() => draw()); return; }
    const dpr = window.devicePixelRatio || 1;
    const bw = Math.round(W * dpr), bh = Math.round(H * dpr);
    if (cv.width !== bw || cv.height !== bh) { cv.width = bw; cv.height = bh; }
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const d: NeuDraw = { data, colors, t: themeRef.current, p: easeOut(progRef.current), hover: hovRef.current, amt: amtRef.current, centerLabel, full };
    if (circular) paintNeuCircular(ctx, kind === 'donut', W / 2, H / 2, size / 2 - 4, d);
    else paintNeuLine(ctx, kind === 'area', W, H, d);
  }, [circular, S, height, data, colors, centerLabel, full, kind, size]);

  /* entrance sweep / draw-in */
  useEffect(() => {
    cancelAnimationFrame(rafRef.current);
    progRef.current = 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      progRef.current = Math.min(1, (now - t0) / 900);
      draw();
      if (progRef.current < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, dataSig]);

  /* hover amount animation */
  useEffect(() => {
    const goal = hover !== null ? 1 : 0;
    if (hover !== null) {
      // moving straight from one slice to another re-plays part of the pop
      if (hovRef.current !== null && hovRef.current !== hover) amtRef.current = Math.min(amtRef.current, 0.35);
      hovRef.current = hover;
    }
    cancelAnimationFrame(hovRafRef.current);
    const tick = () => {
      const diff = goal - amtRef.current;
      if (Math.abs(diff) < 0.02) {
        amtRef.current = goal;
        if (goal === 0) hovRef.current = null;
        if (progRef.current >= 1) draw();
        return;
      }
      amtRef.current += diff * 0.22;
      if (progRef.current >= 1) draw();
      hovRafRef.current = requestAnimationFrame(tick);
    };
    hovRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(hovRafRef.current);
  }, [hover, draw]);

  useEffect(() => { if (progRef.current >= 1) draw(); }, [themeTick, draw]);
  useEffect(() => {
    const cv = ref.current;
    let ro: ResizeObserver | null = null;
    if (cv && typeof ResizeObserver !== 'undefined') { ro = new ResizeObserver(() => draw()); ro.observe(cv); }
    window.addEventListener('resize', draw);
    return () => { ro?.disconnect(); window.removeEventListener('resize', draw); };
  }, [draw]);

  const hit = (e: React.MouseEvent) => {
    const cv = ref.current;
    if (!cv || !data.length) return;
    const r = cv.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    let idx: number | null = null;
    if (circular) {
      const R = size / 2 - 4, rIn = kind === 'donut' ? R * 0.56 : 0;
      const ex = mx - S / 2, ey = my - S / 2;
      const rad = Math.hypot(ex, ey);
      if (rad <= R + 8 && rad >= Math.max(0, rIn - 6)) {
        const total = data.reduce((s, x) => s + x.value, 0) || 1;
        let ang = Math.atan2(ey, ex) + Math.PI / 2;
        ang = ((ang % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        let acc = 0;
        for (let i = 0; i < data.length; i++) { acc += (data[i].value / total) * Math.PI * 2; if (ang <= acc) { idx = i; break; } }
      }
      onHover(idx);
      setTip(null);
    } else {
      const L = neuLineLayout(r.width, height, data, full);
      let best = Math.max(10, L.step / 2), bi: number | null = null;
      data.forEach((_, i) => { const dd = Math.abs(mx - L.xOf(i)); if (dd < best) { best = dd; bi = i; } });
      idx = bi;
      onHover(idx);
      if (idx !== null) {
        const px = L.xOf(idx), py = L.yOf(data[idx].value);
        setTip({ x: Math.max(4, Math.min(r.width - 150, px - 50)), y: Math.max(0, py - 40), text: `${data[idx].label}: ${data[idx].value}` });
      } else setTip(null);
    }
  };

  return (
    <div className="relative shrink-0" style={circular ? { width: S, height: S } : { width: '100%', height }}>
      <canvas ref={ref} style={{ width: '100%', height: '100%', display: 'block', cursor: 'pointer' }}
        onMouseMove={hit} onMouseLeave={() => { onHover(null); setTip(null); }} />
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 px-2.5 py-1 font-body text-[11px] font-bold text-ink" style={{ left: tip.x, top: tip.y }}>
          {tip.text}
        </div>
      )}
    </div>
  );
}

export function NeuChart({ data, title, defaultKind = 'donut', size = 158, centerLabel = 'total', legendSide = false, loading = false, isFullscreen = false }: {
  data: ChartDatum[]; title?: string; defaultKind?: NeuKind; size?: number; centerLabel?: string; legendSide?: boolean; loading?: boolean; isFullscreen?: boolean;
}) {
  const [kind, setKind] = useState<NeuKind>(defaultKind);
  const [hover, setHover] = useState<number | null>(null);
  const [full, setFull] = useState(false);
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const max = Math.max(...data.map((d) => d.value), 1);
  const themeTick = useThemeTick();
  const pal = useMemo(() => activePalette(), [themeTick]); // eslint-disable-line react-hooks/exhaustive-deps
  const colors = useMemo(() => data.map((d, i) => d.color || pal[i % pal.length]), [data, pal]);
  const dataSig = useMemo(() => JSON.stringify(data.map((x) => [x.label, x.value])), [data]);
  const circular = kind === 'donut' || kind === 'pie';

  const doExport = async (fmt: string) => {
    const base = (title || 'chart').toLowerCase().replace(/\s+/g, '-');
    if (fmt === 'csv') {
      downloadBlob(`${base}.csv`, new Blob(['label,value\n' + data.map((d) => `"${d.label}",${d.value}`).join('\n')], { type: 'text/csv' }));
      return;
    }
    if (fmt === 'json') {
      downloadBlob(`${base}.json`, new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      return;
    }
    if (fmt === 'excel') {
      const ExcelJS = await loadExcelJS();
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet('Data');
      const head = ws.addRow(['Label', 'Value']);
      head.eachCell((cell: { font: unknown; fill: unknown }) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
      });
      data.forEach((d) => ws.addRow([d.label, d.value]));
      ws.getColumn(1).width = 24;
      const buf = await wb.xlsx.writeBuffer();
      downloadBlob(`${base}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      return;
    }
    await fontsReady();
    const t = themeColors(true);
    const { W, H } = neuExportDims(kind, data);
    const d: NeuDraw = { data, colors, t, p: 1, hover: null, amt: 0, centerLabel, full: true };
    if (fmt === 'svg') {
      const rec = new SvgCtx(W, H);
      rec.fontCss = await fontFaceCss(fontFamilies(t), ['600', '700']);
      paintNeuExport(rec as unknown as Ctx, W, H, kind, d, title || 'Chart');
      downloadBlob(`${base}.svg`, new Blob([rec.toString()], { type: 'image/svg+xml' }));
      return;
    }
    const scale = 3;
    const cv = document.createElement('canvas');
    cv.width = W * scale; cv.height = H * scale;
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    paintNeuExport(ctx, W, H, kind, d, title || 'Chart');
    if (fmt === 'png') cv.toBlob((b) => b && downloadBlob(`${base}.png`, b), 'image/png');
    else if (fmt === 'pdf') {
      const dataUrl = cv.toDataURL('image/jpeg', 0.94);
      const bytes = Uint8Array.from(atob(dataUrl.split(',')[1]), (c) => c.charCodeAt(0));
      downloadBlob(`${base}.pdf`, jpegToPdf(bytes, cv.width, cv.height));
    } else if (fmt === 'print') printCanvas(title || 'Chart', cv);
  };

  /* ---- horizontal soft bars (DOM, CSS-grown on entrance) ---- */
  const bars = (
    <div key={`bars-${dataSig}`} className="w-full space-y-3">
      {data.map((d, i) => (
        <div key={d.label} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
          <div className="mb-1 flex justify-between font-body text-[11.5px]">
            <span className={`font-semibold ${hover === i ? 'text-ink' : 'text-ink/75'}`}>{d.label}</span>
            <span className="font-bold tabular-nums text-ink">{d.value}</span>
          </div>
          <div className="tk-inset h-4 overflow-hidden rounded-full">
            <div className="tk-grow-w h-full rounded-full transition-[filter] duration-300"
              style={{
                width: `${(d.value / max) * 100}%`, animationDelay: `${i * 70}ms`,
                background: `linear-gradient(145deg, ${shade(colors[i], 1.08)}, ${shade(colors[i], 0.8)})`,
                boxShadow: '1px 1px 3px rgba(0,0,0,0.25), inset 0 1px 1px rgba(255,255,255,0.4)',
                filter: hover === i ? 'brightness(1.12)' : hover !== null ? 'saturate(0.6) opacity(0.7)' : undefined,
              }} />
          </div>
        </div>
      ))}
    </div>
  );

  /* ---- vertical soft columns (DOM, CSS-grown on entrance, adaptive labels) ---- */
  const columns = (() => {
    const N = Math.max(1, data.length);
    const rotate = N > 6;
    return (
      <div key={`cols-${dataSig}`} className="w-full">
        <div className="flex w-full items-end justify-around gap-1.5" style={{ height: size + 24 }}>
          {data.map((d, i) => (
            <div key={d.label} className="flex min-w-0 flex-1 flex-col items-center gap-1.5"
              onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              <span className="font-body text-[10.5px] font-bold tabular-nums text-ink/70">{d.value}</span>
              <div className="tk-inset flex w-full max-w-[44px] items-end overflow-hidden rounded-xl" style={{ height: size - 10 }}>
                <div className="tk-grow-h w-full rounded-xl transition-[filter] duration-300"
                  style={{
                    height: `${(d.value / max) * 100}%`, animationDelay: `${i * 70}ms`,
                    background: `linear-gradient(145deg, ${shade(colors[i], 1.08)}, ${shade(colors[i], 0.8)})`,
                    boxShadow: 'inset 0 2px 2px rgba(255,255,255,0.35), 0 -1px 3px rgba(0,0,0,0.15)',
                    filter: hover === i ? 'brightness(1.12)' : hover !== null ? 'saturate(0.6) opacity(0.7)' : undefined,
                  }} />
              </div>
            </div>
          ))}
        </div>
        <div className="mt-1.5 flex w-full justify-around gap-1.5" style={{ height: rotate ? 52 : 16 }}>
          {data.map((d, i) => (
            <div key={d.label} className="flex min-w-0 flex-1 justify-center">
              <span data-tip={d.label} title={d.label}
                className={`font-body text-[9.5px] font-bold uppercase tracking-wide ${hover === i ? 'text-ink' : 'text-muted'} ${rotate ? 'origin-top-right whitespace-nowrap' : 'w-full truncate text-center'}`}
                style={rotate ? { maxWidth: 64, overflow: 'hidden', textOverflow: 'ellipsis', transform: 'translateX(-50%) rotate(-45deg)' } : undefined}>
                {rotate ? d.label : fitText(d.label, 52, 9.5)}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  })();

  const containerRef = useRef<HTMLDivElement>(null);
  const [isFs, setIsFs] = useState(false);

  useEffect(() => {
    const onFs = () => {
      const active = !!document.fullscreenElement && document.fullscreenElement === containerRef.current;
      setIsFs(active);
    };
    document.addEventListener('fullscreenchange', onFs);
    document.addEventListener('webkitfullscreenchange', onFs);
    return () => {
      document.removeEventListener('fullscreenchange', onFs);
      document.removeEventListener('webkitfullscreenchange', onFs);
    };
  }, []);

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      try {
        if (containerRef.current?.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        } else if ((containerRef.current as unknown as { webkitRequestFullscreen?: () => Promise<void> })?.webkitRequestFullscreen) {
          await (containerRef.current as unknown as { webkitRequestFullscreen: () => Promise<void> }).webkitRequestFullscreen();
        }
        setIsFs(true);
      } catch {
        setFull(true);
      }
    } else {
      try {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as unknown as { webkitExitFullscreen?: () => Promise<void> })?.webkitExitFullscreen) {
          await (document as unknown as { webkitExitFullscreen: () => Promise<void> }).webkitExitFullscreen();
        }
      } catch { /* noop */ }
      setIsFs(false);
      setFull(false);
    }
  };

  const legendEl = (
    <div className={legendSide && circular ? 'min-w-0 flex-1 space-y-2' : 'mt-3 flex flex-wrap justify-center gap-x-4 gap-y-1.5'}>
      {data.map((d, i) => {
        const pct = Math.round((d.value / total) * 100);
        const on = hover === i;
        return (
          <button key={d.label} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}
            className={`flex items-center gap-2 font-body text-[11.5px] font-semibold transition ${on ? 'text-ink' : 'text-ink/75'} ${legendSide && circular ? 'w-full pr-1' : ''}`}>
            <span className="flex min-w-0 flex-1 items-center gap-2">
              <span className="h-2.5 w-2.5 shrink-0 rounded-full transition-shadow"
                style={{ background: colors[i], boxShadow: on ? `0 0 0 3px ${rgba(colors[i], 0.22)}` : '0.5px 0.5px 1.5px rgba(0,0,0,0.3)' }} />
              <span className="truncate">{d.label}</span>
              <span className="shrink-0 text-muted text-[10.5px]">({pct}%)</span>
            </span>
            {legendSide && circular && (
              <span className="ml-2 shrink-0 tabular-nums font-bold text-ink/80 text-[11px] px-2 py-0.5 rounded-md bg-black/5 dark:bg-white/10">{d.value}</span>
            )}
          </button>
        );
      })}
    </div>
  );

  const canvasEl = (
    <NeuCanvas kind={kind} data={data} colors={colors} size={isFs ? Math.min(380, window.innerHeight - 240) : size} height={isFs ? Math.min(420, window.innerHeight - 200) : size + 40} centerLabel={centerLabel}
      hover={hover} onHover={setHover} full={isFullscreen || isFs} />
  );

  const body = (
    <div ref={containerRef} className={`tk-card ${isFs ? '!fixed !inset-0 !z-[100] !w-screen !h-screen !m-0 !rounded-none !p-6 sm:!p-10 flex flex-col justify-between overflow-auto bg-(--t-surface)' : 'p-4'}`}>
      <div className="mb-3 flex flex-wrap items-center gap-2 relative z-50">
        {title && <p className={`mr-auto font-display font-semibold text-ink ${isFs ? 'text-xl' : 'text-[14px]'}`}>{title}</p>}
        <MiniDrop label={NEU_KINDS.find((k) => k.key === kind)!.label} activeKey={kind}
          items={NEU_KINDS.map((k) => ({ key: k.key, label: k.label }))}
          onPick={(k) => { setKind(k as NeuKind); setHover(null); }} />
        <MiniDrop label="Export" icon={<Download size={12} />}
          items={[
            { key: 'png', label: 'PNG image' },
            { key: 'svg', label: 'SVG vector' },
            { key: 'pdf', label: 'PDF document' },
            { key: 'excel', label: 'Excel workbook' },
            { key: 'print', label: 'Print…' },
            { key: 'csv', label: 'CSV data' },
            { key: 'json', label: 'JSON data' },
          ]}
          onPick={doExport} />
        {!isFullscreen && (
          <button onClick={toggleFullscreen} data-tip={isFs ? "Exit fullscreen" : "View fullscreen"} className="tk-btn-ghost rounded-xl p-2">
            {isFs ? <Minimize2 size={15} /> : <Eye size={14} />}
          </button>
        )}
      </div>

      {loading ? (
        <ChartSkeleton kind={circular ? 'circle' : kind === 'bars' ? 'bars' : kind === 'columns' ? 'columns' : 'line'} height={size + 40} legend={legendSide && circular} />
      ) : data.length === 0 ? (
        <div className="flex items-center justify-center font-body text-[12.5px] text-muted" style={{ minHeight: size + 40 }}>No data to chart.</div>
      ) : circular ? (
        legendSide
          ? <div className={`flex items-center gap-6 ${isFs ? 'max-w-4xl mx-auto w-full my-auto' : ''}`}>{canvasEl}{legendEl}</div>
          : <div className={`flex flex-col items-center ${isFs ? 'my-auto' : ''}`}>{canvasEl}{legendEl}</div>
      ) : kind === 'bars' ? bars
        : kind === 'columns' ? columns
        : canvasEl}
    </div>
  );

  return (
    <>
      {body}
      {full && createPortal(
        <div className="fixed inset-0 z-[100] flex flex-col bg-(--t-surface) p-6 sm:p-10 backdrop-blur-md overflow-auto"
          onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) setFull(false); }}>
          <div className="mb-3 flex justify-between items-center">
            {title && <h2 className="font-display text-xl font-bold text-ink">{title}</h2>}
            <button onClick={() => setFull(false)} className="tk-btn-ghost rounded-full p-2.5 ml-auto"><X size={18} /></button>
          </div>
          <div className="flex-1 w-full flex items-center justify-center">
            <NeuChart data={data} title={title} defaultKind={kind}
              size={Math.max(240, Math.min(380, window.innerHeight - 300))} centerLabel={centerLabel} legendSide isFullscreen />
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

/* compat wrappers */
export function NeuDonut(props: { data: ChartDatum[]; title?: string; size?: number; centerLabel?: string; legendSide?: boolean; loading?: boolean }) {
  return <NeuChart {...props} defaultKind="donut" />;
}
export function NeuBars({ data, title, loading }: { data: ChartDatum[]; title?: string; loading?: boolean }) {
  return <NeuChart data={data} title={title} defaultKind="bars" loading={loading} />;
}


