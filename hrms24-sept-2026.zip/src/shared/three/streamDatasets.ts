/* Dynamic streamgraph test datasets — used by the "Dataset" dropdown on the
 * Streamgraph (Dynamic) chart. Each plots in the exact Olympic river-flow
 * language via buildStreamModel(). Every dataset is DENSE (many stacked
 * cohorts over 10 time steps) so the river meanders and layers richly like
 * the source Olympic chart — these exist to test the chart to its fullest.
 *
 * The first (employee_lifecycle) models a real org over 10 years. Column
 * sums start at 15 active people and finish above 50, with a mid-period
 * layoff dip, boomerang rejoiners, a bonus year, a salary-cut cohort and
 * contract/flex hires. Because of churn, well over 80 distinct employees
 * pass through the lifecycle across the decade. */

export interface StreamDynSeries { name: string; color: string; values: number[] }
export interface StreamDynEvent { at: number; label: string; detail?: string }
export interface StreamDynDataset {
  key: string;
  label: string;
  title: string;
  categories: string[];
  series: StreamDynSeries[];
  events: StreamDynEvent[];
}

const YEARS = ['2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'];
const QUARTERS = ['Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7', 'Q8', 'Q9', 'Q10'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'];

/* ---- 1. Employee lifecycle — EACH EMPLOYEE IS ITS OWN RIBBON ----
   Instead of a handful of department cohorts, every individual employee is
   modelled as a separate ribbon that appears at their hire year and vanishes
   when they leave (some rejoin later as boomerangs). A ribbon's thickness is
   the person's salary band, which nudges up each year of tenure and drops on
   a salary cut. This is the Olympic-streamgraph treatment (one lane per
   nation) applied to headcount: the river's active-lane COUNT is the live
   employee count, so it starts at 15+ and finishes above 50, with visible
   new-hire lanes opening, departures closing and boomerang lanes re-opening.
   Generated deterministically so the roster is stable across reloads. */
function buildEmployeeLifecycle(): StreamDynDataset {
  const N_YEARS = YEARS.length;
  // deterministic PRNG (LCG) — stable roster every load
  let seed = 20260923;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };
  const pick = <T,>(a: T[]) => a[Math.floor(rnd() * a.length)];

  const FIRST = ['Ananya', 'Arjun', 'Priya', 'Rahul', 'Sneha', 'Vikram', 'Kavya', 'Rohan', 'Meera', 'Aditya', 'Divya', 'Karthik', 'Isha', 'Nikhil', 'Riya', 'Varun', 'Aditi', 'Sameer', 'Neha', 'Yash', 'Pooja', 'Dev', 'Tara', 'Kabir', 'Sara', 'Omar', 'Lena', 'Noah', 'Grace', 'Ethan', 'Zara', 'Leo', 'Maya', 'Ivan', 'Nadia', 'Hugo'];
  const LAST = ['Sharma', 'Rao', 'Mehta', 'Iyer', 'Nair', 'Patel', 'Reddy', 'Gupta', 'Menon', 'Verma', 'Singh', 'Bose', 'Kapoor', 'Pillai', 'Khan', 'Bennett', 'Tan', 'Rossi', 'Silva', 'Novak'];
  const DEPT_COLORS = ['#0d7a54', '#1e5aa8', '#3b82f6', '#0ea5e9', '#06b6d4', '#c9932b', '#e11d63', '#14b8a6', '#84cc16', '#a16207', '#f97316', '#8b5cf6', '#ef4444', '#22c55e', '#eab308'];

  interface Emp { name: string; color: string; join: number; leave: number | null; rejoin: number | null; band: number; cut: boolean }
  const emps: Emp[] = [];
  const usedNames = new Set<string>();
  const mkName = () => { let n = ''; do { n = `${pick(FIRST)} ${pick(LAST)}`; } while (usedNames.has(n)); usedNames.add(n); return n; };
  const addEmp = (join: number, opts: Partial<Emp> = {}) => {
    emps.push({
      name: mkName(), color: pick(DEPT_COLORS), join,
      leave: opts.leave ?? null, rejoin: opts.rejoin ?? null,
      band: opts.band ?? (1 + Math.floor(rnd() * 3)), // salary band 1..3
      cut: opts.cut ?? false,
    });
  };

  // 16 founders/early staff present from year 0; a few will churn out.
  for (let i = 0; i < 16; i++) {
    const churn = rnd() < 0.35;
    addEmp(0, churn ? { leave: 4 + Math.floor(rnd() * 5), rejoin: rnd() < 0.35 ? 7 + Math.floor(rnd() * 2) : null } : {});
  }
  // Per-year hiring waves sized so the ACTIVE count climbs 15 → 50+.
  const HIRES = [0, 6, 8, 9, 10, 4, 9, 11, 10, 9]; // year 0 already seeded above
  for (let y = 1; y < N_YEARS; y++) {
    for (let k = 0; k < HIRES[y]; k++) {
      // most hires stay; some are short contracts or later departures
      const roll = rnd();
      if (roll < 0.18 && y < N_YEARS - 1) addEmp(y, { leave: y + 1 + Math.floor(rnd() * 2) }); // contract / early exit
      else if (roll < 0.34 && y < N_YEARS - 2) addEmp(y, { leave: y + 2 + Math.floor(rnd() * 3), rejoin: rnd() < 0.3 ? N_YEARS - 1 : null });
      else addEmp(y);
    }
  }
  // Year-5 downturn: a slice of tenured staff leave (layoff); some rejoin later.
  emps.forEach((e) => {
    if (e.join <= 3 && e.leave === null && rnd() < 0.22) {
      e.leave = 5;
      if (rnd() < 0.5) e.rejoin = 7 + Math.floor(rnd() * 2);
      e.cut = true;
    }
  });

  const activeAt = (e: Emp, y: number) => {
    if (y < e.join) return false;
    if (e.leave !== null && y >= e.leave && (e.rejoin === null || y < e.rejoin)) return false;
    return true;
  };
  // salary band grows with tenure, dips the year of a cut
  const valueAt = (e: Emp, y: number): number => {
    if (!activeAt(e, y)) return 0;
    const base = e.rejoin !== null && y >= e.rejoin ? e.rejoin : e.join;
    const tenure = y - base;
    let v = e.band + tenure * 0.35;
    if (e.cut && y === 5) v *= 0.7;
    return Math.max(0.6, +v.toFixed(2));
  };

  const series: StreamDynSeries[] = emps.map((e) => ({
    name: e.name,
    color: e.color,
    values: YEARS.map((_, y) => valueAt(e, y)),
  }));
  // keep only employees that are ever active (all are, but guard anyway)
  const live = series.filter((s) => s.values.some((v) => v > 0));

  return {
    key: 'employee_lifecycle',
    label: 'Employee lifecycle (per-employee, 15 → 50+)',
    title: 'Employee lifecycle · one ribbon per employee (hires, exits, rejoins), 2016–2025',
    categories: YEARS,
    series: live,
    events: [
      { at: 1, label: 'GTM founded', detail: 'First hiring wave joins' },
      { at: 4, label: 'Hiring wave', detail: 'Peak intake before downturn' },
      { at: 5, label: 'Layoff period', detail: 'Tenured lanes close; salary cuts' },
      { at: 6, label: 'Boomerangs return', detail: 'Alumni lanes re-open' },
      { at: 7, label: 'Bonus year', detail: 'Bands step up across the roster' },
      { at: 9, label: 'Contract hiring', detail: 'Flex lanes open at the edges' },
    ],
  };
}

export const EMPLOYEE_LIFECYCLE: StreamDynDataset = buildEmployeeLifecycle();

/* ---- 2. Product adoption by plan tier (active accounts, thousands) ---- */
export const PRODUCT_ADOPTION: StreamDynDataset = {
  key: 'product_adoption',
  label: 'Product adoption by plan tier',
  title: 'Active accounts by plan tier (thousands), Q1–Q10',
  categories: QUARTERS,
  series: [
    { name: 'Free', color: '#38bdf8', values: [12, 18, 26, 34, 40, 44, 52, 58, 63, 70] },
    { name: 'Starter', color: '#0ea5e9', values: [5, 8, 11, 15, 18, 21, 25, 29, 32, 36] },
    { name: 'Pro', color: '#1e5aa8', values: [3, 5, 8, 12, 16, 19, 24, 29, 33, 38] },
    { name: 'Team', color: '#0d7a54', values: [1, 2, 4, 6, 9, 12, 15, 18, 22, 26] },
    { name: 'Business', color: '#14b8a6', values: [0, 1, 2, 4, 6, 9, 12, 16, 20, 24] },
    { name: 'Enterprise', color: '#a855f7', values: [0, 1, 1, 2, 4, 6, 8, 11, 14, 18] },
    { name: 'Education', color: '#8b5cf6', values: [1, 2, 3, 4, 5, 6, 8, 9, 11, 13] },
    { name: 'Trial (converting)', color: '#f97316', values: [4, 6, 7, 8, 6, 9, 10, 8, 11, 12] },
    { name: 'Churned (win-back)', color: '#ef4444', values: [0, 1, 2, 3, 5, 4, 5, 6, 7, 8] },
  ],
  events: [
    { at: 2, label: 'Pro launch', detail: 'Paid tier introduced' },
    { at: 5, label: 'Enterprise GA', detail: 'Large accounts onboard' },
    { at: 8, label: 'PLG motion', detail: 'Self-serve conversions rise' },
  ],
};

/* ---- 3. Cloud spend by service (₹ lakh / month) ---- */
export const CLOUD_SPEND: StreamDynDataset = {
  key: 'cloud_spend',
  label: 'Cloud spend by service',
  title: 'Monthly cloud spend by service (₹L), Jan–Oct',
  categories: MONTHS,
  series: [
    { name: 'Compute (VMs)', color: '#1e5aa8', values: [18, 20, 24, 30, 36, 33, 40, 46, 52, 58] },
    { name: 'Serverless', color: '#3b82f6', values: [3, 4, 6, 8, 11, 12, 15, 18, 22, 26] },
    { name: 'Object Storage', color: '#0ea5e9', values: [8, 9, 11, 13, 15, 16, 19, 22, 25, 28] },
    { name: 'Databases', color: '#a855f7', values: [6, 7, 9, 11, 13, 14, 16, 19, 21, 24] },
    { name: 'Networking / CDN', color: '#0d7a54', values: [4, 5, 6, 7, 9, 10, 12, 13, 15, 17] },
    { name: 'Analytics / Warehouse', color: '#14b8a6', values: [2, 3, 5, 7, 9, 11, 13, 16, 19, 22] },
    { name: 'AI / GPU', color: '#f97316', values: [0, 1, 2, 4, 8, 12, 18, 26, 34, 44] },
    { name: 'Observability', color: '#eab308', values: [2, 3, 3, 4, 5, 6, 7, 8, 9, 10] },
    { name: 'Security', color: '#ef4444', values: [3, 3, 4, 5, 6, 7, 8, 9, 10, 11] },
  ],
  events: [
    { at: 4, label: 'Traffic spike', detail: 'Compute scale-out' },
    { at: 6, label: 'ML platform', detail: 'GPU spend accelerates' },
    { at: 9, label: 'Cost review', detail: 'FinOps optimisation begins' },
  ],
};

/* ---- 4. Support tickets by channel (thousands / month) ---- */
export const SUPPORT_TICKETS: StreamDynDataset = {
  key: 'support_tickets',
  label: 'Support tickets by channel',
  title: 'Monthly support volume by channel (000s), Jan–Oct',
  categories: MONTHS,
  series: [
    { name: 'Email', color: '#64748b', values: [14, 15, 16, 15, 14, 13, 12, 11, 10, 9] },
    { name: 'Live Chat', color: '#0ea5e9', values: [4, 6, 8, 11, 14, 16, 19, 22, 24, 26] },
    { name: 'Phone', color: '#1e5aa8', values: [8, 8, 7, 7, 6, 6, 5, 5, 4, 4] },
    { name: 'Social', color: '#a855f7', values: [2, 3, 3, 4, 5, 5, 6, 7, 8, 9] },
    { name: 'Community Forum', color: '#8b5cf6', values: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] },
    { name: 'In-App', color: '#14b8a6', values: [2, 3, 5, 6, 8, 9, 11, 12, 14, 16] },
    { name: 'WhatsApp', color: '#22c55e', values: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] },
    { name: 'Self-serve (deflected)', color: '#0d7a54', values: [3, 5, 7, 10, 13, 17, 21, 25, 30, 35] },
  ],
  events: [
    { at: 3, label: 'Chat rollout', detail: 'Live chat opened' },
    { at: 6, label: 'Help center', detail: 'Self-serve deflection grows' },
    { at: 9, label: 'AI assistant', detail: 'Automated resolutions' },
  ],
};

/* ---- 5. Revenue by region (₹ crore / quarter) ---- */
export const REVENUE_REGION: StreamDynDataset = {
  key: 'revenue_region',
  label: 'Revenue by region',
  title: 'Quarterly revenue by region (₹Cr), Q1–Q10',
  categories: QUARTERS,
  series: [
    { name: 'North America', color: '#1e5aa8', values: [10, 13, 17, 22, 26, 24, 30, 36, 41, 46] },
    { name: 'Western Europe', color: '#3b82f6', values: [6, 8, 11, 14, 17, 16, 20, 24, 28, 32] },
    { name: 'Eastern Europe', color: '#0ea5e9', values: [2, 3, 4, 6, 8, 8, 10, 12, 14, 17] },
    { name: 'India', color: '#f59e0b', values: [3, 5, 7, 10, 13, 15, 19, 23, 28, 34] },
    { name: 'APAC (ex-India)', color: '#14b8a6', values: [2, 4, 6, 8, 11, 13, 16, 20, 24, 29] },
    { name: 'LATAM', color: '#f97316', values: [1, 2, 3, 4, 5, 6, 7, 9, 11, 13] },
    { name: 'Middle East', color: '#a855f7', values: [0, 1, 2, 3, 4, 5, 6, 8, 10, 12] },
    { name: 'Africa', color: '#84cc16', values: [0, 1, 1, 2, 3, 4, 5, 6, 7, 9] },
  ],
  events: [
    { at: 3, label: 'APAC expansion', detail: 'Singapore + India GTM' },
    { at: 5, label: 'Macro slowdown', detail: 'NA growth softens' },
    { at: 8, label: 'India overtakes EU', detail: 'Fastest-growing region' },
  ],
};

/* ---- 6. Website traffic by source (visits, millions / month) ---- */
export const TRAFFIC_SOURCE: StreamDynDataset = {
  key: 'traffic_source',
  label: 'Website traffic by source',
  title: 'Monthly visits by acquisition source (M), Jan–Oct',
  categories: MONTHS,
  series: [
    { name: 'Organic Search', color: '#0d7a54', values: [6, 7, 9, 11, 13, 14, 17, 19, 22, 25] },
    { name: 'Paid Search', color: '#f59e0b', values: [3, 4, 5, 6, 6, 5, 7, 8, 8, 9] },
    { name: 'Paid Social', color: '#f97316', values: [2, 3, 4, 5, 4, 3, 5, 6, 5, 7] },
    { name: 'Organic Social', color: '#0ea5e9', values: [3, 4, 6, 8, 11, 13, 15, 18, 20, 23] },
    { name: 'Referral', color: '#a855f7', values: [2, 2, 3, 4, 5, 5, 6, 7, 8, 9] },
    { name: 'Direct', color: '#1e5aa8', values: [4, 5, 5, 6, 7, 8, 9, 10, 11, 12] },
    { name: 'Email', color: '#64748b', values: [1, 2, 3, 3, 4, 5, 5, 6, 7, 8] },
    { name: 'Affiliate', color: '#14b8a6', values: [0, 1, 1, 2, 3, 3, 4, 5, 6, 7] },
    { name: 'App Store', color: '#8b5cf6', values: [0, 1, 2, 2, 3, 4, 5, 6, 7, 8] },
  ],
  events: [
    { at: 2, label: 'SEO investment', detail: 'Content engine live' },
    { at: 5, label: 'Viral campaign', detail: 'Social surges' },
    { at: 8, label: 'Brand growth', detail: 'Direct + organic compound' },
  ],
};

export const STREAM_DYN_DATASETS: StreamDynDataset[] = [
  EMPLOYEE_LIFECYCLE,
  PRODUCT_ADOPTION,
  CLOUD_SPEND,
  SUPPORT_TICKETS,
  REVENUE_REGION,
  TRAFFIC_SOURCE,
];
