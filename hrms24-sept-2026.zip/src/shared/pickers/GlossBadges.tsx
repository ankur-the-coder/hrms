import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

/* ============================================================
   GlossBadges — a transparent Three.js overlay that draws glossy 3D coral
   spheres exactly on the calendar's selected start/end date cells, a faithful
   port of the gloss layer in neumorphicGlossyDatepicker.html:
     - OrthographicCamera in CSS-pixel units (positions map 1:1 to the DOM)
     - RoomEnvironment via PMREM for studio reflections ("the shine")
     - a warm top-left key light + a pointer-following shine light
     - MeshPhysicalMaterial { color 0xff5535, roughness .18, clearcoat 1,
       clearcoatRoughness .04 } flattened to a low dome (scale.z 0.6)
   The badge DOM keeps its number (engraved), its fill is made transparent via
   the `.gloss-on` class so the 3D ball shows through. Render-on-demand only.
   ============================================================ */
export default function GlossBadges({ hostRef, badgeSelector = '.cal-badge' }: {
  hostRef: React.RefObject<HTMLElement | null>;
  badgeSelector?: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const host = hostRef.current;
    const canvas = canvasRef.current;
    if (!host || !canvas) return;
    host.classList.add('gloss-on');

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    } catch {
      return; // no WebGL → CSS fallback badge stays visible
    }
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

    const camera = new THREE.OrthographicCamera(0, 1, 0, -1, 1, 2000);
    camera.position.z = 600;

    const key = new THREE.DirectionalLight(0xfff4ea, 2.0);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0005;
    scene.add(key, key.target);

    const shine = new THREE.DirectionalLight(0xffffff, 1.1);
    scene.add(shine, shine.target);

    const catcher = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShadowMaterial({ color: 0x7a3a20, opacity: 0.3 }));
    catcher.receiveShadow = true;
    scene.add(catcher);

    const badgeMat = new THREE.MeshPhysicalMaterial({
      color: 0xff5535, roughness: 0.18, metalness: 0.0,
      clearcoat: 1.0, clearcoatRoughness: 0.04, envMapIntensity: 1.3,
    });
    const group = new THREE.Group();
    scene.add(group);

    let W = 0, H = 0, raf = 0, pending = 0;
    const draw = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => renderer.render(scene, camera)); };
    const resize = () => {
      const r = host.getBoundingClientRect();
      W = Math.max(1, r.width); H = Math.max(1, r.height);
      renderer.setSize(W, H, false);
      camera.right = W; camera.bottom = -H; camera.updateProjectionMatrix();
      catcher.scale.set(W, H, 1);
      catcher.position.set(W / 2, -H / 2, -14);
      const c = new THREE.Vector3(W / 2, -H / 2, 0);
      key.target.position.copy(c);
      key.position.set(c.x - 260, c.y + 260, 380);
      const s = key.shadow.camera, m = Math.max(W, H);
      s.left = -m; s.right = m; s.top = m; s.bottom = -m; s.near = 1; s.far = 1500;
      s.updateProjectionMatrix();
      shine.target.position.copy(c);
      shine.position.set(c.x - 120, c.y + 160, 300);
    };
    const rebuild = () => {
      const c = host.getBoundingClientRect();
      if (c.width !== W || c.height !== H) resize();
      group.children.forEach((m) => (m as THREE.Mesh).geometry.dispose());
      group.clear();
      host.querySelectorAll(badgeSelector).forEach((el) => {
        const r = (el as HTMLElement).getBoundingClientRect();
        const rad = Math.max(8, Math.min(r.width, r.height) / 2);
        const mesh = new THREE.Mesh(new THREE.SphereGeometry(rad, 40, 28), badgeMat);
        mesh.scale.z = 0.6;
        mesh.position.set((r.left + r.right) / 2 - c.left, -((r.top + r.bottom) / 2 - c.top), 4);
        mesh.castShadow = mesh.receiveShadow = true;
        group.add(mesh);
      });
      draw();
    };
    const schedule = () => { cancelAnimationFrame(pending); pending = requestAnimationFrame(rebuild); };

    const mo = new MutationObserver(schedule);
    mo.observe(host, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    const ro = new ResizeObserver(schedule);
    ro.observe(host);
    const onMove = (e: PointerEvent) => {
      const r = host.getBoundingClientRect();
      shine.position.set(e.clientX - r.left, -(e.clientY - r.top), 260);
      draw();
    };
    host.addEventListener('pointermove', onMove);

    resize(); rebuild();

    return () => {
      cancelAnimationFrame(raf); cancelAnimationFrame(pending);
      mo.disconnect(); ro.disconnect();
      host.removeEventListener('pointermove', onMove);
      host.classList.remove('gloss-on');
      group.children.forEach((m) => (m as THREE.Mesh).geometry.dispose());
      badgeMat.dispose(); pmrem.dispose(); renderer.dispose();
    };
  }, [hostRef, badgeSelector]);

  return <canvas ref={canvasRef} className="gloss-canvas" aria-hidden />;
}
