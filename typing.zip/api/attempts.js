import supabase from './db-client.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function getUser(req) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return null;
  const { data: { user } } = await supabase.auth.getUser(token);
  return user;
}

const defaults = {
  mistake_weight: 22, slow_weight: 10, clean_fast_gain: 20, clean_gain: 10,
  mastery_threshold: 80, clean_streak_required: 4, slow_multiplier: 1.35,
  mastery_speed_multiplier: 1.1, include_wrong: true, include_slow: true,
  case_sensitive: false, strip_punctuation: true, min_word_length: 2,
  max_word_length: 30, graduate_enabled: true, recapture_mastered: true,
};

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    if (req.method === 'GET') {
      const { data, error } = await supabase.from('typing_attempts').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(50);
      if (error) throw error;
      const ids = data.map(x => x.test_id).filter(Boolean);
      let titles = {};
      if (ids.length) {
        const { data: tests } = await supabase.from('typing_tests').select('id,title').in('id', ids);
        titles = Object.fromEntries((tests || []).map(t => [t.id, t.title]));
      }
      return res.status(200).json(data.map(a => ({ ...a, test_title: titles[a.test_id] })));
    }

    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
    const b = req.body || {};
    if (!b.module || !Number.isFinite(Number(b.wpm))) return res.status(400).json({ error: 'Invalid attempt data' });
    const { data: stored } = await supabase.from('adaptive_settings').select('*').eq('user_id', user.id).maybeSingle();
    const cfg = { ...defaults, ...(stored || {}) };
    const stats = (b.word_stats || []).filter(s => s.word);
    const targetMs = 60000 / Math.max(30, Number(b.target_wpm) || 60);
    const masteryMaxMs = targetMs * Number(cfg.mastery_speed_multiplier);
    const slow = s => Number(s.ms) > targetMs * Number(cfg.slow_multiplier);
    const errorWords = [...new Set(stats.filter(s => s.mistyped && cfg.include_wrong).map(s => s.word))];
    const slowWords = [...new Set(stats.filter(s => slow(s) && cfg.include_slow).map(s => s.word))];
    const { data: attempt, error } = await supabase.from('typing_attempts').insert({
      user_id: user.id, module: b.module, lesson_id: b.lesson_id, test_id: b.test_id,
      wpm: b.wpm, raw_wpm: b.raw_wpm, accuracy: b.accuracy, corrections: b.corrections,
      duration_seconds: b.duration_seconds, total_chars: b.total_chars,
      error_words: errorWords, slow_words: slowWords,
    }).select().single();
    if (error) throw error;

    for (const s of stats) {
      let word = String(s.word);
      if (cfg.strip_punctuation) word = word.replace(/[^a-zA-Z0-9'-]/g, '');
      if (!cfg.case_sensitive) word = word.toLowerCase();
      word = word.slice(0, 80);
      if (word.length < cfg.min_word_length || word.length > cfg.max_word_length) continue;

      const isSlow = slow(s) && cfg.include_slow;
      const isMistake = Boolean(s.mistyped && cfg.include_wrong);
      const flagged = isMistake || isSlow;
      const [{ data: existing }, { data: state }] = await Promise.all([
        supabase.from('word_metrics').select('*').eq('user_id', user.id).eq('word', word).maybeSingle(),
        supabase.from('adaptive_word_state').select('*').eq('user_id', user.id).eq('word', word).order('id', { ascending: false }).limit(1).maybeSingle(),
      ]);

      let wrongActive = state?.wrong_active ?? Boolean(existing?.mistake_count > 0 && existing?.status === 'active');
      let slowActive = state?.slow_active ?? Boolean(existing?.slow_count > 0 && existing?.status === 'active');
      let wrongStreak = state?.wrong_clean_streak || 0;
      let slowStreak = state?.slow_clean_streak || 0;

      if (isMistake) { wrongActive = true; wrongStreak = 0; }
      else if (wrongActive) { wrongStreak += 1; if (wrongStreak >= cfg.clean_streak_required) wrongActive = false; }

      if (isSlow) { slowActive = true; slowStreak = 0; }
      else if (slowActive && !isMistake && Number(s.ms) <= masteryMaxMs) {
        slowStreak += 1;
        if (slowStreak >= cfg.clean_streak_required) slowActive = false;
      }

      const stateValues = {
        user_id: user.id, word, wrong_active: wrongActive, slow_active: slowActive,
        wrong_clean_streak: wrongStreak, slow_clean_streak: slowStreak,
        last_word_ms: Math.round(Number(s.ms)), last_outcome: isMistake ? 'wrong' : isSlow ? 'slow' : 'clean',
        evaluated_at: new Date().toISOString(),
      };
      if (state) await supabase.from('adaptive_word_state').update(stateValues).eq('id', state.id);
      else await supabase.from('adaptive_word_state').insert(stateValues);

      if (existing) {
        if (existing.status === 'mastered' && flagged && !cfg.recapture_mastered) continue;
        const streak = flagged ? 0 : existing.clean_streak + 1;
        const delta = flagged ? (isMistake ? -cfg.mistake_weight : -cfg.slow_weight) : (Number(s.ms) <= targetMs ? cfg.clean_fast_gain : cfg.clean_gain);
        const score = Math.max(0, Math.min(100, Number(existing.mastery_score) + Number(delta)));
        const avg = Math.round(Number(existing.avg_ms) * .7 + Number(s.ms) * .3);
        const mastered = cfg.graduate_enabled && !wrongActive && !slowActive && streak >= cfg.clean_streak_required && score >= cfg.mastery_threshold && avg <= masteryMaxMs;
        await supabase.from('word_metrics').update({
          mistake_count: existing.mistake_count + (isMistake ? 1 : 0),
          slow_count: existing.slow_count + (isSlow ? 1 : 0), clean_streak: streak,
          mastery_score: score, avg_ms: avg, status: mastered ? 'mastered' : 'active',
          last_seen: new Date().toISOString(),
        }).eq('id', existing.id);
      } else if (flagged) {
        await supabase.from('word_metrics').insert({ user_id: user.id, word, mistake_count: isMistake ? 1 : 0, slow_count: isSlow ? 1 : 0, clean_streak: 0, mastery_score: 0, avg_ms: Math.round(s.ms), status: 'active' });
      }
    }
    return res.status(201).json({ ...attempt, reevaluated_words: stats.length });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
