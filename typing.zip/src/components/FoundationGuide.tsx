type Finger='LP'|'LR'|'LM'|'LI'|'RI'|'RM'|'RR'|'RP';
type KeyMap={normal:string;shifted?:string};
const fingerFor:Record<string,Finger>={'`':'LP','1':'LP','q':'LP','a':'LP','z':'LP','2':'LR','w':'LR','s':'LR','x':'LR','3':'LM','e':'LM','d':'LM','c':'LM','4':'LI','5':'LI','r':'LI','t':'LI','f':'LI','g':'LI','v':'LI','b':'LI','6':'RI','7':'RI','y':'RI','u':'RI','h':'RI','j':'RI','n':'RI','m':'RI','8':'RM','i':'RM','k':'RM',',':'RM','9':'RR','o':'RR','l':'RR','.':'RR','0':'RP','p':'RP',';':'RP',"'":'RP','/':'RP','-':'RP','=':'RP','[':'RP',']':'RP'};
const namesEn:Record<Finger,string>={LP:'left pinky',LR:'left ring',LM:'left middle',LI:'left index',RI:'right index',RM:'right middle',RR:'right ring',RP:'right pinky'};
const namesHi:Record<Finger,string>={LP:'बायीं कनिष्ठा',LR:'बायीं अनामिका',LM:'बायीं मध्यमा',LI:'बायीं तर्जनी',RI:'दायीं तर्जनी',RM:'दायीं मध्यमा',RR:'दायीं अनामिका',RP:'दायीं कनिष्ठा'};
const rows=[['`','1','2','3','4','5','6','7','8','9','0','-','='],['q','w','e','r','t','y','u','i','o','p','[',']'],['a','s','d','f','g','h','j','k','l',';',"'"],['z','x','c','v','b','n','m',',','.','/']];

export default function FoundationGuide({activeKey,display,shift=false,language='en',map}:{activeKey?:string;display:string;shift?:boolean;language?:'en'|'hi';map?:Record<string,KeyMap>}){
  const key=activeKey?.toLowerCase(); const finger=key?fingerFor[key]:undefined; const isSpace=display===' '; const names=language==='hi'?namesHi:namesEn;
  const instruction=language==='hi'?(isSpace?'किसी एक अंगूठे से रिक्त स्थान दबाएँ':`${names[finger!]} से ${shift?'शिफ़्ट के साथ ':''}${key!.toUpperCase()} दबाएँ`):(isSpace?'press space with either thumb':`press ${key!.toUpperCase()} with your ${names[finger!]}`);
  return <div className="foundation-guide"><div className="guide-target"><span className="guide-target-char">{isSpace?'␣':display}</span><span>{instruction}</span></div><div className="guide-board"><div className="guide-keys">{rows.map((row,ri)=><div className="guide-row" key={ri}>{row.map(k=>{const active=k===key;const values=map?.[k];return <div key={k} className={`guide-key ${active?'guide-key-active':''} ${k==='f'||k==='j'?'guide-home':''}`}><small>{k.toUpperCase()}</small>{values?<><b>{values.normal}</b>{values.shifted&&<i>{values.shifted}</i>}</>:<b>{k.toUpperCase()}</b>}</div>})}</div>)}<div className={`guide-space ${isSpace?'guide-key-active':''}`}>{language==='hi'?'रिक्त स्थान':'space'}</div></div>
    <svg className="guide-hands" viewBox="0 0 580 300" aria-label={language==='hi'?'दो हाथ और दस उँगलियाँ':'two hands and ten fingers'}>
      <g className="guide-hand">
        <path className="guide-palm" d="M77 300 C78 269 82 230 91 195 C98 170 111 157 130 159 C146 161 159 175 168 195 C181 218 194 235 219 249 C241 262 252 278 255 300 Z"/>
        <path className={`guide-finger ${finger==='LP'?'guide-finger-active':''}`} d="M92 205 C94 181 97 157 102 136 C105 123 115 116 125 120 C135 124 138 134 135 147 L126 203"/>
        <path className={`guide-finger ${finger==='LR'?'guide-finger-active':''}`} d="M126 193 C132 161 137 128 143 101 C146 87 157 80 168 85 C179 90 181 101 178 115 L164 202"/>
        <path className={`guide-finger ${finger==='LM'?'guide-finger-active':''}`} d="M163 196 C169 156 177 113 184 78 C187 63 199 56 210 62 C221 68 223 80 220 94 L202 209"/>
        <path className={`guide-finger ${finger==='LI'?'guide-finger-active':''}`} d="M201 211 C207 174 214 138 220 111 C223 96 235 89 246 95 C257 101 259 113 256 127 L242 224"/>
        <path className={`guide-finger guide-thumb ${isSpace?'guide-finger-active':''}`} d="M231 250 C245 224 258 202 273 191 C285 182 298 186 302 197 C305 207 298 217 289 226 L263 262"/>
      </g>
      <g className="guide-hand">
        <path className="guide-palm" d="M503 300 C502 269 498 230 489 195 C482 170 469 157 450 159 C434 161 421 175 412 195 C399 218 386 235 361 249 C339 262 328 278 325 300 Z"/>
        <path className={`guide-finger ${finger==='RP'?'guide-finger-active':''}`} d="M488 205 C486 181 483 157 478 136 C475 123 465 116 455 120 C445 124 442 134 445 147 L454 203"/>
        <path className={`guide-finger ${finger==='RR'?'guide-finger-active':''}`} d="M454 193 C448 161 443 128 437 101 C434 87 423 80 412 85 C401 90 399 101 402 115 L416 202"/>
        <path className={`guide-finger ${finger==='RM'?'guide-finger-active':''}`} d="M417 196 C411 156 403 113 396 78 C393 63 381 56 370 62 C359 68 357 80 360 94 L378 209"/>
        <path className={`guide-finger ${finger==='RI'?'guide-finger-active':''}`} d="M379 211 C373 174 366 138 360 111 C357 96 345 89 334 95 C323 101 321 113 324 127 L338 224"/>
        <path className={`guide-finger guide-thumb ${isSpace?'guide-finger-active':''}`} d="M349 250 C335 224 322 202 307 191 C295 182 282 186 278 197 C275 207 282 217 291 226 L317 262"/>
      </g>
    </svg>
  </div><div className="guide-home-note">{language==='hi'?'तर्जनी उँगलियाँ F और J के उभारों पर रखें · कलाई सीधी रखें · कुंजी दबाकर मूल पंक्ति पर लौटें':'Keep index fingers on the F and J bumps · wrists level · tap and return home'}</div></div>
}
