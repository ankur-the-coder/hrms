import { useEffect } from 'react';

const COPY_SELECTOR = '.type-copy, .v2-copy';
const ACTIVE_SELECTOR = '.char-current, .v2-copy .current';

/**
 * A DOM-level visual controller shared by every typing engine.
 * It never changes typed state or scoring. It only renders a detached caret
 * and keeps the active line in a stable reading band.
 */
export default function TypingFeelEnhancer(){
  useEffect(()=>{
    let frame=0;
    let lastContainer:HTMLElement|null=null;

    const update=()=>{
      cancelAnimationFrame(frame);
      frame=requestAnimationFrame(()=>{
        const active=document.querySelector<HTMLElement>(ACTIVE_SELECTOR);
        const container=active?.closest<HTMLElement>(COPY_SELECTOR);
        if(!active||!container)return;

        if(lastContainer&&lastContainer!==container){
          lastContainer.querySelector('.keysteady-caret')?.remove();
        }
        lastContainer=container;
        container.classList.add('smooth-type-surface');

        let caret=container.querySelector<HTMLElement>('.keysteady-caret');
        if(!caret){
          caret=document.createElement('i');
          caret.className='keysteady-caret';
          caret.setAttribute('aria-hidden','true');
          container.appendChild(caret);
        }

        const containerRect=container.getBoundingClientRect();
        const activeRect=active.getBoundingClientRect();
        const style=getComputedStyle(active);
        const lineHeight=parseFloat(style.lineHeight)||activeRect.height||32;
        const fontSize=parseFloat(style.fontSize)||lineHeight*.65;
        const caretHeight=Math.max(18,fontSize*1.08);
        const x=activeRect.left-containerRect.left+container.scrollLeft-1;
        const y=activeRect.top-containerRect.top+container.scrollTop+
          Math.max(0,(activeRect.height-caretHeight)/2);
        caret.style.height=`${caretHeight}px`;
        caret.style.transform=`translate3d(${x}px, ${y}px, 0)`;

        // Keep the active line in a stable upper-middle reading band. Moving
        // by whole line heights avoids the small per-character camera jitter.
        if(container.scrollHeight>container.clientHeight+2){
          const relativeTop=active.offsetTop-container.scrollTop;
          const upper=lineHeight*.45;
          const lower=container.clientHeight-lineHeight*1.35;
          let target=container.scrollTop;
          if(relativeTop>lower)target=Math.max(0,active.offsetTop-lineHeight*1.35);
          else if(relativeTop<upper)target=Math.max(0,active.offsetTop-lineHeight*.45);
          if(Math.abs(target-container.scrollTop)>2)container.scrollTo({top:target,behavior:'smooth'});
        }
      });
    };

    const observer=new MutationObserver(update);
    observer.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});
    window.addEventListener('resize',update,{passive:true});
    document.addEventListener('scroll',update,true);
    update();
    return()=>{
      cancelAnimationFrame(frame);
      observer.disconnect();
      window.removeEventListener('resize',update);
      document.removeEventListener('scroll',update,true);
      document.querySelectorAll('.keysteady-caret').forEach(el=>el.remove());
    };
  },[]);
  return null;
}
