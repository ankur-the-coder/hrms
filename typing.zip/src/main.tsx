import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import TypingFeelEnhancer from './components/TypingFeelEnhancer.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <TypingFeelEnhancer />
    <App />
  </StrictMode>,
)
