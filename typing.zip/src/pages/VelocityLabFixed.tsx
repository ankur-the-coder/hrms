import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import VelocityLab from './VelocityLab';

export default function VelocityLabFixed(){
  const { id } = useParams();

  useEffect(()=>{
    const scrollCurrentIntoView=()=>{
      const container=document.querySelector<HTMLElement>('.v2-copy');
      const current=container?.querySelector<HTMLElement>('.current');
      if(!container||!current)return;
      const desired=Math.max(0,current.offsetTop-container.clientHeight*.34);
      if(Math.abs(container.scrollTop-desired)>4)container.scrollTo({top:desired,behavior:'smooth'});
    };
    const observer=new MutationObserver(scrollCurrentIntoView);
    const connect=()=>{
      const arena=document.querySelector('.v2-arena');
      if(arena){observer.observe(arena,{subtree:true,attributes:true,attributeFilter:['class'],childList:true});scrollCurrentIntoView()}
    };
    const timer=window.setTimeout(connect,0);
    return()=>{window.clearTimeout(timer);observer.disconnect()};
  },[id]);

  return <VelocityLab key={id||'velocity-home'}/>;
}
