import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ChevronRight, Languages, RotateCcw, Sparkles, Trophy } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import supabase from '../lib/supabase';
import FoundationGuide from '../components/FoundationGuide';

type Lesson={id:number;level:number;title:string;description:string;roman_keys:string;hindi_output:string;practice_hindi:string;target_wpm:number;target_accuracy:number};
const normal:Record<string,string>={'q':'ौ','w':'ै','e':'ा','r':'ी','t':'ू','y':'ब','u':'ह','i':'ग','o':'द','p':'ज','[':'ड',']':'़','a':'ो','s':'े','d':'्','f':'ि','g':'ु','h':'प','j':'र','k':'क','l':'त',';':'च',"'":'ट','z':'ॉ','x':'ं','c':'म','v':'न','b':'व','n':'ल','m':'स',',':',','.':'.','/':'य'};
const shifted:Record<string,string>={'q':'औ','w':'ऐ','e':'आ','r':'ई','t':'ऊ','y':'भ','u':'ङ','i':'घ','o':'ध','p':'झ','[':'ढ',']':'ञ','a':'ओ','s':'ए','d':'अ','f':'इ','g':'उ','h':'फ','j':'ऱ','k':'ख','l':'थ',';':'छ',"'":'ठ','z':'ऑ','x':'ँ','c':'ण','v':'ऩ','b':'ऴ','n':'ळ','m':'श',',':'ष','.':'।','/':'य़'};
const charToKey:Record<string,{key:string;shift:boolean}>={};
Object.entries(normal).forEach(([key,value])=>charToKey[value]={key,shift:false});
Object.entries(shifted).forEach(([key,value])=>charToKey[value]={key,shift:true});
const codeToKey:Record<string,string>={KeyQ:'q',KeyW:'w',KeyE:'e',KeyR:'r',KeyT:'t',KeyY:'y',KeyU:'u',KeyI:'i',KeyO:'o',KeyP:'p',BracketLeft:'[',BracketRight:']',KeyA:'a',KeyS:'s',KeyD:'d',KeyF:'f',KeyG:'g',KeyH:'h',KeyJ:'j',KeyK:'k',KeyL:'l',Semicolon:';',Quote:"'",KeyZ:'z',KeyX:'x',KeyC:'c',KeyV:'v',KeyB:'b',KeyN:'n',KeyM:'m',Comma:',',Period:'.',Slash:'/'};

async function saveAttempt(lesson:Lesson,wpm:number,accuracy:number,duration:number,chars:number){
  const{data}=await supabase.auth.getSession();
  await fetch('/api/attempts',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${data.session?.access_token||''}`},body:JSON.stringify({module:'hindi-inscript',wpm,raw_wpm:wpm,accuracy,corrections:0,duration_seconds:duration,total_chars:chars,target_wpm:lesson.target_wpm,word_stats:[]})});
}

export default function HindiLearn(){
  const{id}=useParams(); const nav=useNavigate(); const[lessons,setLessons]=useState<Lesson[]>([]); const[loading,setLoading]=useState(true); const[error,setError]=useState('');
  useEffect(()=>{fetch('/api/hindi-lessons').then(async r=>{if(!r.ok)throw new Error((await r.json()).error);return r.json()}).then(setLessons).catch(e=>setError(e.message)).finally(()=>setLoading(false))},[]);
  if(loading)return <div className="grid min-h-[70vh] place-items-center"><div className="h-7 w-7 animate-spin rounded-full border-2 border-lime-300 border-t-transparent"/></div>;
  if(error)return <div className="m-8 rounded-xl border border-red-400/20 bg-red-400/8 p-4 text-red-300">{error}</div>;
  const lesson=lessons.find(l=>l.id===Number(id));
  if(lesson)return <HindiSession lesson={lesson} onBack={()=>nav('/learn/hindi')} onNext={()=>{const next=lessons.find(l=>l.level===lesson.level+1);nav(next?`/learn/hindi/${next.id}`:'/learn/hindi')}}/>;
  return <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6" lang="hi"><button onClick={()=>nav('/learn')} className="back"><ArrowLeft size={16}/> अंग्रेज़ी अभ्यास</button>
    <div className="mt-9 grid items-end gap-8 lg:grid-cols-[1fr_390px]"><div><span className="eyebrow">हिंदी · इनस्क्रिप्ट स्पर्श टंकण</span><h1 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">देवनागरी, बिना कुंजीपटल देखे।</h1><p className="mt-4 max-w-2xl leading-relaxed text-stone-400">भारत के मानक <b className="text-white">हिंदी इनस्क्रिप्ट</b> विन्यास को अपने परिचित रोमन-अक्षर वाले कुंजीपटल पर सीखें। हर भौतिक कुंजी एक निश्चित हिंदी अक्षर और उँगली से जुड़ी है।</p></div><div className="panel border-lime-300/20! bg-lime-300/[.05]!"><Sparkles className="text-lime-300"/><h2 className="mt-3 font-semibold">कोई तैयारी नहीं · तुरंत शुरू करें</h2><p className="mt-2 text-sm leading-relaxed text-stone-400">भाषा बदलने या नया कुंजीपटल जोड़ने की आवश्यकता नहीं। कुंजीपटल रोमन मोड में ही रखें। कीस्टेडी हर भौतिक कुंजी को सही देवनागरी अक्षर में बदल देगा।</p></div></div>
    <div className="mt-8 rounded-2xl border border-lime-300/15 bg-lime-300/[.04] p-5"><div className="flex gap-3"><Languages className="shrink-0 text-lime-300"/><div><h3 className="font-semibold">रोमन कुंजी → हिंदी अक्षर → सही उँगली</h3><p className="mt-1 text-sm text-stone-400">लक्ष्य अक्षर, भौतिक कुंजी, हाथों का चित्र और पूरा इनस्क्रिप्ट मानचित्र एक साथ दिखेगा। पहले मूल पंक्ति, फिर दूसरी पंक्तियाँ, शिफ़्ट, मात्राएँ, हलन्त, शब्द और वाक्य।</p></div></div></div>
    <div className="mt-8 grid gap-3">{lessons.map((l,i)=><button key={l.id} onClick={()=>nav(`/learn/hindi/${l.id}`)} className="lesson-row"><span className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/[.025] font-display text-lg text-stone-400">{String(i+1).padStart(2,'0')}</span><div className="min-w-0 flex-1"><h3 className="font-semibold">{l.title}</h3><p className="mt-1 truncate text-sm text-stone-500">{l.description}</p></div><div className="hidden text-right sm:block"><p className="font-mono text-sm text-lime-300">कुंजियाँ: {l.roman_keys}</p><p className="mt-1 text-lg text-stone-300">{l.hindi_output}</p></div><ChevronRight className="text-stone-600"/></button>)}</div>
  </main>;
}

function HindiSession({lesson,onBack,onNext}:{lesson:Lesson;onBack:()=>void;onNext:()=>void}){
  const[typed,setTyped]=useState(''); const[start,setStart]=useState<number|null>(null); const[done,setDone]=useState(false); const[saved,setSaved]=useState(false); const[corrections,setCorrections]=useState(0); const box=useRef<HTMLDivElement>(null);
  const text=lesson.practice_hindi.normalize('NFC'); const chars=Array.from(text); const typedChars=Array.from(typed.normalize('NFC')); const current=chars[typedChars.length]||''; const guide=charToKey[current];
  const elapsed=start?Math.max(1,(Date.now()-start)/1000):0; const wrong=typedChars.filter((c,i)=>c!==chars[i]).length; const accuracy=typedChars.length?Math.max(0,(typedChars.length-wrong-corrections)/typedChars.length*100):100; const wpm=start?(typedChars.length/5)/(elapsed/60)*accuracy/100:0;
  useEffect(()=>box.current?.focus(),[]);
  function finish(next:string,now:number){const out=Array.from(next.normalize('NFC'));if(out.length<chars.length)return;const seconds=Math.max(1,(now-(start||now))/1000);const errors=out.filter((c,i)=>c!==chars[i]).length;const acc=Math.max(0,(out.length-errors-corrections)/out.length*100);setDone(true);saveAttempt(lesson,(out.length/5)/(seconds/60)*acc/100,acc,seconds,out.length).then(()=>setSaved(true))}
  function key(e:React.KeyboardEvent){
    if(done||e.altKey||e.key==='Tab'||e.key==='Shift')return;
    if(e.key==='Backspace'&&(e.ctrlKey||e.metaKey)){e.preventDefault();if(!typedChars.length)return;let end=typedChars.length;while(end>0&&typedChars[end-1]===' ')end--;const prior=typedChars.slice(0,end).lastIndexOf(' ');const startIndex=prior+1;setTyped(typedChars.slice(0,startIndex).join(''));setCorrections(v=>v+(typedChars.length-startIndex));return}
    if(e.ctrlKey||e.metaKey)return;e.preventDefault();
    if(e.key==='Enter'){const boundary=chars.indexOf(' ',typedChars.length);const position=boundary===-1?chars.length:boundary+1;const next=chars.slice(0,position).join('');setTyped(next);finish(next,Date.now());return}
    if(e.key==='Backspace'){if(typedChars.length){setTyped(typedChars.slice(0,-1).join(''));setCorrections(v=>v+1)}return}
    const now=Date.now(); if(!start)setStart(now); let output='';
    if(e.code==='Space')output=' '; else {const physical=codeToKey[e.code];if(!physical)return;output=(e.shiftKey?shifted:normal)[physical]||''}
    const next=(typed+output).normalize('NFC');setTyped(next);finish(next,now);
  }
  function reset(){setTyped('');setStart(null);setDone(false);setSaved(false);setCorrections(0);setTimeout(()=>box.current?.focus(),0)}
  const hindiMap=Object.fromEntries(Object.keys(normal).map(k=>[k,{normal:normal[k],shifted:shifted[k]}]));
  return <main className="foundation-page mx-auto max-w-6xl px-4 py-4 sm:px-6" lang="hi"><button onClick={onBack} className="back"><ArrowLeft size={16}/> हिंदी इनस्क्रिप्ट पाठ</button><section ref={box} tabIndex={0} onKeyDown={key} onClick={()=>box.current?.focus()} className="typing-stage foundation-session mt-3 outline-none">
    <div className="flex flex-wrap items-end justify-between gap-3 border-b border-white/8 pb-3"><div><span className="eyebrow">इनस्क्रिप्ट पाठ {lesson.level}</span><h1 className="mt-1 font-display text-2xl font-semibold">{lesson.title}</h1><p className="mt-1 text-xs text-stone-500">{lesson.description}</p></div><div className="flex gap-6 text-right"><div><b className="font-mono text-lg text-lime-300">{Math.round(wpm)}</b><small className="block text-stone-600">शब्द/मि.</small></div><div><b className="font-mono text-lg text-lime-300">{Math.round(accuracy)}%</b><small className="block text-stone-600">शुद्धता</small></div></div></div>
    {!done?<><div className="type-copy foundation-copy" lang="hi">{chars.map((c,i)=><span key={i} className={`${i<typedChars.length?(typedChars[i]===c?'char-ok':'char-bad'):i===typedChars.length?'char-current':''} ${c===' '?'char-space':''}`}>{c}</span>)}</div><div className="foundation-guide-wrap"><FoundationGuide activeKey={current===' '?undefined:guide?.key} display={current} shift={guide?.shift} language="hi" map={hindiMap}/></div><p className="foundation-status justify-center!">कुंजीपटल रोमन मोड में रखें। ऊपर दिखाई गई भौतिक कुंजी दबाएँ; कीस्टेडी हिंदी अक्षर बनाएगा।</p></>:<div className="py-14 text-center"><Trophy className="mx-auto text-lime-300" size={42}/><h2 className="mt-5 font-display text-3xl">बहुत अच्छा! पाठ पूरा हुआ।</h2><p className="mt-2 text-stone-500">{saved?'आपका परिणाम सुरक्षित हो गया है।':'परिणाम सुरक्षित हो रहा है…'}</p><div className="mt-7 flex justify-center gap-3"><button onClick={reset} className="secondary-btn"><RotateCcw size={16}/> फिर से</button><button onClick={onNext} className="primary-btn">अगला पाठ <ChevronRight size={16}/></button></div></div>}
  </section></main>;
}
