import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import type { ChartDatum } from '../Charts';
import { buildThreePNG, captureLabelPositions, withExportResolution, type ExportTheme } from './exportUtils';
import type { ThreeChartHandle } from './ThreeSankey3D';

interface Props {
  data: ChartDatum[];
  palette: string[];
  dim: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (idx: number | null, text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

class ArcCurve3 extends THREE.Curve<THREE.Vector3> {
  radius: number; startAngle: number; endAngle: number;
  constructor(radius: number, startAngle: number, endAngle: number) {
    super();
    this.radius = radius; this.startAngle = startAngle; this.endAngle = endAngle;
  }
  getPoint(t: number, target = new THREE.Vector3()) {
    const angle = this.startAngle + t * (this.endAngle - this.startAngle);
    return target.set(Math.cos(angle) * this.radius, 0, -Math.sin(angle) * this.radius);
  }
}

function escXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function adjustColor(hex: string, percent: number): string {
  const num = parseInt(hex.replace('#', ''), 16);
  let r = (num >> 16) + Math.round(255 * (percent / 100));
  let g = ((num >> 8) & 0x00ff) + Math.round(255 * (percent / 100));
  let b = (num & 0x0000ff) + Math.round(255 * (percent / 100));
  r = Math.min(255, Math.max(0, r)); g = Math.min(255, Math.max(0, g)); b = Math.min(255, Math.max(0, b));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

/** Radial bar chart rendered as real 3D tube-arcs.
 * A single Three.js scene serves BOTH the 2D and 3D views — only the
 * camera position/up-vector and each arc's vertical lift morph between
 * them, so 2D⇄3D is a true camera transition rather than a different
 * chart.
 *
 * Design notes (Option B fixes):
 * - NO white/ghost track pipes: each datum paints exactly ONE colored
 *   tube. Empty remainder is implied by the tube's own sweep.
 * - 3D default view is a readable oblique preset where every label pill
 *   floats on its own staggered lane — nothing hides behind anything.
 * - Labels are panel-styled pills (same family as pie/donut leaders)
 *   and follow the card's font.
 * - SVG export is TRUE vector: every tube is re-projected through the
 *   live camera into shaded ribbon paths + gradients (no <image>). */
const ThreeRadialBar = forwardRef<ThreeChartHandle, Props>(function ThreeRadialBar(
  { data, palette, dim, hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | null>(null);
  const [zoomOn, setZoomOn] = useState(false);

  const api = useRef<{
    renderer: THREE.WebGLRenderer;
    labelRenderer: CSS2DRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    rings: {
      barGroup: THREE.Group; badge: CSS2DObject; stem: THREE.Line; radius: number;
      mat: THREE.MeshPhysicalMaterial; name: string; value: number;
      startA: number; endA: number; frac: number; color: string;
    }[];
    maxR: number;
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    setMode: (m: '2D' | '3D') => void;
    setZoom: (on: boolean) => void;
    getLift: () => number;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 500);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container!.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container!.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 - 0.03;
    controls.enabled = false;
    controls.enableZoom = false;

    scene.add(new THREE.AmbientLight(0xffffff, 1.4));
    const key = new THREE.DirectionalLight(0xfffdfa, 2.1);
    key.position.set(8, 20, 10);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0006;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xa0c8ff, 0.8);
    fill.position.set(-10, 8, -10);
    scene.add(fill);
    // cool top sheen — gives every tube the bright crown the SVG exporter mirrors
    const sheen = new THREE.DirectionalLight(0xffffff, 0.55);
    sheen.position.set(0, 30, -6);
    scene.add(sheen);
    // warm bounce from below so tube undersides keep hue instead of going black
    const bounce = new THREE.HemisphereLight(0xffffff, 0x8a8f88, 0.5);
    scene.add(bounce);

    const graphGroup = new THREE.Group();
    scene.add(graphGroup);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), new THREE.ShadowMaterial({ opacity: 0.1 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.05;
    floor.receiveShadow = true;
    graphGroup.add(floor);

    // ---- PLOT MODEL (fixed): concentric tube-arcs, one datum per ring ----
    //  * rings ordered OUTSIDE→IN by value desc (biggest bar = outermost ring,
    //    exactly like the classic radial-bar language);
    //  * every arc starts at 12 o'clock and sweeps CLOCKWISE up to 97% of a
    //    turn — the empty remainder is always the same top gap, never a
    //    random-looking hole, and arcs never overlap each other;
    //  * MAX is the true data max (no hidden 1.06 padding eating the sweep,
    //    so the biggest bar reads as full and ratios are exact).
    //  ArcCurve3 maps XZ as x=cos(a)·r, z=-sin(a)·r, so with the 2D camera's
    //  up=(0,0,-1) the angle a=π/2 (point (0,0,-r)) lands at screen-top and
    //  DECREASING a moves clockwise on screen. Sweep = startA - frac·2π·0.97.
    const items = (data || []).slice(0, 24)
      .map((d, i) => ({ d, i }))
      .sort((a, b) => b.d.value - a.d.value || a.i - b.i)
      .map(({ d }) => d);
    const MAX_VAL = Math.max(1, ...items.map((d) => d.value));
    // ---- DENSE packing: ring pitch + tube gauge shrink with ring count so
    // dense datasets stay readable; the whole stack is then re-centred so it
    // never drifts (see R0 below). Label lanes are angular (per-tip), NOT a
    // single vertical column — see the badge placer in the frame loop. ----
    const DENSE_N = Math.max(1, items.length);
    const R_STEP = DENSE_N <= 6 ? 0.46 : DENSE_N <= 10 ? 0.38 : DENSE_N <= 16 ? 0.30 : 0.24;
    const TUBE_R = Math.min(0.12, R_STEP * 0.30);
    const INNER_R = 1.55;

    // Shared assets: ONE cap-sphere geometry + ONE stem material for the
    // whole chart (was: per-ring clones) — fewer GPU uploads, less GC churn.
    const capGeo = new THREE.SphereGeometry(TUBE_R, 14, 14);
    const stemMat = new THREE.LineBasicMaterial({ color: dark ? 0x666666 : 0xcccccc, transparent: true, opacity: 0.8 });
    function makeBar(radius: number, startA: number, endA: number, color: string) {
      const group = new THREE.Group();
      const mat = new THREE.MeshPhysicalMaterial({ color: new THREE.Color(color), roughness: 0.25, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.15 });
      const curve = new ArcCurve3(radius, startA, endA);
      // tubular segments scale with sweep (short arcs need fewer rings)
      const sweepLen = Math.max(0.05, Math.abs(endA - startA));
      const tubSeg = Math.max(24, Math.min(96, Math.round(sweepLen * 22)));
      const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, tubSeg, TUBE_R, 12, false), mat);
      tube.castShadow = true; tube.receiveShadow = true;
      group.add(tube);
      const c0 = new THREE.Mesh(capGeo, mat); c0.position.copy(curve.getPoint(0)); c0.castShadow = true; group.add(c0);
      const c1 = new THREE.Mesh(capGeo, mat); c1.position.copy(curve.getPoint(1)); c1.castShadow = true; group.add(c1);
      return { group, mat, tube };
    }

    const rings: NonNullable<typeof api.current>['rings'] = [];
    const hitMeshes: { mesh: THREE.Object3D; ringIdx: number }[] = [];
    const labelRefs: { el: HTMLElement; text: string; color?: string }[] = [];

    items.forEach((d, i) => {
      const color = d.color || palette[i % palette.length];
      const radius = INNER_R + i * R_STEP;
      // NOTE: no track pipe — a single colored tube per datum.
      const frac = Math.min(1, Math.max(0, d.value / MAX_VAL));
      const startA = Math.PI / 2;
      const sweep = frac <= 0 ? 0 : Math.max(0.03, frac * Math.PI * 2 * 0.97);
      const endA = startA - sweep;
      const { group: barGroup, mat, tube } = makeBar(radius, startA, endA, color);
      graphGroup.add(barGroup);
      hitMeshes.push({ mesh: tube, ringIdx: i });
      (barGroup as unknown as { userData: { targetY: number } }).userData = { targetY: 0.1 + frac * 0.42 };

      const cDiv = document.createElement('div');
      cDiv.className = 'rb3d-badge';
      cDiv.textContent = `${d.label} · ${Math.round(d.value)}`;
      cDiv.style.fontFamily = theme.fontBody;
      cDiv.style.color = dark ? '#f1f5ef' : '#1c2620';
      if (dark) {
        cDiv.style.background = 'rgba(20,26,22,0.88)';
        cDiv.style.border = '1px solid rgba(255,255,255,0.16)';
      }
      cDiv.style.borderLeft = `4px solid ${color}`;
      const cObj = new CSS2DObject(cDiv);
      graphGroup.add(cObj);
      // label anchor: each pill is keyed to its OWN tube-END tip angle
      // (angular lane, not a shared vertical column) — pills spread around
      // the dial with the data, so dense sets fan out instead of stacking.
      // The per-frame relaxer below only separates pills whose SCREEN boxes
      // would still collide (small radial nudge, leaders stay attached).
      // Declustering: tube-END tips bunch where values cluster, so each
      // pill's anchor angle is spread by ring index around its own tip —
      // golden-angle walk guarantees neighbours never share a lane even for
      // dense/near-equal datasets. Leader stems stay attached to true tips.
      const GOLDEN = Math.PI * (3 - Math.sqrt(5));
      const spreadN = Math.max(1, items.length);
      const tipAngle = endA + ((i * GOLDEN) % (Math.PI * 2)) / Math.max(1, spreadN * 0.15) * 0.06 + (i % 2 === 0 ? 0.05 : -0.05);
      (cObj as unknown as { userData: { targetY: number; radius: number; lift: number; tipA: number; frac: number; nudge: number } }).userData = {
        targetY: 0.85 + (i % 4) * 0.22, radius, lift: 0, tipA: tipAngle, frac, nudge: 0,
      };
      labelRefs.push({ el: cDiv, text: `${d.label} · ${Math.round(d.value)}`, color });

      const stemGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, -radius), new THREE.Vector3(0, 0, -radius)]);
      const stemLine = new THREE.Line(stemGeo, stemMat);
      graphGroup.add(stemLine);

      rings.push({ barGroup, badge: cObj, stem: stemLine, radius, mat, name: d.label, value: d.value, startA, endA, frac, color });
    });

    const maxR = INNER_R + Math.max(0, items.length - 1) * R_STEP + 0.6;
    // 2D: straight top-down, plot fills the frame.
    const state2D = { camPos: new THREE.Vector3(0, 21, 0.001), camTarget: new THREE.Vector3(0, 0, 0), up: new THREE.Vector3(0, 0, -1), lift: 0 };
    // 3D default: readable oblique preset. The azimuth swings the stacked
    // label column to the LEFT of the rings (screen space) so no pill is
    // ever hidden behind a tube — see badge anchor below (badges sit at
    // -X, tubes occupy the +X half at their tallest).
    const rr = Math.max(3.2, maxR);
    const state3D = { camPos: new THREE.Vector3(-rr * 1.35, rr * 1.5, rr * 1.9), camTarget: new THREE.Vector3(0, 0.25, 0), up: new THREE.Vector3(0, 1, 0), lift: 1 };

    let mode: '2D' | '3D' = '2D';
    let transitioning = false, tProg = 1;
    let needsFrame = true; // resize/fullscreen/visibility always wakes the loop
    const wake = () => { needsFrame = true; };
    const startPos = new THREE.Vector3(), startTarget = new THREE.Vector3(), startUp = new THREE.Vector3();
    camera.position.copy(state2D.camPos);
    camera.up.copy(state2D.up);
    controls.target.copy(state2D.camTarget);

    function setMode(m: '2D' | '3D') {
      if (mode === m) return;
      mode = m;
      controls.enabled = false;
      transitioning = true; tProg = 0;
      startPos.copy(camera.position); startTarget.copy(controls.target); startUp.copy(camera.up);
    }

    function resize() {
      const W = container!.clientWidth || 600, H = container!.clientHeight || 360;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
      wake(); // parked loops must repaint after ANY size change
    }
    const onVis = () => { if (!document.hidden) { resize(); wake(); } };
    document.addEventListener('visibilitychange', onVis);
    // Fullscreen transitions resize the container WITHOUT firing
    // ResizeObserver in some browsers — listen explicitly + belt-and-braces
    // rAF re-check so the plot can never stay blank after exit.
    const onFs = () => { resize(); wake(); requestAnimationFrame(() => { resize(); wake(); }); };
    document.addEventListener('fullscreenchange', onFs);
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    let hoveredRing = -1;
    let origColor: THREE.Color | null = null;

    function applyHover(idx: number) {
      if (hoveredRing === idx) return;
      if (hoveredRing >= 0 && origColor) rings[hoveredRing].mat.color.copy(origColor);
      hoveredRing = idx;
      if (idx >= 0) {
        origColor = rings[idx].mat.color.clone();
        rings[idx].mat.color.offsetHSL(0, 0, 0.12);
      }
    }
    function clearHoverVisual() {
      if (hoveredRing >= 0 && origColor) rings[hoveredRing].mat.color.copy(origColor);
      hoveredRing = -1; origColor = null;
    }

    function onPointerMove(e: PointerEvent) {
      const rect = container!.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(hitMeshes.map((h) => h.mesh), false);
      if (hits.length) {
        const found = hitMeshes.find((h) => h.mesh === hits[0].object);
        if (found) {
          applyHover(found.ringIdx);
          const r = rings[found.ringIdx];
          setTip({ x: e.clientX - rect.left, y: e.clientY - rect.top, text: `${r.name} · ${Math.round(r.value)}` });
          onHover?.(found.ringIdx, `${r.name} · ${Math.round(r.value)}`);
          container!.style.cursor = 'pointer';
        }
      } else {
        clearHoverVisual();
        setTip(null);
        onHover?.(null, null);
        container!.style.cursor = mode === '3D' ? 'grab' : 'default';
      }
    }
    function onPointerLeave() { clearHoverVisual(); setTip(null); onHover?.(null, null); }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    let currentLift = 0;
    const tmpTarget = new THREE.Vector3();
    let raf = 0;
    const lastCam = new THREE.Vector3(1e9, 1e9, 1e9);
    const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
    /* CONTINUOUS render while on-screen: the old park-when-settled loop left
       the canvas blank whenever the drawing buffer was cleared without a
       busy event (fullscreen resizes, exports, buffers discarded after
       scrolling away, WebGL context restores) — the chart "disappeared"
       until a click or hover woke it. Every visible frame now repaints;
       off-screen frames are skipped so the GPU still idles, and the heavy
       badge layout only runs while something actually moves. */
    let onScreen = true;
    const io = new IntersectionObserver((es) => {
      onScreen = es.some((e) => e.isIntersecting);
      if (onScreen) resize();
    }, { threshold: 0 });
    io.observe(container!);
    const onCtxLost = (e: Event) => { e.preventDefault(); };
    const onCtxRestored = () => resize();
    renderer.domElement.addEventListener('webglcontextlost', onCtxLost, false);
    renderer.domElement.addEventListener('webglcontextrestored', onCtxRestored, false);
    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (!onScreen || document.hidden) return;
      const camMoved = camera.position.distanceToSquared(lastCam) > 1e-10;
      lastCam.copy(camera.position);
      const busy = transitioning || Math.abs((mode === '2D' ? 0 : 1) - currentLift) > 0.001 || camMoved || hoveredRing >= 0 || needsFrame;
      if (busy) {
      const target = mode === '2D' ? state2D : state3D;
      if (transitioning) {
        tProg += 0.022;
        if (tProg >= 1) { tProg = 1; transitioning = false; if (mode === '3D') controls.enabled = true; }
        const ease = easeOutCubic(tProg);
        camera.position.lerpVectors(startPos, target.camPos, ease);
        camera.up.lerpVectors(startUp, target.up, ease).normalize();
        tmpTarget.lerpVectors(startTarget, target.camTarget, ease);
        controls.target.copy(tmpTarget);
      }
      currentLift += (target.lift - currentLift) * 0.08;
      // --- angular badge placer + screen-space relaxer ---
      // Each pill anchors OUTSIDE its own tube-END tip (radially outward, at
      // the tip's own angle) — pills spread around the dial WITH the data, so
      // dense sets fan out instead of stacking in one column. A light relaxer
      // then separates any pills whose SCREEN boxes still collide by nudging
      // them further outward along their own radial (leaders stay attached).
      type Bud = { targetY: number; radius: number; lift: number; tipA: number; frac: number; nudge: number };
      const tipOf = (b: Bud) => ({ x: Math.cos(b.tipA) * b.radius, z: -Math.sin(b.tipA) * b.radius });
      const outOf = (b: Bud) => ({ x: Math.cos(b.tipA), z: -Math.sin(b.tipA) });
      if (rings.length) {
        const cont = container!;
        const cw = cont.clientWidth || 600, ch = cont.clientHeight || 360;
        const pv = new THREE.Vector3();
        const pxOf = (b: Bud, tubeY: number) => {
          const tp = tipOf(b), op = outOf(b);
          const rr = maxR + 0.55 + (b.nudge || 0);
          const wx = op.x * rr, wz = op.z * rr;
          const wy = tubeY + 0.12 + b.targetY * currentLift * 0.35 + (b.lift || 0) * currentLift;
          pv.set(wx, wy, wz).project(camera);
          return { sx: ((pv.x * 0.5 + 0.5) * cw), sy: ((-(pv.y * 0.5) + 0.5) * ch), wx, wy, wz, tp };
        };
        const boxes = rings.map((r) => {
          const b = (r.badge as unknown as { userData: Bud }).userData;
          const ud = (r.barGroup as unknown as { userData: { targetY: number } }).userData;
          const tubeY = ud.targetY * currentLift;
          const el = r.badge.element as HTMLElement;
          const w = Math.min(190, el.offsetWidth || 90), h = el.offsetHeight || 20;
          return { r, b, tubeY, w, h, ...pxOf(b, tubeY) };
        });
        // sort angularly so neighbours relax against neighbours
        boxes.sort((p, q) => p.b.tipA - q.b.tipA);
        // iterate to convergence (dense sets need more passes); each pass
        // pushes the smaller pill radially AND lifts it slightly, so pills
        // staircase outward instead of fighting over one ring of space.
        for (let pass = 0; pass < 10; pass++) {
          let moved = false;
          for (let k = 0; k < boxes.length; k++) {
            const c = boxes[k];
            const n = boxes[(k + 1) % boxes.length];
            if (n === c) break;
            const overlapX = Math.min(c.sx + c.w / 2, n.sx + n.w / 2) - Math.max(c.sx - c.w / 2, n.sx - n.w / 2);
            const overlapY = Math.min(c.sy + c.h / 2, n.sy + n.h / 2) - Math.max(c.sy - c.h / 2, n.sy - n.h / 2);
            if (overlapX > 2 && overlapY > 2) {
              // push the SMALLER-value pill further out along its own radial
              const push = (n.r.value <= c.r.value ? n : c);
              const worldPerPx = (2 * camera.position.distanceTo(new THREE.Vector3(push.wx, push.wy, push.wz)) * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2))) / Math.max(1, ch);
              push.b.nudge = Math.min(7.5, (push.b.nudge || 0) + Math.max(6, overlapX + overlapY + 8) * worldPerPx * 0.6 + 0.05);
              push.b.lift = Math.min(3, (push.b.lift || 0) + 0.06);
              Object.assign(push, pxOf(push.b, push.tubeY));
              moved = true;
            }
          }
          if (!moved) break;
        }
        // decay nudges when room frees up (smooth, no pop)
        boxes.forEach(({ b }) => { b.nudge = (b.nudge || 0) * 0.93; if (b.nudge < 0.01) b.nudge = 0; b.lift = (b.lift || 0) * 0.93; if ((b.lift || 0) < 0.01) b.lift = 0; });
        // commit: badge parks outside its tip, stem runs tip → badge
        boxes.forEach(({ r, b, tubeY, wx, wy, wz, tp }) => {
          r.barGroup.position.y = tubeY;
          r.badge.position.set(wx, wy, wz);
          const pos = r.stem.geometry.attributes.position.array as Float32Array;
          pos[0] = wx; pos[1] = wy; pos[2] = wz;
          pos[3] = tp.x; pos[4] = tubeY; pos[5] = tp.z;
          r.stem.geometry.attributes.position.needsUpdate = true;
          (r.badge.element as HTMLElement).style.opacity = '1';
        });
        (stemMat as THREE.LineBasicMaterial).opacity = 0.25 + currentLift * 0.45;
      } else {
        rings.forEach((r) => {
          const ud = (r.barGroup as unknown as { userData: { targetY: number } }).userData;
          r.barGroup.position.y = ud.targetY * currentLift;
        });
      }
      } // end if (busy) — the scene itself repaints EVERY visible frame
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
      needsFrame = false;
    };
    animate();

    const dispose = () => {
      cancelAnimationFrame(raf);
      capGeo.dispose();
      stemMat.dispose();
      ro.disconnect();
      io.disconnect();
      renderer.domElement.removeEventListener('webglcontextlost', onCtxLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onCtxRestored);
      document.removeEventListener('visibilitychange', onVis);
      document.removeEventListener('fullscreenchange', onFs);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      controls.dispose();
      renderer.dispose();
      container!.removeChild(renderer.domElement);
      container!.removeChild(labelRenderer.domElement);
    };

    api.current = { renderer, labelRenderer, scene, camera, controls, rings, maxR, labelRefs, setMode, setZoom: (on: boolean) => { controls.enableZoom = on; }, getLift: () => currentLift, dispose };
    setMode(dim === '3d' ? '3D' : '2D');
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, palette, dark]);

  useEffect(() => { api.current?.setMode(dim === '3d' ? '3D' : '2D'); }, [dim]);

  useEffect(() => {
    const a = api.current;
    if (!a) return;
    a.rings.forEach((r, i) => {
      const active = hoverIndex === i;
      const el = r.badge.element as HTMLElement;
      el.style.boxShadow = active ? '0 4px 14px rgba(0,0,0,0.25)' : '0 2px 6px rgba(0,0,0,0.14)';
      el.style.zIndex = active ? '5' : '1';
    });
  }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(W, H, false);
      // never leave the live panel blank after an export
      a.renderer.render(a.scene, a.camera);
      a.labelRenderer.render(a.scene, a.camera);
      const labels = captureLabelPositions(container, a.labelRefs);
      const legend = a.rings.map((r) => ({ label: r.name, color: r.color }));
      const cv = await buildThreePNG({ title, imageDataUrl: dataUrl, chartW: W, chartH: H, labels, legend, theme, footnote: `Radial bar · ${dim === '3d' ? '3D' : '2D'} view` });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      // TRUE vector export: re-project every tube centreline through the
      // live camera, rebuild the ribbon in screen space with a glassy
      // multi-stop gradient + highlight + shadow. No raster <image>.
      // Fidelity pass (matches the live MeshPhysicalMaterial look):
      //  per-sample tube radius (true perspective), round sphere caps at
      //  both ends, contact shadow offset toward the floor, ACES-style
      //  highlight compression, and a LOCAL cross-tube gradient (bright
      //  crown → saturated core → deep base) instead of one global wash.
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container!.clientWidth, H = container!.clientHeight;
      const scratch = document.createElement('canvas').getContext('2d')!;
      const proj = (v: THREE.Vector3): [number, number] => {
        const q = v.clone().project(a.camera);
        return [((q.x * 0.5 + 0.5) * W), ((-(q.y * 0.5) + 0.5) * H)];
      };
      const camDir = new THREE.Vector3();
      a.camera.getWorldDirection(camDir);
      const SEG = 72;
      const maxR = a.maxR;
      let defs = `<filter id="rbsoft" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="2.5" stdDeviation="3.5" flood-color="#000000" flood-opacity="0.20"/></filter>\n`;
      let body = '';
      let seq = 0;
      const lift = a.getLift();
      a.rings.forEach((r) => {
        const curve = new ArcCurve3(r.radius, r.startA, r.endA);
        const ud = (r.barGroup as unknown as { userData: { targetY: number } }).userData;
        const tubeY = (ud.targetY || 0) * lift;
        const radOf = (wp: THREE.Vector3) => {
          const dist = a.camera.position.distanceTo(wp);
          const pxPerUnit = (H / (2 * Math.tan(THREE.MathUtils.degToRad(a.camera.fov / 2)) * Math.max(0.5, dist)));
          return Math.max(2.5, 0.12 * (pxPerUnit || 40));
        };
        // ACES-ish compression so the crown reads like tone-mapped WebGL
        const crown = adjustColor(adjustColor(r.color, 52), -6);
        const core = r.color;
        const deep = adjustColor(r.color, -34);
        // sample centreline + per-sample radius + screen normal
        const C: [number, number][] = []; const N: [number, number][] = []; const R: number[] = [];
        for (let s = 0; s <= SEG; s++) {
          const wp = curve.getPoint(s / SEG).add(new THREE.Vector3(0, tubeY, 0));
          const pC = proj(wp);
          const pA = proj(curve.getPoint(Math.max(0, s / SEG - 0.004)).add(new THREE.Vector3(0, tubeY, 0)));
          const pB = proj(curve.getPoint(Math.min(1, s / SEG + 0.004)).add(new THREE.Vector3(0, tubeY, 0)));
          const dx = pB[0] - pA[0], dy = pB[1] - pA[1];
          const L = Math.hypot(dx, dy) || 1;
          C.push(pC); N.push([-dy / L, dx / L]); R.push(radOf(wp));
        }
        // contact shadow: same ribbon, dropped toward screen-down (floor dir)
        const shOff = Math.max(2, R[Math.floor(SEG / 2)] * 0.5 + 2);
        const shTop = C.map((p, s) => `${(p[0] + N[s][0] * R[s]).toFixed(1)},${(p[1] + N[s][1] * R[s] + shOff).toFixed(1)}`);
        const shBot = C.map((p, s) => `${(p[0] - N[s][0] * R[s]).toFixed(1)},${(p[1] - N[s][1] * R[s] + shOff).toFixed(1)}`).reverse();
        body += `        <path d="M ${shTop.join(' L ')} L ${shBot.join(' L ')} Z" fill="#000000" fill-opacity="0.14" filter="url(#rbsoft)"/>\n`;
        const top: string[] = []; const bot: string[] = [];
        const hi: string[] = [];
        let yMin = Infinity, yMax = -Infinity;
        for (let s = 0; s <= SEG; s++) {
          const [cxp, cyp] = C[s]; const [nx, ny] = N[s]; const rr = R[s];
          const ax = cxp + nx * rr, ay = cyp + ny * rr;
          const bx = cxp - nx * rr, by = cyp - ny * rr;
          top.push(`${ax.toFixed(1)},${ay.toFixed(1)}`);
          bot.push(`${bx.toFixed(1)},${by.toFixed(1)}`);
          // specular thread rides the camera-facing flank (upper-normal side)
          const side = ny <= 0 ? 1 : -1;
          hi.push(`${(cxp + nx * rr * 0.38 * side).toFixed(1)},${(cyp + ny * rr * 0.38 * side).toFixed(1)}`);
          yMin = Math.min(yMin, ay, by); yMax = Math.max(yMax, ay, by);
        }
        const gid = `rbtube${seq++}`;
        defs += `        <linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="0" y1="${yMin.toFixed(1)}" x2="0" y2="${Math.max(yMin + 1, yMax).toFixed(1)}">\n` +
          `            <stop offset="0" stop-color="${crown}"/>\n` +
          `            <stop offset="0.38" stop-color="${core}"/>\n` +
          `            <stop offset="0.72" stop-color="${adjustColor(r.color, -12)}"/>\n` +
          `            <stop offset="1" stop-color="${deep}"/>\n` +
          `        </linearGradient>\n`;
        const dPath = `M ${top.join(' L ')} L ${bot.reverse().join(' L ')} Z`;
        const midR = R[Math.floor(SEG / 2)];
        const [capSx, capSy] = C[0]; const [capEx, capEy] = C[SEG];
        body += `        <circle cx="${capSx.toFixed(1)}" cy="${capSy.toFixed(1)}" r="${R[0].toFixed(1)}" fill="url(#${gid})" stroke="${deep}" stroke-width="0.7" stroke-opacity="0.6"/>\n`;
        body += `        <circle cx="${capEx.toFixed(1)}" cy="${capEy.toFixed(1)}" r="${R[SEG].toFixed(1)}" fill="url(#${gid})" stroke="${deep}" stroke-width="0.7" stroke-opacity="0.6"/>\n`;
        body += `        <path d="${dPath}" fill="url(#${gid})" stroke="${deep}" stroke-width="0.7" stroke-opacity="0.6" stroke-linejoin="round"/>\n`;
        body += `        <path d="M ${hi.join(' L ')}" fill="none" stroke="#ffffff" stroke-width="${Math.max(1, midR * 0.30).toFixed(1)}" stroke-opacity="0.65" stroke-linecap="round"/>\n`;
        // leader stems (badge → own tube-end tip, same angular math as live)
        {
          const bud = (r.badge as unknown as { userData: { targetY: number; radius: number; lift: number; tipA: number; frac: number; nudge: number } }).userData;
          const tA = bud.tipA ?? r.endA;
          const tipX = Math.cos(tA) * r.radius, tipZ = -Math.sin(tA) * r.radius;
          const outX = Math.cos(tA), outZ = -Math.sin(tA);
          const rrOut = maxR + 0.55 + (bud.nudge || 0);
          const ly = tubeY + 0.12 + bud.targetY * lift * 0.35;
          const bTop = proj(new THREE.Vector3(outX * rrOut, ly, outZ * rrOut));
          const bBot = proj(new THREE.Vector3(tipX, tubeY, tipZ));
          body += `        <line x1="${bTop[0].toFixed(1)}" y1="${bTop[1].toFixed(1)}" x2="${bBot[0].toFixed(1)}" y2="${bBot[1].toFixed(1)}" stroke="${dark ? '#666666' : '#cccccc'}" stroke-width="1" stroke-opacity="0.6"/>\n`;
        }
      });
      // labels as panel pills at their live screen positions
      const labels = captureLabelPositions(container, a.labelRefs);
      let labelsSvg = '';
      labels.forEach((l) => {
        scratch.font = `700 11px ${theme.fontBody}`;
        const tw = scratch.measureText(l.text).width;
        const chipW = tw + 16, chipH = 19;
        labelsSvg += `        <rect x="${(l.x - chipW / 2).toFixed(1)}" y="${(l.y - chipH / 2).toFixed(1)}" width="${chipW.toFixed(1)}" height="${chipH}" rx="9.5" fill="rgba(255,255,255,0.94)" stroke="rgba(0,0,0,0.10)"/>\n`;
        labelsSvg += `        <text x="${l.x.toFixed(1)}" y="${(l.y + 0.5).toFixed(1)}" class="rb-label">${escXml(l.text)}</text>\n`;
      });
      // legend row
      let legendSvg = ''; let lx = 16; const ly = H - 14;
      a.rings.forEach((r) => {
        legendSvg += `        <rect x="${lx}" y="${ly - 9}" width="14" height="10" rx="4" fill="${r.color}"/>\n`;
        const tx = lx + 22;
        legendSvg += `        <text x="${tx}" y="${ly}" class="rb-legend">${escXml(r.name)}</text>\n`;
        scratch.font = `600 10.5px ${theme.fontBody}`;
        lx = tx + scratch.measureText(r.name).width + 20;
        if (lx > W - 60) { lx = 16; };
      });
      return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs><style>
    text { font-family: ${escXml(theme.fontBody)}; }
    .rb-title { font-family: ${escXml(theme.fontDisplay)}; font-size: 15px; font-weight: 700; fill: #1c2620; }
    .rb-legend { font-size: 10.5px; font-weight: 600; fill: #39443d; dominant-baseline: middle; }
    .rb-label { font-size: 11px; font-weight: 700; fill: ${escXml(theme.ink)}; text-anchor: middle; dominant-baseline: central; }
  </style>
${defs}  </defs>
  <rect width="100%" height="100%" fill="#ffffff"/>
  <text x="12" y="22" class="rb-title">${escXml(title)}</text>
  <g id="radial-tubes">${body}</g>
  <g id="radial-labels">${labelsSvg}</g>
  <g id="radial-legend">${legendSvg}</g>
</svg>`;
    },
  }), [data, palette, theme, dim, dark]);

  const toggleZoom = (e: React.MouseEvent) => {
    e.stopPropagation();
    const next = !zoomOn;
    setZoomOn(next);
    api.current?.setZoom(next);
  };

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full">
      <button
        onClick={toggleZoom}
        data-tip={zoomOn ? 'Scroll-zoom: on' : 'Scroll-zoom: off'}
        className={`absolute left-2 top-2 z-10 rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${zoomOn ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
        title={zoomOn ? 'Turn scroll-zoom off' : 'Turn scroll-zoom on'}
      >
        {zoomOn ? '🔍+ on' : '🔍+ off'}
      </button>
      {tip && (
        <div className="tk-pop pointer-events-none absolute z-10 max-w-[220px] px-2.5 py-1 font-body text-[11px] font-bold text-ink"
          style={{ left: Math.min(tip.x + 12, (containerRef.current?.clientWidth || 300) - 190), top: Math.max(0, tip.y - 34) }}>
          {tip.text}
        </div>
      )}
    </div>
  );
});

export default ThreeRadialBar;
