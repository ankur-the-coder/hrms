import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
/* (Kalam removed — labels, legend and hover card now use the theme panel font) */
import type { ExportTheme } from './exportUtils';

/* ============================================================
   Three.js Sankey 3D — EXACT port of the reference `sankey3D.html`
   mock ("3D Sankey - Hiring Funnel").

   Everything below mirrors the reference file 1:1:
   - Scene: TRANSPARENT background (no beige panel / fog) so the chart
     PCFSoft shadows, studio 3-light rig with the same intensities.
   - Geometry: RoundedBox nodes (1.2 wide, 0.2 radius — 1.5 / 0.4 for
     "Job boards"), 64-segment watertight bezier flow ribbons with
     analytic top/bottom normals and 6 closed surfaces (front / back /
     top / bottom / left cap / right cap).
   - Layout engine: stages at startX -8.5 → endX 11.0, maxAllowedHeight
     7.5, gap 0.5, vertical centre 1.0, dropoff-aware stage sorting,
     centerY-sorted inbound/outbound stacking, collision-free Z-layering
     (adjacent ±0.04 / bypass -0.36·rank), unique flow colours.
   - Material: frosted-glass MeshPhysicalMaterial (metalness 0.1,
     roughness 0.25, transmission 0.9/0.95, thickness 2.0, ior 1.5,
     clearcoat 1.0 / 0.1) on every node and flow.
   - Palette: the reference 15-colour palette + the exact hiring-funnel
     node/link colours.
   - Behaviour: OrbitControls with the reference limits, camera preset
     morph (CAM_3D ↔ CAM_2D with fov 40 ↔ 15), Z-flatten to 0.035,
     lighting/fog/platform fades, hover isolate (1.0 / 0.22 + 2.5% pop)
     with the reference tooltip copy, Kalam node labels + legend.
   - Exports: 4x supersampled PNG composite and the true-vector SVG
     (re-projected ribbons/nodes/labels/legend, no raster layers).

   The ONLY adaptation is data plumbing: the reference hard-codes three
   demo datasets, while this component derives the identical
   {nodes, links} dataset shape from the `links` prop (live DB data).
   For the QA hiring funnel the derived stages, values and colours are
   exactly the reference's.
   ============================================================ */

export interface SankeyLink { source: string; target: string; value: number }

export interface ThreeChartHandle {
  exportPNG: (title: string) => Promise<Blob>;
  exportSVG: (title: string) => Promise<string>;
  setZoom?: (on: boolean) => void;
}

interface Props {
  links: SankeyLink[];
  palette: string[];
  /** '2d' | '3d' — the SAME scene renders both; only the camera and a Z-scale
   * flatten morph between them, so node/flow dimensions never change. */
  dim?: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

/* ---------------- reference palette + hiring colours (verbatim) ---------------- */
const REFERENCE_PALETTE = [
  '#7dd4f8', '#f07ed0', '#4dba80', '#fcc84a', '#f7984a',
  '#5cd9d5', '#6b9ff5', '#a8db5a', '#f87171', '#a78bfa',
  '#fb923c', '#34d399', '#f472b6', '#38bdf8', '#b8e065',
];

/** Reference hiring-dataset node colours, keyed by lowercase node name. */
const NODE_COLORS: Record<string, string> = {
  'job boards': '#7dd4f8',
  'linkedin': '#f07ed0',
  'referrals': '#4dba80',
  'screened': '#fcc84a',
  'interviewed': '#f7984a',
  'rejected': '#5cd9d5',
  'offered': '#6b9ff5',
  'hired': '#a8db5a',
  'declined': '#f87171',
};

/** Reference hiring-dataset link colours, keyed by "source|target" (lowercase). */
const LINK_COLORS: Record<string, string> = {
  'job boards|screened': '#7dd4f8',
  'linkedin|screened': '#f07ed0',
  'referrals|screened': '#4dba80',
  'screened|rejected': '#5cd9d5',
  'screened|interviewed': '#f7984a',
  'interviewed|rejected': '#a78bfa',
  'interviewed|offered': '#6b9ff5',
  'offered|hired': '#a8db5a',
  'offered|declined': '#f87171',
};

/* ---------------- reference dataset shape ---------------- */
interface DsNode {
  id: string; name: string; value: number; stage: number; color: string;
  x: number; height: number; topY: number; botY: number; centerY: number;
  outOffset: number; inOffset: number;
  outboundLinks: DsLink[]; inboundLinks: DsLink[];
  legendIdx: number;
}
interface DsLink { source: string; target: string; value: number; color?: string }
interface DsDataset { title: string; nodes: DsNode[]; links: DsLink[] }
interface FlowRec {
  startX: number; endX: number; topY1: number; botY1: number; topY2: number; botY2: number;
  color: string; zDepth: number; zCenter: number;
  sourceId: string; targetId: string; sourceName: string; targetName: string; value: number;
}

/** Derive a reference-shaped dataset from live link data. Stages come from
 * longest-path column assignment; values are max(inflow, outflow); colours
 * resolve to the reference hiring colours whenever names match (so the QA
 * hiring funnel is pixel-identical to the mock) and fall back to the
 * reference palette in order of appearance otherwise. */
function deriveDataset(links: SankeyLink[]): DsDataset {
  const clean = (links || []).filter((l) => l.value > 0 && l.source !== l.target);
  const names = [...new Set(clean.flatMap((l) => [l.source, l.target]))];
  const idx = new Map(names.map((n, i) => [n, i]));
  const outs = names.map(() => [] as number[]);
  const ins = names.map(() => [] as number[]);
  clean.forEach((l, li) => { outs[idx.get(l.source)!].push(li); ins[idx.get(l.target)!].push(li); });
  const col = new Array(names.length).fill(0);
  const visit = (i: number, depth: number, seen: Set<number>) => {
    if (seen.has(i) || depth > 32) return;
    col[i] = Math.max(col[i], depth);
    seen.add(i);
    outs[i].forEach((li) => visit(idx.get(clean[li].target)!, depth + 1, seen));
    seen.delete(i);
  };
  names.forEach((_, i) => { if (!ins[i].length) visit(i, 0, new Set()); });
  const slug = (s: string, i: number) =>
    `${s.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'node'}_${i}`;
  const nodes: DsNode[] = names.map((name, i) => {
    const outSum = outs[i].reduce((s, li) => s + clean[li].value, 0);
    const inSum = ins[i].reduce((s, li) => s + clean[li].value, 0);
    return {
      id: slug(name, i), name, value: Math.max(outSum, inSum), stage: col[i],
      color: NODE_COLORS[name.toLowerCase()] || REFERENCE_PALETTE[i % REFERENCE_PALETTE.length],
      x: 0, height: 0, topY: 0, botY: 0, centerY: 0, outOffset: 0, inOffset: 0,
      outboundLinks: [], inboundLinks: [], legendIdx: i,
    };
  });
  const byName = new Map(nodes.map((n) => [n.name, n]));
  const dsLinks: DsLink[] = clean.map((l) => ({
    source: byName.get(l.source)!.id,
    target: byName.get(l.target)!.id,
    value: l.value,
    color: LINK_COLORS[`${l.source.toLowerCase()}|${l.target.toLowerCase()}`],
  }));
  return { title: '', nodes, links: dsLinks };
}

function escXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function adjustColor(hex: string, percent: number): string {
  const num = parseInt(hex.replace('#', ''), 16);
  let r = (num >> 16) + Math.round(255 * (percent / 100));
  let g = ((num >> 8) & 0x00ff) + Math.round(255 * (percent / 100));
  let b = (num & 0x0000ff) + Math.round(255 * (percent / 100));
  r = Math.min(255, Math.max(0, r));
  g = Math.min(255, Math.max(0, g));
  b = Math.min(255, Math.max(0, b));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

const ThreeSankey3D = forwardRef<ThreeChartHandle, Props>(function ThreeSankey3D(
  { links, dim = '3d', hoverIndex, onHover, theme }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const legendRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; title: string; value: string; color: string } | null>(null);
  const [zoomOn, setZoomOn] = useState(false);

  const S = useRef<{
    setDim: (d: '2d' | '3d') => void;
    hoverByLegendIdx: (i: number | null) => void;
    setZoom: (on: boolean) => void;
    exportPNG: (title: string) => Promise<Blob>;
    exportSVG: (title: string) => Promise<string>;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const el = containerRef.current;
    const legendEl = legendRef.current;
    if (!el) return;
    const container: HTMLDivElement = el;
    const W0 = container.clientWidth || 600;
    const H0 = container.clientHeight || 360;
    // Panel font for outside labels + exports (same family the pie/donut
    // labels use) — resolved once per mount from the export theme.
    const panelFontCss = theme.fontBody || "'Outfit', system-ui, sans-serif";
    const panelInk = theme.ink || '#1c2620';
    const panelDisplayCss = theme.fontDisplay || panelFontCss;

    /* --- 1. SETUP SCENE, CAMERA, RENDERERS (reference verbatim) --- */
    const scene = new THREE.Scene();
    // Transparent scene — the chart sits DIRECTLY in the tile (no separate
    // white/beige panel behind it); the card's own surface shows through.
    scene.background = null;
    scene.fog = null;

    const camera = new THREE.PerspectiveCamera(40, W0 / H0, 0.1, 100);
    camera.position.set(-2, 10, 32);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(W0, H0);
    // DPR cap: full device pixels on huge/retina panels 4x the fragment cost
    // for zero visible gain — 1.75 is the crispness/perf sweet spot.
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.setSize(W0, H0);
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.top = '0px';
    labelRenderer.domElement.style.left = '0px';
    labelRenderer.domElement.style.pointerEvents = 'none';
    container.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.enableZoom = false;
    controls.zoomSpeed = 1.4;
    controls.enablePan = true;
    controls.panSpeed = 1.0;
    controls.enableRotate = true;
    controls.minDistance = 1;
    controls.maxDistance = 200;
    controls.minPolarAngle = 0;
    controls.maxPolarAngle = Math.PI;
    controls.target.set(1, 1, 0);
    controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };

    /* --- VIEW TRANSITION STATE (2D <-> 3D) (reference verbatim) --- */
    let viewMix = dim === '2d' ? 1 : 0;
    let targetViewMix = viewMix;
    let isTransitioning = false;

    // Camera presets keep the reference's LOOK DIRECTION (oblique 3/4 view
    // for 3D, dead-on for 2D) but the DISTANCE is auto-fitted to the live
    // container (see fitPresets()) so the chart fills the frame instead of
    // sitting pushed-back and small. Default 3D reads ~1.7x bigger while
    // the whole graph is guaranteed inside the frustum.
    const CAM_3D = { pos: new THREE.Vector3(-2, 10, 32), target: new THREE.Vector3(1, 1, 0), fov: 40 };
    const CAM_2D = { pos: new THREE.Vector3(1, 1, 55), target: new THREE.Vector3(1, 1, 0), fov: 15 };

    /** Re-fit both camera presets so the full graph (plus label headroom)
     * sits exactly inside the current container. Called after the dataset
     * renders and on every resize — aspect-aware, so narrow and wide
     * frames both get a maximally-filled, never-clipped chart. */
    function fitPresets() {
      const W = container.clientWidth || 600;
      const H = container.clientHeight || 360;
      const aspect = W / H;
      camera.aspect = aspect;
      camera.updateProjectionMatrix();
      // World-space bounds of the graph (layout engine is fixed-scale).
      const box = new THREE.Box3().setFromObject(sankeyGroup);
      if (box.isEmpty()) return;
      box.expandByPoint(new THREE.Vector3(box.min.x, box.max.y + 1.15, box.max.z)); // label headroom
      box.expandByPoint(new THREE.Vector3(box.min.x, box.min.y - 0.35, box.min.z));
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      center.x += 1; center.y = Math.max(center.y, 0.4); // match reference target bias
      const fitDist = (fovDeg: number, dir: THREE.Vector3) => {
        const fov = THREE.MathUtils.degToRad(fovDeg);
        const fitH = (size.y / 2) / Math.tan(fov / 2);
        const fitW = (size.x / 2) / (Math.tan(fov / 2) * aspect);
        const fit = Math.max(fitH, fitW, size.z);
        // compensate for oblique viewing: the projected footprint grows
        const obl = 1 + Math.abs(dir.clone().normalize().y) * 0.35 + Math.abs(dir.clone().normalize().x) * 0.12;
        return (fit * obl + size.length() * 0.08) * 1.06; // 6% breathing margin
      };
      // 3D: keep the reference oblique direction, pull in to a fitted spot
      const dir3 = new THREE.Vector3(-3, 9, 32).normalize();
      const d3 = fitDist(40, dir3);
      CAM_3D.pos.copy(center).addScaledVector(dir3, d3);
      CAM_3D.target.copy(center);
      CAM_3D.fov = 40;
      // 2D: dead-on front view, long-lens feel like the reference
      const dir2 = new THREE.Vector3(0, 0, 1);
      const d2 = fitDist(15, dir2);
      CAM_2D.pos.copy(center).addScaledVector(dir2, d2);
      CAM_2D.target.copy(center);
      CAM_2D.fov = 15;
      // keep the live camera glued to the active preset (unless mid-morph
      // or user-orbiting: only re-seat when settled on a preset view)
      if (!isTransitioning) {
        const preset = targetViewMix > 0.5 ? CAM_2D : CAM_3D;
        const settled = camera.position.distanceTo(preset.pos) < d3 * 0.02;
        if (settled || !userOrbited) {
          camera.position.copy(preset.pos);
          controls.target.copy(preset.target);
          camera.fov = preset.fov;
          camera.updateProjectionMatrix();
        }
      }
      controls.minDistance = d3 * 0.35;
      controls.maxDistance = Math.max(200, d2 * 2.2);
    }
    let userOrbited = false;

    function easeInOutCubic(t: number) {
      return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }

    function setView(mode: '2d' | '3d') {
      targetViewMix = mode === '2d' ? 1 : 0;
      isTransitioning = true;
    }

    controls.addEventListener('start', () => { isTransitioning = false; userOrbited = true; });

    // Wheel policy (Fix: page scroll used to die over this canvas): the page
    // owns the wheel by default. ONLY while scroll-zoom is toggled ON (the
    // 🔍+ button) do we claim the gesture — otherwise the event bubbles to
    // the page scroller untouched. OrbitControls' own wheel listener early-
    // returns while controls.enableZoom === false, so nothing else can
    // swallow the scroll either; drag-orbit / pan are unaffected.
    let zoomOnRef = false; // mirrored by setZoom() below
    const onWheel = (e: WheelEvent) => {
      if (zoomOnRef) e.preventDefault();
    };
    container.addEventListener('wheel', onWheel, { passive: false });

    /* --- 2. LIGHTING (Studio Setup) (reference verbatim) --- */
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xfffdfa, 2.5);
    dirLight.position.set(10, 20, 15);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 50;
    dirLight.shadow.camera.left = -15;
    dirLight.shadow.camera.right = 15;
    dirLight.shadow.camera.top = 15;
    dirLight.shadow.camera.bottom = -15;
    dirLight.shadow.bias = -0.0005;
    dirLight.shadow.normalBias = 0.04;
    scene.add(dirLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 1.5);
    rimLight.position.set(-15, 10, -15);
    scene.add(rimLight);

    const LIGHT_3D = { ambient: 1.2, dir: 2.5, rim: 1.5 };
    const LIGHT_2D = { ambient: 1.9, dir: 0.9, rim: 0.25 };

    /* --- 2B. SANKEY GROUP --- */
    const sankeyGroup = new THREE.Group();
    scene.add(sankeyGroup);

    /* --- 3. BASE PLATFORM — REMOVED (chart sits directly in the tile).
       Shadows fall on an invisible ShadowMaterial catcher instead. --- */
    const platformGeo = new THREE.PlaneGeometry(48, 26);
    const platformMat = new THREE.ShadowMaterial({ opacity: 0.16, transparent: true });
    const platform = new THREE.Mesh(platformGeo, platformMat);
    platform.rotation.x = -Math.PI / 2;
    platform.position.set(1, -4.55, -1);
    platform.receiveShadow = true;
    scene.add(platform);

    /* --- 4. MATERIAL FACTORY (reference verbatim) --- */
    // Material cache: one physical material per (color, transmission) — the
    // reference minted a fresh program per node/flow; sharing keeps the GPU
    // program count tiny and makes hover opacity writes O(1).
    const matCache = new Map<string, THREE.MeshPhysicalMaterial>();
    // Transmission renders an extra scene pass; reserve true transmission
    // for large hero meshes and use cheap opacity-glass below the threshold.
    const TRANSMISSION_AREA = 2.2;
    function createGlassMaterial(hexColor: string, transmission = 0.9, opacity = 1.0, approxArea = 10) {
      const key = `${hexColor}|${transmission}|${approxArea > TRANSMISSION_AREA ? 't' : 'f'}`;
      const hit = matCache.get(key);
      if (hit) { hit.opacity = opacity; return hit.clone(); }
      const useTransmission = approxArea > TRANSMISSION_AREA;
      const mat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(hexColor),
        metalness: 0.1,
        roughness: useTransmission ? 0.25 : 0.32,
        transmission: useTransmission ? transmission : 0,
        thickness: 2.0,
        ior: 1.5,
        transparent: true,
        opacity: useTransmission ? opacity : Math.min(1, opacity * 0.96),
        side: THREE.DoubleSide,
        clearcoat: 1.0,
        clearcoatRoughness: 0.1,
      });
      matCache.set(key, mat);
      return mat.clone();
    }

    /* --- 5. CUSTOM GEOMETRY GENERATOR FOR SANKEY FLOWS (reference verbatim) --- */
    function createSankeyFlow(
      startX: number, endX: number, topY1: number, botY1: number, topY2: number, botY2: number,
      zDepth: number, material: THREE.Material, zCenter = 0,
    ) {
      // Adaptive tessellation: hero ribbons keep 48 segments, thin bypass
      // flows drop to 28 — halves vertex count with no visible change.
      const segments = zDepth >= 0.9 ? 48 : 28;
      const midX = startX + (endX - startX) * 0.5;

      const getBezier = (t: number, p0: number, p1: number, p2: number, p3: number) => {
        const mt = 1 - t;
        return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3;
      };

      const getBezierDeriv = (t: number, p0: number, p1: number, p2: number, p3: number) => {
        const mt = 1 - t;
        return 3 * mt * mt * (p1 - p0) + 6 * mt * t * (p2 - p1) + 3 * t * t * (p3 - p2);
      };

      const pts: { x: number; topY: number; botY: number; topNorm: number[]; botNorm: number[] }[] = [];
      for (let i = 0; i <= segments; i++) {
        const t = i / segments;
        const x = getBezier(t, startX, midX, midX, endX);
        const topY = getBezier(t, topY1, topY1, topY2, topY2);
        const botY = getBezier(t, botY1, botY1, botY2, botY2);

        const dx = getBezierDeriv(t, startX, midX, midX, endX);
        const dtopY = getBezierDeriv(t, topY1, topY1, topY2, topY2);
        const dbotY = getBezierDeriv(t, botY1, botY1, botY2, botY2);

        const topLen = Math.hypot(dx, dtopY) || 1;
        const botLen = Math.hypot(dx, dbotY) || 1;

        const topNorm = [-dtopY / topLen, dx / topLen, 0];
        const botNorm = [dbotY / botLen, -dx / botLen, 0];

        pts.push({ x, topY, botY, topNorm, botNorm });
      }

      const halfZ = zDepth / 2;
      const frontZ = zCenter + halfZ;
      const backZ = zCenter - halfZ;

      const positions: number[] = [];
      const normals: number[] = [];
      const uvs: number[] = [];
      const indices: number[] = [];

      let vCount = 0;

      // 1. Front Surface
      const frontStart = vCount;
      for (let i = 0; i <= segments; i++) {
        const p = pts[i];
        const u = i / segments;
        positions.push(p.x, p.topY, frontZ, p.x, p.botY, frontZ);
        normals.push(0, 0, 1, 0, 0, 1);
        uvs.push(u, 1, u, 0);
      }
      vCount += (segments + 1) * 2;
      for (let i = 0; i < segments; i++) {
        const idx = frontStart + i * 2;
        indices.push(idx, idx + 1, idx + 3);
        indices.push(idx, idx + 3, idx + 2);
      }

      // 2. Back Surface
      const backStart = vCount;
      for (let i = 0; i <= segments; i++) {
        const p = pts[i];
        const u = i / segments;
        positions.push(p.x, p.topY, backZ, p.x, p.botY, backZ);
        normals.push(0, 0, -1, 0, 0, -1);
        uvs.push(u, 1, u, 0);
      }
      vCount += (segments + 1) * 2;
      for (let i = 0; i < segments; i++) {
        const idx = backStart + i * 2;
        indices.push(idx, idx + 3, idx + 1);
        indices.push(idx, idx + 2, idx + 3);
      }

      // 3. Top Surface
      const topStart = vCount;
      for (let i = 0; i <= segments; i++) {
        const p = pts[i];
        const u = i / segments;
        positions.push(p.x, p.topY, backZ, p.x, p.topY, frontZ);
        normals.push(...p.topNorm, ...p.topNorm);
        uvs.push(u, 0, u, 1);
      }
      vCount += (segments + 1) * 2;
      for (let i = 0; i < segments; i++) {
        const idx = topStart + i * 2;
        indices.push(idx, idx + 1, idx + 3);
        indices.push(idx, idx + 3, idx + 2);
      }

      // 4. Bottom Surface
      const botStart = vCount;
      for (let i = 0; i <= segments; i++) {
        const p = pts[i];
        const u = i / segments;
        positions.push(p.x, p.botY, frontZ, p.x, p.botY, backZ);
        normals.push(...p.botNorm, ...p.botNorm);
        uvs.push(u, 0, u, 1);
      }
      vCount += (segments + 1) * 2;
      for (let i = 0; i < segments; i++) {
        const idx = botStart + i * 2;
        indices.push(idx, idx + 1, idx + 3);
        indices.push(idx, idx + 3, idx + 2);
      }

      // 5. Left Cap
      const leftStart = vCount;
      positions.push(startX, topY1, backZ, startX, topY1, frontZ, startX, botY1, frontZ, startX, botY1, backZ);
      normals.push(-1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0);
      uvs.push(0, 1, 1, 1, 1, 0, 0, 0);
      indices.push(leftStart, leftStart + 1, leftStart + 2);
      indices.push(leftStart, leftStart + 2, leftStart + 3);
      vCount += 4;

      // 6. Right Cap
      const rightStart = vCount;
      positions.push(endX, topY2, frontZ, endX, topY2, backZ, endX, botY2, backZ, endX, botY2, frontZ);
      normals.push(1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0);
      uvs.push(0, 1, 1, 1, 1, 0, 0, 0);
      indices.push(rightStart, rightStart + 1, rightStart + 2);
      indices.push(rightStart, rightStart + 2, rightStart + 3);
      vCount += 4;

      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
      geo.setIndex(indices);

      const mesh = new THREE.Mesh(geo, material);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      return mesh;
    }

    /* --- 6. ADDING NODES (reference verbatim) --- */
    function addNode(
      x: number, yCenter: number, height: number, zDepth: number,
      material: THREE.Material, labelText: string | null, nodeData: Record<string, unknown>,
    ) {
      let geo: RoundedBoxGeometry;
      if (labelText && labelText.includes('Job boards')) {
        geo = new RoundedBoxGeometry(1.5, height, zDepth + 0.3, 4, 0.4);
      } else {
        geo = new RoundedBoxGeometry(1.2, height, zDepth + 0.2, 4, 0.2);
      }
      const mesh = new THREE.Mesh(geo, material);
      mesh.position.set(x, yCenter, 0);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.userData = { type: 'node', ...nodeData };
      sankeyGroup.add(mesh);

      if (labelText) {
        // OUTSIDE label only (no duplicate inside labels): a single CSS2D
        // marker floating above the node face, styled like the app's other
        // chart labels (theme panel font, pill chip) — see .sk3d-out-label.
        const div = document.createElement('div');
        div.className = 'sk3d-out-label';
        div.style.fontFamily = panelFontCss;
        div.style.color = panelInk;
        div.textContent = labelText;
        const label = new CSS2DObject(div);
        label.position.set(0, height / 2 + 0.34, zDepth / 2 + 0.3);
        mesh.add(label);
      }
      return mesh;
    }

    /* --- 7. DYNAMIC SANKEY GRAPH ENGINE (reference verbatim) --- */
    let activeGraphData: { title: string; nodes: DsNode[]; flows: FlowRec[]; legend: { name: string; color: string }[] } =
      { title: '', nodes: [], flows: [], legend: [] };

    function clearSankeyGroup() {
      const labelContainer = labelRenderer.domElement;
      while (labelContainer.firstChild) {
        labelContainer.removeChild(labelContainer.firstChild);
      }
      container.querySelectorAll('.sk3d-out-label').forEach((el) => el.remove());

      while (sankeyGroup.children.length > 0) {
        const child = sankeyGroup.children[0];
        const mesh = child as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        if (mesh.material) {
          if (Array.isArray(mesh.material)) mesh.material.forEach((mm) => mm.dispose());
          else (mesh.material as THREE.Material).dispose();
        }
        sankeyGroup.remove(child);
      }
    }

    function renderDataset(dataset: DsDataset) {
      clearSankeyGroup();

      const stagesMap: Record<string, DsNode[]> = {};
      let maxStage = 0;
      dataset.nodes.forEach((n) => {
        if (n.stage > maxStage) maxStage = n.stage;
        if (!stagesMap[n.stage]) stagesMap[n.stage] = [];
        stagesMap[n.stage].push(n);
      });

      const startX = -8.5;
      const endX = 11.0;
      const stepX = (endX - startX) / Math.max(1, maxStage);

      let maxStageSum = 0;
      Object.keys(stagesMap).forEach((stg) => {
        const sum = stagesMap[stg].reduce((acc, curr) => acc + curr.value, 0);
        if (sum > maxStageSum) maxStageSum = sum;
      });

      const maxAllowedHeight = 7.5;
      const scaleY = maxAllowedHeight / Math.max(1, maxStageSum);

      const nodeLookup: Record<string, DsNode> = {};

      Object.keys(stagesMap).forEach((stg) => {
        const stageIdx = parseInt(stg, 10);
        const stageNodes = stagesMap[stg];
        const xPos = startX + stageIdx * stepX;

        stageNodes.sort((a, b) => {
          const isDropA = /abandoned|rejected|declined|loss/i.test(a.name || a.id);
          const isDropB = /abandoned|rejected|declined|loss/i.test(b.name || b.id);
          if (isDropA && !isDropB) return 1;
          if (!isDropA && isDropB) return -1;
          return b.value - a.value;
        });

        const totalValue = stageNodes.reduce((acc, curr) => acc + curr.value, 0);
        const totalNodeHeight = totalValue * scaleY;
        const gap = 0.5;
        const totalBlockHeight = totalNodeHeight + (stageNodes.length - 1) * gap;

        let currentY = 1.0 + totalBlockHeight / 2;

        stageNodes.forEach((node) => {
          const h = Math.max(0.4, node.value * scaleY);
          node.x = xPos;
          node.height = h;
          node.topY = currentY;
          node.botY = currentY - h;
          node.centerY = (node.topY + node.botY) / 2;
          node.outOffset = 0;
          node.inOffset = 0;

          currentY -= h + gap;
          nodeLookup[node.id] = node;
        });
      });

      dataset.nodes.forEach((node) => {
        const nObj = nodeLookup[node.id];
        if (!nObj) return;

        nObj.outboundLinks = dataset.links.filter((l) => l.source === node.id);
        nObj.outboundLinks.sort((a, b) => {
          const tgtA = nodeLookup[a.target];
          const tgtB = nodeLookup[b.target];
          return (tgtB ? tgtB.centerY : 0) - (tgtA ? tgtA.centerY : 0);
        });

        nObj.inboundLinks = dataset.links.filter((l) => l.target === node.id);
        nObj.inboundLinks.sort((a, b) => {
          const srcA = nodeLookup[a.source];
          const srcB = nodeLookup[b.source];
          return (srcB ? srcB.centerY : 0) - (srcA ? srcA.centerY : 0);
        });
      });

      const linkSourceOffsets = new Map<DsLink, { topY: number; botY: number }>();
      const linkTargetOffsets = new Map<DsLink, { topY: number; botY: number }>();

      dataset.nodes.forEach((node) => {
        const nObj = nodeLookup[node.id];
        if (!nObj) return;

        let outAcc = 0;
        nObj.outboundLinks.forEach((link) => {
          const flowHeight = link.value * scaleY;
          linkSourceOffsets.set(link, { topY: nObj.topY - outAcc, botY: nObj.topY - outAcc - flowHeight });
          outAcc += flowHeight;
        });

        let inAcc = 0;
        nObj.inboundLinks.forEach((link) => {
          const flowHeight = link.value * scaleY;
          linkTargetOffsets.set(link, { topY: nObj.topY - inAcc, botY: nObj.topY - inAcc - flowHeight });
          inAcc += flowHeight;
        });
      });

      const computedFlows: FlowRec[] = [];
      const usedColors = new Set<string>();
      let palIdx = 0;

      dataset.links.forEach((link, idx) => {
        const src = nodeLookup[link.source];
        const tgt = nodeLookup[link.target];
        if (!src || !tgt) return;

        const srcOffsets = linkSourceOffsets.get(link);
        const tgtOffsets = linkTargetOffsets.get(link);
        if (!srcOffsets || !tgtOffsets) return;

        const stageSpan = Math.abs(tgt.stage - src.stage);

        let zCenter = 0;
        let zDepth = 1.0;

        if (stageSpan > 1) {
          const bypassRank = stageSpan - 1;
          zCenter = -0.36 * bypassRank;
          zDepth = 0.72;
        } else {
          zCenter = idx % 2 === 0 ? 0.04 : -0.04;
          zDepth = 0.94;
        }

        let flowColor = link.color || src.color;
        if (usedColors.has(flowColor)) {
          while (palIdx < REFERENCE_PALETTE.length && usedColors.has(REFERENCE_PALETTE[palIdx])) {
            palIdx++;
          }
          if (palIdx < REFERENCE_PALETTE.length) {
            flowColor = REFERENCE_PALETTE[palIdx];
          }
        }
        usedColors.add(flowColor);

        computedFlows.push({
          startX: src.x,
          endX: tgt.x,
          topY1: srcOffsets.topY,
          botY1: srcOffsets.botY,
          topY2: tgtOffsets.topY,
          botY2: tgtOffsets.botY,
          color: flowColor,
          zDepth,
          zCenter,
          sourceId: src.id,
          targetId: tgt.id,
          sourceName: src.name,
          targetName: tgt.name,
          value: link.value,
        });
      });

      dataset.nodes.forEach((node) => {
        const isIntermediateBar = node.stage > 0 && node.stage < maxStage;
        const mat = createGlassMaterial(node.color, isIntermediateBar ? 0.95 : 0.9, 1.0);
        addNode(node.x, node.centerY, node.height, isIntermediateBar ? 1.3 : 1.0, mat, `${node.name} · ${node.value}`, {
          ...node,
          outboundLinks: undefined,
          inboundLinks: undefined,
        });
      });

      computedFlows.forEach((flow) => {
        const mat = createGlassMaterial(flow.color, 0.9, 1.0);
        const flowMesh = createSankeyFlow(
          flow.startX, flow.endX,
          flow.topY1, flow.botY1,
          flow.topY2, flow.botY2,
          flow.zDepth, mat, flow.zCenter,
        );
        flowMesh.userData = { type: 'flow', ...flow };
        sankeyGroup.add(flowMesh);
      });

      // In-scene color legend REMOVED (was the 2nd set of color labels):
      // node identity lives ONLY in the outside pill labels + the card
      // legend below the chart. Legend data is still computed for exports.
      {
        const uniqueLegend: { name: string; color: string }[] = [];
        dataset.nodes.forEach((n) => {
          if (!uniqueLegend.find((item) => item.name === n.name)) {
            uniqueLegend.push({ name: n.name, color: n.color });
          }
        });
        activeGraphData = { title: dataset.title, nodes: dataset.nodes, flows: computedFlows, legend: uniqueLegend };
      }
      void legendEl;
    }

    /* --- HOVER PIPES ANIMATION & HIGHLIGHT MANAGER (reference verbatim) --- */
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let hoveredMesh: THREE.Object3D | null = null;

    function setHover(mesh: THREE.Object3D, clientX?: number, clientY?: number) {
      hoveredMesh = mesh;
      container.style.cursor = 'pointer';

      const data = mesh.userData as Record<string, unknown>;
      // Hover card content — the same "Name · value" language as the Sankey
      // (classic) labels; the card chrome itself matches the other charts'
      // hover boxes (panel font, tk-pop surface — see .sankey3d-tip).
      const tipMat = (mesh as THREE.Mesh).material as THREE.MeshPhysicalMaterial | THREE.MeshPhysicalMaterial[];
      const tipMatColor = Array.isArray(tipMat) ? tipMat[0]?.color : tipMat?.color;
      const tipTitle = data.type === 'flow'
        ? `${data.sourceName} → ${data.targetName}`
        : String(data.name ?? '');
      const tipValue = data.type === 'flow'
        ? `Flow · ${data.value}`
        : `Total · ${data.value}`;
      const tipColor = typeof data.color === 'string'
        ? data.color
        : tipMatColor ? `#${tipMatColor.getHexString()}` : '#999999';
      const rect = container.getBoundingClientRect();
      const px = clientX !== undefined ? clientX - rect.left : rect.width / 2;
      const py = clientY !== undefined ? clientY - rect.top : rect.height / 2;
      setTip({ x: px, y: py, title: tipTitle, value: tipValue, color: tipColor });
      const plain = data.type === 'flow'
        ? `${data.sourceName} → ${data.targetName} · ${data.value}`
        : `${data.name} · ${data.value}`;
      onHover?.(plain);

      sankeyGroup.children.forEach((child) => {
        const cm = child as THREE.Mesh;
        const cmat = cm.material as THREE.Material & { opacity?: number } | undefined;
        if (!cmat) return;

        if (child === mesh) {
          if (cmat.opacity !== undefined) cmat.opacity = 1.0;
          child.scale.set(1.025, 1.025, 1.025);
        } else if (
          data.type === 'flow' &&
          child.userData &&
          (child.userData.id === data.sourceId || child.userData.id === data.targetId)
        ) {
          if (cmat.opacity !== undefined) cmat.opacity = 1.0;
        } else if (
          data.type === 'node' &&
          child.userData &&
          child.userData.type === 'flow' &&
          (child.userData.sourceId === data.id || child.userData.targetId === data.id)
        ) {
          if (cmat.opacity !== undefined) cmat.opacity = 1.0;
        } else if (cmat.opacity !== undefined) {
          cmat.opacity = 0.22;
        }
      });
    }

    function resetHover() {
      hoveredMesh = null;
      container.style.cursor = 'default';
      setTip(null);
      onHover?.(null);

      sankeyGroup.children.forEach((child) => {
        const cm = child as THREE.Mesh;
        const cmat = cm.material as THREE.Material & { opacity?: number } | undefined;
        if (!cmat) return;
        if (cmat.opacity !== undefined) cmat.opacity = 1.0;
        child.scale.set(1.0, 1.0, 1.0);
      });
    }

    function hoverByLegendIdx(i: number | null) {
      if (i === null || i === undefined || i < 0) {
        if (hoveredMesh) resetHover();
        return;
      }
      const found = sankeyGroup.children.find(
        (c) => c.userData && c.userData.type === 'node' && (c.userData as { legendIdx?: number }).legendIdx === i,
      );
      if (found) {
        const v = new THREE.Vector3();
        found.getWorldPosition(v);
        v.project(camera);
        const rect = container.getBoundingClientRect();
        const sx = rect.left + ((v.x * 0.5 + 0.5) * rect.width);
        const sy = rect.top + (-(v.y * 0.5) + 0.5) * rect.height;
        setHover(found, sx, sy);
      } else if (hoveredMesh) {
        resetHover();
      }
    }

    const onPointerMove = (e: PointerEvent) => {
      wake();
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(sankeyGroup.children, true);

      if (intersects.length > 0) {
        let hitObj: THREE.Object3D | null = intersects[0].object;
        while (hitObj && hitObj.parent && hitObj.parent !== sankeyGroup) {
          hitObj = hitObj.parent;
        }

        if (hitObj && hitObj.userData && (hitObj.userData as { type?: string }).type) {
          if (hoveredMesh !== hitObj) {
            setHover(hitObj, e.clientX, e.clientY);
          } else {
            // Same mesh still hovered — glide the card with the cursor.
            const data = hitObj.userData as Record<string, unknown>;
            const tipMat = (hitObj as THREE.Mesh).material as THREE.MeshPhysicalMaterial | THREE.MeshPhysicalMaterial[];
            const tipMatColor = Array.isArray(tipMat) ? tipMat[0]?.color : tipMat?.color;
            setTip({
              x: e.clientX - rect.left,
              y: e.clientY - rect.top,
              title: data.type === 'flow' ? `${data.sourceName} → ${data.targetName}` : String(data.name ?? ''),
              value: data.type === 'flow' ? `Flow · ${data.value}` : `Total · ${data.value}`,
              color: typeof data.color === 'string' ? data.color : tipMatColor ? `#${tipMatColor.getHexString()}` : '#999999',
            });
          }
          return;
        }
      }

      if (hoveredMesh) resetHover();
    };
    const onPointerLeave = () => { if (hoveredMesh) { resetHover(); wake(); } };
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    /* --- initial dataset (derived from live links) --- */
    renderDataset(deriveDataset(links));
    sankeyGroup.updateMatrixWorld(true);
    fitPresets();
    // re-seat onto the settled preset (first mount is never "user-orbited")
    {
      const preset = viewMix > 0.5 ? CAM_2D : CAM_3D;
      camera.position.copy(preset.pos);
      controls.target.copy(preset.target);
      camera.fov = preset.fov;
      camera.updateProjectionMatrix();
    }

    /* --- snap the initial lighting/flatten to the starting view
       (camera itself was already seated by fitPresets() above) --- */
    {
      const e0 = easeInOutCubic(viewMix);
      sankeyGroup.scale.z = THREE.MathUtils.lerp(1, 0.035, e0);
      ambientLight.intensity = THREE.MathUtils.lerp(LIGHT_3D.ambient, LIGHT_2D.ambient, e0);
      dirLight.intensity = THREE.MathUtils.lerp(LIGHT_3D.dir, LIGHT_2D.dir, e0);
      rimLight.intensity = THREE.MathUtils.lerp(LIGHT_3D.rim, LIGHT_2D.rim, e0);
      platformMat.opacity = THREE.MathUtils.lerp(0.16, 0.0, e0);
      platform.visible = platformMat.opacity > 0.01;
      dirLight.castShadow = e0 < 0.85;
    }

    /* --- 10. EXPORT FUNCTIONS (reference verbatim, container-scoped) --- */
    function exportPNG(title: string, scale = 4): Promise<Blob> {
      return new Promise((resolve, reject) => {
        try {
          const origWidth = container.clientWidth || 600;
          const origHeight = container.clientHeight || 360;
          const exportWidth = origWidth * scale;
          const exportHeight = origHeight * scale;

          const prevPixelRatio = renderer.getPixelRatio();
          renderer.setPixelRatio(scale);
          renderer.setSize(origWidth, origHeight, false);
          renderer.render(scene, camera);

          const canvas4x = document.createElement('canvas');
          canvas4x.width = exportWidth;
          canvas4x.height = exportHeight;
          const ctx = canvas4x.getContext('2d')!;

          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';

          ctx.clearRect(0, 0, exportWidth, exportHeight);

          ctx.drawImage(renderer.domElement, 0, 0, exportWidth, exportHeight);

          renderer.setPixelRatio(prevPixelRatio);
          renderer.setSize(origWidth, origHeight, false);
          renderer.render(scene, camera);

          ctx.fillStyle = '#2a2a2a';
          ctx.font = `700 ${24 * scale}px ${panelDisplayCss}`;
          ctx.textBaseline = 'top';
          ctx.fillText(title || activeGraphData.title, 40 * scale, 30 * scale);

          let startX = 40 * scale;
          const legendY = exportHeight - 40 * scale;
          ctx.font = `700 ${15 * scale}px ${panelFontCss}`;
          ctx.textBaseline = 'middle';

          activeGraphData.legend.forEach((item) => {
            const dotW = 14 * scale;
            const dotH = 10 * scale;
            const radius = 4 * scale;
            const dotY = legendY - dotH / 2;

            ctx.fillStyle = item.color;
            if ((ctx as CanvasRenderingContext2D & { roundRect?: (...a: number[]) => void }).roundRect) {
              ctx.beginPath();
              (ctx as unknown as { roundRect: (...a: number[]) => void }).roundRect(startX, dotY, dotW, dotH, radius);
              ctx.fill();
            } else {
              ctx.fillRect(startX, dotY, dotW, dotH);
            }

            ctx.fillStyle = '#333333';
            const textX = startX + dotW + 8 * scale;
            ctx.fillText(item.name, textX, legendY);

            const textWidth = ctx.measureText(item.name).width;
            startX = textX + textWidth + 20 * scale;
          });

          const cRect = container.getBoundingClientRect();
          const nodeLabelEls = container.querySelectorAll('.sk3d-out-label');
          nodeLabelEls.forEach((el) => {
            const text = el.textContent;
            if (!text) return;

            const rect = (el as HTMLElement).getBoundingClientRect();
            const centerX = (rect.left - cRect.left + rect.width / 2) * scale;
            const centerY = (rect.top - cRect.top + rect.height / 2) * scale;

            // Outside label chip — panel font, like the other chart labels.
            ctx.font = `700 ${11 * scale}px ${panelFontCss}`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const tw = ctx.measureText(text).width;
            const chipW = tw + 14 * scale, chipH = 18 * scale;

            ctx.shadowColor = 'rgba(0, 0, 0, 0.14)';
            ctx.shadowBlur = 6 * scale;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 2 * scale;
            ctx.fillStyle = 'rgba(255,255,255,0.94)';
            ctx.beginPath();
            (ctx as unknown as { roundRect: (...a: number[]) => void }).roundRect(centerX - chipW / 2, centerY - chipH / 2, chipW, chipH, 9 * scale);
            ctx.fill();
            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;
            ctx.shadowOffsetY = 0;
            ctx.strokeStyle = 'rgba(0,0,0,0.10)';
            ctx.lineWidth = Math.max(1, 1 * scale);
            ctx.stroke();

            ctx.fillStyle = '#1c2620';
            ctx.fillText(text, centerX, centerY + 0.5 * scale);
            ctx.textAlign = 'left';
          });

          canvas4x.toBlob((b) => (b ? resolve(b) : reject(new Error('PNG export failed'))), 'image/png');
        } catch (err) {
          reject(err as Error);
        }
      });
    }

    function exportSVG(title: string): Promise<string> {
      return new Promise((resolve) => {
        const width = container.clientWidth || 600;
        const height = container.clientHeight || 360;

        sankeyGroup.updateMatrixWorld(true);

        function projectPoint(x: number, y: number, z: number) {
          const [px, py] = projectXY(x, y, z);
          return `${px.toFixed(2)},${py.toFixed(2)}`;
        }

        function projectXY(x: number, y: number, z: number): [number, number] {
          const p = new THREE.Vector3(x, y, z);
          p.applyMatrix4(sankeyGroup.matrixWorld);
          p.project(camera);
          return [((p.x * 0.5 + 0.5) * width), ((-(p.y * 0.5) + 0.5) * height)];
        }

        function projectWorldPoint(x: number, y: number, z: number) {
          const p = new THREE.Vector3(x, y, z);
          p.project(camera);
          const px = ((p.x * 0.5 + 0.5) * width).toFixed(2);
          const py = (-(p.y * 0.5) + 0.5) * height;
          return `${px},${py.toFixed(2)}`;
        }

        // Transparent export: no background panel — only a soft projected
        // ground shadow so the chart keeps its depth cue on any surface.
        let platformSvg = '';
        if (platform.visible && platformMat.opacity > 0.02) {
          const shPts: string[] = [];
          const shY = -4.55;
          for (let a = 0; a < 24; a++) {
            const th = (a / 24) * Math.PI * 2;
            shPts.push(projectWorldPoint(1 + Math.cos(th) * 13.5, shY, -1 + Math.sin(th) * 5.6));
          }
          platformSvg += `    <!-- Vector ground shadow (no platform panel) -->\n    <polygon points="${shPts.join(' ')}" fill="#000000" fill-opacity="${(platformMat.opacity * 0.55).toFixed(3)}" filter="url(#sksoft)"/>\n`;
        }

        function getBezier(t: number, p0: number, p1: number, p2: number, p3: number) {
          const mt = 1 - t;
          return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3;
        }

        // True-vector flow pass: each ribbon is rebuilt from the SAME width
        // profile the WebGL geometry uses (64-segment sampling), then
        // wrapped in:
        //  - soft drop shadow (SVG filter, like the scene's PCF shadow),
        //  - vertical glass gradient (bright crown → mid → deep base),
        //  - top-edge specular highlight + bottom inner shade,
        //  - back/top depth strips in 3D (same hue family as the live mesh).
        // No <image> layers anywhere — pure paths + gradients.
        let flowDefs = '';
        let flowPathsSvg = '';
        const segments = 48;
        let flowSeq = 0;

        activeGraphData.flows.forEach((flow) => {
          const midX = flow.startX + (flow.endX - flow.startX) * 0.5;
          const z = (flow.zDepth || 1.0) / 2;
          const topFrontPts: string[] = [];
          const botFrontPts: string[] = [];
          const topBackPts: string[] = [];
          const botBackPts: string[] = [];
          const topXPts: number[] = [];
          const topYPts: number[] = [];
          const botYPts: number[] = [];

          const zc = flow.zCenter || 0;
          for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            const x = getBezier(t, flow.startX, midX, midX, flow.endX);
            const tY = getBezier(t, flow.topY1, flow.topY1, flow.topY2, flow.topY2);
            const bY = getBezier(t, flow.botY1, flow.botY1, flow.botY2, flow.botY2);

            topFrontPts.push(projectPoint(x, tY, z + zc));
            botFrontPts.push(projectPoint(x, bY, z + zc));
            topBackPts.push(projectPoint(x, tY, -z + zc));
            botBackPts.push(projectPoint(x, bY, -z + zc));
            const [tXp, tYp] = projectXY(x, tY, z + zc);
            const [, bYp] = projectXY(x, bY, z + zc);
            topXPts.push(tXp); topYPts.push(tYp); botYPts.push(bYp);
          }

          const fid = `skflow${flowSeq++}`;
          const crown = adjustColor(flow.color, 42);
          const mid = adjustColor(flow.color, 8);
          const deep = adjustColor(flow.color, -30);
          const yTop = Math.min(...topYPts), yBot = Math.max(...botYPts);
          flowDefs += `        <linearGradient id="${fid}" gradientUnits="userSpaceOnUse" x1="0" y1="${yTop.toFixed(1)}" x2="0" y2="${Math.max(yTop + 1, yBot).toFixed(1)}">\n` +
            `            <stop offset="0" stop-color="${crown}"/>\n` +
            `            <stop offset="0.35" stop-color="${mid}"/>\n` +
            `            <stop offset="1" stop-color="${deep}"/>\n` +
            `        </linearGradient>\n`;

          const lightColor = adjustColor(flow.color, 18);
          const darkColor = adjustColor(flow.color, -25);

          if (viewMix < 0.95) {
            const topStripPath = `M ${topFrontPts.join(' L ')} L ${topBackPts.slice().reverse().join(' L ')} Z`;
            flowPathsSvg += `        <path d="${topStripPath}" fill="${lightColor}" fill-opacity="0.75"/>\n`;

            const backStripPath = `M ${topBackPts.join(' L ')} L ${botBackPts.slice().reverse().join(' L ')} Z`;
            flowPathsSvg += `        <path d="${backStripPath}" fill="${darkColor}" fill-opacity="0.6"/>\n`;
          }

          const frontPath = `M ${topFrontPts.join(' L ')} L ${botFrontPts.slice().reverse().join(' L ')} Z`;
          flowPathsSvg += `        <path d="${frontPath}" fill="url(#${fid})" fill-opacity="0.96" filter="url(#sksoft)" stroke="${deep}" stroke-width="0.6" stroke-opacity="0.55"/>\n`;
          // specular crown along the top edge + soft inner shade at the base
          const topEdge = `M ${topFrontPts.join(' L ')}`;
          const botEdge = `M ${botFrontPts.join(' L ')}`;
          flowPathsSvg += `        <path d="${topEdge}" fill="none" stroke="#ffffff" stroke-width="1.6" stroke-opacity="0.65" stroke-linecap="round"/>\n`;
          flowPathsSvg += `        <path d="${botEdge}" fill="none" stroke="${deep}" stroke-width="1.2" stroke-opacity="0.5" stroke-linecap="round"/>\n`;
        });

        let nodesSvg = '';
        let nodeSeq = 0;
        activeGraphData.nodes.forEach((node) => {
          const w = 0.6;
          const h = (node.height || 1.5) / 2;
          const z = 0.5;

          const flt = projectPoint(node.x - w, node.centerY + h, z);
          const frt = projectPoint(node.x + w, node.centerY + h, z);
          const frb = projectPoint(node.x + w, node.centerY - h, z);
          const flb = projectPoint(node.x - w, node.centerY - h, z);

          const blt = projectPoint(node.x - w, node.centerY + h, -z);
          const brt = projectPoint(node.x + w, node.centerY + h, -z);
          const brb = projectPoint(node.x + w, node.centerY - h, -z);

          // Node glass: horizontal sheen (lit left edge → saturated core →
          // deep right edge) + vertical depth ramp via two stacked fills.
          const nid = `sknode${nodeSeq++}`;
          const [, yT] = projectXY(node.x, node.centerY + h, z);
          const [, yB] = projectXY(node.x, node.centerY - h, z);
          const [xL] = projectXY(node.x - w, node.centerY, z);
          const [xR] = projectXY(node.x + w, node.centerY, z);
          const nCrown = adjustColor(node.color, 46);
          const nDeep = adjustColor(node.color, -32);
          flowDefs += `        <linearGradient id="${nid}" gradientUnits="userSpaceOnUse" x1="${Math.min(xL, xR).toFixed(1)}" y1="0" x2="${Math.max(xL, xR).toFixed(1)}" y2="0">\n` +
            `            <stop offset="0" stop-color="${nCrown}"/>\n` +
            `            <stop offset="0.42" stop-color="${node.color}"/>\n` +
            `            <stop offset="1" stop-color="${nDeep}"/>\n` +
            `        </linearGradient>\n`;
          void yT; void yB;

          const lightColor = adjustColor(node.color, 20);
          const darkColor = adjustColor(node.color, -20);

          if (viewMix < 0.95) {
            nodesSvg += `        <polygon points="${flt} ${frt} ${brt} ${blt}" fill="${lightColor}"/>\n`;
            nodesSvg += `        <polygon points="${frt} ${frb} ${brb} ${brt}" fill="${darkColor}"/>\n`;
          }
          nodesSvg += `        <polygon points="${flt} ${frt} ${frb} ${flb}" fill="url(#${nid})" filter="url(#sksoft)" stroke="${nDeep}" stroke-width="0.6" stroke-opacity="0.55"/>\n`;
          // vertical sheen band on the face + bright left lip
          const [sLx] = projectXY(node.x - w * 0.55, node.centerY, z);
          const [sRx] = projectXY(node.x - w * 0.05, node.centerY, z);
          const sheenX0 = Math.min(sLx, sRx).toFixed(1);
          const sheenW = Math.abs(sRx - sLx).toFixed(1);
          nodesSvg += `        <polygon points="${projectPoint(node.x - w * 0.55, node.centerY + h * 0.92, z)} ${projectPoint(node.x - w * 0.05, node.centerY + h * 0.92, z)} ${projectPoint(node.x - w * 0.05, node.centerY - h * 0.92, z)} ${projectPoint(node.x - w * 0.55, node.centerY - h * 0.92, z)}" fill="#ffffff" fill-opacity="0.28"/>\n`;
          void sheenX0; void sheenW;
        });

        let labelsSvg = '';
        const cRect = container.getBoundingClientRect();
        const nodeLabelEls = container.querySelectorAll('.sk3d-out-label');
        const scratch = document.createElement('canvas').getContext('2d')!;
        nodeLabelEls.forEach((el) => {
          const text = el.textContent;
          if (!text) return;

          const rect = (el as HTMLElement).getBoundingClientRect();
          const centerX = rect.left - cRect.left + rect.width / 2;
          const centerY = rect.top - cRect.top + rect.height / 2;

          // Panel-style chip (matches the live .sk3d-out-label DOM chip).
          scratch.font = `700 11px ${panelFontCss}`;
          const tw = scratch.measureText(text).width;
          const chipW = tw + 16, chipH = 19;
          labelsSvg += `        <rect x="${(centerX - chipW / 2).toFixed(1)}" y="${(centerY - chipH / 2).toFixed(1)}" width="${chipW.toFixed(1)}" height="${chipH}" rx="9.5" fill="rgba(255,255,255,0.94)" stroke="rgba(0,0,0,0.10)"/>\n`;
          labelsSvg += `        <text x="${centerX.toFixed(1)}" y="${(centerY + 0.5).toFixed(1)}" class="node-text">${escXml(text)}</text>\n`;
        });

        let startX = 40;
        const legendY = height - 35;
        let legendSvg = '';

        activeGraphData.legend.forEach((item) => {
          const dotW = 14;
          const dotH = 10;
          const dotY = legendY - 5;
          legendSvg += `        <rect x="${startX}" y="${dotY}" width="${dotW}" height="${dotH}" rx="4" fill="${item.color}" />\n`;
          const textX = startX + dotW + 8;
          legendSvg += `        <text x="${textX}" y="${legendY}" class="legend-text">${escXml(item.name)}</text>\n`;

          const approxWidth = item.name.length * 9;
          startX = textX + approxWidth + 20;
        });

        const svgContent = `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
    <defs>
        <style type="text/css">
            text { font-family: ${escXml(panelFontCss)}; }
            .title-text { font-family: ${escXml(panelDisplayCss)}; font-size: 24px; font-weight: 700; fill: #2a2a2a; }
            .legend-text { font-size: 15px; font-weight: 700; fill: #333333; dominant-baseline: middle; }
            .node-text {
                font-size: 11px;
                font-weight: 700;
                fill: ${escXml(panelInk)};
                text-anchor: middle;
                dominant-baseline: central;
            }
        </style>
        <filter id="sksoft" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#000000" flood-opacity="0.18"/>
        </filter>
${flowDefs}    </defs>

    <!-- Transparent background: chart floats directly in the tile -->

${platformSvg}
    <!-- Vector Flow Ribbons -->
    <g id="sankey-vector-flows">
${flowPathsSvg}    </g>

    <!-- Vector Nodes (Rendered over ribbons for clean endpoints) -->
    <g id="sankey-vector-nodes">
${nodesSvg}    </g>

    <!-- Vector Header Title -->
    <text x="40" y="45" class="title-text">${escXml(title || activeGraphData.title)}</text>

    <!-- Vector Legend -->
    <g id="sankey-vector-legend">
${legendSvg}    </g>

    <!-- Vector Node Labels -->
    <g id="sankey-vector-labels">
${labelsSvg}    </g>
</svg>`;

        resolve(svgContent);
      });
    }

    /* --- 9. RENDER LOOP (continuous while on-screen) ---
       The old render-on-demand parking blanked the canvas whenever the
       drawing buffer was cleared without a "busy" event — setSize on
       fullscreen enter/exit, the export resolution swap, buffers discarded
       after scrolling away, WebGL context restores — so the chart
       "disappeared" until the next hover or click. Rendering every frame
       while the container is visible makes a blank frame impossible;
       off-screen (or hidden-tab) frames are skipped so the GPU still idles. */
    let raf = 0;
    let onScreen = true;
    function wake() { /* continuous loop repaints regardless — kept for existing call sites */ }
    const io = new IntersectionObserver((es) => {
      onScreen = es.some((e) => e.isIntersecting);
      if (onScreen) onResize();
    }, { threshold: 0 });
    const onVisChange = () => { if (!document.hidden) onResize(); };
    document.addEventListener('visibilitychange', onVisChange);
    const onFsChange = () => { onResize(); requestAnimationFrame(onResize); };
    document.addEventListener('fullscreenchange', onFsChange);
    const onCtxLost = (e: Event) => { e.preventDefault(); };
    const onCtxRestored = () => onResize();
    renderer.domElement.addEventListener('webglcontextlost', onCtxLost, false);
    renderer.domElement.addEventListener('webglcontextrestored', onCtxRestored, false);
    controls.addEventListener('change', wake);
    function animate() {
      raf = requestAnimationFrame(animate);
      if (!onScreen || document.hidden) return;

      viewMix += (targetViewMix - viewMix) * 0.055;
      if (Math.abs(targetViewMix - viewMix) < 0.0005) {
        viewMix = targetViewMix;
      }
      const e = easeInOutCubic(viewMix);

      sankeyGroup.scale.z = THREE.MathUtils.lerp(1, 0.035, e);

      if (isTransitioning) {
        camera.position.lerpVectors(CAM_3D.pos, CAM_2D.pos, e);
        controls.target.lerpVectors(CAM_3D.target, CAM_2D.target, e);
        camera.fov = THREE.MathUtils.lerp(CAM_3D.fov, CAM_2D.fov, e);
        camera.updateProjectionMatrix();

        if (Math.abs(targetViewMix - viewMix) < 0.001) {
          isTransitioning = false;
        }
      }

      ambientLight.intensity = THREE.MathUtils.lerp(LIGHT_3D.ambient, LIGHT_2D.ambient, e);
      dirLight.intensity = THREE.MathUtils.lerp(LIGHT_3D.dir, LIGHT_2D.dir, e);
      rimLight.intensity = THREE.MathUtils.lerp(LIGHT_3D.rim, LIGHT_2D.rim, e);
      platformMat.opacity = THREE.MathUtils.lerp(0.16, 0.0, e);
      platform.visible = platformMat.opacity > 0.01;
      dirLight.castShadow = e < 0.85;

      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }

    const onResize = () => {
      const W = container.clientWidth || 600;
      const H = container.clientHeight || 360;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
      fitPresets();
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(container);
    io.observe(container);

    animate();

    const dispose = () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      document.removeEventListener('visibilitychange', onVisChange);
      document.removeEventListener('fullscreenchange', onFsChange);
      renderer.domElement.removeEventListener('webglcontextlost', onCtxLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onCtxRestored);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      container.removeEventListener('wheel', onWheel);
      controls.dispose();
      controls.removeEventListener('change', wake);
      matCache.forEach((mm) => mm.dispose());
      matCache.clear();
      clearSankeyGroup();
      platformGeo.dispose();
      platformMat.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement === container) container.removeChild(renderer.domElement);
      if (labelRenderer.domElement.parentElement === container) container.removeChild(labelRenderer.domElement);
      if (legendEl) legendEl.innerHTML = '';
    };

    S.current = {
      setDim: (d: '2d' | '3d') => setView(d),
      setZoom: (on: boolean) => { zoomOnRef = on; controls.enableZoom = on; },
      hoverByLegendIdx,
      exportPNG: (title: string) => exportPNG(title, 4),
      exportSVG: (title: string) => exportSVG(title),
      dispose,
    };
    return () => { S.current?.dispose(); S.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [links]);

  useEffect(() => { S.current?.setDim(dim); }, [dim]);

  useEffect(() => { S.current?.hoverByLegendIdx(hoverIndex ?? null); }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: (title: string) => {
      if (!S.current) return Promise.reject(new Error('chart not ready'));
      return S.current.exportPNG(title);
    },
    exportSVG: (title: string) => {
      if (!S.current) return Promise.reject(new Error('chart not ready'));
      return S.current.exportSVG(title);
    },
    setZoom: (on: boolean) => { setZoomOn(on); S.current?.setZoom(on); },
  }), []);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full overflow-hidden" style={{ cursor: 'default', background: 'transparent', borderRadius: 'inherit' }}>
      {/* in-scene color legend removed: node identity now lives ONLY in the
          outside pill labels (plus the card legend below the chart) */}
      {tip && (
        <div
          className="sankey3d-tip font-body"
          style={{
            left: Math.min(Math.max(tip.x, 104), (containerRef.current?.clientWidth || 600) - 104),
            top: Math.max(tip.y, 46),
          }}
        >
          <span className="tip-dot" style={{ background: tip.color }} />
          <span>{tip.title}</span>
          <span className="tip-sub">{tip.value}</span>
        </div>
      )}
      {dim === '3d' && !tip && (
        <div className="pointer-events-none absolute bottom-1.5 right-2 z-10 rounded-full bg-black/55 px-2.5 py-0.5 font-body text-[10px] font-semibold text-white/90 backdrop-blur-sm">
          Drag to orbit{zoomOn ? ' · scroll to zoom' : ''}
        </div>
      )}
      <button
        onClick={(e) => { e.stopPropagation(); const next = !zoomOn; setZoomOn(next); S.current?.setZoom(next); }}
        data-tip={zoomOn ? 'Scroll-zoom: on' : 'Scroll-zoom: off'}
        className={`absolute left-2 top-2 z-10 rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${zoomOn ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
        title={zoomOn ? 'Turn scroll-zoom off' : 'Turn scroll-zoom on'}
      >
        {zoomOn ? '🔍+ on' : '🔍+ off'}
      </button>
    </div>
  );
});

export default ThreeSankey3D;
