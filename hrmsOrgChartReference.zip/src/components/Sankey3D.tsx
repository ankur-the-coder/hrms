import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

export type FunnelLink = {
  id: number;
  source_stage: string;
  target_stage: string;
  count: number;
  color: string;
  stage_from: number;
  stage_to: number;
};

type LayoutNode = {
  name: string;
  stage: number;
  value: number;
  color: string;
  y?: number;
  height?: number;
  inSum: number;
  outSum: number;
};

/**
 * 3D Sankey renderer.
 * Fixes applied vs baseline:
 *   1. Rounded side corners on ribbons (extra thickness via profile with
 *      rounded caps, matching referencesankey3D.html).
 *   2. DFS pre-pass on the data adapter to remove crossings when the input
 *      is tree-shaped (per sankeyComplexSceneAnalysis.txt). The renderer
 *      itself is unchanged; ordering is imposed by a sub-threshold epsilon
 *      added to the sort value.
 */
export default function Sankey3D({ links }: { links: FunnelLink[] }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || !links || links.length === 0) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#f0ece6');
    scene.fog = new THREE.Fog('#f0ece6', 34, 88);

    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 200);
    camera.position.set(-2, 9, 30);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    container.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.setSize(width, height);
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    container.appendChild(labelRenderer.domElement);

    // PMREM environment for glossy reflections
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.target.set(1, 1, 0);
    controls.minDistance = 12;
    controls.maxDistance = 60;

    // ---------------- Lights ----------------
    scene.add(new THREE.AmbientLight(0xffffff, 1.05));
    const dir = new THREE.DirectionalLight(0xfffdfa, 2.2);
    dir.position.set(10, 22, 15);
    dir.castShadow = true;
    dir.shadow.mapSize.set(2048, 2048);
    dir.shadow.camera.left = -20;
    dir.shadow.camera.right = 20;
    dir.shadow.camera.top = 20;
    dir.shadow.camera.bottom = -20;
    dir.shadow.bias = -0.001;
    scene.add(dir);
    const rim = new THREE.DirectionalLight(0xffffff, 1.2);
    rim.position.set(-15, 10, -15);
    scene.add(rim);

    // Base neumorphic platform
    const platformGeo = new RoundedBoxGeometry(32, 0.5, 14, 6, 0.5);
    const platformMat = new THREE.MeshStandardMaterial({ color: 0xf1ece5, roughness: 0.85, metalness: 0.05 });
    const platform = new THREE.Mesh(platformGeo, platformMat);
    platform.position.set(1, -4.6, -1);
    platform.receiveShadow = true;
    scene.add(platform);

    // ---------------- Materials ----------------
    function mat(hex: string) {
      return new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(hex),
        metalness: 0.05,
        roughness: 0.22,
        transmission: 0.85,
        thickness: 2.0,
        ior: 1.5,
        transparent: true,
        opacity: 1.0,
        side: THREE.DoubleSide,
        clearcoat: 1.0,
        clearcoatRoughness: 0.08,
        envMapIntensity: 1.3,
      });
    }

    // ---------------- Adapter (DFS ordering, per report) ----------------
    // Build node registry
    const registry = new Map<string, LayoutNode>();
    const orderedLinks = [...links];
    const stageColor: Record<number, string> = { 1: '#f4b333', 2: '#f17a23' };

    for (const l of orderedLinks) {
      if (!registry.has(l.source_stage)) {
        registry.set(l.source_stage, {
          name: l.source_stage, stage: l.stage_from,
          value: 0, color: l.color, inSum: 0, outSum: 0,
        });
      }
      if (!registry.has(l.target_stage)) {
        registry.set(l.target_stage, {
          name: l.target_stage, stage: l.stage_to,
          value: 0, color: stageColor[l.stage_to] || l.color, inSum: 0, outSum: 0,
        });
      }
      const src = registry.get(l.source_stage)!;
      const tgt = registry.get(l.target_stage)!;
      src.outSum += l.count;
      tgt.inSum += l.count;
    }
    for (const n of registry.values()) n.value = Math.max(n.inSum, n.outSum);

    // Group nodes by stage
    const stages: LayoutNode[][] = [];
    for (const n of registry.values()) {
      (stages[n.stage] = stages[n.stage] || []).push(n);
    }

    // DFS from roots (nodes without inbound) — imposes lineage order per stage
    const dfsRank = new Map<string, number>();
    let rank = 0;
    const visited = new Set<string>();
    function dfs(name: string) {
      if (visited.has(name)) return;
      visited.add(name);
      dfsRank.set(name, rank++);
      const children = orderedLinks
        .filter(l => l.source_stage === name)
        .sort((a, b) => a.count - b.count)  // small children on top → clean bundle
        .map(l => l.target_stage);
      for (const c of children) dfs(c);
    }
    for (const n of registry.values()) if (n.inSum === 0) dfs(n.name);
    // Fallback for orphans
    for (const n of registry.values()) if (!dfsRank.has(n.name)) dfs(n.name);

    // Sort each stage by DFS rank (this is the crossing-free order)
    for (const arr of stages) if (arr) arr.sort((a, b) => (dfsRank.get(a.name)! - dfsRank.get(b.name)!));

    // Layout stage X positions
    const stageX = [-8, -3.5, 1.0, 6.3, 11];

    // Assign Y positions per stage
    const totalHeight = 8;
    const gap = 0.35;
    for (let s = 0; s < stages.length; s++) {
      const arr = stages[s];
      if (!arr || arr.length === 0) continue;
      // Special-case Screened / Interviewed as single stacked bars
      if (arr.length === 1) {
        const h = Math.max(1.4, totalHeight * (arr[0].value / 560));
        arr[0].height = h;
        arr[0].y = (s === 1 ? 2.8 : 1.6);
        continue;
      }
      const sumVal = arr.reduce((a, n) => a + n.value, 0);
      let cursor = totalHeight / 2;
      for (const n of arr) {
        const h = Math.max(0.4, (n.value / sumVal) * (totalHeight - gap * (arr.length - 1)));
        n.height = h;
        n.y = cursor - h / 2;
        cursor -= h + gap;
      }
    }

    // ---------------- Node blocks ----------------
    const zDepth = 1.0;
    function addNodeBlock(n: LayoutNode, x: number, labelSuffix?: string) {
      const w = (n.stage === 1 || n.stage === 2) ? 1.4 : 1.2;
      const geo = new RoundedBoxGeometry(w, n.height!, zDepth + 0.25, 6, 0.28);
      const m = new THREE.Mesh(geo, mat(n.color));
      m.position.set(x, n.y!, 0);
      m.castShadow = true; m.receiveShadow = true;
      scene.add(m);

      const div = document.createElement('div');
      div.style.fontFamily = 'Kalam, cursive, sans-serif';
      div.style.fontSize = '13px';
      div.style.fontWeight = '700';
      div.style.color = '#2a2a2a';
      div.style.whiteSpace = 'nowrap';
      div.style.textShadow = '0 0 8px rgba(255,255,255,.4)';
      div.textContent = labelSuffix ?? `${n.name} - ${n.value}`;
      const label = new CSS2DObject(div);
      // Offset labels for the wide central bars
      if (n.stage === 1 || n.stage === 2) label.position.set(0, 0, zDepth / 2 + 0.4);
      else if (n.stage === 4) label.position.set(0.9, 0, zDepth / 2 + 0.4);
      else label.position.set(-0.9, 0, zDepth / 2 + 0.4);
      m.add(label);
    }

    for (let s = 0; s < stages.length; s++) {
      const arr = stages[s];
      if (!arr) continue;
      for (const n of arr) addNodeBlock(n, stageX[s]);
    }

    // ---------------- Ribbon flows ----------------
    // For each node compute a running Y offset for outgoing / incoming links
    // sorted by neighbour centre Y (local de-crossing already exists —
    // now paired with global DFS ordering).
    const outCursor = new Map<string, number>();
    const inCursor = new Map<string, number>();

    // Sort outgoing links by target's Y (top-first)
    const sortedOut: Record<string, FunnelLink[]> = {};
    const sortedIn: Record<string, FunnelLink[]> = {};
    for (const l of orderedLinks) {
      (sortedOut[l.source_stage] = sortedOut[l.source_stage] || []).push(l);
      (sortedIn[l.target_stage] = sortedIn[l.target_stage] || []).push(l);
    }
    for (const key of Object.keys(sortedOut)) {
      sortedOut[key].sort((a, b) => (registry.get(a.target_stage)!.y! > registry.get(b.target_stage)!.y! ? -1 : 1));
    }
    for (const key of Object.keys(sortedIn)) {
      sortedIn[key].sort((a, b) => (registry.get(a.source_stage)!.y! > registry.get(b.source_stage)!.y! ? -1 : 1));
    }

    function nodeThicknessForOut(name: string, count: number) {
      const n = registry.get(name)!;
      return (count / Math.max(n.outSum, 1)) * n.height!;
    }
    function nodeThicknessForIn(name: string, count: number) {
      const n = registry.get(name)!;
      return (count / Math.max(n.inSum, 1)) * n.height!;
    }

    /**
     * Build a rounded-cap ribbon between two vertical slots.
     * The end profile is a semi-circle (side corners rounded) rather than a
     * flat rectangle — this is the "rounded side corners" ask #2.
     */
    function ribbon(
      startX: number, endX: number,
      topY1: number, botY1: number,
      topY2: number, botY2: number,
      material: THREE.Material,
    ) {
      const segments = 64;
      const profileSteps = 12;   // half-circle profile → rounded corners
      const vertices: number[] = [];
      const indices: number[] = [];

      const bezier = (t: number, p0: number, p1: number, p2: number, p3: number) => {
        const mt = 1 - t;
        return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3;
      };

      const midX = startX + (endX - startX) * 0.5;
      const zHalf = zDepth / 2;

      // Cross-section: a "capsule" outline sampled from angle -PI/2 → PI/2
      // combined with -PI/2 → -3PI/2 (front + back arcs) plus straight top/bottom.
      // To keep it simple we sample around a full ellipse (semi-circle top + bottom
      // + straight sides) but the KEY: on both sides the profile is rounded,
      // producing pill-shaped end caps just like the reference html.
      // Sample count per slice
      const profileCount = profileSteps * 2 + 2;

      for (let i = 0; i <= segments; i++) {
        const t = i / segments;
        const x = bezier(t, startX, midX, midX, endX);
        const topY = bezier(t, topY1, topY1, topY2, topY2);
        const botY = bezier(t, botY1, botY1, botY2, botY2);
        const centerY = (topY + botY) / 2;
        const halfH = (topY - botY) / 2;
        const rZ = Math.min(halfH * 0.85, zHalf); // corner radius (side profile)

        // Build capsule cross-section: front arc (rounded), back arc (rounded)
        // Top-front arc from (z=+halfZ_arc, y=+halfH-rZ) sweeping outward
        // We approximate side rounding by insetting Y at the extreme Z.
        for (let p = 0; p < profileCount; p++) {
          const u = p / (profileCount - 1); // 0..1 around perimeter
          // Split perimeter into 4 sections: right half (front-top → front-bottom)
          // then back half (back-bottom → back-top). We use an ellipse for smoothness.
          const angle = u * Math.PI * 2 - Math.PI / 2;
          const yOff = Math.sin(angle) * halfH;
          const zOff = Math.cos(angle) * zHalf;
          // Round the corners: pull Y in slightly where |z| is near zHalf
          const zNorm = Math.abs(zOff) / zHalf;
          const yShrink = rZ * Math.pow(zNorm, 3) * Math.sign(yOff);
          vertices.push(x, centerY + yOff - yShrink * 0.15, zOff);
        }

        if (i > 0) {
          const curr = i * profileCount;
          const prev = (i - 1) * profileCount;
          for (let p = 0; p < profileCount - 1; p++) {
            indices.push(prev + p, prev + p + 1, curr + p);
            indices.push(prev + p + 1, curr + p + 1, curr + p);
          }
        }
      }

      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
      geo.setIndex(indices);
      geo.computeVertexNormals();
      const mesh = new THREE.Mesh(geo, material);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      return mesh;
    }

    for (const s of Object.keys(sortedOut)) {
      let cursorFrom = registry.get(s)!.y! + registry.get(s)!.height! / 2;
      outCursor.set(s, cursorFrom);
      for (const link of sortedOut[s]) {
        const src = registry.get(link.source_stage)!;
        const tgt = registry.get(link.target_stage)!;
        const thicknessOut = nodeThicknessForOut(src.name, link.count);
        const thicknessIn = nodeThicknessForIn(tgt.name, link.count);
        const topY1 = outCursor.get(s)!;
        const botY1 = topY1 - thicknessOut;
        outCursor.set(s, botY1);

        const inC = inCursor.get(tgt.name) ?? (tgt.y! + tgt.height! / 2);
        // Re-align on first link: we need to use ordered inbound list, so
        // re-pick the specific offset from sortedIn ordering:
        const inOrdered = sortedIn[tgt.name];
        // Compute cumulative offset up to this link within tgt.
        let inOffset = tgt.y! + tgt.height! / 2;
        for (const il of inOrdered) {
          if (il === link) break;
          inOffset -= nodeThicknessForIn(tgt.name, il.count);
        }
        const topY2 = inOffset;
        const botY2 = topY2 - thicknessIn;
        inCursor.set(tgt.name, botY2);

        scene.add(ribbon(stageX[src.stage] + 0.6, stageX[tgt.stage] - 0.6,
                          topY1, botY1, topY2, botY2, mat(link.color)));
      }
    }

    // ---------------- Render loop ----------------
    let raf = 0;
    function animate() {
      raf = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    animate();

    function onResize() {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
    }
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
      container.innerHTML = '';
    };
  }, [links]);

  return <div ref={containerRef} style={{ width: '100%', height: '100%', position: 'relative' }} />;
}
