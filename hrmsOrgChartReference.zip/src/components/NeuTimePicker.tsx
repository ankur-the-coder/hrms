import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

/**
 * Neumorphic time picker with glossy knobs on:
 *   - the clock hand tip (draggable)
 *   - the two H and M sliders (draggable)
 * Rendered via a shared transparent WebGL overlay (same technique as the
 * date picker) so the knobs pick up real reflections + a follow-pointer
 * highlight.
 */
export default function NeuTimePicker() {
  const [hour, setHour] = useState(9);
  const [minute, setMinute] = useState(30);
  const [mode, setMode] = useState<'hour' | 'minute'>('hour');
  const [ampm, setAmpm] = useState<'AM' | 'PM'>('AM');

  const cardRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const clockRef = useRef<HTMLDivElement>(null);

  // --- Shared gloss layer ---
  useEffect(() => {
    const cardEl = cardRef.current;
    const canvas = canvasRef.current;
    if (!cardEl || !canvas) return;
    const card: HTMLDivElement = cardEl;

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

    const camera = new THREE.OrthographicCamera(0, 1, 0, -1, 1, 2000);
    camera.position.z = 600;

    const key = new THREE.DirectionalLight(0xfff4ea, 2.0);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0005;
    scene.add(key, key.target);

    const shine = new THREE.DirectionalLight(0xffffff, 1.1);
    scene.add(shine, shine.target);

    const catcher = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.ShadowMaterial({ color: 0x7a3a20, opacity: 0.30 }),
    );
    catcher.receiveShadow = true;
    scene.add(catcher);

    const knobMat = new THREE.MeshPhysicalMaterial({
      color: 0xff5535, roughness: 0.18, metalness: 0.0,
      clearcoat: 1.0, clearcoatRoughness: 0.04, envMapIntensity: 1.3,
    });
    const group = new THREE.Group();
    scene.add(group);

    let W = 0, H = 0;
    function resize() {
      const r = card.getBoundingClientRect();
      W = r.width; H = r.height;
      renderer.setSize(W, H, false);
      camera.right = W; camera.bottom = -H; camera.updateProjectionMatrix();
      catcher.scale.set(W, H, 1);
      catcher.position.set(W / 2, -H / 2, -14);
      const c = new THREE.Vector3(W / 2, -H / 2, 0);
      key.target.position.copy(c);
      key.position.set(c.x - 260, c.y + 260, 380);
      const s = key.shadow.camera; const m = Math.max(W, H);
      s.left = -m; s.right = m; s.top = m; s.bottom = -m; s.near = 1; s.far = 1500;
      s.updateProjectionMatrix();
      shine.target.position.copy(c);
      shine.position.set(c.x - 120, c.y + 160, 300);
    }

    function rebuild() {
      const c = card.getBoundingClientRect();
      if (c.width !== W || c.height !== H) resize();
      group.children.forEach((m) => (m as THREE.Mesh).geometry.dispose());
      group.clear();

      const knobs = card.querySelectorAll('[data-glossy-knob]');
      knobs.forEach((el) => {
        const r = (el as HTMLElement).getBoundingClientRect();
        const size = Math.min(r.width, r.height) / 2;
        if (size < 4) return;
        const mesh = new THREE.Mesh(new THREE.SphereGeometry(size, 48, 32), knobMat);
        mesh.scale.z = 0.6;
        mesh.position.set((r.left + r.right) / 2 - c.left, -((r.top + r.bottom) / 2 - c.top), 4);
        mesh.castShadow = mesh.receiveShadow = true;
        group.add(mesh);
      });
      draw();
    }

    let raf = 0;
    function draw() { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => renderer.render(scene, camera)); }
    let pending = 0;
    function schedule() { cancelAnimationFrame(pending); pending = requestAnimationFrame(rebuild); }

    const mo = new MutationObserver(schedule);
    mo.observe(card, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class', 'data-glossy-knob'] });
    const ro = new ResizeObserver(schedule);
    ro.observe(card);

    function onMove(e: PointerEvent) {
      const r = card.getBoundingClientRect();
      shine.position.set(e.clientX - r.left, -(e.clientY - r.top), 260);
      draw();
    }
    card.addEventListener('pointermove', onMove);

    resize();
    rebuild();

    return () => {
      card.removeEventListener('pointermove', onMove);
      mo.disconnect(); ro.disconnect();
      cancelAnimationFrame(raf);
      renderer.dispose();
    };
  }, []);

  // Rebuild gloss after every state change so knob positions refresh
  useEffect(() => {
    const card = cardRef.current;
    if (card) card.setAttribute('data-tick', String(Date.now()));
  }, [hour, minute, mode, ampm]);

  // --- Clock geometry ---
  const clockSize = 260;
  const clockCenter = clockSize / 2;
  const numRadius = clockCenter - 30;
  const handRadius = clockCenter - 44;

  const currentVal = mode === 'hour' ? hour : minute;
  const currentMax = mode === 'hour' ? 12 : 60;
  const angle = ((currentVal % currentMax) / currentMax) * Math.PI * 2 - Math.PI / 2;
  const knobX = clockCenter + Math.cos(angle) * handRadius;
  const knobY = clockCenter + Math.sin(angle) * handRadius;

  const clockNumbers = useMemo(() => {
    if (mode === 'hour') {
      return Array.from({ length: 12 }, (_, i) => {
        const v = i + 1;
        const a = (v / 12) * Math.PI * 2 - Math.PI / 2;
        return { v, x: clockCenter + Math.cos(a) * numRadius, y: clockCenter + Math.sin(a) * numRadius };
      });
    }
    return Array.from({ length: 12 }, (_, i) => {
      const v = i * 5;
      const a = (v / 60) * Math.PI * 2 - Math.PI / 2;
      return { v: v === 0 ? '00' : String(v), x: clockCenter + Math.cos(a) * numRadius, y: clockCenter + Math.sin(a) * numRadius };
    });
  }, [mode]);

  // --- Drag handler on the clock face ---
  function pointFromEvent(e: React.PointerEvent | PointerEvent): { x: number; y: number } | null {
    const el = clockRef.current;
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { x: e.clientX - r.left - clockCenter, y: e.clientY - r.top - clockCenter };
  }
  function setFromPoint(pt: { x: number; y: number }) {
    let ang = Math.atan2(pt.y, pt.x) + Math.PI / 2;
    if (ang < 0) ang += Math.PI * 2;
    const t = ang / (Math.PI * 2);
    if (mode === 'hour') {
      let v = Math.round(t * 12);
      if (v === 0) v = 12;
      setHour(v);
    } else {
      const v = Math.round(t * 60) % 60;
      setMinute(v);
    }
  }
  function onClockPointerDown(e: React.PointerEvent) {
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    const pt = pointFromEvent(e); if (pt) setFromPoint(pt);
    const onMove = (ev: PointerEvent) => { const p = pointFromEvent(ev); if (p) setFromPoint(p); };
    const onUp = (ev: PointerEvent) => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      try { (ev.target as HTMLElement).releasePointerCapture(ev.pointerId); } catch { /* ignore */ }
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  }

  // --- Slider handler ---
  function makeSliderHandler(max: number, setter: (n: number) => void) {
    return (e: React.PointerEvent<HTMLDivElement>) => {
      const track = e.currentTarget;
      const set = (ev: PointerEvent | React.PointerEvent) => {
        const r = track.getBoundingClientRect();
        const t = Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width));
        setter(Math.round(t * max));
      };
      set(e);
      const onMove = (ev: PointerEvent) => set(ev);
      const onUp = () => {
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
      };
      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
    };
  }

  const pad = (n: number) => String(n).padStart(2, '0');

  return (
    <div ref={cardRef} className="neu-card p-8 relative isolate" style={{ maxWidth: 380, position: 'relative' }}>
      <canvas
        ref={canvasRef}
        className="absolute pointer-events-none"
        style={{ inset: 0, width: '100%', height: '100%', zIndex: 1, borderRadius: 'inherit' }}
      />

      {/* Time display */}
      <div className="neu-pressed flex items-center justify-center gap-2 py-4 mb-5" style={{ position: 'relative', zIndex: 2 }}>
        <button
          className={`px-4 py-1 rounded-lg carved ${mode === 'hour' ? '' : 'opacity-50'}`}
          onClick={() => setMode('hour')}
          style={{ fontSize: '2.2rem', fontWeight: 500, background: 'none', border: 'none', cursor: 'pointer', color: mode === 'hour' ? 'var(--coral-accent)' : 'var(--text-main)' }}
        >
          {pad(hour)}
        </button>
        <span className="carved" style={{ fontSize: '2.2rem', fontWeight: 300 }}>:</span>
        <button
          className={`px-4 py-1 rounded-lg carved ${mode === 'minute' ? '' : 'opacity-50'}`}
          onClick={() => setMode('minute')}
          style={{ fontSize: '2.2rem', fontWeight: 500, background: 'none', border: 'none', cursor: 'pointer', color: mode === 'minute' ? 'var(--coral-accent)' : 'var(--text-main)' }}
        >
          {pad(minute)}
        </button>
        <div className="ml-3 flex flex-col gap-1">
          <button
            className={`range-pill ${ampm === 'AM' ? 'active' : ''}`}
            style={{ padding: '4px 10px', fontSize: '.75rem' }}
            onClick={() => setAmpm('AM')}
          >AM</button>
          <button
            className={`range-pill ${ampm === 'PM' ? 'active' : ''}`}
            style={{ padding: '4px 10px', fontSize: '.75rem' }}
            onClick={() => setAmpm('PM')}
          >PM</button>
        </div>
      </div>

      {/* Clock face */}
      <div className="flex justify-center mb-5" style={{ position: 'relative', zIndex: 2 }}>
        <div
          ref={clockRef}
          className="neu-pressed"
          style={{
            width: clockSize,
            height: clockSize,
            borderRadius: '50%',
            position: 'relative',
            touchAction: 'none',
            cursor: 'pointer',
          }}
          onPointerDown={onClockPointerDown}
        >
          {/* Numbers */}
          {clockNumbers.map((n) => (
            <div
              key={n.v}
              className="carved absolute select-none"
              style={{
                left: n.x, top: n.y,
                transform: 'translate(-50%, -50%)',
                fontSize: '.9rem',
                fontWeight: 500,
                opacity: 0.7,
                pointerEvents: 'none',
              }}
            >
              {n.v}
            </div>
          ))}
          {/* Hand */}
          <div
            aria-hidden
            style={{
              position: 'absolute',
              left: clockCenter,
              top: clockCenter,
              width: handRadius,
              height: 2,
              background: 'var(--coral-accent)',
              borderRadius: 2,
              transformOrigin: '0 50%',
              transform: `rotate(${angle}rad)`,
              opacity: .55,
              boxShadow: '0 0 6px rgba(255,104,73,.4)',
              pointerEvents: 'none',
            }}
          />
          {/* Center pin */}
          <div
            data-glossy-knob
            className="knob-fallback"
            style={{
              position: 'absolute',
              left: clockCenter, top: clockCenter,
              width: 12, height: 12, borderRadius: '50%',
              transform: 'translate(-50%, -50%)',
              pointerEvents: 'none',
            }}
          />
          {/* Glossy tip knob */}
          <div
            data-glossy-knob
            className="knob-fallback"
            style={{
              position: 'absolute',
              left: knobX, top: knobY,
              width: 30, height: 30, borderRadius: '50%',
              transform: 'translate(-50%, -50%)',
              pointerEvents: 'none',
            }}
          />
        </div>
      </div>

      {/* Sliders */}
      <div className="space-y-4" style={{ position: 'relative', zIndex: 2 }}>
        <SliderRow
          label="Hour"
          value={hour}
          max={12}
          onDown={makeSliderHandler(12, (n) => setHour(n === 0 ? 12 : n))}
        />
        <SliderRow
          label="Min"
          value={minute}
          max={59}
          onDown={makeSliderHandler(59, setMinute)}
        />
      </div>
    </div>
  );
}

function SliderRow({
  label,
  value,
  max,
  onDown,
}: {
  label: string;
  value: number;
  max: number;
  onDown: (e: React.PointerEvent<HTMLDivElement>) => void;
}) {
  const t = max === 0 ? 0 : value / max;
  return (
    <div className="flex items-center gap-3">
      <div className="carved" style={{ fontSize: '.8rem', width: 34, opacity: 0.7 }}>{label}</div>
      <div
        className="neu-pressed relative flex-1"
        style={{ height: 14, borderRadius: 7, cursor: 'pointer', touchAction: 'none' }}
        onPointerDown={onDown}
      >
        {/* filled portion */}
        <div
          style={{
            position: 'absolute',
            left: 4, top: 4, bottom: 4,
            width: `calc(${t * 100}% - 8px)`,
            background: 'var(--coral-accent)',
            borderRadius: 4,
            opacity: 0.35,
          }}
        />
        {/* knob */}
        <div
          data-glossy-knob
          className="knob-fallback"
          style={{
            position: 'absolute',
            top: '50%',
            left: `calc(${t * 100}%)`,
            width: 22,
            height: 22,
            borderRadius: '50%',
            transform: 'translate(-50%, -50%)',
            pointerEvents: 'none',
          }}
        />
      </div>
      <div className="carved" style={{ fontSize: '.8rem', width: 26, textAlign: 'right', color: 'var(--coral-accent)', fontWeight: 500 }}>
        {String(value).padStart(2, '0')}
      </div>
    </div>
  );
}
