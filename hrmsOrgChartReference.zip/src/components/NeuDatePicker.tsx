import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ChevronLeft, ChevronRight } from 'lucide-react';

type Mode = 'single' | 'range';

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const WEEKDAYS = ['Su','Mo','Tu','We','Th','Fr','Sa'];

// Range selection presets — matches rangeSelectionArea.png
const RANGE_PRESETS = [
  { label: 'Today', days: 0 },
  { label: 'Yesterday', days: -1 },
  { label: 'Last 7 Days', days: -7 },
  { label: 'Last 30 Days', days: -30 },
  { label: 'This Month', months: 0 },
  { label: 'Last Month', months: -1 },
  { label: 'This Year', years: 0 },
  { label: 'Last Year', years: -1 },
] as const;

function sameDay(a: Date | null, b: Date | null) {
  if (!a || !b) return false;
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}
function fmt(d: Date | null) {
  if (!d) return null;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default function NeuDatePicker({ initialMode = 'range' }: { initialMode?: Mode }) {
  const [mode, setMode] = useState<Mode>(initialMode);
  const [cursor, setCursor] = useState<Date>(new Date());
  const [start, setStart] = useState<Date | null>(null);
  const [end, setEnd] = useState<Date | null>(null);
  const [single, setSingle] = useState<Date | null>(null);
  const [hover, setHover] = useState<Date | null>(null);
  const [activePreset, setActivePreset] = useState<string | null>(null);

  const cardRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // ----------- Gloss layer -----------
  useEffect(() => {
    const cardEl = cardRef.current;
    const canvas = canvasRef.current;
    if (!cardEl || !canvas) return;
    const card: HTMLDivElement = cardEl;

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

    const camera = new THREE.OrthographicCamera(0, 1, 0, -1, 1, 2000);
    camera.position.z = 600;

    const key = new THREE.DirectionalLight(0xfff4ea, 2.0);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0005;
    scene.add(key, key.target);

    const shine = new THREE.DirectionalLight(0xffffff, 1.1);
    scene.add(shine, shine.target);

    const catcher = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.ShadowMaterial({ color: 0x7a3a20, opacity: 0.30 }),
    );
    catcher.receiveShadow = true;
    scene.add(catcher);

    const badgeMat = new THREE.MeshPhysicalMaterial({
      color: 0xff5535, roughness: 0.18, metalness: 0.0,
      clearcoat: 1.0, clearcoatRoughness: 0.04, envMapIntensity: 1.3,
    });
    const group = new THREE.Group();
    scene.add(group);

    let W = 0, H = 0;
    function resize() {
      const r = card.getBoundingClientRect();
      W = r.width; H = r.height;
      renderer.setSize(W, H, false);
      camera.right = W; camera.bottom = -H; camera.updateProjectionMatrix();
      catcher.scale.set(W, H, 1);
      catcher.position.set(W / 2, -H / 2, -14);
      const c = new THREE.Vector3(W / 2, -H / 2, 0);
      key.target.position.copy(c);
      key.position.set(c.x - 260, c.y + 260, 380);
      const s = key.shadow.camera; const m = Math.max(W, H);
      s.left = -m; s.right = m; s.top = m; s.bottom = -m; s.near = 1; s.far = 1500;
      s.updateProjectionMatrix();
      shine.target.position.copy(c);
      shine.position.set(c.x - 120, c.y + 160, 300);
    }

    function rebuild() {
      const c = card.getBoundingClientRect();
      if (c.width !== W || c.height !== H) resize();
      group.children.forEach((m) => (m as THREE.Mesh).geometry.dispose());
      group.clear();

      const badges = card.querySelectorAll('.raised-badge');
      badges.forEach((el) => {
        const r = (el as HTMLElement).getBoundingClientRect();
        const size = Math.min(r.width, r.height) / 2;
        const mesh = new THREE.Mesh(new THREE.SphereGeometry(size, 48, 32), badgeMat);
        mesh.scale.z = 0.6;
        mesh.position.set((r.left + r.right) / 2 - c.left, -((r.top + r.bottom) / 2 - c.top), 4);
        mesh.castShadow = mesh.receiveShadow = true;
        group.add(mesh);
      });
      draw();
    }

    let raf = 0;
    function draw() { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => renderer.render(scene, camera)); }
    let pending = 0;
    function schedule() { cancelAnimationFrame(pending); pending = requestAnimationFrame(rebuild); }

    const gridEl = gridRef.current;
    const mo = new MutationObserver(schedule);
    if (gridEl) mo.observe(gridEl, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    const ro = new ResizeObserver(schedule);
    ro.observe(card);

    function onMove(e: PointerEvent) {
      const r = card.getBoundingClientRect();
      shine.position.set(e.clientX - r.left, -(e.clientY - r.top), 260);
      draw();
    }
    card.addEventListener('pointermove', onMove);

    resize();
    rebuild();

    return () => {
      card.removeEventListener('pointermove', onMove);
      mo.disconnect(); ro.disconnect();
      cancelAnimationFrame(raf);
      renderer.dispose();
    };
  }, []);

  // ----------- Grid data -----------
  const grid = useMemo(() => {
    const year = cursor.getFullYear();
    const month = cursor.getMonth();
    const firstDayIndex = new Date(year, month, 1).getDay();
    const totalDays = new Date(year, month + 1, 0).getDate();
    const cells: { date: Date | null; col: number }[] = [];
    for (let i = 0; i < firstDayIndex; i++) cells.push({ date: null, col: i });
    for (let d = 1; d <= totalDays; d++) {
      cells.push({ date: new Date(year, month, d), col: (firstDayIndex + d - 1) % 7 });
    }
    return cells;
  }, [cursor]);

  // ----------- Handlers -----------
  function clickDay(d: Date) {
    setActivePreset(null);
    if (mode === 'single') {
      setSingle(new Date(d));
      return;
    }
    if (!start || (start && end)) {
      setStart(new Date(d)); setEnd(null); setHover(null);
    } else if (start && !end) {
      if (d < start) { setStart(new Date(d)); setEnd(null); }
      else { setEnd(new Date(d)); setHover(null); }
    }
  }

  function clearAll() {
    setStart(null); setEnd(null); setSingle(null); setHover(null); setActivePreset(null);
  }

  function applyPreset(label: string) {
    const now = new Date();
    let s: Date, e: Date;
    switch (label) {
      case 'Today': s = e = now; break;
      case 'Yesterday': {
        const y = new Date(now); y.setDate(y.getDate() - 1); s = e = y; break;
      }
      case 'Last 7 Days': {
        e = now; s = new Date(now); s.setDate(now.getDate() - 6); break;
      }
      case 'Last 30 Days': {
        e = now; s = new Date(now); s.setDate(now.getDate() - 29); break;
      }
      case 'This Month': {
        s = new Date(now.getFullYear(), now.getMonth(), 1);
        e = new Date(now.getFullYear(), now.getMonth() + 1, 0); break;
      }
      case 'Last Month': {
        s = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        e = new Date(now.getFullYear(), now.getMonth(), 0); break;
      }
      case 'This Year': {
        s = new Date(now.getFullYear(), 0, 1); e = new Date(now.getFullYear(), 11, 31); break;
      }
      case 'Last Year': {
        s = new Date(now.getFullYear() - 1, 0, 1); e = new Date(now.getFullYear() - 1, 11, 31); break;
      }
      default: return;
    }
    setMode('range');
    setStart(s); setEnd(e); setHover(null);
    setCursor(new Date(s.getFullYear(), s.getMonth(), 1));
    setActivePreset(label);
  }

  // ----------- Effective range (with hover preview) -----------
  let effStart: Date | null = null; let effEnd: Date | null = null;
  if (mode === 'single' && single) { effStart = single; effEnd = single; }
  else if (mode === 'range') {
    if (start && end) {
      effStart = start < end ? start : end;
      effEnd = start < end ? end : start;
    } else if (start && hover) {
      effStart = start < hover ? start : hover;
      effEnd = start < hover ? hover : start;
    } else if (start) {
      effStart = start;
    }
  }

  return (
    <div className="grid gap-6" style={{ gridTemplateColumns: 'minmax(0, 240px) minmax(0, 400px)' }}>
      {/* --- Left: range presets (matches rangeSelectionArea.png) --- */}
      <div className="neu-card p-6 flex flex-col gap-3" style={{ height: 'fit-content' }}>
        <div className="carved text-sm font-medium mb-1">Quick Range</div>
        <div className="flex flex-col gap-2.5">
          {RANGE_PRESETS.map((p) => (
            <button
              key={p.label}
              className={`range-pill ${activePreset === p.label ? 'active' : ''}`}
              style={{ textAlign: 'left', paddingLeft: 20 }}
              onClick={() => applyPreset(p.label)}
            >
              {p.label}
            </button>
          ))}
        </div>
        <div className="carved text-xs opacity-60 mt-3 pt-3" style={{ borderTop: '1px solid rgba(0,0,0,0.05)' }}>
          Custom Range
        </div>
        <div className="flex gap-2">
          <button
            className={`neu-btn text-sm ${mode === 'single' ? 'active' : ''}`}
            style={{ padding: '8px 12px', flex: 1 }}
            onClick={() => setMode('single')}
          >
            Single
          </button>
          <button
            className={`neu-btn text-sm ${mode === 'range' ? 'active' : ''}`}
            style={{ padding: '8px 12px', flex: 1 }}
            onClick={() => setMode('range')}
          >
            Range
          </button>
        </div>
      </div>

      {/* --- Right: picker card with WebGL gloss layer --- */}
      <div ref={cardRef} className="neu-card p-8 relative isolate" style={{ position: 'relative' }}>
        <canvas
          ref={canvasRef}
          className="absolute pointer-events-none"
          style={{ inset: 0, width: '100%', height: '100%', zIndex: 1, borderRadius: 'inherit' }}
        />
        {/* Range display slot */}
        <div className="neu-pressed flex items-center justify-between px-5 py-4 mb-6" style={{ position: 'relative', zIndex: 2 }}>
          <span className="carved" style={{ opacity: (mode === 'single' ? single : start) ? 1 : 0.55 }}>
            {mode === 'single' ? (fmt(single) ?? 'Select Date') : (fmt(start) ?? 'Start Date')}
          </span>
          {mode === 'range' && (
            <>
              <span style={{ color: 'var(--coral-accent)', fontWeight: 600, fontSize: '1.1rem' }}>→</span>
              <span className="carved" style={{ opacity: end ? 1 : 0.55 }}>
                {fmt(end) ?? 'End Date'}
              </span>
            </>
          )}
        </div>

        {/* Month nav */}
        <div className="flex justify-between items-center mb-5" style={{ position: 'relative', zIndex: 2 }}>
          <button className="neu-icon-btn" style={{ width: 40, height: 40 }} onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}>
            <ChevronLeft size={18} />
          </button>
          <div className="carved" style={{ fontSize: '1.05rem', fontWeight: 500 }}>
            {MONTHS[cursor.getMonth()]} {cursor.getFullYear()}
          </div>
          <button className="neu-icon-btn" style={{ width: 40, height: 40 }} onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}>
            <ChevronRight size={18} />
          </button>
        </div>

        {/* Weekday labels */}
        <div className="trench-row carved mb-2" style={{ fontSize: '.85rem', fontWeight: 500, textAlign: 'center', position: 'relative', zIndex: 2 }}>
          {WEEKDAYS.map((w) => <div key={w}>{w}</div>)}
        </div>

        {/* Days grid */}
        <div
          ref={gridRef}
          className="trench-row"
          style={{ position: 'relative', zIndex: 2 }}
          onMouseLeave={() => { if (start && !end) setHover(null); }}
        >
          {grid.map((c, i) => {
            if (!c.date) return <div key={i} className="day-cell empty" />;
            const d = c.date;
            const isStart = effStart && sameDay(d, effStart);
            const isEnd = effEnd && sameDay(d, effEnd);
            const isMid = effStart && effEnd && d > effStart && d < effEnd;
            const inRange = isStart || isEnd || isMid;

            const classes = ['day-cell', 'interactive', 'carved'];
            if (inRange) classes.push('in-trench');
            if (inRange && (isStart || c.col === 0)) classes.push('trench-cap-left');
            if (inRange && (isEnd || c.col === 6 || (isStart && !effEnd))) classes.push('trench-cap-right');

            return (
              <div
                key={i}
                className={classes.join(' ')}
                onClick={() => clickDay(d)}
                onMouseEnter={() => { if (mode === 'range' && start && !end) setHover(d); }}
              >
                {(isStart || isEnd) ? (
                  <div className="raised-badge fallback">{d.getDate()}</div>
                ) : (
                  <span>{d.getDate()}</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Actions */}
        <div className="flex justify-end mt-5" style={{ position: 'relative', zIndex: 2 }}>
          <button className="neu-btn coral" style={{ padding: '10px 20px', fontSize: '.88rem' }} onClick={clearAll}>
            Clear
          </button>
        </div>
      </div>
    </div>
  );
}
