import { useMemo, useRef, useState } from 'react';
import { Mail, Phone, MapPin, Plus, Minus, ChevronDown, ChevronRight } from 'lucide-react';

export type Employee = {
  id: number;
  name: string;
  title: string;
  department: string | null;
  email: string | null;
  phone: string | null;
  location: string | null;
  manager_id: number | null;
  photo_url: string | null;
  level: number;
  team_size: number;
};

type TreeNode = Employee & { children: TreeNode[] };

function buildTree(rows: Employee[]): TreeNode[] {
  const byId = new Map<number, TreeNode>();
  rows.forEach((r) => byId.set(r.id, { ...r, children: [] }));
  const roots: TreeNode[] = [];
  for (const r of byId.values()) {
    if (r.manager_id && byId.has(r.manager_id)) {
      byId.get(r.manager_id)!.children.push(r);
    } else {
      roots.push(r);
    }
  }
  return roots;
}

/**
 * Per-tile control state
 */
type TileState = { zoom: number; expanded: boolean };

export default function OrgChart({ employees }: { employees: Employee[] }) {
  const tree = useMemo(() => buildTree(employees), [employees]);
  const [tileState, setTileState] = useState<Record<number, TileState>>({});
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [globalScale, setGlobalScale] = useState<number>(1);
  const scrollRef = useRef<HTMLDivElement>(null);

  const setTile = (id: number, patch: Partial<TileState>) => {
    setTileState((prev) => {
      const base: TileState = prev[id] ?? { zoom: 1, expanded: true };
      return { ...prev, [id]: { ...base, ...patch } };
    });
  };

  const getState = (id: number): TileState =>
    tileState[id] ?? { zoom: 1, expanded: true };

  return (
    <div className="w-full h-full flex flex-col gap-4">
      {/* Global chrome */}
      <div className="flex items-center justify-between px-1">
        <div>
          <h2 className="carved text-2xl font-medium">Organization Structure</h2>
          <p className="carved text-sm opacity-70 mt-1">
            {employees.length} people · {tree.length} root{tree.length !== 1 ? 's' : ''} · tile-level zoom
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            className="neu-icon-btn"
            title="Zoom out"
            onClick={() => setGlobalScale((s) => Math.max(0.5, +(s - 0.1).toFixed(2)))}
          >
            <Minus size={16} strokeWidth={2.5} />
          </button>
          <div className="range-pill" style={{ minWidth: 60, textAlign: 'center' }}>
            {Math.round(globalScale * 100)}%
          </div>
          <button
            className="neu-icon-btn"
            title="Zoom in"
            onClick={() => setGlobalScale((s) => Math.min(1.6, +(s + 0.1).toFixed(2)))}
          >
            <Plus size={16} strokeWidth={2.5} />
          </button>
        </div>
      </div>

      {/* Chart canvas */}
      <div
        ref={scrollRef}
        className="neu-pressed flex-1 overflow-auto p-8"
        style={{ minHeight: 520 }}
      >
        <div
          style={{
            transform: `scale(${globalScale})`,
            transformOrigin: 'top center',
            transition: 'transform .18s ease',
            display: 'flex',
            justifyContent: 'center',
            paddingBottom: 40,
          }}
        >
          <div className="flex flex-col items-center gap-14">
            {tree.map((root) => (
              <TreeBranch
                key={root.id}
                node={root}
                tileState={tileState}
                setTile={setTile}
                getState={getState}
                selectedId={selectedId}
                setSelectedId={setSelectedId}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- branch

function TreeBranch({
  node,
  tileState,
  setTile,
  getState,
  selectedId,
  setSelectedId,
}: {
  node: TreeNode;
  tileState: Record<number, TileState>;
  setTile: (id: number, patch: Partial<TileState>) => void;
  getState: (id: number) => TileState;
  selectedId: number | null;
  setSelectedId: (id: number) => void;
}) {
  const state = getState(node.id);

  return (
    <div className="flex flex-col items-center">
      <EmployeeTile
        emp={node}
        state={state}
        setState={(patch) => setTile(node.id, patch)}
        selected={selectedId === node.id}
        onSelect={() => setSelectedId(node.id)}
        hasChildren={node.children.length > 0}
      />

      {node.children.length > 0 && state.expanded && (
        <>
          {/* vertical connector (darker per request) */}
          <div style={{ width: 3, height: 34, background: '#4a4038', borderRadius: 2 }} />

          {/* horizontal connector spanning all children */}
          <div style={{ position: 'relative', width: '100%' }}>
            {node.children.length > 1 && (
              <div
                aria-hidden
                style={{
                  position: 'absolute',
                  left: '10%',
                  right: '10%',
                  top: 0,
                  height: 3,
                  background: '#4a4038',
                  borderRadius: 2,
                }}
              />
            )}
            <div className="flex items-start justify-center gap-10 pt-8">
              {node.children.map((child) => (
                <div key={child.id} className="flex flex-col items-center">
                  {/* short vertical drop into each child */}
                  <div style={{ width: 3, height: 20, background: '#4a4038', marginTop: -30, borderRadius: 2 }} />
                  <TreeBranch
                    node={child}
                    tileState={tileState}
                    setTile={setTile}
                    getState={getState}
                    selectedId={selectedId}
                    setSelectedId={setSelectedId}
                  />
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- tile

function EmployeeTile({
  emp,
  state,
  setState,
  selected,
  onSelect,
  hasChildren,
}: {
  emp: TreeNode;
  state: TileState;
  setState: (patch: Partial<TileState>) => void;
  selected: boolean;
  onSelect: () => void;
  hasChildren: boolean;
}) {
  const zoom = state.zoom;
  const baseWidth = 250;
  const width = baseWidth * zoom;

  return (
    <div
      onClick={onSelect}
      className="neu-tile"
      style={{
        width,
        padding: `${16 * zoom}px`,
        transition: 'transform .16s ease, box-shadow .16s ease, width .16s ease',
        outline: selected ? `2px solid var(--coral-accent)` : 'none',
        outlineOffset: 3,
        cursor: 'pointer',
        position: 'relative',
      }}
    >
      {/* Zoom controls in top-right of the tile (replaces zoom-lock) */}
      <div
        className="absolute flex gap-1.5"
        style={{ top: 10, right: 10 }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          className="neu-icon-btn"
          style={{ width: 26, height: 26 }}
          onClick={() => setState({ zoom: Math.max(0.75, +(zoom - 0.1).toFixed(2)) })}
          title="Zoom out tile"
        >
          <Minus size={13} strokeWidth={2.5} />
        </button>
        <button
          className="neu-icon-btn"
          style={{ width: 26, height: 26 }}
          onClick={() => setState({ zoom: Math.min(1.5, +(zoom + 0.1).toFixed(2)) })}
          title="Zoom in tile"
        >
          <Plus size={13} strokeWidth={2.5} />
        </button>
      </div>

      {/* Avatar + name */}
      <div className="flex items-center gap-3">
        <div
          className="neu-pressed"
          style={{
            width: 64 * zoom,
            height: 64 * zoom,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 4,
            flexShrink: 0,
          }}
        >
          <img
            src={emp.photo_url ?? ''}
            alt={emp.name}
            style={{
              width: '100%',
              height: '100%',
              borderRadius: '50%',
              objectFit: 'cover',
              display: 'block',
            }}
            onError={(e) => {
              (e.target as HTMLImageElement).style.background = '#d3ccc3';
            }}
          />
        </div>
        <div className="min-w-0 flex-1 pr-6">
          <div
            className="carved font-medium truncate"
            style={{ fontSize: 15 * zoom, lineHeight: 1.25 }}
          >
            {emp.name}
          </div>
          <div
            className="truncate"
            style={{
              fontSize: 12 * zoom,
              color: 'var(--coral-accent)',
              fontWeight: 500,
              marginTop: 2,
            }}
          >
            {emp.title}
          </div>
          <div
            className="carved truncate"
            style={{ fontSize: 11 * zoom, opacity: 0.65, marginTop: 2 }}
          >
            {emp.department}
          </div>
        </div>
      </div>

      {/* Contact rows (compact) */}
      <div className="mt-3 space-y-1.5" style={{ fontSize: 11 * zoom }}>
        {emp.email && (
          <div className="carved flex items-center gap-2 opacity-80 truncate">
            <Mail size={11 * zoom} color="#7a7166" />
            <span className="truncate">{emp.email}</span>
          </div>
        )}
        {emp.phone && (
          <div className="carved flex items-center gap-2 opacity-80 truncate">
            <Phone size={11 * zoom} color="#7a7166" />
            <span>{emp.phone}</span>
          </div>
        )}
        {emp.location && (
          <div className="carved flex items-center gap-2 opacity-80 truncate">
            <MapPin size={11 * zoom} color="#7a7166" />
            <span>{emp.location}</span>
          </div>
        )}
      </div>

      {/* Footer: team size + expand */}
      {(emp.team_size > 0 || hasChildren) && (
        <div className="mt-3 flex items-center justify-between">
          <div
            className="range-pill"
            style={{ padding: `4px 12px`, fontSize: 11 * zoom }}
          >
            {emp.team_size} reports
          </div>
          {hasChildren && (
            <button
              className="neu-icon-btn"
              style={{ width: 28, height: 28 }}
              onClick={(e) => {
                e.stopPropagation();
                setState({ expanded: !state.expanded });
              }}
              title={state.expanded ? 'Collapse' : 'Expand'}
            >
              {state.expanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
