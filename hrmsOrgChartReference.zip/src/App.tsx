import { useEffect, useState } from 'react';
import { Users, Activity, Calendar, Clock, FileText } from 'lucide-react';
import OrgChart, { type Employee } from './components/OrgChart';
import Sankey3D, { type FunnelLink } from './components/Sankey3D';
import NeuDatePicker from './components/NeuDatePicker';
import NeuTimePicker from './components/NeuTimePicker';

type Tab = 'org' | 'sankey' | 'date' | 'time' | 'report';

const TABS: { id: Tab; label: string; Icon: typeof Users }[] = [
  { id: 'org', label: 'Org Chart', Icon: Users },
  { id: 'sankey', label: 'Hiring Funnel', Icon: Activity },
  { id: 'date', label: 'Date & Range', Icon: Calendar },
  { id: 'time', label: 'Time Picker', Icon: Clock },
  { id: 'report', label: 'Sankey Analysis', Icon: FileText },
];

export default function App() {
  const [tab, setTab] = useState<Tab>('org');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [funnel, setFunnel] = useState<FunnelLink[]>([]);
  const [loading, setLoading] = useState(true);
  const [report, setReport] = useState<string>('');

  useEffect(() => {
    (async () => {
      try {
        const [eRes, fRes, rRes] = await Promise.all([
          fetch('/api/employees'),
          fetch('/api/hiring-funnel'),
          fetch('/sankeyComplexSceneAnalysis.txt'),
        ]);
        const [e, f, r] = await Promise.all([eRes.json(), fRes.json(), rRes.text()]);
        setEmployees(Array.isArray(e) ? e : []);
        setFunnel(Array.isArray(f) ? f : []);
        setReport(r);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div className="min-h-screen w-full" style={{ background: 'var(--bg-color)' }}>
      {/* Top bar */}
      <header className="sticky top-0 z-10" style={{ background: 'var(--bg-color)', borderBottom: '1px solid rgba(0,0,0,0.03)' }}>
        <div className="max-w-[1400px] mx-auto px-6 py-4 flex items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div
              className="neu-tile flex items-center justify-center"
              style={{ width: 42, height: 42, borderRadius: 12 }}
            >
              <div
                style={{
                  width: 22, height: 22, borderRadius: 6,
                  background: 'linear-gradient(135deg, #ff8b6a, #d9421f)',
                  boxShadow: '0 3px 8px rgba(217, 66, 31, 0.35)',
                }}
              />
            </div>
            <div>
              <div className="carved text-lg font-medium leading-tight">Aviary HRMS</div>
              <div className="carved text-xs opacity-60 leading-tight">Neumorphic + Three.js glossy edition</div>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-2">
            {TABS.map(({ id, label, Icon }) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={`neu-btn ${tab === id ? 'active' : ''}`}
                style={{ padding: '10px 16px', fontSize: '.88rem', display: 'flex', alignItems: 'center', gap: 8 }}
              >
                <Icon size={15} strokeWidth={2} />
                <span>{label}</span>
              </button>
            ))}
          </nav>
        </div>
        {/* mobile nav */}
        <div className="md:hidden overflow-x-auto no-scrollbar px-4 pb-3 flex gap-2">
          {TABS.map(({ id, label, Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`neu-btn shrink-0 ${tab === id ? 'active' : ''}`}
              style={{ padding: '8px 14px', fontSize: '.8rem', display: 'flex', alignItems: 'center', gap: 6 }}
            >
              <Icon size={14} />
              <span>{label}</span>
            </button>
          ))}
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-[1400px] mx-auto px-4 md:px-6 py-6">
        {loading ? (
          <div className="neu-card p-16 text-center carved">
            <div className="text-lg">Loading HRMS…</div>
            <div className="text-sm opacity-60 mt-2">Fetching people and funnel data</div>
          </div>
        ) : (
          <>
            {tab === 'org' && (
              <div style={{ height: 'calc(100vh - 180px)' }}>
                <OrgChart employees={employees} />
              </div>
            )}

            {tab === 'sankey' && (
              <div className="flex flex-col gap-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="carved text-2xl font-medium">Hiring Funnel · 3D Sankey</h2>
                    <p className="carved text-sm opacity-70 mt-1">
                      DFS-ordered stages · rounded ribbon caps · drag to orbit
                    </p>
                  </div>
                  <div className="hidden md:flex items-center gap-3">
                    {[
                      ['#5bc0eb', 'Job boards'],
                      ['#d9389e', 'LinkedIn'],
                      ['#31955b', 'Referrals'],
                      ['#f4b333', 'Screened'],
                      ['#f17a23', 'Interviewed'],
                      ['#40c9c5', 'Rejected'],
                      ['#295fb2', 'Offered'],
                      ['#8cc63f', 'Hired'],
                      ['#d83c3c', 'Declined'],
                    ].map(([c, l]) => (
                      <div key={l as string} className="flex items-center gap-1.5 carved" style={{ fontSize: '.75rem' }}>
                        <div style={{ width: 12, height: 10, background: c, borderRadius: 3 }} />
                        <span>{l}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="neu-pressed overflow-hidden" style={{ height: 'calc(100vh - 240px)', minHeight: 480 }}>
                  <Sankey3D links={funnel} />
                </div>
              </div>
            )}

            {tab === 'date' && (
              <div className="flex flex-col gap-4">
                <div>
                  <h2 className="carved text-2xl font-medium">Date &amp; Range Picker</h2>
                  <p className="carved text-sm opacity-70 mt-1">
                    Neumorphic base · continuous trench selection · glossy WebGL Start / End badges
                  </p>
                </div>
                <NeuDatePicker />
              </div>
            )}

            {tab === 'time' && (
              <div className="flex flex-col gap-4">
                <div>
                  <h2 className="carved text-2xl font-medium">Time Picker</h2>
                  <p className="carved text-sm opacity-70 mt-1">
                    Glossy Three.js knobs on the clock hand tip and slider handles
                  </p>
                </div>
                <NeuTimePicker />
              </div>
            )}

            {tab === 'report' && (
              <div className="flex flex-col gap-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="carved text-2xl font-medium">Sankey Complex Scene Analysis</h2>
                    <p className="carved text-sm opacity-70 mt-1">
                      sankeyComplexSceneAnalysis.txt · rules for resolving crossings without altering the renderer
                    </p>
                  </div>
                  <a
                    href="/sankeyComplexSceneAnalysis.txt"
                    download="sankeyComplexSceneAnalysis.txt"
                    className="neu-btn coral"
                    style={{ padding: '10px 18px', fontSize: '.85rem', textDecoration: 'none' }}
                  >
                    Download .txt
                  </a>
                </div>
                <div className="neu-pressed p-6 overflow-auto" style={{ maxHeight: 'calc(100vh - 260px)' }}>
                  <pre className="carved" style={{ whiteSpace: 'pre-wrap', fontSize: 12.5, lineHeight: 1.55, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>{report}</pre>
                </div>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
