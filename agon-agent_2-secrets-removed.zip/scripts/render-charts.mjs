// Offscreen visual harness: paints every chart kind with node-canvas into
// PNGs under public/uploads/qa so the output can be eyeballed without a
// browser. Usage: node scripts/render-charts.mjs [canvasModulePath]
import { spawnSync } from 'child_process';
import { writeFileSync, mkdtempSync, mkdirSync, existsSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

const canvasMod = process.argv[2] || 'canvas';
const tmp = mkdtempSync(join(tmpdir(), 'chart-render-'));
const entry = join(tmp, 'entry.ts');
const outDir = join(process.cwd(), 'public/uploads/qa');
mkdirSync(outDir, { recursive: true });

writeFileSync(entry, `
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const { createCanvas } = require(${JSON.stringify(canvasMod)});
import { writeFileSync } from 'fs';

// ---- minimal DOM shims the painters touch ----
(globalThis as any).document = {
  createElement: (tag: string) => tag === 'canvas' ? createCanvas(10, 10) : { style: {} },
  documentElement: {},
  fonts: { ready: Promise.resolve() },
};
(globalThis as any).getComputedStyle = () => ({ getPropertyValue: () => '' });
(globalThis as any).document.documentElement = { getAttribute: () => null };
(globalThis as any).window = { devicePixelRatio: 1, addEventListener() {}, removeEventListener() {} };

const C = await import('${process.cwd()}/src/shared/Charts.tsx');
const { paintChart, composeExport, exportDims, paintNeuExport, neuExportDims, paintNeuCircular, paintNeuLine, themeColors, PALETTE } = C;

const many = Array.from({ length: 26 }, (_, i) => ({ label: ['January','February','March','April','May','June','July','August','September','October','November','December'][i % 12] + ' ' + (2023 + Math.floor(i / 12)), value: 20 + Math.round(60 * Math.abs(Math.sin(i * 0.7))) }));
const data = [
  { label: 'Engineering Team', value: 240 },
  { label: 'Sales & Partnerships', value: 96 },
  { label: 'Customer Success', value: 58 },
  { label: 'Human Resources', value: 30 },
  { label: 'Finance Operations', value: 18 },
  { label: 'Legal & Compliance', value: 9 },
];
const cats = ['Q1 FY24', 'Q2 FY24', 'Q3 FY24', 'Q4 FY24', 'Q1 FY25', 'Q2 FY25'];
const series = [
  { name: 'Product & Tech', values: [12, 18, 15, 22, 26, 24] },
  { name: 'Go-To-Market', values: [8, 10, 14, 12, 17, 19] },
  { name: 'Corporate', values: [5, 6, 8, 7, 9, 11] },
];
const colors = data.map((_, i) => PALETTE[i % PALETTE.length]);
const hov = { idx: null, seg: null, amt: 0 };
const save = (name: string, cv: any) => writeFileSync('${outDir}/' + name + '.png', cv.toBuffer('image/png'));

// 1) live-style renders on a transparent-ish dark bg to prove nothing is clipped
function live(kind: string, W: number, H: number, m: number, opts: any = {}) {
  const cv = createCanvas(W, H); const ctx = cv.getContext('2d');
  ctx.fillStyle = '#e4e7e0'; ctx.fillRect(0, 0, W, H);
  paintChart(ctx, kind as any, { W, H, t: themeColors(false), p: 1, m, hov, data: opts.data || data, colors: opts.colors || colors,
    multi: !!opts.series, cats: opts.series ? cats : [], series: opts.series || [], sColors: PALETTE.slice(0, 3), yLabel: 'Employees', full: !!opts.full, bg: '#e4e7e0' });
  return cv;
}
save('live-pie-3d', live('pie', 520, 240, 1));
save('live-donut-2d', live('donut', 520, 240, 0));
save('live-donut-morph-half', live('donut', 520, 240, 0.5));
save('live-funnel-3d', live('funnel', 560, 280, 1));
save('live-funnel-2d', live('funnel', 560, 280, 0));
save('live-area-3d', live('area', 640, 260, 1, { series }));
save('live-bar-many-compact', live('bar', 640, 260, 0, { data: many, colors: many.map((_, i) => PALETTE[i % PALETTE.length]) }));
save('live-line-many-full', live('line', 1000, 520, 0, { data: many, colors: many.map((_, i) => PALETTE[i % PALETTE.length]), full: true }));
save('live-pie-full', live('pie', 1000, 520, 1, { full: true }));

// 2) exports (white bg, wide enough for complete labels)
for (const kind of ['pie', 'donut', 'bar', 'area', 'funnel', 'radar']) {
  const multi = kind === 'area';
  const dims = exportDims(kind as any, 520, 240, data, multi, multi ? cats : []);
  const t = themeColors(true);
  const cv = composeExport('Headcount by department · ' + kind, dims.W, dims.H, data.map((d, i) => ({ label: d.label, color: colors[i] })),
    (ctx: any) => paintChart(ctx, kind as any, { W: dims.W, H: dims.H, t, p: 1, m: kind === 'bar' ? 0 : 1, hov, data, colors, multi, cats: multi ? cats : [], series: multi ? series : [], sColors: PALETTE.slice(0, 3), yLabel: 'Employees', full: true, bg: '#ffffff' }), t);
  save('export-' + kind, cv);
}

// 3) neumorphic family
for (const kind of ['donut', 'pie', 'bars', 'columns', 'line', 'area']) {
  const d0 = kind === 'line' || kind === 'area' ? many : data;
  const dims = neuExportDims(kind as any, d0);
  const cv = createCanvas(dims.W, dims.H); const ctx = cv.getContext('2d');
  paintNeuExport(ctx, dims.W, dims.H, kind as any, { data: d0, colors: d0.map((_, i) => PALETTE[i % PALETTE.length]), t: themeColors(true), p: 1, hover: null, amt: 0, centerLabel: 'headcount', full: true }, 'Neumorphic ' + kind);
  save('neu-export-' + kind, cv);
}
// live neu circular at the analytics size (132) + hover state, on the app surface
{
  const S = 132 + 36; const cv = createCanvas(S * 2 + 20, S); const ctx = cv.getContext('2d');
  ctx.fillStyle = '#e4e7e0'; ctx.fillRect(0, 0, cv.width, cv.height);
  const t = { ...themeColors(false), surface: '#e4e7e0', ink: '#101914' };
  paintNeuCircular(ctx, true, S / 2, S / 2, 132 / 2 - 4, { data, colors, t, p: 1, hover: 1, amt: 1, centerLabel: 'headcount', full: false });
  paintNeuCircular(ctx, false, S + 20 + S / 2, S / 2, 132 / 2 - 4, { data, colors, t, p: 1, hover: null, amt: 0, centerLabel: 'headcount', full: false });
  save('neu-live-circular', cv);
}
{
  const W = 420, H = 172; const cv = createCanvas(W, H); const ctx = cv.getContext('2d');
  ctx.fillStyle = '#e4e7e0'; ctx.fillRect(0, 0, W, H);
  paintNeuLine(ctx, true, W, H, { data: many, colors, t: { ...themeColors(false), surface: '#e4e7e0', ink: '#101914' }, p: 1, hover: 7, amt: 1, centerLabel: '', full: false });
  save('neu-live-area-compact', cv);
}

// 4) new kinds + morph/hover checks
save('live-radialbar', live('radialbar', 520, 260, 0));
save('live-dual-multi', live('dual', 640, 280, 0, { series }));
save('live-dual-single', live('dual', 640, 280, 0));
{
  // diameter must be identical at m=0, m=0.5, m=1 — paint side by side
  const W = 520, H = 240; const cv = createCanvas(W * 3 + 20, H); const ctx = cv.getContext('2d');
  ctx.fillStyle = '#e4e7e0'; ctx.fillRect(0, 0, cv.width, cv.height);
  [0, 0.5, 1].forEach((m, i) => {
    ctx.save(); ctx.translate(i * (W + 10), 0);
    paintChart(ctx, 'donut', { W, H, t: themeColors(false), p: 1, m, hov: i === 2 ? { idx: 1, seg: null, amt: 1 } : hov, data, colors, multi: false, cats: [], series: [], sColors: [], full: false });
    ctx.restore();
  });
  save('morph-donut-0-50-100-hover3d', cv);
}
save('live-pyramid-3d-half', live('pyramid', 560, 280, 0.5));

console.log('rendered to public/uploads/qa');
`);

const fixBin = process.cwd() + '/.esbuild-fix/@esbuild/linux-x64/bin/esbuild';
const candidates = [fixBin, process.cwd() + '/node_modules/.bin/esbuild', '/mnt/efs-fullstack/sessions/node_modules/.bin/esbuild', '/usr/lib/node_modules/tsx/node_modules/esbuild/bin/esbuild'];
const esbuildBin = candidates.find((c) => existsSync(c)) || 'esbuild';
const out = join(tmp, 'bundle.mjs');
const r = spawnSync(esbuildBin, [
  entry, '--bundle', '--format=esm', '--platform=node', '--jsx=automatic',
  '--loader:.tsx=tsx', '--loader:.ts=ts', '--loader:.css=empty', '--loader:.woff2=empty', '--loader:.woff=empty', `--outfile=${out}`,
  '--external:react', '--external:react-dom', '--external:lucide-react', '--external:framer-motion', '--external:canvas',
], { encoding: 'utf8' });
if (r.status !== 0) { console.error(r.stderr); process.exit(1); }
const run = spawnSync('node', [out], { encoding: 'utf8', cwd: process.cwd() });
console.log(run.stdout);
if (run.stderr) console.error(run.stderr);
process.exit(run.status ?? 1);
