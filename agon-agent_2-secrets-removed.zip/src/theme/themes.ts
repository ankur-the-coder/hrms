import { FONT_LIBRARY, fontStack as bundledStack, loadFont, type FontCategory } from './fonts';

export type ThemeKey = 'soft' | 'basic' | 'brutal' | 'glass' | 'anime' | 'honest' | 'custom';
export type Mode = 'light' | 'dark';

export interface CustomTokens {
  bg: string; surface: string; surface2?: string; ink: string; muted?: string;
  accent: string; accentDeep?: string; glow?: string; gold?: string; goldDeep?: string;
  border?: string; radius?: string; radiusLg?: string;
  shadowCard?: string; shadowPop?: string; inset?: string;
  fontDisplay?: string; fontBody?: string;
}
export interface CustomTheme {
  name: string;
  tokens: CustomTokens;
  darkTokens?: CustomTokens;
}

export const THEME_LIST: { key: ThemeKey; name: string; desc: string; swatch: string[] }[] = [
  { key: 'soft', name: 'Soft UI', desc: 'Neumorphic — the Aviary signature', swatch: ['#e4e7e0', '#0d7a54', '#d9f96a', '#c9932b'] },
  { key: 'basic', name: 'Basic UI', desc: 'Clean, flat and quick', swatch: ['#f6f5f0', '#ffffff', '#0d7a54', '#101914'] },
  { key: 'brutal', name: 'Neo-Brutalism', desc: 'Hard borders, loud shadows', swatch: ['#fdf3d8', '#ffd900', '#1f6feb', '#111111'] },
  { key: 'glass', name: 'Glassmorphism', desc: 'Frosted panels over color fields', swatch: ['#dfe9ef', '#ffffffaa', '#0d7a54', '#3898c7'] },
  { key: 'anime', name: 'Anime', desc: 'Painted skies — meadow, teal & sunlight', swatch: ['#eaf2e8', '#3a8fb7', '#ffd166', '#e08e3c'] },
  { key: 'honest', name: 'Honest Paper', desc: 'From “Pie. — a small, honest chart maker”: warm paper, ink & hard shadows', swatch: ['#f6f1e7', '#1b1b1f', '#e4572e', '#d9d0be'] },
];

/** Chart palette that ships with the Honest Paper theme (Pie.’s slice colours, purple swapped for ink-blue). */
export const HONEST_PALETTE = ['#e4572e', '#f3a712', '#2e933c', '#669bbc', '#29335c', '#17bebb', '#f7b2ad', '#ffc857', '#a8c686', '#1e5aa8'];

/* ============================================================
   FONT LIBRARY — self-hosted Fontsource families (see fonts.ts).
   Nothing is fetched from Google Fonts or any CDN at runtime.
   ============================================================ */
export type { FontCategory };
export const GOOGLE_FONTS: { name: string; cat: FontCategory }[] = FONT_LIBRARY.map(({ name, cat }) => ({ name, cat }));
export const fontStack = bundledStack;
/** Load a bundled family (kept under its historical name for callers). */
export function loadGoogleFont(family: string) { void loadFont(family); }



export const WALLPAPERS: { key: string; name: string; css: string }[] = [
  { key: 'none', name: 'None', css: '' },
  { key: 'emerald-mist', name: 'Emerald Mist', css: 'radial-gradient(ellipse at 20% 15%, rgba(13,122,84,0.35), transparent 55%), radial-gradient(ellipse at 80% 85%, rgba(217,249,106,0.28), transparent 50%), linear-gradient(160deg, #eef3ec, #dce8df)' },
  { key: 'dawn', name: 'Dawn', css: 'linear-gradient(150deg, #ffdfc4 0%, #ffb8a0 30%, #b8a0d8 70%, #7a8ec9 100%)' },
  { key: 'graphite', name: 'Graphite Weave', css: 'repeating-linear-gradient(45deg, #23282c 0 14px, #272d31 14px 28px)' },
  { key: 'sakura', name: 'Sakura', css: 'radial-gradient(circle at 25% 20%, rgba(255,150,190,0.4), transparent 45%), radial-gradient(circle at 75% 70%, rgba(200,160,255,0.35), transparent 45%), linear-gradient(160deg, #fff0f5, #ffe4ef)' },
  { key: 'aurora', name: 'Aurora', css: 'linear-gradient(200deg, #071a14 10%, #0b3b2d 40%, #14755b 65%, #58c1a0 100%)' },
];

/** Ready-made prompt the user pastes into any AI along with their design brief. */
export const CUSTOM_THEME_PROMPT = `You are a UI theme generator. I will describe the design style I want below. Respond with ONLY a valid JSON object (no markdown, no commentary) matching exactly this schema:

{
  "name": "<short theme name>",
  "tokens": {
    "bg": "<page background css color>",
    "surface": "<card/panel background css color>",
    "surface2": "<secondary surface css color>",
    "ink": "<main text color>",
    "muted": "<secondary text color>",
    "accent": "<primary action color>",
    "accentDeep": "<darker accent for hover>",
    "glow": "<highlight/accent-2 color>",
    "gold": "<warm secondary accent>",
    "goldDeep": "<darker warm accent>",
    "border": "<border color, may be 'transparent'>",
    "radius": "<corner radius e.g. '14px'>",
    "radiusLg": "<large corner radius e.g. '20px'>",
    "shadowCard": "<css box-shadow for cards>",
    "shadowPop": "<stronger css box-shadow for popovers>",
    "inset": "<inset css box-shadow for inputs>",
    "fontDisplay": "<css font-family stack for headings>",
    "fontBody": "<css font-family stack for body>"
  },
  "darkTokens": { same keys as tokens, tuned for dark mode }
}

Rules: all values must be valid CSS. Ensure WCAG-readable contrast between ink and bg/surface. Shadows should express the style (e.g. hard offset for brutalism, soft dual shadows for neumorphism). Fonts must be web-safe or one of the bundled families: Fraunces, Outfit, Archivo Black, Baloo 2, IBM Plex Mono, Inter, Manrope, Sora, Playfair Display, Lora, Georgia, system-ui.

MY DESIGN BRIEF: <describe the look you want here>`;

const VAR_MAP: Record<keyof CustomTokens, string> = {
  bg: '--t-bg', surface: '--t-surface', surface2: '--t-surface2', ink: '--t-ink',
  muted: '--t-muted', accent: '--t-accent', accentDeep: '--t-accent-deep',
  glow: '--t-glow', gold: '--t-gold', goldDeep: '--t-gold-deep', border: '--t-border',
  radius: '--t-radius', radiusLg: '--t-radius-lg', shadowCard: '--t-shadow-card',
  shadowPop: '--t-shadow-pop', inset: '--t-inset', fontDisplay: '--t-font-display',
  fontBody: '--t-font-body',
};

export function applyCustomTokens(theme: CustomTheme | null, mode: Mode) {
  const root = document.documentElement;
  Object.values(VAR_MAP).forEach((v) => root.style.removeProperty(v));
  if (!theme) return;
  const t = mode === 'dark' && theme.darkTokens ? { ...theme.tokens, ...theme.darkTokens } : theme.tokens;
  (Object.keys(VAR_MAP) as (keyof CustomTokens)[]).forEach((k) => {
    const val = t[k];
    if (val && String(val).length < 400) root.style.setProperty(VAR_MAP[k], String(val));
  });
}

export function parseCustomTheme(text: string): CustomTheme {
  let raw = text.trim();
  const fence = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) raw = fence[1].trim();
  const obj = JSON.parse(raw);
  if (!obj || typeof obj !== 'object' || !obj.tokens) throw new Error('Missing "tokens" object');
  const req = ['bg', 'surface', 'ink', 'accent'];
  for (const k of req) {
    if (!obj.tokens[k]) throw new Error(`tokens.${k} is required`);
  }
  return { name: String(obj.name || 'Custom theme').slice(0, 48), tokens: obj.tokens, darkTokens: obj.darkTokens };
}
