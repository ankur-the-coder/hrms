/* ============================================================
   FONT LIBRARY — self-hosted via Fontsource (npm), zero runtime
   dependency on Google Fonts or any CDN.
   - Core theme fonts are bundled eagerly (Fraunces, Outfit,
     Archivo Black, Baloo 2, IBM Plex Mono).
   - Every other family (160+) is code-split: each family's weights
     are a lazy chunk, loaded the first time it is previewed or applied.
   - `fontFaceCss()` embeds loaded woff2 faces as base64 @font-face
     rules so exported SVGs can carry their fonts.
   ============================================================ */

/* ---- eager: fonts the built-in themes use ---- */
import '@fontsource/fraunces/latin-400.css';
import '@fontsource/fraunces/latin-400-italic.css';
import '@fontsource/fraunces/latin-600.css';
import '@fontsource/fraunces/latin-700.css';
import '@fontsource/fraunces/latin-700-italic.css';
import '@fontsource/outfit/latin-300.css';
import '@fontsource/outfit/latin-400.css';
import '@fontsource/outfit/latin-500.css';
import '@fontsource/outfit/latin-600.css';
import '@fontsource/outfit/latin-700.css';
import '@fontsource/outfit/latin-800.css';
import '@fontsource/archivo-black/latin-400.css';
import '@fontsource/baloo-2/latin-400.css';
import '@fontsource/baloo-2/latin-600.css';
import '@fontsource/baloo-2/latin-700.css';
import '@fontsource/baloo-2/latin-800.css';
import '@fontsource/ibm-plex-mono/latin-400.css';
import '@fontsource/ibm-plex-mono/latin-500.css';
import '@fontsource/ibm-plex-mono/latin-600.css';

export type FontCategory = 'serif' | 'sans-serif' | 'display' | 'handwriting' | 'monospace';

export interface FontEntry { pkg: string; name: string; cat: FontCategory; weights: number[]; italic?: boolean }

/** Generated from the installed @fontsource packages (latin subset, static weights). */
export const FONT_LIBRARY: FontEntry[] = [
  { pkg: "abril-fatface", name: "Abril Fatface", cat: "display", weights: [400] },
  { pkg: "albert-sans", name: "Albert Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "alfa-slab-one", name: "Alfa Slab One", cat: "display", weights: [400] },
  { pkg: "almarai", name: "Almarai", cat: "sans-serif", weights: [400, 700] },
  { pkg: "amatic-sc", name: "Amatic SC", cat: "handwriting", weights: [400, 700] },
  { pkg: "anton", name: "Anton", cat: "sans-serif", weights: [400] },
  { pkg: "archivo", name: "Archivo", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "archivo-black", name: "Archivo Black", cat: "sans-serif", weights: [400] },
  { pkg: "archivo-narrow", name: "Archivo Narrow", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "arvo", name: "Arvo", cat: "serif", weights: [400, 700], italic: true },
  { pkg: "assistant", name: "Assistant", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "audiowide", name: "Audiowide", cat: "display", weights: [400] },
  { pkg: "baloo-2", name: "Baloo 2", cat: "display", weights: [400, 600, 700] },
  { pkg: "baloo-bhai-2", name: "Baloo Bhai 2", cat: "display", weights: [400, 600, 700] },
  { pkg: "barlow", name: "Barlow", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "be-vietnam-pro", name: "Be Vietnam Pro", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "bebas-neue", name: "Bebas Neue", cat: "sans-serif", weights: [400] },
  { pkg: "big-shoulders-display", name: "Big Shoulders Display", cat: "display", weights: [400, 600, 700] },
  { pkg: "bitter", name: "Bitter", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "black-ops-one", name: "Black Ops One", cat: "display", weights: [400] },
  { pkg: "bodoni-moda", name: "Bodoni Moda", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "bricolage-grotesque", name: "Bricolage Grotesque", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "bungee", name: "Bungee", cat: "display", weights: [400] },
  { pkg: "cabin", name: "Cabin", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "cairo", name: "Cairo", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "cardo", name: "Cardo", cat: "serif", weights: [400, 700], italic: true },
  { pkg: "caveat", name: "Caveat", cat: "handwriting", weights: [400, 600, 700] },
  { pkg: "chewy", name: "Chewy", cat: "display", weights: [400] },
  { pkg: "chivo", name: "Chivo", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "chivo-mono", name: "Chivo Mono", cat: "monospace", weights: [400, 600, 700], italic: true },
  { pkg: "comfortaa", name: "Comfortaa", cat: "display", weights: [400, 600, 700] },
  { pkg: "commissioner", name: "Commissioner", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "concert-one", name: "Concert One", cat: "display", weights: [400] },
  { pkg: "cormorant-garamond", name: "Cormorant Garamond", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "courier-prime", name: "Courier Prime", cat: "monospace", weights: [400, 700], italic: true },
  { pkg: "crimson-pro", name: "Crimson Pro", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "crimson-text", name: "Crimson Text", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "dancing-script", name: "Dancing Script", cat: "handwriting", weights: [400, 600, 700] },
  { pkg: "dm-mono", name: "DM Mono", cat: "monospace", weights: [400, 500], italic: true },
  { pkg: "dm-sans", name: "DM Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "dm-serif-display", name: "DM Serif Display", cat: "serif", weights: [400], italic: true },
  { pkg: "domine", name: "Domine", cat: "serif", weights: [400, 600, 700] },
  { pkg: "eb-garamond", name: "EB Garamond", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "exo-2", name: "Exo 2", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "familjen-grotesk", name: "Familjen Grotesk", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "figtree", name: "Figtree", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "fira-code", name: "Fira Code", cat: "monospace", weights: [400, 600, 700] },
  { pkg: "frank-ruhl-libre", name: "Frank Ruhl Libre", cat: "serif", weights: [400, 600, 700] },
  { pkg: "fraunces", name: "Fraunces", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "fredoka", name: "Fredoka", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "gabarito", name: "Gabarito", cat: "display", weights: [400, 600, 700] },
  { pkg: "geist", name: "Geist", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "geist-mono", name: "Geist Mono", cat: "monospace", weights: [400, 600, 700], italic: true },
  { pkg: "gloock", name: "Gloock", cat: "serif", weights: [400] },
  { pkg: "gochi-hand", name: "Gochi Hand", cat: "handwriting", weights: [400] },
  { pkg: "golos-text", name: "Golos Text", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "great-vibes", name: "Great Vibes", cat: "handwriting", weights: [400] },
  { pkg: "hanken-grotesk", name: "Hanken Grotesk", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "hind", name: "Hind", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "hind-siliguri", name: "Hind Siliguri", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "host-grotesk", name: "Host Grotesk", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "ibm-plex-mono", name: "IBM Plex Mono", cat: "monospace", weights: [400, 600, 700], italic: true },
  { pkg: "ibm-plex-sans", name: "IBM Plex Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "ibm-plex-sans-condensed", name: "IBM Plex Sans Condensed", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "ibm-plex-serif", name: "IBM Plex Serif", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "inclusive-sans", name: "Inclusive Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "inconsolata", name: "Inconsolata", cat: "monospace", weights: [400, 600, 700] },
  { pkg: "indie-flower", name: "Indie Flower", cat: "handwriting", weights: [400] },
  { pkg: "instrument-sans", name: "Instrument Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "instrument-serif", name: "Instrument Serif", cat: "serif", weights: [400], italic: true },
  { pkg: "inter", name: "Inter", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "jetbrains-mono", name: "JetBrains Mono", cat: "monospace", weights: [400, 600, 700], italic: true },
  { pkg: "josefin-sans", name: "Josefin Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "jost", name: "Jost", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "kalam", name: "Kalam", cat: "handwriting", weights: [400, 700] },
  { pkg: "kanit", name: "Kanit", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "karla", name: "Karla", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "khand", name: "Khand", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "lato", name: "Lato", cat: "sans-serif", weights: [400, 700], italic: true },
  { pkg: "lexend", name: "Lexend", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "lexend-deca", name: "Lexend Deca", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "libre-baskerville", name: "Libre Baskerville", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "libre-caslon-text", name: "Libre Caslon Text", cat: "serif", weights: [400, 700], italic: true },
  { pkg: "lilita-one", name: "Lilita One", cat: "display", weights: [400] },
  { pkg: "literata", name: "Literata", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "lobster", name: "Lobster", cat: "display", weights: [400] },
  { pkg: "lora", name: "Lora", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "manjari", name: "Manjari", cat: "sans-serif", weights: [400, 700] },
  { pkg: "manrope", name: "Manrope", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "martian-mono", name: "Martian Mono", cat: "monospace", weights: [400, 600, 700] },
  { pkg: "merriweather", name: "Merriweather", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "michroma", name: "Michroma", cat: "sans-serif", weights: [400] },
  { pkg: "mitr", name: "Mitr", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "montserrat", name: "Montserrat", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "mukta", name: "Mukta", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "mulish", name: "Mulish", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "newsreader", name: "Newsreader", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "noto-sans", name: "Noto Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "noto-sans-devanagari", name: "Noto Sans Devanagari", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "noto-sans-jp", name: "Noto Sans JP", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "noto-sans-kr", name: "Noto Sans KR", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "noto-sans-sc", name: "Noto Sans SC", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "noto-serif", name: "Noto Serif", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "nunito", name: "Nunito", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "nunito-sans", name: "Nunito Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "onest", name: "Onest", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "open-sans", name: "Open Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "orbitron", name: "Orbitron", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "oswald", name: "Oswald", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "outfit", name: "Outfit", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "overpass", name: "Overpass", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "pacifico", name: "Pacifico", cat: "handwriting", weights: [400] },
  { pkg: "passion-one", name: "Passion One", cat: "display", weights: [400, 700] },
  { pkg: "patrick-hand", name: "Patrick Hand", cat: "handwriting", weights: [400] },
  { pkg: "playfair-display", name: "Playfair Display", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "playfair-display-sc", name: "Playfair Display SC", cat: "serif", weights: [400, 700], italic: true },
  { pkg: "plus-jakarta-sans", name: "Plus Jakarta Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "poetsen-one", name: "Poetsen One", cat: "display", weights: [400] },
  { pkg: "poppins", name: "Poppins", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "press-start-2p", name: "Press Start 2P", cat: "display", weights: [400] },
  { pkg: "prompt", name: "Prompt", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "pt-sans", name: "PT Sans", cat: "sans-serif", weights: [400, 700], italic: true },
  { pkg: "pt-serif", name: "PT Serif", cat: "serif", weights: [400, 700], italic: true },
  { pkg: "public-sans", name: "Public Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "quicksand", name: "Quicksand", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "rajdhani", name: "Rajdhani", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "raleway", name: "Raleway", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "red-hat-display", name: "Red Hat Display", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "righteous", name: "Righteous", cat: "display", weights: [400] },
  { pkg: "roboto", name: "Roboto", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "roboto-mono", name: "Roboto Mono", cat: "monospace", weights: [400, 600, 700], italic: true },
  { pkg: "roboto-slab", name: "Roboto Slab", cat: "serif", weights: [400, 600, 700] },
  { pkg: "rowdies", name: "Rowdies", cat: "display", weights: [400, 700] },
  { pkg: "rubik", name: "Rubik", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "sacramento", name: "Sacramento", cat: "handwriting", weights: [400] },
  { pkg: "sarabun", name: "Sarabun", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "satisfy", name: "Satisfy", cat: "handwriting", weights: [400] },
  { pkg: "schibsted-grotesk", name: "Schibsted Grotesk", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "secular-one", name: "Secular One", cat: "sans-serif", weights: [400] },
  { pkg: "shadows-into-light", name: "Shadows Into Light", cat: "handwriting", weights: [400] },
  { pkg: "silkscreen", name: "Silkscreen", cat: "display", weights: [400, 700] },
  { pkg: "sora", name: "Sora", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "source-code-pro", name: "Source Code Pro", cat: "monospace", weights: [400, 600, 700], italic: true },
  { pkg: "source-sans-3", name: "Source Sans 3", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "source-serif-4", name: "Source Serif 4", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "space-grotesk", name: "Space Grotesk", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "space-mono", name: "Space Mono", cat: "monospace", weights: [400, 700], italic: true },
  { pkg: "spectral", name: "Spectral", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "staatliches", name: "Staatliches", cat: "display", weights: [400] },
  { pkg: "syncopate", name: "Syncopate", cat: "sans-serif", weights: [400, 700] },
  { pkg: "tajawal", name: "Tajawal", cat: "sans-serif", weights: [400, 500, 700] },
  { pkg: "teko", name: "Teko", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "tiro-devanagari-hindi", name: "Tiro Devanagari Hindi", cat: "serif", weights: [400], italic: true },
  { pkg: "titan-one", name: "Titan One", cat: "display", weights: [400] },
  { pkg: "ubuntu-mono", name: "Ubuntu Mono", cat: "monospace", weights: [400, 700], italic: true },
  { pkg: "unbounded", name: "Unbounded", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "urbanist", name: "Urbanist", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "vollkorn", name: "Vollkorn", cat: "serif", weights: [400, 600, 700], italic: true },
  { pkg: "vt323", name: "VT323", cat: "monospace", weights: [400] },
  { pkg: "wix-madefor-display", name: "Wix Madefor Display", cat: "sans-serif", weights: [400, 600, 700] },
  { pkg: "work-sans", name: "Work Sans", cat: "sans-serif", weights: [400, 600, 700], italic: true },
  { pkg: "yantramanav", name: "Yantramanav", cat: "sans-serif", weights: [400, 500, 700] },
  { pkg: "zilla-slab", name: "Zilla Slab", cat: "serif", weights: [400, 600, 700], italic: true },
];

const CORE = new Set(['Fraunces', 'Outfit', 'Archivo Black', 'Baloo 2', 'IBM Plex Mono']);

/* explicit lazy loaders — each family's weights become their own code-split chunks */
const LOADERS: Record<string, () => Promise<unknown>> = {
  "Abril Fatface": () => Promise.all([import('@fontsource/abril-fatface/latin-400.css')]),
  "Albert Sans": () => Promise.all([import('@fontsource/albert-sans/latin-400.css'), import('@fontsource/albert-sans/latin-600.css'), import('@fontsource/albert-sans/latin-700.css')]),
  "Alfa Slab One": () => Promise.all([import('@fontsource/alfa-slab-one/latin-400.css')]),
  "Almarai": () => Promise.all([import('@fontsource/almarai/latin-400.css'), import('@fontsource/almarai/latin-700.css')]),
  "Amatic SC": () => Promise.all([import('@fontsource/amatic-sc/latin-400.css'), import('@fontsource/amatic-sc/latin-700.css')]),
  "Anton": () => Promise.all([import('@fontsource/anton/latin-400.css')]),
  "Archivo": () => Promise.all([import('@fontsource/archivo/latin-400.css'), import('@fontsource/archivo/latin-600.css'), import('@fontsource/archivo/latin-700.css')]),
  "Archivo Narrow": () => Promise.all([import('@fontsource/archivo-narrow/latin-400.css'), import('@fontsource/archivo-narrow/latin-600.css'), import('@fontsource/archivo-narrow/latin-700.css')]),
  "Arvo": () => Promise.all([import('@fontsource/arvo/latin-400.css'), import('@fontsource/arvo/latin-700.css')]),
  "Assistant": () => Promise.all([import('@fontsource/assistant/latin-400.css'), import('@fontsource/assistant/latin-600.css'), import('@fontsource/assistant/latin-700.css')]),
  "Audiowide": () => Promise.all([import('@fontsource/audiowide/latin-400.css')]),
  "Baloo Bhai 2": () => Promise.all([import('@fontsource/baloo-bhai-2/latin-400.css'), import('@fontsource/baloo-bhai-2/latin-600.css'), import('@fontsource/baloo-bhai-2/latin-700.css')]),
  "Barlow": () => Promise.all([import('@fontsource/barlow/latin-400.css'), import('@fontsource/barlow/latin-600.css'), import('@fontsource/barlow/latin-700.css')]),
  "Be Vietnam Pro": () => Promise.all([import('@fontsource/be-vietnam-pro/latin-400.css'), import('@fontsource/be-vietnam-pro/latin-600.css'), import('@fontsource/be-vietnam-pro/latin-700.css')]),
  "Bebas Neue": () => Promise.all([import('@fontsource/bebas-neue/latin-400.css')]),
  "Big Shoulders Display": () => Promise.all([import('@fontsource/big-shoulders-display/latin-400'), import('@fontsource/big-shoulders-display/latin-600'), import('@fontsource/big-shoulders-display/latin-700')]),
  "Bitter": () => Promise.all([import('@fontsource/bitter/latin-400.css'), import('@fontsource/bitter/latin-600.css'), import('@fontsource/bitter/latin-700.css')]),
  "Black Ops One": () => Promise.all([import('@fontsource/black-ops-one/latin-400.css')]),
  "Bodoni Moda": () => Promise.all([import('@fontsource/bodoni-moda/latin-400.css'), import('@fontsource/bodoni-moda/latin-600.css'), import('@fontsource/bodoni-moda/latin-700.css')]),
  "Bricolage Grotesque": () => Promise.all([import('@fontsource/bricolage-grotesque/latin-400.css'), import('@fontsource/bricolage-grotesque/latin-600.css'), import('@fontsource/bricolage-grotesque/latin-700.css')]),
  "Bungee": () => Promise.all([import('@fontsource/bungee/latin-400.css')]),
  "Cabin": () => Promise.all([import('@fontsource/cabin/latin-400.css'), import('@fontsource/cabin/latin-600.css'), import('@fontsource/cabin/latin-700.css')]),
  "Cairo": () => Promise.all([import('@fontsource/cairo/latin-400.css'), import('@fontsource/cairo/latin-600.css'), import('@fontsource/cairo/latin-700.css')]),
  "Cardo": () => Promise.all([import('@fontsource/cardo/latin-400.css'), import('@fontsource/cardo/latin-700.css')]),
  "Caveat": () => Promise.all([import('@fontsource/caveat/latin-400.css'), import('@fontsource/caveat/latin-600.css'), import('@fontsource/caveat/latin-700.css')]),
  "Chewy": () => Promise.all([import('@fontsource/chewy/latin-400.css')]),
  "Chivo": () => Promise.all([import('@fontsource/chivo/latin-400.css'), import('@fontsource/chivo/latin-600.css'), import('@fontsource/chivo/latin-700.css')]),
  "Chivo Mono": () => Promise.all([import('@fontsource/chivo-mono/latin-400.css'), import('@fontsource/chivo-mono/latin-600.css'), import('@fontsource/chivo-mono/latin-700.css')]),
  "Comfortaa": () => Promise.all([import('@fontsource/comfortaa/latin-400.css'), import('@fontsource/comfortaa/latin-600.css'), import('@fontsource/comfortaa/latin-700.css')]),
  "Commissioner": () => Promise.all([import('@fontsource/commissioner/latin-400.css'), import('@fontsource/commissioner/latin-600.css'), import('@fontsource/commissioner/latin-700.css')]),
  "Concert One": () => Promise.all([import('@fontsource/concert-one/latin-400.css')]),
  "Cormorant Garamond": () => Promise.all([import('@fontsource/cormorant-garamond/latin-400.css'), import('@fontsource/cormorant-garamond/latin-600.css'), import('@fontsource/cormorant-garamond/latin-700.css')]),
  "Courier Prime": () => Promise.all([import('@fontsource/courier-prime/latin-400.css'), import('@fontsource/courier-prime/latin-700.css')]),
  "Crimson Pro": () => Promise.all([import('@fontsource/crimson-pro/latin-400.css'), import('@fontsource/crimson-pro/latin-600.css'), import('@fontsource/crimson-pro/latin-700.css')]),
  "Crimson Text": () => Promise.all([import('@fontsource/crimson-text/latin-400.css'), import('@fontsource/crimson-text/latin-600.css'), import('@fontsource/crimson-text/latin-700.css')]),
  "Dancing Script": () => Promise.all([import('@fontsource/dancing-script/latin-400.css'), import('@fontsource/dancing-script/latin-600.css'), import('@fontsource/dancing-script/latin-700.css')]),
  "DM Mono": () => Promise.all([import('@fontsource/dm-mono/latin-400.css'), import('@fontsource/dm-mono/latin-500.css')]),
  "DM Sans": () => Promise.all([import('@fontsource/dm-sans/latin-400.css'), import('@fontsource/dm-sans/latin-600.css'), import('@fontsource/dm-sans/latin-700.css')]),
  "DM Serif Display": () => Promise.all([import('@fontsource/dm-serif-display/latin-400.css')]),
  "Domine": () => Promise.all([import('@fontsource/domine/latin-400.css'), import('@fontsource/domine/latin-600.css'), import('@fontsource/domine/latin-700.css')]),
  "EB Garamond": () => Promise.all([import('@fontsource/eb-garamond/latin-400.css'), import('@fontsource/eb-garamond/latin-600.css'), import('@fontsource/eb-garamond/latin-700.css')]),
  "Exo 2": () => Promise.all([import('@fontsource/exo-2/latin-400.css'), import('@fontsource/exo-2/latin-600.css'), import('@fontsource/exo-2/latin-700.css')]),
  "Familjen Grotesk": () => Promise.all([import('@fontsource/familjen-grotesk/latin-400.css'), import('@fontsource/familjen-grotesk/latin-600.css'), import('@fontsource/familjen-grotesk/latin-700.css')]),
  "Figtree": () => Promise.all([import('@fontsource/figtree/latin-400.css'), import('@fontsource/figtree/latin-600.css'), import('@fontsource/figtree/latin-700.css')]),
  "Fira Code": () => Promise.all([import('@fontsource/fira-code/latin-400.css'), import('@fontsource/fira-code/latin-600.css'), import('@fontsource/fira-code/latin-700.css')]),
  "Frank Ruhl Libre": () => Promise.all([import('@fontsource/frank-ruhl-libre/latin-400.css'), import('@fontsource/frank-ruhl-libre/latin-600.css'), import('@fontsource/frank-ruhl-libre/latin-700.css')]),
  "Fredoka": () => Promise.all([import('@fontsource/fredoka/latin-400.css'), import('@fontsource/fredoka/latin-600.css'), import('@fontsource/fredoka/latin-700.css')]),
  "Gabarito": () => Promise.all([import('@fontsource/gabarito/latin-400.css'), import('@fontsource/gabarito/latin-600.css'), import('@fontsource/gabarito/latin-700.css')]),
  "Geist": () => Promise.all([import('@fontsource/geist/latin-400.css'), import('@fontsource/geist/latin-600.css'), import('@fontsource/geist/latin-700.css')]),
  "Geist Mono": () => Promise.all([import('@fontsource/geist-mono/latin-400.css'), import('@fontsource/geist-mono/latin-600.css'), import('@fontsource/geist-mono/latin-700.css')]),
  "Gloock": () => Promise.all([import('@fontsource/gloock/latin-400.css')]),
  "Gochi Hand": () => Promise.all([import('@fontsource/gochi-hand/latin-400.css')]),
  "Golos Text": () => Promise.all([import('@fontsource/golos-text/latin-400.css'), import('@fontsource/golos-text/latin-600.css'), import('@fontsource/golos-text/latin-700.css')]),
  "Great Vibes": () => Promise.all([import('@fontsource/great-vibes/latin-400.css')]),
  "Hanken Grotesk": () => Promise.all([import('@fontsource/hanken-grotesk/latin-400.css'), import('@fontsource/hanken-grotesk/latin-600.css'), import('@fontsource/hanken-grotesk/latin-700.css')]),
  "Hind": () => Promise.all([import('@fontsource/hind/latin-400.css'), import('@fontsource/hind/latin-600.css'), import('@fontsource/hind/latin-700.css')]),
  "Hind Siliguri": () => Promise.all([import('@fontsource/hind-siliguri/latin-400.css'), import('@fontsource/hind-siliguri/latin-600.css'), import('@fontsource/hind-siliguri/latin-700.css')]),
  "Host Grotesk": () => Promise.all([import('@fontsource/host-grotesk/latin-400.css'), import('@fontsource/host-grotesk/latin-600.css'), import('@fontsource/host-grotesk/latin-700.css')]),
  "IBM Plex Sans": () => Promise.all([import('@fontsource/ibm-plex-sans/latin-400.css'), import('@fontsource/ibm-plex-sans/latin-600.css'), import('@fontsource/ibm-plex-sans/latin-700.css')]),
  "IBM Plex Sans Condensed": () => Promise.all([import('@fontsource/ibm-plex-sans-condensed/latin-400.css'), import('@fontsource/ibm-plex-sans-condensed/latin-600.css'), import('@fontsource/ibm-plex-sans-condensed/latin-700.css')]),
  "IBM Plex Serif": () => Promise.all([import('@fontsource/ibm-plex-serif/latin-400.css'), import('@fontsource/ibm-plex-serif/latin-600.css'), import('@fontsource/ibm-plex-serif/latin-700.css')]),
  "Inclusive Sans": () => Promise.all([import('@fontsource/inclusive-sans/latin-400.css'), import('@fontsource/inclusive-sans/latin-600.css'), import('@fontsource/inclusive-sans/latin-700.css')]),
  "Inconsolata": () => Promise.all([import('@fontsource/inconsolata/latin-400.css'), import('@fontsource/inconsolata/latin-600.css'), import('@fontsource/inconsolata/latin-700.css')]),
  "Indie Flower": () => Promise.all([import('@fontsource/indie-flower/latin-400.css')]),
  "Instrument Sans": () => Promise.all([import('@fontsource/instrument-sans/latin-400.css'), import('@fontsource/instrument-sans/latin-600.css'), import('@fontsource/instrument-sans/latin-700.css')]),
  "Instrument Serif": () => Promise.all([import('@fontsource/instrument-serif/latin-400.css')]),
  "Inter": () => Promise.all([import('@fontsource/inter/latin-400.css'), import('@fontsource/inter/latin-600.css'), import('@fontsource/inter/latin-700.css')]),
  "JetBrains Mono": () => Promise.all([import('@fontsource/jetbrains-mono/latin-400.css'), import('@fontsource/jetbrains-mono/latin-600.css'), import('@fontsource/jetbrains-mono/latin-700.css')]),
  "Josefin Sans": () => Promise.all([import('@fontsource/josefin-sans/latin-400.css'), import('@fontsource/josefin-sans/latin-600.css'), import('@fontsource/josefin-sans/latin-700.css')]),
  "Jost": () => Promise.all([import('@fontsource/jost/latin-400.css'), import('@fontsource/jost/latin-600.css'), import('@fontsource/jost/latin-700.css')]),
  "Kalam": () => Promise.all([import('@fontsource/kalam/latin-400.css'), import('@fontsource/kalam/latin-700.css')]),
  "Kanit": () => Promise.all([import('@fontsource/kanit/latin-400.css'), import('@fontsource/kanit/latin-600.css'), import('@fontsource/kanit/latin-700.css')]),
  "Karla": () => Promise.all([import('@fontsource/karla/latin-400.css'), import('@fontsource/karla/latin-600.css'), import('@fontsource/karla/latin-700.css')]),
  "Khand": () => Promise.all([import('@fontsource/khand/latin-400.css'), import('@fontsource/khand/latin-600.css'), import('@fontsource/khand/latin-700.css')]),
  "Lato": () => Promise.all([import('@fontsource/lato/latin-400.css'), import('@fontsource/lato/latin-700.css')]),
  "Lexend": () => Promise.all([import('@fontsource/lexend/latin-400.css'), import('@fontsource/lexend/latin-600.css'), import('@fontsource/lexend/latin-700.css')]),
  "Lexend Deca": () => Promise.all([import('@fontsource/lexend-deca/latin-400.css'), import('@fontsource/lexend-deca/latin-600.css'), import('@fontsource/lexend-deca/latin-700.css')]),
  "Libre Baskerville": () => Promise.all([import('@fontsource/libre-baskerville/latin-400.css'), import('@fontsource/libre-baskerville/latin-600.css'), import('@fontsource/libre-baskerville/latin-700.css')]),
  "Libre Caslon Text": () => Promise.all([import('@fontsource/libre-caslon-text/latin-400.css'), import('@fontsource/libre-caslon-text/latin-700.css')]),
  "Lilita One": () => Promise.all([import('@fontsource/lilita-one/latin-400.css')]),
  "Literata": () => Promise.all([import('@fontsource/literata/latin-400.css'), import('@fontsource/literata/latin-600.css'), import('@fontsource/literata/latin-700.css')]),
  "Lobster": () => Promise.all([import('@fontsource/lobster/latin-400.css')]),
  "Lora": () => Promise.all([import('@fontsource/lora/latin-400.css'), import('@fontsource/lora/latin-600.css'), import('@fontsource/lora/latin-700.css')]),
  "Manjari": () => Promise.all([import('@fontsource/manjari/latin-400.css'), import('@fontsource/manjari/latin-700.css')]),
  "Manrope": () => Promise.all([import('@fontsource/manrope/latin-400.css'), import('@fontsource/manrope/latin-600.css'), import('@fontsource/manrope/latin-700.css')]),
  "Martian Mono": () => Promise.all([import('@fontsource/martian-mono/latin-400.css'), import('@fontsource/martian-mono/latin-600.css'), import('@fontsource/martian-mono/latin-700.css')]),
  "Merriweather": () => Promise.all([import('@fontsource/merriweather/latin-400.css'), import('@fontsource/merriweather/latin-600.css'), import('@fontsource/merriweather/latin-700.css')]),
  "Michroma": () => Promise.all([import('@fontsource/michroma/latin-400.css')]),
  "Mitr": () => Promise.all([import('@fontsource/mitr/latin-400.css'), import('@fontsource/mitr/latin-600.css'), import('@fontsource/mitr/latin-700.css')]),
  "Montserrat": () => Promise.all([import('@fontsource/montserrat/latin-400.css'), import('@fontsource/montserrat/latin-600.css'), import('@fontsource/montserrat/latin-700.css')]),
  "Mukta": () => Promise.all([import('@fontsource/mukta/latin-400.css'), import('@fontsource/mukta/latin-600.css'), import('@fontsource/mukta/latin-700.css')]),
  "Mulish": () => Promise.all([import('@fontsource/mulish/latin-400.css'), import('@fontsource/mulish/latin-600.css'), import('@fontsource/mulish/latin-700.css')]),
  "Newsreader": () => Promise.all([import('@fontsource/newsreader/latin-400.css'), import('@fontsource/newsreader/latin-600.css'), import('@fontsource/newsreader/latin-700.css')]),
  "Noto Sans": () => Promise.all([import('@fontsource/noto-sans/latin-400.css'), import('@fontsource/noto-sans/latin-600.css'), import('@fontsource/noto-sans/latin-700.css')]),
  "Noto Sans Devanagari": () => Promise.all([import('@fontsource/noto-sans-devanagari/latin-400.css'), import('@fontsource/noto-sans-devanagari/latin-600.css'), import('@fontsource/noto-sans-devanagari/latin-700.css')]),
  "Noto Sans JP": () => Promise.all([import('@fontsource/noto-sans-jp/latin-400.css'), import('@fontsource/noto-sans-jp/latin-600.css'), import('@fontsource/noto-sans-jp/latin-700.css')]),
  "Noto Sans KR": () => Promise.all([import('@fontsource/noto-sans-kr/latin-400.css'), import('@fontsource/noto-sans-kr/latin-600.css'), import('@fontsource/noto-sans-kr/latin-700.css')]),
  "Noto Sans SC": () => Promise.all([import('@fontsource/noto-sans-sc/latin-400.css'), import('@fontsource/noto-sans-sc/latin-600.css'), import('@fontsource/noto-sans-sc/latin-700.css')]),
  "Noto Serif": () => Promise.all([import('@fontsource/noto-serif/latin-400.css'), import('@fontsource/noto-serif/latin-600.css'), import('@fontsource/noto-serif/latin-700.css')]),
  "Nunito": () => Promise.all([import('@fontsource/nunito/latin-400.css'), import('@fontsource/nunito/latin-600.css'), import('@fontsource/nunito/latin-700.css')]),
  "Nunito Sans": () => Promise.all([import('@fontsource/nunito-sans/latin-400.css'), import('@fontsource/nunito-sans/latin-600.css'), import('@fontsource/nunito-sans/latin-700.css')]),
  "Onest": () => Promise.all([import('@fontsource/onest/latin-400.css'), import('@fontsource/onest/latin-600.css'), import('@fontsource/onest/latin-700.css')]),
  "Open Sans": () => Promise.all([import('@fontsource/open-sans/latin-400.css'), import('@fontsource/open-sans/latin-600.css'), import('@fontsource/open-sans/latin-700.css')]),
  "Orbitron": () => Promise.all([import('@fontsource/orbitron/latin-400.css'), import('@fontsource/orbitron/latin-600.css'), import('@fontsource/orbitron/latin-700.css')]),
  "Oswald": () => Promise.all([import('@fontsource/oswald/latin-400.css'), import('@fontsource/oswald/latin-600.css'), import('@fontsource/oswald/latin-700.css')]),
  "Overpass": () => Promise.all([import('@fontsource/overpass/latin-400.css'), import('@fontsource/overpass/latin-600.css'), import('@fontsource/overpass/latin-700.css')]),
  "Pacifico": () => Promise.all([import('@fontsource/pacifico/latin-400.css')]),
  "Passion One": () => Promise.all([import('@fontsource/passion-one/latin-400.css'), import('@fontsource/passion-one/latin-700.css')]),
  "Patrick Hand": () => Promise.all([import('@fontsource/patrick-hand/latin-400.css')]),
  "Playfair Display": () => Promise.all([import('@fontsource/playfair-display/latin-400.css'), import('@fontsource/playfair-display/latin-600.css'), import('@fontsource/playfair-display/latin-700.css')]),
  "Playfair Display SC": () => Promise.all([import('@fontsource/playfair-display-sc/latin-400.css'), import('@fontsource/playfair-display-sc/latin-700.css')]),
  "Plus Jakarta Sans": () => Promise.all([import('@fontsource/plus-jakarta-sans/latin-400.css'), import('@fontsource/plus-jakarta-sans/latin-600.css'), import('@fontsource/plus-jakarta-sans/latin-700.css')]),
  "Poetsen One": () => Promise.all([import('@fontsource/poetsen-one/latin-400.css')]),
  "Poppins": () => Promise.all([import('@fontsource/poppins/latin-400.css'), import('@fontsource/poppins/latin-600.css'), import('@fontsource/poppins/latin-700.css')]),
  "Press Start 2P": () => Promise.all([import('@fontsource/press-start-2p/latin-400.css')]),
  "Prompt": () => Promise.all([import('@fontsource/prompt/latin-400.css'), import('@fontsource/prompt/latin-600.css'), import('@fontsource/prompt/latin-700.css')]),
  "PT Sans": () => Promise.all([import('@fontsource/pt-sans/latin-400.css'), import('@fontsource/pt-sans/latin-700.css')]),
  "PT Serif": () => Promise.all([import('@fontsource/pt-serif/latin-400.css'), import('@fontsource/pt-serif/latin-700.css')]),
  "Public Sans": () => Promise.all([import('@fontsource/public-sans/latin-400.css'), import('@fontsource/public-sans/latin-600.css'), import('@fontsource/public-sans/latin-700.css')]),
  "Quicksand": () => Promise.all([import('@fontsource/quicksand/latin-400.css'), import('@fontsource/quicksand/latin-600.css'), import('@fontsource/quicksand/latin-700.css')]),
  "Rajdhani": () => Promise.all([import('@fontsource/rajdhani/latin-400.css'), import('@fontsource/rajdhani/latin-600.css'), import('@fontsource/rajdhani/latin-700.css')]),
  "Raleway": () => Promise.all([import('@fontsource/raleway/latin-400.css'), import('@fontsource/raleway/latin-600.css'), import('@fontsource/raleway/latin-700.css')]),
  "Red Hat Display": () => Promise.all([import('@fontsource/red-hat-display/latin-400.css'), import('@fontsource/red-hat-display/latin-600.css'), import('@fontsource/red-hat-display/latin-700.css')]),
  "Righteous": () => Promise.all([import('@fontsource/righteous/latin-400.css')]),
  "Roboto": () => Promise.all([import('@fontsource/roboto/latin-400.css'), import('@fontsource/roboto/latin-600.css'), import('@fontsource/roboto/latin-700.css')]),
  "Roboto Mono": () => Promise.all([import('@fontsource/roboto-mono/latin-400.css'), import('@fontsource/roboto-mono/latin-600.css'), import('@fontsource/roboto-mono/latin-700.css')]),
  "Roboto Slab": () => Promise.all([import('@fontsource/roboto-slab/latin-400.css'), import('@fontsource/roboto-slab/latin-600.css'), import('@fontsource/roboto-slab/latin-700.css')]),
  "Rowdies": () => Promise.all([import('@fontsource/rowdies/latin-400.css'), import('@fontsource/rowdies/latin-700.css')]),
  "Rubik": () => Promise.all([import('@fontsource/rubik/latin-400.css'), import('@fontsource/rubik/latin-600.css'), import('@fontsource/rubik/latin-700.css')]),
  "Sacramento": () => Promise.all([import('@fontsource/sacramento/latin-400.css')]),
  "Sarabun": () => Promise.all([import('@fontsource/sarabun/latin-400.css'), import('@fontsource/sarabun/latin-600.css'), import('@fontsource/sarabun/latin-700.css')]),
  "Satisfy": () => Promise.all([import('@fontsource/satisfy/latin-400.css')]),
  "Schibsted Grotesk": () => Promise.all([import('@fontsource/schibsted-grotesk/latin-400.css'), import('@fontsource/schibsted-grotesk/latin-600.css'), import('@fontsource/schibsted-grotesk/latin-700.css')]),
  "Secular One": () => Promise.all([import('@fontsource/secular-one/latin-400.css')]),
  "Shadows Into Light": () => Promise.all([import('@fontsource/shadows-into-light/latin-400.css')]),
  "Silkscreen": () => Promise.all([import('@fontsource/silkscreen/latin-400.css'), import('@fontsource/silkscreen/latin-700.css')]),
  "Sora": () => Promise.all([import('@fontsource/sora/latin-400.css'), import('@fontsource/sora/latin-600.css'), import('@fontsource/sora/latin-700.css')]),
  "Source Code Pro": () => Promise.all([import('@fontsource/source-code-pro/latin-400.css'), import('@fontsource/source-code-pro/latin-600.css'), import('@fontsource/source-code-pro/latin-700.css')]),
  "Source Sans 3": () => Promise.all([import('@fontsource/source-sans-3/latin-400.css'), import('@fontsource/source-sans-3/latin-600.css'), import('@fontsource/source-sans-3/latin-700.css')]),
  "Source Serif 4": () => Promise.all([import('@fontsource/source-serif-4/latin-400.css'), import('@fontsource/source-serif-4/latin-600.css'), import('@fontsource/source-serif-4/latin-700.css')]),
  "Space Grotesk": () => Promise.all([import('@fontsource/space-grotesk/latin-400.css'), import('@fontsource/space-grotesk/latin-600.css'), import('@fontsource/space-grotesk/latin-700.css')]),
  "Space Mono": () => Promise.all([import('@fontsource/space-mono/latin-400.css'), import('@fontsource/space-mono/latin-700.css')]),
  "Spectral": () => Promise.all([import('@fontsource/spectral/latin-400.css'), import('@fontsource/spectral/latin-600.css'), import('@fontsource/spectral/latin-700.css')]),
  "Staatliches": () => Promise.all([import('@fontsource/staatliches/latin-400.css')]),
  "Syncopate": () => Promise.all([import('@fontsource/syncopate/latin-400.css'), import('@fontsource/syncopate/latin-700.css')]),
  "Tajawal": () => Promise.all([import('@fontsource/tajawal/latin-400.css'), import('@fontsource/tajawal/latin-500.css'), import('@fontsource/tajawal/latin-700.css')]),
  "Teko": () => Promise.all([import('@fontsource/teko/latin-400.css'), import('@fontsource/teko/latin-600.css'), import('@fontsource/teko/latin-700.css')]),
  "Tiro Devanagari Hindi": () => Promise.all([import('@fontsource/tiro-devanagari-hindi/latin-400.css')]),
  "Titan One": () => Promise.all([import('@fontsource/titan-one/latin-400.css')]),
  "Ubuntu Mono": () => Promise.all([import('@fontsource/ubuntu-mono/latin-400.css'), import('@fontsource/ubuntu-mono/latin-700.css')]),
  "Unbounded": () => Promise.all([import('@fontsource/unbounded/latin-400.css'), import('@fontsource/unbounded/latin-600.css'), import('@fontsource/unbounded/latin-700.css')]),
  "Urbanist": () => Promise.all([import('@fontsource/urbanist/latin-400.css'), import('@fontsource/urbanist/latin-600.css'), import('@fontsource/urbanist/latin-700.css')]),
  "Vollkorn": () => Promise.all([import('@fontsource/vollkorn/latin-400.css'), import('@fontsource/vollkorn/latin-600.css'), import('@fontsource/vollkorn/latin-700.css')]),
  "VT323": () => Promise.all([import('@fontsource/vt323/latin-400.css')]),
  "Wix Madefor Display": () => Promise.all([import('@fontsource/wix-madefor-display/latin-400.css'), import('@fontsource/wix-madefor-display/latin-600.css'), import('@fontsource/wix-madefor-display/latin-700.css')]),
  "Work Sans": () => Promise.all([import('@fontsource/work-sans/latin-400.css'), import('@fontsource/work-sans/latin-600.css'), import('@fontsource/work-sans/latin-700.css')]),
  "Yantramanav": () => Promise.all([import('@fontsource/yantramanav/latin-400.css'), import('@fontsource/yantramanav/latin-500.css'), import('@fontsource/yantramanav/latin-700.css')]),
  "Zilla Slab": () => Promise.all([import('@fontsource/zilla-slab/latin-400.css'), import('@fontsource/zilla-slab/latin-600.css'), import('@fontsource/zilla-slab/latin-700.css')]),
};

const FALLBACK: Record<FontCategory, string> = {
  serif: 'Georgia, serif',
  'sans-serif': 'system-ui, sans-serif',
  display: 'system-ui, sans-serif',
  handwriting: 'cursive',
  monospace: 'ui-monospace, monospace',
};

export function fontStack(family: string): string {
  const cat = FONT_LIBRARY.find((f) => f.name === family)?.cat || 'sans-serif';
  return `"${family}", ${FALLBACK[cat]}`;
}

const loaded = new Set<string>();
/** Load a bundled family on demand (idempotent). Core fonts resolve immediately. */
export function loadFont(family: string): Promise<void> {
  const entry = FONT_LIBRARY.find((f) => f.name === family);
  if (!entry || CORE.has(family) || loaded.has(family)) return Promise.resolve();
  const load = LOADERS[family];
  if (!load) return Promise.resolve();
  loaded.add(family);
  return load().then(() => undefined).catch(() => { loaded.delete(family); });
}

/* ------------------------------------------------------------
   Embed @font-face rules (base64 woff2) for the given families so
   exported SVG files carry their fonts. Reads the same-origin
   stylesheets Vite emitted for the Fontsource CSS.
   ------------------------------------------------------------ */
const faceCache = new Map<string, Promise<string>>();

async function toBase64(url: string): Promise<string | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const buf = await res.arrayBuffer();
    let bin = '';
    const bytes = new Uint8Array(buf);
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  } catch { return null; }
}

/**
 * @param families font families to embed
 * @param weights  only these weights are embedded (default: the ones charts use).
 *                 Each face costs ~20–40 KB base64, so keep the list tight.
 */
export function fontFaceCss(families: string[], weights: string[] = ['600', '700']): Promise<string> {
  const key = [...new Set(families)].sort().join('|') + '#' + weights.join(',');
  if (!faceCache.has(key)) {
    faceCache.set(key, (async () => {
      if (typeof document === 'undefined') return '';
      const want = new Set(families.map((f) => f.toLowerCase()));
      const WEIGHTS = new Set(weights);
      const rules: { family: string; weight: string; style: string; url: string }[] = [];
      for (const sheet of Array.from(document.styleSheets)) {
        let list: CSSRuleList;
        try { list = sheet.cssRules; } catch { continue; }
        for (const r of Array.from(list)) {
          if (!(r instanceof CSSFontFaceRule)) continue;
          const fam = r.style.getPropertyValue('font-family').replace(/["']/g, '').trim();
          if (!want.has(fam.toLowerCase())) continue;
          const weight = (r.style.getPropertyValue('font-weight') || '400').trim();
          const style = (r.style.getPropertyValue('font-style') || 'normal').trim();
          if (!WEIGHTS.has(weight) || style !== 'normal') continue;
          const src = r.style.getPropertyValue('src');
          const m = /url\(["']?([^"')]+\.woff2)["']?\)/.exec(src);
          if (!m) continue;
          const url = new URL(m[1], sheet.href || document.baseURI).href;
          if (!rules.some((x) => x.family === fam && x.weight === weight)) rules.push({ family: fam, weight, style, url });
        }
      }
      const parts = await Promise.all(rules.map(async (r) => {
        const b64 = await toBase64(r.url);
        return b64 ? `@font-face{font-family:'${r.family}';font-weight:${r.weight};font-style:${r.style};src:url(data:font/woff2;base64,${b64}) format('woff2');}` : '';
      }));
      return parts.join('');
    })());
  }
  return faceCache.get(key)!;
}
