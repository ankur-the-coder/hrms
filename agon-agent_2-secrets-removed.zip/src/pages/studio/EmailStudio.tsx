import { useState, useEffect, useMemo, useRef, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import {
  Mail, Save, Trash2, FolderOpen, Copy, Download, ExternalLink, Smartphone, Monitor, Plus, ArrowUp, ArrowDown,
  Type, AlignLeft, List, MousePointerClick, Minus, MoveVertical, PenLine, Megaphone, Image as ImageIcon, Users, Check, LayoutTemplate,
} from 'lucide-react';
import { api } from '../../lib/api';
import { useAssets, uid, readFileAsDataUrl, fitImage, mergeFields, esc, downloadBlob } from '../../studio/lib';
import Select from '../../shared/Select';
import { Modal, Badge, Skeleton, btnPrimary, btnGhost, inputCls, labelCls } from '../../shared/primitives';
import type { OrgPerson } from '../org/orgData';

/* ============================================================
   Professional Email Generator
   Editable block templates → bulletproof HTML (600px tables,
   inline styles, MSO/VML button fallbacks, dark-mode meta) that
   renders consistently in Gmail, Outlook (desktop & web), Apple
   Mail and mobile clients. Copy rich content straight into a
   compose window, download .html / .eml, or open a compose link.
   ============================================================ */

type BlockType = 'header' | 'heading' | 'paragraph' | 'bullets' | 'button' | 'divider' | 'spacer' | 'signature' | 'callout' | 'image';
interface Block { id: string; type: BlockType; text?: string; items?: string[]; href?: string; label?: string; align?: 'left' | 'center'; src?: string; alt?: string; height?: number }
interface Brand { accent: string; company: string; logo: string | null; footer: string; address: string; font: 'sans' | 'serif' }
interface Email { name: string; subject: string; preheader: string; to: string; blocks: Block[]; brand: Brand }

const B = (type: BlockType, p: Partial<Block> = {}): Block => ({ id: uid(), type, ...p });
const BRAND: Brand = { accent: '#0d7a54', company: 'Aviary Technologies', logo: null, footer: 'You are receiving this because you are part of {{company}}. Questions? Reply to this email or write to people@aviary.io.', address: 'Prestige Tech Park, Tower B, Bengaluru 560103, India', font: 'sans' };
const SIG = () => B('signature', { text: '{{manager}}\nHead of People · {{company}}\npeople@aviary.io · aviary.io' });

const TEMPLATES: { key: string; name: string; desc: string; build: () => Email }[] = [
  { key: 'offer', name: 'Offer letter', desc: 'Formal offer with CTA to accept.', build: () => ({ name: 'Offer letter', subject: 'Your offer from {{company}} — {{role}}', preheader: 'We would love for you to join us.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Welcome aboard, {{first_name}} 🎉' }),
    B('paragraph', { text: 'We are delighted to offer you the position of <b>{{role}}</b> in our {{dept}} team, based in {{location}}. Your start date is {{joined}} and you will report to {{manager}}.' }),
    B('callout', { text: 'Annual compensation: ₹{{salary}} · Benefits: health cover, learning budget, hybrid work.' }),
    B('paragraph', { text: 'Please review the attached letter and accept your offer within five working days. We cannot wait to build with you.' }),
    B('button', { label: 'Accept offer', href: 'https://aviary.io/offers/{{employee_no}}', align: 'center' }), B('divider'), SIG(),
  ] }) },
  { key: 'welcome', name: 'Welcome & onboarding', desc: 'Day-one checklist for new joiners.', build: () => ({ name: 'Welcome & onboarding', subject: 'Welcome to {{company}}, {{first_name}}! Your first week', preheader: 'Everything you need for day one.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Your first week at {{company}}' }),
    B('paragraph', { text: 'Hi {{first_name}}, we are thrilled you are joining the {{dept}} team on {{joined}}. Here is what to expect.' }),
    B('bullets', { items: ['Day 1 · 9:30 AM — orientation with People Ops at {{location}}', 'Day 1 · afternoon — laptop setup & accounts', 'Day 2 — meet your buddy and team lead {{manager}}', 'Week 1 — complete your profile in People OS'] }),
    B('button', { label: 'Complete your profile', href: 'https://aviary.io/onboarding', align: 'left' }),
    B('paragraph', { text: 'Reply to this email if anything is unclear — we are here to help.' }), B('divider'), SIG(),
  ] }) },
  { key: 'interview', name: 'Interview invitation', desc: 'Schedule with details & agenda.', build: () => ({ name: 'Interview invitation', subject: 'Interview with {{company}} — {{role}}', preheader: 'Details for your upcoming conversation.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Let’s talk, {{first_name}}' }),
    B('paragraph', { text: 'Thank you for applying for the <b>{{role}}</b> role. We would like to invite you to an interview on <b>{{date}}</b>.' }),
    B('callout', { text: 'Format: 60 minutes · Panel: {{manager}} and two team members · Location: video call (link below) or {{location}}.' }),
    B('button', { label: 'Confirm your slot', href: 'https://aviary.io/interviews', align: 'center' }),
    B('paragraph', { text: 'Please let us know if you need any accommodation. We look forward to meeting you.' }), B('divider'), SIG(),
  ] }) },
  { key: 'appraisal', name: 'Appraisal letter', desc: 'Annual review outcome.', build: () => ({ name: 'Appraisal letter', subject: 'Your {{date}} performance review', preheader: 'Thank you for a strong year.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Thank you for an outstanding year' }),
    B('paragraph', { text: 'Dear {{first_name}}, following your annual review as {{role}}, we are pleased to share the outcome.' }),
    B('callout', { text: 'Revised annual compensation: ₹{{salary}}, effective {{date}}.' }),
    B('bullets', { items: ['Consistent delivery on {{dept}} priorities', 'Mentorship and knowledge sharing across the team', 'Living the {{company}} values'] }),
    B('paragraph', { text: 'Your manager {{manager}} will walk you through the details in your 1:1. Congratulations!' }), B('divider'), SIG(),
  ] }) },
  { key: 'policy', name: 'Policy update', desc: 'Announcement to all staff.', build: () => ({ name: 'Policy update', subject: 'Update: hybrid work guidelines from {{date}}', preheader: 'What changes and what stays the same.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Hybrid work guidelines · effective {{date}}' }),
    B('paragraph', { text: 'Hi team, we are refreshing how we work together across offices and home.' }),
    B('bullets', { items: ['Teams choose two anchor days per week for in-office collaboration', 'Meeting rooms bookable up to 14 days ahead', 'Remote-first teams keep their current arrangement'] }),
    B('button', { label: 'Read the full policy', href: 'https://aviary.io/policies/hybrid', align: 'left' }), B('divider'), SIG(),
  ] }) },
  { key: 'leave', name: 'Leave approval', desc: 'Confirmation with dates.', build: () => ({ name: 'Leave approval', subject: 'Leave approved · {{date}}', preheader: 'Enjoy your time off.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Your leave is approved ✅' }),
    B('paragraph', { text: 'Hi {{first_name}}, your leave request has been approved by {{manager}}.' }),
    B('callout', { text: 'Dates: {{date}} · Type: Earned leave · Balance after: 12 days' }),
    B('paragraph', { text: 'Please set your out-of-office and hand over open items before you go. Have a restful break!' }), B('divider'), SIG(),
  ] }) },
  { key: 'payroll', name: 'Payslip notice', desc: 'Monthly payroll processed.', build: () => ({ name: 'Payslip notice', subject: 'Your payslip for {{date}} is ready', preheader: 'Salary credited · payslip available in People OS.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Payslip ready' }),
    B('paragraph', { text: 'Hi {{first_name}}, payroll for {{date}} has been processed and your salary has been credited.' }),
    B('button', { label: 'View payslip', href: 'https://aviary.io/payroll', align: 'center' }),
    B('paragraph', { text: 'For queries on deductions or reimbursements, raise a ticket with Finance within 7 days.' }), B('divider'), SIG(),
  ] }) },
  { key: 'reminder', name: 'Meeting reminder', desc: 'Short nudge with agenda.', build: () => ({ name: 'Meeting reminder', subject: 'Reminder: Quarterly town hall · {{date}}', preheader: 'Tomorrow at 4:00 PM IST.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Town hall tomorrow' }),
    B('paragraph', { text: 'A quick reminder that our quarterly town hall is on {{date}} at 4:00 PM IST, in the {{location}} auditorium and on livestream.' }),
    B('bullets', { items: ['Quarter in review', 'Roadmap and hiring plan', 'Open Q&A with leadership'] }),
    B('button', { label: 'Add to calendar', href: 'https://aviary.io/events/town-hall', align: 'left' }), SIG(),
  ] }) },
  { key: 'birthday', name: 'Birthday wishes', desc: 'Warm celebratory note.', build: () => ({ name: 'Birthday wishes', subject: 'Happy birthday, {{first_name}}! 🎂', preheader: 'From all of us at {{company}}.', to: '', brand: { ...BRAND, accent: '#c9932b' }, blocks: [
    B('header'), B('heading', { text: 'Happy birthday, {{first_name}}!' }),
    B('paragraph', { text: 'Wishing you a wonderful year ahead. Thank you for everything you bring to the {{dept}} team — today is all about you.' }),
    B('callout', { text: 'Treat yourself: your birthday leave is pre-approved for any day this month.' }), SIG(),
  ] }) },
  { key: 'farewell', name: 'Farewell', desc: 'Graceful goodbye & handover.', build: () => ({ name: 'Farewell', subject: 'Thank you, {{first_name}}', preheader: 'Wishing you the very best.', to: '', brand: BRAND, blocks: [
    B('header'), B('heading', { text: 'Thank you for everything' }),
    B('paragraph', { text: 'Dear {{first_name}}, as your time as {{role}} at {{company}} comes to a close, we want to thank you for your contribution to the {{dept}} team.' }),
    B('bullets', { items: ['Your last working day is {{date}}', 'Exit conversation with {{manager}} this week', 'Return your ID card and laptop to IT'] }),
    B('paragraph', { text: 'Stay in touch — you will always be part of the Aviary story.' }), B('divider'), SIG(),
  ] }) },
];

const MERGE_FIELDS = ['first_name', 'employee_name', 'role', 'dept', 'location', 'email', 'employee_no', 'joined', 'salary', 'company', 'date', 'manager'];
const fmtDate = (d?: string | null) => (d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : '');
const inlineMd = (s: string) => esc(s).replace(/&lt;b&gt;(.*?)&lt;\/b&gt;/g, '<b>$1</b>').replace(/&lt;i&gt;(.*?)&lt;\/i&gt;/g, '<i>$1</i>').replace(/\n/g, '<br>');
const stripTags = (s: string) => s.replace(/<\/?[bi]>/g, '');

/* ---------- bulletproof HTML renderer ---------- */
export function toHtml(e: Email, T: (s: string) => string): string {
  const font = e.brand.font === 'serif' ? "Georgia, 'Times New Roman', serif" : "Arial, Helvetica, 'Segoe UI', sans-serif";
  const acc = e.brand.accent;
  const row = (inner: string, pad = '0 32px 16px') => `<tr><td style="padding:${pad};font-family:${font};">${inner}</td></tr>`;
  const body = e.blocks.map((b) => {
    switch (b.type) {
      case 'header': return `<tr><td style="padding:28px 32px 8px;font-family:${font};">${e.brand.logo ? `<img src="${e.brand.logo}" alt="${esc(e.brand.company)}" height="36" style="height:36px;display:block;border:0;">` : `<table role="presentation" cellpadding="0" cellspacing="0"><tr><td style="width:34px;height:34px;border-radius:9px;background:${acc};text-align:center;vertical-align:middle;color:#ffffff;font-weight:bold;font-size:16px;font-family:${font};">${esc(e.brand.company.charAt(0))}</td><td style="padding-left:10px;font-size:16px;font-weight:bold;color:#1b1b1f;font-family:${font};">${esc(T(e.brand.company))}</td></tr></table>`}</td></tr>`;
      case 'heading': return row(`<h1 style="margin:8px 0 0;font-size:24px;line-height:1.25;color:#1b1b1f;font-weight:bold;">${inlineMd(T(b.text || ''))}</h1>`, '8px 32px 12px');
      case 'paragraph': return row(`<p style="margin:0;font-size:15px;line-height:1.6;color:#2c352f;">${inlineMd(T(b.text || ''))}</p>`);
      case 'bullets': return row(`<table role="presentation" cellpadding="0" cellspacing="0" width="100%">${(b.items || []).map((it) => `<tr><td valign="top" style="width:18px;color:${acc};font-size:15px;line-height:1.6;font-family:${font};">•</td><td style="font-size:15px;line-height:1.6;color:#2c352f;padding-bottom:4px;font-family:${font};">${inlineMd(T(it))}</td></tr>`).join('')}</table>`);
      case 'callout': return row(`<table role="presentation" cellpadding="0" cellspacing="0" width="100%"><tr><td style="background:#f2f5f2;border-left:4px solid ${acc};padding:14px 16px;border-radius:6px;font-size:14px;line-height:1.55;color:#1b1b1f;font-family:${font};">${inlineMd(T(b.text || ''))}</td></tr></table>`);
      case 'button': {
        const href = esc(T(b.href || '#')), label = esc(T(b.label || 'Open'));
        return row(`<table role="presentation" cellpadding="0" cellspacing="0" align="${b.align === 'center' ? 'center' : 'left'}"><tr><td>
<!--[if mso]><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="${href}" style="height:44px;v-text-anchor:middle;width:220px;" arcsize="30%" strokecolor="${acc}" fillcolor="${acc}"><w:anchorlock/><center style="color:#ffffff;font-family:Arial,sans-serif;font-size:15px;font-weight:bold;">${label}</center></v:roundrect><![endif]-->
<!--[if !mso]><!--><a href="${href}" target="_blank" style="background:${acc};border-radius:12px;color:#ffffff;display:inline-block;font-family:${font};font-size:15px;font-weight:bold;line-height:44px;text-align:center;text-decoration:none;width:220px;-webkit-text-size-adjust:none;mso-hide:all;">${label}</a><!--<![endif]-->
</td></tr></table>`, '4px 32px 20px');
      }
      case 'divider': return row(`<table role="presentation" cellpadding="0" cellspacing="0" width="100%"><tr><td style="border-top:1px solid #e3e7e3;font-size:0;line-height:0;">&nbsp;</td></tr></table>`, '4px 32px 16px');
      case 'spacer': return `<tr><td style="height:${b.height || 24}px;font-size:0;line-height:0;">&nbsp;</td></tr>`;
      case 'image': return b.src ? row(`<img src="${b.src}" alt="${esc(b.alt || '')}" width="536" style="width:100%;max-width:536px;display:block;border:0;border-radius:10px;">`) : '';
      case 'signature': {
        const lines = T(b.text || '').split('\n');
        return row(`<p style="margin:0;font-size:14px;line-height:1.55;color:#2c352f;"><b style="color:#1b1b1f;">${esc(lines[0] || '')}</b>${lines.slice(1).map((l) => `<br><span style="color:#6b746e;">${esc(l)}</span>`).join('')}</p>`, '4px 32px 24px');
      }
      default: return '';
    }
  }).join('\n');
  const pre = esc(T(e.preheader || ''));
  return `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="x-apple-disable-message-reformatting">
<meta name="color-scheme" content="light"><meta name="supported-color-schemes" content="light">
<title>${esc(T(e.subject))}</title>
<!--[if mso]><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml>
<style>table,td{border-collapse:collapse;mso-table-lspace:0pt;mso-table-rspace:0pt;} body,td,p,a{font-family:Arial,sans-serif !important;}</style><![endif]-->
<style>
body{margin:0;padding:0;background:#f3f5f2;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;}
img{border:0;line-height:100%;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;}
a{color:${acc};}
@media only screen and (max-width:620px){.wrap{width:100% !important;} .pad{padding-left:20px !important;padding-right:20px !important;}}
</style>
</head>
<body style="margin:0;padding:0;background:#f3f5f2;">
<div style="display:none;font-size:1px;color:#f3f5f2;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">${pre}${'&nbsp;&zwnj;'.repeat(30)}</div>
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#f3f5f2;">
<tr><td align="center" style="padding:28px 12px;">
<!--[if mso]><table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0"><tr><td><![endif]-->
<table role="presentation" class="wrap" cellpadding="0" cellspacing="0" border="0" width="600" style="width:600px;max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;">
<tr><td style="height:6px;background:${acc};font-size:0;line-height:0;">&nbsp;</td></tr>
${body}
</table>
<table role="presentation" class="wrap" cellpadding="0" cellspacing="0" border="0" width="600" style="width:600px;max-width:600px;">
<tr><td style="padding:18px 32px 0;font-family:${font};font-size:12px;line-height:1.55;color:#8a938d;text-align:center;">${inlineMd(T(e.brand.footer))}<br>${esc(T(e.brand.address))}</td></tr>
</table>
<!--[if mso]></td></tr></table><![endif]-->
</td></tr></table>
</body></html>`;
}
export function toText(e: Email, T: (s: string) => string): string {
  const out: string[] = [];
  e.blocks.forEach((b) => {
    if (b.type === 'heading') out.push(stripTags(T(b.text || '')).toUpperCase(), '');
    else if (b.type === 'paragraph' || b.type === 'callout') out.push(stripTags(T(b.text || '')), '');
    else if (b.type === 'bullets') out.push(...(b.items || []).map((i) => `• ${stripTags(T(i))}`), '');
    else if (b.type === 'button') out.push(`${T(b.label || 'Open')}: ${T(b.href || '')}`, '');
    else if (b.type === 'divider') out.push('— — —', '');
    else if (b.type === 'signature') out.push(T(b.text || ''));
  });
  out.push('', T(e.brand.footer).replace(/<[^>]+>/g, ''), T(e.brand.address));
  return out.join('\n');
}

const BLOCK_META: Record<BlockType, { label: string; icon: typeof Type }> = {
  header: { label: 'Brand header', icon: ImageIcon }, heading: { label: 'Heading', icon: Type }, paragraph: { label: 'Paragraph', icon: AlignLeft },
  bullets: { label: 'Bullet list', icon: List }, button: { label: 'Button', icon: MousePointerClick }, callout: { label: 'Callout', icon: Megaphone },
  divider: { label: 'Divider', icon: Minus }, spacer: { label: 'Spacer', icon: MoveVertical }, signature: { label: 'Signature', icon: PenLine }, image: { label: 'Image', icon: ImageIcon },
};

/* ============================================================ */
export default function EmailStudio() {
  const [email, setEmail] = useState<Email>(() => TEMPLATES[0].build());
  const [selBlock, setSelBlock] = useState<string | null>(null);
  const [device, setDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [tab, setTab] = useState<'blocks' | 'templates' | 'saved'>('blocks');
  const [people, setPeople] = useState<OrgPerson[]>([]);
  const [merge, setMerge] = useState<Record<string, string>>({ company: 'Aviary Technologies', date: fmtDate(new Date().toISOString()), manager: 'Ananya Rao', first_name: 'Asha', employee_name: 'Asha Verma', role: 'Senior Software Engineer', dept: 'Engineering', location: 'Bengaluru HQ', email: 'asha.verma@aviary.io', employee_no: 'AV-1042', joined: fmtDate('2026-10-01'), salary: '24,00,000' });
  const [toast, setToast] = useState('');
  const [savedId, setSavedId] = useState<number | null>(null);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState('');
  const [codeOpen, setCodeOpen] = useState(false);
  const assets = useAssets<Email>('email');
  const addRef = useRef<HTMLDivElement>(null);
  const [addOpen, setAddOpen] = useState(false);
  const notify = (m: string) => { setToast(m); setTimeout(() => setToast(''), 2400); };

  useEffect(() => { api<OrgPerson[]>('organization?resource=people').then(setPeople).catch(() => setPeople([])); }, []);
  useEffect(() => {
    const onDown = (e: MouseEvent) => { if (addRef.current && !addRef.current.contains(e.target as Node)) setAddOpen(false); };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, []);

  const T = (s: string) => mergeFields(s, merge);
  const html = useMemo(() => toHtml(email, T), [email, merge]); // eslint-disable-line react-hooks/exhaustive-deps
  const text = useMemo(() => toText(email, T), [email, merge]); // eslint-disable-line react-hooks/exhaustive-deps
  const subject = T(email.subject);

  const setE = (p: Partial<Email>) => setEmail((e) => ({ ...e, ...p }));
  const setBrand = (p: Partial<Brand>) => setEmail((e) => ({ ...e, brand: { ...e.brand, ...p } }));
  const patchBlock = (id: string, p: Partial<Block>) => setEmail((e) => ({ ...e, blocks: e.blocks.map((b) => (b.id === id ? { ...b, ...p } : b)) }));
  const removeBlock = (id: string) => { setEmail((e) => ({ ...e, blocks: e.blocks.filter((b) => b.id !== id) })); setSelBlock(null); };
  const moveBlock = (id: string, dir: 1 | -1) => setEmail((e) => { const i = e.blocks.findIndex((b) => b.id === id), j = i + dir; if (i < 0 || j < 0 || j >= e.blocks.length) return e; const arr = [...e.blocks]; [arr[i], arr[j]] = [arr[j], arr[i]]; return { ...e, blocks: arr }; });
  const addBlock = (type: BlockType) => {
    const nb: Block = type === 'heading' ? B(type, { text: 'New heading' }) : type === 'paragraph' ? B(type, { text: 'Write your paragraph here. Use {{first_name}} and other merge fields to personalise.' })
      : type === 'bullets' ? B(type, { items: ['First point', 'Second point'] }) : type === 'button' ? B(type, { label: 'Call to action', href: 'https://aviary.io', align: 'center' })
      : type === 'callout' ? B(type, { text: 'Key detail everyone should notice.' }) : type === 'spacer' ? B(type, { height: 24 }) : type === 'signature' ? SIG() : B(type);
    setEmail((e) => { const i = selBlock ? e.blocks.findIndex((b) => b.id === selBlock) : -1; const arr = [...e.blocks]; arr.splice(i >= 0 ? i + 1 : arr.length, 0, nb); return { ...e, blocks: arr }; });
    setSelBlock(nb.id); setAddOpen(false);
  };

  const applyPerson = (p: OrgPerson) => setMerge((m) => ({ ...m, employee_name: p.full_name, first_name: p.full_name.split(' ')[0], role: p.role, dept: p.dept, location: p.location, email: p.email, employee_no: `AV-${1000 + p.id}`, joined: fmtDate(p.joined), salary: Number(p.salary).toLocaleString('en-IN') }));

  /* ---------- output actions ---------- */
  const copyRich = async () => {
    try {
      // rich clipboard: paste straight into Gmail / Outlook compose with the design intact
      const bodyOnly = html.slice(html.indexOf('<body'), html.indexOf('</body>') + 7);
      const item = new ClipboardItem({ 'text/html': new Blob([bodyOnly], { type: 'text/html' }), 'text/plain': new Blob([text], { type: 'text/plain' }) });
      await navigator.clipboard.write([item]);
      notify('Copied — paste into a Gmail or Outlook compose window');
    } catch { await navigator.clipboard.writeText(html); notify('Copied HTML source'); }
  };
  const copyHtml = async () => { await navigator.clipboard.writeText(html); notify('HTML copied'); };
  const downloadHtml = () => downloadBlob(`${email.name.toLowerCase().replace(/\s+/g, '-')}.html`, new Blob([html], { type: 'text/html' }));
  const downloadEml = () => {
    const b64 = (s: string) => btoa(unescape(encodeURIComponent(s))).replace(/(.{76})/g, '$1\r\n');
    const boundary = `----=_Aviary_${uid()}`;
    const eml = [
      `From: People Operations <people@aviary.io>`, `To: ${email.to || T(merge.email || '')}`, `Subject: =?UTF-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,
      `Date: ${new Date().toUTCString()}`, `X-Unsent: 1`, `MIME-Version: 1.0`, `Content-Type: multipart/alternative; boundary="${boundary}"`, '',
      `--${boundary}`, `Content-Type: text/plain; charset=UTF-8`, `Content-Transfer-Encoding: base64`, '', b64(text), '',
      `--${boundary}`, `Content-Type: text/html; charset=UTF-8`, `Content-Transfer-Encoding: base64`, '', b64(html), '',
      `--${boundary}--`, '',
    ].join('\r\n');
    downloadBlob(`${email.name.toLowerCase().replace(/\s+/g, '-')}.eml`, new Blob([eml], { type: 'message/rfc822' }));
    notify('.eml saved — opens as a draft in Outlook / Apple Mail');
  };
  const openGmail = () => window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(email.to || merge.email || '')}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`, '_blank');
  const openOutlook = () => window.open(`https://outlook.office.com/mail/deeplink/compose?to=${encodeURIComponent(email.to || merge.email || '')}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`, '_blank');
  const openMailto = () => { window.location.href = `mailto:${encodeURIComponent(email.to || merge.email || '')}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`; };

  const saveTpl = async () => {
    try { const a = await assets.save(saveName || email.name, { ...email, name: saveName || email.name }, savedId || undefined); setSavedId(a.id); setE({ name: a.name }); setSaveOpen(false); notify('Template saved'); }
    catch (e) { notify(e instanceof Error ? e.message : 'Save failed'); }
  };

  const Field = ({ label, children }: { label: string; children: ReactNode }) => (<div><label className={labelCls}>{label}</label>{children}</div>);
  const sel = email.blocks.find((b) => b.id === selBlock) || null;

  return (
    <div className="space-y-4">
      {toast && <div className="fixed left-1/2 top-20 z-[80] -translate-x-1/2 rounded-full bg-ink px-5 py-2.5 font-body text-[13px] font-bold text-paper shadow-xl">{toast}</div>}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-body text-[12px] font-bold uppercase tracking-[0.18em] text-primary">Studio · Emails</p>
          <h1 className="mt-1 flex items-center gap-2.5 font-display text-2xl font-semibold tracking-tight text-ink">
            <span className="tk-raise-sm flex h-9 w-9 items-center justify-center rounded-xl text-primary"><Mail size={17} /></span>
            Professional email generator
          </h1>
          <p className="mt-1 font-body text-[13px] text-muted">Editable templates that render cleanly in Gmail, Outlook and mobile — copy, download or open in your mail client.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={() => { setSaveName(email.name); setSaveOpen(true); }} className={btnGhost + ' !py-2 text-[12px]'}><Save size={13} /> {savedId ? 'Save' : 'Save template'}</button>
          <button onClick={copyRich} className={btnPrimary + ' !py-2 text-[12px]'}><Copy size={13} /> Copy for Gmail / Outlook</button>
        </div>
      </motion.div>

      <div className="grid gap-4 xl:grid-cols-[300px_1fr_300px]">
        {/* ---------- LEFT: blocks · templates · saved ---------- */}
        <div className="tk-card h-fit p-3 xl:sticky xl:top-20">
          <div className="tk-inset mb-3 flex gap-0.5 p-1">
            {([['blocks', 'Content', AlignLeft], ['templates', 'Templates', LayoutTemplate], ['saved', 'Saved', FolderOpen]] as const).map(([k, l, I]) => (
              <button key={k} onClick={() => setTab(k)} className={`flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 font-body text-[11px] font-bold transition ${tab === k ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}><I size={12} /> {l}</button>
            ))}
          </div>
          {tab === 'blocks' && (
            <div className="space-y-2">
              <Field label="Subject"><input value={email.subject} onChange={(e) => setE({ subject: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
              <Field label="Preheader (inbox preview line)"><input value={email.preheader} onChange={(e) => setE({ preheader: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
              <Field label="To"><input value={email.to} onChange={(e) => setE({ to: e.target.value })} placeholder={merge.email || 'recipient@company.com'} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
              <div className="flex items-center justify-between pt-1">
                <p className="font-body text-[10.5px] font-bold uppercase tracking-wider text-muted">Blocks · {email.blocks.length}</p>
                <div ref={addRef} className="relative">
                  <button onClick={() => setAddOpen(!addOpen)} className={btnPrimary + ' !px-2.5 !py-1 text-[11.5px]'}><Plus size={12} /> Add</button>
                  {addOpen && (
                    <div className="tk-pop absolute right-0 top-[calc(100%+6px)] z-40 w-48 p-1.5">
                      {(Object.keys(BLOCK_META) as BlockType[]).map((t) => { const I = BLOCK_META[t].icon; return <button key={t} onClick={() => addBlock(t)} className="flex w-full items-center gap-2 rounded-lg px-3 py-1.5 text-left font-body text-[12px] font-semibold text-ink/80 hover:bg-primary/8"><I size={12} className="text-primary" /> {BLOCK_META[t].label}</button>; })}
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-1">
                {email.blocks.map((b, i) => { const I = BLOCK_META[b.type].icon; const on = selBlock === b.id; return (
                  <div key={b.id} className={`flex items-center gap-1.5 rounded-xl px-2 py-1.5 ${on ? 'tk-inset text-primary' : 'text-ink/75 hover:text-ink'}`}>
                    <button onClick={() => setSelBlock(b.id)} className="flex min-w-0 flex-1 items-center gap-2 text-left"><I size={12} className="shrink-0" /><span className="truncate font-body text-[12px] font-bold">{BLOCK_META[b.type].label}</span><span className="truncate font-body text-[10.5px] text-muted">{stripTags(b.text || b.label || b.items?.[0] || '')}</span></button>
                    <button onClick={() => moveBlock(b.id, -1)} disabled={i === 0} className="text-muted hover:text-ink disabled:opacity-30"><ArrowUp size={11} /></button>
                    <button onClick={() => moveBlock(b.id, 1)} disabled={i === email.blocks.length - 1} className="text-muted hover:text-ink disabled:opacity-30"><ArrowDown size={11} /></button>
                    <button onClick={() => removeBlock(b.id)} className="text-muted hover:text-rose-500"><Trash2 size={11} /></button>
                  </div>
                ); })}
              </div>
            </div>
          )}
          {tab === 'templates' && (
            <div className="space-y-1.5">
              {TEMPLATES.map((t) => (
                <button key={t.key} onClick={() => { setEmail(t.build()); setSavedId(null); setSelBlock(null); }} className="tk-raise-sm w-full rounded-xl px-3 py-2.5 text-left transition hover:-translate-y-0.5">
                  <p className="font-body text-[12.5px] font-bold text-ink">{t.name}</p><p className="font-body text-[11px] text-muted">{t.desc}</p>
                </button>
              ))}
            </div>
          )}
          {tab === 'saved' && (
            <div className="space-y-2">
              {assets.loading && Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 w-full rounded-xl" />)}
              {!assets.loading && assets.items.length === 0 && <p className="py-6 text-center font-body text-[12px] text-muted">No saved templates yet.</p>}
              {assets.items.map((a) => (
                <div key={a.id} className={`tk-raise-sm flex items-center gap-2 rounded-xl px-3 py-2 ${savedId === a.id ? 'ring-2 ring-(--t-accent)/50' : ''}`}>
                  <button onClick={() => { setEmail({ ...TEMPLATES[0].build(), ...a.payload }); setSavedId(a.id); setSelBlock(null); notify(`Opened “${a.name}”`); }} className="min-w-0 flex-1 text-left"><span className="block truncate font-body text-[12.5px] font-bold text-ink">{a.name}</span><span className="block truncate font-body text-[10.5px] text-muted">{a.payload.subject}</span></button>
                  <button onClick={() => assets.remove(a.id).then(() => notify('Deleted'))} className="text-muted hover:text-rose-500"><Trash2 size={12} /></button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ---------- CENTER: preview ---------- */}
        <div className="min-w-0 space-y-3">
          <div className="tk-card flex flex-wrap items-center gap-2 px-3 py-2">
            <div className="tk-inset flex gap-0.5 p-1">
              {(['desktop', 'mobile'] as const).map((d) => { const I = d === 'desktop' ? Monitor : Smartphone; return <button key={d} onClick={() => setDevice(d)} className={`flex items-center gap-1 rounded-lg px-2.5 py-1 font-body text-[11.5px] font-bold capitalize transition ${device === d ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}><I size={12} /> {d}</button>; })}
            </div>
            <span className="min-w-0 flex-1 truncate font-body text-[12px] text-ink"><b>Subject:</b> {subject}</span>
            <button onClick={() => setCodeOpen(true)} className={btnGhost + ' !py-1.5 text-[11.5px]'}>HTML source</button>
          </div>
          <div className="tk-inset flex justify-center overflow-auto rounded-2xl p-4" style={{ minHeight: 560, background: 'color-mix(in srgb, var(--t-ink) 5%, var(--t-surface))' }}>
            <iframe title="Email preview" srcDoc={html} sandbox="allow-same-origin" className="rounded-xl bg-white shadow-lg transition-all" style={{ width: device === 'mobile' ? 390 : 720, height: 760, border: 0 }} />
          </div>
          <div className="tk-card flex flex-wrap items-center gap-2 p-3">
            <p className="mr-auto font-body text-[11px] font-bold uppercase tracking-wider text-muted">Send / export</p>
            <button onClick={openGmail} className={btnGhost + ' !py-1.5 text-[12px]'}><ExternalLink size={12} /> Gmail compose</button>
            <button onClick={openOutlook} className={btnGhost + ' !py-1.5 text-[12px]'}><ExternalLink size={12} /> Outlook web</button>
            <button onClick={openMailto} className={btnGhost + ' !py-1.5 text-[12px]'}><Mail size={12} /> Default mail app</button>
            <button onClick={downloadEml} className={btnGhost + ' !py-1.5 text-[12px]'}><Download size={12} /> .eml draft</button>
            <button onClick={downloadHtml} className={btnGhost + ' !py-1.5 text-[12px]'}><Download size={12} /> .html</button>
            <button onClick={copyHtml} className={btnGhost + ' !py-1.5 text-[12px]'}><Copy size={12} /> Copy HTML</button>
          </div>
          <p className="font-body text-[11px] leading-relaxed text-muted">“Copy for Gmail / Outlook” places the rendered design on your clipboard — paste it into a compose window to keep formatting. Compose links carry the plain-text version; the .eml file opens as a ready draft in Outlook desktop and Apple Mail.</p>
        </div>

        {/* ---------- RIGHT: block editor · brand · data ---------- */}
        <div className="tk-card h-fit space-y-4 p-4 xl:sticky xl:top-20">
          <div>
            <p className="mb-2 font-body text-[10.5px] font-bold uppercase tracking-wider text-muted">Selected block</p>
            {!sel && <p className="font-body text-[12px] text-muted">Select a block on the left to edit its content.</p>}
            {sel && (
              <div className="space-y-2.5">
                <Badge tone="green">{BLOCK_META[sel.type].label}</Badge>
                {(sel.type === 'heading' || sel.type === 'paragraph' || sel.type === 'callout' || sel.type === 'signature') && (
                  <Field label={sel.type === 'signature' ? 'Lines (first line is bold)' : 'Text · <b>bold</b> and <i>italic</i> allowed'}><textarea rows={sel.type === 'heading' ? 2 : 5} value={sel.text || ''} onChange={(e) => patchBlock(sel.id, { text: e.target.value })} className={inputCls + ' text-[12.5px]'} /></Field>
                )}
                {sel.type === 'bullets' && (
                  <Field label="Items (one per line)"><textarea rows={5} value={(sel.items || []).join('\n')} onChange={(e) => patchBlock(sel.id, { items: e.target.value.split('\n') })} className={inputCls + ' text-[12.5px]'} /></Field>
                )}
                {sel.type === 'button' && (<>
                  <Field label="Label"><input value={sel.label || ''} onChange={(e) => patchBlock(sel.id, { label: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
                  <Field label="Link"><input value={sel.href || ''} onChange={(e) => patchBlock(sel.id, { href: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
                  <Field label="Alignment"><Select options={[{ value: 'left', label: 'Left' }, { value: 'center', label: 'Center' }]} value={sel.align || 'center'} onChange={(v) => v && patchBlock(sel.id, { align: v as Block['align'] })} searchable={false} /></Field>
                </>)}
                {sel.type === 'spacer' && <Field label={`Height · ${sel.height || 24}px`}><input type="range" min={8} max={80} value={sel.height || 24} onChange={(e) => patchBlock(sel.id, { height: +e.target.value })} className="tk-range w-full" /></Field>}
                {sel.type === 'image' && (<>
                  <label className={btnGhost + ' w-full cursor-pointer !py-1.5 text-[12px]'}><ImageIcon size={12} /> {sel.src ? 'Replace image' : 'Upload image'}<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) patchBlock(sel.id, { src: await fitImage(await readFileAsDataUrl(f), 1200) }); e.target.value = ''; }} /></label>
                  <Field label="Alt text"><input value={sel.alt || ''} onChange={(e) => patchBlock(sel.id, { alt: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
                  <p className="font-body text-[10.5px] text-muted">Embedded images are inlined as data URLs — fine for .html/.eml; for bulk sends host the image and paste its URL instead.</p>
                </>)}
                {sel.type === 'header' && <p className="font-body text-[11.5px] text-muted">Shows your logo (or a monogram) and company name. Edit under Brand below.</p>}
                <div className="flex flex-wrap gap-1">{MERGE_FIELDS.map((f) => <button key={f} onClick={() => { if (sel.type === 'bullets') patchBlock(sel.id, { items: [...(sel.items || []), `{{${f}}}`] }); else if (sel.type === 'button') patchBlock(sel.id, { label: (sel.label || '') + ` {{${f}}}` }); else patchBlock(sel.id, { text: (sel.text || '') + ` {{${f}}}` }); }} className="tk-chip px-2 py-0.5 font-body text-[9.5px] font-bold text-ink/70 hover:text-primary">{`{{${f}}}`}</button>)}</div>
              </div>
            )}
          </div>
          <div className="border-t tk-divider pt-3">
            <p className="mb-2 font-body text-[10.5px] font-bold uppercase tracking-wider text-muted">Brand</p>
            <div className="space-y-2">
              <Field label="Accent colour"><div className="tk-inset flex items-center gap-2 rounded-xl px-2 py-1.5"><input type="color" value={email.brand.accent} onChange={(e) => setBrand({ accent: e.target.value })} className="h-6 w-8 cursor-pointer rounded border-0 bg-transparent" /><input value={email.brand.accent} onChange={(e) => setBrand({ accent: e.target.value })} className="w-full bg-transparent font-body text-[12px] text-ink outline-none" /></div></Field>
              <Field label="Company"><input value={email.brand.company} onChange={(e) => setBrand({ company: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
              <Field label="Typeface (email-safe)"><Select options={[{ value: 'sans', label: 'Arial / Helvetica (sans)' }, { value: 'serif', label: 'Georgia (serif)' }]} value={email.brand.font} onChange={(v) => v && setBrand({ font: v as Brand['font'] })} searchable={false} /></Field>
              <label className={btnGhost + ' w-full cursor-pointer !py-1.5 text-[11.5px]'}><ImageIcon size={12} /> {email.brand.logo ? 'Replace logo' : 'Upload logo'}<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setBrand({ logo: await fitImage(await readFileAsDataUrl(f), 400) }); e.target.value = ''; }} /></label>
              {email.brand.logo && <button onClick={() => setBrand({ logo: null })} className="font-body text-[11px] font-bold text-rose-500 hover:underline">Remove logo</button>}
              <Field label="Footer note"><textarea rows={2} value={email.brand.footer} onChange={(e) => setBrand({ footer: e.target.value })} className={inputCls + ' text-[12px]'} /></Field>
              <Field label="Postal address"><input value={email.brand.address} onChange={(e) => setBrand({ address: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
            </div>
          </div>
          <div className="border-t tk-divider pt-3">
            <p className="mb-2 flex items-center gap-1.5 font-body text-[10.5px] font-bold uppercase tracking-wider text-muted"><Users size={11} /> Recipient & merge data</p>
            <Select options={people.map((p) => ({ value: String(p.id), label: p.full_name, hint: p.role }))} value={null} onChange={(v) => { const p = people.find((x) => String(x.id) === v); if (p) { applyPerson(p); setE({ to: p.email }); notify(`Personalised for ${p.full_name}`); } }} placeholder={people.length ? 'Pick an employee…' : 'Loading roster…'} />
            <div className="mt-2 space-y-1.5">
              {MERGE_FIELDS.map((f) => (
                <div key={f} className="flex items-center gap-2"><span className="w-24 shrink-0 truncate font-body text-[10.5px] font-bold text-muted">{f}</span><input value={merge[f] || ''} onChange={(e) => setMerge((m) => ({ ...m, [f]: e.target.value }))} className={inputCls + ' !py-1 text-[11.5px]'} /></div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <Modal open={codeOpen} onClose={() => setCodeOpen(false)} title="HTML source" wide>
        <div className="space-y-3">
          <p className="font-body text-[12px] text-muted">Table-based layout · inline styles · VML button fallback for Outlook · 600px with mobile media query · preheader text · light colour-scheme meta.</p>
          <textarea readOnly value={html} className={inputCls + ' h-[50vh] font-mono text-[11px]'} />
          <div className="flex justify-end gap-2"><button onClick={copyHtml} className={btnGhost}><Copy size={14} /> Copy</button><button onClick={downloadHtml} className={btnPrimary}><Download size={14} /> Download .html</button></div>
        </div>
      </Modal>
      <Modal open={saveOpen} onClose={() => setSaveOpen(false)} title="Save email template">
        <div className="space-y-3">
          <Field label="Template name"><input value={saveName} onChange={(e) => setSaveName(e.target.value)} className={inputCls} autoFocus /></Field>
          <div className="flex justify-end gap-2">{savedId && <button onClick={() => { setSavedId(null); saveTpl(); }} className={btnGhost}>Save as copy</button>}<button onClick={saveTpl} disabled={!saveName.trim()} className={btnPrimary + ' disabled:opacity-50'}><Check size={14} /> Save</button></div>
        </div>
      </Modal>
    </div>
  );
}
