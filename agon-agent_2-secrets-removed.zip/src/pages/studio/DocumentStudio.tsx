import { useState, useEffect, useRef, useMemo, useCallback, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import {
  FileText, Type, Image as ImageIcon, Square, Circle, Minus, QrCode, LayoutTemplate, FolderOpen, Save, Download,
  Undo2, Redo2, Trash2, Copy, ArrowUp, ArrowDown, Grid3X3, ZoomIn, ZoomOut, Maximize2, Wand2, Lock, Unlock,
  AlignLeft, AlignCenter, AlignRight, Bold, Italic, Underline, Settings2, Users, X, Plus, Eraser, Crosshair,
} from 'lucide-react';
import QRCode from 'qrcode';
import { api } from '../../lib/api';
import { useAssets, uid, readFileAsDataUrl, fitImage, removeBackground, captureNode, canvasToPdf, downloadBlob, downloadDataUrl, mergeFields, esc, toPx, fromPx, type Unit } from '../../studio/lib';
import { FONT_LIBRARY, loadFont } from '../../theme/fonts';
import Select from '../../shared/Select';
import { Modal, Badge, Skeleton, btnPrimary, btnGhost, inputCls, labelCls } from '../../shared/primitives';
import type { OrgPerson } from '../org/orgData';

/* ============================================================
   Document Editor & Creator
   Any page size (presets or custom in px / mm / in), drag-and-resize
   elements (text · image · shapes · line · QR), templates, merge
   fields from the roster, one-click background removal for imported
   images, undo/redo, and export to PNG / JPG / PDF / SVG / JSON.
   Designs persist to hrms_studio_assets.
   ============================================================ */

type ElType = 'text' | 'image' | 'rect' | 'ellipse' | 'line' | 'qr';
interface El {
  id: string; type: ElType; x: number; y: number; w: number; h: number; rot: number; opacity: number; locked?: boolean;
  text?: string; fontFamily?: string; fontSize?: number; fontWeight?: number; italic?: boolean; underline?: boolean;
  color?: string; align?: 'left' | 'center' | 'right'; lineHeight?: number; letterSpacing?: number;
  fill?: string; stroke?: string; strokeWidth?: number; radius?: number;
  src?: string; originalSrc?: string; fit?: 'cover' | 'contain' | 'fill';
  qrValue?: string;
}
interface Doc { name: string; width: number; height: number; unit: Unit; bg: string; elements: El[] }

const PRESETS: { key: string; name: string; w: number; h: number; unit: Unit }[] = [
  { key: 'a4p', name: 'A4 portrait', w: 210, h: 297, unit: 'mm' },
  { key: 'a4l', name: 'A4 landscape', w: 297, h: 210, unit: 'mm' },
  { key: 'a3', name: 'A3 portrait', w: 297, h: 420, unit: 'mm' },
  { key: 'letter', name: 'US Letter', w: 215.9, h: 279.4, unit: 'mm' },
  { key: 'a5', name: 'A5 postcard', w: 148, h: 210, unit: 'mm' },
  { key: 'bcard', name: 'Business card', w: 85.6, h: 54, unit: 'mm' },
  { key: 'badge', name: 'Badge (CR80 portrait)', w: 54, h: 85.6, unit: 'mm' },
  { key: 'square', name: 'Social square 1080', w: 1080, h: 1080, unit: 'px' },
  { key: 'story', name: 'Story 1080×1920', w: 1080, h: 1920, unit: 'px' },
  { key: 'slide', name: 'Slide 1920×1080', w: 1920, h: 1080, unit: 'px' },
];
const FONTS = FONT_LIBRARY.map((f) => f.name);
const MERGE_FIELDS = ['employee_name', 'first_name', 'role', 'dept', 'location', 'email', 'employee_no', 'joined', 'salary', 'company', 'date', 'manager'];

const base = (type: ElType, x: number, y: number, w: number, h: number, extra: Partial<El> = {}): El => ({
  id: uid(), type, x, y, w, h, rot: 0, opacity: 1, ...extra,
});
const text = (x: number, y: number, w: number, t: string, size: number, extra: Partial<El> = {}): El =>
  base('text', x, y, w, Math.round(size * 1.35 * (t.split('\n').length)), { text: t, fontFamily: 'Outfit', fontSize: size, fontWeight: 400, color: '#1b1b1f', align: 'left', lineHeight: 1.3, ...extra });

/* ---------- templates (positions in px at 96 dpi) ---------- */
function makeDoc(name: string, preset: string, bg = '#ffffff', elements: El[] = []): Doc {
  const p = PRESETS.find((x) => x.key === preset)!;
  return { name, width: p.w, height: p.h, unit: p.unit, bg, elements };
}
const TEMPLATES: { key: string; name: string; desc: string; build: () => Doc }[] = [
  { key: 'blank', name: 'Blank A4', desc: 'Start from nothing.', build: () => makeDoc('Untitled document', 'a4p') },
  {
    key: 'offer', name: 'Offer letter', desc: 'Formal letter with merge fields.', build: () => makeDoc('Offer letter', 'a4p', '#ffffff', [
      base('rect', 0, 0, 794, 14, { fill: '#0d7a54' }),
      text(64, 54, 400, '{{company}}', 26, { fontFamily: 'Fraunces', fontWeight: 700, color: '#0d7a54' }),
      text(64, 92, 400, 'People Operations · {{date}}', 12, { color: '#6b746e' }),
      text(64, 160, 660, 'Dear {{first_name}},', 15),
      text(64, 200, 660, 'We are delighted to offer you the position of {{role}} in our {{dept}} team, based in {{location}}. Your expected start date is {{joined}}, reporting to {{manager}}.\n\nYour annual compensation will be ₹{{salary}}, paid monthly, along with the benefits described in the attached schedule. This offer is contingent on satisfactory completion of background verification.\n\nPlease sign and return this letter within five working days to confirm your acceptance. We look forward to welcoming you to {{company}}.', 13, { lineHeight: 1.55, color: '#2c352f' }),
      text(64, 640, 300, 'Warm regards,', 13),
      text(64, 700, 300, '{{manager}}', 14, { fontWeight: 700 }),
      text(64, 722, 300, 'Head of People · {{company}}', 12, { color: '#6b746e' }),
      base('line', 64, 690, 200, 2, { stroke: '#1b1b1f', strokeWidth: 1.5 }),
      text(64, 1040, 660, '{{company}} · This letter is confidential and intended solely for the addressee.', 9, { color: '#9aa39d', align: 'center' }),
    ]),
  },
  {
    key: 'certificate', name: 'Certificate', desc: 'Landscape award / completion certificate.', build: () => makeDoc('Certificate of achievement', 'a4l', '#fbf8f1', [
      base('rect', 28, 28, 1067, 738, { fill: 'transparent', stroke: '#c9932b', strokeWidth: 3, radius: 6 }),
      base('rect', 42, 42, 1039, 710, { fill: 'transparent', stroke: '#1b1b1f', strokeWidth: 1, radius: 4 }),
      text(120, 120, 880, 'CERTIFICATE OF ACHIEVEMENT', 18, { align: 'center', letterSpacing: 6, color: '#c9932b', fontWeight: 700 }),
      text(120, 175, 880, 'This certificate is proudly presented to', 14, { align: 'center', color: '#6b746e' }),
      text(120, 230, 880, '{{employee_name}}', 54, { align: 'center', fontFamily: 'Fraunces', fontWeight: 700, color: '#1b1b1f' }),
      base('line', 360, 315, 400, 2, { stroke: '#c9932b', strokeWidth: 2 }),
      text(160, 350, 800, 'for outstanding contribution as {{role}} in the {{dept}} team, demonstrating excellence, ownership and the values of {{company}}.', 15, { align: 'center', lineHeight: 1.5, color: '#2c352f' }),
      text(140, 560, 300, '{{manager}}', 14, { align: 'center', fontWeight: 700 }),
      base('line', 160, 552, 260, 2, { stroke: '#1b1b1f', strokeWidth: 1 }),
      text(140, 582, 300, 'Head of People', 11, { align: 'center', color: '#6b746e' }),
      text(680, 560, 300, '{{date}}', 14, { align: 'center', fontWeight: 700 }),
      base('line', 700, 552, 260, 2, { stroke: '#1b1b1f', strokeWidth: 1 }),
      text(680, 582, 300, 'Date of issue', 11, { align: 'center', color: '#6b746e' }),
      base('qr', 512, 600, 96, 96, { qrValue: 'https://aviary.io/verify/{{employee_no}}' }),
    ]),
  },
  {
    key: 'memo', name: 'Internal memo', desc: 'Announcement with header band.', build: () => makeDoc('Internal memo', 'letter', '#ffffff', [
      base('rect', 0, 0, 816, 150, { fill: '#1b1b1f' }),
      text(56, 46, 500, 'INTERNAL MEMO', 12, { color: '#d9f96a', letterSpacing: 4, fontWeight: 700 }),
      text(56, 76, 700, 'Hybrid work policy · effective {{date}}', 28, { color: '#ffffff', fontFamily: 'Fraunces', fontWeight: 700 }),
      text(56, 190, 700, 'To: All employees\nFrom: People Operations, {{company}}\nRe: Updated hybrid work guidelines', 13, { lineHeight: 1.6, color: '#2c352f' }),
      base('line', 56, 268, 704, 2, { stroke: '#e5e7e5', strokeWidth: 2 }),
      text(56, 296, 704, 'Starting {{date}}, teams may choose two anchor days per week for in-office collaboration. Managers will confirm anchor days by the end of this month. Desk booking opens in the People OS on Monday.\n\nWhat changes\n• Anchor days replace the fixed Tuesday/Thursday schedule.\n• Meeting rooms are now bookable up to 14 days ahead.\n• Remote-first teams keep their current arrangement.\n\nQuestions? Reach out to people@aviary.io.', 13, { lineHeight: 1.6, color: '#2c352f' }),
    ]),
  },
  {
    key: 'poster', name: 'Event poster', desc: 'Bold A3 poster for town halls & socials.', build: () => makeDoc('Town hall poster', 'a3', '#0d7a54', [
      base('ellipse', 700, -200, 700, 700, { fill: '#0a5c40' }),
      base('ellipse', -160, 1180, 520, 520, { fill: '#14a06f' }),
      text(80, 140, 960, 'ALL-HANDS', 22, { color: '#d9f96a', letterSpacing: 10, fontWeight: 700 }),
      text(80, 190, 980, 'Quarterly\nTown Hall', 132, { color: '#ffffff', fontFamily: 'Fraunces', fontWeight: 700, lineHeight: 1.02 }),
      text(80, 560, 900, '{{date}} · 4:00 PM IST\nAuditorium, {{location}} + livestream', 30, { color: '#ffffff', lineHeight: 1.4 }),
      base('rect', 80, 700, 420, 74, { fill: '#d9f96a', radius: 37 }),
      text(80, 720, 420, 'RSVP in People OS', 24, { align: 'center', color: '#0a5c40', fontWeight: 700 }),
      text(80, 1440, 960, '{{company}} · People & Culture', 18, { color: 'rgba(255,255,255,0.7)' }),
      base('qr', 940, 1380, 120, 120, { qrValue: 'https://aviary.io/events/town-hall' }),
    ]),
  },
  {
    key: 'bcard', name: 'Business card', desc: 'Front of a standard 85.6 × 54 mm card.', build: () => makeDoc('Business card', 'bcard', '#ffffff', [
      base('rect', 0, 0, 12, 204, { fill: '#0d7a54' }),
      text(28, 34, 260, '{{employee_name}}', 17, { fontWeight: 700, fontFamily: 'Fraunces' }),
      text(28, 58, 260, '{{role}} · {{dept}}', 9.5, { color: '#6b746e' }),
      text(28, 120, 260, '{{email}}\n+91 98765 43210\naviary.io', 9, { lineHeight: 1.6, color: '#2c352f' }),
      text(200, 160, 110, '{{company}}', 10, { align: 'right', fontWeight: 700, color: '#0d7a54' }),
    ]),
  },
  {
    key: 'social', name: 'Social announcement', desc: 'Square welcome / promotion post.', build: () => makeDoc('Welcome post', 'square', '#101914', [
      base('rect', 60, 60, 960, 960, { fill: 'transparent', stroke: '#d9f96a', strokeWidth: 3, radius: 32 }),
      text(120, 150, 840, 'PLEASE WELCOME', 22, { align: 'center', color: '#d9f96a', letterSpacing: 8, fontWeight: 700 }),
      base('ellipse', 400, 230, 280, 280, { fill: '#0d7a54' }),
      text(120, 560, 840, '{{employee_name}}', 64, { align: 'center', color: '#ffffff', fontFamily: 'Fraunces', fontWeight: 700 }),
      text(120, 650, 840, '{{role}} · {{dept}}', 28, { align: 'center', color: 'rgba(255,255,255,0.75)' }),
      text(120, 860, 840, 'Joining {{company}} in {{location}} on {{joined}}', 22, { align: 'center', color: 'rgba(255,255,255,0.6)' }),
    ]),
  },
];

const docPx = (d: Doc) => ({ W: Math.round(toPx(d.width, d.unit)), H: Math.round(toPx(d.height, d.unit)) });
const fmtDate = (d?: string | null) => (d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : '');

/* ============================================================ */
export default function DocumentStudio() {
  const [doc, setDoc] = useState<Doc>(() => TEMPLATES[1].build());
  const [sel, setSel] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [zoom, setZoom] = useState<number | 'fit'>('fit');
  const [grid, setGrid] = useState(true);
  const [snap, setSnap] = useState(true);
  const [leftTab, setLeftTab] = useState<'templates' | 'elements' | 'saved'>('elements');
  const [rightTab, setRightTab] = useState<'element' | 'page' | 'data'>('element');
  const [toast, setToast] = useState('');
  const [busy, setBusy] = useState('');
  const [savedId, setSavedId] = useState<number | null>(null);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState('');
  const [bgTool, setBgTool] = useState<{ id: string; tol: number; feather: number; pick: { x: number; y: number } | null; preview: string; picking: boolean } | null>(null);
  const [people, setPeople] = useState<OrgPerson[]>([]);
  const [merge, setMerge] = useState<Record<string, string>>({ company: 'Aviary Technologies', date: fmtDate(new Date().toISOString()), manager: 'Ananya Rao' });
  const [qrCache, setQrCache] = useState<Record<string, string>>({});
  const stageRef = useRef<HTMLDivElement>(null);
  const pageRef = useRef<HTMLDivElement>(null);
  const [stageW, setStageW] = useState(800);
  const [stageH, setStageH] = useState(600);
  const history = useRef<string[]>([]);
  const future = useRef<string[]>([]);
  const assets = useAssets<Doc>('document');

  const { W, H } = docPx(doc);
  const scale = zoom === 'fit' ? Math.min((stageW - 48) / W, (stageH - 48) / H, 2) : zoom;
  const selEl = doc.elements.find((e) => e.id === sel) || null;
  const notify = (m: string) => { setToast(m); setTimeout(() => setToast(''), 2400); };

  useEffect(() => { api<OrgPerson[]>('organization?resource=people').then(setPeople).catch(() => setPeople([])); }, []);
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => { setStageW(el.clientWidth); setStageH(el.clientHeight); });
    ro.observe(el); setStageW(el.clientWidth); setStageH(el.clientHeight);
    return () => ro.disconnect();
  }, []);
  // fonts used by the document are loaded on demand (bundled, offline)
  useEffect(() => { doc.elements.forEach((e) => { if (e.fontFamily) void loadFont(e.fontFamily); }); }, [doc.elements]);
  // QR images
  useEffect(() => {
    doc.elements.filter((e) => e.type === 'qr').forEach((e) => {
      const v = mergeFields(e.qrValue || '', merge);
      const key = `${v}|${e.color || '#000000'}`;
      if (qrCache[key]) return;
      QRCode.toDataURL(v || ' ', { margin: 1, width: 512, color: { dark: e.color || '#000000', light: '#00000000' } }).then((url) => setQrCache((c) => ({ ...c, [key]: url }))).catch(() => {});
    });
  }, [doc.elements, merge, qrCache]);

  /* ---------- history ---------- */
  const commit = useCallback((next: Doc | ((d: Doc) => Doc)) => {
    setDoc((d) => {
      const n = typeof next === 'function' ? next(d) : next;
      history.current.push(JSON.stringify(d));
      if (history.current.length > 80) history.current.shift();
      future.current = [];
      return n;
    });
  }, []);
  const undo = () => { const prev = history.current.pop(); if (!prev) return; future.current.push(JSON.stringify(doc)); setDoc(JSON.parse(prev)); };
  const redo = () => { const nxt = future.current.pop(); if (!nxt) return; history.current.push(JSON.stringify(doc)); setDoc(JSON.parse(nxt)); };
  const patch = (id: string, p: Partial<El>, record = true) => (record ? commit : setDoc)((d: Doc) => ({ ...d, elements: d.elements.map((e) => (e.id === id ? { ...e, ...p } : e)) }));
  const add = (el: El) => { commit((d) => ({ ...d, elements: [...d.elements, el] })); setSel(el.id); setRightTab('element'); };
  const remove = (id: string) => { commit((d) => ({ ...d, elements: d.elements.filter((e) => e.id !== id) })); setSel(null); };
  const duplicate = (id: string) => { const e = doc.elements.find((x) => x.id === id); if (e) add({ ...e, id: uid(), x: e.x + 16, y: e.y + 16 }); };
  const reorder = (id: string, dir: 1 | -1) => commit((d) => {
    const i = d.elements.findIndex((e) => e.id === id); const j = i + dir;
    if (i < 0 || j < 0 || j >= d.elements.length) return d;
    const arr = [...d.elements]; [arr[i], arr[j]] = [arr[j], arr[i]]; return { ...d, elements: arr };
  });

  /* ---------- keyboard ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (editing || tag === 'INPUT' || tag === 'TEXTAREA' || (e.target as HTMLElement).isContentEditable) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }
      if (!sel) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicate(sel); return; }
      if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); remove(sel); return; }
      const step = e.shiftKey ? 10 : 1;
      const mv: Record<string, [number, number]> = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
      if (mv[e.key]) { e.preventDefault(); const el = doc.elements.find((x) => x.id === sel); if (el && !el.locked) patch(sel, { x: el.x + mv[e.key][0], y: el.y + mv[e.key][1] }); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sel, editing, doc]);

  /* ---------- pointer: move & resize ---------- */
  const drag = useRef<{ id: string; mode: string; sx: number; sy: number; ox: number; oy: number; ow: number; oh: number } | null>(null);
  const startDrag = (e: React.PointerEvent, el: El, mode = 'move') => {
    if (el.locked) return;
    e.stopPropagation(); e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { id: el.id, mode, sx: e.clientX, sy: e.clientY, ox: el.x, oy: el.y, ow: el.w, oh: el.h };
    setSel(el.id); setRightTab('element');
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current; if (!d) return;
    const dx = (e.clientX - d.sx) / scale, dy = (e.clientY - d.sy) / scale;
    const g = snap ? 8 : 1;
    const sn = (v: number) => Math.round(v / g) * g;
    let { ox: x, oy: y, ow: w, oh: h } = d;
    if (d.mode === 'move') { x = sn(d.ox + dx); y = sn(d.oy + dy); }
    else {
      if (d.mode.includes('e')) w = Math.max(8, sn(d.ow + dx));
      if (d.mode.includes('s')) h = Math.max(4, sn(d.oh + dy));
      if (d.mode.includes('w')) { const nw = Math.max(8, sn(d.ow - dx)); x = d.ox + (d.ow - nw); w = nw; }
      if (d.mode.includes('n')) { const nh = Math.max(4, sn(d.oh - dy)); y = d.oy + (d.oh - nh); h = nh; }
    }
    patch(d.id, { x, y, w, h }, false);
  };
  const endDrag = () => {
    const d = drag.current; if (!d) return;
    drag.current = null;
    // record one history step for the whole gesture
    const el = doc.elements.find((x) => x.id === d.id);
    if (el && (el.x !== d.ox || el.y !== d.oy || el.w !== d.ow || el.h !== d.oh)) {
      history.current.push(JSON.stringify({ ...doc, elements: doc.elements.map((x) => (x.id === d.id ? { ...x, x: d.ox, y: d.oy, w: d.ow, h: d.oh } : x)) }));
      future.current = [];
    }
  };

  /* ---------- images ---------- */
  const addImage = async (file: File) => {
    try {
      const src = await fitImage(await readFileAsDataUrl(file));
      const img = new Image(); img.src = src; await img.decode();
      const maxW = W * 0.5; const s = Math.min(1, maxW / img.width);
      add(base('image', Math.round((W - img.width * s) / 2), Math.round((H - img.height * s) / 2), Math.round(img.width * s), Math.round(img.height * s), { src, originalSrc: src, fit: 'contain' }));
    } catch { notify('Could not import that image'); }
  };
  const openBgTool = (el: El) => setBgTool({ id: el.id, tol: 34, feather: 1, pick: null, preview: el.originalSrc || el.src || '', picking: false });
  useEffect(() => {
    if (!bgTool) return;
    const el = doc.elements.find((e) => e.id === bgTool.id);
    const src = el?.originalSrc || el?.src; if (!src) return;
    let alive = true;
    setBusy('Removing background…');
    removeBackground(src, { tolerance: bgTool.tol, feather: bgTool.feather, pick: bgTool.pick }).then((out) => { if (alive) setBgTool((b) => (b ? { ...b, preview: out } : b)); }).finally(() => setBusy(''));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bgTool?.tol, bgTool?.feather, bgTool?.pick, bgTool?.id]);

  /* ---------- merge data ---------- */
  const applyPerson = (p: OrgPerson) => setMerge((m) => ({
    ...m, employee_name: p.full_name, first_name: p.full_name.split(' ')[0], role: p.role, dept: p.dept, location: p.location, email: p.email,
    employee_no: `AV-${1000 + p.id}`, joined: fmtDate(p.joined), salary: Number(p.salary).toLocaleString('en-IN'),
  }));
  const T = (s: string) => mergeFields(s, merge);

  /* ---------- export ---------- */
  const exportAs = async (fmt: string, dpi = 150) => {
    const node = pageRef.current; if (!node) return;
    const name = doc.name.toLowerCase().replace(/\s+/g, '-');
    const wasSel = sel; setSel(null); setEditing(null);
    await new Promise((r) => setTimeout(r, 30));
    try {
      setBusy(`Exporting ${fmt.toUpperCase()}…`);
      if (fmt === 'json') { downloadBlob(`${name}.json`, new Blob([JSON.stringify(doc, null, 2)], { type: 'application/json' })); return; }
      if (fmt === 'svg') { downloadBlob(`${name}.svg`, new Blob([toSvg(doc, T, qrCache)], { type: 'image/svg+xml' })); return; }
      // capture the page at its natural size (undo the on-screen zoom)
      const prev = node.style.transform; node.style.transform = 'scale(1)';
      const cv = await captureNode(node, dpi / 96, doc.bg);
      node.style.transform = prev;
      if (fmt === 'png') downloadDataUrl(`${name}.png`, cv.toDataURL('image/png'));
      else if (fmt === 'jpg') downloadDataUrl(`${name}.jpg`, cv.toDataURL('image/jpeg', 0.93));
      else if (fmt === 'pdf') canvasToPdf([cv], fromPx(W, 'mm'), fromPx(H, 'mm'), `${name}.pdf`);
    } catch (e) { notify(e instanceof Error ? e.message : 'Export failed'); }
    finally { setBusy(''); setSel(wasSel); }
  };
  const saveDoc = async () => {
    const node = pageRef.current;
    let thumb: string | null = null;
    try { if (node) { const prev = node.style.transform; node.style.transform = 'scale(1)'; const cv = await captureNode(node, Math.min(0.3, 300 / W), doc.bg); node.style.transform = prev; thumb = cv.toDataURL('image/jpeg', 0.7); } } catch { /* thumbnail optional */ }
    try {
      const saved = await assets.save(saveName || doc.name, { ...doc, name: saveName || doc.name }, savedId || undefined, thumb);
      setSavedId(saved.id); setDoc((d) => ({ ...d, name: saved.name })); setSaveOpen(false); notify('Document saved');
    } catch (e) { notify(e instanceof Error ? e.message : 'Save failed'); }
  };
  const loadDoc = (a: { id: number; payload: Doc }) => { history.current = []; future.current = []; setDoc(a.payload); setSavedId(a.id); setSel(null); notify(`Opened “${a.payload.name}”`); };
  const useTemplate = (t: typeof TEMPLATES[number]) => { history.current = []; future.current = []; setDoc(t.build()); setSavedId(null); setSel(null); setZoom('fit'); };

  /* ---------- render helpers ---------- */
  const textStyle = (e: El): React.CSSProperties => ({
    fontFamily: `"${e.fontFamily || 'Outfit'}", system-ui, sans-serif`, fontSize: e.fontSize || 14, fontWeight: e.fontWeight || 400,
    fontStyle: e.italic ? 'italic' : 'normal', textDecoration: e.underline ? 'underline' : 'none', color: e.color || '#111',
    textAlign: e.align || 'left', lineHeight: e.lineHeight || 1.3, letterSpacing: e.letterSpacing ? `${e.letterSpacing}px` : undefined,
    whiteSpace: 'pre-wrap', wordBreak: 'break-word',
  });
  const renderEl = (e: El) => {
    const common: React.CSSProperties = { position: 'absolute', left: e.x, top: e.y, width: e.w, height: e.h, transform: e.rot ? `rotate(${e.rot}deg)` : undefined, opacity: e.opacity, boxSizing: 'border-box' };
    if (e.type === 'text') return <div style={{ ...common, ...textStyle(e), overflow: 'visible' }}>{editing === e.id ? '' : T(e.text || '')}</div>;
    if (e.type === 'image') return <div style={{ ...common, borderRadius: e.radius || 0, overflow: 'hidden' }}>{e.src && <img src={e.src} alt="" draggable={false} style={{ width: '100%', height: '100%', objectFit: e.fit || 'contain', display: 'block' }} />}</div>;
    if (e.type === 'rect') return <div style={{ ...common, background: e.fill || 'transparent', border: e.strokeWidth ? `${e.strokeWidth}px solid ${e.stroke || '#000'}` : undefined, borderRadius: e.radius || 0 }} />;
    if (e.type === 'ellipse') return <div style={{ ...common, background: e.fill || 'transparent', border: e.strokeWidth ? `${e.strokeWidth}px solid ${e.stroke || '#000'}` : undefined, borderRadius: '50%' }} />;
    if (e.type === 'line') return <div style={{ ...common, height: Math.max(1, e.strokeWidth || 2), background: e.stroke || '#000', top: e.y + (e.h - (e.strokeWidth || 2)) / 2 }} />;
    if (e.type === 'qr') { const url = qrCache[`${T(e.qrValue || '')}|${e.color || '#000000'}`]; return <div style={{ ...common, background: e.fill || 'transparent', borderRadius: e.radius || 0, display: 'grid', placeItems: 'center' }}>{url ? <img src={url} alt="QR" draggable={false} style={{ width: '100%', height: '100%' }} /> : <span style={{ fontSize: 10, color: '#888' }}>QR</span>}</div>; }
    return null;
  };

  const Field = ({ label, children }: { label: string; children: ReactNode }) => (<div><label className={labelCls}>{label}</label>{children}</div>);
  const Num = ({ v, on, step = 1, min }: { v: number; on: (n: number) => void; step?: number; min?: number }) => (
    <input type="number" value={Number.isFinite(v) ? Math.round(v * 100) / 100 : 0} step={step} min={min} onChange={(ev) => on(parseFloat(ev.target.value) || 0)} className={inputCls + ' !py-1.5 text-[12.5px]'} />
  );
  const Color = ({ v, on }: { v: string; on: (c: string) => void }) => (
    <div className="tk-inset flex items-center gap-2 rounded-xl px-2 py-1.5">
      <input type="color" value={/^#[0-9a-f]{6}$/i.test(v) ? v : '#000000'} onChange={(ev) => on(ev.target.value)} className="h-6 w-8 cursor-pointer rounded border-0 bg-transparent" />
      <input value={v} onChange={(ev) => on(ev.target.value)} className="w-full bg-transparent font-body text-[12px] text-ink outline-none" />
    </div>
  );

  return (
    <div className="space-y-4">
      {toast && <div className="fixed left-1/2 top-20 z-[80] -translate-x-1/2 rounded-full bg-ink px-5 py-2.5 font-body text-[13px] font-bold text-paper shadow-xl">{toast}</div>}
      {busy && <div className="fixed bottom-6 left-1/2 z-[80] -translate-x-1/2 rounded-full bg-ink/90 px-4 py-2 font-body text-[12px] font-bold text-paper">{busy}</div>}

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-body text-[12px] font-bold uppercase tracking-[0.18em] text-primary">Studio · Documents</p>
          <h1 className="mt-1 flex items-center gap-2.5 font-display text-2xl font-semibold tracking-tight text-ink">
            <span className="tk-raise-sm flex h-9 w-9 items-center justify-center rounded-xl text-primary"><FileText size={17} /></span>
            Document editor & creator
          </h1>
          <p className="mt-1 font-body text-[13px] text-muted">Any size, drag anything, export anywhere — no code required.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input value={doc.name} onChange={(e) => setDoc((d) => ({ ...d, name: e.target.value }))} className={inputCls + ' w-56 !py-2 text-[13px] font-bold'} />
          <button onClick={() => { setSaveName(doc.name); setSaveOpen(true); }} className={btnGhost + ' !py-2 text-[12px]'}><Save size={13} /> {savedId ? 'Save' : 'Save as…'}</button>
          <ExportMenu onPick={exportAs} />
        </div>
      </motion.div>

      <div className="grid gap-4 xl:grid-cols-[250px_1fr_280px]">
        {/* ================= LEFT: templates · elements · saved ================= */}
        <div className="tk-card h-fit p-3 xl:sticky xl:top-20">
          <div className="tk-inset mb-3 flex gap-0.5 p-1">
            {([['elements', 'Add', Plus], ['templates', 'Templates', LayoutTemplate], ['saved', 'Saved', FolderOpen]] as const).map(([k, l, I]) => (
              <button key={k} onClick={() => setLeftTab(k)} className={`flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 font-body text-[11px] font-bold transition ${leftTab === k ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}><I size={12} /> {l}</button>
            ))}
          </div>
          {leftTab === 'elements' && (
            <div className="space-y-1.5">
              {[
                { icon: Type, label: 'Heading', go: () => add(text(Math.round(W * 0.1), Math.round(H * 0.1), Math.round(W * 0.8), 'Heading text', Math.max(28, Math.round(W / 22)), { fontFamily: 'Fraunces', fontWeight: 700 })) },
                { icon: Type, label: 'Subheading', go: () => add(text(Math.round(W * 0.1), Math.round(H * 0.2), Math.round(W * 0.8), 'Subheading', Math.max(18, Math.round(W / 40)), { fontWeight: 600, color: '#0d7a54' })) },
                { icon: Type, label: 'Body text', go: () => add(text(Math.round(W * 0.1), Math.round(H * 0.3), Math.round(W * 0.8), 'Body text. Double-click to edit. Use {{merge_fields}} to personalise.', Math.max(12, Math.round(W / 60)), { lineHeight: 1.5 })) },
                { icon: Square, label: 'Rectangle', go: () => add(base('rect', Math.round(W * 0.3), Math.round(H * 0.3), Math.round(W * 0.4), Math.round(H * 0.2), { fill: '#0d7a54', radius: 12 })) },
                { icon: Circle, label: 'Ellipse', go: () => add(base('ellipse', Math.round(W * 0.35), Math.round(H * 0.3), Math.round(W * 0.3), Math.round(W * 0.3), { fill: '#c9932b' })) },
                { icon: Minus, label: 'Line', go: () => add(base('line', Math.round(W * 0.1), Math.round(H * 0.5), Math.round(W * 0.8), 8, { stroke: '#1b1b1f', strokeWidth: 2 })) },
                { icon: QrCode, label: 'QR code', go: () => add(base('qr', Math.round(W * 0.4), Math.round(H * 0.4), Math.round(W * 0.16), Math.round(W * 0.16), { qrValue: 'https://aviary.io', color: '#000000' })) },
              ].map(({ icon: I, label, go }) => (
                <button key={label} onClick={go} className="tk-raise-sm flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left font-body text-[12.5px] font-bold text-ink transition hover:-translate-y-0.5"><I size={14} className="text-primary" /> {label}</button>
              ))}
              <label className="tk-btn-primary flex w-full cursor-pointer items-center gap-2.5 rounded-xl px-3 py-2 font-body text-[12.5px] font-bold"><ImageIcon size={14} /> Import image
                <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) addImage(f); e.target.value = ''; }} />
              </label>
              <p className="pt-2 font-body text-[10.5px] font-bold uppercase tracking-wider text-muted">Merge fields</p>
              <div className="flex flex-wrap gap-1">
                {MERGE_FIELDS.map((f) => (
                  <button key={f} onClick={() => { if (selEl?.type === 'text') patch(selEl.id, { text: (selEl.text || '') + ` {{${f}}}` }); else add(text(Math.round(W * 0.1), Math.round(H * 0.1), Math.round(W * 0.6), `{{${f}}}`, Math.max(14, Math.round(W / 50)))); }}
                    className="tk-chip px-2 py-0.5 font-body text-[10px] font-bold text-ink/70 hover:text-primary">{`{{${f}}}`}</button>
                ))}
              </div>
            </div>
          )}
          {leftTab === 'templates' && (
            <div className="space-y-1.5">
              {TEMPLATES.map((t) => (
                <button key={t.key} onClick={() => useTemplate(t)} className="tk-raise-sm w-full rounded-xl px-3 py-2.5 text-left transition hover:-translate-y-0.5">
                  <p className="font-body text-[12.5px] font-bold text-ink">{t.name}</p>
                  <p className="font-body text-[11px] text-muted">{t.desc}</p>
                </button>
              ))}
              <label className={btnGhost + ' mt-1 w-full cursor-pointer !py-2 text-[12px]'}><FolderOpen size={13} /> Import design JSON
                <input type="file" accept="application/json" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { const d = JSON.parse(await f.text()) as Doc; if (!d.elements || !d.width) throw new Error(); history.current = []; setDoc(d); setSavedId(null); notify('Design imported'); } catch { notify('Not a valid design file'); } e.target.value = ''; }} />
              </label>
            </div>
          )}
          {leftTab === 'saved' && (
            <div className="space-y-2">
              {assets.loading && Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-xl" />)}
              {!assets.loading && assets.items.length === 0 && <p className="py-6 text-center font-body text-[12px] text-muted">No saved documents yet.</p>}
              {assets.items.map((a) => (
                <div key={a.id} className={`tk-raise-sm flex items-center gap-2.5 rounded-xl p-2 ${savedId === a.id ? 'ring-2 ring-(--t-accent)/50' : ''}`}>
                  <button onClick={() => loadDoc(a)} className="flex min-w-0 flex-1 items-center gap-2.5 text-left">
                    <span className="tk-inset flex h-12 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg">{a.thumbnail ? <img src={a.thumbnail} alt="" className="h-full w-full object-cover" /> : <FileText size={14} className="text-muted" />}</span>
                    <span className="min-w-0"><span className="block truncate font-body text-[12.5px] font-bold text-ink">{a.name}</span><span className="block font-body text-[10.5px] text-muted">{new Date(a.updated_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</span></span>
                  </button>
                  <button onClick={() => assets.remove(a.id).then(() => { if (savedId === a.id) setSavedId(null); notify('Deleted'); })} className="text-muted hover:text-rose-500" data-tip="Delete"><Trash2 size={13} /></button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ================= CENTER: stage ================= */}
        <div className="min-w-0">
          <div className="tk-card mb-3 flex flex-wrap items-center gap-1.5 px-3 py-2">
            <button onClick={undo} disabled={!history.current.length} className="tk-btn-ghost rounded-lg p-1.5 disabled:opacity-40" data-tip="Undo (Ctrl+Z)"><Undo2 size={14} /></button>
            <button onClick={redo} disabled={!future.current.length} className="tk-btn-ghost rounded-lg p-1.5 disabled:opacity-40" data-tip="Redo (Ctrl+Y)"><Redo2 size={14} /></button>
            <span className="mx-1 h-5 w-px bg-ink/10" />
            <button onClick={() => setGrid(!grid)} className={`tk-btn-ghost rounded-lg p-1.5 ${grid ? 'text-primary' : ''}`} data-tip="Grid"><Grid3X3 size={14} /></button>
            <button onClick={() => setSnap(!snap)} className={`tk-btn-ghost rounded-lg px-2 py-1.5 font-body text-[11px] font-bold ${snap ? 'text-primary' : ''}`} data-tip="Snap to 8px grid">Snap</button>
            <span className="mx-1 h-5 w-px bg-ink/10" />
            <button onClick={() => setZoom(Math.max(0.1, (zoom === 'fit' ? scale : zoom) - 0.1))} className="tk-btn-ghost rounded-lg p-1.5"><ZoomOut size={14} /></button>
            <span className="w-12 text-center font-body text-[11.5px] font-bold tabular-nums text-ink">{Math.round(scale * 100)}%</span>
            <button onClick={() => setZoom(Math.min(4, (zoom === 'fit' ? scale : zoom) + 0.1))} className="tk-btn-ghost rounded-lg p-1.5"><ZoomIn size={14} /></button>
            <button onClick={() => setZoom('fit')} className={`tk-btn-ghost rounded-lg p-1.5 ${zoom === 'fit' ? 'text-primary' : ''}`} data-tip="Fit to screen"><Maximize2 size={14} /></button>
            <span className="ml-auto font-body text-[11.5px] text-muted">{doc.width} × {doc.height} {doc.unit} · {W} × {H} px</span>
            {selEl && (
              <div className="flex items-center gap-1">
                <button onClick={() => reorder(selEl.id, 1)} className="tk-btn-ghost rounded-lg p-1.5" data-tip="Bring forward"><ArrowUp size={13} /></button>
                <button onClick={() => reorder(selEl.id, -1)} className="tk-btn-ghost rounded-lg p-1.5" data-tip="Send backward"><ArrowDown size={13} /></button>
                <button onClick={() => duplicate(selEl.id)} className="tk-btn-ghost rounded-lg p-1.5" data-tip="Duplicate (Ctrl+D)"><Copy size={13} /></button>
                <button onClick={() => patch(selEl.id, { locked: !selEl.locked })} className="tk-btn-ghost rounded-lg p-1.5" data-tip={selEl.locked ? 'Unlock' : 'Lock'}>{selEl.locked ? <Lock size={13} /> : <Unlock size={13} />}</button>
                <button onClick={() => remove(selEl.id)} className="tk-btn-ghost rounded-lg p-1.5 text-rose-500" data-tip="Delete"><Trash2 size={13} /></button>
              </div>
            )}
          </div>

          <div ref={stageRef} className="tk-inset relative overflow-auto rounded-2xl" style={{ height: 'min(78vh, 900px)' }}
            onPointerDown={() => { setSel(null); setEditing(null); }}>
            <div style={{ width: Math.max(stageW, W * scale + 48), height: Math.max(stageH, H * scale + 48), display: 'grid', placeItems: 'center' }}>
              <div style={{ width: W * scale, height: H * scale, position: 'relative' }}>
                <div ref={pageRef} onPointerDown={(e) => e.stopPropagation()}
                  style={{ width: W, height: H, background: doc.bg, transform: `scale(${scale})`, transformOrigin: 'top left', position: 'absolute', left: 0, top: 0, boxShadow: '0 12px 40px rgba(0,0,0,0.25)', overflow: 'hidden', cursor: 'default' }}
                  onClick={(e) => { if (e.target === e.currentTarget) { setSel(null); setEditing(null); } }}>
                  {grid && <div data-html2canvas-ignore style={{ position: 'absolute', inset: 0, pointerEvents: 'none', backgroundImage: 'linear-gradient(rgba(0,0,0,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.06) 1px, transparent 1px)', backgroundSize: '32px 32px' }} />}
                  {doc.elements.map((e) => (
                    <div key={e.id} onPointerDown={(ev) => startDrag(ev, e)} onPointerMove={onMove} onPointerUp={endDrag} onPointerCancel={endDrag}
                      onDoubleClick={() => { if (e.type === 'text' && !e.locked) { setEditing(e.id); setSel(e.id); } }}
                      style={{ position: 'absolute', left: 0, top: 0, width: 0, height: 0, cursor: e.locked ? 'not-allowed' : 'move' }}>
                      {renderEl(e)}
                      {editing === e.id && e.type === 'text' && (
                        <textarea autoFocus value={e.text || ''} onChange={(ev) => patch(e.id, { text: ev.target.value }, false)} onBlur={() => { setEditing(null); commit((d) => d); }}
                          onPointerDown={(ev) => ev.stopPropagation()} data-html2canvas-ignore
                          style={{ position: 'absolute', left: e.x, top: e.y, width: e.w, minHeight: e.h, ...textStyle(e), background: 'rgba(255,255,255,0.85)', outline: '2px solid var(--t-accent)', border: 0, resize: 'none', padding: 0, margin: 0, overflow: 'hidden' }} />
                      )}
                      {sel === e.id && !editing && (
                        <div data-html2canvas-ignore style={{ position: 'absolute', left: e.x, top: e.y, width: e.w, height: e.h, outline: `${2 / scale}px solid var(--t-accent)`, pointerEvents: 'none' }}>
                          {!e.locked && ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'].map((hnd) => {
                            const s = 10 / scale;
                            const pos: React.CSSProperties = {
                              position: 'absolute', width: s, height: s, background: '#fff', border: `${1.5 / scale}px solid var(--t-accent)`, borderRadius: 2 / scale, pointerEvents: 'auto',
                              left: hnd.includes('w') ? -s / 2 : hnd.includes('e') ? e.w - s / 2 : e.w / 2 - s / 2,
                              top: hnd.includes('n') ? -s / 2 : hnd.includes('s') ? e.h - s / 2 : e.h / 2 - s / 2,
                              cursor: `${hnd}-resize`,
                            };
                            return <div key={hnd} style={pos} onPointerDown={(ev) => startDrag(ev, e, hnd)} onPointerMove={onMove} onPointerUp={endDrag} />;
                          })}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <p className="mt-2 font-body text-[11px] text-muted">Drag to move · handles to resize · double-click text to edit · Delete removes · Ctrl+D duplicates · arrows nudge (Shift = 10px)</p>
        </div>

        {/* ================= RIGHT: properties ================= */}
        <div className="tk-card h-fit p-3 xl:sticky xl:top-20">
          <div className="tk-inset mb-3 flex gap-0.5 p-1">
            {([['element', 'Element', Settings2], ['page', 'Page', LayoutTemplate], ['data', 'Data', Users]] as const).map(([k, l, I]) => (
              <button key={k} onClick={() => setRightTab(k)} className={`flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 font-body text-[11px] font-bold transition ${rightTab === k ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}><I size={12} /> {l}</button>
            ))}
          </div>

          {rightTab === 'element' && !selEl && <p className="py-8 text-center font-body text-[12px] text-muted">Select an element on the page to edit it, or add one from the left panel.</p>}
          {rightTab === 'element' && selEl && (
            <div className="space-y-3">
              <div className="flex items-center justify-between"><Badge tone="green">{selEl.type}</Badge><span className="font-body text-[10.5px] text-muted">layer {doc.elements.findIndex((e) => e.id === selEl.id) + 1} / {doc.elements.length}</span></div>
              <div className="grid grid-cols-2 gap-2">
                <Field label="X"><Num v={selEl.x} on={(n) => patch(selEl.id, { x: n })} /></Field>
                <Field label="Y"><Num v={selEl.y} on={(n) => patch(selEl.id, { y: n })} /></Field>
                <Field label="Width"><Num v={selEl.w} on={(n) => patch(selEl.id, { w: Math.max(4, n) })} min={4} /></Field>
                <Field label="Height"><Num v={selEl.h} on={(n) => patch(selEl.id, { h: Math.max(4, n) })} min={4} /></Field>
                <Field label="Rotation °"><Num v={selEl.rot} on={(n) => patch(selEl.id, { rot: n })} /></Field>
                <Field label="Opacity"><input type="range" min={0} max={1} step={0.02} value={selEl.opacity} onChange={(e) => patch(selEl.id, { opacity: parseFloat(e.target.value) })} className="tk-range mt-2 w-full" /></Field>
              </div>
              {selEl.type === 'text' && (
                <>
                  <Field label="Text"><textarea rows={4} value={selEl.text || ''} onChange={(e) => patch(selEl.id, { text: e.target.value })} className={inputCls + ' text-[12.5px]'} /></Field>
                  <Field label="Font"><Select options={FONTS.map((f) => ({ value: f, label: f }))} value={selEl.fontFamily || 'Outfit'} onChange={(v) => { if (v) { void loadFont(v); patch(selEl.id, { fontFamily: v }); } }} /></Field>
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Size"><Num v={selEl.fontSize || 14} on={(n) => patch(selEl.id, { fontSize: Math.max(4, n) })} min={4} /></Field>
                    <Field label="Line height"><Num v={selEl.lineHeight || 1.3} step={0.05} on={(n) => patch(selEl.id, { lineHeight: n })} /></Field>
                    <Field label="Weight"><Select options={[300, 400, 500, 600, 700, 800].map((w) => ({ value: String(w), label: String(w) }))} value={String(selEl.fontWeight || 400)} onChange={(v) => v && patch(selEl.id, { fontWeight: +v })} searchable={false} /></Field>
                    <Field label="Letter spacing"><Num v={selEl.letterSpacing || 0} step={0.5} on={(n) => patch(selEl.id, { letterSpacing: n })} /></Field>
                  </div>
                  <div className="flex items-center gap-1">
                    {(['left', 'center', 'right'] as const).map((a) => { const I = a === 'left' ? AlignLeft : a === 'center' ? AlignCenter : AlignRight; return <button key={a} onClick={() => patch(selEl.id, { align: a })} className={`tk-btn-ghost rounded-lg p-1.5 ${selEl.align === a ? 'text-primary' : ''}`}><I size={13} /></button>; })}
                    <span className="mx-1 h-5 w-px bg-ink/10" />
                    <button onClick={() => patch(selEl.id, { fontWeight: (selEl.fontWeight || 400) >= 700 ? 400 : 700 })} className={`tk-btn-ghost rounded-lg p-1.5 ${(selEl.fontWeight || 400) >= 700 ? 'text-primary' : ''}`}><Bold size={13} /></button>
                    <button onClick={() => patch(selEl.id, { italic: !selEl.italic })} className={`tk-btn-ghost rounded-lg p-1.5 ${selEl.italic ? 'text-primary' : ''}`}><Italic size={13} /></button>
                    <button onClick={() => patch(selEl.id, { underline: !selEl.underline })} className={`tk-btn-ghost rounded-lg p-1.5 ${selEl.underline ? 'text-primary' : ''}`}><Underline size={13} /></button>
                  </div>
                  <Field label="Colour"><Color v={selEl.color || '#111111'} on={(c) => patch(selEl.id, { color: c })} /></Field>
                </>
              )}
              {(selEl.type === 'rect' || selEl.type === 'ellipse') && (
                <>
                  <Field label="Fill"><Color v={selEl.fill || 'transparent'} on={(c) => patch(selEl.id, { fill: c })} /></Field>
                  <Field label="Border colour"><Color v={selEl.stroke || '#000000'} on={(c) => patch(selEl.id, { stroke: c })} /></Field>
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Border width"><Num v={selEl.strokeWidth || 0} on={(n) => patch(selEl.id, { strokeWidth: Math.max(0, n) })} min={0} /></Field>
                    {selEl.type === 'rect' && <Field label="Corner radius"><Num v={selEl.radius || 0} on={(n) => patch(selEl.id, { radius: Math.max(0, n) })} min={0} /></Field>}
                  </div>
                </>
              )}
              {selEl.type === 'line' && (
                <>
                  <Field label="Colour"><Color v={selEl.stroke || '#000000'} on={(c) => patch(selEl.id, { stroke: c })} /></Field>
                  <Field label="Thickness"><Num v={selEl.strokeWidth || 2} on={(n) => patch(selEl.id, { strokeWidth: Math.max(1, n) })} min={1} /></Field>
                </>
              )}
              {selEl.type === 'qr' && (
                <>
                  <Field label="QR content (URL / text — merge fields allowed)"><textarea rows={3} value={selEl.qrValue || ''} onChange={(e) => patch(selEl.id, { qrValue: e.target.value })} className={inputCls + ' text-[12.5px]'} /></Field>
                  <Field label="Module colour"><Color v={selEl.color || '#000000'} on={(c) => patch(selEl.id, { color: c })} /></Field>
                  <Field label="Background"><Color v={selEl.fill || 'transparent'} on={(c) => patch(selEl.id, { fill: c })} /></Field>
                </>
              )}
              {selEl.type === 'image' && (
                <>
                  <Field label="Fit"><Select options={[{ value: 'contain', label: 'Contain' }, { value: 'cover', label: 'Cover (crop)' }, { value: 'fill', label: 'Stretch' }]} value={selEl.fit || 'contain'} onChange={(v) => v && patch(selEl.id, { fit: v as El['fit'] })} searchable={false} /></Field>
                  <Field label="Corner radius"><Num v={selEl.radius || 0} on={(n) => patch(selEl.id, { radius: Math.max(0, n) })} min={0} /></Field>
                  <button onClick={() => openBgTool(selEl)} className={btnPrimary + ' w-full !py-2 text-[12.5px]'}><Wand2 size={13} /> Remove background</button>
                  {selEl.originalSrc && selEl.originalSrc !== selEl.src && <button onClick={() => patch(selEl.id, { src: selEl.originalSrc })} className={btnGhost + ' w-full !py-2 text-[12px]'}><Eraser size={13} /> Restore original</button>}
                  <label className={btnGhost + ' w-full cursor-pointer !py-2 text-[12px]'}><ImageIcon size={13} /> Replace image
                    <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) { const src = await fitImage(await readFileAsDataUrl(f)); patch(selEl.id, { src, originalSrc: src }); } e.target.value = ''; }} />
                  </label>
                </>
              )}
            </div>
          )}

          {rightTab === 'page' && (
            <div className="space-y-3">
              <Field label="Preset">
                <Select options={PRESETS.map((p) => ({ value: p.key, label: `${p.name} · ${p.w}×${p.h} ${p.unit}` }))} value={PRESETS.find((p) => p.w === doc.width && p.h === doc.height && p.unit === doc.unit)?.key || null}
                  onChange={(v) => { const p = PRESETS.find((x) => x.key === v); if (p) commit((d) => ({ ...d, width: p.w, height: p.h, unit: p.unit })); }} placeholder="Custom size" />
              </Field>
              <div className="grid grid-cols-3 gap-2">
                <Field label="Width"><Num v={doc.width} step={doc.unit === 'px' ? 1 : 0.1} on={(n) => commit((d) => ({ ...d, width: Math.max(1, n) }))} min={1} /></Field>
                <Field label="Height"><Num v={doc.height} step={doc.unit === 'px' ? 1 : 0.1} on={(n) => commit((d) => ({ ...d, height: Math.max(1, n) }))} min={1} /></Field>
                <Field label="Unit"><Select options={[{ value: 'px', label: 'px' }, { value: 'mm', label: 'mm' }, { value: 'in', label: 'in' }]} value={doc.unit} onChange={(v) => { if (!v) return; const u = v as Unit; commit((d) => ({ ...d, unit: u, width: Math.round(fromPx(toPx(d.width, d.unit), u) * 100) / 100, height: Math.round(fromPx(toPx(d.height, d.unit), u) * 100) / 100 })); }} searchable={false} /></Field>
              </div>
              <button onClick={() => commit((d) => ({ ...d, width: d.height, height: d.width }))} className={btnGhost + ' w-full !py-2 text-[12px]'}>Swap orientation</button>
              <Field label="Background colour"><Color v={doc.bg} on={(c) => commit((d) => ({ ...d, bg: c }))} /></Field>
              <p className="font-body text-[11px] leading-relaxed text-muted">Exports use the page’s physical size: PDF pages are {fromPx(W, 'mm').toFixed(1)} × {fromPx(H, 'mm').toFixed(1)} mm; PNG/JPG are rendered at the DPI you pick in Export.</p>
            </div>
          )}

          {rightTab === 'data' && (
            <div className="space-y-3">
              <Field label="Fill merge fields from an employee">
                <Select options={people.map((p) => ({ value: String(p.id), label: p.full_name, hint: p.role }))} value={null} onChange={(v) => { const p = people.find((x) => String(x.id) === v); if (p) { applyPerson(p); notify(`Merged ${p.full_name}`); } }} placeholder={people.length ? 'Search roster…' : 'Loading roster…'} />
              </Field>
              <div className="space-y-2">
                {MERGE_FIELDS.map((f) => (
                  <div key={f} className="flex items-center gap-2">
                    <span className="w-28 shrink-0 truncate font-body text-[11px] font-bold text-muted">{`{{${f}}}`}</span>
                    <input value={merge[f] || ''} onChange={(e) => setMerge((m) => ({ ...m, [f]: e.target.value }))} className={inputCls + ' !py-1.5 text-[12px]'} placeholder="—" />
                  </div>
                ))}
              </div>
              <p className="font-body text-[11px] text-muted">Fields are substituted live on the page and in every export. Unfilled fields stay visible as <code>{'{{field}}'}</code> so nothing silently disappears.</p>
            </div>
          )}
        </div>
      </div>

      {/* ---------- background removal tool ---------- */}
      <Modal open={bgTool !== null} onClose={() => setBgTool(null)} title="Remove background" wide>
        {bgTool && (() => {
          const el = doc.elements.find((e) => e.id === bgTool.id);
          const src = el?.originalSrc || el?.src || '';
          return (
            <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <p className={labelCls}>Original {bgTool.picking && <span className="text-primary">· click the background colour</span>}</p>
                  <div className="tk-inset overflow-hidden rounded-xl" style={{ background: 'repeating-conic-gradient(#d8dbd5 0 25%, #eceee9 0 50%) 0 0 / 16px 16px' }}>
                    <img src={src} alt="" className={`block max-h-[360px] w-full object-contain ${bgTool.picking ? 'cursor-crosshair' : ''}`}
                      onClick={(e) => { if (!bgTool.picking) return; const img = e.currentTarget; const r = img.getBoundingClientRect(); const sx = img.naturalWidth / r.width; const sy = img.naturalHeight / r.height; const bw = r.width, bh = r.height; const iw = img.naturalWidth / Math.max(sx, sy), ih = img.naturalHeight / Math.max(sx, sy); const ox = (bw - iw) / 2, oy = (bh - ih) / 2; const x = Math.round((e.clientX - r.left - ox) * Math.max(sx, sy)); const y = Math.round((e.clientY - r.top - oy) * Math.max(sx, sy)); setBgTool((b) => (b ? { ...b, pick: { x, y }, picking: false } : b)); }} />
                  </div>
                </div>
                <div>
                  <p className={labelCls}>Result</p>
                  <div className="tk-inset overflow-hidden rounded-xl" style={{ background: 'repeating-conic-gradient(#d8dbd5 0 25%, #eceee9 0 50%) 0 0 / 16px 16px' }}>
                    <img src={bgTool.preview} alt="" className="block max-h-[360px] w-full object-contain" />
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className={labelCls}>Tolerance · {bgTool.tol}</label>
                  <input type="range" min={4} max={120} value={bgTool.tol} onChange={(e) => setBgTool((b) => (b ? { ...b, tol: +e.target.value } : b))} className="tk-range w-full" />
                  <p className="mt-1 font-body text-[11px] text-muted">Higher removes more shades of the background; lower keeps more detail.</p>
                </div>
                <div>
                  <label className={labelCls}>Edge softness · {bgTool.feather}</label>
                  <input type="range" min={0} max={4} value={bgTool.feather} onChange={(e) => setBgTool((b) => (b ? { ...b, feather: +e.target.value } : b))} className="tk-range w-full" />
                </div>
                <div>
                  <label className={labelCls}>Background colour</label>
                  <div className="flex gap-2">
                    <button onClick={() => setBgTool((b) => (b ? { ...b, picking: true } : b))} className={btnGhost + ' flex-1 !py-2 text-[12px]'}><Crosshair size={13} /> Pick from image</button>
                    <button onClick={() => setBgTool((b) => (b ? { ...b, pick: null, picking: false } : b))} className={btnGhost + ' !py-2 text-[12px]'}>Auto</button>
                  </div>
                  <p className="mt-1 font-body text-[11px] text-muted">{bgTool.pick ? `Using the colour at ${bgTool.pick.x}, ${bgTool.pick.y}` : 'Auto detects the colour around the image border.'}</p>
                </div>
                <div className="flex gap-2 pt-2">
                  <button onClick={() => setBgTool(null)} className={btnGhost + ' flex-1'}>Cancel</button>
                  <button onClick={() => { patch(bgTool.id, { src: bgTool.preview, originalSrc: src }); setBgTool(null); notify('Background removed'); }} disabled={!!busy} className={btnPrimary + ' flex-1 disabled:opacity-50'}><Wand2 size={14} /> Apply</button>
                </div>
              </div>
            </div>
          );
        })()}
      </Modal>

      {/* ---------- save modal ---------- */}
      <Modal open={saveOpen} onClose={() => setSaveOpen(false)} title={savedId ? 'Save document' : 'Save document as'}>
        <div className="space-y-3">
          <Field label="Name"><input value={saveName} onChange={(e) => setSaveName(e.target.value)} className={inputCls} autoFocus /></Field>
          <div className="flex justify-end gap-2">
            {savedId && <button onClick={() => { setSavedId(null); saveDoc(); }} className={btnGhost}>Save as new copy</button>}
            <button onClick={saveDoc} disabled={!saveName.trim()} className={btnPrimary + ' disabled:opacity-50'}><Save size={14} /> Save</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

/* ---------- export menu (format × DPI) ---------- */
export function ExportMenu({ onPick, formats = ['png', 'jpg', 'pdf', 'svg', 'json'] }: { onPick: (fmt: string, dpi: number) => void; formats?: string[] }) {
  const [open, setOpen] = useState(false);
  const [dpi, setDpi] = useState(150);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onDown = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, []);
  const labels: Record<string, string> = { png: 'PNG image', jpg: 'JPG image', pdf: 'PDF (true size)', svg: 'SVG vector', json: 'Design file (JSON)' };
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(!open)} className={btnPrimary + ' !py-2 text-[12px]'}><Download size={13} /> Export</button>
      {open && (
        <div className="tk-pop absolute right-0 top-[calc(100%+6px)] z-40 w-60 p-2">
          {formats.some((f) => f === 'png' || f === 'jpg' || f === 'pdf') && (
            <div className="mb-2 px-1">
              <p className={labelCls}>Resolution</p>
              <div className="tk-inset flex gap-0.5 p-1">
                {[96, 150, 300].map((d) => <button key={d} onClick={() => setDpi(d)} className={`flex-1 rounded-lg py-1 font-body text-[11px] font-bold ${dpi === d ? 'tk-raise-sm text-primary' : 'text-muted'}`}>{d} dpi</button>)}
              </div>
            </div>
          )}
          {formats.map((f) => (
            <button key={f} onClick={() => { setOpen(false); onPick(f, dpi); }} className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left font-body text-[12.5px] font-semibold text-ink/80 transition hover:bg-primary/8">
              {labels[f] || f.toUpperCase()} <span className="font-body text-[10px] font-bold uppercase text-muted">.{f}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- SVG serializer ---------- */
function toSvg(doc: Doc, T: (s: string) => string, qr: Record<string, string>): string {
  const { W, H } = docPx(doc);
  const parts: string[] = [`<rect width="${W}" height="${H}" fill="${esc(doc.bg)}"/>`];
  doc.elements.forEach((e) => {
    const tf = e.rot ? ` transform="rotate(${e.rot} ${e.x + e.w / 2} ${e.y + e.h / 2})"` : '';
    const op = e.opacity < 1 ? ` opacity="${e.opacity}"` : '';
    if (e.type === 'rect') parts.push(`<rect x="${e.x}" y="${e.y}" width="${e.w}" height="${e.h}" rx="${e.radius || 0}" fill="${esc(e.fill || 'none')}" stroke="${esc(e.stroke || 'none')}" stroke-width="${e.strokeWidth || 0}"${tf}${op}/>`);
    else if (e.type === 'ellipse') parts.push(`<ellipse cx="${e.x + e.w / 2}" cy="${e.y + e.h / 2}" rx="${e.w / 2}" ry="${e.h / 2}" fill="${esc(e.fill || 'none')}" stroke="${esc(e.stroke || 'none')}" stroke-width="${e.strokeWidth || 0}"${tf}${op}/>`);
    else if (e.type === 'line') parts.push(`<line x1="${e.x}" y1="${e.y + e.h / 2}" x2="${e.x + e.w}" y2="${e.y + e.h / 2}" stroke="${esc(e.stroke || '#000')}" stroke-width="${e.strokeWidth || 2}"${tf}${op}/>`);
    else if (e.type === 'image' && e.src) parts.push(`<image x="${e.x}" y="${e.y}" width="${e.w}" height="${e.h}" href="${e.src}" preserveAspectRatio="${e.fit === 'cover' ? 'xMidYMid slice' : e.fit === 'fill' ? 'none' : 'xMidYMid meet'}"${tf}${op}/>`);
    else if (e.type === 'qr') { const url = qr[`${T(e.qrValue || '')}|${e.color || '#000000'}`]; if (url) parts.push(`<image x="${e.x}" y="${e.y}" width="${e.w}" height="${e.h}" href="${url}"${tf}${op}/>`); }
    else if (e.type === 'text') {
      const fs = e.fontSize || 14, lh = (e.lineHeight || 1.3) * fs;
      const anchor = e.align === 'center' ? 'middle' : e.align === 'right' ? 'end' : 'start';
      const tx = e.align === 'center' ? e.x + e.w / 2 : e.align === 'right' ? e.x + e.w : e.x;
      const lines = T(e.text || '').split('\n');
      const spans = lines.map((ln, i) => `<tspan x="${tx}" dy="${i === 0 ? fs : lh}">${esc(ln) || ' '}</tspan>`).join('');
      parts.push(`<text x="${tx}" y="${e.y}" font-family="${esc(e.fontFamily || 'Outfit')}, sans-serif" font-size="${fs}" font-weight="${e.fontWeight || 400}"${e.italic ? ' font-style="italic"' : ''}${e.underline ? ' text-decoration="underline"' : ''} fill="${esc(e.color || '#111')}" text-anchor="${anchor}"${e.letterSpacing ? ` letter-spacing="${e.letterSpacing}"` : ''}${tf}${op}>${spans}</text>`);
    }
  });
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">${parts.join('')}</svg>`;
}

export const useDocTemplates = () => useMemo(() => TEMPLATES, []);
