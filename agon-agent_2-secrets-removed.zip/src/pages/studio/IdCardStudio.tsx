import { useState, useEffect, useRef, useMemo, useCallback, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import { IdCard, Save, Trash2, Image as ImageIcon, Wand2, RotateCcw, Users, Layers, Printer, FolderOpen, QrCode, Barcode, X, Check } from 'lucide-react';
import QRCode from 'qrcode';
import JsBarcode from 'jsbarcode';
import { api } from '../../lib/api';
import { useAssets, readFileAsDataUrl, fitImage, removeBackground, captureNode, canvasToPdf, downloadDataUrl, jsPDF } from '../../studio/lib';
import { ExportMenu } from './DocumentStudio';
import Select from '../../shared/Select';
import { Modal, Badge, Skeleton, btnPrimary, btnGhost, inputCls, labelCls } from '../../shared/primitives';
import type { OrgPerson } from '../org/orgData';

/* ============================================================
   ID Card Generator — CR80 (85.6 × 54 mm) badges, portrait or
   landscape, 4 layouts, live QR (vCard / JSON / URL) + CODE128
   barcode, photo with background removal, front & back, PNG /
   PDF export at true size and batch print sheets for the roster.
   ============================================================ */

type Layout = 'band' | 'split' | 'minimal' | 'gradient';
interface Design {
  layout: Layout; orientation: 'portrait' | 'landscape'; accent: string; bg: string; ink: string;
  company: string; tagline: string; address: string; terms: string; website: string;
  showQr: boolean; qrMode: 'vcard' | 'json' | 'url'; qrUrl: string;
  showBarcode: boolean; barcodeMode: 'empno' | 'email' | 'custom'; barcodeCustom: string;
  logo: string | null; validUntil: string; signatory: string;
}
interface Holder { name: string; empNo: string; role: string; dept: string; email: string; location: string; joined: string; phone: string; blood: string; emergency: string; photo: string | null; photoOriginal: string | null }

const DEFAULT_DESIGN: Design = {
  layout: 'band', orientation: 'portrait', accent: '#0d7a54', bg: '#ffffff', ink: '#101914',
  company: 'Aviary Technologies', tagline: 'People OS', address: 'Prestige Tech Park, Tower B, Bengaluru 560103, India',
  terms: 'This card is the property of the company and must be returned on request. If found, please return to the address above or email people@aviary.io.',
  website: 'aviary.io', showQr: true, qrMode: 'vcard', qrUrl: 'https://aviary.io/verify/{{empNo}}',
  showBarcode: true, barcodeMode: 'empno', barcodeCustom: '', logo: null, validUntil: `Dec ${new Date().getFullYear() + 2}`, signatory: 'Ananya Rao · Head of People',
};
const DEFAULT_HOLDER: Holder = { name: 'Asha Verma', empNo: 'AV-1042', role: 'Senior Software Engineer', dept: 'Engineering', email: 'asha.verma@aviary.io', location: 'Bengaluru HQ', joined: '2022-03-14', phone: '+91 98765 43210', blood: 'B+', emergency: 'Ravi Verma · +91 98123 45678', photo: null, photoOriginal: null };

const LAYOUTS: { key: Layout; name: string; desc: string }[] = [
  { key: 'band', name: 'Classic band', desc: 'Brand band, round photo, QR' },
  { key: 'split', name: 'Split column', desc: 'Colour column with photo' },
  { key: 'minimal', name: 'Minimal', desc: 'Clean white with accent rule' },
  { key: 'gradient', name: 'Gradient', desc: 'Deep gradient, light type' },
];
/* CR80 at 4 css-px per mm */
const MM = 4;
const CARD_W = 85.6 * MM, CARD_H = 54 * MM;

const initials = (n: string) => n.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
const vcard = (h: Holder, d: Design) => `BEGIN:VCARD\nVERSION:3.0\nN:${h.name.split(' ').slice(1).join(' ')};${h.name.split(' ')[0]}\nFN:${h.name}\nORG:${d.company}\nTITLE:${h.role}\nEMAIL:${h.email}\nTEL:${h.phone}\nNOTE:Employee ${h.empNo} · ${h.dept}\nURL:https://${d.website}\nEND:VCARD`;
const qrPayload = (h: Holder, d: Design) => d.qrMode === 'vcard' ? vcard(h, d) : d.qrMode === 'json' ? JSON.stringify({ id: h.empNo, name: h.name, role: h.role, dept: h.dept, company: d.company }) : d.qrUrl.replace('{{empNo}}', h.empNo);
const barcodeValue = (h: Holder, d: Design) => (d.barcodeMode === 'empno' ? h.empNo : d.barcodeMode === 'email' ? h.email : d.barcodeCustom || h.empNo);

function useQr(text: string, dark: string, enabled: boolean) {
  const [url, setUrl] = useState('');
  useEffect(() => {
    if (!enabled) { setUrl(''); return; }
    let alive = true;
    QRCode.toDataURL(text || ' ', { margin: 0, width: 400, errorCorrectionLevel: 'M', color: { dark, light: '#00000000' } }).then((u) => { if (alive) setUrl(u); }).catch(() => {});
    return () => { alive = false; };
  }, [text, dark, enabled]);
  return url;
}
function useBarcode(value: string, color: string, enabled: boolean) {
  const [url, setUrl] = useState('');
  useEffect(() => {
    if (!enabled) { setUrl(''); return; }
    try {
      const cv = document.createElement('canvas');
      JsBarcode(cv, value || '0', { format: 'CODE128', displayValue: false, margin: 0, width: 3, height: 60, background: 'rgba(0,0,0,0)', lineColor: color });
      setUrl(cv.toDataURL('image/png'));
    } catch { setUrl(''); }
  }, [value, color, enabled]);
  return url;
}

/* ---------- the card faces ---------- */
function CardFace({ side, d, h, qr, bc, scale = 1 }: { side: 'front' | 'back'; d: Design; h: Holder; qr: string; bc: string; scale?: number }) {
  const portrait = d.orientation === 'portrait';
  const W = portrait ? CARD_H : CARD_W, H = portrait ? CARD_W : CARD_H;
  const light = d.layout === 'gradient';
  const ink = light ? '#ffffff' : d.ink;
  const muted = light ? 'rgba(255,255,255,0.72)' : 'rgba(16,25,20,0.58)';
  const bg = d.layout === 'gradient' ? `linear-gradient(150deg, ${d.accent}, ${d.ink})` : d.bg;
  const font = { fontFamily: '"Outfit", system-ui, sans-serif' };
  const photo = (size: number, round = true) => (
    <div style={{ width: size, height: size, borderRadius: round ? '50%' : 10, overflow: 'hidden', background: light ? 'rgba(255,255,255,0.18)' : `${d.accent}22`, border: `3px solid ${light ? 'rgba(255,255,255,0.7)' : d.bg}`, boxShadow: '0 4px 12px rgba(0,0,0,0.18)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
      {h.photo ? <img src={h.photo} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ ...font, fontWeight: 700, fontSize: size * 0.36, color: light ? '#fff' : d.accent }}>{initials(h.name)}</span>}
    </div>
  );
  const logo = (size: number, onDark: boolean) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      {d.logo ? <img src={d.logo} alt="" style={{ height: size, maxWidth: size * 3, objectFit: 'contain' }} /> : (
        <span style={{ width: size, height: size, borderRadius: size * 0.3, background: onDark ? 'rgba(255,255,255,0.2)' : d.accent, display: 'grid', placeItems: 'center' }}>
          <svg viewBox="0 0 64 64" width={size * 0.7} height={size * 0.7}><path d="M20 44 C22 30 30 20 46 17 C45 30 38 41 25 44 L20 44 Z" fill={onDark ? '#fff' : '#d9f96a'} /></svg>
        </span>
      )}
      <span style={{ ...font, lineHeight: 1 }}>
        <span style={{ display: 'block', fontWeight: 800, fontSize: size * 0.5, color: onDark ? '#fff' : d.ink, letterSpacing: -0.2 }}>{d.company}</span>
        <span style={{ display: 'block', fontWeight: 700, fontSize: size * 0.28, color: onDark ? 'rgba(255,255,255,0.7)' : muted, textTransform: 'uppercase', letterSpacing: 1.6, marginTop: 2 }}>{d.tagline}</span>
      </span>
    </div>
  );
  const label = (t: string) => <span style={{ ...font, display: 'block', fontSize: 6.5, fontWeight: 700, letterSpacing: 1.2, textTransform: 'uppercase', color: muted }}>{t}</span>;
  const value = (t: string, fs = 9.5) => <span style={{ ...font, display: 'block', fontSize: fs, fontWeight: 600, color: ink, lineHeight: 1.25 }}>{t}</span>;
  const qrImg = (size: number) => (d.showQr && qr ? <img src={qr} alt="QR" style={{ width: size, height: size, background: light ? '#fff' : 'transparent', padding: light ? 3 : 0, borderRadius: 4 }} /> : null);
  const bcImg = (w: number, h2: number, color?: string) => (d.showBarcode && bc ? <img src={bc} alt="barcode" style={{ width: w, height: h2, objectFit: 'fill', filter: color ? undefined : undefined }} /> : null);

  const frame: React.CSSProperties = { width: W, height: H, background: bg, borderRadius: 3.2 * MM, position: 'relative', overflow: 'hidden', color: ink, transform: scale !== 1 ? `scale(${scale})` : undefined, transformOrigin: 'top left', boxShadow: '0 10px 30px rgba(0,0,0,0.22)' };

  if (side === 'back') {
    return (
      <div style={frame} className="idcard-face">
        <div style={{ position: 'absolute', inset: 0, padding: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>{logo(16, light)}<span style={{ ...font, fontSize: 7.5, fontWeight: 700, color: muted }}>{d.website}</span></div>
          <div style={{ height: 2, background: light ? 'rgba(255,255,255,0.35)' : d.accent, borderRadius: 2 }} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            <div>{label('Emergency contact')}{value(h.emergency, 8)}</div>
            <div>{label('Blood group')}{value(h.blood, 8)}</div>
            <div>{label('Valid until')}{value(d.validUntil, 8)}</div>
            <div>{label('Location')}{value(h.location, 8)}</div>
          </div>
          <p style={{ ...font, fontSize: 6.8, lineHeight: 1.45, color: muted, margin: 0, flex: 1 }}>{d.terms}<br />{d.address}</p>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 10 }}>
            <div style={{ flex: 1 }}>
              {bcImg(Math.min(W - 32, portrait ? W - 32 : W * 0.55), 26)}
              <span style={{ ...font, display: 'block', fontSize: 7, fontWeight: 700, letterSpacing: 1.5, color: muted, marginTop: 2 }}>{barcodeValue(h, d)}</span>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ width: 70, borderTop: `1px solid ${muted}`, marginLeft: 'auto', paddingTop: 2 }}>{label('Authorised signatory')}</div>
              <span style={{ ...font, fontSize: 6.8, fontWeight: 600, color: ink }}>{d.signatory}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (d.layout === 'split') {
    const colW = portrait ? W : W * 0.36;
    return (
      <div style={frame} className="idcard-face">
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: portrait ? 'column' : 'row' }}>
          <div style={{ width: portrait ? '100%' : colW, height: portrait ? H * 0.46 : '100%', background: d.accent, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 12 }}>
            {photo(portrait ? 72 : 64)}
            {qrImg(portrait ? 40 : 44) && <div style={{ background: '#fff', padding: 3, borderRadius: 5 }}>{qrImg(portrait ? 40 : 44)}</div>}
          </div>
          <div style={{ flex: 1, padding: 14, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            {logo(15, false)}
            <div>
              <span style={{ ...font, display: 'block', fontSize: portrait ? 14 : 15, fontWeight: 800, color: d.ink, lineHeight: 1.1 }}>{h.name}</span>
              <span style={{ ...font, display: 'block', fontSize: 8.5, fontWeight: 600, color: d.accent, marginTop: 3 }}>{h.role}</span>
              <span style={{ ...font, display: 'block', fontSize: 7.5, color: muted, marginTop: 1 }}>{h.dept} · {h.location}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
              <div>{label('Employee ID')}{value(h.empNo, 10)}</div>
              {bcImg(portrait ? 80 : 70, 18)}
            </div>
          </div>
        </div>
      </div>
    );
  }
  if (d.layout === 'minimal') {
    return (
      <div style={frame} className="idcard-face">
        <div style={{ position: 'absolute', inset: 0, padding: 16, display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>{logo(15, false)}<span style={{ ...font, fontSize: 7, fontWeight: 700, letterSpacing: 1.5, color: muted }}>EMPLOYEE</span></div>
          <div style={{ height: 3, background: d.accent, borderRadius: 2, margin: '10px 0' }} />
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', flex: 1 }}>
            {photo(portrait ? 84 : 76, false)}
            <div style={{ minWidth: 0, flex: 1 }}>
              <span style={{ ...font, display: 'block', fontSize: portrait ? 13 : 15, fontWeight: 800, color: d.ink, lineHeight: 1.1 }}>{h.name}</span>
              <span style={{ ...font, display: 'block', fontSize: 8.5, fontWeight: 600, color: d.accent, marginTop: 3 }}>{h.role}</span>
              <div style={{ display: 'grid', gridTemplateColumns: portrait ? '1fr' : '1fr 1fr', gap: 5, marginTop: 8 }}>
                <div>{label('Department')}{value(h.dept, 8.5)}</div>
                <div>{label('Employee ID')}{value(h.empNo, 8.5)}</div>
                <div>{label('Email')}{value(h.email, 7.5)}</div>
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 10 }}>
            {bcImg(portrait ? W - 32 - 50 : 120, 22)}
            {qrImg(portrait ? 44 : 40)}
          </div>
        </div>
      </div>
    );
  }
  if (d.layout === 'gradient') {
    return (
      <div style={frame} className="idcard-face">
        <div style={{ position: 'absolute', right: -40, top: -50, width: 160, height: 160, borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
        <div style={{ position: 'absolute', inset: 0, padding: 16, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          {logo(15, true)}
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            {photo(portrait ? 78 : 68)}
            <div style={{ minWidth: 0 }}>
              <span style={{ ...font, display: 'block', fontSize: portrait ? 13 : 15, fontWeight: 800, color: '#fff', lineHeight: 1.1 }}>{h.name}</span>
              <span style={{ ...font, display: 'block', fontSize: 8.5, fontWeight: 600, color: '#d9f96a', marginTop: 3 }}>{h.role}</span>
              <span style={{ ...font, display: 'block', fontSize: 7.5, color: 'rgba(255,255,255,0.72)', marginTop: 1 }}>{h.dept} · {h.location}</span>
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div>{label('Employee ID')}{value(h.empNo, 11)}</div>
            {qrImg(portrait ? 46 : 42)}
          </div>
        </div>
      </div>
    );
  }
  // classic band
  const bandH = portrait ? 64 : 46;
  return (
    <div style={frame} className="idcard-face">
      <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: bandH, background: d.accent, padding: '10px 14px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        {logo(15, true)}<span style={{ ...font, fontSize: 7, fontWeight: 700, letterSpacing: 1.5, color: 'rgba(255,255,255,0.8)' }}>{h.empNo}</span>
      </div>
      <div style={{ position: 'absolute', inset: 0, padding: 14, paddingTop: bandH - (portrait ? 30 : 24), display: 'flex', flexDirection: portrait ? 'column' : 'row', alignItems: portrait ? 'center' : 'flex-start', gap: portrait ? 8 : 12 }}>
        {photo(portrait ? 76 : 64)}
        <div style={{ textAlign: portrait ? 'center' : 'left', minWidth: 0, flex: 1, paddingTop: portrait ? 0 : 26 }}>
          <span style={{ ...font, display: 'block', fontSize: portrait ? 14 : 15, fontWeight: 800, color: d.ink, lineHeight: 1.1 }}>{h.name}</span>
          <span style={{ ...font, display: 'block', fontSize: 8.5, fontWeight: 600, color: d.accent, marginTop: 3 }}>{h.role}</span>
          <span style={{ ...font, display: 'block', fontSize: 7.5, color: muted, marginTop: 1 }}>{h.dept} · {h.location}</span>
          {!portrait && <div style={{ display: 'flex', gap: 10, marginTop: 8, alignItems: 'flex-end' }}>{bcImg(96, 18)}<div>{label('Valid until')}{value(d.validUntil, 7.5)}</div></div>}
        </div>
        {portrait ? (
          <div style={{ marginTop: 'auto', width: '100%', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 8 }}>
            <div>{bcImg(110, 20)}<span style={{ ...font, display: 'block', fontSize: 6.5, color: muted, marginTop: 2 }}>{d.website}</span></div>
            {qrImg(44)}
          </div>
        ) : <div style={{ paddingTop: 30 }}>{qrImg(46)}</div>}
      </div>
    </div>
  );
}

/* ============================================================ */
export default function IdCardStudio() {
  const [design, setDesign] = useState<Design>(DEFAULT_DESIGN);
  const [holder, setHolder] = useState<Holder>(DEFAULT_HOLDER);
  const [side, setSide] = useState<'front' | 'back'>('front');
  const [people, setPeople] = useState<OrgPerson[]>([]);
  const [batch, setBatch] = useState<Set<number>>(new Set());
  const [batchOpen, setBatchOpen] = useState(false);
  const [batchQ, setBatchQ] = useState('');
  const [toast, setToast] = useState('');
  const [busy, setBusy] = useState('');
  const [bgTol, setBgTol] = useState(34);
  const [savedId, setSavedId] = useState<number | null>(null);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState('Aviary badge');
  const frontRef = useRef<HTMLDivElement>(null);
  const backRef = useRef<HTMLDivElement>(null);
  const batchRef = useRef<HTMLDivElement>(null);
  const [batchRender, setBatchRender] = useState<Holder[] | null>(null);
  const assets = useAssets<Design>('idcard');
  const notify = (m: string) => { setToast(m); setTimeout(() => setToast(''), 2400); };

  useEffect(() => { api<OrgPerson[]>('organization?resource=people').then(setPeople).catch(() => setPeople([])); }, []);

  const light = design.layout === 'gradient';
  const qr = useQr(qrPayload(holder, design), light ? design.ink : design.ink, design.showQr);
  const bc = useBarcode(barcodeValue(holder, design), light ? '#ffffff' : design.ink, design.showBarcode);

  const fromPerson = useCallback((p: OrgPerson): Holder => ({
    ...DEFAULT_HOLDER, name: p.full_name, empNo: `AV-${1000 + p.id}`, role: p.role, dept: p.dept, email: p.email, location: p.location, joined: p.joined,
    phone: DEFAULT_HOLDER.phone, blood: ['A+', 'B+', 'O+', 'AB+', 'O-'][p.id % 5], emergency: DEFAULT_HOLDER.emergency, photo: null, photoOriginal: null,
  }), []);

  const setD = (p: Partial<Design>) => setDesign((d) => ({ ...d, ...p }));
  const setH = (p: Partial<Holder>) => setHolder((h) => ({ ...h, ...p }));

  const upload = async (f: File, what: 'photo' | 'logo') => {
    const src = await fitImage(await readFileAsDataUrl(f), what === 'photo' ? 900 : 600);
    if (what === 'photo') setH({ photo: src, photoOriginal: src }); else setD({ logo: src });
  };
  const cutout = async () => {
    const src = holder.photoOriginal || holder.photo; if (!src) return;
    setBusy('Removing background…');
    try { setH({ photo: await removeBackground(src, { tolerance: bgTol, feather: 1 }) }); } finally { setBusy(''); }
  };

  const portrait = design.orientation === 'portrait';
  const cardW = portrait ? CARD_H : CARD_W, cardH = portrait ? CARD_W : CARD_H;
  const mmW = portrait ? 54 : 85.6, mmH = portrait ? 85.6 : 54;

  const exportAs = async (fmt: string, dpi: number) => {
    const s = dpi / 25.4 / MM; // the card is MM css-px per mm → device pixels per css px at the chosen dpi
    const name = holder.name.toLowerCase().replace(/\s+/g, '-');
    setBusy(`Exporting ${fmt.toUpperCase()}…`);
    try {
      const f = frontRef.current!, b = backRef.current!;
      const [cf, cb] = await Promise.all([captureNode(f, s, null), captureNode(b, s, null)]);
      if (fmt === 'png') { downloadDataUrl(`id-${name}-front.png`, cf.toDataURL('image/png')); downloadDataUrl(`id-${name}-back.png`, cb.toDataURL('image/png')); }
      else if (fmt === 'jpg') { downloadDataUrl(`id-${name}-front.jpg`, cf.toDataURL('image/jpeg', 0.94)); downloadDataUrl(`id-${name}-back.jpg`, cb.toDataURL('image/jpeg', 0.94)); }
      else if (fmt === 'pdf') canvasToPdf([cf, cb], mmW, mmH, `id-${name}.pdf`);
    } catch (e) { notify(e instanceof Error ? e.message : 'Export failed'); }
    finally { setBusy(''); }
  };

  /* batch print sheet: A4, cards laid out in a grid with 4 mm gutters, fronts then backs (mirrored for duplex) */
  const runBatch = async () => {
    const list = people.filter((p) => batch.has(p.id)).map(fromPerson);
    if (!list.length) { notify('Pick at least one employee'); return; }
    setBatchOpen(false);
    setBatchRender(list);
    setBusy(`Rendering ${list.length} cards…`);
    await new Promise((r) => setTimeout(r, 700)); // let QR/barcode images resolve
    try {
      const nodes = Array.from(batchRef.current?.querySelectorAll<HTMLElement>('.batch-card') || []);
      const s = 300 / 25.4 / MM;
      const pdf = new jsPDF({ unit: 'mm', format: 'a4', compress: true });
      const pageW = 210, pageH = 297, gutter = 4, margin = 10;
      const cols = Math.floor((pageW - margin * 2 + gutter) / (mmW + gutter));
      const rows = Math.floor((pageH - margin * 2 + gutter) / (mmH + gutter));
      const perPage = cols * rows;
      const place = async (faces: HTMLElement[], mirror: boolean) => {
        for (let i = 0; i < faces.length; i++) {
          if (i > 0 && i % perPage === 0) pdf.addPage();
          const k = i % perPage;
          const c = mirror ? cols - 1 - (k % cols) : k % cols, r = Math.floor(k / cols);
          const cv = await captureNode(faces[i], s, null);
          pdf.addImage(cv.toDataURL('image/jpeg', 0.93), 'JPEG', margin + c * (mmW + gutter), margin + r * (mmH + gutter), mmW, mmH);
        }
      };
      const fronts = nodes.filter((n) => n.dataset.side === 'front'), backs = nodes.filter((n) => n.dataset.side === 'back');
      await place(fronts, false);
      pdf.addPage();
      await place(backs, true);
      pdf.save(`id-cards-batch-${list.length}.pdf`);
      notify(`Print sheet ready · ${list.length} cards`);
    } catch (e) { notify(e instanceof Error ? e.message : 'Batch failed'); }
    finally { setBusy(''); setBatchRender(null); }
  };

  const saveDesign = async () => {
    try { const a = await assets.save(saveName, design, savedId || undefined); setSavedId(a.id); setSaveOpen(false); notify('Design saved'); }
    catch (e) { notify(e instanceof Error ? e.message : 'Save failed'); }
  };

  const Field = ({ label, children }: { label: string; children: ReactNode }) => (<div><label className={labelCls}>{label}</label>{children}</div>);
  const Color = ({ v, on }: { v: string; on: (c: string) => void }) => (
    <div className="tk-inset flex items-center gap-2 rounded-xl px-2 py-1.5">
      <input type="color" value={v} onChange={(ev) => on(ev.target.value)} className="h-6 w-8 cursor-pointer rounded border-0 bg-transparent" />
      <input value={v} onChange={(ev) => on(ev.target.value)} className="w-full bg-transparent font-body text-[12px] text-ink outline-none" />
    </div>
  );
  const Toggle = ({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) => (
    <button onClick={onClick} className="flex w-full items-center justify-between rounded-xl px-1 py-1.5">
      <span className="font-body text-[12.5px] font-semibold text-ink">{label}</span>
      <span className={`relative h-5 w-9 rounded-full transition ${on ? 'bg-(--t-accent)' : 'tk-inset'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} /></span>
    </button>
  );
  const filteredPeople = useMemo(() => people.filter((p) => !batchQ.trim() || `${p.full_name} ${p.dept} ${p.role}`.toLowerCase().includes(batchQ.toLowerCase())), [people, batchQ]);

  const previewScale = Math.min(1.9, portrait ? 520 / cardW : 620 / cardW);

  return (
    <div className="space-y-4">
      {toast && <div className="fixed left-1/2 top-20 z-[80] -translate-x-1/2 rounded-full bg-ink px-5 py-2.5 font-body text-[13px] font-bold text-paper shadow-xl">{toast}</div>}
      {busy && <div className="fixed bottom-6 left-1/2 z-[80] -translate-x-1/2 rounded-full bg-ink/90 px-4 py-2 font-body text-[12px] font-bold text-paper">{busy}</div>}

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-body text-[12px] font-bold uppercase tracking-[0.18em] text-primary">Studio · ID cards</p>
          <h1 className="mt-1 flex items-center gap-2.5 font-display text-2xl font-semibold tracking-tight text-ink">
            <span className="tk-raise-sm flex h-9 w-9 items-center justify-center rounded-xl text-primary"><IdCard size={17} /></span>
            ID card generator
          </h1>
          <p className="mt-1 font-body text-[13px] text-muted">CR80 badges with live QR & barcode, front and back, print-ready at true size.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={() => setBatchOpen(true)} className={btnGhost + ' !py-2 text-[12px]'}><Printer size={13} /> Batch print sheet</button>
          <button onClick={() => setSaveOpen(true)} className={btnGhost + ' !py-2 text-[12px]'}><Save size={13} /> Save design</button>
          <ExportMenu onPick={exportAs} formats={['png', 'jpg', 'pdf']} />
        </div>
      </motion.div>

      <div className="grid gap-4 xl:grid-cols-[290px_1fr_280px]">
        {/* ---------- LEFT: holder ---------- */}
        <div className="tk-card h-fit space-y-3 p-4 xl:sticky xl:top-20">
          <p className="flex items-center gap-2 font-display text-[14px] font-semibold text-ink"><Users size={14} className="text-primary" /> Card holder</p>
          <Field label="Pick from roster"><Select options={people.map((p) => ({ value: String(p.id), label: p.full_name, hint: p.dept }))} value={null} onChange={(v) => { const p = people.find((x) => String(x.id) === v); if (p) { setHolder(fromPerson(p)); notify(`Loaded ${p.full_name}`); } }} placeholder={people.length ? 'Search employees…' : 'Loading…'} /></Field>
          <div className="flex items-center gap-3">
            <div className="tk-inset flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-2xl" style={{ background: 'repeating-conic-gradient(#d8dbd5 0 25%, #eceee9 0 50%) 0 0 / 12px 12px' }}>
              {holder.photo ? <img src={holder.photo} alt="" className="h-full w-full object-cover" /> : <span className="font-display text-lg font-bold text-primary">{initials(holder.name)}</span>}
            </div>
            <div className="flex-1 space-y-1.5">
              <label className={btnGhost + ' w-full cursor-pointer !py-1.5 text-[11.5px]'}><ImageIcon size={12} /> Upload photo<input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f, 'photo'); e.target.value = ''; }} /></label>
              <div className="flex gap-1.5">
                <button onClick={cutout} disabled={!holder.photo || !!busy} className={btnPrimary + ' flex-1 !py-1.5 text-[11.5px] disabled:opacity-40'}><Wand2 size={12} /> Cut out</button>
                {holder.photoOriginal && holder.photoOriginal !== holder.photo && <button onClick={() => setH({ photo: holder.photoOriginal })} className={btnGhost + ' !py-1.5 text-[11.5px]'} data-tip="Restore"><RotateCcw size={12} /></button>}
              </div>
            </div>
          </div>
          {holder.photo && <div><label className={labelCls}>Cut-out tolerance · {bgTol}</label><input type="range" min={6} max={110} value={bgTol} onChange={(e) => setBgTol(+e.target.value)} className="tk-range w-full" /></div>}
          {([['name', 'Full name'], ['empNo', 'Employee ID'], ['role', 'Job title'], ['dept', 'Department'], ['email', 'Email'], ['location', 'Location'], ['phone', 'Phone'], ['blood', 'Blood group'], ['emergency', 'Emergency contact']] as const).map(([k, l]) => (
            <Field key={k} label={l}><input value={holder[k]} onChange={(e) => setH({ [k]: e.target.value } as Partial<Holder>)} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
          ))}
        </div>

        {/* ---------- CENTER: preview ---------- */}
        <div className="min-w-0 space-y-3">
          <div className="tk-card flex flex-wrap items-center gap-2 px-3 py-2">
            <div className="tk-inset flex gap-0.5 p-1">
              {(['front', 'back'] as const).map((s) => <button key={s} onClick={() => setSide(s)} className={`rounded-lg px-3 py-1 font-body text-[11.5px] font-bold capitalize transition ${side === s ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}>{s}</button>)}
            </div>
            <div className="tk-inset flex gap-0.5 p-1">
              {(['portrait', 'landscape'] as const).map((o) => <button key={o} onClick={() => setD({ orientation: o })} className={`rounded-lg px-3 py-1 font-body text-[11.5px] font-bold capitalize transition ${design.orientation === o ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}>{o}</button>)}
            </div>
            <span className="ml-auto font-body text-[11.5px] text-muted">CR80 · {mmW} × {mmH} mm</span>
          </div>
          <div className="tk-inset flex min-h-[520px] items-center justify-center overflow-auto rounded-2xl p-8">
            <div style={{ width: cardW * previewScale, height: cardH * previewScale, position: 'relative' }}>
              <motion.div key={side} initial={{ rotateY: 90, opacity: 0 }} animate={{ rotateY: 0, opacity: 1 }} transition={{ duration: 0.35 }} style={{ position: 'absolute', inset: 0 }}>
                <div style={{ display: side === 'front' ? 'block' : 'none' }}><CardFace side="front" d={design} h={holder} qr={qr} bc={bc} scale={previewScale} /></div>
                <div style={{ display: side === 'back' ? 'block' : 'none' }}><CardFace side="back" d={design} h={holder} qr={qr} bc={bc} scale={previewScale} /></div>
              </motion.div>
            </div>
          </div>
          {/* export sources at natural size (kept off-screen, both faces always mounted) */}
          <div style={{ position: 'fixed', left: -4000, top: 0 }} aria-hidden>
            <div ref={frontRef}><CardFace side="front" d={design} h={holder} qr={qr} bc={bc} /></div>
            <div ref={backRef}><CardFace side="back" d={design} h={holder} qr={qr} bc={bc} /></div>
            {batchRender && (
              <div ref={batchRef}>
                {batchRender.map((h) => <BatchPair key={h.empNo} d={design} h={h} />)}
              </div>
            )}
          </div>
          <p className="font-body text-[11px] text-muted">Exports render both faces at the DPI you choose; PDF pages are exactly {mmW} × {mmH} mm. Batch sheets tile the roster on A4 with mirrored backs for duplex printing.</p>
        </div>

        {/* ---------- RIGHT: design ---------- */}
        <div className="tk-card h-fit space-y-3 p-4 xl:sticky xl:top-20">
          <p className="flex items-center gap-2 font-display text-[14px] font-semibold text-ink"><Layers size={14} className="text-primary" /> Design</p>
          <div className="grid grid-cols-2 gap-1.5">
            {LAYOUTS.map((l) => (
              <button key={l.key} onClick={() => setD({ layout: l.key })} className={`tk-raise-sm rounded-xl p-2 text-left transition hover:-translate-y-0.5 ${design.layout === l.key ? 'ring-2 ring-(--t-accent)' : ''}`}>
                <span className="block font-body text-[12px] font-bold text-ink">{l.name}</span><span className="block font-body text-[10px] text-muted">{l.desc}</span>
              </button>
            ))}
          </div>
          <div className="grid grid-cols-1 gap-2">
            <Field label="Accent"><Color v={design.accent} on={(c) => setD({ accent: c })} /></Field>
            <Field label="Card background"><Color v={design.bg} on={(c) => setD({ bg: c })} /></Field>
            <Field label="Text / ink"><Color v={design.ink} on={(c) => setD({ ink: c })} /></Field>
          </div>
          <Field label="Company"><input value={design.company} onChange={(e) => setD({ company: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Tagline"><input value={design.tagline} onChange={(e) => setD({ tagline: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
            <Field label="Website"><input value={design.website} onChange={(e) => setD({ website: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
          </div>
          <label className={btnGhost + ' w-full cursor-pointer !py-1.5 text-[11.5px]'}><ImageIcon size={12} /> {design.logo ? 'Replace logo' : 'Upload logo'}<input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f, 'logo'); e.target.value = ''; }} /></label>
          {design.logo && <button onClick={() => setD({ logo: null })} className="font-body text-[11px] font-bold text-rose-500 hover:underline">Remove logo</button>}
          <div className="border-t tk-divider pt-2">
            <Toggle on={design.showQr} onClick={() => setD({ showQr: !design.showQr })} label="QR code" />
            {design.showQr && (
              <div className="space-y-2 pb-2 pl-1">
                <Select options={[{ value: 'vcard', label: 'vCard (save contact)' }, { value: 'json', label: 'JSON record' }, { value: 'url', label: 'Verification URL' }]} value={design.qrMode} onChange={(v) => v && setD({ qrMode: v as Design['qrMode'] })} searchable={false} />
                {design.qrMode === 'url' && <input value={design.qrUrl} onChange={(e) => setD({ qrUrl: e.target.value })} className={inputCls + ' !py-1.5 text-[12px]'} placeholder="https://… use {{empNo}}" />}
              </div>
            )}
            <Toggle on={design.showBarcode} onClick={() => setD({ showBarcode: !design.showBarcode })} label="Barcode (CODE128)" />
            {design.showBarcode && (
              <div className="space-y-2 pb-2 pl-1">
                <Select options={[{ value: 'empno', label: 'Employee ID' }, { value: 'email', label: 'Email' }, { value: 'custom', label: 'Custom value' }]} value={design.barcodeMode} onChange={(v) => v && setD({ barcodeMode: v as Design['barcodeMode'] })} searchable={false} />
                {design.barcodeMode === 'custom' && <input value={design.barcodeCustom} onChange={(e) => setD({ barcodeCustom: e.target.value })} className={inputCls + ' !py-1.5 text-[12px]'} placeholder="Value to encode" />}
              </div>
            )}
          </div>
          <Field label="Valid until"><input value={design.validUntil} onChange={(e) => setD({ validUntil: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
          <Field label="Signatory (back)"><input value={design.signatory} onChange={(e) => setD({ signatory: e.target.value })} className={inputCls + ' !py-1.5 text-[12.5px]'} /></Field>
          <Field label="Address (back)"><textarea rows={2} value={design.address} onChange={(e) => setD({ address: e.target.value })} className={inputCls + ' text-[12px]'} /></Field>
          <Field label="Terms (back)"><textarea rows={3} value={design.terms} onChange={(e) => setD({ terms: e.target.value })} className={inputCls + ' text-[12px]'} /></Field>
          <div className="border-t tk-divider pt-3">
            <p className="mb-2 flex items-center gap-1.5 font-body text-[10.5px] font-bold uppercase tracking-wider text-muted"><FolderOpen size={11} /> Saved designs</p>
            {assets.loading && <Skeleton className="h-9 w-full rounded-xl" />}
            {!assets.loading && assets.items.length === 0 && <p className="font-body text-[11.5px] text-muted">None yet — save this one.</p>}
            <div className="space-y-1">
              {assets.items.map((a) => (
                <div key={a.id} className={`flex items-center gap-2 rounded-lg px-2 py-1.5 ${savedId === a.id ? 'tk-inset' : ''}`}>
                  <button onClick={() => { setDesign({ ...DEFAULT_DESIGN, ...a.payload }); setSavedId(a.id); setSaveName(a.name); notify(`Loaded “${a.name}”`); }} className="min-w-0 flex-1 truncate text-left font-body text-[12px] font-bold text-ink">{a.name}</button>
                  <span className="h-3 w-3 rounded-full" style={{ background: a.payload.accent }} />
                  <button onClick={() => assets.remove(a.id).then(() => notify('Deleted'))} className="text-muted hover:text-rose-500"><Trash2 size={12} /></button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ---------- batch modal ---------- */}
      <Modal open={batchOpen} onClose={() => setBatchOpen(false)} title="Batch print sheet" wide>
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <input value={batchQ} onChange={(e) => setBatchQ(e.target.value)} placeholder="Filter employees…" className={inputCls + ' max-w-xs !py-2 text-[12.5px]'} />
            <button onClick={() => setBatch(new Set(filteredPeople.map((p) => p.id)))} className={btnGhost + ' !py-2 text-[12px]'}>Select shown</button>
            <button onClick={() => setBatch(new Set())} className={btnGhost + ' !py-2 text-[12px]'}>Clear</button>
            <Badge tone="green">{batch.size} selected</Badge>
          </div>
          <div className="tk-inset max-h-[46vh] overflow-auto rounded-xl p-2">
            <div className="grid gap-1 sm:grid-cols-2 lg:grid-cols-3">
              {filteredPeople.map((p) => {
                const on = batch.has(p.id);
                return (
                  <button key={p.id} onClick={() => setBatch((s) => { const n = new Set(s); if (n.has(p.id)) n.delete(p.id); else n.add(p.id); return n; })}
                    className={`flex items-center gap-2 rounded-lg px-2.5 py-2 text-left transition ${on ? 'tk-raise-sm text-primary' : 'text-ink/80 hover:text-ink'}`}>
                    <span className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${on ? 'border-(--t-accent) bg-(--t-accent) text-white' : 'border-ink/30'}`}>{on && <Check size={11} />}</span>
                    <span className="min-w-0"><span className="block truncate font-body text-[12.5px] font-bold">{p.full_name}</span><span className="block truncate font-body text-[10.5px] text-muted">{p.role} · {p.dept}</span></span>
                  </button>
                );
              })}
            </div>
          </div>
          <p className="font-body text-[11.5px] text-muted">Produces an A4 PDF at 300 dpi: fronts on odd pages, backs mirrored on even pages for duplex printing. Photos are initials unless uploaded per employee.</p>
          <div className="flex justify-end gap-2"><button onClick={() => setBatchOpen(false)} className={btnGhost}><X size={14} /> Cancel</button><button onClick={runBatch} disabled={!batch.size} className={btnPrimary + ' disabled:opacity-50'}><Printer size={14} /> Generate PDF</button></div>
        </div>
      </Modal>

      <Modal open={saveOpen} onClose={() => setSaveOpen(false)} title="Save card design">
        <div className="space-y-3">
          <Field label="Design name"><input value={saveName} onChange={(e) => setSaveName(e.target.value)} className={inputCls} autoFocus /></Field>
          <p className="font-body text-[11.5px] text-muted">Saves layout, colours, company text, QR/barcode settings and logo — not the card holder.</p>
          <div className="flex justify-end gap-2">{savedId && <button onClick={() => { setSavedId(null); saveDesign(); }} className={btnGhost}>Save as copy</button>}<button onClick={saveDesign} disabled={!saveName.trim()} className={btnPrimary + ' disabled:opacity-50'}><Save size={14} /> Save</button></div>
        </div>
      </Modal>
      <span className="hidden"><QrCode size={1} /><Barcode size={1} /></span>
    </div>
  );
}

/** One employee's front + back rendered at natural size for the batch sheet. */
function BatchPair({ d, h }: { d: Design; h: Holder }) {
  const light = d.layout === 'gradient';
  const qr = useQr(qrPayload(h, d), d.ink, d.showQr);
  const bc = useBarcode(barcodeValue(h, d), light ? '#ffffff' : d.ink, d.showBarcode);
  return (
    <>
      <div className="batch-card" data-side="front"><CardFace side="front" d={d} h={h} qr={qr} bc={bc} /></div>
      <div className="batch-card" data-side="back"><CardFace side="back" d={d} h={h} qr={qr} bc={bc} /></div>
    </>
  );
}
