import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { PieChart as PieIcon, RotateCcw, Users, Layers, Crown, Minimize2, Info } from 'lucide-react';
import { useOrgPeople, countBy, distinct } from './org/orgData';
import Chart, { NeuChart, PALETTE, type ChartDatum } from '../shared/Charts';
import Select from '../shared/Select';
import DataTable, { type Column } from '../shared/DataTable';
import { Badge, Skeleton, TileSkeleton, ChartSkeleton, TableSkeleton } from '../shared/primitives';

/* ============================================================
   Pie Chart — standalone page.
   Slices the live people roster (hrms_people) by any dimension and
   renders it as an interactive pie (2D / 3D, export, legend) plus a
   slice breakdown table. Kept as its own page per product request.
   ============================================================ */

type DimKey = 'dept' | 'gender' | 'location' | 'employment_type' | 'worker_type' | 'nationality' | 'business_unit' | 'legal_entity' | 'cost_center' | 'status' | 'role';

const DIMENSIONS: { key: DimKey; label: string }[] = [
  { key: 'dept', label: 'Department' },
  { key: 'gender', label: 'Gender' },
  { key: 'location', label: 'Location' },
  { key: 'employment_type', label: 'Employment Type' },
  { key: 'worker_type', label: 'Worker Type' },
  { key: 'nationality', label: 'Nationality' },
  { key: 'business_unit', label: 'Business Unit' },
  { key: 'legal_entity', label: 'Legal Entity' },
  { key: 'cost_center', label: 'Cost Center' },
  { key: 'status', label: 'Employee Status' },
  { key: 'role', label: 'Job Title' },
];

interface Slice extends ChartDatum { id: number; share: number; color: string }

const Stat = ({ icon: Icon, label, value, tone = 'text-primary' }: { icon: typeof Users; label: string; value: string; tone?: string }) => (
  <div className="tk-card flex items-center gap-3.5 p-4">
    <span className={`tk-inset flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${tone}`}><Icon size={17} /></span>
    <div className="min-w-0">
      <p className="truncate font-display text-[20px] font-semibold leading-none text-ink">{value}</p>
      <p className="mt-1 font-body text-[10.5px] font-bold uppercase tracking-wider text-muted">{label}</p>
    </div>
  </div>
);

export default function PieChart() {
  const { people, loading, error, reload } = useOrgPeople();
  const [dim, setDim] = useState<DimKey>('dept');
  const [scope, setScope] = useState<'active' | 'all'>('active');
  const [focus, setFocus] = useState<string | null>(null); // secondary filter: narrow by department

  const dimMeta = DIMENSIONS.find((d) => d.key === dim)!;

  const rows = useMemo(() => people.filter((p) =>
    (scope === 'all' || p.status !== 'Exited') &&
    (!focus || p.dept === focus)
  ), [people, scope, focus]);

  const slices: Slice[] = useMemo(() => {
    const total = rows.length || 1;
    return countBy(rows, (p) => String((p as unknown as Record<string, string>)[dim] || ''))
      .sort((a, b) => b.value - a.value)
      .map((d, i) => ({ ...d, id: i, share: (d.value / total) * 100, color: PALETTE[i % PALETTE.length] }));
  }, [rows, dim]);

  const reset = () => { setDim('dept'); setScope('active'); setFocus(null); };

  if (loading) {
    return (
      <div className="space-y-5" aria-busy>
        <div>
          <p className="font-body text-[12px] font-bold uppercase tracking-[0.18em] text-primary">Extra page · Visualisation</p>
          <h1 className="mt-1 flex items-center gap-2.5 font-display text-2xl font-semibold tracking-tight text-ink">
            <span className="tk-raise-sm flex h-9 w-9 items-center justify-center rounded-xl text-primary"><PieIcon size={17} /></span>
            Pie chart
          </h1>
        </div>
        <div className="tk-card flex flex-wrap items-center gap-2.5 p-3">
          <Skeleton className="h-9 w-44 rounded-xl" /><Skeleton className="h-9 w-44 rounded-xl" /><Skeleton className="h-9 w-40 rounded-xl" />
          <Skeleton className="ml-auto h-9 w-20 rounded-xl" />
        </div>
        <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">{Array.from({ length: 4 }).map((_, i) => <TileSkeleton key={i} />)}</div>
        <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
          <div className="tk-card p-4"><Skeleton className="mb-3 h-3.5 w-48" /><ChartSkeleton kind="circle" height={380} /></div>
          <div className="tk-card p-4"><Skeleton className="mb-3 h-3.5 w-28" /><ChartSkeleton kind="circle" height={220} /></div>
        </div>
        <div className="tk-card"><TableSkeleton rows={6} cols={3} /></div>
      </div>
    );
  }

  const largest = slices[0];
  const smallest = slices[slices.length - 1];

  const cols: Column<Slice>[] = [
    {
      key: 'label', label: dimMeta.label,
      render: (r) => (
        <span className="flex items-center gap-2.5">
          <span className="h-3 w-3 shrink-0 rounded-full shadow-sm" style={{ background: r.color }} />
          <span className="font-bold text-ink">{r.label}</span>
        </span>
      ),
    },
    { key: 'value', label: 'Headcount', accessor: (r) => r.value, render: (r) => <span className="font-semibold tabular-nums">{r.value}</span> },
    {
      key: 'share', label: 'Share', accessor: (r) => r.share,
      render: (r) => (
        <span className="flex items-center gap-2.5">
          <span className="tk-inset h-2 w-28 overflow-hidden rounded-full">
            <span className="block h-full rounded-full transition-all duration-500" style={{ width: `${r.share}%`, background: r.color }} />
          </span>
          <span className="tabular-nums text-muted">{r.share.toFixed(1)}%</span>
        </span>
      ),
    },
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <div>
        <p className="font-body text-[12px] font-bold uppercase tracking-[0.18em] text-primary">Extra page · Visualisation</p>
        <h1 className="mt-1 flex items-center gap-2.5 font-display text-2xl font-semibold tracking-tight text-ink">
          <span className="tk-raise-sm flex h-9 w-9 items-center justify-center rounded-xl text-primary"><PieIcon size={17} /></span>
          Pie chart
        </h1>
        <p className="mt-1 max-w-2xl font-body text-[13px] leading-relaxed text-muted">
          Live composition of your workforce, sliced any way you like. Data streams straight from the organization roster — switch dimension, narrow to a department or include exited employees, then export from the chart toolbar.
        </p>
      </div>

      {error && (
        <div className="tk-card flex items-center justify-between px-4 py-2.5 font-body text-[13px] text-rose-500">
          <span>{error}</span>
          <button onClick={reload} className="font-bold underline">retry</button>
        </div>
      )}

      {/* controls */}
      <div className="tk-card flex flex-wrap items-center gap-2.5 p-3">
        <Select options={DIMENSIONS.map((d) => ({ value: d.key, label: d.label }))} value={dim}
          onChange={(v) => setDim((v as DimKey) || 'dept')} placeholder="Slice by…" searchable={false} className="w-44" />
        <Select options={distinct(people, (p) => p.dept).map((d) => ({ value: d, label: d }))} value={focus}
          onChange={setFocus} placeholder="All departments" className="w-44" />
        <div className="tk-inset flex gap-0.5 p-1">
          {([['active', 'Active only'], ['all', 'Everyone']] as const).map(([k, l]) => (
            <button key={k} onClick={() => setScope(k)}
              className={`rounded-lg px-3 py-1.5 font-body text-[11.5px] font-bold transition ${scope === k ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}>
              {l}
            </button>
          ))}
        </div>
        <button onClick={reset} className="tk-btn-ghost ml-auto flex items-center gap-1.5 rounded-xl px-3 py-2 font-body text-[12px] font-bold">
          <RotateCcw size={12} /> Reset
        </button>
        <Badge tone="green">{rows.length} in scope</Badge>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
        <Stat icon={Users} label="Employees in scope" value={String(rows.length)} />
        <Stat icon={Layers} label={`${dimMeta.label} slices`} value={String(slices.length)} tone="text-sky-600" />
        <Stat icon={Crown} label="Largest slice" value={largest ? `${largest.label} · ${largest.share.toFixed(0)}%` : '—'} tone="text-gold-deep" />
        <Stat icon={Minimize2} label="Smallest slice" value={smallest ? `${smallest.label} · ${smallest.share.toFixed(0)}%` : '—'} tone="text-rose-500" />
      </div>

      {rows.length === 0 ? (
        <div className="tk-card flex flex-col items-center gap-2 px-6 py-12 text-center">
          <span className="tk-inset flex h-12 w-12 items-center justify-center rounded-2xl text-muted"><Info size={18} /></span>
          <p className="font-display text-[16px] font-semibold text-ink">Nothing to slice</p>
          <p className="max-w-sm font-body text-[12.5px] text-muted">No employees match the current filters. Widen the scope or pick another department.</p>
        </div>
      ) : (
        <>
          {/* charts */}
          <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
            <Chart key={`${dim}-${scope}-${focus}`} title={`Headcount by ${dimMeta.label}${focus ? ` · ${focus}` : ''}`}
              data={slices.map(({ label, value, color }) => ({ label, value, color }))}
              defaultKind="pie" defaultDim="3d" height={380} yLabel="Employees"
              insight={largest && smallest && slices.length > 1 ? [
                `${largest.label} is the biggest ${dimMeta.label.toLowerCase()} group with ${largest.value} people (${largest.share.toFixed(1)}%).`,
                `${smallest.label} is the smallest with ${smallest.value} (${smallest.share.toFixed(1)}%).`,
              ] : undefined} />
            <NeuChart key={`neu-${dim}-${scope}-${focus}`} title={`${dimMeta.label} mix`} defaultKind="pie" legendSide size={150} centerLabel="people"
              data={slices.map(({ label, value, color }) => ({ label, value, color }))} />
          </div>

          {/* slice table */}
          <DataTable<Slice>
            data={slices}
            columns={cols}
            rowKey={(r) => r.id}
            views={['list']}
            pageSize={8}
            onReload={reload}
            exportName={`pie-${dim}`}
            searchKeys={['label']}
            exportDetail={(r) => ({ [dimMeta.label]: r.label, Headcount: r.value, 'Share (%)': r.share.toFixed(1) })}
          />
        </>
      )}

    </motion.div>
  );
}
