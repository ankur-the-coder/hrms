import { useState, useEffect, useRef, useCallback, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

/* ---------- Avatar ---------- */
export function Avatar({ src, name, size = 40 }: { src?: string | null; name: string; size?: number }) {
  const initials = (name || '?').split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  if (src) return <img src={src} alt={name} style={{ width: size, height: size }} className="tk-raise-sm shrink-0 rounded-full object-cover" />;
  return (
    <div style={{ width: size, height: size, fontSize: size * 0.36 }}
      className="tk-raise-sm flex shrink-0 items-center justify-center rounded-full font-body font-semibold text-primary">
      {initials}
    </div>
  );
}

/* ---------- Buttons ---------- */
export const btnPrimary = 'tk-btn-primary inline-flex items-center justify-center gap-2 px-4 py-2.5 font-body text-sm font-semibold';
export const btnGhost = 'tk-btn-ghost inline-flex items-center justify-center gap-2 px-4 py-2.5 font-body text-sm font-semibold';
export const inputCls = 'tk-input w-full px-3.5 py-2.5 font-body text-sm placeholder:text-muted';
export const labelCls = 'mb-1.5 block font-body text-[11px] font-bold uppercase tracking-[0.12em] text-muted';

/* ---------- Badge ---------- */
export function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral' | 'green' | 'amber' | 'red' | 'blue' | 'gold' }) {
  const tones: Record<string, string> = {
    neutral: 'text-muted', green: 'text-primary', amber: 'text-amber-600',
    red: 'text-rose-500', blue: 'text-sky-600', gold: 'text-gold-deep',
  };
  return (
    <span className={`tk-chip inline-flex items-center gap-1 px-2.5 py-0.5 font-body text-[11px] font-bold ${tones[tone]}`}>
      {children}
    </span>
  );
}

/* ---------- Loading ---------- */
export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-14">
      <div className="h-9 w-9 animate-spin rounded-full border-[3px] border-primary/20 border-t-primary" />
      {label && <p className="font-body text-sm text-muted">{label}</p>}
    </div>
  );
}
/* ============================================================
   Shimmer skeletons — the app's loading language.
   Rule of thumb: when the *shape* of the incoming content is known
   (tiles, tables, charts, cards) we shimmer that shape so the layout
   never jumps. The circular NeuLoader is reserved for moments with
   no layout to hint at (auth boot, blocking actions).
   ============================================================ */
export function Skeleton({ className = '', style }: { className?: string; style?: React.CSSProperties }) {
  return <div className={`tk-skeleton ${className}`} style={style} aria-hidden />;
}
export function TableSkeleton({ rows = 6, toolbar = true, cols = 5 }: { rows?: number; toolbar?: boolean; cols?: number }) {
  const widths = [34, 18, 14, 16, 12, 10];
  return (
    <div className="p-4" aria-busy>
      {toolbar && (
        <div className="mb-4 flex items-center gap-3">
          <Skeleton className="h-9 w-56 rounded-xl" />
          <Skeleton className="h-9 w-24 rounded-xl" />
          <Skeleton className="ml-auto h-9 w-28 rounded-xl" />
        </div>
      )}
      <div className="mb-3 flex gap-4 px-2">
        {Array.from({ length: cols }).map((_, i) => <Skeleton key={i} className="h-2.5" style={{ width: `${widths[i % widths.length]}%` }} />)}
      </div>
      <div className="space-y-2">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="flex items-center gap-4 rounded-xl px-2 py-2.5" style={{ opacity: 1 - r * (0.6 / Math.max(1, rows)) }}>
            <Skeleton className="h-4 w-4 rounded" />
            {Array.from({ length: cols }).map((_, c) => (
              <Skeleton key={c} className="h-3" style={{ width: `${widths[c % widths.length] * (c === 0 ? 1 : 0.9)}%` }} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
/** Stat tile placeholder (icon + value + caption). */
export function TileSkeleton() {
  return (
    <div className="tk-card flex items-center gap-3.5 p-4">
      <Skeleton className="h-10 w-10 shrink-0 rounded-xl" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-5 w-14" />
        <Skeleton className="h-2.5 w-24" />
      </div>
    </div>
  );
}
/** Generic card placeholder with a title line and N body lines. */
export function CardSkeleton({ lines = 3, className = '' }: { lines?: number; className?: string }) {
  const w = [92, 70, 84, 60, 76, 66];
  return (
    <div className={`tk-card p-4 ${className}`}>
      <Skeleton className="mb-3 h-3.5 w-2/5" />
      <div className="space-y-2.5">
        {Array.from({ length: lines }).map((_, i) => <Skeleton key={i} className="h-3" style={{ width: `${w[i % w.length]}%` }} />)}
      </div>
    </div>
  );
}
/** Chart-shaped shimmer — mirrors the chart that is about to appear. */
export function ChartSkeleton({ kind = 'columns', height = 240, legend = true }: { kind?: 'circle' | 'bars' | 'columns' | 'line'; height?: number; legend?: boolean }) {
  if (kind === 'circle') {
    const s = Math.max(96, Math.min(height - 24, 190));
    return (
      <div className="flex items-center gap-5" style={{ height }} aria-busy>
        <div className="relative shrink-0 rounded-full tk-skeleton" style={{ width: s, height: s }}>
          <div className="absolute rounded-full" style={{ inset: s * 0.29, background: 'var(--t-surface)' }} />
        </div>
        {legend && (
          <div className="min-w-0 flex-1 space-y-3">
            {[82, 64, 72, 54].map((w, i) => (
              <div key={i} className="flex items-center gap-2.5">
                <Skeleton className="h-2.5 w-2.5 shrink-0 rounded-full" />
                <Skeleton className="h-2.5" style={{ width: `${w}%` }} />
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }
  if (kind === 'bars') {
    const n = Math.max(3, Math.min(7, Math.floor(height / 44)));
    const w = [88, 64, 74, 46, 58, 36, 68];
    return (
      <div className="flex flex-col justify-center gap-3.5" style={{ height }} aria-busy>
        {Array.from({ length: n }).map((_, i) => (
          <div key={i} className="space-y-1.5">
            <div className="flex justify-between"><Skeleton className="h-2.5 w-24" /><Skeleton className="h-2.5 w-8" /></div>
            <Skeleton className="h-4 rounded-full" style={{ width: `${w[i % w.length]}%` }} />
          </div>
        ))}
      </div>
    );
  }
  if (kind === 'line') {
    return (
      <div className="relative" style={{ height }} aria-busy>
        <div className="absolute inset-x-0 bottom-7 top-1 flex items-stretch gap-3">
          <div className="flex w-7 flex-col justify-between py-1">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-2 w-6" />)}</div>
          <Skeleton className="flex-1 rounded-2xl" />
        </div>
        <div className="absolute inset-x-10 bottom-0 flex justify-between">{[0, 1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-2 w-8" />)}</div>
      </div>
    );
  }
  const hs = [46, 72, 58, 88, 64, 78, 40, 66];
  const n = Math.max(4, Math.min(8, Math.floor(280 / 34)));
  return (
    <div className="relative" style={{ height }} aria-busy>
      <div className="absolute inset-x-0 bottom-7 top-1 flex items-end gap-3 pl-8">
        {Array.from({ length: n }).map((_, i) => <Skeleton key={i} className="flex-1 rounded-t-lg" style={{ height: `${hs[i % hs.length]}%`, animationDelay: `${i * 90}ms` }} />)}
      </div>
      <div className="absolute inset-x-8 bottom-0 flex gap-3">{Array.from({ length: n }).map((_, i) => <Skeleton key={i} className="h-2 flex-1" />)}</div>
    </div>
  );
}

/* ---------- Empty ---------- */
export function EmptyState({ icon, title, subtitle }: { icon: ReactNode; title: string; subtitle?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-12 text-center">
      <div className="tk-inset mb-1 flex h-12 w-12 items-center justify-center rounded-2xl text-muted">{icon}</div>
      <p className="font-display text-[15px] font-semibold text-ink/80">{title}</p>
      {subtitle && <p className="max-w-xs font-body text-[13px] text-muted">{subtitle}</p>}
    </div>
  );
}

/* ---------- Modal ---------- */
export function Modal({ open, onClose, title, children, wide = false }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    if (open) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-0 backdrop-blur-[3px] sm:items-center sm:p-6"
          onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) onClose(); }}>
          <motion.div initial={{ y: 40, opacity: 0, scale: 0.98 }} animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 30, opacity: 0, scale: 0.98 }} transition={{ type: 'spring', damping: 26, stiffness: 320 }}
            className={`tk-pop max-h-[92vh] w-full overflow-y-auto rounded-t-3xl sm:rounded-3xl ${wide ? 'sm:max-w-2xl' : 'sm:max-w-lg'}`}>
            <div className="sticky top-0 z-10 flex items-center justify-between border-b tk-divider bg-surface/95 px-6 py-4 backdrop-blur">
              <h2 className="font-display text-lg font-semibold tracking-tight text-ink">{title}</h2>
              <button onClick={onClose} className="rounded-full p-1.5 text-muted transition hover:text-ink"><X size={18} /></button>
            </div>
            <div className="px-6 py-5">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}

/* ---------- Smart flip popover ----------
   Measures available space and opens up when the bottom can't fit. */
export function useFlip(estHeight = 320) {
  const anchorRef = useRef<HTMLDivElement>(null);
  const [dir, setDir] = useState<'down' | 'up'>('down');
  const measure = useCallback(() => {
    const el = anchorRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const below = window.innerHeight - r.bottom;
    setDir(below < estHeight && r.top > below ? 'up' : 'down');
  }, [estHeight]);
  return { anchorRef, dir, measure };
}

export function useIsMobile() {
  const [mobile, setMobile] = useState(() => typeof window !== 'undefined' && (window.innerWidth < 640 || window.matchMedia('(pointer: coarse)').matches));
  useEffect(() => {
    const on = () => setMobile(window.innerWidth < 640 || window.matchMedia('(pointer: coarse)').matches);
    window.addEventListener('resize', on);
    return () => window.removeEventListener('resize', on);
  }, []);
  return mobile;
}

/** Side drawer — slides in from the right; used for entity create/edit forms. */
export function Drawer({ open, onClose, title, children, width = 440 }: { open: boolean; onClose: () => void; title: string; children: ReactNode; width?: number }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    if (open) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-[2px]"
          onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) onClose(); }}>
          <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            style={{ width: `min(${width}px, 94vw)` }}
            className="tk-pop absolute inset-y-0 right-0 !rounded-none !rounded-l-3xl overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between border-b tk-divider bg-surface/95 px-5 py-4 backdrop-blur">
              <h2 className="font-display text-[16px] font-semibold tracking-tight text-ink">{title}</h2>
              <button onClick={onClose} className="rounded-full p-1.5 text-muted transition hover:text-ink"><X size={17} /></button>
            </div>
            <div className="px-5 py-4">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}

/** Global tooltip layer — event-delegated [data-tip], fixed positioning, viewport-clamped.
 *  Mount once in Layout; tooltips can never be clipped by table overflow. */
export function TooltipLayer() {
  const [tip, setTip] = useState<{ text: string; x: number; y: number } | null>(null);
  useEffect(() => {
    let current: HTMLElement | null = null;
    const onOver = (e: MouseEvent) => {
      const el = (e.target as HTMLElement)?.closest?.('[data-tip]') as HTMLElement | null;
      if (!el || el === current) return;
      current = el;
      const text = el.getAttribute('data-tip') || '';
      if (!text) return;
      const r = el.getBoundingClientRect();
      setTip({ text, x: r.left + r.width / 2, y: r.top });
    };
    const onOut = (e: MouseEvent) => {
      if (current && !current.contains(e.relatedTarget as Node)) { current = null; setTip(null); }
    };
    const onHide = () => { current = null; setTip(null); };
    document.addEventListener('mouseover', onOver);
    document.addEventListener('mouseout', onOut);
    document.addEventListener('scroll', onHide, true);
    document.addEventListener('mousedown', onHide);
    return () => {
      document.removeEventListener('mouseover', onOver);
      document.removeEventListener('mouseout', onOut);
      document.removeEventListener('scroll', onHide, true);
      document.removeEventListener('mousedown', onHide);
    };
  }, []);
  if (!tip) return null;
  const w = Math.min(320, tip.text.length * 6.6 + 22);
  const left = Math.max(8, Math.min(tip.x - w / 2, window.innerWidth - w - 8));
  const above = tip.y > 44;
  return createPortal(
    <div className="tk-tooltip" style={{ left, top: above ? undefined : tip.y + 26, bottom: above ? window.innerHeight - tip.y + 8 : undefined }}>
      {tip.text}
    </div>,
    document.body
  );
}

/** Circular neumorphic loader. */
export function NeuLoader({ label, size = 64 }: { label?: string; size?: number }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-14">
      <div className="tk-neuloader" style={{ width: size, height: size }} />
      {label && <p className="font-body text-sm text-muted">{label}</p>}
    </div>
  );
}

/** Popover on desktop (portal + fixed positioning, viewport-clamped so it
 *  never gets clipped by overflow containers), bottom-sheet on mobile. */
export function Popover({ open, onClose, anchorRef, dir, children, width = 320, sheetTitle }: {
  open: boolean; onClose: () => void; anchorRef: React.RefObject<HTMLDivElement | null>;
  dir: 'down' | 'up'; children: ReactNode; width?: number; sheetTitle?: string;
}) {
  const mobile = useIsMobile();
  const popRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top?: number; bottom?: number; width: number } | null>(null);

  useEffect(() => {
    if (!open || mobile) return;
    const update = () => {
      const r = anchorRef.current?.getBoundingClientRect();
      if (!r) return;
      const vw = window.innerWidth;
      const effWidth = Math.min(width, vw - 16);
      const left = Math.min(Math.max(8, r.left), vw - effWidth - 8);
      setPos(dir === 'down'
        ? { left, top: r.bottom + 6, width: effWidth }
        : { left, bottom: window.innerHeight - r.top + 6, width: effWidth });
    };
    update();
    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true);
    return () => { window.removeEventListener('resize', update); window.removeEventListener('scroll', update, true); };
  }, [open, mobile, anchorRef, dir, width]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); onClose(); } };
    const onDown = (e: MouseEvent) => {
      if (mobile) return;
      const t = e.target as Node;
      if (anchorRef.current?.contains(t)) return;
      if (popRef.current?.contains(t)) return;
      onClose();
    };
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('mousedown', onDown);
    return () => { window.removeEventListener('keydown', onKey, true); window.removeEventListener('mousedown', onDown); };
  }, [open, onClose, anchorRef, mobile]);

  if (mobile) {
    return createPortal(
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[150] flex items-end bg-black/40 backdrop-blur-[2px]"
            onMouseDown={(e: React.MouseEvent) => { if (e.target === e.currentTarget) onClose(); }}>
            <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 320 }}
              className="tk-pop max-h-[85vh] w-full overflow-y-auto rounded-t-3xl p-4 pb-6">
              <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-ink/15" />
              {sheetTitle && <p className="mb-2 text-center font-body text-[11px] font-bold uppercase tracking-wider text-muted">{sheetTitle}</p>}
              {children}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>,
      document.body
    );
  }

  return createPortal(
    <AnimatePresence>
      {open && pos && (
        <motion.div ref={popRef}
          initial={{ opacity: 0, y: dir === 'down' ? 6 : -6, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: dir === 'down' ? 6 : -6, scale: 0.98 }}
          transition={{ duration: 0.16 }}
          style={{ position: 'fixed', left: pos.left, top: pos.top, bottom: pos.bottom, width: pos.width, zIndex: 150 }}
          className="tk-pop p-3">
          {children}
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
