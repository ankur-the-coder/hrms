import { useState, useMemo, useRef, useEffect, useCallback, Fragment, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, X, ChevronUp, ChevronDown, ChevronRight, ChevronLeft, MoreHorizontal,
  Columns3, LayoutList, Kanban, Image as ImageIcon, CalendarDays, GanttChartSquare,
  BarChart3, CheckSquare, Inbox, RotateCw, Download, SlidersHorizontal, GripVertical, Plus,
} from 'lucide-react';
import Chart, { MiniDrop, downloadBlob, type ChartDatum } from './Charts';
import { useFlip, Popover, EmptyState, Badge, TableSkeleton, Skeleton, ChartSkeleton, Modal } from './primitives';
import Select from './Select';

/* ============================================================
   Shared DataTable — list / kanban / gallery / calendar /
   timeline / chart views, pagination or infinite scroll,
   search, sort, filters, bulk + row actions, expandable rows,
   column manager, tooltips, flip-aware action menus.
   ============================================================ */

export interface Column<T> {
  key: string;
  label: string;
  sortable?: boolean;
  render?: (row: T) => ReactNode;
  accessor?: (row: T) => string | number;
  tooltip?: (row: T) => string;
  filterOptions?: string[];
  defaultHidden?: boolean;
}
export interface RowAction<T> { label: string; icon?: ReactNode; tone?: 'default' | 'danger'; onClick: (row: T) => void }
export interface BulkAction<T> { label: string; icon?: ReactNode; tone?: 'default' | 'danger'; onClick: (rows: T[]) => void }
export type ViewKind = 'list' | 'kanban' | 'gallery' | 'calendar' | 'timeline' | 'chart';

export interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  rowKey: (r: T) => string | number;
  views?: ViewKind[];
  searchKeys?: string[];
  pageSize?: number;
  rowActions?: RowAction<T>[];
  bulkActions?: BulkAction<T>[];
  expandable?: (row: T) => ReactNode;
  groupField?: string;                       // kanban columns + chart grouping
  dateField?: string;                        // calendar + timeline
  card?: { title: (r: T) => string; subtitle?: (r: T) => string; badge?: (r: T) => string };
  onRowClick?: (row: T) => void;
  loading?: boolean;
  onReload?: () => void;
  /** Kanban drag & drop — called when a card is dropped on another column. */
  onKanbanMove?: (row: T, group: string) => void;
  /** File name base for exports. */
  exportName?: string;
  /** Structured detail data per row — enables hyperlinked detail sheets in Excel. */
  exportDetail?: (row: T) => Record<string, string | number>;
}

const VIEW_META: Record<ViewKind, { label: string; icon: typeof LayoutList }> = {
  list: { label: 'List', icon: LayoutList },
  kanban: { label: 'Kanban', icon: Kanban },
  gallery: { label: 'Gallery', icon: ImageIcon },
  calendar: { label: 'Calendar', icon: CalendarDays },
  timeline: { label: 'Timeline', icon: GanttChartSquare },
  chart: { label: 'Chart', icon: BarChart3 },
};

const get = (row: unknown, key: string): unknown => (row as Record<string, unknown>)[key];
const str = (v: unknown) => (v === null || v === undefined ? '' : String(v));
/** Robust date parsing — handles both 'YYYY-MM-DD' and full ISO timestamps. */
const valueOf = <T,>(row: T, col: Column<T>): unknown => (col.accessor ? col.accessor(row) : get(row, col.key));
const niceStep = (raw: number) => { const p = Math.pow(10, Math.floor(Math.log10(Math.max(1e-9, raw)))); const f = raw / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; };
const compact = (n: number) => Math.abs(n) >= 1e7 ? `${(n / 1e7).toFixed(1).replace(/\.0$/, '')}Cr` : Math.abs(n) >= 1e5 ? `${(n / 1e5).toFixed(1).replace(/\.0$/, '')}L` : Math.abs(n) >= 1e3 ? `${(n / 1e3).toFixed(1).replace(/\.0$/, '')}k` : String(Math.round(n));

/** Loading shimmer shaped like the active view, so the layout never jumps when data lands. */
function ViewSkeleton({ view, pageSize, cols }: { view: ViewKind; pageSize: number; cols: number }) {
  if (view === 'kanban') {
    return (
      <div className="flex gap-4 overflow-hidden p-4" aria-busy>
        {[3, 2, 4, 2].map((n, c) => (
          <div key={c} className="w-64 shrink-0">
            <div className="mb-2 flex items-center justify-between px-1"><Skeleton className="h-2.5 w-24" /><Skeleton className="h-4 w-7 rounded-full" /></div>
            <div className="tk-inset space-y-2 rounded-xl p-2">
              {Array.from({ length: n }).map((_, i) => (
                <div key={i} className="tk-raise-sm rounded-xl p-3"><Skeleton className="mb-2 h-3 w-3/5" /><Skeleton className="h-2.5 w-4/5" /></div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }
  if (view === 'gallery') {
    return (
      <div className="grid gap-3.5 p-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" aria-busy>
        {Array.from({ length: Math.min(8, Math.max(4, pageSize)) }).map((_, i) => (
          <div key={i} className="tk-raise-sm rounded-2xl p-4">
            <div className="mb-2.5 flex items-start justify-between"><Skeleton className="h-11 w-11 rounded-full" /><Skeleton className="h-4 w-4 rounded" /></div>
            <Skeleton className="mb-2 h-3.5 w-2/3" /><Skeleton className="mb-3 h-2.5 w-1/2" /><Skeleton className="h-4 w-16 rounded-full" />
          </div>
        ))}
      </div>
    );
  }
  if (view === 'calendar') {
    return (
      <div className="p-4" aria-busy>
        <div className="mb-3 flex items-center justify-between"><Skeleton className="h-7 w-7 rounded-lg" /><Skeleton className="h-4 w-36" /><Skeleton className="h-7 w-7 rounded-lg" /></div>
        <div className="grid grid-cols-7 gap-1.5">
          {Array.from({ length: 7 }).map((_, i) => <Skeleton key={`h${i}`} className="mx-auto h-2 w-6" />)}
          {Array.from({ length: 35 }).map((_, i) => <Skeleton key={i} className="aspect-square rounded-xl" style={{ animationDelay: `${(i % 7) * 60}ms` }} />)}
        </div>
      </div>
    );
  }
  if (view === 'timeline') {
    return (
      <div className="p-5" aria-busy>
        {[3, 2, 3].map((n, g) => (
          <div key={g} className="relative border-l-2 border-primary/20 pb-5 pl-5">
            <span className="absolute -left-[7px] top-0 h-3 w-3 rounded-full tk-skeleton" />
            <Skeleton className="mb-2.5 h-3.5 w-32" />
            <div className="space-y-1.5">{Array.from({ length: n }).map((_, i) => <Skeleton key={i} className="h-11 w-full rounded-xl" />)}</div>
          </div>
        ))}
      </div>
    );
  }
  if (view === 'chart') {
    return (
      <div className="space-y-4 p-4" aria-busy>
        <div className="flex gap-3"><Skeleton className="h-9 w-56 rounded-xl" /><Skeleton className="h-9 w-56 rounded-xl" /></div>
        <div className="tk-card p-4"><Skeleton className="mb-3 h-3.5 w-52" /><ChartSkeleton kind="columns" height={300} /></div>
      </div>
    );
  }
  return <TableSkeleton rows={Math.min(pageSize, 8)} toolbar={false} cols={cols} />;
}

/* ============================================================
   KanbanBoard — Notion-style: pointer-driven drag (no HTML5 ghost,
   no re-mount flicker), a placeholder that slides between cards,
   collapsible columns with counts, quick-add card, column reorder,
   keyboard-accessible move menu. Cards only animate when a
   placeholder pushes them, never while the board is idle.
   ============================================================ */
interface KanbanProps<T> {
  groups: [string, T[]][]; data: T[]; groupField: string; rowKey: (r: T) => string | number; knownGroups: string[];
  title: (r: T) => string; subtitle: (r: T) => string; badge?: (r: T) => string;
  onMove?: (row: T, group: string) => void; onOpen?: (row: T) => void;
  selected: Set<string | number>; onToggle: (k: string | number) => void;
  /** a move is being persisted — show a light overlay loader over the board */
  syncing?: boolean;
}
interface DragState { key: string | number; fromCol: string; w: number; h: number; ox: number; oy: number; x: number; y: number; overCol: string | null; overIdx: number | null }

function KanbanBoard<T>({ groups, groupField, rowKey, knownGroups, title, subtitle, badge, onMove, onOpen, selected, onToggle, syncing = false }: KanbanProps<T>) {
  const [order, setOrder] = useState<string[]>([]);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [drag, setDrag] = useState<DragState | null>(null);
  const [colDrag, setColDrag] = useState<{ name: string; x: number } | null>(null);
  const [adding, setAdding] = useState<string | null>(null);
  const [pending, setPending] = useState<{ key: string | number; to: string } | null>(null); // optimistic placement until data refreshes
  const boardRef = useRef<HTMLDivElement>(null);
  const colRefs = useRef(new Map<string, HTMLDivElement>());
  const cardRefs = useRef(new Map<string | number, HTMLDivElement>());
  const dragRef = useRef<DragState | null>(null);

  const names = useMemo(() => {
    const all = [...new Set([...knownGroups, ...groups.map(([g]) => g)])];
    const seen = new Set<string>();
    const ordered = [...order.filter((n) => all.includes(n)), ...all.filter((n) => !order.includes(n))];
    return ordered.filter((n) => (seen.has(n) ? false : (seen.add(n), true)));
  }, [knownGroups, groups, order]);

  // the pending row moves instantly; once the parent's data reflects it, clear it
  useEffect(() => {
    if (!pending) return;
    const col = groups.find(([g]) => g === pending.to)?.[1] || [];
    if (col.some((r) => rowKey(r) === pending.key)) setPending(null);
  }, [groups, pending, rowKey]);

  const colRows = useCallback((g: string): T[] => {
    let rows = groups.find(([gg]) => gg === g)?.[1] || [];
    if (pending) {
      rows = rows.filter((r) => rowKey(r) !== pending.key);
      if (pending.to === g) { const row = groups.flatMap(([, r]) => r).find((r) => rowKey(r) === pending.key); if (row) rows = [...rows, row]; }
    }
    return rows;
  }, [groups, pending, rowKey]);

  /* ---- card drag (pointer events) ---- */
  const startCard = (e: React.PointerEvent, row: T, col: string) => {
    if (!onMove || e.button !== 0) return;
    const el = cardRefs.current.get(rowKey(row)); if (!el) return;
    const r = el.getBoundingClientRect();
    const st: DragState = { key: rowKey(row), fromCol: col, w: r.width, h: r.height, ox: e.clientX - r.left, oy: e.clientY - r.top, x: r.left, y: r.top, overCol: col, overIdx: null };
    dragRef.current = st; setDrag(st);
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    e.preventDefault();
  };
  const moveCard = (e: React.PointerEvent) => {
    const st = dragRef.current; if (!st) return;
    const x = e.clientX - st.ox, y = e.clientY - st.oy;
    // which column is under the pointer?
    let overCol: string | null = null;
    for (const [name, el] of colRefs.current) {
      const r = el.getBoundingClientRect();
      if (e.clientX >= r.left - 8 && e.clientX <= r.right + 8) { overCol = name; break; }
    }
    // which slot? compare pointer y with card midpoints in that column (ignoring the dragged card)
    let overIdx: number | null = null;
    if (overCol) {
      const rows = colRows(overCol).filter((r) => rowKey(r) !== st.key);
      overIdx = rows.length;
      for (let i = 0; i < rows.length; i++) {
        const el = cardRefs.current.get(rowKey(rows[i])); if (!el) continue;
        const r = el.getBoundingClientRect();
        if (e.clientY < r.top + r.height / 2) { overIdx = i; break; }
      }
    }
    const next = { ...st, x, y, overCol, overIdx };
    dragRef.current = next;
    setDrag(next);
    // auto-scroll the board horizontally near its edges
    const b = boardRef.current;
    if (b) { const r = b.getBoundingClientRect(); if (e.clientX > r.right - 40) b.scrollLeft += 12; else if (e.clientX < r.left + 40) b.scrollLeft -= 12; }
  };
  const endCard = () => {
    const st = dragRef.current; if (!st) return;
    dragRef.current = null; setDrag(null);
    if (st.overCol && st.overCol !== st.fromCol && onMove) {
      const row = groups.flatMap(([, r]) => r).find((r) => rowKey(r) === st.key);
      if (row) { setPending({ key: st.key, to: st.overCol }); onMove(row, st.overCol); }
    }
  };

  /* ---- column drag (header handle) ---- */
  const startCol = (e: React.PointerEvent, name: string) => {
    if (e.button !== 0) return;
    setColDrag({ name, x: e.clientX });
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    e.preventDefault();
  };
  const moveCol = (e: React.PointerEvent) => {
    if (!colDrag) return;
    let target: string | null = null;
    for (const [name, el] of colRefs.current) { const r = el.getBoundingClientRect(); if (e.clientX >= r.left && e.clientX <= r.right) { target = name; break; } }
    if (target && target !== colDrag.name) {
      const arr = [...names]; const from = arr.indexOf(colDrag.name), to = arr.indexOf(target);
      arr.splice(from, 1); arr.splice(to, 0, colDrag.name); setOrder(arr);
    }
  };

  const dragRow = drag ? groups.flatMap(([, r]) => r).find((r) => rowKey(r) === drag.key) || null : null;

  return (
    <div className="relative">
      {syncing && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-start justify-center pt-24" aria-live="polite">
          <div className="tk-pop flex items-center gap-2.5 rounded-full px-4 py-2 font-body text-[12px] font-bold text-ink">
            <span className="tk-neuloader h-5 w-5" /> Saving move…
          </div>
        </div>
      )}
    <div ref={boardRef} className={`hide-scrollbar flex select-none gap-4 overflow-x-auto p-4 transition-opacity ${syncing ? 'pointer-events-none opacity-80' : ''}`} onPointerMove={(e) => { moveCard(e); moveCol(e); }} onPointerUp={() => { endCard(); setColDrag(null); }} onPointerCancel={() => { endCard(); setColDrag(null); }}>
      {names.map((g) => {
        const rows = colRows(g);
        const isCollapsed = collapsed.has(g);
        const visible = drag ? rows.filter((r) => rowKey(r) !== drag.key) : rows;
        const showPh = !!drag && drag.overCol === g;
        const phIdx = showPh ? Math.min(drag!.overIdx ?? visible.length, visible.length) : -1;
        const count = rows.length + (showPh && drag!.fromCol !== g ? 1 : 0) - (drag && drag.fromCol === g && drag.overCol !== g ? 1 : 0);
        return (
          <div key={g} ref={(el) => { if (el) colRefs.current.set(g, el); else colRefs.current.delete(g); }}
            className={`shrink-0 transition-[width] duration-200 ${isCollapsed ? 'w-12' : 'w-[272px]'} ${colDrag?.name === g ? 'opacity-60' : ''}`}>
            {/* header */}
            <div className={`mb-2 flex items-center gap-1.5 px-1 ${isCollapsed ? 'flex-col' : ''}`}>
              <button onPointerDown={(e) => startCol(e, g)} className="cursor-grab text-muted hover:text-ink active:cursor-grabbing" data-tip="Drag to reorder column"><GripVertical size={13} /></button>
              <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: `color-mix(in srgb, var(--t-accent) ${100 - (names.indexOf(g) % 6) * 14}%, var(--t-gold))` }} />
              {!isCollapsed && <p className="min-w-0 flex-1 truncate font-body text-[12px] font-bold uppercase tracking-wider text-ink/75">{g}</p>}
              <Badge tone={showPh ? 'green' : 'neutral'}>{count}</Badge>
              <button onClick={() => setCollapsed((c) => { const n = new Set(c); if (n.has(g)) n.delete(g); else n.add(g); return n; })} className="text-muted hover:text-ink" data-tip={isCollapsed ? 'Expand' : 'Collapse'}>
                {isCollapsed ? <ChevronRight size={13} /> : <ChevronDown size={13} />}
              </button>
            </div>
            {isCollapsed ? (
              <div className="tk-inset flex h-40 items-center justify-center rounded-xl"><span className="rotate-90 whitespace-nowrap font-body text-[11px] font-bold uppercase tracking-wider text-muted">{g}</span></div>
            ) : (
              <div className={`tk-inset kanban-col min-h-[140px] rounded-xl p-2 transition-shadow ${showPh ? 'ring-2 ring-(--t-accent)/35' : ''}`}>
                {(() => {
                  // render the placeholder inline at its slot so the column reflows naturally
                  const items: ReactNode[] = [];
                  const ph = (
                    <div key="__ph" className="pointer-events-none mb-2 rounded-xl border-2 border-dashed border-(--t-accent)/45 bg-primary/6" style={{ height: drag?.h || 64 }} />
                  );
                  visible.forEach((r, i) => {
                    if (showPh && i === phIdx) items.push(ph);
                    const k = rowKey(r);
                    items.push(
                      <div key={String(k)} ref={(el) => { if (el) cardRefs.current.set(k, el); else cardRefs.current.delete(k); }}
                        onPointerDown={(e) => startCard(e, r, g)}
                        className="kanban-card tk-raise-sm group relative mb-2 rounded-xl p-3">
                        <div className="flex items-start gap-2">
                          <input type="checkbox" checked={selected.has(k)} onChange={() => onToggle(k)} onPointerDown={(e) => e.stopPropagation()} className="tk-check mt-0.5 shrink-0 opacity-0 transition group-hover:opacity-100 checked:opacity-100" />
                          <button onClick={() => onOpen?.(r)} onPointerDown={(e) => e.stopPropagation()} className="min-w-0 flex-1 text-left">
                            <p className="truncate font-body text-[13px] font-bold text-ink">{title(r)}</p>
                            <p className="truncate font-body text-[11.5px] text-muted">{subtitle(r)}</p>
                          </button>
                          {onMove && <MoveMenu groups={names.filter((n) => n !== g)} onPick={(to) => { setPending({ key: k, to }); onMove(r, to); }} />}
                        </div>
                        {badge && <div className="mt-1.5"><Badge tone="green">{badge(r)}</Badge></div>}
                      </div>,
                    );
                  });
                  if (showPh && phIdx >= visible.length) items.push(ph);
                  return items;
                })()}
                {visible.length === 0 && !showPh && <p className="py-6 text-center font-body text-[11px] text-muted">No records</p>}
                {onMove && (
                  adding === g ? (
                    <p className="px-1 py-2 font-body text-[11px] text-muted">Drag a card here or use a card’s ⋯ menu → move to <b>{g}</b>.</p>
                  ) : (
                    <button onClick={() => setAdding(g)} className="flex w-full items-center gap-1.5 rounded-lg px-2 py-1.5 font-body text-[11.5px] font-bold text-muted transition hover:bg-primary/8 hover:text-primary"><Plus size={12} /> Add to {g}</button>
                  )
                )}
              </div>
            )}
          </div>
        );
      })}

      {/* drag overlay — the card itself follows the pointer, rendered once via portal */}
      {drag && dragRow && createPortal(
        <div className="tk-raise-sm pointer-events-none fixed z-[200] rounded-xl p-3 shadow-2xl"
          style={{ left: drag.x, top: drag.y, width: drag.w, transform: 'rotate(1.5deg) scale(1.03)', background: 'var(--t-surface)' }}>
          <p className="truncate font-body text-[13px] font-bold text-ink">{title(dragRow)}</p>
          <p className="truncate font-body text-[11.5px] text-muted">{subtitle(dragRow)}</p>
          {badge && <div className="mt-1.5"><Badge tone="green">{badge(dragRow)}</Badge></div>}
        </div>,
        document.body,
      )}
    </div>
    </div>
  );
}

function MoveMenu({ groups, onPick }: { groups: string[]; onPick: (g: string) => void }) {
  const [open, setOpen] = useState(false);
  const { anchorRef, dir, measure } = useFlip(groups.length * 34 + 40);
  return (
    <div ref={anchorRef} className="relative shrink-0" onPointerDown={(e) => e.stopPropagation()}>
      <button onClick={() => { measure(); setOpen(!open); }} className="rounded-md p-1 text-muted opacity-0 transition group-hover:opacity-100 hover:text-ink" aria-label="Move to…"><MoreHorizontal size={13} /></button>
      <Popover open={open} onClose={() => setOpen(false)} anchorRef={anchorRef} dir={dir} width={180} sheetTitle="Move to">
        <p className="px-3 pb-1 pt-1.5 font-body text-[10px] font-bold uppercase tracking-wider text-muted">Move to</p>
        {groups.map((g) => (
          <button key={g} onClick={() => { setOpen(false); onPick(g); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left font-body text-[12.5px] font-semibold text-ink/80 transition hover:bg-primary/8">
            <ChevronRight size={12} className="text-primary" /> {g}
          </button>
        ))}
      </Popover>
    </div>
  );
}

const parseDate = (s: string): Date | null => {
  if (!s) return null;
  const d = new Date(s.includes('T') ? s : s + 'T00:00:00');
  return isNaN(d.getTime()) ? null : d;
};

/* ---- CDN loaders for export libraries (node_modules is immutable) ---- */
const scriptCache = new Map<string, Promise<void>>();
function loadScript(src: string): Promise<void> {
  if (!scriptCache.has(src)) {
    scriptCache.set(src, new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = () => resolve();
      s.onerror = () => { scriptCache.delete(src); reject(new Error('Failed to load ' + src)); };
      document.head.appendChild(s);
    }));
  }
  return scriptCache.get(src)!;
}
async function loadPdfMake(): Promise<any> {
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.12/pdfmake.min.js');
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.12/vfs_fonts.js');
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (window as any).pdfMake;
}
async function loadExcelJS(): Promise<any> {
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js');
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (window as any).ExcelJS;
}

/* ============================================================
   FilterHub — one compact button hosting ALL table filters.
   Scales from 5 to 20+ filters without crowding the toolbar:
   filter list on the left, searchable value panel on the right,
   live counts, per-filter and global clear.
   ============================================================ */
function FilterHub<T>({ columns, filters, setFilters }: {
  columns: Column<T>[];
  filters: Record<string, string[]>;
  setFilters: React.Dispatch<React.SetStateAction<Record<string, string[]>>>;
}) {
  const [open, setOpen] = useState(false);
  const [activeKey, setActiveKey] = useState(columns[0]?.key || '');
  const [vq, setVq] = useState('');
  const { anchorRef, dir, measure } = useFlip(400);
  const activeCount = Object.values(filters).reduce((s, v) => s + v.length, 0);
  const activeCol = columns.find((c) => c.key === activeKey) || columns[0];
  const values = (activeCol?.filterOptions || []).filter((o) => !vq.trim() || o.toLowerCase().includes(vq.toLowerCase()));

  const toggleVal = (key: string, val: string) => {
    setFilters((f) => {
      const cur = f[key] || [];
      return { ...f, [key]: cur.includes(val) ? cur.filter((x) => x !== val) : [...cur, val] };
    });
  };

  return (
    <div ref={anchorRef} className="relative">
      <button onClick={() => { measure(); setOpen(!open); setVq(''); }}
        className={`tk-btn-ghost flex items-center gap-1.5 rounded-xl px-3 py-2 font-body text-[12px] font-bold ${activeCount ? 'text-primary' : ''}`}>
        <SlidersHorizontal size={13} /> Filters
        {activeCount > 0 && (
          <span className="flex h-4.5 min-w-[18px] items-center justify-center rounded-full bg-(--t-accent) px-1 font-body text-[10px] font-bold text-white">
            {activeCount}
          </span>
        )}
      </button>
      <Popover open={open} onClose={() => setOpen(false)} anchorRef={anchorRef} dir={dir} width={430} sheetTitle="Filters">
        <div className="flex" style={{ maxHeight: 340 }}>
          {/* left: filter list */}
          <div className="hide-scrollbar w-[150px] shrink-0 overflow-y-auto border-r tk-divider pr-1.5">
            {columns.map((c) => {
              const n = (filters[c.key] || []).length;
              return (
                <button key={c.key} onClick={() => { setActiveKey(c.key); setVq(''); }}
                  className={`flex w-full items-center justify-between gap-1 rounded-lg px-2.5 py-2 text-left font-body text-[12px] font-bold transition ${
                    activeKey === c.key ? 'tk-inset text-primary' : 'text-ink/70 hover:text-ink'
                  }`}>
                  <span className="truncate">{c.label}</span>
                  {n > 0 && <span className="shrink-0 rounded-full bg-(--t-accent) px-1.5 font-body text-[9.5px] font-bold text-white">{n}</span>}
                </button>
              );
            })}
          </div>
          {/* right: values with search */}
          <div className="flex min-w-0 flex-1 flex-col pl-2.5">
            <div className="tk-inset mb-2 flex shrink-0 items-center gap-2 rounded-lg px-2.5 py-1.5">
              <Search size={12} className="shrink-0 text-muted" />
              <input value={vq} onChange={(e) => setVq(e.target.value)} placeholder={`Search ${activeCol?.label || ''}…`}
                className="w-full bg-transparent font-body text-[12px] text-ink outline-none placeholder:text-muted" />
            </div>
            <div className="hide-scrollbar flex-1 overflow-y-auto">
              {values.length === 0 && <p className="px-2 py-4 text-center font-body text-[11.5px] text-muted">No matching values</p>}
              {values.map((v) => {
                const on = (filters[activeCol.key] || []).includes(v);
                return (
                  <label key={v} className="flex cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-1.5 font-body text-[12.5px] font-semibold text-ink/80 transition hover:bg-primary/8">
                    <input type="checkbox" className="tk-check" checked={on} onChange={() => toggleVal(activeCol.key, v)} />
                    <span className="truncate">{v}</span>
                  </label>
                );
              })}
            </div>
            <div className="flex shrink-0 items-center justify-between border-t tk-divider pt-2">
              <button onClick={() => setFilters((f) => ({ ...f, [activeCol.key]: [] }))}
                className="font-body text-[11.5px] font-bold text-muted transition hover:text-ink">Clear this filter</button>
              <button onClick={() => setFilters({})}
                className="font-body text-[11.5px] font-bold text-rose-500 transition hover:underline">Clear all</button>
            </div>
          </div>
        </div>
      </Popover>
    </div>
  );
}

function RowMenu<T>({ row, actions }: { row: T; actions: RowAction<T>[] }) {
  const [open, setOpen] = useState(false);
  const { anchorRef, dir, measure } = useFlip(actions.length * 40 + 20);
  return (
    <div ref={anchorRef} className="relative inline-block">
      <button onClick={(e) => { e.stopPropagation(); measure(); setOpen(!open); }}
        className="rounded-lg p-1.5 text-muted transition hover:bg-primary/8 hover:text-ink">
        <MoreHorizontal size={16} />
      </button>
      <Popover open={open} onClose={() => setOpen(false)} anchorRef={anchorRef} dir={dir} width={176} sheetTitle="Actions">
        {actions.map((a) => (
          <button key={a.label} onClick={(e) => { e.stopPropagation(); setOpen(false); a.onClick(row); }}
            className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left font-body text-[13px] font-semibold transition hover:bg-primary/8 ${a.tone === 'danger' ? 'text-rose-500' : 'text-ink/80'}`}>
            {a.icon} {a.label}
          </button>
        ))}
      </Popover>
    </div>
  );
}

export default function DataTable<T>({
  data, columns, rowKey, views = ['list'], searchKeys, pageSize = 10,
  rowActions = [], bulkActions = [], expandable, groupField, dateField, card, onRowClick,
  loading = false, onReload, onKanbanMove, exportName = 'data', exportDetail,
}: DataTableProps<T>) {
  const [view, setView] = useState<ViewKind>(views[0]);
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<{ key: string; dir: 1 | -1 } | null>(null);
  const [filters, setFilters] = useState<Record<string, string[]>>({});
  const [selected, setSelected] = useState<Set<string | number>>(new Set());
  const [expanded, setExpanded] = useState<Set<string | number>>(new Set());
  const [hidden, setHidden] = useState<Set<string>>(() => new Set(columns.filter((c) => c.defaultHidden).map((c) => c.key)));
  const [page, setPage] = useState(0);
  const [exporting, setExporting] = useState(false);
  const [calMonth, setCalMonth] = useState(() => new Date());
  const [colMgrOpen, setColMgrOpen] = useState(false);
  const colMgr = useFlip(280);
  const [detailRow, setDetailRow] = useState<T | null>(null);
  const [dayList, setDayList] = useState<{ label: string; rows: T[] } | null>(null);
  const [kanbanMoving, setKanbanMoving] = useState(false); // a board move is syncing → overlay loader, never a skeleton
  const [chartBasis, setChartBasis] = useState<string>(groupField || columns[0]?.key || '');
  const [chartMeasure, setChartMeasure] = useState<string>('count');

  /* ---- pipeline: search → filter → sort ---- */
  const processed = useMemo(() => {
    let rows = data;
    const t = q.trim().toLowerCase();
    if (t) {
      const keys = searchKeys || columns.map((c) => c.key);
      rows = rows.filter((r) => keys.some((k) => str(get(r, k)).toLowerCase().includes(t)));
    }
    for (const [k, vals] of Object.entries(filters)) {
      if (vals.length) rows = rows.filter((r) => vals.includes(str(get(r, k))));
    }
    if (sort) {
      const col = columns.find((c) => c.key === sort.key);
      rows = [...rows].sort((a, b) => {
        const av = col?.accessor ? col.accessor(a) : get(a, sort.key);
        const bv = col?.accessor ? col.accessor(b) : get(b, sort.key);
        if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * sort.dir;
        return str(av).localeCompare(str(bv)) * sort.dir;
      });
    }
    return rows;
  }, [data, q, filters, sort, columns, searchKeys]);

  useEffect(() => { setPage(0); }, [q, filters, sort, view, pageSize]);

  const pageRows = processed.slice(page * pageSize, (page + 1) * pageSize);
  const totalPages = Math.max(1, Math.ceil(processed.length / pageSize));
  useEffect(() => { if (!loading) setKanbanMoving(false); }, [loading]);
  // keep the last board data alive while a move syncs so the board never blanks
  const lastRows = useRef<T[]>([]);
  if (!loading) lastRows.current = data;

  const shownCols = columns.filter((c) => !hidden.has(c.key));
  const filterCols = columns.filter((c) => c.filterOptions?.length);

  /* ---------------- EXPORTS: PDF (pdfMake) / Excel (ExcelJS) / CSV / Print ---------------- */
  const cellText = useCallback((row: T, col: Column<T>): string => {
    if (col.accessor) return str(col.accessor(row));
    return str(get(row, col.key));
  }, []);

  const doExport = async (fmt: string) => {
    const cols = columns.filter((c) => !hidden.has(c.key));
    const rows = processed; // full filtered + sorted result, not just the visible page
    const stamp = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
    setExporting(true);
    try {
      if (fmt === 'csv') {
        const head = cols.map((c) => `"${c.label}"`).join(',');
        const lines = rows.map((r) => cols.map((c) => `"${cellText(r, c).replace(/"/g, '""')}"`).join(','));
        downloadBlob(`${exportName}.csv`, new Blob([head + '\n' + lines.join('\n')], { type: 'text/csv' }));
        return;
      }

      if (fmt === 'pdf') {
        const pdfMake = await loadPdfMake();
        const body = [
          cols.map((c) => ({ text: c.label, style: 'th' })),
          ...rows.map((r) => cols.map((c) => ({ text: cellText(r, c), style: 'td' }))),
        ];
        pdfMake.createPdf({
          pageOrientation: cols.length > 5 ? 'landscape' : 'portrait',
          pageMargins: [28, 64, 28, 44],
          header: {
            margin: [28, 20, 28, 0],
            columns: [
              { text: 'AVIARY · PEOPLE OS', color: '#0d7a54', bold: true, fontSize: 9, characterSpacing: 1 },
              { text: stamp, alignment: 'right', color: '#8a938d', fontSize: 9 },
            ],
          },
          footer: (page: number, total: number) => ({
            margin: [28, 8, 28, 0],
            columns: [
              { text: `${rows.length} records`, color: '#8a938d', fontSize: 8 },
              { text: `Page ${page} of ${total}`, alignment: 'right', color: '#8a938d', fontSize: 8 },
            ],
          }),
          content: [
            { text: exportName.replace(/-/g, ' ').toUpperCase(), fontSize: 15, bold: true, color: '#1c2620', margin: [0, 0, 0, 12] },
            {
              table: { headerRows: 1, widths: cols.map(() => '*'), body },
              layout: {
                fillColor: (i: number) => (i === 0 ? '#0d7a54' : i % 2 === 0 ? '#f2f4f0' : null),
                hLineColor: () => '#dde2dd', vLineColor: () => '#dde2dd',
                hLineWidth: () => 0.5, vLineWidth: () => 0.5,
                paddingTop: () => 5, paddingBottom: () => 5, paddingLeft: () => 6, paddingRight: () => 6,
              },
            },
          ],
          styles: {
            th: { color: '#ffffff', bold: true, fontSize: 8.5 },
            td: { color: '#2c352f', fontSize: 8.5 },
          },
        }).download(`${exportName}.pdf`);
        return;
      }

      if (fmt === 'excel') {
        const ExcelJS = await loadExcelJS();
        const wb = new ExcelJS.Workbook();
        wb.creator = 'Aviary People OS';
        const ws = wb.addWorksheet('Data', { views: [{ state: 'frozen', ySplit: 2 }] });
        // title row
        ws.mergeCells(1, 1, 1, cols.length);
        const titleCell = ws.getCell(1, 1);
        titleCell.value = exportName.replace(/-/g, ' ').toUpperCase() + '  ·  ' + stamp;
        titleCell.font = { bold: true, size: 13, color: { argb: 'FF0D7A54' } };
        ws.getRow(1).height = 24;
        // header
        const headRow = ws.addRow(cols.map((c) => c.label));
        headRow.eachCell((cell: { font: unknown; fill: unknown; alignment: unknown; border: unknown }) => {
          cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 10 };
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
          cell.alignment = { vertical: 'middle' };
          cell.border = { bottom: { style: 'thin', color: { argb: 'FF0A5C40' } } };
        });
        ws.getRow(2).height = 20;
        rows.forEach((r, ri) => {
          const row = ws.addRow(cols.map((c) => {
            const raw = c.accessor ? c.accessor(r) : get(r, c.key);
            return typeof raw === 'number' ? raw : str(raw);
          }));
          if (ri % 2 === 1) row.eachCell((cell: { fill: unknown }) => {
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF2F4F0' } };
          });
          // hyperlinked detail sheet for rows with expandable data
          if (exportDetail) {
            const detail = exportDetail(r);
            if (detail && Object.keys(detail).length) {
              const sheetName = `Row ${ri + 2}`;
              const ds = wb.addWorksheet(sheetName);
              ds.getCell('A1').value = { text: '← Back to Data', hyperlink: `#'Data'!A${ri + 3}` };
              ds.getCell('A1').font = { color: { argb: 'FF0D7A54' }, underline: true, bold: true };
              ds.addRow([]);
              const dh = ds.addRow(['Field', 'Value']);
              dh.eachCell((cell: { font: unknown; fill: unknown }) => {
                cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0D7A54' } };
              });
              Object.entries(detail).forEach(([k, v]) => ds.addRow([k, v]));
              ds.getColumn(1).width = 26;
              ds.getColumn(2).width = 44;
              const first = row.getCell(1);
              first.value = { text: str(first.value), hyperlink: `#'${sheetName}'!A1` };
              first.font = { color: { argb: 'FF0D7A54' }, underline: true };
            }
          }
        });
        cols.forEach((c, i) => {
          const maxLen = Math.max(c.label.length, ...rows.slice(0, 200).map((r) => cellText(r, c).length));
          ws.getColumn(i + 1).width = Math.min(38, Math.max(11, maxLen + 3));
        });
        const buf = await wb.xlsx.writeBuffer();
        downloadBlob(`${exportName}.xlsx`, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
        return;
      }

      if (fmt === 'print') {
        // re-render a clean high-resolution page in a hidden iframe (never
        // blocked by popup rules), then trigger print from it
        const html = `<!doctype html><html><head><title>${exportName}</title><style>
          @page { margin: 14mm; }
          body { font-family: 'Segoe UI', system-ui, sans-serif; color: #1c2620; margin: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .brand { color: #0d7a54; font-weight: 800; font-size: 11px; letter-spacing: 2px; }
          h1 { font-size: 19px; margin: 4px 0 2px; text-transform: capitalize; }
          .meta { color: #79837c; font-size: 11px; margin-bottom: 14px; }
          table { width: 100%; border-collapse: collapse; font-size: 11px; }
          th { background: #0d7a54; color: #fff; text-align: left; padding: 7px 8px; font-size: 10px; }
          td { padding: 6px 8px; border-bottom: 0.5px solid #dde2dd; }
          tr:nth-child(even) td { background: #f4f6f2; }
          thead { display: table-header-group; }
        </style></head><body>
          <div class="brand">AVIARY · PEOPLE OS</div>
          <h1>${exportName.replace(/-/g, ' ')}</h1>
          <div class="meta">${stamp} · ${rows.length} records</div>
          <table><thead><tr>${cols.map((c) => `<th>${c.label}</th>`).join('')}</tr></thead>
          <tbody>${rows.map((r) => `<tr>${cols.map((c) => `<td>${cellText(r, c)}</td>`).join('')}</tr>`).join('')}</tbody></table>
        </body></html>`;
        const iframe = document.createElement('iframe');
        iframe.style.cssText = 'position:fixed;right:200vw;bottom:200vh;width:1080px;height:760px;border:0;';
        document.body.appendChild(iframe);
        const doc = iframe.contentWindow!.document;
        doc.open(); doc.write(html); doc.close();
        const cleanup = () => { try { iframe.remove(); } catch { /* noop */ } };
        iframe.contentWindow!.onafterprint = cleanup;
        setTimeout(() => {
          try { iframe.contentWindow!.focus(); iframe.contentWindow!.print(); } catch { cleanup(); }
          setTimeout(cleanup, 60000);
        }, 350);
        return;
      }
    } finally {
      setExporting(false);
    }
  };

  const toggleSel = (k: string | number) => setSelected((s) => { const n = new Set(s); if (n.has(k)) n.delete(k); else n.add(k); return n; });
  // Select-all covers EVERY record in the current search/filter result — not just the visible page.
  const allSelected = processed.length > 0 && processed.every((r) => selected.has(rowKey(r)));
  const toggleAll = () => setSelected(() => allSelected ? new Set() : new Set(processed.map((r) => rowKey(r))));
  const selectedRows = useMemo(() => data.filter((r) => selected.has(rowKey(r))), [data, selected, rowKey]);

  const cycleSort = (key: string) => setSort((s) => (!s || s.key !== key) ? { key, dir: 1 } : s.dir === 1 ? { key, dir: -1 } : null);

  const kanbanGroups = useMemo(() => {
    if (!groupField) return [] as [string, T[]][];
    const src = loading && kanbanMoving ? lastRows.current : processed;
    const m = new Map<string, T[]>();
    src.forEach((r) => {
      const g = str(get(r, groupField)) || '—';
      if (!m.has(g)) m.set(g, []);
      m.get(g)!.push(r);
    });
    return Array.from(m.entries());
  }, [processed, groupField, loading, kanbanMoving]);

  const groups = useMemo(() => {
    if (!groupField) return [];
    const m = new Map<string, T[]>();
    processed.forEach((r) => {
      const g = str(get(r, groupField)) || '—';
      if (!m.has(g)) m.set(g, []);
      m.get(g)!.push(r);
    });
    return Array.from(m.entries());
  }, [processed, groupField]);

  const cardTitle = useCallback((r: T) => card?.title(r) ?? str(get(r, columns[0].key)), [card, columns]);
  const cardSub = useCallback((r: T) => card?.subtitle?.(r) ?? (columns[1] ? str(get(r, columns[1].key)) : ''), [card, columns]);

  /* ============================ render ============================ */
  return (
    <div className="tk-card overflow-visible">
      {/* ---- toolbar (visible but disabled while loading) ---- */}
      <div className={`flex flex-wrap items-center gap-2.5 border-b tk-divider px-4 py-3 ${loading ? 'pointer-events-none opacity-55' : ''}`}>
        <div className="tk-inset flex min-w-[170px] flex-1 items-center gap-2 px-3 py-2 sm:max-w-xs">
          <Search size={13} className="shrink-0 text-muted" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search…"
            className="w-full bg-transparent font-body text-[13px] text-ink outline-none placeholder:text-muted" />
          {q && <button onClick={() => setQ('')} className="text-muted hover:text-ink"><X size={13} /></button>}
        </div>

        {/* FilterHub — one button hosts ALL filters (scales to 20+ without crowding) */}
        {filterCols.length > 0 && <FilterHub columns={filterCols} filters={filters} setFilters={setFilters} />}

        <div className="ml-auto flex items-center gap-2">
          <MiniDrop label={exporting ? 'Exporting…' : 'Export'} icon={<Download size={12} />}
            items={[
              { key: 'pdf', label: 'PDF document' },
              { key: 'excel', label: 'Excel workbook' },
              { key: 'csv', label: 'CSV data' },
              { key: 'print', label: 'Print…' },
            ]}
            onPick={doExport} />
          {/* column manager */}
          {view === 'list' && (
            <div ref={colMgr.anchorRef} className="relative">
              <button onClick={() => { colMgr.measure(); setColMgrOpen(!colMgrOpen); }} data-tip="Show / hide columns"
                className="tk-btn-ghost rounded-xl p-2"><Columns3 size={15} /></button>
              <Popover open={colMgrOpen} onClose={() => setColMgrOpen(false)} anchorRef={colMgr.anchorRef} dir={colMgr.dir} width={210} sheetTitle="Columns">
                {columns.map((c) => (
                  <label key={c.key} className="flex cursor-pointer items-center gap-2.5 rounded-lg px-3 py-2 font-body text-[13px] font-semibold text-ink/80 transition hover:bg-primary/8">
                    <input type="checkbox" checked={!hidden.has(c.key)}
                      onChange={() => setHidden((h) => { const n = new Set(h); if (n.has(c.key)) n.delete(c.key); else n.add(c.key); return n; })}
                      className="tk-check" />
                    {c.label}
                  </label>
                ))}
              </Popover>
            </div>
          )}
          {/* view switcher */}
          {views.length > 1 && (
            <div className="tk-inset flex gap-0.5 p-1">
              {views.map((v) => {
                const Icon = VIEW_META[v].icon;
                return (
                  <button key={v} onClick={() => setView(v)} data-tip={VIEW_META[v].label}
                    className={`rounded-lg p-1.5 transition ${view === v ? 'tk-raise-sm text-primary' : 'text-muted hover:text-ink'}`}>
                    <Icon size={15} />
                  </button>
                );
              })}
            </div>
          )}
          {/* reload sits AFTER the view switcher */}
          {onReload && (
            <button onClick={onReload} data-tip="Reload data" disabled={loading}
              className="tk-btn-ghost rounded-xl p-2">
              <RotateCw size={15} className={loading ? 'animate-spin' : ''} />
            </button>
          )}
        </div>
      </div>

      {/* active filter chips */}
      {Object.entries(filters).some(([, v]) => v.length > 0) && (
        <div className="flex flex-wrap items-center gap-1.5 border-b tk-divider px-4 py-2">
          {Object.entries(filters).flatMap(([k, vals]) =>
            vals.map((v) => (
              <span key={k + v} className="tk-chip flex items-center gap-1.5 px-2.5 py-1 font-body text-[11px] font-bold text-ink/75">
                <span className="text-muted">{columns.find((c) => c.key === k)?.label}:</span> {v}
                <button onClick={() => setFilters((f) => ({ ...f, [k]: (f[k] || []).filter((x) => x !== v) }))}
                  className="text-muted transition hover:text-rose-500"><X size={11} /></button>
              </span>
            ))
          )}
          <button onClick={() => setFilters({})} className="ml-1 font-body text-[11px] font-bold text-muted transition hover:text-ink">Clear all</button>
        </div>
      )}

      {/* ---- bulk bar ---- */}
      <AnimatePresence>
        {selected.size > 0 && bulkActions.length > 0 && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-b tk-divider">
            <div className="flex flex-wrap items-center gap-2.5 bg-primary/6 px-4 py-2.5">
              <span className="flex items-center gap-1.5 font-body text-[12.5px] font-bold text-primary"><CheckSquare size={13} /> {selected.size} selected</span>
              {bulkActions.map((a) => (
                <button key={a.label} onClick={() => { a.onClick(selectedRows); setSelected(new Set()); }}
                  className={`tk-btn-ghost rounded-lg px-3 py-1.5 font-body text-[12px] font-bold ${a.tone === 'danger' ? '!text-rose-500' : ''}`}>
                  {a.icon} {a.label}
                </button>
              ))}
              <button onClick={() => setSelected(new Set())} className="ml-auto font-body text-[12px] font-bold text-muted hover:text-ink">Clear</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {loading && !(view === 'kanban' && kanbanMoving) ? (
        /* the body shimmers in the shape of whichever view is about to land */
        <div style={{ minHeight: Math.max(280, pageSize * 46) }}>
          <ViewSkeleton view={view} pageSize={pageSize} cols={Math.min(6, Math.max(3, shownCols.length))} />
        </div>
      ) : processed.length === 0 && !kanbanMoving ? (
        <EmptyState icon={<Inbox size={22} />} title="No records" subtitle="Try adjusting your search or filters." />
      ) : (
        <>
          {/* ================= LIST ================= */}
          {view === 'list' && (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px]">
                <thead>
                  <tr className="border-b tk-divider">
                    <th className="w-10 px-4 py-3" data-tip={allSelected ? 'Deselect all' : `Select all ${processed.length}`}>
                      <input type="checkbox" checked={allSelected} onChange={toggleAll} className="tk-check" />
                    </th>
                    {expandable && <th className="w-8" />}
                    {shownCols.map((c) => (
                      <th key={c.key} onClick={() => c.sortable !== false && cycleSort(c.key)}
                        className={`px-4 py-3 text-left font-body text-[10.5px] font-bold uppercase tracking-wider text-muted ${c.sortable !== false ? 'cursor-pointer select-none hover:text-ink' : ''}`}>
                        <span className="inline-flex items-center gap-1">
                          {c.label}
                          {sort?.key === c.key && (sort.dir === 1 ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                        </span>
                      </th>
                    ))}
                    {rowActions.length > 0 && <th className="w-12" />}
                  </tr>
                </thead>
                <tbody>
                  {pageRows.map((r) => {
                    const k = rowKey(r);
                    const isExp = expanded.has(k);
                    const colCount = 1 + (expandable ? 1 : 0) + shownCols.length + (rowActions.length > 0 ? 1 : 0);
                    return (
                      <Fragment key={String(k)}>
                        <tr onClick={() => onRowClick?.(r)}
                          className={`border-b tk-divider transition hover:bg-primary/4 ${onRowClick ? 'cursor-pointer' : ''}`}>
                          <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                            <input type="checkbox" checked={selected.has(k)} onChange={() => toggleSel(k)} className="tk-check" />
                          </td>
                          {expandable && (
                            <td className="py-3" onClick={(e) => e.stopPropagation()}>
                              <button onClick={() => setExpanded((s) => { const n = new Set(s); if (n.has(k)) n.delete(k); else n.add(k); return n; })}
                                className="rounded p-1 text-muted transition hover:text-primary">
                                <ChevronRight size={14} className={`transition-transform ${isExp ? 'rotate-90' : ''}`} />
                              </button>
                            </td>
                          )}
                          {shownCols.map((c) => (
                            <td key={c.key} className="px-4 py-3 font-body text-[13px] text-ink/80"
                              {...(c.tooltip ? { 'data-tip': c.tooltip(r) } : {})}>
                              {c.render ? c.render(r) : str(get(r, c.key))}
                            </td>
                          ))}
                          {rowActions.length > 0 && (
                            <td className="px-2 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                              <RowMenu row={r} actions={rowActions} />
                            </td>
                          )}
                        </tr>
                        {/* expansion renders INSIDE the table — pure height open/close */}
                        {expandable && (
                          <tr className={isExp ? 'border-b tk-divider' : ''}>
                            <td colSpan={colCount} className="p-0">
                              <div className={`tk-expand ${isExp ? 'open' : ''}`}>
                                <div>
                                  <div className="tk-inset mx-4 mb-3 mt-1 px-4 py-3">
                                    <p className="mb-1 font-body text-[10.5px] font-bold uppercase tracking-wider text-muted">Details · {cardTitle(r)}</p>
                                    {expandable(r)}
                                  </div>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    );
                  })}
                </tbody>
              </table>

            </div>
          )}

          {/* ================= KANBAN — Notion-style board ================= */}
          {view === 'kanban' && groupField && (
            <KanbanBoard<T>
              groups={kanbanGroups} data={processed} groupField={groupField} rowKey={rowKey}
              knownGroups={columns.find((c) => c.key === groupField)?.filterOptions || []}
              title={cardTitle} subtitle={cardSub} badge={card?.badge}
              onMove={onKanbanMove ? (row, group) => { setKanbanMoving(true); onKanbanMove(row, group); } : undefined}
              onOpen={onRowClick} syncing={loading && kanbanMoving}
              selected={selected} onToggle={toggleSel} />
          )}

          {/* ================= GALLERY ================= */}
          {view === 'gallery' && (
            <div className="grid gap-3.5 p-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {pageRows.map((r) => {
                const k = rowKey(r);
                return (
                  <div key={String(k)} className={`tk-raise-sm relative rounded-2xl p-4 transition hover:-translate-y-0.5 ${selected.has(k) ? 'ring-2 ring-(--t-accent)/50' : ''}`}>
                    {/* header row: avatar left, select box pinned right with a guaranteed gutter */}
                    <div className="mb-2.5 flex items-start justify-between gap-4">
                      <div className="tk-inset flex h-11 w-11 shrink-0 items-center justify-center rounded-full font-display text-[15px] font-bold text-primary">
                        {cardTitle(r).split(' ').map((w) => w[0]).slice(0, 2).join('')}
                      </div>
                      <label className="flex h-11 shrink-0 items-start pt-0.5" data-tip={selected.has(k) ? 'Deselect' : 'Select'}>
                        <input type="checkbox" checked={selected.has(k)} onChange={() => toggleSel(k)} className="tk-check" />
                      </label>
                    </div>
                    <button onClick={() => onRowClick?.(r)} className="block w-full text-left">
                      <p className="font-body text-[13.5px] font-bold text-ink">{cardTitle(r)}</p>
                      <p className="font-body text-[12px] text-muted">{cardSub(r)}</p>
                      {card?.badge && <div className="mt-2"><Badge tone="green">{card.badge(r)}</Badge></div>}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* ================= CALENDAR ================= */}
          {view === 'calendar' && dateField && (() => {
            const y = calMonth.getFullYear(), m = calMonth.getMonth();
            const firstDow = new Date(y, m, 1).getDay();
            const days = new Date(y, m + 1, 0).getDate();
            const byDay = new Map<number, T[]>();
            processed.forEach((r) => {
              const d = parseDate(str(get(r, dateField)));
              if (d && d.getFullYear() === y && d.getMonth() === m) {
                if (!byDay.has(d.getDate())) byDay.set(d.getDate(), []);
                byDay.get(d.getDate())!.push(r);
              }
            });
            return (
              <div className="p-4">
                <div className="mb-3 flex items-center justify-between">
                  <button onClick={() => setCalMonth(new Date(y, m - 1, 1))} className="tk-btn-ghost rounded-lg p-1.5"><ChevronLeft size={15} /></button>
                  <p className="font-display text-[15px] font-semibold text-ink">{calMonth.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</p>
                  <button onClick={() => setCalMonth(new Date(y, m + 1, 1))} className="tk-btn-ghost rounded-lg p-1.5"><ChevronRight size={15} /></button>
                </div>
                <div className="grid grid-cols-7 gap-1.5">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                    <span key={d} className="pb-1 text-center font-body text-[10px] font-bold uppercase text-muted">{d}</span>
                  ))}
                  {Array.from({ length: firstDow }).map((_, i) => <span key={`e${i}`} />)}
                  {Array.from({ length: days }, (_, i) => {
                    const items = byDay.get(i + 1) || [];
                    const dayLabel = new Date(y, m, i + 1).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
                    const today = new Date();
                    const isToday = today.getFullYear() === y && today.getMonth() === m && today.getDate() === i + 1;
                    return (
                      <div key={i} className={`tk-inset relative flex aspect-square flex-col overflow-hidden rounded-xl p-1.5 ${isToday ? 'ring-2 ring-(--t-accent)/50' : ''}`}>
                        <p className={`font-body text-[11px] font-bold ${isToday ? 'text-primary' : 'text-ink/60'}`}>{i + 1}</p>
                        <div className="mt-0.5 min-h-0 flex-1 space-y-0.5 overflow-hidden">
                          {items.slice(0, 3).map((r) => (
                            <button key={String(rowKey(r))} onClick={() => setDetailRow(r)} title={cardTitle(r)}
                              className="block w-full truncate rounded bg-primary/12 px-1 py-0.5 text-left font-body text-[10px] font-bold text-primary transition hover:bg-primary/22">
                              {cardTitle(r)}
                            </button>
                          ))}
                        </div>
                        {items.length > 3 && (
                          <button onClick={() => setDayList({ label: dayLabel, rows: items })}
                            className="mt-0.5 text-left font-body text-[9.5px] font-bold text-muted hover:text-primary">+{items.length - 3} more</button>
                        )}
                        {items.length > 0 && items.length <= 3 && (
                          <button onClick={() => setDayList({ label: dayLabel, rows: items })} className="absolute inset-0 -z-0" aria-label={`Open ${dayLabel}`} style={{ zIndex: -1 }} />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}

          {/* ================= TIMELINE ================= */}
          {view === 'timeline' && dateField && (
            <div className="p-5">
              {(() => {
                const sorted = [...processed].sort((a, b) => str(get(b, dateField)).localeCompare(str(get(a, dateField))));
                const byMonth = new Map<string, T[]>();
                sorted.forEach((r) => {
                  const d = parseDate(str(get(r, dateField)));
                  if (!d) return;
                  const key = d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
                  if (!byMonth.has(key)) byMonth.set(key, []);
                  byMonth.get(key)!.push(r);
                });
                return Array.from(byMonth.entries()).map(([mo, rows]) => (
                  <div key={mo} className="relative border-l-2 border-primary/25 pb-5 pl-5">
                    <span className="absolute -left-[7px] top-0 h-3 w-3 rounded-full bg-primary" />
                    <p className="mb-2 font-display text-[14px] font-semibold text-ink">{mo}</p>
                    <div className="space-y-1.5">
                      {rows.map((r) => (
                        <button key={String(rowKey(r))} onClick={() => onRowClick?.(r)}
                          className="tk-raise-sm flex w-full items-center justify-between gap-3 rounded-xl px-3.5 py-2 text-left transition hover:-translate-y-0.5">
                          <span className="min-w-0">
                            <span className="block truncate font-body text-[13px] font-bold text-ink">{cardTitle(r)}</span>
                            <span className="block truncate font-body text-[11.5px] text-muted">{cardSub(r)}</span>
                          </span>
                          <span className="shrink-0 font-body text-[11px] font-semibold tabular-nums text-muted">
                            {parseDate(str(get(r, dateField)))?.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) || '—'}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                ));
              })()}
            </div>
          )}

          {/* ================= CHART — custom basis · every chart kind · exports ================= */}
          {view === 'chart' && (() => {
            const numericCols = columns.filter((c) => processed.some((r) => typeof valueOf(r, c) === 'number'));
            const basisCol = columns.find((c) => c.key === chartBasis) || columns.find((c) => c.key === groupField) || columns[0];
            const measureCol = chartMeasure.startsWith('sum:') || chartMeasure.startsWith('avg:')
              ? numericCols.find((c) => c.key === chartMeasure.slice(4)) : undefined;
            const isNumBasis = numericCols.some((c) => c.key === basisCol.key);
            const buckets = new Map<string, T[]>();
            if (isNumBasis) {
              const vals = processed.map((r) => Number(valueOf(r, basisCol))).filter((v) => !Number.isNaN(v));
              const lo = Math.min(...vals), hi = Math.max(...vals);
              const bins = vals.length > 1 && hi > lo ? Math.min(6, Math.max(3, Math.round(Math.sqrt(vals.length)))) : 1;
              const size = bins > 1 ? niceStep((hi - lo) / bins) : 1;
              const startAt = Math.floor(lo / size) * size;
              processed.forEach((r) => {
                const v = Number(valueOf(r, basisCol));
                const b = bins > 1 ? Math.min(bins + 2, Math.floor((v - startAt) / size)) : 0;
                const label = bins > 1 ? `${compact(startAt + b * size)} – ${compact(startAt + (b + 1) * size)}` : compact(v);
                if (!buckets.has(label)) buckets.set(label, []);
                buckets.get(label)!.push(r);
              });
            } else {
              processed.forEach((r) => {
                const g = str(valueOf(r, basisCol)) || '—';
                if (!buckets.has(g)) buckets.set(g, []);
                buckets.get(g)!.push(r);
              });
            }
            let entries = [...buckets.entries()].map(([label, rows]) => ({
              label,
              value: !measureCol ? rows.length
                : chartMeasure.startsWith('sum:') ? rows.reduce((s2, r) => s2 + Number(valueOf(r, measureCol) || 0), 0)
                : Math.round(rows.reduce((s2, r) => s2 + Number(valueOf(r, measureCol) || 0), 0) / Math.max(1, rows.length)),
            }));
            if (!isNumBasis) entries.sort((a, b) => b.value - a.value);
            if (entries.length > 14) {
              const rest = entries.slice(13).reduce((s2, e) => s2 + e.value, 0);
              entries = [...entries.slice(0, 13), { label: `Other (${entries.length - 13})`, value: rest }];
            }
            const chartData: ChartDatum[] = entries;
            const measureLabel = !measureCol ? 'Records' : `${chartMeasure.startsWith('sum:') ? 'Total' : 'Average'} ${measureCol.label.toLowerCase()}`;
            const sel = (label: string, value: string, onChange: (v: string) => void, options: { value: string; label: string }[]) => (
              <label className="flex items-center gap-2 font-body text-[11px] font-bold uppercase tracking-wider text-muted">
                {label}
                <Select options={options} value={value} onChange={(v) => v && onChange(v)} searchable={options.length > 8} className="w-44 normal-case tracking-normal" />
              </label>
            );
            return (
              <div className="space-y-4 p-4">
                <div className="flex flex-wrap items-center gap-3">
                  {sel('Group by', basisCol.key, setChartBasis, columns.map((c) => ({ value: c.key, label: c.label })))}
                  {sel('Measure', chartMeasure, setChartMeasure, [
                    { value: 'count', label: 'Count of records' },
                    ...numericCols.flatMap((c) => [{ value: `sum:${c.key}`, label: `Total ${c.label}` }, { value: `avg:${c.key}`, label: `Average ${c.label}` }]),
                  ])}
                  <span className="ml-auto font-body text-[11.5px] text-muted">{processed.length} records · {entries.length} groups</span>
                </div>
                <Chart key={`${basisCol.key}|${chartMeasure}`} title={`${measureLabel} by ${basisCol.label.toLowerCase()}`} data={chartData}
                  defaultKind={isNumBasis ? 'bar' : entries.length <= 6 ? 'donut' : 'bar'} height={320}
                  extraKinds={['funnel', 'pyramid']} yLabel={measureLabel} />
              </div>
            );
          })()}

          {/* ---- footer ---- */}
          {(view === 'list' || view === 'gallery') && (
            <div className="flex flex-wrap items-center justify-between gap-3 border-t tk-divider px-4 py-3">
              <p className="font-body text-[12px] text-muted">
                Page {page + 1} of {totalPages} · {processed.length} records
              </p>
              <div className="flex items-center gap-1">
                <button disabled={page === 0} onClick={() => setPage((p) => p - 1)} className="tk-btn-ghost rounded-lg p-1.5 disabled:opacity-40"><ChevronLeft size={14} /></button>
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const p = totalPages <= 5 ? i : Math.max(0, Math.min(page - 2, totalPages - 5)) + i;
                  return (
                    <button key={p} onClick={() => setPage(p)}
                      className={`h-7 w-7 rounded-lg font-body text-[12px] font-bold transition ${p === page ? 'tk-btn-primary !p-0' : 'text-muted hover:text-ink'}`}>
                      {p + 1}
                    </button>
                  );
                })}
                <button disabled={page >= totalPages - 1} onClick={() => setPage((p) => p + 1)} className="tk-btn-ghost rounded-lg p-1.5 disabled:opacity-40"><ChevronRight size={14} /></button>
              </div>
            </div>
          )}
        </>
      )}

      {/* ---- record detail modal (calendar & day list) ---- */}
      <Modal open={detailRow !== null} onClose={() => setDetailRow(null)} title={detailRow ? cardTitle(detailRow) : 'Record'}>
        {detailRow && (
          <div className="space-y-3">
            {cardSub(detailRow) && <p className="font-body text-[12.5px] text-muted">{cardSub(detailRow)}</p>}
            <div className="grid gap-x-6 gap-y-3 sm:grid-cols-2">
              {columns.map((c) => (
                <div key={c.key}>
                  <p className="font-body text-[10px] font-bold uppercase tracking-wider text-muted">{c.label}</p>
                  <p className="mt-0.5 break-words font-body text-[13px] font-semibold text-ink">{c.render ? c.render(detailRow) : cellText(detailRow, c) || '—'}</p>
                </div>
              ))}
            </div>
            {onRowClick && (
              <div className="flex justify-end pt-1">
                <button onClick={() => { const r = detailRow; setDetailRow(null); onRowClick(r); }} className="tk-btn-primary rounded-xl px-4 py-2 font-body text-[12.5px] font-bold">Open record</button>
              </div>
            )}
          </div>
        )}
      </Modal>
      <Modal open={dayList !== null && detailRow === null} onClose={() => setDayList(null)} title={dayList?.label || ''}>
        {dayList && (
          <div className="space-y-1.5">
            {dayList.rows.map((r) => (
              <button key={String(rowKey(r))} onClick={() => setDetailRow(r)}
                className="tk-raise-sm flex w-full items-center justify-between gap-3 rounded-xl px-3.5 py-2.5 text-left transition hover:-translate-y-0.5">
                <span className="min-w-0">
                  <span className="block truncate font-body text-[13px] font-bold text-ink">{cardTitle(r)}</span>
                  <span className="block truncate font-body text-[11.5px] text-muted">{cardSub(r)}</span>
                </span>
                {card?.badge && <Badge tone="green">{card.badge(r)}</Badge>}
              </button>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
