// Stub for jsPDF's optional peers (canvg / dompurify / html2canvas-in-pdf paths) — not used by the studio exports.
export default {};
