declare module 'qrcode' {
  interface QRCodeToDataURLOptions {
    margin?: number; width?: number; scale?: number; errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
    color?: { dark?: string; light?: string };
  }
  const QRCode: { toDataURL(text: string, opts?: QRCodeToDataURLOptions): Promise<string> };
  export default QRCode;
}

/* Fontsource packages that export './*' → './*.css' are imported without the extension */
declare module '@fontsource/*';
