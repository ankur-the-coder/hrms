import { useState, useEffect, useCallback } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { api } from '../lib/api';

/* ============================================================
   Studio shared library — persistence, export and image tools
   used by the Document, ID Card and Email studios.
   ============================================================ */

export type AssetKind = 'document' | 'idcard' | 'email';
export interface Asset<P = unknown> { id: number; kind: AssetKind; name: string; payload: P; thumbnail: string | null; created_at: string; updated_at: string }

export function useAssets<P>(kind: AssetKind) {
  const [items, setItems] = useState<Asset<P>[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const reload = useCallback(() => {
    setLoading(true);
    api<Asset<P>[]>(`studio?kind=${kind}`).then(setItems).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, [kind]);
  useEffect(reload, [reload]);
  const save = async (name: string, payload: P, id?: number, thumbnail?: string | null) => {
    const res = id
      ? await api<Asset<P>>('studio', { method: 'PUT', body: JSON.stringify({ id, name, payload, thumbnail }) })
      : await api<Asset<P>>('studio', { method: 'POST', body: JSON.stringify({ kind, name, payload, thumbnail }) });
    reload();
    return res;
  };
  const remove = async (id: number) => { await api('studio', { method: 'DELETE', body: JSON.stringify({ id }) }); reload(); };
  return { items, loading, error, reload, save, remove };
}

/* ---------- ids & files ---------- */
export const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3);

export function downloadBlob(name: string, blob: Blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
export const downloadDataUrl = (name: string, dataUrl: string) => { const a = document.createElement('a'); a.href = dataUrl; a.download = name; a.click(); };

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(new Error('Could not read file'));
    r.readAsDataURL(file);
  });
}
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Image failed to load'));
    img.src = src;
  });
}
/** Downscale large uploads so designs stay light enough to save. */
export async function fitImage(dataUrl: string, maxSide = 1600): Promise<string> {
  const img = await loadImage(dataUrl);
  const s = Math.min(1, maxSide / Math.max(img.width, img.height));
  if (s >= 1 && dataUrl.length < 900_000) return dataUrl;
  const cv = document.createElement('canvas');
  cv.width = Math.round(img.width * s); cv.height = Math.round(img.height * s);
  cv.getContext('2d')!.drawImage(img, 0, 0, cv.width, cv.height);
  return cv.toDataURL(dataUrl.startsWith('data:image/png') ? 'image/png' : 'image/jpeg', 0.9);
}

/* ---------- background removal (client-side, no upload) ----------
   Flood-fills from the image border: every pixel connected to the edge whose
   colour is within `tolerance` of the sampled background becomes transparent,
   so same-coloured details INSIDE the subject are kept. Optional feathering
   softens the cut edge. Works for studio photos, logos, product shots. */
export interface RemoveBgOptions { tolerance?: number; feather?: number; pick?: { x: number; y: number } | null }
export async function removeBackground(dataUrl: string, opts: RemoveBgOptions = {}): Promise<string> {
  const { tolerance = 34, feather = 1, pick = null } = opts;
  const img = await loadImage(dataUrl);
  const W = img.width, H = img.height;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0);
  const im = ctx.getImageData(0, 0, W, H);
  const d = im.data;
  const px = (x: number, y: number) => (y * W + x) * 4;
  // background reference: picked pixel, or the median of the border pixels
  let ref: [number, number, number];
  if (pick) { const i = px(Math.max(0, Math.min(W - 1, pick.x)), Math.max(0, Math.min(H - 1, pick.y))); ref = [d[i], d[i + 1], d[i + 2]]; }
  else {
    const samples: number[][] = [];
    const step = Math.max(1, Math.floor((W + H) / 200));
    for (let x = 0; x < W; x += step) { samples.push([d[px(x, 0)], d[px(x, 0) + 1], d[px(x, 0) + 2]]); samples.push([d[px(x, H - 1)], d[px(x, H - 1) + 1], d[px(x, H - 1) + 2]]); }
    for (let y = 0; y < H; y += step) { samples.push([d[px(0, y)], d[px(0, y) + 1], d[px(0, y) + 2]]); samples.push([d[px(W - 1, y)], d[px(W - 1, y) + 1], d[px(W - 1, y) + 2]]); }
    const med = (k: number) => samples.map((s) => s[k]).sort((a, b) => a - b)[Math.floor(samples.length / 2)];
    ref = [med(0), med(1), med(2)];
  }
  const tol2 = tolerance * tolerance * 3;
  const close = (i: number) => { const dr = d[i] - ref[0], dg = d[i + 1] - ref[1], db = d[i + 2] - ref[2]; return dr * dr + dg * dg + db * db <= tol2; };
  const mask = new Uint8Array(W * H); // 1 = background
  const stack: number[] = [];
  const seed = (x: number, y: number) => { const k = y * W + x; if (!mask[k] && close(k * 4)) { mask[k] = 1; stack.push(k); } };
  if (pick) seed(Math.max(0, Math.min(W - 1, pick.x)), Math.max(0, Math.min(H - 1, pick.y)));
  else { for (let x = 0; x < W; x++) { seed(x, 0); seed(x, H - 1); } for (let y = 0; y < H; y++) { seed(0, y); seed(W - 1, y); } }
  while (stack.length) {
    const k = stack.pop()!;
    const x = k % W, y = (k - x) / W;
    if (x > 0) seed(x - 1, y);
    if (x < W - 1) seed(x + 1, y);
    if (y > 0) seed(x, y - 1);
    if (y < H - 1) seed(x, y + 1);
  }
  // alpha: 0 for background; feather = soften pixels adjacent to the cut
  for (let k = 0; k < W * H; k++) if (mask[k]) d[k * 4 + 3] = 0;
  if (feather > 0) {
    const alpha = new Uint8ClampedArray(W * H);
    for (let k = 0; k < W * H; k++) alpha[k] = d[k * 4 + 3];
    const r = Math.round(feather);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const k = y * W + x;
      if (!alpha[k]) continue;
      let bg = 0, n = 0;
      for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
        const xx = x + dx, yy = y + dy;
        if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
        n++; if (!alpha[yy * W + xx]) bg++;
      }
      if (bg) d[k * 4 + 3] = Math.round(alpha[k] * (1 - (bg / n) * 0.85));
    }
  }
  ctx.putImageData(im, 0, 0);
  return cv.toDataURL('image/png');
}

/* ---------- DOM → raster / PDF ---------- */
export async function captureNode(node: HTMLElement, scale = 2, background: string | null = null): Promise<HTMLCanvasElement> {
  try { await (document as unknown as { fonts?: { ready: Promise<unknown> } }).fonts?.ready; } catch { /* noop */ }
  return html2canvas(node, { scale, backgroundColor: background, useCORS: true, logging: false });
}
export function canvasToPdf(canvases: HTMLCanvasElement[], wMm: number, hMm: number, name: string) {
  const pdf = new jsPDF({ orientation: wMm > hMm ? 'landscape' : 'portrait', unit: 'mm', format: [wMm, hMm], compress: true });
  canvases.forEach((cv, i) => {
    if (i > 0) pdf.addPage([wMm, hMm], wMm > hMm ? 'landscape' : 'portrait');
    pdf.addImage(cv.toDataURL('image/jpeg', 0.95), 'JPEG', 0, 0, wMm, hMm);
  });
  pdf.save(name);
}
export { jsPDF };

/* ---------- merge fields ---------- */
export function mergeFields(text: string, data: Record<string, string | number | null | undefined>): string {
  return text.replace(/\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}/g, (_, k: string) => {
    const v = data[k];
    return v === null || v === undefined || v === '' ? `{{${k}}}` : String(v);
  });
}
export const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/* ---------- units ---------- */
export type Unit = 'px' | 'mm' | 'in';
export const toPx = (v: number, unit: Unit, dpi = 96) => (unit === 'px' ? v : unit === 'mm' ? (v / 25.4) * dpi : v * dpi);
export const fromPx = (px: number, unit: Unit, dpi = 96) => (unit === 'px' ? px : unit === 'mm' ? (px / dpi) * 25.4 : px / dpi);
