import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default (defineConfig as any)(async ({ mode }: { mode: string }) => {
  const plugins = [react(), tailwindcss()];
  try {
    // @ts-ignore
    const m = await import('./.vite-source-tags.js');
    plugins.push(m.sourceTags());
  } catch {}

  const env = loadEnv(mode, process.cwd(), ['VITE_', 'NEXT_PUBLIC_']);
  const processEnvDefines: Record<string, string> = {};
  for (const [key, value] of Object.entries(env)) {
    processEnvDefines[`process.env.${key}`] = JSON.stringify(value);
  }

  return {
    plugins,
    envPrefix: ['VITE_', 'NEXT_PUBLIC_'],
    define: processEnvDefines,
    resolve: {
      alias: [
        // jsPDF optional peers (SVG-in-PDF path) — unused here, and canvg drags in core-js
        { find: /^canvg$/, replacement: '/src/studio/empty.ts' },
        { find: /^dompurify$/, replacement: '/src/studio/empty.ts' },
      ],
    },
    build: { chunkSizeWarningLimit: 1600 },
  };
})
