// See https://svelte.dev/docs/kit/types#app.d.ts
declare global {
  namespace App {
    // interface Error {}
    // interface Locals {}
    // interface PageData {}
  }
  interface Window {
    pdfMake?: unknown;
    ExcelJS?: unknown;
  }
}

export {};
