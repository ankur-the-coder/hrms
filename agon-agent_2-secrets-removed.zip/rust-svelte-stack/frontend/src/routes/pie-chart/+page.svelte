<script lang="ts">
  // Pie Chart — standalone page. Mirrors React src/pages/PieChart.tsx.
  // Slices the live roster (GET /api/v1/org/people) by any dimension and
  // renders an interactive pie (Chart.svelte) + neumorphic pie (NeuDonut)
  // + slice breakdown table.
  import { onMount } from 'svelte';
  import { api } from '$lib/api';
  import Chart from '$lib/components/Chart.svelte';
  import NeuDonut from '$lib/components/NeuDonut.svelte';
  import NeuLoader from '$lib/components/NeuLoader.svelte';

  interface Person {
    id: number; full_name: string; gender: string; dept: string; role: string; status: string; location: string;
    employment_type: string; worker_type: string; nationality: string; business_unit: string; cost_center: string; legal_entity: string;
  }
  type DimKey = keyof Omit<Person, 'id' | 'full_name'>;

  const DIMENSIONS: { key: DimKey; label: string }[] = [
    { key: 'dept', label: 'Department' }, { key: 'gender', label: 'Gender' }, { key: 'location', label: 'Location' },
    { key: 'employment_type', label: 'Employment Type' }, { key: 'worker_type', label: 'Worker Type' },
    { key: 'nationality', label: 'Nationality' }, { key: 'business_unit', label: 'Business Unit' },
    { key: 'legal_entity', label: 'Legal Entity' }, { key: 'cost_center', label: 'Cost Center' },
    { key: 'status', label: 'Employee Status' }, { key: 'role', label: 'Job Title' },
  ];
  const PALETTE = ['#0d7a54', '#c9932b', '#0ea5e9', '#e11d63', '#f97316', '#14b8a6', '#1e5aa8', '#84cc16', '#f43f5e', '#a16207', '#06b6d4', '#64748b'];

  let people = $state<Person[]>([]);
  let loading = $state(true);
  let error = $state('');
  let dim = $state<DimKey>('dept');
  let scope = $state<'active' | 'all'>('active');
  let focus = $state('');

  async function load() {
    loading = true; error = '';
    try { people = await api<Person[]>('org/people'); }
    catch (e) { error = e instanceof Error ? e.message : 'Failed to load'; }
    finally { loading = false; }
  }
  onMount(load);

  const dimLabel = $derived(DIMENSIONS.find((d) => d.key === dim)?.label || '');
  const depts = $derived([...new Set(people.map((p) => p.dept).filter(Boolean))].sort());
  const rows = $derived(people.filter((p) => (scope === 'all' || p.status !== 'Exited') && (!focus || p.dept === focus)));
  const slices = $derived.by(() => {
    const m = new Map<string, number>();
    rows.forEach((p) => { const k = p[dim] || 'Not Specified'; m.set(k, (m.get(k) || 0) + 1); });
    const total = rows.length || 1;
    return [...m.entries()].map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value)
      .map((d, i) => ({ ...d, share: (d.value / total) * 100, color: PALETTE[i % PALETTE.length] }));
  });
  const largest = $derived(slices[0]);
  const smallest = $derived(slices[slices.length - 1]);

  function reset() { dim = 'dept'; scope = 'active'; focus = ''; }
</script>

<p class="eyebrow">Extra page · Visualisation</p>
<h1>Pie chart</h1>
<p class="sub">Live composition of your workforce, sliced any way you like.</p>

{#if loading}
  <div class="tk-card"><NeuLoader label="Slicing the roster…" /></div>
{:else}
  {#if error}<div class="tk-card err">{error} <button onclick={load}>retry</button></div>{/if}

  <div class="tk-card controls">
    <select class="tk-input" bind:value={dim}>
      {#each DIMENSIONS as d (d.key)}<option value={d.key}>{d.label}</option>{/each}
    </select>
    <select class="tk-input" bind:value={focus}>
      <option value="">All departments</option>
      {#each depts as d (d)}<option value={d}>{d}</option>{/each}
    </select>
    <div class="tk-inset seg">
      <button class:on={scope === 'active'} onclick={() => (scope = 'active')}>Active only</button>
      <button class:on={scope === 'all'} onclick={() => (scope = 'all')}>Everyone</button>
    </div>
    <button class="tk-btn-ghost reset" onclick={reset}>Reset</button>
    <span class="tk-chip">{rows.length} in scope</span>
  </div>

  <div class="kpis">
    <div class="tk-card kpi"><b>{rows.length}</b><small>Employees in scope</small></div>
    <div class="tk-card kpi"><b>{slices.length}</b><small>{dimLabel} slices</small></div>
    <div class="tk-card kpi"><b>{largest ? `${largest.label} · ${largest.share.toFixed(0)}%` : '—'}</b><small>Largest slice</small></div>
    <div class="tk-card kpi"><b>{smallest ? `${smallest.label} · ${smallest.share.toFixed(0)}%` : '—'}</b><small>Smallest slice</small></div>
  </div>

  {#if rows.length === 0}
    <div class="tk-card empty"><b>Nothing to slice</b><span>No employees match the current filters.</span></div>
  {:else}
    <div class="charts">
      {#key `${dim}-${scope}-${focus}`}
        <Chart title={`Headcount by ${dimLabel}${focus ? ` · ${focus}` : ''}`} data={slices} defaultKind="pie" height={380} />
        <NeuDonut title={`${dimLabel} mix`} data={slices} size={150} centerLabel="people" legendSide />
      {/key}
    </div>

    <div class="tk-card table">
      <table>
        <thead><tr><th>{dimLabel}</th><th>Headcount</th><th>Share</th></tr></thead>
        <tbody>
          {#each slices as s (s.label)}
            <tr>
              <td><span class="dot" style={`background:${s.color}`}></span>{s.label}</td>
              <td class="num">{s.value}</td>
              <td><span class="tk-inset bar"><span style={`width:${s.share}%;background:${s.color}`}></span></span> <span class="num muted">{s.share.toFixed(1)}%</span></td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
  {/if}
{/if}

<style>
  .eyebrow { margin: 0; font: 700 12px var(--t-font-body); text-transform: uppercase; letter-spacing: 0.18em; color: var(--t-accent); }
  h1 { margin: 4px 0 4px; font: 600 26px var(--t-font-display); color: var(--t-ink); }
  .sub { margin: 0 0 20px; font: 400 13px var(--t-font-body); color: var(--t-muted); }
  .err { padding: 10px 16px; margin-bottom: 16px; font: 400 13px var(--t-font-body); color: #f43f5e; }
  .err button { font-weight: 700; text-decoration: underline; color: inherit; }
  .controls { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; padding: 12px; margin-bottom: 20px; }
  .controls select { width: 180px; padding: 8px 12px; font: 600 13px var(--t-font-body); color: var(--t-ink); }
  .seg { display: flex; gap: 2px; padding: 4px; border-radius: 12px; }
  .seg button { padding: 6px 12px; border-radius: 8px; font: 700 11.5px var(--t-font-body); color: var(--t-muted); }
  .seg button.on { color: var(--t-accent); box-shadow: var(--t-shadow-card); background: var(--t-surface); }
  .reset { margin-left: auto; padding: 8px 12px; font: 700 12px var(--t-font-body); }
  .kpis { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin-bottom: 20px; }
  .kpi { padding: 16px; }
  .kpi b { display: block; font: 600 20px var(--t-font-display); color: var(--t-ink); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .kpi small { display: block; margin-top: 4px; font: 700 10.5px var(--t-font-body); text-transform: uppercase; letter-spacing: 0.08em; color: var(--t-muted); }
  .empty { padding: 48px 24px; text-align: center; }
  .empty b { display: block; font: 600 16px var(--t-font-display); color: var(--t-ink); }
  .empty span { font: 400 12.5px var(--t-font-body); color: var(--t-muted); }
  .charts { display: grid; grid-template-columns: 1fr; gap: 20px; margin-bottom: 20px; }
  @media (min-width: 1200px) { .charts { grid-template-columns: 1fr 360px; } }
  .table { padding: 8px 16px; overflow-x: auto; }
  table { width: 100%; border-collapse: collapse; font: 400 13px var(--t-font-body); color: var(--t-ink); }
  th { text-align: left; padding: 10px 8px; font: 700 10.5px var(--t-font-body); text-transform: uppercase; letter-spacing: 0.08em; color: var(--t-muted); }
  td { padding: 10px 8px; border-top: 1px solid color-mix(in srgb, var(--t-ink) 8%, transparent); font-weight: 600; }
  .dot { display: inline-block; width: 12px; height: 12px; border-radius: 999px; margin-right: 10px; vertical-align: -1px; }
  .num { font-variant-numeric: tabular-nums; }
  .muted { color: var(--t-muted); }
  .bar { display: inline-block; width: 112px; height: 8px; border-radius: 999px; overflow: hidden; vertical-align: middle; margin-right: 8px; }
  .bar span { display: block; height: 100%; border-radius: 999px; transition: width 0.5s; }
</style>
