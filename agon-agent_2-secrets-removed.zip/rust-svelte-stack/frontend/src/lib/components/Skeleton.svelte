<script lang="ts">
  // Shimmer skeleton — mirrors React src/shared/primitives.tsx `Skeleton` /
  // `ChartSkeleton`. Token-driven so it reads on every theme + dark mode.
  // kind: 'block' (default) | 'circle' | 'bars' | 'columns' | 'line'
  let { kind = 'block', width = '100%', height = 16, legend = true } = $props<{
    kind?: 'block' | 'circle' | 'bars' | 'columns' | 'line'; width?: string | number; height?: number; legend?: boolean;
  }>();
  const px = (v: string | number) => (typeof v === 'number' ? `${v}px` : v);
  const s = $derived(Math.max(96, Math.min(height - 24, 190)));
</script>

{#if kind === 'circle'}
  <div class="row" style={`height:${height}px`} aria-busy="true">
    <div class="sk ring" style={`width:${s}px;height:${s}px`}><span style={`inset:${s * 0.29}px`}></span></div>
    {#if legend}
      <div class="col">
        {#each [82, 64, 72, 54] as w (w)}<div class="legend"><span class="sk dot"></span><span class="sk" style={`width:${w}%;height:10px`}></span></div>{/each}
      </div>
    {/if}
  </div>
{:else if kind === 'bars'}
  <div class="col" style={`height:${height}px;justify-content:center`} aria-busy="true">
    {#each [88, 64, 74, 46, 58] as w (w)}
      <div class="bar"><div class="between"><span class="sk" style="width:96px;height:10px"></span><span class="sk" style="width:32px;height:10px"></span></div><span class="sk" style={`width:${w}%;height:16px;border-radius:999px`}></span></div>
    {/each}
  </div>
{:else if kind === 'columns'}
  <div class="cols" style={`height:${height}px`} aria-busy="true">
    {#each [46, 72, 58, 88, 64, 78, 40] as h, i (i)}<span class="sk" style={`height:${h}%;animation-delay:${i * 90}ms`}></span>{/each}
  </div>
{:else if kind === 'line'}
  <div class="line" style={`height:${height}px`} aria-busy="true"><span class="sk plot"></span></div>
{:else}
  <span class="sk" style={`width:${px(width)};height:${px(height)}`} aria-hidden="true"></span>
{/if}

<style>
  @keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
  .sk {
    display: block; border-radius: var(--t-radius);
    background: linear-gradient(100deg,
      color-mix(in srgb, var(--t-ink) 7%, var(--t-surface)) 0%, color-mix(in srgb, var(--t-ink) 7%, var(--t-surface)) 38%,
      color-mix(in srgb, var(--t-ink) 3%, var(--t-surface2)) 50%,
      color-mix(in srgb, var(--t-ink) 7%, var(--t-surface)) 62%, color-mix(in srgb, var(--t-ink) 7%, var(--t-surface)) 100%);
    background-size: 300% 100%; animation: shimmer 1.7s cubic-bezier(0.4, 0, 0.2, 1) infinite;
    box-shadow: inset 1px 1px 2px color-mix(in srgb, var(--t-ink) 6%, transparent);
  }
  .row { display: flex; align-items: center; gap: 20px; }
  .col { display: flex; flex-direction: column; gap: 12px; flex: 1; min-width: 0; }
  .ring { position: relative; border-radius: 999px; flex-shrink: 0; }
  .ring span { position: absolute; border-radius: 999px; background: var(--t-surface); }
  .legend { display: flex; align-items: center; gap: 10px; }
  .dot { width: 10px; height: 10px; border-radius: 999px; flex-shrink: 0; }
  .bar { display: flex; flex-direction: column; gap: 6px; }
  .between { display: flex; justify-content: space-between; }
  .cols { display: flex; align-items: flex-end; gap: 12px; padding: 4px 0 28px 32px; }
  .cols .sk { flex: 1; border-radius: 10px 10px 0 0; }
  .line { position: relative; padding: 4px 0 28px 40px; }
  .plot { width: 100%; height: 100%; border-radius: 16px; }
  @media (prefers-reduced-motion: reduce) { .sk { animation: none; } }
</style>
