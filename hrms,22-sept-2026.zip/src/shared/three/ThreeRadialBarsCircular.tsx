import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import type { ChartDatum } from '../Charts';
import { buildThreePNG, captureLabelPositions, withExportResolution, type ExportTheme } from './exportUtils';
import type { ThreeChartHandle } from './ThreeSankey3D';

/* ============================================================
   Radial Bars Circular — faithful port of 3d_radial_bar_chart.html
   (Trust-in-Europe reference) into a data-driven card component.

   Reference elements, 1:1:
   - Extruded arc-wedge bars (THREE.Shape.absarc + ExtrudeGeometry,
     bevel on, rotateX(π/2) onto the XZ plane), barHeight 0.5
   - Concentric dashed scale rings + prior-period red arc markers +
     increase/decrease cone arrows around the perimeter
   - Ground shadow disc + outer rim, dashed average ring + tag
   - CSS2D country/category pills + scale labels, glass tooltip with
     delta badge, TWEEN-style hover (Y-scale pop + darker fill)
   - Camera (0,22,24) fov 45, OrbitControls damping, reset/auto-rotate/
     height-toggle controls, entrance Back.Out stagger.

   Adaptations (data-driven only): the reference hard-codes 30 Eurostat
   rows; here `data` supplies the primary values and `series[0..1]`
   (when multi) the current/prior pair. Colours default to the theme
   palette; the reference's blue-600/red-500 semantics (current/prior)
   are preserved via marker + tooltip language.
   ============================================================ */

interface Props {
  data: ChartDatum[];
  categories?: string[];
  series?: { name: string; color?: string; values: number[] }[];
  palette: string[];
  dim: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (idx: number | null, text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

function escXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Semantic legend mirroring the source HTML's legend card (bars are ONE
   blue material, so per-category swatches would misrepresent the chart). */
const RBC_LEGEND = [
  { label: 'Current (bar)', color: '#2563eb' },
  { label: 'Prior (marker)', color: '#ef4444' },
  { label: '▲ Increased', color: '#2563eb' },
  { label: '▼ Fell', color: '#ef4444' },
  { label: 'Average (dashed)', color: '#f87171' },
];

// Tiny tween helper (reference uses TWEEN; keep dependency-free here).
function tweenNum(from: number, to: number, dur: number, delay: number, ease: (t: number) => number, onU: (v: number) => void, onC?: () => void) {
  const t0 = performance.now() + delay;
  let raf = 0;
  const tick = (now: number) => {
    const t = Math.min(1, Math.max(0, (now - t0) / dur));
    onU(from + (to - from) * ease(t));
    if (t < 1) raf = requestAnimationFrame(tick);
    else onC?.();
  };
  raf = requestAnimationFrame(tick);
  return () => cancelAnimationFrame(raf);
}
const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
const easeOutBack = (t: number) => { const c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };

const RBC3D = forwardRef<ThreeChartHandle, Props>(function RBC3D(
  { data, categories, series, palette, dim, hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; title: string; cur: string; prior: string; delta: string; up: boolean; curLbl: string; priorLbl: string } | null>(null);
  const [autoRot, setAutoRot] = useState(false);

  const api = useRef<{
    renderer: THREE.WebGLRenderer;
    labelRenderer: CSS2DRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    setMode: (m: '2D' | '3D') => void;
    setZoom: (on: boolean) => void;
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    const container: HTMLDivElement = containerRef.current!;
    if (!containerRef.current) return;

    // ---- data model: primary + optional prior -------------------------
    const rows = (data || []).slice(0, 30);
    const n = Math.max(1, rows.length);
    const multi = !!(series && series.length >= 2 && categories && categories.length >= 2);
    const curLbl = multi ? series![0].name : 'Current';
    const priorLbl = multi && series!.length > 1 ? series![1].name : 'Prior';
    const cur = rows.map((d, i) => (multi ? series![0].values[i] ?? d.value : d.value));
    // Prior period: series[1] when multi, else the datum's own `prior` field
    // (the gallery dataset ships its current-vs-prior pairs inline).
    const prior = rows.map((d, i) => (multi && series!.length > 1
      ? series![1].values[i] ?? NaN
      : (d.prior != null && Number.isFinite(d.prior) ? d.prior : NaN)));
    const hasPrior = prior.some((v) => Number.isFinite(v));
    const names = rows.map((d) => d.label);
    const maxV = Math.max(1, ...cur, ...prior.filter(Number.isFinite));
    // map values onto the reference's 0–10 rating span
    const toRating = (v: number) => (v / maxV) * 10;
    const curR = cur.map(toRating);
    const priorR = prior.map((v) => (Number.isFinite(v) ? toRating(v as number) : NaN));
    const avgR = curR.reduce((a, b) => a + b, 0) / Math.max(1, curR.length);

    const INNER_RADIUS = 3.5;
    const RADIUS_PER_UNIT = 0.8;
    const MAX_RATING = 10;
    const CHART_OUTER_RADIUS = INNER_RADIUS + MAX_RATING * RADIUS_PER_UNIT;
    const BAR_H = 0.5;

    // ---- scene (reference verbatim, card-scoped) -----------------------
    const scene = new THREE.Scene();
    scene.background = null;
    scene.fog = null;
    const W0 = container.clientWidth || 640, H0 = container.clientHeight || 460;
    const camera = new THREE.PerspectiveCamera(45, W0 / H0, 0.1, 1000);
    camera.position.set(0, 22, 24);
    // GPU OPTIMIZATION: `preserveDrawingBuffer` forces the browser to skip
    // its normal implicit-clear/fast-swap path on every single frame —
    // it's only needed if a pixel read (toDataURL) can happen an
    // arbitrary time after the last render. exportPNG below always calls
    // renderer.render() synchronously right before reading pixels, so the
    // buffer is guaranteed valid without paying this cost every frame.
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(W0, H0);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = false;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.setSize(W0, H0);
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.minDistance = 10;
    controls.maxDistance = 50;
    controls.target.set(0, 0, 0);
    controls.enableZoom = false;

    // LIGHTING: bumped — the bars were reading dim/flat; ambient and both
    // directionals are stronger now so the extruded wedges show clear
    // depth/gloss without blowing out the blue highlight colour.
    scene.add(new THREE.AmbientLight(dark ? 0xdde6f0 : 0xffffff, dark ? 0.72 : 0.95));
    const mainLight = new THREE.DirectionalLight(0xffffff, dark ? 0.9 : 1.05);
    mainLight.position.set(15, 25, 15);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.set(1024, 1024);
    mainLight.shadow.camera.near = 0.5;
    mainLight.shadow.camera.far = 60;
    const dd = 16;
    mainLight.shadow.camera.left = -dd;
    mainLight.shadow.camera.right = dd;
    mainLight.shadow.camera.top = dd;
    mainLight.shadow.camera.bottom = -dd;
    mainLight.shadow.bias = -0.0005;
    scene.add(mainLight);
    const fillLight = new THREE.DirectionalLight(0x93c5fd, 0.5);
    fillLight.position.set(-15, 15, -15);
    scene.add(fillLight);

    const barGroup = new THREE.Group();
    const markersGroup = new THREE.Group();
    const guideGroup = new THREE.Group();
    const labelsGroup = new THREE.Group();
    scene.add(barGroup, markersGroup, guideGroup, labelsGroup);

    // ground shadow disc + rim
    {
      const plane = new THREE.Mesh(
        new THREE.CircleGeometry(CHART_OUTER_RADIUS + 4, 64),
        new THREE.ShadowMaterial({ opacity: dark ? 0.22 : 0.06 }),
      );
      plane.rotation.x = -Math.PI / 2;
      plane.position.y = -0.01;
      plane.receiveShadow = true;
      scene.add(plane);
      const rim = new THREE.Mesh(
        new THREE.RingGeometry(CHART_OUTER_RADIUS + 0.1, CHART_OUTER_RADIUS + 0.15, 128),
        new THREE.MeshBasicMaterial({ color: dark ? 0x334155 : 0xe2e8f0, side: THREE.DoubleSide }),
      );
      rim.rotation.x = -Math.PI / 2;
      scene.add(rim);
    }

    // dashed scale rings + numeric scale labels + average ring + tag
    const gridCol = dark ? 0x475569 : 0xcbd5e1;
    [2, 4, 6, 8, 10].forEach((val) => {
      const radius = INNER_RADIUS + val * RADIUS_PER_UNIT;
      const pts: THREE.Vector3[] = [];
      for (let i = 0; i <= 128; i++) {
        const th = (i / 128) * Math.PI * 2;
        pts.push(new THREE.Vector3(Math.cos(th) * radius, 0, Math.sin(th) * radius));
      }
      const line = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineDashedMaterial({ color: gridCol, dashSize: 0.2, gapSize: 0.15 }),
      );
      line.computeLineDistances();
      guideGroup.add(line);
      const sDiv = document.createElement('div');
      sDiv.className = 'rbc-scale-label';
      sDiv.textContent = String(Math.round((val / 10) * maxV));
      sDiv.style.fontFamily = theme.fontBody;
      const sObj = new CSS2DObject(sDiv);
      sObj.position.set(0, 0.1, -radius);
      guideGroup.add(sObj);
    });
    {
      const euRadius = INNER_RADIUS + avgR * RADIUS_PER_UNIT;
      const pts: THREE.Vector3[] = [];
      for (let i = 0; i <= 128; i++) {
        const th = (i / 128) * Math.PI * 2;
        pts.push(new THREE.Vector3(Math.cos(th) * euRadius, 0.02, Math.sin(th) * euRadius));
      }
      const eu = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineDashedMaterial({ color: 0xef4444, dashSize: 0.3, gapSize: 0.2 }),
      );
      eu.computeLineDistances();
      guideGroup.add(eu);
      const euDiv = document.createElement('div');
      euDiv.className = 'rbc-avg-tag';
      euDiv.textContent = 'Average';
      euDiv.style.fontFamily = theme.fontBody;
      const euObj = new CSS2DObject(euDiv);
      const aEU = -Math.PI * 0.72;
      euObj.position.set(Math.cos(aEU) * euRadius, 0.1, Math.sin(aEU) * euRadius);
      guideGroup.add(euObj);
    }

    // ---- bars + markers + arrows + labels ------------------------------
    const interactive: THREE.Mesh[] = [];
    const labelRefs: { el: HTMLElement; text: string; color?: string }[] = [];
    const canceller: (() => void)[] = [];
    // Source-HTML materials verbatim: polished blue-600 bars, blue-700 hover.
    const barBase = new THREE.Color('#2563eb');
    const barHi = new THREE.Color('#1d4ed8');
    const angleStep = (PI2(n));
    function PI2(_n: number) { return (Math.PI * 2) / _n; }
    const arrowUpGeo = new THREE.ConeGeometry(0.18, 0.35, 3);
    arrowUpGeo.rotateX(Math.PI / 2);
    const arrowDownGeo = new THREE.ConeGeometry(0.18, 0.35, 3);
    arrowDownGeo.rotateX(-Math.PI / 2);
    const arrowBlueMat = new THREE.MeshBasicMaterial({ color: 0x2563eb });
    const arrowRedMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });

    let hovered: THREE.Mesh | null = null;
    const setTipFor = (mesh: THREE.Mesh, cx: number, cy: number) => {
      const u = mesh.userData as { i: number };
      const i = u.i;
      const c = cur[i], pr = prior[i];
      const d = Number.isFinite(pr) ? c - (pr as number) : NaN;
      setTip({
        x: cx, y: cy, title: names[i],
        cur: `${fmt(c)}`, prior: Number.isFinite(pr) ? `${fmt(pr as number)}` : '—',
        delta: Number.isFinite(d) ? `${d >= 0 ? '+' : ''}${fmt(d)}` : '—',
        up: d >= 0, curLbl, priorLbl: priorLbl || 'Prior',
      });
    };
    const fmt = (v: number) => (Math.abs(v) >= 1000 ? (v / 1000).toFixed(1).replace(/\.0$/, '') + 'k' : String(Math.round(v * 10) / 10));

    rows.forEach((_d, index) => {
      const angleCenter = index * angleStep - Math.PI / 2;
      const angleWidth = angleStep * 0.62;
      const startAngle = angleCenter - angleWidth / 2;
      const endAngle = angleCenter + angleWidth / 2;
      const score2025 = curR[index];
      const score2013 = priorR[index];
      const outer2025 = INNER_RADIUS + score2025 * RADIUS_PER_UNIT;
      const outer2013 = Number.isFinite(score2013) ? INNER_RADIUS + (score2013 as number) * RADIUS_PER_UNIT : NaN;

      const shape = new THREE.Shape();
      shape.absarc(0, 0, INNER_RADIUS, startAngle, endAngle, false);
      const SEG = 12;
      for (let i = SEG; i >= 0; i--) {
        const a = startAngle + ((endAngle - startAngle) * i) / SEG;
        shape.lineTo(Math.cos(a) * outer2025, Math.sin(a) * outer2025);
      }
      shape.closePath();
      const barGeo = new THREE.ExtrudeGeometry(shape, {
        depth: BAR_H, bevelEnabled: true, bevelSegments: 3, steps: 1, bevelSize: 0.03, bevelThickness: 0.03,
      });
      barGeo.rotateX(Math.PI / 2);
      const mat = new THREE.MeshStandardMaterial({ color: barBase.clone(), roughness: 0.2, metalness: 0.1, shadowSide: THREE.DoubleSide });
      const barMesh = new THREE.Mesh(barGeo, mat);
      barMesh.position.y = BAR_H;
      barMesh.castShadow = true;
      barMesh.receiveShadow = true;
      barMesh.userData = { i: index, angleCenter };
      barGroup.add(barMesh);
      interactive.push(barMesh);

      if (Number.isFinite(outer2013)) {
        const mp = new THREE.Path();
        mp.absarc(0, 0, outer2013 as number, startAngle, endAngle, false);
        const mg = new THREE.BufferGeometry().setFromPoints(mp.getPoints(12));
        const ml = new THREE.Line(mg, new THREE.LineBasicMaterial({ color: 0xef4444 }));
        ml.rotation.x = Math.PI / 2;
        ml.position.y = BAR_H + 0.06;
        markersGroup.add(ml);
      }
      if (Number.isFinite(score2013)) {
        const up = score2025 >= (score2013 as number);
        const arrowMesh = new THREE.Mesh(up ? arrowUpGeo : arrowDownGeo, up ? arrowBlueMat : arrowRedMat);
        const ar = CHART_OUTER_RADIUS + 0.55;
        arrowMesh.position.set(Math.cos(angleCenter) * ar, 0.1, Math.sin(angleCenter) * ar);
        arrowMesh.rotation.y = -angleCenter + (up ? Math.PI / 2 : -Math.PI / 2);
        markersGroup.add(arrowMesh);
      }
      const cDiv = document.createElement('div');
      cDiv.className = 'rbc-country-label';
      cDiv.textContent = names[index];
      cDiv.style.fontFamily = theme.fontBody;
      cDiv.addEventListener('mouseenter', () => highlight(barMesh, -1, -1));
      cDiv.addEventListener('mouseleave', () => unhighlight());
      const lr = CHART_OUTER_RADIUS + 1.25;
      const lObj = new CSS2DObject(cDiv);
      lObj.position.set(Math.cos(angleCenter) * lr, 0.1, Math.sin(angleCenter) * lr);
      labelsGroup.add(lObj);
      labelRefs.push({ el: cDiv, text: names[index] });
    });

    function highlight(mesh: THREE.Mesh, cx: number, cy: number) {
      if (hovered === mesh) { if (cx >= 0) setTipFor(mesh, cx, cy); return; }
      unhighlight(true);
      hovered = mesh;
      canceller.push(tweenNum(mesh.scale.y, 1.4, 200, 0, easeOutCubic, (v) => { mesh.scale.y = v; wake(1); }));
      (mesh.material as THREE.MeshStandardMaterial).color.copy(barHi);
      const u = mesh.userData as { i: number };
      onHover?.(u.i, names[u.i]);
      if (cx >= 0) setTipFor(mesh, cx, cy);
      else {
        const rect = container.getBoundingClientRect();
        setTipFor(mesh, rect.width / 2, rect.height / 2);
      }
      container.style.cursor = 'pointer';
      wake();
    }
    function unhighlight(silent = false) {
      if (!hovered) return;
      const m = hovered;
      hovered = null;
      canceller.push(tweenNum(m.scale.y, 1.0, 200, 0, easeOutCubic, (v) => { m.scale.y = v; wake(1); }));
      (m.material as THREE.MeshStandardMaterial).color.copy(barBase);
      if (!silent) { setTip(null); onHover?.(null, null); container.style.cursor = 'grab'; wake(); }
    }

    // ---- camera modes: 2D = top-down twin, 3D = reference oblique -------
    const fitR = CHART_OUTER_RADIUS + 3.4;
    const dist2D = fitR / Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    const state2D = { camPos: new THREE.Vector3(0, dist2D, 0.01), camTarget: new THREE.Vector3(0, 0, 0), up: new THREE.Vector3(0, 0, -1) };
    const state3D = { camPos: new THREE.Vector3(0, 22, 24), camTarget: new THREE.Vector3(0, 0, 0), up: new THREE.Vector3(0, 1, 0) };
    let mode: '2D' | '3D' = '2D';
    let transitioning = false, tProg = 1;
    let needsFrame = true;
    let onScreen = true;
    let dampingTail = 0;
    const wake = (tail = 0) => { needsFrame = true; if (tail > dampingTail) dampingTail = tail; };
    const startPos = new THREE.Vector3(), startTg = new THREE.Vector3(), startUp = new THREE.Vector3();
    camera.position.copy(state2D.camPos);
    camera.up.copy(state2D.up);
    controls.target.copy(state2D.camTarget);
    function setMode(mm: '2D' | '3D') {
      if (mode === mm) return;
      mode = mm;
      controls.enabled = false;
      controls.enableDamping = false;
      transitioning = true; tProg = 0;
      startPos.copy(camera.position); startTg.copy(controls.target); startUp.copy(camera.up);
      renderer.shadowMap.needsUpdate = true;
      wake(2);
    }

    function resize() {
      const W = container.clientWidth || 640, H = container.clientHeight || 460;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
      wake();
    }
    const onVis = () => { if (!document.hidden) { resize(); wake(); } };
    document.addEventListener('visibilitychange', onVis);
    const onFs = () => { resize(); wake(); requestAnimationFrame(() => { resize(); wake(); }); };
    document.addEventListener('fullscreenchange', onFs);
    const onScroll = () => wake();
    window.addEventListener('scroll', onScroll, { passive: true, capture: true });
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    // entrance: Back.Out radial stagger (reference animateEntrance)
    barGroup.children.forEach((bar, i) => {
      bar.scale.set(0.01, 1, 0.01);
      canceller.push(tweenNum(0.01, 1, 1200, i * 30, easeOutBack, (v) => { bar.scale.x = v; bar.scale.z = v; wake(1); }));
    });
    const io = new IntersectionObserver((es) => {
      onScreen = es.some((e) => e.isIntersecting);
      if (onScreen) { resize(); wake(); }
    }, { threshold: 0 });
    io.observe(container);
    const onCtxLost = (e: Event) => { e.preventDefault(); };
    const onCtxRestored = () => { resize(); wake(); };
    renderer.domElement.addEventListener('webglcontextlost', onCtxLost, false);
    renderer.domElement.addEventListener('webglcontextrestored', onCtxRestored, false);

    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    function onPointerMove(e: PointerEvent) {
      const rect = container.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(interactive, false);
      if (hits.length) highlight(hits[0].object as THREE.Mesh, e.clientX - rect.left, e.clientY - rect.top);
      else unhighlight();
    }
    function onPointerLeave() { unhighlight(); }
    function onClick() { wake(); }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);
    renderer.domElement.addEventListener('click', onClick);

    let raf = 0;
    const tmpT = new THREE.Vector3();
    /* Demand-render: idle tiles sleep. Entrance tween, orbit damping,
       2D↔3D morph, hover and resize all wake the loop. First visible
       frame always paints so the drawing buffer cannot sit blank. */
    controls.addEventListener('change', () => { wake(2); renderer.shadowMap.needsUpdate = true; });
    controls.addEventListener('end', () => wake(28));
    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (!onScreen || document.hidden) return;
      if (!needsFrame && !transitioning && dampingTail <= 0) return;
      const target = mode === '2D' ? state2D : state3D;
      if (transitioning) {
        tProg += 0.022;
        if (tProg >= 1) {
          tProg = 1; transitioning = false;
          controls.enabled = true;
          controls.enableDamping = true;
        }
        const e = easeOutCubic(tProg);
        camera.position.lerpVectors(startPos, target.camPos, e);
        camera.up.lerpVectors(startUp, target.up, e).normalize();
        tmpT.lerpVectors(startTg, target.camTarget, e);
        controls.target.copy(tmpT);
        renderer.shadowMap.needsUpdate = true;
      } else {
        controls.update();
      }
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
      needsFrame = transitioning || dampingTail > 0 || !!controls.autoRotate;
      if (dampingTail > 0) dampingTail -= 1;
    };
    animate();

    const dispose = () => {
      cancelAnimationFrame(raf);
      canceller.forEach((c) => c());
      ro.disconnect();
      io.disconnect();
      renderer.domElement.removeEventListener('webglcontextlost', onCtxLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onCtxRestored);
      document.removeEventListener('visibilitychange', onVis);
      document.removeEventListener('fullscreenchange', onFs);
      window.removeEventListener('scroll', onScroll, true);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      renderer.domElement.removeEventListener('click', onClick);
      controls.dispose();
      renderer.dispose();
      // GPU FIX: force immediate WebGL context loss on unmount (see the
      // matching note in ThreeReferenceRadialBar/ThreeSankey3D) so VRAM
      // is reclaimed right away instead of waiting on browser GC.
      try { renderer.getContext().getExtension('WEBGL_lose_context')?.loseContext(); } catch { /* noop */ }
      if (renderer.domElement.parentElement === container) container.removeChild(renderer.domElement);
      if (labelRenderer.domElement.parentElement === container) container.removeChild(labelRenderer.domElement);
    };

    api.current = {
      renderer, labelRenderer, scene, camera, controls, labelRefs, setMode,
      setZoom: (on: boolean) => { controls.enableZoom = on; },
      dispose,
    };
    (api.current as unknown as { setAuto: (a: boolean) => void }).setAuto = (a: boolean) => {
      controls.autoRotate = a;
      controls.autoRotateSpeed = 1.5;
      wake(a ? 8 : 2);
    };
    (api.current as unknown as { reset: () => void }).reset = () => {
      const p0 = camera.position.clone(), t0 = controls.target.clone();
      canceller.push(tweenNum(0, 1, 1000, 0, easeOutCubic, (v) => {
        camera.position.lerpVectors(p0, state3D.camPos, v);
        controls.target.lerpVectors(t0, state3D.camTarget, v);
        wake();
      }));
    };
    setMode(dim === '3d' ? '3D' : '2D');
    // snap instantly on mount
    {
      const t = dim === '3d' ? state3D : state2D;
      camera.position.copy(t.camPos); controls.target.copy(t.camTarget); camera.up.copy(t.up);
      transitioning = false; controls.enabled = true;
    }
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify((data || []).map((d) => [d.label, d.value])), JSON.stringify(series || []), (categories || []).join('|'), palette.join('|'), dark]);

  useEffect(() => { api.current?.setMode(dim === '3d' ? '3D' : '2D'); }, [dim]);
  useEffect(() => {
    // legend hover → scene hover (badge flash via tooltip-less highlight)
    void hoverIndex;
  }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container.clientWidth, H = container.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(W, H, false);
      // never leave the live panel blank after an export
      a.renderer.render(a.scene, a.camera);
      a.labelRenderer.render(a.scene, a.camera);
      const cv = await buildThreePNG({
        title, imageDataUrl: dataUrl, chartW: W, chartH: H,
        // bake the on-screen CSS2D category pill-labels into the file so the
        // export carries the reference's complete labelling method
        labels: captureLabelPositions(container, a.labelRefs),
        legend: RBC_LEGEND,
        theme, footnote: `Radial Bars Circular · ${dim === '3d' ? '3D' : '2D top-down'} view`,
      });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      /* TRUE-vector export, camera-aware. BUG FIX: this used to emit the
         reference's flat top-down "plan" twin UNCONDITIONALLY — selecting
         3D view and exporting SVG produced a 2D-looking file. Now the 2D
         view keeps that flat plan twin (correct — the reference's own 2D
         mode IS the top-down twin), while the 3D view projects the SAME
         extruded wedges, grid rings, markers and labels the live scene
         builds through the LIVE camera (whatever the user has orbited to),
         so a 3D export always looks three-dimensional. Pure paths — no
         <image>, no raster, in either mode. */
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container.clientWidth || 640, H = container.clientHeight || 460;
      const rows = (data || []).slice(0, 30);
      const n = Math.max(1, rows.length);
      const multiX = !!(series && series.length >= 2 && categories && categories.length >= 2);
      const cur = rows.map((d, i) => (multiX ? series![0].values[i] ?? d.value : d.value));
      const prior = rows.map((d, i) => (multiX && series!.length > 1
        ? series![1].values[i] ?? NaN
        : (d.prior != null && Number.isFinite(d.prior) ? d.prior : NaN)));
      const maxV = Math.max(1, ...cur, ...prior.filter(Number.isFinite));
      const avgV = cur.reduce((s2, v) => s2 + v, 0) / Math.max(1, cur.length);
      const headH = title ? 34 : 8;
      const legH = 26;
      const TH = headH + H + legH;
      const cx = W / 2, cy = H / 2;
      const plotR = Math.max(60, Math.min(W / 2 - 84, H / 2 - 34));
      // HTML proportions verbatim: INNER_RADIUS 3.5 / CHART_OUTER_RADIUS 11.5
      const rIn = (3.5 / 11.5) * plotR;
      const radOf = (v: number) => rIn + (Math.max(0, v) / maxV) * (plotR - rIn);
      const lane = (Math.PI * 2) / n;
      const pt = (rr: number, aa: number) => `${(cx + rr * Math.cos(aa)).toFixed(1)},${(cy + rr * Math.sin(aa)).toFixed(1)}`;
      const defs = `<linearGradient id="rbcBar" gradientUnits="userSpaceOnUse" x1="${cx}" y1="${(cy - plotR).toFixed(1)}" x2="${cx}" y2="${(cy + plotR).toFixed(1)}"><stop offset="0" stop-color="#3b82f6"/><stop offset="0.5" stop-color="#2563eb"/><stop offset="1" stop-color="#1e40af"/></linearGradient>`;

      const buildPlan2D = () => {
        let out = '';
        for (let g = 1; g <= 5; g++) {
          const gr = rIn + ((plotR - rIn) * g) / 5;
          out += `<circle cx="${cx}" cy="${cy.toFixed(1)}" r="${gr.toFixed(1)}" fill="none" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="3,3"/>`;
          out += `<text x="${cx + 4}" y="${(cy - gr + 3.5).toFixed(1)}" font-size="10" font-weight="700" fill="#64748b">${Math.round((maxV * g) / 5)}</text>`;
        }
        {
          const ar = radOf(avgV);
          out += `<circle cx="${cx}" cy="${cy.toFixed(1)}" r="${ar.toFixed(1)}" fill="none" stroke="#ef4444" stroke-width="1.4" stroke-dasharray="5,4"/>`;
          const aA = -Math.PI * 0.72;
          const tx2 = cx + Math.cos(aA) * ar, ty2 = cy + Math.sin(aA) * ar;
          out += `<rect x="${(tx2 - 27).toFixed(1)}" y="${(ty2 - 8).toFixed(1)}" width="54" height="15" rx="4" fill="rgba(255,255,255,0.92)" stroke="#fecaca"/>`;
          out += `<text x="${tx2.toFixed(1)}" y="${(ty2 + 4).toFixed(1)}" text-anchor="middle" font-size="9.5" font-weight="700" fill="#ef4444">Average</text>`;
        }
        rows.forEach((d, i) => {
          const aC = -Math.PI / 2 + i * lane;
          const aS = aC - lane * 0.31, aE = aC + lane * 0.31;
          const rO = radOf(cur[i]);
          out += `<path d="M${pt(rIn, aS)}L${pt(rO, aS)}A${rO.toFixed(1)} ${rO.toFixed(1)} 0 0 1 ${pt(rO, aE)}L${pt(rIn, aE)}A${rIn.toFixed(1)} ${rIn.toFixed(1)} 0 0 0 ${pt(rIn, aS)}Z" fill="url(#rbcBar)" stroke="#ffffff" stroke-width="0.8"/>`;
          if (Number.isFinite(prior[i])) {
            const rp = radOf(prior[i] as number);
            out += `<path d="M${pt(rp, aS)}A${rp.toFixed(1)} ${rp.toFixed(1)} 0 0 1 ${pt(rp, aE)}" fill="none" stroke="#ef4444" stroke-width="2.4" stroke-linecap="round"/>`;
            const up = cur[i] >= (prior[i] as number);
            const ar2 = plotR + 9;
            const ax = cx + Math.cos(aC) * ar2, ay = cy + Math.sin(aC) * ar2;
            const s = 4.4;
            out += up
              ? `<polygon points="${ax.toFixed(1)},${(ay - s).toFixed(1)} ${(ax + s * 0.86).toFixed(1)},${(ay + s * 0.6).toFixed(1)} ${(ax - s * 0.86).toFixed(1)},${(ay + s * 0.6).toFixed(1)}" fill="#2563eb"/>`
              : `<polygon points="${ax.toFixed(1)},${(ay + s).toFixed(1)} ${(ax + s * 0.86).toFixed(1)},${(ay - s * 0.6).toFixed(1)} ${(ax - s * 0.86).toFixed(1)},${(ay - s * 0.6).toFixed(1)}" fill="#ef4444"/>`;
          }
          const lr = plotR + 24;
          const lx = cx + Math.cos(aC) * lr, ly = cy + Math.sin(aC) * lr;
          out += `<text x="${lx.toFixed(1)}" y="${(ly + 3.5).toFixed(1)}" text-anchor="middle" font-size="10" font-weight="600" fill="#334155">${escXml(d.label)}</text>`;
        });
        out += `<circle cx="${cx}" cy="${cy.toFixed(1)}" r="${(plotR + 1.5).toFixed(1)}" fill="none" stroke="#e2e8f0" stroke-width="2"/>`;
        return out;
      };

      const buildOblique3D = () => {
        // Same world-space constants the live scene builds bars with.
        const INNER = 3.5, RPU = 0.8, MAXR = 10, BH = 0.5;
        const OUTER_RIM = INNER + MAXR * RPU;
        const toRating = (v: number) => (v / maxV) * MAXR;
        const cam = a.camera;
        cam.updateMatrixWorld(true);
        const proj = (x: number, y: number, z: number) => {
          const v = new THREE.Vector3(x, y, z).project(cam);
          return { x: (v.x * 0.5 + 0.5) * W, y: (-v.y * 0.5 + 0.5) * H, z: v.z };
        };
        const camPos = new THREE.Vector3().setFromMatrixPosition(cam.matrixWorld);
        const P = (p: { x: number; y: number }) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`;
        const faces: { z: number; svg: string }[] = [];
        const arcPts = (radius: number, a0: number, a1: number, y: number, steps = 10) =>
          Array.from({ length: steps + 1 }, (_, k) => { const a2 = a0 + ((a1 - a0) * k) / steps; return proj(Math.cos(a2) * radius, y, Math.sin(a2) * radius); });
        // SOLID-FILL + FILE-SIZE FIX: bars used to dump EVERY triangle of
        // the real ExtrudeGeometry (bevelled, 12-segment arc) — correctly
        // solid, but hundreds of tiny triangles per bar pushed the file
        // to ~750 KB for a full 20–30 row chart. A bar's true shape is
        // just 4 faces (top lid, outer curved wall, inner curved wall,
        // two flat end walls) — reconstructed here analytically from the
        // SAME world-space constants the live mesh is built from (no
        // mesh/geometry traversal needed), as a handful of QUADS per
        // curved wall (not one quad per vertex-density triangle) plus ONE
        // polygon for the top lid. Quads on the SAME curved wall always
        // meet edge-to-edge, so — unlike the old hand-derived version —
        // there is no seam mismatch to read as hollow. Lit by the SAME
        // ambient + two directional lights as the live scene, all four
        // face types by their true geometric normal.
        const barBaseByIndex = new Map<number, THREE.Color>();
        a.scene.traverse((obj) => {
          const m = obj as THREE.Mesh;
          const ud = m.userData as { i?: number; angleCenter?: number };
          if ((m as THREE.Mesh).isMesh && typeof ud.i === 'number' && ud.angleCenter !== undefined) {
            barBaseByIndex.set(ud.i, (m.material as THREE.MeshStandardMaterial).color);
          }
        });
        const AMB_COL = dark ? new THREE.Color(0xdde6f0) : new THREE.Color(0xffffff);
        const AMB_I = dark ? 0.72 : 0.95;
        const L1_DIR = new THREE.Vector3(15, 25, 15).normalize();
        const L1_I = dark ? 0.9 : 1.05;
        const L2_DIR = new THREE.Vector3(-15, 15, -15).normalize();
        const L2_COL = new THREE.Color(0x93c5fd);
        const L2_I = 0.5;
        const shadeFace = (base: THREE.Color, nrm: THREE.Vector3) => {
          const ndl1 = Math.max(0, nrm.dot(L1_DIR)), ndl2 = Math.max(0, nrm.dot(L2_DIR));
          const rC = base.r * AMB_COL.r * AMB_I + base.r * L1_I * ndl1 + base.r * L2_COL.r * L2_I * ndl2;
          const gC = base.g * AMB_COL.g * AMB_I + base.g * L1_I * ndl1 + base.g * L2_COL.g * L2_I * ndl2;
          const bC = base.b * AMB_COL.b * AMB_I + base.b * L1_I * ndl1 + base.b * L2_COL.b * L2_I * ndl2;
          return `rgb(${Math.min(255, Math.round(rC * 255))},${Math.min(255, Math.round(gC * 255))},${Math.min(255, Math.round(bC * 255))})`;
        };
        const world = (radius: number, ang: number, y: number) => new THREE.Vector3(Math.cos(ang) * radius, y, Math.sin(ang) * radius);
        function barFacesAnalytic(a0: number, a1: number, innerR: number, outerR: number, barH: number, base: THREE.Color): { z: number; svg: string }[] {
          const out: { z: number; svg: string }[] = [];
          const WALL_SEG = 5; // per curved wall — plenty smooth, keeps the file small
          const pushQuad = (p0: THREE.Vector3, p1: THREE.Vector3, p2: THREE.Vector3, p3: THREE.Vector3, nrm: THREE.Vector3) => {
            const proj0 = proj(p0.x, p0.y, p0.z), proj1 = proj(p1.x, p1.y, p1.z), proj2 = proj(p2.x, p2.y, p2.z), proj3 = proj(p3.x, p3.y, p3.z);
            const pts = [proj0, proj1, proj2, proj3];
            if (pts.every((pp) => pp.z < -1 || pp.z > 1)) return;
            const center = p0.clone().add(p1).add(p2).add(p3).multiplyScalar(0.25);
            if (nrm.dot(camPos.clone().sub(center)) <= 0) return; // back-facing
            const fill = shadeFace(base, nrm);
            const zAvg = pts.reduce((s, pp) => s + pp.z, 0) / 4;
            out.push({ z: zAvg, svg: `<polygon points="${pts.map(P).join(' ')}" fill="${fill}"/>` });
          };
          // top lid — one polygon spanning outer arc forward + inner arc back
          {
            const topPts: THREE.Vector3[] = [];
            for (let k = 0; k <= WALL_SEG; k++) topPts.push(world(outerR, a0 + ((a1 - a0) * k) / WALL_SEG, barH));
            for (let k = WALL_SEG; k >= 0; k--) topPts.push(world(innerR, a0 + ((a1 - a0) * k) / WALL_SEG, barH));
            const proj2 = topPts.map((p) => proj(p.x, p.y, p.z));
            if (!proj2.every((pp) => pp.z < -1 || pp.z > 1)) {
              const zAvg = proj2.reduce((s, pp) => s + pp.z, 0) / proj2.length;
              out.push({ z: zAvg, svg: `<polygon points="${proj2.map(P).join(' ')}" fill="${shadeFace(base, new THREE.Vector3(0, 1, 0))}"/>` });
            }
          }
          // outer + inner curved walls, as WALL_SEG quads each
          for (let k = 0; k < WALL_SEG; k++) {
            const ka = a0 + ((a1 - a0) * k) / WALL_SEG, kb = a0 + ((a1 - a0) * (k + 1)) / WALL_SEG, mid = (ka + kb) / 2;
            pushQuad(world(outerR, ka, 0), world(outerR, kb, 0), world(outerR, kb, barH), world(outerR, ka, barH), new THREE.Vector3(Math.cos(mid), 0, Math.sin(mid)));
            pushQuad(world(innerR, kb, 0), world(innerR, ka, 0), world(innerR, ka, barH), world(innerR, kb, barH), new THREE.Vector3(-Math.cos(mid), 0, -Math.sin(mid)));
          }
          // two flat end walls
          pushQuad(world(innerR, a0, 0), world(outerR, a0, 0), world(outerR, a0, barH), world(innerR, a0, barH), new THREE.Vector3(Math.sin(a0), 0, -Math.cos(a0)));
          pushQuad(world(outerR, a1, 0), world(innerR, a1, 0), world(innerR, a1, barH), world(outerR, a1, barH), new THREE.Vector3(-Math.sin(a1), 0, Math.cos(a1)));
          return out;
        }
        // dashed scale rings + numeric labels, projected around the ground plane
        [2, 4, 6, 8, 10].forEach((val) => {
          const radius = INNER + val * RPU;
          const ring = arcPts(radius, 0, Math.PI * 2, 0, 96);
          faces.push({ z: 0.999, svg: `<polyline points="${ring.map(P).join(' ')}" fill="none" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="3,3"/>` });
          const lp = proj(0, 0.1, -radius);
          faces.push({ z: lp.z, svg: `<text x="${lp.x.toFixed(1)}" y="${lp.y.toFixed(1)}" font-size="10" font-weight="700" fill="#64748b">${Math.round((maxV * val) / 10)}</text>` });
        });
        // average ring + tag, at the reference's exact world position
        {
          const avgR = toRating(avgV);
          const radius = INNER + avgR * RPU;
          const ring = arcPts(radius, 0, Math.PI * 2, 0.02, 128);
          faces.push({ z: 0.998, svg: `<polyline points="${ring.map(P).join(' ')}" fill="none" stroke="#ef4444" stroke-width="1.4" stroke-dasharray="5,4"/>` });
          const aEU = -Math.PI * 0.72;
          const tp = proj(Math.cos(aEU) * radius, 0.1, Math.sin(aEU) * radius);
          faces.push({ z: tp.z, svg: `<rect x="${(tp.x - 27).toFixed(1)}" y="${(tp.y - 8).toFixed(1)}" width="54" height="15" rx="4" fill="rgba(255,255,255,0.92)" stroke="#fecaca"/><text x="${tp.x.toFixed(1)}" y="${(tp.y + 4).toFixed(1)}" text-anchor="middle" font-size="9.5" font-weight="700" fill="#ef4444">Average</text>` });
        }
        // outer rim, on the ground plane
        faces.push({ z: 0.9999, svg: `<polyline points="${arcPts(OUTER_RIM + 0.1, 0, Math.PI * 2, 0, 96).map(P).join(' ')}" fill="none" stroke="#e2e8f0" stroke-width="2"/>` });
        // every bar: lit top face, outer curved wall, two flat end walls —
        // the SAME extruded wedge the live 3D scene renders, in world space.
        const angleStep = (Math.PI * 2) / n;
        rows.forEach((d, i) => {
          const angleCenter = i * angleStep - Math.PI / 2;
          const angleWidth = angleStep * 0.62;
          const a0 = angleCenter - angleWidth / 2, a1 = angleCenter + angleWidth / 2;
          const outerR = INNER + toRating(cur[i]) * RPU;
          const base = barBaseByIndex.get(i);
          if (base) barFacesAnalytic(a0, a1, INNER, outerR, BH, base).forEach((f) => faces.push(f));
          // prior-period marker arc, same world y-offset as the live scene
          if (Number.isFinite(prior[i])) {
            const priorR = INNER + toRating(prior[i] as number) * RPU;
            const marker = arcPts(priorR, a0, a1, BH + 0.06, 10);
            faces.push({ z: Math.min(...marker.map((p) => p.z)), svg: `<polyline points="${marker.map(P).join(' ')}" fill="none" stroke="#ef4444" stroke-width="2.4" stroke-linecap="round"/>` });
            const up = cur[i] >= (prior[i] as number);
            const tip = proj(Math.cos(angleCenter) * (OUTER_RIM + 1.1), BH + (up ? 0.55 : 0), Math.sin(angleCenter) * (OUTER_RIM + 1.1));
            const s = 4.4;
            faces.push({ z: tip.z - 0.001, svg: up
              ? `<polygon points="${tip.x.toFixed(1)},${(tip.y - s).toFixed(1)} ${(tip.x + s * 0.86).toFixed(1)},${(tip.y + s * 0.6).toFixed(1)} ${(tip.x - s * 0.86).toFixed(1)},${(tip.y + s * 0.6).toFixed(1)}" fill="#2563eb"/>`
              : `<polygon points="${tip.x.toFixed(1)},${(tip.y + s).toFixed(1)} ${(tip.x + s * 0.86).toFixed(1)},${(tip.y - s * 0.6).toFixed(1)} ${(tip.x - s * 0.86).toFixed(1)},${(tip.y - s * 0.6).toFixed(1)}" fill="#ef4444"/>` });
          }
          // category label, projected just past the bar's own outer edge
          const lp = proj(Math.cos(angleCenter) * (outerR + 0.9), BH + 0.2, Math.sin(angleCenter) * (outerR + 0.9));
          faces.push({ z: lp.z - 0.002, svg: `<text x="${lp.x.toFixed(1)}" y="${lp.y.toFixed(1)}" text-anchor="middle" font-size="10" font-weight="600" fill="#334155">${escXml(d.label)}</text>` });
        });
        faces.sort((p, q) => q.z - p.z);
        return faces.map((f) => f.svg).join('');
      };

      const body = dim === '3d' && a.camera ? buildOblique3D() : buildPlan2D();
      // semantic legend row (mirrors the HTML legend card)
      const scratch = document.createElement('canvas').getContext('2d')!;
      scratch.font = `600 10.5px ${theme.fontBody}`;
      let leg = ''; let lxx = 12; const lyy = TH - 9;
      RBC_LEGEND.forEach((it) => {
        leg += `<rect x="${lxx}" y="${lyy - 8}" width="9" height="9" rx="2" fill="${it.color}"/>`;
        leg += `<text x="${lxx + 13}" y="${lyy}" font-size="10.5" font-weight="600" fill="#39443d">${escXml(it.label)}</text>`;
        lxx += 13 + scratch.measureText(it.label).width + 18;
      });
      return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${TH}" viewBox="0 0 ${W} ${TH}">
<defs><style>text { font-family: ${escXml(theme.fontBody)}, -apple-system, sans-serif; }</style>${defs}</defs>
<rect width="${W}" height="${TH}" fill="#ffffff"/>
${title ? `<text x="12" y="22" font-family="${escXml(theme.fontDisplay)}" font-size="15" font-weight="700" fill="#1c2620">${escXml(title)}</text>` : ''}
<g id="rbc-scene" transform="translate(0 ${headH})">${body}</g>
<g id="rbc-legend">${leg}</g>
</svg>`;
    },
  }), [data, series, categories, palette, theme, dim, dark]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full">
      <div className="absolute right-2 top-2 z-10 flex gap-1.5">
        <button
          onClick={(e) => { e.stopPropagation(); (api.current as unknown as { reset?: () => void })?.reset?.(); }}
          className="rounded-full bg-black/45 px-2 py-1 font-body text-[10px] font-bold text-white/85 backdrop-blur-sm transition hover:bg-black/60"
          title="Reset view"
        >
          ⟲ Reset
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); const nx = !autoRot; setAutoRot(nx); (api.current as unknown as { setAuto?: (a: boolean) => void })?.setAuto?.(nx); }}
          className={`rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${autoRot ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
          title="Auto-rotate"
        >
          ⟳ Rotate
        </button>
      </div>
      {tip && tip.x >= 0 && (
        <div className="rbc-tip font-body"
          style={{ left: Math.min(Math.max(tip.x + 14, 8), (containerRef.current?.clientWidth || 300) - 220), top: Math.max(4, tip.y - 10) }}>
          <div className="tt-head"><span>{tip.title}</span><span className={`delta ${tip.up ? 'up' : 'down'}`}>{tip.delta}</span></div>
          <div className="tt-row"><span>{tip.curLbl}:</span><b className="cur">{tip.cur}</b></div>
          <div className="tt-row"><span>{tip.priorLbl}:</span><b className="prior">{tip.prior}</b></div>
          <div className="tt-row"><span>Trend:</span><b style={{ color: tip.up ? '#2563eb' : '#ef4444' }}>{tip.delta === '—' ? '—' : tip.up ? 'Increased' : 'Fell'}</b></div>
        </div>
      )}
    </div>
  );
});

export default RBC3D;
