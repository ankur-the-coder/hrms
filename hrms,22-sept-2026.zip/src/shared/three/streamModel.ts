/* Streamgraph dataset — EXACT port of 3DstreamGraph.html §1 (Winter
 * Olympic medal wins per nation, 1924–2022, incl. the WWII gap where the
 * 1940/1944 Games were cancelled). Editions, nations, per-edition medal
 * counts, colours and label placements are copied verbatim so the chart's
 * data, structure and colour identity match the supplied reference file
 * exactly — nothing here is invented or re-themed. */

export interface StreamEdition { yr: number; name: string }
export interface StreamCountry { id: string; name: string; color: string; vals: number[]; labelIdx?: number; zLane: number }
export interface StreamAnnotation { normX: number; yTop: number; title: string; text: string }

/** 24 editions actually held — 1940 and 1944 are deliberately absent
 * (cancelled for WWII), exactly like the reference's own `editions` array. */
export const STREAM_EDITIONS: StreamEdition[] = [
  { yr: 1924, name: 'Chamonix' }, { yr: 1928, name: 'St. Moritz' },
  { yr: 1932, name: 'Lake Placid' }, { yr: 1936, name: 'Garmisch' },
  { yr: 1948, name: 'St. Moritz' }, { yr: 1952, name: 'Oslo' },
  { yr: 1956, name: 'Cortina' }, { yr: 1960, name: 'Squaw Valley' },
  { yr: 1964, name: 'Innsbruck' }, { yr: 1968, name: 'Grenoble' },
  { yr: 1972, name: 'Sapporo' }, { yr: 1976, name: 'Innsbruck' },
  { yr: 1980, name: 'Lake Placid' }, { yr: 1984, name: 'Sarajevo' },
  { yr: 1988, name: 'Calgary' }, { yr: 1992, name: 'Albertville' },
  { yr: 1994, name: 'Lillehammer' }, { yr: 1998, name: 'Nagano' },
  { yr: 2002, name: 'Salt Lake City' }, { yr: 2006, name: 'Turin' },
  { yr: 2010, name: 'Vancouver' }, { yr: 2014, name: 'Sochi' },
  { yr: 2018, name: 'PyeongChang' }, { yr: 2022, name: 'Beijing' },
];

/** 20 nation layers, in the reference's own stack order (zLane 0 = topmost
 * lane). `vals` has one entry per STREAM_EDITIONS row. Colours verbatim. */
export const STREAM_COUNTRIES: StreamCountry[] = [
  { id: 'others_top', name: 'Other Nations (N)', color: '#92c5fe', vals: [1,1,1,1, 2,2,3,4,4,5,6,6,5,7,8,9,9,10,12,13,11,10,8,7], zLane: 0 },
  { id: 'sweden', name: 'Sweden', color: '#1d4ed8', vals: [2,3,2,3, 2,3,2,1,2,3,4,4,4,3,4,3,4,5,7,8,9,11,14,13], zLane: 1 },
  { id: 'norway', name: 'Norway', color: '#f9572b', vals: [10,8,6,7, 7,10,2,3,8,9,8,4,5,5,3,12,16,15,15,12,14,16,24,22], labelIdx: 22, zLane: 2 },
  { id: 'austria', name: 'Austria', color: '#10b981', vals: [0,0,0,0, 0,0,1,2,3,3,4,4,5,4,5,6,5,4,6,5,6,7,9,10], zLane: 3 },
  { id: 'netherlands', name: 'Netherlands', color: '#06d6a0', vals: [0,0,0,0, 0,1,0,1,1,5,5,3,2,0,4,2,2,6,5,6,5,15,12,10], labelIdx: 21, zLane: 4 },
  { id: 'us', name: 'U.S.', color: '#64748b', vals: [3,4,7,3, 6,7,4,6,4,4,5,6,7,5,4,7,8,8,22,16,24,18,15,16], labelIdx: 18, zLane: 5 },
  { id: 'canada', name: 'Canada', color: '#fba354', vals: [1,1,4,1, 2,1,2,3,2,2,1,2,1,3,3,4,8,9,11,15,17,16,19,17], labelIdx: 20, zLane: 6 },
  { id: 'germany', name: 'Germany', color: '#d946ef', vals: [0,1,1,3, 0,4,1,4,5,4,0,0,0,0,0,16,15,18,23,19,20,13,21,18], labelIdx: 17, zLane: 7 },
  { id: 'east_germany', name: 'East Germany', color: '#e879f9', vals: [0,0,0,0, 0,0,0,0,0,3,9,12,15,16,16,0,0,0,0,0,0,0,0,0], labelIdx: 12, zLane: 8 },
  { id: 'italy', name: 'Italy', color: '#ef4444', vals: [0,1,0,1, 1,1,2,1,3,3,4,3,1,1,3,9,13,6,8,7,3,5,6,11], labelIdx: 16, zLane: 9 },
  { id: 'finland', name: 'Finland', color: '#60a5fa', vals: [2,2,2,3, 3,2,3,4,3,4,5,4,5,4,6,5,4,5,6,5,7,8,6,7], zLane: 10 },
  { id: 'ussr', name: 'Soviet Union', color: '#059669', vals: [0,0,0,0, 0,0,11,14,17,13,11,18,15,17,20,0,0,0,0,0,0,0,0,0], labelIdx: 11, zLane: 11 },
  { id: 'russia', name: 'Russia', color: '#047857', vals: [0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,15,12,8,14,10,20,0,0], labelIdx: 21, zLane: 12 },
  { id: 'roc', name: 'ROC', color: '#065f46', vals: [0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,21], labelIdx: 23, zLane: 13 },
  { id: 'unified', name: 'Unified Team', color: '#10b981', vals: [0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,15,0,0,0,0,0,0,0,0], zLane: 14 },
  { id: 'china', name: 'China', color: '#a855f7', vals: [0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,2,2,5,5,7,7,6,6,10], labelIdx: 19, zLane: 15 },
  { id: 'others_bot1', name: 'Other Nations (S)', color: '#c084fc', vals: [1,1,1,1, 2,2,3,2,3,2,2,2,3,4,4,5,6,7,9,11,12,13,10,9], zLane: 16 },
  { id: 'others_bot2', name: 'Switzerland', color: '#2563eb', vals: [1,1,1,1, 2,2,2,3,3,4,3,3,4,5,5,6,7,8,7,6,8,7,6,5], zLane: 17 },
  { id: 'others_bot3', name: 'France', color: '#f97316', vals: [1,1,1,2, 1,2,2,1,1,1,1,2,2,2,3,3,4,5,4,5,6,7,6,6], zLane: 18 },
  { id: 'others_bot4', name: 'Others', color: '#38bdf8', vals: [0,0,1,1, 1,1,1,2,2,2,2,2,2,3,3,4,3,3,4,4,3,4,5,6], zLane: 19 },
];

/** The reference's 3 floating 3D pole annotations, verbatim (normX is a
 * fraction of the 0..23 edition index range, matching `add3DAnnotation`'s
 * own call sites: 3.5/23, 14.5/23, 22/23). */
export const STREAM_ANNOTATIONS: StreamAnnotation[] = [
  { normX: 3.5 / 23, yTop: 10, title: '1940 & 1944', text: 'Cancelled during World War II' },
  { normX: 14.5 / 23, yTop: 18, title: '1990–1991', text: 'Soviet Union fell, Germany united' },
  { normX: 22 / 23, yTop: 26, title: '2017', text: 'Russia banned from the Olympic Games' },
];

/** Pre/post-WWII spline blocks — a real temporal gap sits between them
 * (indices 3 → 4), exactly like the reference's own `blocks` array. */
export const STREAM_BLOCKS = [
  { start: 0, end: 3, segs: 30 },
  { start: 4, end: 23, segs: 140 },
] as const;

export const STREAM_TOTAL_WIDTH = 84;
export const STREAM_HEIGHT_SCALE = 0.32;
export const STREAM_Z_TOTAL_SPAN = 16;
