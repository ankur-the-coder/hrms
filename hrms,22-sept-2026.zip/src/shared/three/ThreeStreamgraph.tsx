import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import type { ThreeChartHandle } from './ThreeSankey3D';
import type { ExportTheme } from './exportUtils';
import { buildThreePNG, captureLabelPositions, legendRows, withExportResolution } from './exportUtils';
import {
  STREAM_EDITIONS, STREAM_COUNTRIES, STREAM_ANNOTATIONS, STREAM_BLOCKS,
  STREAM_TOTAL_WIDTH, STREAM_HEIGHT_SCALE, STREAM_Z_TOTAL_SPAN,
} from './streamModel';
import type { StackedSeries } from '../Charts';

/* ============================================================
   Three.js Streamgraph — faithful port of the supplied 3DstreamGraph.html
   ("3D Winter Olympics Streamgraph"): the exact dataset (24 editions,
   1924–2022, WWII gap; 20 nation ribbon layers with the reference's own
   colours), the exact volumetric-ribbon construction (per-block spline
   sampling → centred stacking with drift → addQuad front/back/top/bottom
   + end-cap solid geometry), the exact studio lighting rig (ambient 1.1,
   key/fill/rim directional lights, shadow-catching ground + grid floor),
   the exact floating 3D pole annotations (metal cylinder + glass callout
   card) and the exact hover language (raycast → additive emissive darken
   + tooltip).

   Deliberate adaptations, per product request:
   - Camera: the reference's 3 presets (Perspective / Side / Top) are
     replaced by exactly TWO — "Side Elevation" as the ONLY 3D view (the
     reference's own `side` preset direction), and a self-authored
     top-down 2D view — driven by this app's own system 2D/3D toggle
     instead of in-scene preset buttons. Camera DISTANCE is fitted to the
     live container's bounding box (not hardcoded), so the full graph
     always fills the tile without clipping, at any panel size.
   - Chrome: no in-scene title/legend/view-buttons (the card supplies its
     own heading and the single outside legend row) — only the same
     zoom-lock button convention every other Three.js chart in this app
     uses. The hover tooltip keeps the reference's copy but is styled with
     this app's glass tooltip surface.
   - Colours, ribbon geometry and lighting values are otherwise UNCHANGED
     from the reference.
   ============================================================ */

interface Props {
  categories?: string[];
  series?: StackedSeries[];
  palette: string[];
  dim: '2d' | '3d';
  hoverIndex?: number | null;
  onHover?: (idx: number | null, text: string | null) => void;
  theme: ExportTheme;
  dark?: boolean;
}

interface RibbonRecord {
  name: string; color: string; z: number;
  top: { x: number; y: number }[]; bottom: { x: number; y: number }[];
}

function escXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

const NUM_SERIES = STREAM_COUNTRIES.length;
const Z_STEP = STREAM_Z_TOTAL_SPAN / NUM_SERIES;
const FLOOR_Y = -20;

const ThreeStreamgraph = forwardRef<ThreeChartHandle, Props>(function ThreeStreamgraph(
  { categories, series, palette, dim, hoverIndex, onHover, theme, dark }, ref,
) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState<{ x: number; y: number; name: string; color: string; sub: string } | null>(null);
  const [zoomOn, setZoomOn] = useState(false);
  const [ready, setReady] = useState(false);

  const api = useRef<{
    renderer: THREE.WebGLRenderer;
    labelRenderer: CSS2DRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    labelRefs: { el: HTMLElement; text: string; color?: string }[];
    setMode: (m: '2D' | '3D') => void;
    setZoom: (on: boolean) => void;
    hoverSeries: (i: number | null) => void;
    ribbons: RibbonRecord[];
    dispose: () => void;
  } | null>(null);

  useEffect(() => {
    void categories; void series; void palette; // dataset is always the reference's own
    const container: HTMLDivElement = containerRef.current!;
    if (!container) return;
    setReady(false);

    const scene = new THREE.Scene();
    const W0 = container.clientWidth || 700, H0 = container.clientHeight || 420;
    const camera = new THREE.PerspectiveCamera(38, W0 / H0, 1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setClearColor(0x000000, 0);
    renderer.setSize(W0, H0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = false;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    container.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.setSize(W0, H0);
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.inset = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    labelRenderer.domElement.style.overflow = 'hidden';
    container.appendChild(labelRenderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.target.set(2, -1, 0);
    controls.maxPolarAngle = Math.PI / 2 + 0.1;
    controls.enableZoom = false; // zoom lock, same convention as every other Three.js chart

    /* --- studio lighting rig (reference verbatim) --- */
    scene.add(new THREE.AmbientLight(0xffffff, 1.1));
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.4);
    keyLight.position.set(-30, 60, 45);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 10;
    keyLight.shadow.camera.far = 180;
    const shD = 50;
    keyLight.shadow.camera.left = -shD;
    keyLight.shadow.camera.right = shD;
    keyLight.shadow.camera.top = shD;
    keyLight.shadow.camera.bottom = -shD;
    keyLight.shadow.bias = -0.0004;
    scene.add(keyLight);
    const fillLight = new THREE.DirectionalLight(0xbdd7ff, 1.2);
    fillLight.position.set(40, -10, -40);
    scene.add(fillLight);
    const rimLight = new THREE.DirectionalLight(0xffffff, 0.9);
    rimLight.position.set(0, 30, -50);
    scene.add(rimLight);

    /* --- shadow-catching ground + grid floor (reference verbatim, grid tint theme-aware) --- */
    const shadowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(240, 240),
      new THREE.ShadowMaterial({ opacity: 0.12 }),
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = FLOOR_Y;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);
    const gridHelper = new THREE.GridHelper(160, 40, dark ? 0x3a4a5a : 0xdbeafe, dark ? 0x28323d : 0xedf2f7);
    gridHelper.position.y = FLOOR_Y - 0.05;
    scene.add(gridHelper);

    /* --- volumetric ribbons: per-block spline stacking, verbatim topology --- */
    const ribbonGroup = new THREE.Group();
    scene.add(ribbonGroup);
    /* 2D-VIEW ADAPTATION: flatten ribbon Z-spread toward 0 so the side
       elevation reads as a true 2D stream (no lane parallax) while the
       3D view keeps the original volumetric depth. Tweened with the
       camera so 2D⇄3D never jumps. */
    let flattenAmt = dim === '3d' ? 0 : 1;
    let fromFlatten = flattenAmt;
    const applyFlatten = (t: number) => { ribbonGroup.scale.z = 1 - 0.97 * t; };
    const ribbonMeshes: THREE.Mesh<THREE.BufferGeometry, THREE.MeshPhysicalMaterial>[] = [];
    const ribbonRecords: RibbonRecord[] = [];
    const labelObjs: CSS2DObject[] = [];
    const editionCount = STREAM_EDITIONS.length;

    STREAM_BLOCKS.forEach((blk) => {
      const numSteps = blk.segs;
      const xs: number[] = [];
      for (let i = blk.start; i <= blk.end; i++) xs.push(i / (editionCount - 1));
      const sampled = STREAM_COUNTRIES.map((c) => {
        const pts: THREE.Vector2[] = [];
        for (let i = blk.start; i <= blk.end; i++) pts.push(new THREE.Vector2(xs[i - blk.start], c.vals[i]));
        const curve = new THREE.SplineCurve(pts);
        return curve.getPoints(numSteps);
      });
      const stackBottom: THREE.Vector2[][] = Array.from({ length: NUM_SERIES }, () => []);
      const stackTop: THREE.Vector2[][] = Array.from({ length: NUM_SERIES }, () => []);
      for (let step = 0; step <= numSteps; step++) {
        let totalH = 0;
        for (let s = 0; s < NUM_SERIES; s++) totalH += Math.max(0, sampled[s][step].y);
        const normX = sampled[0][step].x;
        const drift = -normX * 6.0;
        let currentY = -totalH / 2 + drift;
        for (let s = 0; s < NUM_SERIES; s++) {
          const h = Math.max(0, sampled[s][step].y);
          const x = (normX - 0.5) * STREAM_TOTAL_WIDTH;
          stackBottom[s].push(new THREE.Vector2(x, currentY * STREAM_HEIGHT_SCALE));
          currentY += h;
          stackTop[s].push(new THREE.Vector2(x, currentY * STREAM_HEIGHT_SCALE));
        }
      }

      STREAM_COUNTRIES.forEach((country, s) => {
        let maxV = 0;
        for (const p of sampled[s]) if (p.y > maxV) maxV = p.y;
        if (maxV < 0.05) return;

        const zCenter = (s - NUM_SERIES / 2) * Z_STEP;
        const ribbonDepth = 1.6;
        const zFront = zCenter + ribbonDepth / 2, zBack = zCenter - ribbonDepth / 2;

        const positions: number[] = [], normals: number[] = [], uvs: number[] = [], indices: number[] = [];
        let vertCount = 0;
        const V3 = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
        function addQuad(p1: THREE.Vector3, p2: THREE.Vector3, p3: THREE.Vector3, p4: THREE.Vector3, n: THREE.Vector3) {
          positions.push(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, p3.x, p3.y, p3.z, p4.x, p4.y, p4.z);
          for (let k = 0; k < 4; k++) normals.push(n.x, n.y, n.z);
          uvs.push(0, 0, 1, 0, 1, 1, 0, 1);
          indices.push(vertCount, vertCount + 1, vertCount + 2, vertCount, vertCount + 2, vertCount + 3);
          vertCount += 4;
        }
        for (let i = 0; i < numSteps; i++) {
          const b0 = stackBottom[s][i], b1 = stackBottom[s][i + 1];
          const t0 = stackTop[s][i], t1 = stackTop[s][i + 1];
          addQuad(V3(b0.x, b0.y, zFront), V3(b1.x, b1.y, zFront), V3(t1.x, t1.y, zFront), V3(t0.x, t0.y, zFront), V3(0, 0, 1));
          addQuad(V3(b1.x, b1.y, zBack), V3(b0.x, b0.y, zBack), V3(t0.x, t0.y, zBack), V3(t1.x, t1.y, zBack), V3(0, 0, -1));
          const topNorm = V3(-(t1.y - t0.y), t1.x - t0.x, 0).normalize();
          addQuad(V3(t0.x, t0.y, zFront), V3(t1.x, t1.y, zFront), V3(t1.x, t1.y, zBack), V3(t0.x, t0.y, zBack), topNorm);
          const botNorm = V3(b1.y - b0.y, -(b1.x - b0.x), 0).normalize();
          addQuad(V3(b1.x, b1.y, zFront), V3(b0.x, b0.y, zFront), V3(b0.x, b0.y, zBack), V3(b1.x, b1.y, zBack), botNorm);
        }
        const startB = stackBottom[s][0], startT = stackTop[s][0];
        addQuad(V3(startB.x, startB.y, zBack), V3(startB.x, startB.y, zFront), V3(startT.x, startT.y, zFront), V3(startT.x, startT.y, zBack), V3(-1, 0, 0));
        const endB = stackBottom[s][numSteps], endT = stackTop[s][numSteps];
        addQuad(V3(endB.x, endB.y, zFront), V3(endB.x, endB.y, zBack), V3(endT.x, endT.y, zBack), V3(endT.x, endT.y, zFront), V3(1, 0, 0));

        const geom = new THREE.BufferGeometry();
        geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geom.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
        geom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
        geom.setIndex(indices);
        geom.computeVertexNormals();

        const material = new THREE.MeshPhysicalMaterial({
          color: new THREE.Color(country.color),
          roughness: 0.28, metalness: 0.08,
          clearcoat: 0.75, clearcoatRoughness: 0.2,
          side: THREE.DoubleSide,
        });
        const mesh = new THREE.Mesh(geom, material);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.userData = { country: country.name, color: country.color, s };
        ribbonGroup.add(mesh);
        ribbonMeshes.push(mesh);
        ribbonRecords.push({
          name: country.name, color: country.color, z: zFront,
          top: stackTop[s].map((p) => ({ x: p.x, y: p.y })),
          bottom: stackBottom[s].map((p) => ({ x: p.x, y: p.y })),
        });

        if (country.labelIdx !== undefined && country.labelIdx >= blk.start && country.labelIdx <= blk.end) {
          const progress = (country.labelIdx - blk.start) / (blk.end - blk.start);
          const stepIdx = Math.min(numSteps, Math.floor(progress * numSteps));
          const posX = stackBottom[s][stepIdx].x;
          const posY = (stackBottom[s][stepIdx].y + stackTop[s][stepIdx].y) / 2;
          const div = document.createElement('div');
          div.className = 'sg-employee-tag';
          div.textContent = country.name;
          div.style.fontFamily = theme.fontBody;
          const labelObj = new CSS2DObject(div);
          labelObj.position.set(posX, posY, zFront + 0.2);
          scene.add(labelObj);
          labelObjs.push(labelObj);
        }
      });
    });

    /* --- timeline axis (reference verbatim) ---
       OVERLAP FIX: with 24 editions spread across STREAM_TOTAL_WIDTH,
       adjacent labels sit only a few world-units apart — as plain
       horizontal text their bounding boxes overlapped and crammed into
       each other (worse still after the 2D-view zoom-in above). Angling
       each label so it reads diagonally, fanned out away from its own
       tick mark, is the same technique dense axis labels use in any 2D
       chart, and needs no more world-space room than a horizontal label
       already had — it only needs a CSS rotation.
       CSS2DObject overwrites `element.style.transform` every frame (that
       IS how it positions labels in screen space), so a rotation can't be
       applied to the element CSS2DObject is given directly — the actual
       rotated text lives on a NESTED inner span instead, which
       CSS2DRenderer never touches, so the renderer's positioning and this
       rotation compose instead of one overwriting the other. */
    const axisMat = new THREE.LineBasicMaterial({ color: dark ? 0x5a6a7a : 0xcfd8dc });
    const axisLabelInners: HTMLElement[] = [];
    STREAM_EDITIONS.forEach((ed, i) => {
      const x = (i / (editionCount - 1) - 0.5) * STREAM_TOTAL_WIDTH;
      const lineGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(x, FLOOR_Y, -STREAM_Z_TOTAL_SPAN / 2 - 2),
        new THREE.Vector3(x, FLOOR_Y, STREAM_Z_TOTAL_SPAN / 2 + 6),
      ]);
      scene.add(new THREE.Line(lineGeo, axisMat));
      const wrap = document.createElement('div');
      wrap.className = 'sg-axis-label-wrap';
      const div = document.createElement('div');
      div.className = 'sg-axis-label';
      div.textContent = `${ed.yr} ${ed.name}`;
      div.style.fontFamily = theme.fontBody;
      if (dark) div.style.color = '#9fb2c5';
      wrap.appendChild(div);
      const labelObj = new CSS2DObject(wrap);
      labelObj.position.set(x, FLOOR_Y - 0.2, STREAM_Z_TOTAL_SPAN / 2 + 7.5);
      scene.add(labelObj);
      labelObjs.push(labelObj);
      axisLabelInners.push(div);
    });
    /* BASE-LABEL ORIENTATION: CSS2DRenderer billboards every label to
       face the camera (so they would otherwise stay horizontal and pile
       up as the graph is orbited). Re-project the graph's own +X time
       axis each frame and rotate the nested inner span to match — labels
       stay parallel to the floor/time axis, fanned at a resting −38°
       when looking straight on, and never clutter when the view yaws.
       The same treatment is applied to pole-base captions (they sit on
       the same floor line). */
    const _p0 = new THREE.Vector3();
    const _p1 = new THREE.Vector3();
    function updateBaseLabelSpin() {
      camera.updateMatrixWorld(true);
      _p0.set(0, FLOOR_Y, STREAM_Z_TOTAL_SPAN / 2 + 7.5).project(camera);
      _p1.set(1, FLOOR_Y, STREAM_Z_TOTAL_SPAN / 2 + 7.5).project(camera);
      let deg = Math.atan2(-(_p1.y - _p0.y), _p1.x - _p0.x) * (180 / Math.PI);
      if (deg > 90) deg -= 180;
      if (deg < -90) deg += 180;
      const applied = deg - 38;
      const tx = `translate(-100%, 0) rotate(${applied.toFixed(2)}deg)`;
      for (const el of axisLabelInners) el.style.transform = tx;
    }

    /* --- floating 3D pole annotations (reference verbatim: metal pole + glass callout) --- */
    const poleMeshes: THREE.Mesh[] = [];
    STREAM_ANNOTATIONS.forEach((a) => {
      const x = (a.normX - 0.5) * STREAM_TOTAL_WIDTH;
      const z = STREAM_Z_TOTAL_SPAN / 2 + 3;
      const poleH = a.yTop - FLOOR_Y;
      const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.1, 0.1, poleH, 16),
        new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.3 }),
      );
      pole.position.set(x, a.yTop - poleH / 2, z);
      pole.castShadow = true;
      scene.add(pole);
      poleMeshes.push(pole);
      const div = document.createElement('div');
      div.className = 'sg-callout visible';
      div.style.fontFamily = theme.fontBody;
      div.innerHTML = `<strong>${escXml(a.title)}</strong><span>${escXml(a.text)}</span>`;
      const labelObj = new CSS2DObject(div);
      labelObj.position.set(x, a.yTop, z);
      scene.add(labelObj);
      labelObjs.push(labelObj);
    });

    /* --- camera: fitted Side-Elevation (3D) / adapted FRONT flat (2D) ---
       2D is the 3D side elevation adapted to a true 2D stream: same look
       direction (along +Z, up = +Y) so time reads left-to-right and
       values read vertically, PLUS ribbon Z-scale flattened toward 0 and
       a long-lens FOV so lane parallax disappears. ZOOM: fitted ~12%
       closer than a full bounding-box fit so the default view is slightly
       zoomed in; horizontal + ribbon-vertical extents stay inside the
       frame, while the floor grid ("bottom net") is allowed to clip. */
    const box = new THREE.Box3().setFromObject(ribbonGroup);
    const center = box.isEmpty() ? new THREE.Vector3() : box.getCenter(new THREE.Vector3());
    const size = box.isEmpty() ? new THREE.Vector3(STREAM_TOTAL_WIDTH, 20, STREAM_Z_TOTAL_SPAN) : box.getSize(new THREE.Vector3());
    function fitDistance(fovDeg: number, aspect: number, dims: [number, number]) {
      const fov = THREE.MathUtils.degToRad(fovDeg);
      const fitH = (dims[1] / 2) / Math.tan(fov / 2);
      const fitW = (dims[0] / 2) / (Math.tan(fov / 2) * aspect);
      return Math.max(fitH, fitW) * 1.18;
    }
    const FOV_3D = 38, FOV_2D = 14;
    let sideDist = 85, frontDist2D = 340;
    function refit() {
      const aspect = camera.aspect;
      // Fill more of the tile: pull both cameras in. Ribbons stay inside
      // the frustum; the floor grid ("bottom net") is allowed to clip.
      sideDist = fitDistance(FOV_3D, aspect, [size.x, size.y + 6]) * 0.78;
      const fitY2d = Math.max(size.y + 4, (center.y - FLOOR_Y) * 0.45 + size.y * 0.5);
      frontDist2D = fitDistance(FOV_2D, aspect, [size.x * 0.90, fitY2d]) * 0.74;
    }
    refit();
    const view3D = () => ({ pos: new THREE.Vector3(center.x, center.y + 1.2, center.z + sideDist), target: center.clone(), up: new THREE.Vector3(0, 1, 0), fov: FOV_3D });
    const view2D = () => ({ pos: new THREE.Vector3(center.x, center.y + 0.6, center.z + frontDist2D), target: new THREE.Vector3(center.x, center.y + 0.6, center.z), up: new THREE.Vector3(0, 1, 0), fov: FOV_2D });

    let mode: '2D' | '3D' = dim === '3d' ? '3D' : '2D';
    let transitioning = false, tStart = 0;
    const TWEEN_MS = 900;
    const fromPos = new THREE.Vector3(), fromTg = new THREE.Vector3(), fromUp = new THREE.Vector3();
    let fromFov = FOV_3D;
    const tmpTg = new THREE.Vector3(), tmpUp = new THREE.Vector3();
    const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
    function applyInstant(m: '2D' | '3D') {
      const v = m === '3D' ? view3D() : view2D();
      camera.position.copy(v.pos);
      controls.target.copy(v.target);
      camera.up.copy(v.up || new THREE.Vector3(0, 1, 0));
      camera.fov = v.fov;
      camera.updateProjectionMatrix();
      flattenAmt = m === '2D' ? 1 : 0;
      applyFlatten(flattenAmt);
      updateBaseLabelSpin();
    }
    function seatCamera(m: '2D' | '3D') {
      const v = m === '3D' ? view3D() : view2D();
      camera.position.copy(v.pos);
      controls.target.copy(v.target);
      camera.up.copy(v.up || new THREE.Vector3(0, 1, 0));
      camera.fov = v.fov;
      camera.updateProjectionMatrix();
      flattenAmt = m === '2D' ? 1 : 0;
      applyFlatten(flattenAmt);
      // Sync OrbitControls' internal spherical from the seated pose —
      // otherwise the next controls.update() reapplies the PRE-tween
      // orbit and the graph flies out of frame.
      controls.update();
      updateBaseLabelSpin();
    }
    function setMode(m: '2D' | '3D') {
      if (mode === m) return;
      // Always morph between the two FITTED presets (not the orbited
      // pose). A user drag + dim change used to lerp from a side/top
      // orbit into the long-lens 2D camera while Z-flattening, which
      // sent the river out of view. Starting from the framed current
      // preset keeps every in-between frame inside the tile.
      const from = mode === '3D' ? view3D() : view2D();
      mode = m;
      controls.enableDamping = false;
      fromPos.copy(from.pos); fromTg.copy(from.target); fromUp.copy(from.up);
      fromFov = from.fov;
      fromFlatten = flattenAmt;
      transitioning = true; tStart = performance.now();
      renderer.shadowMap.needsUpdate = true;
      wake(2);
    }
    applyInstant(mode);

    /* --- hover: raycast + additive emissive darken (reference verbatim) --- */
    const raycaster = new THREE.Raycaster();
    const mouseV = new THREE.Vector2();
    let hoveredMesh: THREE.Mesh<THREE.BufferGeometry, THREE.MeshPhysicalMaterial> | null = null;
    function highlight(mesh: typeof hoveredMesh, clientX?: number, clientY?: number, hitX?: number) {
      if (!mesh) return;
      if (hoveredMesh && hoveredMesh !== mesh) hoveredMesh.material.emissive.setHex(0x000000);
      hoveredMesh = mesh;
      mesh.material.emissive.setHex(0x333333);
      const rect = container.getBoundingClientRect();
      const px = clientX !== undefined ? clientX - rect.left : rect.width / 2;
      const py = clientY !== undefined ? clientY - rect.top : rect.height / 2;
      const ud = mesh.userData as { country: string; color: string; s: number };
      // Reference tooltip copy: "Era: ~<year> · 3D Ribbon Layer".
      const firstYr = STREAM_EDITIONS[0].yr, lastYr = STREAM_EDITIONS[STREAM_EDITIONS.length - 1].yr;
      const yrProgress = Math.max(0, Math.min(1, (hitX ?? 0) / STREAM_TOTAL_WIDTH + 0.5));
      const approxYr = Math.round(firstYr + yrProgress * (lastYr - firstYr));
      setTip({ x: px, y: py, name: ud.country, color: ud.color, sub: `Era: ~${approxYr} · 3D Ribbon Layer` });
      onHover?.(ud.s, ud.country);
      container.style.cursor = 'pointer';
      wake();
    }
    function unhighlight() {
      if (hoveredMesh) { hoveredMesh.material.emissive.setHex(0x000000); hoveredMesh = null; }
      setTip(null);
      onHover?.(null, null);
      container.style.cursor = 'default';
      wake();
    }
    function onPointerMove(e: PointerEvent) {
      const rect = container.getBoundingClientRect();
      mouseV.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseV.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseV, camera);
      const hits = raycaster.intersectObjects(ribbonMeshes, false);
      if (hits.length) highlight(hits[0].object as typeof hoveredMesh, e.clientX, e.clientY, hits[0].point.x);
      else if (hoveredMesh) unhighlight();
    }
    function onPointerLeave() { if (hoveredMesh) unhighlight(); }
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerleave', onPointerLeave);

    /* --- render-on-demand loop --- */
    let raf = 0, onScreen = true, needsFrame = true, dampingTail = 0;
    function wake(tail = 0) { needsFrame = true; if (tail > dampingTail) dampingTail = tail; }
    function resize() {
      const W = container.clientWidth || 700, H = container.clientHeight || 420;
      camera.aspect = W / H;
      refit();
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
      if (!transitioning) applyInstant(mode);
      renderer.shadowMap.needsUpdate = true;
      wake(2);
    }
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();
    const io = new IntersectionObserver((es) => { onScreen = es.some((e) => e.isIntersecting); if (onScreen) { resize(); } }, { threshold: 0 });
    io.observe(container);
    const onVisChange = () => { if (!document.hidden) resize(); };
    document.addEventListener('visibilitychange', onVisChange);
    const onFsChange = () => { resize(); requestAnimationFrame(resize); };
    document.addEventListener('fullscreenchange', onFsChange);
    const onCtxLost = (e: Event) => e.preventDefault();
    const onCtxRestored = () => resize();
    renderer.domElement.addEventListener('webglcontextlost', onCtxLost, false);
    renderer.domElement.addEventListener('webglcontextrestored', onCtxRestored, false);
    controls.addEventListener('change', () => { wake(2); renderer.shadowMap.needsUpdate = true; });
    controls.addEventListener('end', () => wake(28));

    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (!onScreen || document.hidden) return;
      if (!needsFrame && !transitioning && dampingTail <= 0) return;
      if (transitioning) {
        const t = Math.min(1, (performance.now() - tStart) / TWEEN_MS);
        const e = easeOutCubic(t);
        const target = mode === '3D' ? view3D() : view2D();
        camera.position.lerpVectors(fromPos, target.pos, e);
        tmpTg.lerpVectors(fromTg, target.target, e);
        controls.target.copy(tmpTg);
        tmpUp.lerpVectors(fromUp, target.up || new THREE.Vector3(0, 1, 0), e).normalize();
        camera.up.copy(tmpUp);
        camera.fov = THREE.MathUtils.lerp(fromFov, target.fov, e);
        camera.updateProjectionMatrix();
        flattenAmt = THREE.MathUtils.lerp(fromFlatten, mode === '2D' ? 1 : 0, e);
        applyFlatten(flattenAmt);
        renderer.shadowMap.needsUpdate = true;
        if (t >= 1) {
          transitioning = false;
          seatCamera(mode);
          controls.enableDamping = true;
        }
      } else {
        controls.update();
      }
      updateBaseLabelSpin();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
      needsFrame = transitioning || dampingTail > 0;
      if (dampingTail > 0) dampingTail -= 1;
    };
    animate();
    requestAnimationFrame(() => requestAnimationFrame(() => setReady(true)));

    const dispose = () => {
      cancelAnimationFrame(raf);
      ro.disconnect(); io.disconnect();
      document.removeEventListener('visibilitychange', onVisChange);
      document.removeEventListener('fullscreenchange', onFsChange);
      renderer.domElement.removeEventListener('webglcontextlost', onCtxLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onCtxRestored);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      ribbonMeshes.forEach((mm) => { mm.geometry.dispose(); mm.material.dispose(); });
      poleMeshes.forEach((pm) => { pm.geometry.dispose(); (pm.material as THREE.Material).dispose(); });
      controls.dispose();
      renderer.dispose();
      // GPU FIX: explicitly force the WebGL context lost (rather than
      // waiting for browser GC) so its VRAM is reclaimed immediately —
      // this is what prevented other canvases/contexts on the page (the
      // Radial Bar tile in particular) from occasionally going blank
      // after a heavy WebGL-hosted chart had been mounted and torn down.
      try { renderer.getContext().getExtension('WEBGL_lose_context')?.loseContext(); } catch { /* noop */ }
      if (renderer.domElement.parentElement === container) container.removeChild(renderer.domElement);
      if (labelRenderer.domElement.parentElement === container) container.removeChild(labelRenderer.domElement);
    };

    api.current = {
      renderer, labelRenderer, scene, camera, controls,
      labelRefs: labelObjs.map((o) => ({ el: o.element as HTMLElement, text: (o.element as HTMLElement).textContent || '' })),
      setMode,
      setZoom: (on: boolean) => { controls.enableZoom = on; },
      hoverSeries: (i: number | null) => {
        if (i === null) { unhighlight(); return; }
        const mesh = ribbonMeshes.find((mm) => (mm.userData as { s: number }).s === i);
        if (mesh) highlight(mesh); else unhighlight();
      },
      ribbons: ribbonRecords,
      dispose,
    };
    return () => { api.current?.dispose(); api.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dark, theme.fontBody]);

  useEffect(() => { api.current?.setMode(dim === '3d' ? '3D' : '2D'); }, [dim]);
  useEffect(() => { api.current?.hoverSeries(hoverIndex ?? null); }, [hoverIndex]);

  useImperativeHandle(ref, () => ({
    exportPNG: async (title: string) => {
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container.clientWidth, H = container.clientHeight;
      let dataUrl = '';
      withExportResolution(a.renderer, () => { a.renderer.render(a.scene, a.camera); dataUrl = a.renderer.domElement.toDataURL('image/png'); });
      a.renderer.setSize(W, H, false);
      a.renderer.render(a.scene, a.camera);
      a.labelRenderer.render(a.scene, a.camera);
      const legend = STREAM_COUNTRIES.map((c) => ({ label: c.name, color: c.color }));
      const cv = await buildThreePNG({
        title, imageDataUrl: dataUrl, chartW: W, chartH: H,
        labels: captureLabelPositions(container, a.labelRefs),
        legend, theme, footnote: `Streamgraph · ${dim === '3d' ? 'Side elevation' : 'Top-down'} view · 1924–2022`,
      });
      return await new Promise<Blob>((resolve) => cv.toBlob((b) => resolve(b as Blob), 'image/png'));
    },
    exportSVG: async (title: string) => {
      /* TRUE-vector export of the LIVE scene: every ribbon's front + lit
         top face are re-projected through the CURRENT camera (side
         elevation or top-down, whichever is on screen) into flat-shaded
         SVG polygons, back-to-front — matching the on-screen colour,
         shape and camera angle exactly. No raster, no <image>. */
      const a = api.current; const container = containerRef.current;
      if (!a || !container) throw new Error('chart not ready');
      const W = container.clientWidth || 700, H = container.clientHeight || 420;
      a.camera.updateMatrixWorld(true);
      const proj = (x: number, y: number, z: number): { x: number; y: number; z: number } => {
        const v = new THREE.Vector3(x, y, z).project(a.camera);
        return { x: (v.x * 0.5 + 0.5) * W, y: (-v.y * 0.5 + 0.5) * H, z: v.z };
      };
      const shadeCss = (hex: string, k: number): string => {
        const c = hex.replace('#', '');
        const n = parseInt(c.length === 3 ? c.split('').map((ch) => ch + ch).join('') : c, 16);
        const r = Math.min(255, Math.round(((n >> 16) & 255) * k));
        const g = Math.min(255, Math.round(((n >> 8) & 255) * k));
        const b = Math.min(255, Math.round((n & 255) * k));
        return `rgb(${r},${g},${b})`;
      };
      type Face = { z: number; svg: string };
      const faces: Face[] = [];
      const STEP = 3;
      a.ribbons.forEach((rb, ri) => {
        const front: { x: number; y: number; z: number }[] = [], back: { x: number; y: number; z: number }[] = [];
        for (let i = 0; i < rb.top.length; i += STEP) {
          front.push(proj(rb.top[i].x, rb.top[i].y, rb.z));
          back.push(proj(rb.top[i].x, rb.top[i].y, rb.z - 1.6));
        }
        const bottomF: { x: number; y: number; z: number }[] = [];
        for (let i = 0; i < rb.bottom.length; i += STEP) bottomF.push(proj(rb.bottom[i].x, rb.bottom[i].y, rb.z));
        if (front.length < 2 || bottomF.length < 2) return;
        const zAvg = front.reduce((s, p) => s + p.z, 0) / front.length;
        const pts = (arr: { x: number; y: number }[]) => arr.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
        const gid = `sgr${ri}`;
        const topPoly = `<polygon points="${pts(back)} ${pts([...front].reverse())}" fill="${shadeCss(rb.color, 1.3)}" opacity="0.92"/>`;
        const frontPoly = `<polygon points="${pts(front)} ${pts([...bottomF].reverse())}" fill="${rb.color}" stroke="rgba(255,255,255,0.3)" stroke-width="0.5"/>`;
        void gid;
        faces.push({ z: zAvg, svg: topPoly + frontPoly });
      });
      faces.sort((p, q) => q.z - p.z);
      const labels = captureLabelPositions(container, a.labelRefs);
      const legend = STREAM_COUNTRIES.map((c) => ({ label: c.name, color: c.color }));
      const scratch = document.createElement('canvas').getContext('2d')!;
      scratch.font = `600 11px ${theme.fontBody}`;
      const lay = legendRows((s) => scratch.measureText(s).width, legend, W);
      const headH = title ? 36 : 10;
      const footnote = `Streamgraph · ${dim === '3d' ? 'Side elevation' : 'Top-down'} view · 1924–2022`;
      const TH = Math.round(headH + H + lay.height + 20);
      let labelSvg = '';
      labels.forEach((l) => {
        const fs = l.fontSize || 10;
        scratch.font = `${l.bold ? 700 : 600} ${fs}px ${theme.fontBody}`;
        labelSvg += `<text x="${l.x.toFixed(1)}" y="${(headH + l.y + fs * 0.32).toFixed(1)}" text-anchor="middle" font-size="${fs}" font-weight="${l.bold ? 700 : 600}" fill="${l.color || '#334155'}">${escXml(l.text)}</text>`;
      });
      let leg = '';
      lay.rows.forEach(({ x, y, it }) => {
        const yy = headH + H + 14 + y;
        leg += `<rect x="${x}" y="${(yy - 7.5).toFixed(1)}" width="9" height="9" rx="2" fill="${it.color}"/>`;
        leg += `<text x="${x + 13}" y="${yy}" font-size="10.5" font-weight="600" fill="#39443d">${escXml(it.label)}</text>`;
      });
      return `<?xml version="1.0" encoding="utf-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${TH}" viewBox="0 0 ${W} ${TH}">
<rect width="${W}" height="${TH}" fill="#ffffff"/>
<style>text { font-family: ${escXml(theme.fontBody)}, -apple-system, sans-serif; }</style>
${title ? `<text x="12" y="23" font-family="${escXml(theme.fontDisplay)}" font-weight="700" font-size="15" fill="#1c2620">${escXml(title)}</text>` : ''}
<g transform="translate(0,${headH})">
<g id="stream-ribbons">${faces.map((f) => f.svg).join('')}</g>
<g id="ribbon-labels">${labelSvg}</g>
</g>
<g id="legend">${leg}</g>
<text x="12" y="${TH - 6}" font-size="9.5" fill="rgba(28,38,32,0.5)">${escXml(footnote)}</text>
</svg>`;
    },
    setZoom: (on: boolean) => { setZoomOn(on); api.current?.setZoom(on); },
  }), [theme, dim]);

  return (
    <div ref={containerRef} className="absolute inset-0 h-full w-full overflow-hidden">
      {!ready && (
        <div className="absolute inset-0 z-20 flex items-center justify-center gap-2.5 bg-(--t-surface) font-body text-[12.5px] font-semibold text-muted">
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent opacity-70" />
          Loading chart…
        </div>
      )}
      <button
        onClick={(e) => { e.stopPropagation(); const next = !zoomOn; setZoomOn(next); api.current?.setZoom(next); }}
        data-tip={zoomOn ? 'Scroll-zoom: on' : 'Scroll-zoom: off'}
        className={`absolute left-2 top-2 z-10 rounded-full px-2 py-1 font-body text-[10px] font-bold backdrop-blur-sm transition ${zoomOn ? 'bg-primary text-white' : 'bg-black/45 text-white/85 hover:bg-black/60'}`}
        title={zoomOn ? 'Turn scroll-zoom off' : 'Turn scroll-zoom on'}
      >
        {zoomOn ? '🔍+ on' : '🔍+ off'}
      </button>
      {tip && (
        <div className="sg-tip font-body"
          style={{ left: Math.min(Math.max(tip.x, 90), (containerRef.current?.clientWidth || 300) - 90), top: Math.max(tip.y, 60) }}>
          <div className="tt-name"><span>{tip.name}</span><span style={{ fontSize: 10, color: tip.color, fontWeight: 700 }}>●</span></div>
          <div className="tt-role">{tip.sub}</div>
        </div>
      )}
    </div>
  );
});

export default ThreeStreamgraph;
